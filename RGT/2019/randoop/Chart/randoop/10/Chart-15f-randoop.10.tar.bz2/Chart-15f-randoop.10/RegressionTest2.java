import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color3 = java.awt.Color.ORANGE;
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset7 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer8 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset7, waferMapRenderer8);
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        waferMapPlot9.setDataset(waferMapDataset10);
        waferMapPlot9.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot9);
        jFreeChart14.setBackgroundImageAlpha(1.0f);
        jFreeChart14.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = jFreeChart14.getPadding();
        org.jfree.chart.block.LineBorder lineBorder20 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color4, stroke5, rectangleInsets19);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color3, stroke5);
        polarPlot1.setRadiusGridlineStroke(stroke5);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot1.getOrientation();
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(plotOrientation23);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        jFreeChart8.removeLegend();
        org.jfree.data.general.WaferMapDataset waferMapDataset15 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer16 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot17 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset15, waferMapRenderer16);
        org.jfree.data.general.WaferMapDataset waferMapDataset18 = null;
        waferMapPlot17.setDataset(waferMapDataset18);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) waferMapPlot17);
        jFreeChart8.plotChanged(plotChangeEvent20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.lang.String str23 = rectangleInsets22.toString();
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray25 = null;
        float[] floatArray26 = color24.getRGBComponents(floatArray25);
        org.jfree.chart.block.BlockBorder blockBorder27 = new org.jfree.chart.block.BlockBorder(rectangleInsets22, (java.awt.Paint) color24);
        jFreeChart8.setPadding(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str23.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(floatArray26);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color4 = java.awt.Color.green;
        java.awt.Color color5 = java.awt.Color.red;
        float[] floatArray11 = new float[] { '4', (-1L), 10L, 10.0f, 0 };
        float[] floatArray12 = color5.getComponents(floatArray11);
        float[] floatArray13 = color4.getColorComponents(floatArray11);
        float[] floatArray14 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (short) 100, 0, floatArray13);
        float[] floatArray15 = color0.getRGBComponents(floatArray13);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        java.lang.Object obj7 = xYPlot0.clone();
        xYPlot0.setDomainZeroBaselineVisible(true);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation10 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color2 = java.awt.Color.ORANGE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer7 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6, waferMapRenderer7);
        org.jfree.data.general.WaferMapDataset waferMapDataset9 = null;
        waferMapPlot8.setDataset(waferMapDataset9);
        waferMapPlot8.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot8);
        jFreeChart13.setBackgroundImageAlpha(1.0f);
        jFreeChart13.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = jFreeChart13.getPadding();
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color3, stroke4, rectangleInsets18);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color2, stroke4);
        polarPlot0.setRadiusGridlineStroke(stroke4);
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = polarPlot0.getOrientation();
        org.jfree.chart.axis.TickUnit tickUnit23 = polarPlot0.getAngleTickUnit();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(plotOrientation22);
        org.junit.Assert.assertNotNull(tickUnit23);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        java.awt.Shape shape4 = dateAxis2.getUpArrow();
        dateAxis2.centerRange((double) (short) 1);
        dateAxis2.setRange(0.0d, (double) '#');
        org.jfree.data.Range range12 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis2.setRange(range12, false, false);
        org.jfree.data.Range range17 = org.jfree.data.Range.expandToInclude(range12, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(2.0d, range12);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        boolean boolean6 = dateAxis1.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis1.getTickLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis1.getLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType11 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets8.createAdjustedRectangle(rectangle2D9, lengthAdjustmentType10, lengthAdjustmentType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isAngleGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        polarPlot0.setDataset(xYDataset2);
        java.awt.Font font4 = polarPlot0.getAngleLabelFont();
        polarPlot0.setRadiusGridlinesVisible(true);
        try {
            polarPlot0.zoom(0.14d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxis((int) (short) 10);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset();
        java.awt.Stroke stroke9 = categoryPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource9);
        org.jfree.data.Range range11 = dateAxis1.getRange();
        org.jfree.chart.ui.ProjectInfo projectInfo12 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str13 = projectInfo12.getLicenceText();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape20 = dateAxis19.getDownArrow();
        java.awt.Shape shape21 = dateAxis19.getUpArrow();
        dateAxis19.centerRange((double) (short) 1);
        dateAxis19.setRange(0.0d, (double) '#');
        dateAxis19.setAutoRange(false);
        categoryPlot14.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis19);
        java.util.Date date30 = dateAxis19.getMinimumDate();
        java.awt.Paint paint31 = dateAxis19.getAxisLinePaint();
        boolean boolean32 = projectInfo12.equals((java.lang.Object) dateAxis19);
        boolean boolean33 = dateAxis19.isNegativeArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit36 = dateAxis35.getTickUnit();
        java.util.Date date37 = dateAxis19.calculateHighestVisibleTickValue(dateTickUnit36);
        dateAxis1.setMinimumDate(date37);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dateTickUnit36);
        org.junit.Assert.assertNotNull(date37);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str2 = categoryAxis3D1.getLabelURL();
        double double3 = categoryAxis3D1.getCategoryMargin();
        categoryAxis3D1.setLabelURL("RectangleEdge.TOP");
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis3D1.setTickMarkStroke(stroke6);
        java.awt.Font font9 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) (short) 100);
        java.awt.Paint paint11 = null;
        categoryAxis3D1.setTickLabelPaint((java.lang.Comparable) (-1L), paint11);
        java.awt.Paint paint13 = categoryAxis3D1.getTickMarkPaint();
        categoryAxis3D1.setFixedDimension((double) (-1L));
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement24 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment20, verticalAlignment21, (double) 10L, (double) 100.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint26 = categoryPlot25.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot25.zoomDomainAxes(8.0d, plotRenderingInfo29, point2D30);
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot25);
        java.awt.Font font33 = legendTitle32.getItemFont();
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke35 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset37 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer38 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot39 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset37, waferMapRenderer38);
        org.jfree.data.general.WaferMapDataset waferMapDataset40 = null;
        waferMapPlot39.setDataset(waferMapDataset40);
        waferMapPlot39.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot39);
        jFreeChart44.setBackgroundImageAlpha(1.0f);
        jFreeChart44.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = jFreeChart44.getPadding();
        org.jfree.chart.block.LineBorder lineBorder50 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color34, stroke35, rectangleInsets49);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = lineBorder50.getInsets();
        columnArrangement24.add((org.jfree.chart.block.Block) legendTitle32, (java.lang.Object) rectangleInsets51);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = legendTitle32.getLegendItemGraphicEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        try {
            org.jfree.chart.axis.AxisState axisState55 = categoryAxis3D1.draw(graphics2D16, 0.0d, rectangle2D18, rectangle2D19, rectangleEdge53, plotRenderingInfo54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(verticalAlignment21);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(rectangleEdge53);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        waferMapPlot4.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot4);
        jFreeChart9.setBackgroundImageAlpha(1.0f);
        jFreeChart9.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = jFreeChart9.getPadding();
        boolean boolean15 = jFreeChart9.isNotify();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart9, chartChangeEventType16);
        org.jfree.chart.JFreeChart jFreeChart18 = chartChangeEvent17.getChart();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        try {
            java.awt.image.BufferedImage bufferedImage22 = jFreeChart18.createBufferedImage((int) (short) -1, 100, chartRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (100) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(jFreeChart18);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke1 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer4 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset3, waferMapRenderer4);
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        waferMapPlot5.setDataset(waferMapDataset6);
        waferMapPlot5.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot5);
        jFreeChart10.setBackgroundImageAlpha(1.0f);
        jFreeChart10.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = jFreeChart10.getPadding();
        org.jfree.chart.block.LineBorder lineBorder16 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = lineBorder16.getInsets();
        java.awt.Paint paint18 = lineBorder16.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint20 = categoryPlot19.getNoDataMessagePaint();
        categoryPlot19.setAnchorValue(0.0d);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str25 = textTitle24.getURLText();
        java.awt.Paint paint26 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle24.setBackgroundPaint(paint26);
        categoryPlot19.setDomainGridlinePaint(paint26);
        categoryPlot19.setWeight((int) (byte) -1);
        categoryPlot19.setAnchorValue(90.0d, false);
        double[] doubleArray38 = new double[] { 0.4d, (-1) };
        double[] doubleArray41 = new double[] { 0.4d, (-1) };
        double[] doubleArray44 = new double[] { 0.4d, (-1) };
        double[] doubleArray47 = new double[] { 0.4d, (-1) };
        double[] doubleArray50 = new double[] { 0.4d, (-1) };
        double[] doubleArray53 = new double[] { 0.4d, (-1) };
        double[][] doubleArray54 = new double[][] { doubleArray38, doubleArray41, doubleArray44, doubleArray47, doubleArray50, doubleArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "{0}", doubleArray54);
        org.jfree.data.Range range56 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset55);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = categoryPlot19.getRendererForDataset(categoryDataset55);
        java.lang.Number number58 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D60 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font62 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D60.setTickLabelFont((java.lang.Comparable) (short) 10, font62);
        int int64 = categoryAxis3D60.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke65 = categoryAxis3D60.getAxisLineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean67 = numberAxis66.getAutoRangeIncludesZero();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand68 = null;
        numberAxis66.setMarkerBand(markerAxisBand68);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer70 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot71 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D60, (org.jfree.chart.axis.ValueAxis) numberAxis66, categoryItemRenderer70);
        boolean boolean72 = lineBorder16.equals((java.lang.Object) categoryAxis3D60);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNull(categoryItemRenderer57);
        org.junit.Assert.assertTrue("'" + number58 + "' != '" + 0.4d + "'", number58.equals(0.4d));
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 1, 0);
        categoryPlot0.setDrawSharedDomainAxis(true);
        java.lang.Object obj6 = categoryPlot0.clone();
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker7, layer8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getInteriorGap();
        boolean boolean2 = piePlot3D0.getDarkerSides();
        piePlot3D0.setCircular(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08d + "'", double1 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        float float7 = waferMapPlot4.getBackgroundImageAlpha();
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker1.setLabelAnchor(rectangleAnchor9);
        java.awt.Paint paint11 = valueMarker1.getOutlinePaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = valueMarker1.getLabelOffsetType();
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(lengthAdjustmentType12);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.Object obj1 = ringPlot0.clone();
        double double2 = ringPlot0.getMaximumExplodePercent();
        double double3 = ringPlot0.getInnerSeparatorExtension();
        java.awt.Paint paint4 = ringPlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke5 = ringPlot0.getBaseSectionOutlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        java.awt.Paint paint9 = ringPlot0.getSectionOutlinePaint((java.lang.Comparable) dateTickUnit8);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray3 = null;
        float[] floatArray4 = color2.getRGBComponents(floatArray3);
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color2);
        double double6 = rectangleInsets0.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str1.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean2 = numberAxis0.isAutoRange();
        numberAxis0.setLabelAngle((double) '4');
        org.jfree.data.RangeType rangeType5 = numberAxis0.getRangeType();
        double double6 = numberAxis0.getUpperMargin();
        boolean boolean7 = numberAxis0.isVerticalTickLabels();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis0.getLabelInsets();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rangeType5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        boolean boolean14 = jFreeChart8.isNotify();
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart8.getLegend(200);
        jFreeChart8.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.data.general.WaferMapDataset waferMapDataset19 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer20 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot21 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset19, waferMapRenderer20);
        org.jfree.data.general.WaferMapDataset waferMapDataset22 = null;
        waferMapPlot21.setDataset(waferMapDataset22);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent24 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) waferMapPlot21);
        org.jfree.chart.JFreeChart jFreeChart25 = plotChangeEvent24.getChart();
        jFreeChart8.plotChanged(plotChangeEvent24);
        org.jfree.chart.plot.Plot plot27 = plotChangeEvent24.getPlot();
        java.awt.Font font28 = plot27.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(legendTitle16);
        org.junit.Assert.assertNull(jFreeChart25);
        org.junit.Assert.assertNotNull(plot27);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        categoryPlot0.setAnchorValue(0.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str6 = textTitle5.getURLText();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle5.setBackgroundPaint(paint7);
        categoryPlot0.setDomainGridlinePaint(paint7);
        categoryPlot0.setWeight((int) (byte) -1);
        categoryPlot0.setAnchorValue(90.0d, false);
        double[] doubleArray19 = new double[] { 0.4d, (-1) };
        double[] doubleArray22 = new double[] { 0.4d, (-1) };
        double[] doubleArray25 = new double[] { 0.4d, (-1) };
        double[] doubleArray28 = new double[] { 0.4d, (-1) };
        double[] doubleArray31 = new double[] { 0.4d, (-1) };
        double[] doubleArray34 = new double[] { 0.4d, (-1) };
        double[][] doubleArray35 = new double[][] { doubleArray19, doubleArray22, doubleArray25, doubleArray28, doubleArray31, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "{0}", doubleArray35);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset36);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = categoryPlot0.getRendererForDataset(categoryDataset36);
        java.lang.Number number39 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset36);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset36, true);
        java.lang.Number number42 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset36);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNull(categoryItemRenderer38);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 0.4d + "'", number39.equals(0.4d));
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + (-1.0d) + "'", number42.equals((-1.0d)));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (-16711681), 3.0d, 1, (java.lang.Comparable) (-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean2 = numberAxis1.getAutoRangeIncludesZero();
        java.lang.String str3 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = numberAxis1.getMarkerBand();
        double double5 = numberAxis1.getFixedDimension();
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis1.getStandardTickUnits();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, polarItemRenderer7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(markerAxisBand4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxisForDataset((-1));
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str10 = categoryAxis3D9.getLabelURL();
        double double11 = categoryAxis3D9.getCategoryMargin();
        categoryAxis3D9.setLabelURL("RectangleEdge.TOP");
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis3D9.setTickMarkStroke(stroke14);
        java.awt.Font font17 = categoryAxis3D9.getTickLabelFont((java.lang.Comparable) (short) 100);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D18.clearCategoryLabelToolTips();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D21 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str22 = categoryAxis3D21.getLabelURL();
        double double23 = categoryAxis3D21.getCategoryMargin();
        categoryAxis3D21.setLabelURL("RectangleEdge.TOP");
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray26 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis3D9, categoryAxis3D18, categoryAxis3D21 };
        categoryPlot0.setDomainAxes(categoryAxisArray26);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent28);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertNotNull(categoryAxisArray26);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(1.0d, 90.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.chart.util.UnitType unitType4 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean5 = lengthConstraintType3.equals((java.lang.Object) unitType4);
        java.lang.String str6 = unitType4.toString();
        java.awt.Paint paint7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        boolean boolean8 = unitType4.equals((java.lang.Object) paint7);
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UnitType.ABSOLUTE" + "'", str6.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.data.category.CategoryDataset categoryDataset6 = categoryPlot0.getDataset(1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRenderer((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(categoryDataset6);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNull(categoryItemRenderer9);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.Object obj1 = ringPlot0.clone();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint5 = ringPlot4.getLabelBackgroundPaint();
        ringPlot4.setShadowXOffset((double) (-1.0f));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.PiePlotState piePlotState10 = ringPlot0.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.PiePlot) ringPlot4, (java.lang.Integer) 200, plotRenderingInfo9);
        double double11 = ringPlot0.getInnerSeparatorExtension();
        double double12 = ringPlot0.getInnerSeparatorExtension();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator13 = ringPlot0.getLegendLabelGenerator();
        ringPlot0.setPieIndex(0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(piePlotState10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator13);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer11 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset10, waferMapRenderer11);
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        waferMapPlot12.setDataset(waferMapDataset13);
        waferMapPlot12.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot12);
        jFreeChart17.setBackgroundImageAlpha(1.0f);
        jFreeChart17.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = jFreeChart17.getPadding();
        org.jfree.chart.block.LineBorder lineBorder23 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color7, stroke8, rectangleInsets22);
        xYPlot0.setDomainZeroBaselineStroke(stroke8);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape27 = dateAxis26.getDownArrow();
        java.awt.Shape shape28 = dateAxis26.getUpArrow();
        dateAxis26.centerRange((double) (short) 1);
        dateAxis26.setRange(0.0d, (double) '#');
        boolean boolean34 = dateAxis26.isNegativeArrowVisible();
        java.awt.Paint paint35 = dateAxis26.getTickMarkPaint();
        xYPlot0.setRangeCrosshairPaint(paint35);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = xYPlot0.getDomainAxisEdge((int) (short) 100);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline42 = dateAxis41.getTimeline();
        java.awt.Shape shape43 = dateAxis41.getDownArrow();
        xYPlot0.setDomainAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis41, false);
        xYPlot0.clearRangeAxes();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(timeline42);
        org.junit.Assert.assertNotNull(shape43);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(8.0d, plotRenderingInfo4, point2D5);
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle7.getLegendItemGraphicEdge();
        boolean boolean9 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge8);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = textTitle15.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = textTitle15.getPosition();
        jFreeChart8.setTitle(textTitle15);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint20 = categoryPlot19.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot19.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot19.zoomDomainAxes(8.0d, plotRenderingInfo23, point2D24);
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot19);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = legendTitle26.getLegendItemGraphicEdge();
        java.awt.Color color28 = java.awt.Color.gray;
        java.awt.Color color29 = java.awt.Color.green;
        java.awt.Color color30 = java.awt.Color.red;
        float[] floatArray36 = new float[] { '4', (-1L), 10L, 10.0f, 0 };
        float[] floatArray37 = color30.getComponents(floatArray36);
        float[] floatArray38 = color29.getColorComponents(floatArray36);
        float[] floatArray39 = color28.getComponents(floatArray38);
        legendTitle26.setItemPaint((java.awt.Paint) color28);
        jFreeChart8.removeSubtitle((org.jfree.chart.title.Title) legendTitle26);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint44 = textTitle43.getPaint();
        legendTitle26.setBackgroundPaint(paint44);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = legendTitle26.getLegendItemGraphicLocation();
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(rectangleAnchor46);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot0.getRenderer(0);
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace14);
        java.awt.Stroke stroke16 = null;
        try {
            xYPlot0.setDomainCrosshairStroke(stroke16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(xYItemRenderer12);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 10L, (double) 100.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot5.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomDomainAxes(8.0d, plotRenderingInfo9, point2D10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot5);
        java.awt.Font font13 = legendTitle12.getItemFont();
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset17 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer18 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot19 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset17, waferMapRenderer18);
        org.jfree.data.general.WaferMapDataset waferMapDataset20 = null;
        waferMapPlot19.setDataset(waferMapDataset20);
        waferMapPlot19.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot19);
        jFreeChart24.setBackgroundImageAlpha(1.0f);
        jFreeChart24.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = jFreeChart24.getPadding();
        org.jfree.chart.block.LineBorder lineBorder30 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color14, stroke15, rectangleInsets29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = lineBorder30.getInsets();
        columnArrangement4.add((org.jfree.chart.block.Block) legendTitle12, (java.lang.Object) rectangleInsets31);
        java.lang.Object obj33 = legendTitle12.clone();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(obj33);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(8.0d, plotRenderingInfo4, point2D5);
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle7.getLegendItemGraphicEdge();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint10 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot9.setRangeZeroBaselinePaint(paint10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray13 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer12 };
        xYPlot9.setRenderers(xYItemRendererArray13);
        legendTitle7.setSources((org.jfree.chart.LegendItemSource[]) xYItemRendererArray13);
        java.lang.Object obj16 = legendTitle7.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendTitle7.getLegendItemGraphicLocation();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(xYItemRendererArray13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isNegativeArrowVisible();
        java.awt.Shape shape2 = dateAxis0.getLeftArrow();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        org.jfree.data.general.WaferMapDataset waferMapDataset7 = null;
        waferMapPlot6.setDataset(waferMapDataset7);
        float float9 = waferMapPlot6.getBackgroundImageAlpha();
        valueMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot6);
        java.awt.Font font11 = valueMarker3.getLabelFont();
        dateAxis1.setTickLabelFont(font11);
        org.jfree.data.Range range15 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis1.setRangeWithMargins(range15);
        float float17 = dateAxis1.getTickMarkInsideLength();
        dateAxis1.setLowerMargin(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis22.resizeRange((double) 'a', (double) (short) 10);
        java.awt.Stroke stroke26 = dateAxis22.getAxisLineStroke();
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis22.setTickUnit(dateTickUnit27);
        java.util.Date date29 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit27);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5f + "'", float9 == 0.5f);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(dateTickUnit27);
        org.junit.Assert.assertNotNull(date29);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font2 = textTitle1.getFont();
        java.awt.Graphics2D graphics2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textTitle1.arrange(graphics2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        waferMapPlot4.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot4);
        jFreeChart9.setBackgroundImageAlpha(1.0f);
        jFreeChart9.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = jFreeChart9.getPadding();
        boolean boolean15 = jFreeChart9.isNotify();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart9, chartChangeEventType16);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str20 = textTitle19.getURLText();
        jFreeChart9.removeSubtitle((org.jfree.chart.title.Title) textTitle19);
        jFreeChart9.setBackgroundImageAlpha((float) 0L);
        jFreeChart9.setTextAntiAlias(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint27 = categoryPlot26.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot26.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot26.zoomDomainAxes(8.0d, plotRenderingInfo30, point2D31);
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot26);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = legendTitle33.getLegendItemGraphicEdge();
        jFreeChart9.addLegend(legendTitle33);
        java.awt.RenderingHints renderingHints36 = jFreeChart9.getRenderingHints();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNotNull(renderingHints36);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 10L, (double) 100.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot5.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomDomainAxes(8.0d, plotRenderingInfo9, point2D10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot5);
        java.awt.Font font13 = legendTitle12.getItemFont();
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset17 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer18 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot19 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset17, waferMapRenderer18);
        org.jfree.data.general.WaferMapDataset waferMapDataset20 = null;
        waferMapPlot19.setDataset(waferMapDataset20);
        waferMapPlot19.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot19);
        jFreeChart24.setBackgroundImageAlpha(1.0f);
        jFreeChart24.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = jFreeChart24.getPadding();
        org.jfree.chart.block.LineBorder lineBorder30 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color14, stroke15, rectangleInsets29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = lineBorder30.getInsets();
        columnArrangement4.add((org.jfree.chart.block.Block) legendTitle12, (java.lang.Object) rectangleInsets31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = legendTitle12.getLegendItemGraphicEdge();
        java.lang.String str34 = rectangleEdge33.toString();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "RectangleEdge.LEFT" + "'", str34.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        boolean boolean2 = ringPlot0.isCircular();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setRangeCrosshairValue((double) 200, false);
        boolean boolean9 = categoryPlot5.isRangeCrosshairVisible();
        java.awt.Color color11 = java.awt.Color.white;
        java.awt.Color color12 = java.awt.Color.getColor("", color11);
        categoryPlot5.setNoDataMessagePaint((java.awt.Paint) color11);
        valueMarker4.setOutlinePaint((java.awt.Paint) color11);
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color11);
        double double16 = ringPlot0.getInteriorGap();
        float float17 = ringPlot0.getBackgroundAlpha();
        double double18 = ringPlot0.getLabelLinkMargin();
        ringPlot0.setLabelLinksVisible(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.08d + "'", double16 == 0.08d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.025d + "'", double18 == 0.025d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        dateAxis1.setAutoRange(false);
        dateAxis1.setAxisLineVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        xYPlot13.clearDomainAxes();
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot13);
        boolean boolean17 = dateAxis1.isHiddenValue(0L);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setName("Pie Plot");
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "RectangleEdge.TOP", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "ThreadContext", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=90.0]");
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        java.util.Date date3 = dateAxis1.getMinimumDate();
        dateAxis1.setRangeWithMargins((double) (short) 10, (double) 255);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        boolean boolean3 = xYPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer7 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6, waferMapRenderer7);
        org.jfree.data.general.WaferMapDataset waferMapDataset9 = null;
        waferMapPlot8.setDataset(waferMapDataset9);
        float float11 = waferMapPlot8.getBackgroundImageAlpha();
        valueMarker5.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker5.setLabelAnchor(rectangleAnchor13);
        java.awt.Paint paint15 = valueMarker5.getOutlinePaint();
        java.awt.Stroke stroke16 = valueMarker5.getStroke();
        org.jfree.chart.util.Layer layer17 = null;
        try {
            xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker5, layer17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape4 = dateAxis3.getDownArrow();
        dateAxis1.setUpArrow(shape4);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape9, "{0}", "hi!");
        chartEntity6.setArea(shape9);
        java.lang.Object obj14 = chartEntity6.clone();
        java.awt.Shape shape15 = chartEntity6.getArea();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        boolean boolean2 = ringPlot0.isCircular();
        java.awt.Stroke stroke3 = ringPlot0.getLabelLinkStroke();
        java.awt.Paint paint4 = ringPlot0.getShadowPaint();
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean6 = polarPlot5.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint10 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot9.setRangeZeroBaselinePaint(paint10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray13 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer12 };
        xYPlot9.setRenderers(xYItemRendererArray13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        xYPlot9.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo17, point2D18);
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        xYPlot9.setFixedRangeAxisSpace(axisSpace20);
        java.awt.Stroke stroke22 = xYPlot9.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D23 = xYPlot9.getQuadrantOrigin();
        polarPlot5.zoomDomainAxes(1.0E-8d, plotRenderingInfo8, point2D23);
        ringPlot0.setParent((org.jfree.chart.plot.Plot) polarPlot5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment27 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement30 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment26, verticalAlignment27, (double) 10L, (double) 100.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint32 = categoryPlot31.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation33 = categoryPlot31.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot31.zoomDomainAxes(8.0d, plotRenderingInfo35, point2D36);
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot31);
        java.awt.Font font39 = legendTitle38.getItemFont();
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset43 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer44 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot45 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset43, waferMapRenderer44);
        org.jfree.data.general.WaferMapDataset waferMapDataset46 = null;
        waferMapPlot45.setDataset(waferMapDataset46);
        waferMapPlot45.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot45);
        jFreeChart50.setBackgroundImageAlpha(1.0f);
        jFreeChart50.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = jFreeChart50.getPadding();
        org.jfree.chart.block.LineBorder lineBorder56 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color40, stroke41, rectangleInsets55);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = lineBorder56.getInsets();
        columnArrangement30.add((org.jfree.chart.block.Block) legendTitle38, (java.lang.Object) rectangleInsets57);
        columnArrangement30.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement60 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle61 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0, (org.jfree.chart.block.Arrangement) columnArrangement30, (org.jfree.chart.block.Arrangement) flowArrangement60);
        java.awt.Graphics2D graphics2D62 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint63 = null;
        org.jfree.chart.util.Size2D size2D64 = legendTitle61.arrange(graphics2D62, rectangleConstraint63);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(xYItemRendererArray13);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(point2D23);
        org.junit.Assert.assertNotNull(verticalAlignment27);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(size2D64);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.Object obj1 = ringPlot0.clone();
        double double2 = ringPlot0.getMaximumExplodePercent();
        ringPlot0.setShadowXOffset((-7.0d));
        int int5 = ringPlot0.getPieIndex();
        ringPlot0.setMaximumLabelWidth(90.0d);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.Object obj1 = ringPlot0.clone();
        double double2 = ringPlot0.getMaximumExplodePercent();
        ringPlot0.setCircular(false);
        ringPlot0.setCircular(true);
        ringPlot0.setOutlineVisible(false);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = ringPlot0.getLegendLabelToolTipGenerator();
        java.awt.Stroke stroke10 = ringPlot0.getBaseSectionOutlineStroke();
        ringPlot0.setBackgroundImageAlpha(0.5f);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isAngleGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        polarPlot0.setDataset(xYDataset2);
        java.awt.Font font4 = polarPlot0.getAngleLabelFont();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.data.xy.XYDataset xYDataset7 = polarPlot0.getDataset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        try {
            polarPlot0.zoomRangeAxes(100.0d, (double) 0.8f, plotRenderingInfo10, point2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(xYDataset7);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace2 = xYPlot0.getFixedRangeAxisSpace();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        xYPlot0.drawBackgroundImage(graphics2D3, rectangle2D4);
        boolean boolean6 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint8 = categoryPlot7.getNoDataMessagePaint();
        java.awt.Color color9 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint12 = textTitle11.getPaint();
        java.awt.Color color13 = java.awt.Color.red;
        java.awt.Color color14 = java.awt.Color.red;
        java.awt.Color color15 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray16 = new java.awt.Paint[] { color9, paint12, color13, color14, color15 };
        java.awt.Paint[] paintArray17 = null;
        java.awt.Stroke stroke18 = null;
        java.awt.Stroke[] strokeArray19 = new java.awt.Stroke[] { stroke18 };
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] {};
        java.awt.Shape shape21 = null;
        java.awt.Shape[] shapeArray22 = new java.awt.Shape[] { shape21 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray16, paintArray17, strokeArray19, strokeArray20, shapeArray22);
        java.awt.Stroke stroke24 = defaultDrawingSupplier23.getNextStroke();
        java.awt.Paint paint25 = defaultDrawingSupplier23.getNextFillPaint();
        java.awt.Paint paint26 = defaultDrawingSupplier23.getNextPaint();
        categoryPlot7.setRangeGridlinePaint(paint26);
        java.util.List list28 = categoryPlot7.getCategories();
        org.jfree.chart.axis.AxisLocation axisLocation30 = categoryPlot7.getRangeAxisLocation((int) '#');
        org.jfree.chart.plot.PlotOrientation plotOrientation31 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation30, plotOrientation31);
        xYPlot0.setRangeAxisLocation(axisLocation30);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(strokeArray19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(shapeArray22);
        org.junit.Assert.assertNull(stroke24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(list28);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(plotOrientation31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = piePlotState1.getExplodedPieArea();
        piePlotState1.setPassesRequired(2);
        double double5 = piePlotState1.getTotal();
        double double6 = piePlotState1.getPieHRadius();
        org.junit.Assert.assertNull(rectangle2D2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setInfo("hi!");
        projectInfo0.setInfo("");
        projectInfo0.setInfo("");
        projectInfo0.setVersion("TextAnchor.HALF_ASCENT_CENTER");
        projectInfo0.setCopyright("");
        java.lang.String str11 = projectInfo0.getLicenceName();
        java.lang.String str12 = projectInfo0.getName();
        java.awt.Image image13 = projectInfo0.getLogo();
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(image13);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setInfo("hi!");
        projectInfo0.setInfo("");
        projectInfo0.setInfo("");
        projectInfo0.setInfo("{0}");
        java.lang.String str9 = projectInfo0.getCopyright();
        projectInfo0.setLicenceName("ThreadContext");
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot0.getDomainAxisEdge();
        java.util.List list14 = xYPlot0.getAnnotations();
        xYPlot0.clearDomainAxes();
        xYPlot0.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color2 = java.awt.Color.ORANGE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer7 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6, waferMapRenderer7);
        org.jfree.data.general.WaferMapDataset waferMapDataset9 = null;
        waferMapPlot8.setDataset(waferMapDataset9);
        waferMapPlot8.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot8);
        jFreeChart13.setBackgroundImageAlpha(1.0f);
        jFreeChart13.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = jFreeChart13.getPadding();
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color3, stroke4, rectangleInsets18);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color2, stroke4);
        polarPlot0.setRadiusGridlineStroke(stroke4);
        polarPlot0.removeCornerTextItem("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        ringPlot24.setIgnoreZeroValues(true);
        java.awt.Stroke stroke27 = ringPlot24.getLabelLinkStroke();
        polarPlot0.setOutlineStroke(stroke27);
        polarPlot0.setAngleLabelsVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.plot.PolarPlot polarPlot33 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean34 = polarPlot33.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint38 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot37.setRangeZeroBaselinePaint(paint38);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray41 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer40 };
        xYPlot37.setRenderers(xYItemRendererArray41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        java.awt.geom.Point2D point2D46 = null;
        xYPlot37.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo45, point2D46);
        org.jfree.chart.axis.AxisSpace axisSpace48 = null;
        xYPlot37.setFixedRangeAxisSpace(axisSpace48);
        java.awt.Stroke stroke50 = xYPlot37.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D51 = xYPlot37.getQuadrantOrigin();
        polarPlot33.zoomDomainAxes(1.0E-8d, plotRenderingInfo36, point2D51);
        polarPlot0.zoomDomainAxes((double) 100.0f, plotRenderingInfo32, point2D51);
        int int54 = polarPlot0.getSeriesCount();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(xYItemRendererArray41);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(point2D51);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getNoDataMessagePaint();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot3.setRangeCrosshairStroke(stroke5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot3.getDomainAxisLocation();
        xYPlot0.setRangeAxisLocation(axisLocation7, false);
        xYPlot0.setOutlineVisible(false);
        boolean boolean12 = xYPlot0.isDomainCrosshairVisible();
        java.awt.Paint paint13 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = xYPlot0.getDomainAxisEdge();
        java.util.List list15 = xYPlot0.getAnnotations();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getFirstTextFragment();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        try {
            textLine1.draw(graphics2D3, (float) (-1L), (float) 2, textAnchor6, (float) 500, 0.0f, 90.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textFragment2);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(8.0d, plotRenderingInfo4, point2D5);
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle7.getLegendItemGraphicEdge();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.data.general.WaferMapDataset waferMapDataset11 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer12 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset11, waferMapRenderer12);
        org.jfree.data.general.WaferMapDataset waferMapDataset14 = null;
        waferMapPlot13.setDataset(waferMapDataset14);
        waferMapPlot13.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot13);
        jFreeChart18.setBackgroundImageAlpha(1.0f);
        jFreeChart18.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = jFreeChart18.getPadding();
        boolean boolean24 = jFreeChart18.isNotify();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color9, jFreeChart18, chartChangeEventType25);
        boolean boolean27 = legendTitle7.equals((java.lang.Object) color9);
        org.jfree.chart.block.BlockContainer blockContainer28 = legendTitle7.getItemContainer();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(blockContainer28);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape4 = dateAxis3.getDownArrow();
        dateAxis1.setUpArrow(shape4);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.PiePlotState piePlotState8 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo7);
        java.awt.geom.Rectangle2D rectangle2D9 = piePlotState8.getLinkArea();
        double double10 = piePlotState8.getTotal();
        java.awt.geom.Rectangle2D rectangle2D11 = piePlotState8.getExplodedPieArea();
        boolean boolean12 = chartEntity6.equals((java.lang.Object) rectangle2D11);
        java.lang.Object obj13 = chartEntity6.clone();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(rectangle2D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource9);
        org.jfree.chart.plot.Plot plot11 = dateAxis1.getPlot();
        double[] doubleArray16 = new double[] { 0.4d, (-1) };
        double[] doubleArray19 = new double[] { 0.4d, (-1) };
        double[] doubleArray22 = new double[] { 0.4d, (-1) };
        double[] doubleArray25 = new double[] { 0.4d, (-1) };
        double[] doubleArray28 = new double[] { 0.4d, (-1) };
        double[] doubleArray31 = new double[] { 0.4d, (-1) };
        double[][] doubleArray32 = new double[][] { doubleArray16, doubleArray19, doubleArray22, doubleArray25, doubleArray28, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "{0}", doubleArray32);
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset33);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset33, true);
        dateAxis1.setRange(range36);
        dateAxis1.setUpperMargin(0.08d);
        dateAxis1.setUpperMargin(1.0E-8d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(range36);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace2 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace3);
        int int5 = xYPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection2);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        categoryPlot0.markerChanged(markerChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.lang.String str8 = numberAxis6.getLabelURL();
        numberAxis6.setFixedAutoRange((double) 0);
        java.awt.Paint paint11 = numberAxis6.getTickMarkPaint();
        org.jfree.data.Range range12 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        java.lang.String str2 = numberAxis0.getLabelURL();
        numberAxis0.setFixedAutoRange((double) 0);
        java.awt.Paint paint5 = numberAxis0.getTickMarkPaint();
        numberAxis0.setRange((double) 1L, 200.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint17 = categoryPlot16.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot16.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation18);
        org.jfree.chart.plot.Plot plot20 = xYPlot0.getParent();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNull(plot20);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Color color6 = java.awt.Color.white;
        java.awt.Color color7 = java.awt.Color.getColor("", color6);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray10 = null;
        float[] floatArray11 = color9.getRGBComponents(floatArray10);
        float[] floatArray12 = color6.getComponents(floatArray10);
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer14 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot15 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset13, waferMapRenderer14);
        org.jfree.data.general.WaferMapDataset waferMapDataset16 = null;
        waferMapPlot15.setDataset(waferMapDataset16);
        float float18 = waferMapPlot15.getBackgroundImageAlpha();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = null;
        waferMapPlot15.datasetChanged(datasetChangeEvent19);
        java.awt.Color color22 = java.awt.Color.white;
        java.awt.Color color23 = java.awt.Color.getColor("", color22);
        int int24 = color22.getRGB();
        waferMapPlot15.setOutlinePaint((java.awt.Paint) color22);
        java.awt.color.ColorSpace colorSpace26 = color22.getColorSpace();
        java.awt.Color color27 = java.awt.Color.red;
        float[] floatArray33 = new float[] { '4', (-1L), 10L, 10.0f, 0 };
        float[] floatArray34 = color27.getComponents(floatArray33);
        float[] floatArray35 = color6.getColorComponents(colorSpace26, floatArray34);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.5f + "'", float18 == 0.5f);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(colorSpace26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color2 = java.awt.Color.ORANGE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer7 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6, waferMapRenderer7);
        org.jfree.data.general.WaferMapDataset waferMapDataset9 = null;
        waferMapPlot8.setDataset(waferMapDataset9);
        waferMapPlot8.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot8);
        jFreeChart13.setBackgroundImageAlpha(1.0f);
        jFreeChart13.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = jFreeChart13.getPadding();
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color3, stroke4, rectangleInsets18);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color2, stroke4);
        polarPlot0.setRadiusGridlineStroke(stroke4);
        polarPlot0.removeCornerTextItem("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        ringPlot24.setIgnoreZeroValues(true);
        java.awt.Stroke stroke27 = ringPlot24.getLabelLinkStroke();
        polarPlot0.setOutlineStroke(stroke27);
        polarPlot0.setAngleLabelsVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.plot.PolarPlot polarPlot33 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean34 = polarPlot33.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint38 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot37.setRangeZeroBaselinePaint(paint38);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray41 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer40 };
        xYPlot37.setRenderers(xYItemRendererArray41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        java.awt.geom.Point2D point2D46 = null;
        xYPlot37.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo45, point2D46);
        org.jfree.chart.axis.AxisSpace axisSpace48 = null;
        xYPlot37.setFixedRangeAxisSpace(axisSpace48);
        java.awt.Stroke stroke50 = xYPlot37.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D51 = xYPlot37.getQuadrantOrigin();
        polarPlot33.zoomDomainAxes(1.0E-8d, plotRenderingInfo36, point2D51);
        polarPlot0.zoomDomainAxes((double) 100.0f, plotRenderingInfo32, point2D51);
        java.lang.Object obj54 = polarPlot0.clone();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(xYItemRendererArray41);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(point2D51);
        org.junit.Assert.assertNotNull(obj54);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        blockResult0.setEntityCollection(entityCollection1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean2 = numberAxis0.isAutoRange();
        numberAxis0.setLabelAngle((double) '4');
        org.jfree.data.RangeType rangeType5 = numberAxis0.getRangeType();
        java.text.NumberFormat numberFormat6 = numberAxis0.getNumberFormatOverride();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rangeType5);
        org.junit.Assert.assertNull(numberFormat6);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        boolean boolean2 = ringPlot0.isCircular();
        java.awt.Paint paint3 = ringPlot0.getSeparatorPaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator4);
        org.jfree.chart.util.Rotation rotation6 = ringPlot0.getDirection();
        java.awt.Paint paint7 = ringPlot0.getLabelLinkPaint();
        double double8 = ringPlot0.getMaximumExplodePercent();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.junit.Assert.assertNotNull(numberTickUnit0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        boolean boolean2 = ringPlot0.isCircular();
        java.awt.Paint paint3 = ringPlot0.getSeparatorPaint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat5 = standardPieSectionLabelGenerator4.getNumberFormat();
        java.lang.Object obj6 = standardPieSectionLabelGenerator4.clone();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.text.NumberFormat numberFormat8 = standardPieSectionLabelGenerator4.getNumberFormat();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(numberFormat5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(numberFormat8);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getPadding();
        java.awt.Paint paint3 = textTitle1.getPaint();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        boolean boolean2 = ringPlot0.isCircular();
        java.awt.Paint paint3 = ringPlot0.getSeparatorPaint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat5 = standardPieSectionLabelGenerator4.getNumberFormat();
        java.lang.Object obj6 = standardPieSectionLabelGenerator4.clone();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Paint paint8 = null;
        try {
            ringPlot0.setLabelLinkPaint(paint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(numberFormat5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        waferMapPlot4.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot4);
        jFreeChart9.setBackgroundImageAlpha(1.0f);
        jFreeChart9.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = jFreeChart9.getPadding();
        boolean boolean15 = jFreeChart9.isNotify();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart9, chartChangeEventType16);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str20 = textTitle19.getURLText();
        jFreeChart9.removeSubtitle((org.jfree.chart.title.Title) textTitle19);
        java.lang.Object obj22 = textTitle19.clone();
        textTitle19.setText("0,0,-2,-2,2,-2,2,-2");
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = categoryPlot0.getDomainAxis();
        categoryPlot0.mapDatasetToDomainAxis(0, (int) '#');
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        categoryPlot0.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint11 = categoryPlot10.getNoDataMessagePaint();
        java.awt.Color color12 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint15 = textTitle14.getPaint();
        java.awt.Color color16 = java.awt.Color.red;
        java.awt.Color color17 = java.awt.Color.red;
        java.awt.Color color18 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { color12, paint15, color16, color17, color18 };
        java.awt.Paint[] paintArray20 = null;
        java.awt.Stroke stroke21 = null;
        java.awt.Stroke[] strokeArray22 = new java.awt.Stroke[] { stroke21 };
        java.awt.Stroke[] strokeArray23 = new java.awt.Stroke[] {};
        java.awt.Shape shape24 = null;
        java.awt.Shape[] shapeArray25 = new java.awt.Shape[] { shape24 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier26 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray19, paintArray20, strokeArray22, strokeArray23, shapeArray25);
        java.awt.Stroke stroke27 = defaultDrawingSupplier26.getNextStroke();
        java.awt.Paint paint28 = defaultDrawingSupplier26.getNextFillPaint();
        java.awt.Paint paint29 = defaultDrawingSupplier26.getNextPaint();
        categoryPlot10.setRangeGridlinePaint(paint29);
        java.util.List list31 = categoryPlot10.getCategories();
        java.awt.Stroke stroke32 = categoryPlot10.getDomainGridlineStroke();
        categoryPlot0.setRangeGridlineStroke(stroke32);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(categoryAxis4);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(strokeArray22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertNotNull(shapeArray25);
        org.junit.Assert.assertNull(stroke27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(list31);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        double double2 = categoryAxis3D1.getCategoryMargin();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getNoDataMessagePaint();
        categoryPlot3.setAnchorValue(0.0d);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getURLText();
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle8.setBackgroundPaint(paint10);
        categoryPlot3.setDomainGridlinePaint(paint10);
        categoryPlot3.setWeight((int) (byte) -1);
        categoryAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        categoryPlot3.clearDomainMarkers();
        categoryPlot3.configureRangeAxes();
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot3.getDomainMarkers((int) (byte) -1, layer19);
        double[] doubleArray26 = new double[] { 0.4d, (-1) };
        double[] doubleArray29 = new double[] { 0.4d, (-1) };
        double[] doubleArray32 = new double[] { 0.4d, (-1) };
        double[] doubleArray35 = new double[] { 0.4d, (-1) };
        double[] doubleArray38 = new double[] { 0.4d, (-1) };
        double[] doubleArray41 = new double[] { 0.4d, (-1) };
        double[][] doubleArray42 = new double[][] { doubleArray26, doubleArray29, doubleArray32, doubleArray35, doubleArray38, doubleArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "{0}", doubleArray42);
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset43);
        org.jfree.data.Range range46 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset43, true);
        categoryPlot3.setDataset((int) (short) 100, categoryDataset43);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(range46);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection4);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot0.getOrientation();
        boolean boolean7 = categoryPlot0.isRangeCrosshairLockedOnData();
        boolean boolean8 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.Object obj1 = ringPlot0.clone();
        double double2 = ringPlot0.getMaximumExplodePercent();
        double double3 = ringPlot0.getInnerSeparatorExtension();
        java.awt.Paint paint4 = ringPlot0.getLabelOutlinePaint();
        java.awt.Paint paint5 = ringPlot0.getSeparatorPaint();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.jfree.data.Range range3 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        org.jfree.data.Range range6 = org.jfree.data.Range.expand(range3, (double) (byte) 100, 4.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType7 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        java.awt.Shape shape12 = dateAxis10.getUpArrow();
        dateAxis10.centerRange((double) (short) 1);
        dateAxis10.setRange(0.0d, (double) '#');
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis10.setStandardTickUnits(tickUnitSource18);
        org.jfree.chart.plot.Plot plot20 = dateAxis10.getPlot();
        double[] doubleArray25 = new double[] { 0.4d, (-1) };
        double[] doubleArray28 = new double[] { 0.4d, (-1) };
        double[] doubleArray31 = new double[] { 0.4d, (-1) };
        double[] doubleArray34 = new double[] { 0.4d, (-1) };
        double[] doubleArray37 = new double[] { 0.4d, (-1) };
        double[] doubleArray40 = new double[] { 0.4d, (-1) };
        double[][] doubleArray41 = new double[][] { doubleArray25, doubleArray28, doubleArray31, doubleArray34, doubleArray37, doubleArray40 };
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "{0}", doubleArray41);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset42);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset42, true);
        dateAxis10.setRange(range45);
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape50 = dateAxis49.getDownArrow();
        java.awt.Shape shape51 = dateAxis49.getUpArrow();
        dateAxis49.centerRange((double) (short) 1);
        dateAxis49.setRange(0.0d, (double) '#');
        org.jfree.data.Range range59 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis49.setRange(range59, false, false);
        org.jfree.data.Range range64 = org.jfree.data.Range.shift(range59, 8.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint65 = new org.jfree.chart.block.RectangleConstraint(10.0d, range64);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint67 = rectangleConstraint65.toFixedWidth(0.12d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType68 = rectangleConstraint67.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint69 = new org.jfree.chart.block.RectangleConstraint((double) (-12566464), range6, lengthConstraintType7, (double) (short) 0, range45, lengthConstraintType68);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(lengthConstraintType7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(range64);
        org.junit.Assert.assertNotNull(rectangleConstraint67);
        org.junit.Assert.assertNotNull(lengthConstraintType68);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainAxes();
        int int2 = xYPlot0.getWeight();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Rotation.CLOCKWISE");
        java.lang.Object obj2 = standardPieSectionLabelGenerator1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setLinkArea(rectangle2D2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        int int3 = xYPlot0.getIndexOf(xYItemRenderer2);
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setRangeCrosshairValue((double) 200, false);
        boolean boolean10 = categoryPlot6.isRangeCrosshairVisible();
        java.awt.Color color12 = java.awt.Color.white;
        java.awt.Color color13 = java.awt.Color.getColor("", color12);
        categoryPlot6.setNoDataMessagePaint((java.awt.Paint) color12);
        valueMarker5.setOutlinePaint((java.awt.Paint) color12);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = valueMarker5.getLabelOffset();
        java.awt.Font font17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        valueMarker5.setLabelFont(font17);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker5);
        xYPlot0.mapDatasetToRangeAxis((-12566464), 500);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setPieHRadius(0.0d);
        double double4 = piePlotState1.getPieCenterY();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        boolean boolean9 = dateAxis1.isNegativeArrowVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = dateAxis1.getStandardTickUnits();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition11 = null;
        try {
            dateAxis1.setTickMarkPosition(dateTickMarkPosition11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(tickUnitSource10);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color2 = java.awt.Color.ORANGE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer7 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6, waferMapRenderer7);
        org.jfree.data.general.WaferMapDataset waferMapDataset9 = null;
        waferMapPlot8.setDataset(waferMapDataset9);
        waferMapPlot8.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot8);
        jFreeChart13.setBackgroundImageAlpha(1.0f);
        jFreeChart13.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = jFreeChart13.getPadding();
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color3, stroke4, rectangleInsets18);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color2, stroke4);
        polarPlot0.setRadiusGridlineStroke(stroke4);
        java.awt.Stroke stroke22 = polarPlot0.getRadiusGridlineStroke();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        polarPlot0.datasetChanged(datasetChangeEvent23);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        java.lang.Object obj3 = null;
        boolean boolean4 = categoryPlot0.equals(obj3);
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomRangeAxes(4.0d, plotRenderingInfo7, point2D8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        categoryPlot0.markerChanged(markerChangeEvent10);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getUpperMargin();
        double double2 = categoryAxis0.getCategoryMargin();
        categoryAxis0.setLowerMargin((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str2 = categoryAxis3D1.getLabelURL();
        java.awt.Paint paint4 = categoryAxis3D1.getTickLabelPaint((java.lang.Comparable) "ThreadContext");
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint6 = ringPlot5.getLabelBackgroundPaint();
        boolean boolean7 = ringPlot5.isCircular();
        java.awt.Stroke stroke8 = ringPlot5.getLabelLinkStroke();
        java.awt.Paint paint9 = ringPlot5.getShadowPaint();
        categoryAxis3D1.setAxisLinePaint(paint9);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        java.awt.Font font2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getNoDataMessagePaint();
        categoryPlot3.setAnchorValue(0.0d);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getURLText();
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle8.setBackgroundPaint(paint10);
        categoryPlot3.setDomainGridlinePaint(paint10);
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint10);
        java.util.List list14 = textBlock13.getLines();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        textBlock13.draw(graphics2D15, 10.0f, (float) (-16711681), textBlockAnchor18);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font22 = textTitle21.getFont();
        boolean boolean23 = textBlock13.equals((java.lang.Object) font22);
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint25 = ringPlot24.getLabelBackgroundPaint();
        boolean boolean26 = ringPlot24.isCircular();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setRangeCrosshairValue((double) 200, false);
        boolean boolean33 = categoryPlot29.isRangeCrosshairVisible();
        java.awt.Color color35 = java.awt.Color.white;
        java.awt.Color color36 = java.awt.Color.getColor("", color35);
        categoryPlot29.setNoDataMessagePaint((java.awt.Paint) color35);
        valueMarker28.setOutlinePaint((java.awt.Paint) color35);
        ringPlot24.setLabelBackgroundPaint((java.awt.Paint) color35);
        org.jfree.chart.text.TextLine textLine40 = new org.jfree.chart.text.TextLine("{0}", font22, (java.awt.Paint) color35);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape4 = dateAxis3.getDownArrow();
        dateAxis1.setUpArrow(shape4);
        java.text.DateFormat dateFormat6 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabel("ClassContext");
        double double9 = dateAxis1.getAutoRangeMinimumSize();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(dateFormat6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = xYPlot0.getAxisOffset();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint6 = textTitle5.getPaint();
        xYPlot0.setDomainGridlinePaint(paint6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getNoDataMessagePaint();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot9.setRangeCrosshairStroke(stroke11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot9.getDomainAxisLocation();
        try {
            xYPlot0.setDomainAxisLocation((-8388480), axisLocation13, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint12 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot11.setRangeZeroBaselinePaint(paint12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray15 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer14 };
        xYPlot11.setRenderers(xYItemRendererArray15);
        xYPlot0.setRenderers(xYItemRendererArray15);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape20 = dateAxis19.getDownArrow();
        java.awt.Shape shape21 = dateAxis19.getUpArrow();
        dateAxis19.centerRange((double) (short) 1);
        dateAxis19.setRange(0.0d, (double) '#');
        dateAxis19.setAutoRange(false);
        dateAxis19.setRangeWithMargins((double) 'a', (double) 100.0f);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = new org.jfree.chart.axis.ValueAxis[] { dateAxis19 };
        xYPlot0.setRangeAxes(valueAxisArray32);
        org.jfree.data.xy.XYDataset xYDataset35 = xYPlot0.getDataset((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace36 = xYPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = xYPlot0.getDomainMarkers(layer37);
        java.awt.Paint paint39 = xYPlot0.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(xYItemRendererArray15);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(valueAxisArray32);
        org.junit.Assert.assertNull(xYDataset35);
        org.junit.Assert.assertNull(axisSpace36);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertNull(paint39);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((double) 2);
        double double3 = blockParams0.getTranslateY();
        blockParams0.setTranslateX((double) 500);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape4 = dateAxis3.getDownArrow();
        dateAxis1.setUpArrow(shape4);
        dateAxis1.setLabelURL("");
        dateAxis1.setLabel("java.awt.Color[r=255,g=200,b=0]");
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        java.awt.Color color0 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint3 = textTitle2.getPaint();
        java.awt.Color color4 = java.awt.Color.red;
        java.awt.Color color5 = java.awt.Color.red;
        java.awt.Color color6 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color0, paint3, color4, color5, color6 };
        java.awt.Paint[] paintArray8 = null;
        java.awt.Stroke stroke9 = null;
        java.awt.Stroke[] strokeArray10 = new java.awt.Stroke[] { stroke9 };
        java.awt.Stroke[] strokeArray11 = new java.awt.Stroke[] {};
        java.awt.Shape shape12 = null;
        java.awt.Shape[] shapeArray13 = new java.awt.Shape[] { shape12 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray8, strokeArray10, strokeArray11, shapeArray13);
        java.awt.Paint paint15 = defaultDrawingSupplier14.getNextPaint();
        java.awt.Paint paint16 = defaultDrawingSupplier14.getNextPaint();
        java.lang.Object obj17 = defaultDrawingSupplier14.clone();
        java.awt.Stroke stroke18 = defaultDrawingSupplier14.getNextStroke();
        try {
            java.awt.Paint paint19 = defaultDrawingSupplier14.getNextOutlinePaint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(strokeArray11);
        org.junit.Assert.assertNotNull(shapeArray13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNull(stroke18);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        java.lang.Object obj7 = xYPlot0.clone();
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = xYPlot0.getRangeMarkers(layer8);
        java.awt.Stroke stroke10 = xYPlot0.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isAngleGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        polarPlot0.setDataset(xYDataset2);
        java.awt.Font font4 = polarPlot0.getAngleLabelFont();
        java.awt.Font font5 = polarPlot0.getAngleLabelFont();
        java.lang.Object obj6 = polarPlot0.clone();
        java.awt.Paint paint7 = polarPlot0.getAngleGridlinePaint();
        try {
            double double8 = polarPlot0.getMaxRadius();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        categoryPlot0.setAnchorValue(0.0d);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers((int) (byte) 10, layer5);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(collection6);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape4 = dateAxis3.getDownArrow();
        dateAxis1.setUpArrow(shape4);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape9, "{0}", "hi!");
        chartEntity6.setArea(shape9);
        java.lang.Object obj14 = chartEntity6.clone();
        java.lang.String str15 = chartEntity6.getShapeType();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "poly" + "'", str15.equals("poly"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str2 = categoryAxis3D1.getLabelURL();
        double double3 = categoryAxis3D1.getCategoryMargin();
        categoryAxis3D1.setLabelURL("RectangleEdge.TOP");
        categoryAxis3D1.setLabelToolTip("hi!");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setInfo("hi!");
        projectInfo0.setInfo("");
        org.jfree.chart.ui.ProjectInfo projectInfo5 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str6 = projectInfo5.getLicenceText();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo5);
        projectInfo0.setCopyright("Category Plot");
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = textTitle15.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = textTitle15.getPosition();
        jFreeChart8.setTitle(textTitle15);
        jFreeChart8.setAntiAlias(false);
        jFreeChart8.clearSubtitles();
        jFreeChart8.setTitle("hi!");
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxisForDataset((-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getAxisOffset();
        boolean boolean7 = categoryPlot0.isDomainZoomable();
        categoryPlot0.setRangeCrosshairVisible(false);
        java.lang.String str10 = categoryPlot0.getPlotType();
        java.awt.Color color11 = java.awt.Color.green;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color11);
        boolean boolean13 = categoryPlot0.isDomainZoomable();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font3 = textTitle2.getFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setRangeCrosshairValue((double) 200, false);
        boolean boolean8 = categoryPlot4.isRangeCrosshairVisible();
        java.awt.Color color10 = java.awt.Color.white;
        java.awt.Color color11 = java.awt.Color.getColor("", color10);
        categoryPlot4.setNoDataMessagePaint((java.awt.Paint) color10);
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("Pie Plot", font3, (java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock13);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        strokeMap0.clear();
        java.lang.Object obj2 = strokeMap0.clone();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean5 = polarPlot4.isAngleGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        polarPlot4.setDataset(xYDataset6);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = polarPlot4.getRenderer();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        boolean boolean10 = polarPlot4.equals((java.lang.Object) textBlockAnchor9);
        java.awt.Stroke stroke11 = polarPlot4.getAngleGridlineStroke();
        java.awt.Stroke stroke12 = polarPlot4.getAngleGridlineStroke();
        strokeMap0.put((java.lang.Comparable) ' ', stroke12);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(polarItemRenderer8);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
    }
}

