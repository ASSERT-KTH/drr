import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        boolean boolean3 = xYPlot0.isRangeCrosshairVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        xYPlot0.datasetChanged(datasetChangeEvent4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace6);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        float float7 = waferMapPlot4.getBackgroundImageAlpha();
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot4);
        java.awt.Paint paint9 = valueMarker1.getPaint();
        java.awt.Paint paint10 = valueMarker1.getLabelPaint();
        org.jfree.chart.text.TextAnchor textAnchor11 = null;
        try {
            valueMarker1.setLabelTextAnchor(textAnchor11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.HALF_ASCENT_CENTER");
        numberAxis1.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit4, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        java.lang.String str2 = numberAxis0.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = numberAxis0.getMarkerBand();
        double double4 = numberAxis0.getFixedDimension();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = numberAxis0.getStandardTickUnits();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot9.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot9.zoomDomainAxes(8.0d, plotRenderingInfo13, point2D14);
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot9);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = legendTitle16.getLegendItemGraphicEdge();
        try {
            java.util.List list18 = numberAxis0.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(markerAxisBand3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("TextAnchor.HALF_ASCENT_CENTER", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.block.Arrangement arrangement2 = blockContainer1.getArrangement();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(1.0d, 90.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = rectangleConstraint5.getWidthConstraintType();
        org.jfree.chart.util.UnitType unitType7 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean8 = lengthConstraintType6.equals((java.lang.Object) unitType7);
        java.lang.String str9 = lengthConstraintType6.toString();
        boolean boolean10 = blockContainer1.equals((java.lang.Object) lengthConstraintType6);
        java.lang.Object obj11 = blockContainer1.clone();
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((double) (byte) 0, (double) (short) 100, (double) (-1.0f), 100.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = blockBorder16.getInsets();
        boolean boolean18 = blockContainer1.equals((java.lang.Object) blockBorder16);
        org.junit.Assert.assertNotNull(arrangement2);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
        org.junit.Assert.assertNotNull(unitType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "LengthConstraintType.FIXED" + "'", str9.equals("LengthConstraintType.FIXED"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0, (double) 100.0f);
        double double3 = size2D2.width;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D2, (double) (byte) -1, (-9.0d), rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D7);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = textTitle15.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = textTitle15.getPosition();
        jFreeChart8.setTitle(textTitle15);
        java.awt.Color color19 = java.awt.Color.gray;
        jFreeChart8.setBackgroundPaint((java.awt.Paint) color19);
        jFreeChart8.fireChartChanged();
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxisForDataset((-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getAxisOffset();
        boolean boolean7 = categoryPlot0.isDomainZoomable();
        categoryPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint12 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot11.setRangeZeroBaselinePaint(paint12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray15 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer14 };
        xYPlot11.setRenderers(xYItemRendererArray15);
        xYPlot0.setRenderers(xYItemRendererArray15);
        org.jfree.chart.plot.Plot plot18 = xYPlot0.getParent();
        java.awt.Stroke stroke19 = xYPlot0.getRangeGridlineStroke();
        boolean boolean20 = xYPlot0.isDomainGridlinesVisible();
        xYPlot0.clearDomainMarkers();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(xYItemRendererArray15);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.Object obj1 = ringPlot0.clone();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint5 = ringPlot4.getLabelBackgroundPaint();
        ringPlot4.setShadowXOffset((double) (-1.0f));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.PiePlotState piePlotState10 = ringPlot0.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.PiePlot) ringPlot4, (java.lang.Integer) 200, plotRenderingInfo9);
        boolean boolean11 = ringPlot0.getIgnoreZeroValues();
        ringPlot0.setSimpleLabels(false);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(piePlotState10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = textTitle1.getPosition();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle7.getPadding();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = textTitle7.getTextAlignment();
        textTitle5.setHorizontalAlignment(horizontalAlignment9);
        textTitle1.setHorizontalAlignment(horizontalAlignment9);
        java.lang.String str12 = textTitle1.getText();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getNoDataMessagePaint();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot3.setRangeCrosshairStroke(stroke5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot3.getDomainAxisLocation();
        xYPlot0.setRangeAxisLocation(axisLocation7, false);
        xYPlot0.setOutlineVisible(false);
        boolean boolean12 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        int int14 = xYPlot0.indexOf(xYDataset13);
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeZeroBaselineStroke(stroke15);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setInfo("hi!");
        projectInfo0.setInfo("");
        projectInfo0.setInfo("");
        java.util.List list7 = projectInfo0.getContributors();
        org.junit.Assert.assertNull(list7);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.awt.Image image2 = null;
        waferMapPlot1.setBackgroundImage(image2);
        java.awt.Paint paint4 = waferMapPlot1.getNoDataMessagePaint();
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = waferMapPlot1.getDataset();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(waferMapDataset5);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        java.awt.Shape shape7 = dateAxis5.getUpArrow();
        dateAxis5.centerRange((double) (short) 1);
        dateAxis5.setRange(0.0d, (double) '#');
        dateAxis5.setAutoRange(false);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.lang.String str16 = categoryPlot0.getPlotType();
        categoryPlot0.configureDomainAxes();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setRangeCrosshairValue((double) 200, false);
        boolean boolean5 = categoryPlot1.isRangeCrosshairVisible();
        java.awt.Color color7 = java.awt.Color.white;
        java.awt.Color color8 = java.awt.Color.getColor("", color7);
        categoryPlot1.setNoDataMessagePaint((java.awt.Paint) color7);
        piePlot3D0.setLabelLinkPaint((java.awt.Paint) color7);
        double double11 = piePlot3D0.getDepthFactor();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date15 = dateAxis13.calculateHighestVisibleTickValue(dateTickUnit14);
        java.awt.Paint paint16 = piePlot3D0.getSectionPaint((java.lang.Comparable) date15);
        boolean boolean17 = piePlot3D0.isSubplot();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.12d + "'", double11 == 0.12d);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.Color color5 = java.awt.Color.getColor("", color4);
        int int6 = color4.getRGB();
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        java.awt.Stroke stroke8 = xYPlot0.getDomainCrosshairStroke();
        boolean boolean9 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer14 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot15 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset13, waferMapRenderer14);
        org.jfree.data.general.WaferMapDataset waferMapDataset16 = null;
        waferMapPlot15.setDataset(waferMapDataset16);
        float float18 = waferMapPlot15.getBackgroundImageAlpha();
        valueMarker12.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot15);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker12.setLabelAnchor(rectangleAnchor20);
        org.jfree.chart.util.Layer layer22 = null;
        try {
            boolean boolean23 = xYPlot0.removeDomainMarker((int) (short) 0, (org.jfree.chart.plot.Marker) valueMarker12, layer22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.5f + "'", float18 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.UnitType unitType1 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(unitType1, (double) '4', (double) 200, (double) 1, (double) 10.0f);
        boolean boolean7 = horizontalAlignment0.equals((java.lang.Object) unitType1);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot8.setRangeZeroBaselinePaint(paint9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray12 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer11 };
        xYPlot8.setRenderers(xYItemRendererArray12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        xYPlot8.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo16, point2D17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        xYPlot8.setFixedRangeAxisSpace(axisSpace19);
        xYPlot8.zoom((double) (short) -1);
        java.awt.Paint paint23 = xYPlot8.getDomainZeroBaselinePaint();
        boolean boolean24 = horizontalAlignment0.equals((java.lang.Object) paint23);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(xYItemRendererArray12);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.Color color3 = java.awt.Color.getColor("", color2);
        ringPlot0.setLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = ringPlot0.getLabelLinksVisible();
        int int6 = ringPlot0.getPieIndex();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint16 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot15.setRangeZeroBaselinePaint(paint16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray19 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer18 };
        xYPlot15.setRenderers(xYItemRendererArray19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot15.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo23, point2D24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        xYPlot15.setFixedRangeAxisSpace(axisSpace26);
        java.awt.Stroke stroke28 = xYPlot15.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D29 = xYPlot15.getQuadrantOrigin();
        xYPlot0.zoomDomainAxes((double) 10.0f, (double) 2.0f, plotRenderingInfo14, point2D29);
        boolean boolean31 = xYPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(xYItemRendererArray19);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getPadding();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle1.getTextAlignment();
        textTitle1.setExpandToFitSpace(true);
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer7 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6, waferMapRenderer7);
        org.jfree.data.general.WaferMapDataset waferMapDataset9 = null;
        waferMapPlot8.setDataset(waferMapDataset9);
        float float11 = waferMapPlot8.getBackgroundImageAlpha();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        waferMapPlot8.datasetChanged(datasetChangeEvent12);
        java.awt.Color color15 = java.awt.Color.white;
        java.awt.Color color16 = java.awt.Color.getColor("", color15);
        int int17 = color15.getRGB();
        waferMapPlot8.setOutlinePaint((java.awt.Paint) color15);
        textTitle1.setBackgroundPaint((java.awt.Paint) color15);
        java.awt.color.ColorSpace colorSpace20 = color15.getColorSpace();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(colorSpace20);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        ringPlot0.setShadowXOffset((double) (-1.0f));
        org.jfree.chart.util.Rotation rotation4 = ringPlot0.getDirection();
        org.jfree.data.general.WaferMapDataset waferMapDataset7 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer8 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset7, waferMapRenderer8);
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        waferMapPlot9.setDataset(waferMapDataset10);
        waferMapPlot9.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot9);
        jFreeChart14.setBackgroundImageAlpha(1.0f);
        jFreeChart14.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = jFreeChart14.getPadding();
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = textTitle21.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = textTitle21.getPosition();
        jFreeChart14.setTitle(textTitle21);
        java.awt.Color color25 = java.awt.Color.gray;
        jFreeChart14.setBackgroundPaint((java.awt.Paint) color25);
        java.awt.Stroke stroke27 = jFreeChart14.getBorderStroke();
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) 0, stroke27);
        java.awt.Paint paint29 = ringPlot0.getLabelPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        boolean boolean9 = dateAxis1.isNegativeArrowVisible();
        java.awt.Paint paint10 = dateAxis1.getTickMarkPaint();
        dateAxis1.setLowerBound((double) 2.0f);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = textTitle3.getPadding();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle3.getTextAlignment();
        textTitle1.setHorizontalAlignment(horizontalAlignment5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) (short) 0, (double) 100.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        org.jfree.data.Range range12 = rectangleConstraint10.getHeightRange();
        try {
            org.jfree.chart.util.Size2D size2D13 = textTitle1.arrange(graphics2D7, rectangleConstraint10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getMaximumLabelWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean3 = piePlot3D0.equals((java.lang.Object) rectangleAnchor2);
        java.awt.Stroke stroke4 = piePlot3D0.getBaseSectionOutlineStroke();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.14d + "'", double1 == 0.14d);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getUpperMargin();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean4 = polarPlot3.isRadiusGridlinesVisible();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint7 = categoryPlot6.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace13 = categoryAxis0.reserveSpace(graphics2D2, (org.jfree.chart.plot.Plot) polarPlot3, rectangle2D5, rectangleEdge11, axisSpace12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        waferMapPlot2.setOutlineStroke(stroke3);
        waferMapPlot2.setBackgroundImageAlignment(0);
        org.jfree.data.general.WaferMapDataset waferMapDataset7 = null;
        waferMapPlot2.setDataset(waferMapDataset7);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        java.lang.Object obj3 = null;
        boolean boolean4 = categoryPlot0.equals(obj3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getNoDataMessagePaint();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot5.setRangeCrosshairStroke(stroke7);
        categoryPlot0.setRangeCrosshairStroke(stroke7);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        categoryPlot0.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint13 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot12.setRangeZeroBaselinePaint(paint13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray16 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer15 };
        xYPlot12.setRenderers(xYItemRendererArray16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot12.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo20, point2D21);
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        xYPlot12.setFixedRangeAxisSpace(axisSpace23);
        java.awt.Stroke stroke25 = xYPlot12.getDomainCrosshairStroke();
        java.awt.Stroke stroke26 = xYPlot12.getDomainCrosshairStroke();
        categoryPlot0.setDomainGridlineStroke(stroke26);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(xYItemRendererArray16);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.awt.Color color2 = java.awt.Color.getColor("hi!", (int) 'a');
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        boolean boolean2 = ringPlot0.isCircular();
        java.awt.Stroke stroke3 = ringPlot0.getLabelLinkStroke();
        java.awt.Paint paint4 = ringPlot0.getShadowPaint();
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean6 = polarPlot5.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint10 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot9.setRangeZeroBaselinePaint(paint10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray13 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer12 };
        xYPlot9.setRenderers(xYItemRendererArray13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        xYPlot9.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo17, point2D18);
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        xYPlot9.setFixedRangeAxisSpace(axisSpace20);
        java.awt.Stroke stroke22 = xYPlot9.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D23 = xYPlot9.getQuadrantOrigin();
        polarPlot5.zoomDomainAxes(1.0E-8d, plotRenderingInfo8, point2D23);
        ringPlot0.setParent((org.jfree.chart.plot.Plot) polarPlot5);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = polarPlot5.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color31 = java.awt.Color.ORANGE;
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset35 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer36 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot37 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset35, waferMapRenderer36);
        org.jfree.data.general.WaferMapDataset waferMapDataset38 = null;
        waferMapPlot37.setDataset(waferMapDataset38);
        waferMapPlot37.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart42 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot37);
        jFreeChart42.setBackgroundImageAlpha(1.0f);
        jFreeChart42.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = jFreeChart42.getPadding();
        org.jfree.chart.block.LineBorder lineBorder48 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color32, stroke33, rectangleInsets47);
        org.jfree.chart.plot.ValueMarker valueMarker49 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color31, stroke33);
        polarPlot29.setRadiusGridlineStroke(stroke33);
        java.awt.Stroke stroke51 = polarPlot29.getRadiusGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint56 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot55.setRangeZeroBaselinePaint(paint56);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer58 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray59 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer58 };
        xYPlot55.setRenderers(xYItemRendererArray59);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = null;
        java.awt.geom.Point2D point2D64 = null;
        xYPlot55.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo63, point2D64);
        org.jfree.chart.axis.AxisSpace axisSpace66 = null;
        xYPlot55.setFixedRangeAxisSpace(axisSpace66);
        java.awt.Stroke stroke68 = xYPlot55.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D69 = xYPlot55.getQuadrantOrigin();
        polarPlot29.zoomDomainAxes(0.05d, 0.05d, plotRenderingInfo54, point2D69);
        try {
            polarPlot5.zoomRangeAxes(0.0d, plotRenderingInfo28, point2D69, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(xYItemRendererArray13);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(point2D23);
        org.junit.Assert.assertNull(polarItemRenderer26);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(xYItemRendererArray59);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(point2D69);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = piePlotState1.getLinkArea();
        double double3 = piePlotState1.getTotal();
        java.awt.geom.Rectangle2D rectangle2D4 = piePlotState1.getExplodedPieArea();
        java.awt.geom.Rectangle2D rectangle2D5 = piePlotState1.getPieArea();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        piePlotState1.setPieArea(rectangle2D6);
        org.junit.Assert.assertNull(rectangle2D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertNull(rectangle2D5);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setRangeCrosshairValue((double) 200, false);
        boolean boolean5 = categoryPlot1.isRangeCrosshairVisible();
        java.awt.Color color7 = java.awt.Color.white;
        java.awt.Color color8 = java.awt.Color.getColor("", color7);
        categoryPlot1.setNoDataMessagePaint((java.awt.Paint) color7);
        piePlot3D0.setLabelLinkPaint((java.awt.Paint) color7);
        double double11 = piePlot3D0.getDepthFactor();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date15 = dateAxis13.calculateHighestVisibleTickValue(dateTickUnit14);
        java.awt.Paint paint16 = piePlot3D0.getSectionPaint((java.lang.Comparable) date15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot19.setRangeCrosshairValue((double) 200, false);
        boolean boolean23 = categoryPlot19.isRangeCrosshairVisible();
        java.awt.Color color25 = java.awt.Color.white;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        categoryPlot19.setNoDataMessagePaint((java.awt.Paint) color25);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot19.getAxisOffset();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent29 = null;
        categoryPlot19.rendererChanged(rendererChangeEvent29);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D32 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str33 = categoryAxis3D32.getLabelURL();
        double double34 = categoryAxis3D32.getCategoryMargin();
        categoryAxis3D32.setLabelURL("RectangleEdge.TOP");
        float float37 = categoryAxis3D32.getMaximumCategoryLabelWidthRatio();
        categoryPlot19.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        org.jfree.chart.plot.PolarPlot polarPlot42 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean43 = polarPlot42.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint47 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot46.setRangeZeroBaselinePaint(paint47);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray50 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer49 };
        xYPlot46.setRenderers(xYItemRendererArray50);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        java.awt.geom.Point2D point2D55 = null;
        xYPlot46.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo54, point2D55);
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        xYPlot46.setFixedRangeAxisSpace(axisSpace57);
        java.awt.Stroke stroke59 = xYPlot46.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D60 = xYPlot46.getQuadrantOrigin();
        polarPlot42.zoomDomainAxes(1.0E-8d, plotRenderingInfo45, point2D60);
        categoryPlot19.zoomRangeAxes((-7.0d), (double) 10L, plotRenderingInfo41, point2D60);
        org.jfree.chart.plot.PlotState plotState63 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        try {
            piePlot3D0.draw(graphics2D17, rectangle2D18, point2D60, plotState63, plotRenderingInfo64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.12d + "'", double11 == 0.12d);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.2d + "'", double34 == 0.2d);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 0.0f + "'", float37 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(xYItemRendererArray50);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(point2D60);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        boolean boolean6 = dateAxis1.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis1.getTickLabelInsets();
        org.jfree.chart.plot.Plot plot8 = null;
        dateAxis1.setPlot(plot8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        java.awt.Shape shape13 = dateAxis11.getUpArrow();
        dateAxis11.centerRange((double) (short) 1);
        dateAxis11.setRange(0.0d, (double) '#');
        org.jfree.data.Range range21 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis11.setRange(range21, false, false);
        org.jfree.data.Range range27 = org.jfree.data.Range.shift(range21, (double) 255, false);
        dateAxis1.setRange(range21, true, false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(range27);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(1.0d, 90.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint2.getWidthConstraintType();
        java.lang.String str5 = lengthConstraintType4.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "LengthConstraintType.FIXED" + "'", str5.equals("LengthConstraintType.FIXED"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.Color color5 = java.awt.Color.getColor("", color4);
        int int6 = color4.getRGB();
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace8);
        xYPlot0.setDomainZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double[] doubleArray4 = new double[] { 0.4d, (-1) };
        double[] doubleArray7 = new double[] { 0.4d, (-1) };
        double[] doubleArray10 = new double[] { 0.4d, (-1) };
        double[] doubleArray13 = new double[] { 0.4d, (-1) };
        double[] doubleArray16 = new double[] { 0.4d, (-1) };
        double[] doubleArray19 = new double[] { 0.4d, (-1) };
        double[][] doubleArray20 = new double[][] { doubleArray4, doubleArray7, doubleArray10, doubleArray13, doubleArray16, doubleArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "{0}", doubleArray20);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset21);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset21, false);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range24);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        boolean boolean6 = dateAxis1.isPositiveArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        java.awt.Shape shape10 = dateAxis8.getUpArrow();
        dateAxis8.centerRange((double) (short) 1);
        dateAxis8.setRange(0.0d, (double) '#');
        dateAxis8.setAutoRange(false);
        dateAxis8.setRangeWithMargins((double) 'a', (double) 100.0f);
        java.awt.Font font21 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        dateAxis8.setTickLabelFont(font21);
        dateAxis1.setLabelFont(font21);
        double double24 = dateAxis1.getLabelAngle();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D2.setTickLabelFont((java.lang.Comparable) (short) 10, font4);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("", font4);
        textTitle6.setNotify(true);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) (-16711681), (float) (byte) -1, (double) 2.0f, 10.0f, 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((double) 2);
        boolean boolean3 = blockParams0.getGenerateEntities();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(1.0d, 90.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        java.lang.String str4 = rectangleConstraint2.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toUnconstrainedWidth();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=90.0]" + "'", str4.equals("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=90.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint5);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean2 = numberAxis0.isAutoRange();
        numberAxis0.setLabelAngle((double) '4');
        numberAxis0.setAutoRangeStickyZero(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot0.getRenderer(0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation13 = null;
        try {
            boolean boolean14 = xYPlot0.removeAnnotation(xYAnnotation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(xYItemRenderer12);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean2 = numberAxis0.isAutoRange();
        numberAxis0.setLabelAngle((double) '4');
        numberAxis0.setLowerBound(17.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("LengthConstraintType.FIXED");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textLine1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource9);
        java.lang.Object obj11 = dateAxis1.clone();
        dateAxis1.setRangeAboutValue((double) (byte) 1, 8.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.Object obj1 = ringPlot0.clone();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint5 = ringPlot4.getLabelBackgroundPaint();
        ringPlot4.setShadowXOffset((double) (-1.0f));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.PiePlotState piePlotState10 = ringPlot0.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.PiePlot) ringPlot4, (java.lang.Integer) 200, plotRenderingInfo9);
        double double11 = ringPlot0.getInnerSeparatorExtension();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = ringPlot0.getLabelPadding();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor14 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 10);
        pieLabelDistributor14.sort();
        ringPlot0.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor14);
        java.awt.Paint paint17 = ringPlot0.getLabelPaint();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(piePlotState10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        boolean boolean9 = dateAxis1.isNegativeArrowVisible();
        double double10 = dateAxis1.getFixedDimension();
        java.text.DateFormat dateFormat11 = null;
        dateAxis1.setDateFormatOverride(dateFormat11);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date16 = dateAxis14.calculateHighestVisibleTickValue(dateTickUnit15);
        dateAxis1.setMaximumDate(date16);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getPadding();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle1.getTextAlignment();
        textTitle1.setExpandToFitSpace(true);
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = textTitle1.getVerticalAlignment();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(verticalAlignment6);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        java.awt.Stroke stroke5 = xYPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getURLText();
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle1.setBackgroundPaint(paint3);
        textTitle1.setHeight((double) ' ');
        org.jfree.chart.util.Size2D size2D7 = new org.jfree.chart.util.Size2D();
        boolean boolean8 = textTitle1.equals((java.lang.Object) size2D7);
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer11 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset10, waferMapRenderer11);
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        waferMapPlot12.setDataset(waferMapDataset13);
        waferMapPlot12.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot12);
        java.awt.Stroke stroke18 = jFreeChart17.getBorderStroke();
        boolean boolean19 = jFreeChart17.isBorderVisible();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.data.general.WaferMapDataset waferMapDataset21 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer22 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot23 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset21, waferMapRenderer22);
        org.jfree.data.general.WaferMapDataset waferMapDataset24 = null;
        waferMapPlot23.setDataset(waferMapDataset24);
        boolean boolean26 = chartChangeEventType20.equals((java.lang.Object) waferMapPlot23);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textTitle1, jFreeChart17, chartChangeEventType20);
        org.jfree.chart.title.TextTitle textTitle28 = jFreeChart17.getTitle();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(textTitle28);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer6 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset5, waferMapRenderer6);
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        waferMapPlot7.setDataset(waferMapDataset8);
        waferMapPlot7.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot7);
        jFreeChart12.setBackgroundImageAlpha(1.0f);
        jFreeChart12.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = jFreeChart12.getPadding();
        org.jfree.chart.block.LineBorder lineBorder18 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color2, stroke3, rectangleInsets17);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color1, stroke3);
        java.lang.String str20 = color1.toString();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=200,b=0]" + "'", str20.equals("java.awt.Color[r=255,g=200,b=0]"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        org.jfree.data.general.WaferMapDataset waferMapDataset7 = null;
        waferMapPlot6.setDataset(waferMapDataset7);
        float float9 = waferMapPlot6.getBackgroundImageAlpha();
        valueMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot6);
        java.awt.Font font11 = valueMarker3.getLabelFont();
        dateAxis1.setTickLabelFont(font11);
        dateAxis1.zoomRange((double) (-1L), 10.0d);
        double[] doubleArray20 = new double[] { 0.4d, (-1) };
        double[] doubleArray23 = new double[] { 0.4d, (-1) };
        double[] doubleArray26 = new double[] { 0.4d, (-1) };
        double[] doubleArray29 = new double[] { 0.4d, (-1) };
        double[] doubleArray32 = new double[] { 0.4d, (-1) };
        double[] doubleArray35 = new double[] { 0.4d, (-1) };
        double[][] doubleArray36 = new double[][] { doubleArray20, doubleArray23, doubleArray26, doubleArray29, doubleArray32, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "{0}", doubleArray36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset37);
        dateAxis1.setRangeWithMargins(range38);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5f + "'", float9 == 0.5f);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(range38);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        xYPlot0.zoom((double) (short) -1);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = xYPlot0.getDomainMarkers(layer15);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = xYPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset((double) 10.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double[] doubleArray6 = new double[] { 0.4d, (-1) };
        double[] doubleArray9 = new double[] { 0.4d, (-1) };
        double[] doubleArray12 = new double[] { 0.4d, (-1) };
        double[] doubleArray15 = new double[] { 0.4d, (-1) };
        double[] doubleArray18 = new double[] { 0.4d, (-1) };
        double[] doubleArray21 = new double[] { 0.4d, (-1) };
        double[][] doubleArray22 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15, doubleArray18, doubleArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "{0}", doubleArray22);
        org.jfree.data.category.CategoryDataset categoryDataset24 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "ClassContext", doubleArray22);
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset24);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 2.4d + "'", number25.equals(2.4d));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ThreadContext");
        java.text.AttributedString attributedString3 = standardPieSectionLabelGenerator1.getAttributedLabel((int) (byte) -1);
        java.text.AttributedString attributedString5 = standardPieSectionLabelGenerator1.getAttributedLabel((int) (byte) -1);
        org.junit.Assert.assertNull(attributedString3);
        org.junit.Assert.assertNull(attributedString5);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setInfo("hi!");
        projectInfo0.setInfo("");
        java.lang.String str5 = projectInfo0.getCopyright();
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) "Category Plot", keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        java.lang.String str2 = numberAxis0.getLabelURL();
        numberAxis0.setUpperMargin(0.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) (-1), 1.0f, (double) 255, (float) (-1L), (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(8.0d, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot0.getDomainMarkers(layer7);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection8);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreZeroValues(true);
        ringPlot0.setLabelGap(90.0d);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        ringPlot0.setDataset(pieDataset5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.lang.Class class1 = null;
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer4 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset3, waferMapRenderer4);
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        waferMapPlot5.setDataset(waferMapDataset6);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) waferMapPlot5);
        org.jfree.chart.plot.Plot plot9 = plotChangeEvent8.getPlot();
        java.lang.Class<?> wildcardClass10 = plot9.getClass();
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ChartChangeEventType.DATASET_UPDATED", (java.lang.Class) wildcardClass10);
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Range[100.0,100.0]", class1, (java.lang.Class) wildcardClass10);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(uRL11);
        org.junit.Assert.assertNull(obj12);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        double double2 = categoryAxis3D1.getCategoryMargin();
        java.awt.Font font3 = categoryAxis3D1.getLabelFont();
        java.lang.Comparable comparable4 = null;
        try {
            java.awt.Font font5 = categoryAxis3D1.getTickLabelFont(comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        ringPlot0.setShadowXOffset((double) (-1.0f));
        org.jfree.chart.util.Rotation rotation4 = ringPlot0.getDirection();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        ringPlot0.setDataset(pieDataset5);
        ringPlot0.setCircular(false, true);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str12 = textTitle11.getURLText();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle11.setBackgroundPaint(paint13);
        ringPlot0.setShadowPaint(paint13);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = textTitle1.getPosition();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle7.getPadding();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = textTitle7.getTextAlignment();
        textTitle5.setHorizontalAlignment(horizontalAlignment9);
        textTitle1.setHorizontalAlignment(horizontalAlignment9);
        textTitle1.setURLText("Rotation.CLOCKWISE");
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        boolean boolean2 = ringPlot0.isCircular();
        java.awt.Paint paint3 = ringPlot0.getSeparatorPaint();
        boolean boolean4 = ringPlot0.getSectionOutlinesVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getInteriorGap();
        boolean boolean2 = piePlot3D0.getDarkerSides();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        piePlot3D0.markerChanged(markerChangeEvent3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08d + "'", double1 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        java.awt.Stroke stroke9 = jFreeChart8.getBorderStroke();
        boolean boolean10 = jFreeChart8.isBorderVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = jFreeChart8.getPadding();
        jFreeChart8.setAntiAlias(false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        java.awt.Color color2 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint5 = textTitle4.getPaint();
        java.awt.Color color6 = java.awt.Color.red;
        java.awt.Color color7 = java.awt.Color.red;
        java.awt.Color color8 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color2, paint5, color6, color7, color8 };
        java.awt.Paint[] paintArray10 = null;
        java.awt.Stroke stroke11 = null;
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] { stroke11 };
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] {};
        java.awt.Shape shape14 = null;
        java.awt.Shape[] shapeArray15 = new java.awt.Shape[] { shape14 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray10, strokeArray12, strokeArray13, shapeArray15);
        java.awt.Stroke stroke17 = defaultDrawingSupplier16.getNextStroke();
        java.awt.Paint paint18 = defaultDrawingSupplier16.getNextFillPaint();
        java.awt.Paint paint19 = defaultDrawingSupplier16.getNextPaint();
        categoryPlot0.setRangeGridlinePaint(paint19);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset25 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer26 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot27 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset25, waferMapRenderer26);
        org.jfree.data.general.WaferMapDataset waferMapDataset28 = null;
        waferMapPlot27.setDataset(waferMapDataset28);
        float float30 = waferMapPlot27.getBackgroundImageAlpha();
        valueMarker24.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot27);
        java.awt.Font font32 = valueMarker24.getLabelFont();
        dateAxis22.setTickLabelFont(font32);
        org.jfree.data.Range range34 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis22);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = categoryPlot0.getRangeMarkers(layer37);
        boolean boolean39 = categoryPlot0.isRangeZoomable();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.5f + "'", float30 == 0.5f);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        java.awt.Stroke stroke13 = xYPlot0.getDomainCrosshairStroke();
        java.awt.Stroke stroke14 = xYPlot0.getDomainCrosshairStroke();
        int int15 = xYPlot0.getDatasetCount();
        java.awt.Paint paint16 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot19.setRangeCrosshairValue((double) 200, false);
        boolean boolean23 = categoryPlot19.isRangeCrosshairVisible();
        java.awt.Color color25 = java.awt.Color.white;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        categoryPlot19.setNoDataMessagePaint((java.awt.Paint) color25);
        valueMarker18.setOutlinePaint((java.awt.Paint) color25);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = valueMarker18.getLabelOffset();
        valueMarker18.setAlpha(0.5f);
        org.jfree.chart.text.TextAnchor textAnchor32 = valueMarker18.getLabelTextAnchor();
        try {
            boolean boolean33 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(textAnchor32);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str2 = categoryAxis3D1.getLabelURL();
        float float3 = categoryAxis3D1.getTickMarkOutsideLength();
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio((float) 1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(8.0d, plotRenderingInfo4, point2D5);
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle7.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle7.getItemLabelPadding();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceText();
        java.lang.String str2 = projectInfo0.getName();
        java.lang.String str3 = projectInfo0.getLicenceText();
        java.lang.String str4 = projectInfo0.getLicenceText();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (short) 10, (double) (-1.0f), (double) (short) 1, (double) ' ');
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            blockBorder4.draw(graphics2D5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Point2D point2D4 = null;
        org.jfree.chart.plot.PlotState plotState5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            piePlot3D1.draw(graphics2D2, rectangle2D3, point2D4, plotState5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreZeroValues(true);
        int int3 = ringPlot0.getBackgroundImageAlignment();
        ringPlot0.setPieIndex(500);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getNoDataMessagePaint();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot3.setRangeCrosshairStroke(stroke5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot3.getDomainAxisLocation();
        xYPlot0.setRangeAxisLocation(axisLocation7, false);
        xYPlot0.setOutlineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace13);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isAngleGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        polarPlot0.setDataset(xYDataset2);
        java.awt.Paint paint4 = polarPlot0.getRadiusGridlinePaint();
        boolean boolean5 = polarPlot0.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot0.getFixedDomainAxisSpace();
        java.lang.Object obj4 = categoryPlot0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        ringPlot0.setShadowXOffset((double) (-1.0f));
        org.jfree.chart.util.Rotation rotation4 = ringPlot0.getDirection();
        org.jfree.data.general.WaferMapDataset waferMapDataset7 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer8 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset7, waferMapRenderer8);
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        waferMapPlot9.setDataset(waferMapDataset10);
        waferMapPlot9.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot9);
        jFreeChart14.setBackgroundImageAlpha(1.0f);
        jFreeChart14.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = jFreeChart14.getPadding();
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = textTitle21.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = textTitle21.getPosition();
        jFreeChart14.setTitle(textTitle21);
        java.awt.Color color25 = java.awt.Color.gray;
        jFreeChart14.setBackgroundPaint((java.awt.Paint) color25);
        java.awt.Stroke stroke27 = jFreeChart14.getBorderStroke();
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) 0, stroke27);
        boolean boolean29 = ringPlot0.getSimpleLabels();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        boolean boolean3 = xYPlot0.isRangeCrosshairVisible();
        boolean boolean4 = xYPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        boolean boolean2 = ringPlot0.isCircular();
        java.awt.Stroke stroke3 = ringPlot0.getLabelLinkStroke();
        java.awt.Paint paint4 = ringPlot0.getShadowPaint();
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean6 = polarPlot5.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint10 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot9.setRangeZeroBaselinePaint(paint10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray13 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer12 };
        xYPlot9.setRenderers(xYItemRendererArray13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        xYPlot9.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo17, point2D18);
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        xYPlot9.setFixedRangeAxisSpace(axisSpace20);
        java.awt.Stroke stroke22 = xYPlot9.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D23 = xYPlot9.getQuadrantOrigin();
        polarPlot5.zoomDomainAxes(1.0E-8d, plotRenderingInfo8, point2D23);
        ringPlot0.setParent((org.jfree.chart.plot.Plot) polarPlot5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment27 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement30 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment26, verticalAlignment27, (double) 10L, (double) 100.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint32 = categoryPlot31.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation33 = categoryPlot31.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot31.zoomDomainAxes(8.0d, plotRenderingInfo35, point2D36);
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot31);
        java.awt.Font font39 = legendTitle38.getItemFont();
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset43 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer44 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot45 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset43, waferMapRenderer44);
        org.jfree.data.general.WaferMapDataset waferMapDataset46 = null;
        waferMapPlot45.setDataset(waferMapDataset46);
        waferMapPlot45.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot45);
        jFreeChart50.setBackgroundImageAlpha(1.0f);
        jFreeChart50.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = jFreeChart50.getPadding();
        org.jfree.chart.block.LineBorder lineBorder56 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color40, stroke41, rectangleInsets55);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = lineBorder56.getInsets();
        columnArrangement30.add((org.jfree.chart.block.Block) legendTitle38, (java.lang.Object) rectangleInsets57);
        columnArrangement30.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement60 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle61 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0, (org.jfree.chart.block.Arrangement) columnArrangement30, (org.jfree.chart.block.Arrangement) flowArrangement60);
        org.jfree.chart.block.BlockContainer blockContainer62 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement30);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(xYItemRendererArray13);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(point2D23);
        org.junit.Assert.assertNotNull(verticalAlignment27);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(rectangleInsets57);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        double double15 = rectangleInsets13.trimWidth((double) (byte) 100);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setRangeCrosshairValue((double) 200, false);
        boolean boolean6 = categoryPlot2.isRangeCrosshairVisible();
        java.awt.Color color8 = java.awt.Color.white;
        java.awt.Color color9 = java.awt.Color.getColor("", color8);
        categoryPlot2.setNoDataMessagePaint((java.awt.Paint) color8);
        valueMarker1.setOutlinePaint((java.awt.Paint) color8);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = valueMarker1.getLabelOffset();
        valueMarker1.setAlpha(0.5f);
        org.jfree.chart.text.TextAnchor textAnchor15 = valueMarker1.getLabelTextAnchor();
        java.lang.String str16 = textAnchor15.toString();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TextAnchor.CENTER" + "'", str16.equals("TextAnchor.CENTER"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getNoDataMessagePaint();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot3.setRangeCrosshairStroke(stroke5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot3.getDomainAxisLocation();
        xYPlot0.setRangeAxisLocation(axisLocation7, false);
        xYPlot0.setOutlineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = xYPlot0.getDatasetRenderingOrder();
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        xYPlot0.setDomainCrosshairPaint(paint13);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = objectList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource9);
        org.jfree.chart.plot.Plot plot11 = dateAxis1.getPlot();
        double[] doubleArray16 = new double[] { 0.4d, (-1) };
        double[] doubleArray19 = new double[] { 0.4d, (-1) };
        double[] doubleArray22 = new double[] { 0.4d, (-1) };
        double[] doubleArray25 = new double[] { 0.4d, (-1) };
        double[] doubleArray28 = new double[] { 0.4d, (-1) };
        double[] doubleArray31 = new double[] { 0.4d, (-1) };
        double[][] doubleArray32 = new double[][] { doubleArray16, doubleArray19, doubleArray22, doubleArray25, doubleArray28, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "{0}", doubleArray32);
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset33);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset33, true);
        dateAxis1.setRange(range36);
        dateAxis1.setUpperMargin(0.08d);
        org.jfree.chart.event.AxisChangeListener axisChangeListener40 = null;
        dateAxis1.removeChangeListener(axisChangeListener40);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(range36);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        org.jfree.chart.util.Rotation rotation2 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj4 = categoryAxis3D3.clone();
        boolean boolean5 = rotation2.equals((java.lang.Object) categoryAxis3D3);
        int int6 = objectList0.indexOf((java.lang.Object) rotation2);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0, (double) 100.0f);
        double double3 = size2D2.height;
        java.lang.Object obj4 = size2D2.clone();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        xYPlot0.zoom((double) (short) -1);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = xYPlot0.getDomainMarkers(layer15);
        xYPlot0.setDomainCrosshairVisible(false);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        xYPlot0.setDataset(100, xYDataset20);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(collection16);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        dateAxis1.setAutoRange(false);
        dateAxis1.setAxisLineVisible(false);
        java.awt.Shape shape13 = null;
        try {
            dateAxis1.setUpArrow(shape13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setRangeCrosshairValue((double) 200, false);
        boolean boolean6 = categoryPlot2.isRangeCrosshairVisible();
        java.awt.Color color8 = java.awt.Color.white;
        java.awt.Color color9 = java.awt.Color.getColor("", color8);
        categoryPlot2.setNoDataMessagePaint((java.awt.Paint) color8);
        valueMarker1.setOutlinePaint((java.awt.Paint) color8);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = valueMarker1.getLabelOffset();
        java.awt.Font font13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        valueMarker1.setLabelFont(font13);
        valueMarker1.setValue(0.0d);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        valueMarker1.notifyListeners(markerChangeEvent17);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint5 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot4.setRangeZeroBaselinePaint(paint5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray8 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer7 };
        xYPlot4.setRenderers(xYItemRendererArray8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot4.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo12, point2D13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace15);
        java.awt.Stroke stroke17 = xYPlot4.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D18 = xYPlot4.getQuadrantOrigin();
        polarPlot0.zoomDomainAxes(1.0E-8d, plotRenderingInfo3, point2D18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint24 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot23.setRangeZeroBaselinePaint(paint24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray27 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer26 };
        xYPlot23.setRenderers(xYItemRendererArray27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        xYPlot23.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo31, point2D32);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        xYPlot23.setFixedRangeAxisSpace(axisSpace34);
        java.awt.Stroke stroke36 = xYPlot23.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D37 = xYPlot23.getQuadrantOrigin();
        try {
            polarPlot0.zoomRangeAxes((double) (byte) 1, (double) (short) 1, plotRenderingInfo22, point2D37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(xYItemRendererArray8);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(xYItemRendererArray27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(point2D37);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot0.getDomainAxisEdge();
        java.util.List list14 = xYPlot0.getAnnotations();
        xYPlot0.clearDomainAxes();
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset18 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer19 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot20 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset18, waferMapRenderer19);
        org.jfree.data.general.WaferMapDataset waferMapDataset21 = null;
        waferMapPlot20.setDataset(waferMapDataset21);
        float float23 = waferMapPlot20.getBackgroundImageAlpha();
        valueMarker17.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot20);
        java.awt.Paint paint25 = valueMarker17.getPaint();
        java.awt.Paint paint26 = valueMarker17.getLabelPaint();
        xYPlot0.setDomainZeroBaselinePaint(paint26);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.5f + "'", float23 == 0.5f);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str2 = categoryAxis3D1.getLabelURL();
        double double3 = categoryAxis3D1.getCategoryMargin();
        categoryAxis3D1.setLabelURL("RectangleEdge.TOP");
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis3D1.setTickMarkStroke(stroke6);
        java.awt.Font font9 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) (short) 100);
        java.awt.Paint paint11 = null;
        categoryAxis3D1.setTickLabelPaint((java.lang.Comparable) (-1L), paint11);
        java.awt.Paint paint13 = categoryAxis3D1.getTickMarkPaint();
        categoryAxis3D1.setFixedDimension((double) (-1L));
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio((float) (short) 0);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis3D1.getCategoryEnd((int) (byte) -1, 15, rectangle2D20, rectangleEdge21);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint25 = categoryPlot24.getNoDataMessagePaint();
        java.awt.Color color26 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint29 = textTitle28.getPaint();
        java.awt.Color color30 = java.awt.Color.red;
        java.awt.Color color31 = java.awt.Color.red;
        java.awt.Color color32 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray33 = new java.awt.Paint[] { color26, paint29, color30, color31, color32 };
        java.awt.Paint[] paintArray34 = null;
        java.awt.Stroke stroke35 = null;
        java.awt.Stroke[] strokeArray36 = new java.awt.Stroke[] { stroke35 };
        java.awt.Stroke[] strokeArray37 = new java.awt.Stroke[] {};
        java.awt.Shape shape38 = null;
        java.awt.Shape[] shapeArray39 = new java.awt.Shape[] { shape38 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier40 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray33, paintArray34, strokeArray36, strokeArray37, shapeArray39);
        java.awt.Stroke stroke41 = defaultDrawingSupplier40.getNextStroke();
        java.awt.Paint paint42 = defaultDrawingSupplier40.getNextFillPaint();
        java.awt.Paint paint43 = defaultDrawingSupplier40.getNextPaint();
        categoryPlot24.setRangeGridlinePaint(paint43);
        java.awt.Color color46 = java.awt.Color.ORANGE;
        java.awt.Color color47 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke48 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset50 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer51 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot52 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset50, waferMapRenderer51);
        org.jfree.data.general.WaferMapDataset waferMapDataset53 = null;
        waferMapPlot52.setDataset(waferMapDataset53);
        waferMapPlot52.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart57 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot52);
        jFreeChart57.setBackgroundImageAlpha(1.0f);
        jFreeChart57.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = jFreeChart57.getPadding();
        org.jfree.chart.block.LineBorder lineBorder63 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color47, stroke48, rectangleInsets62);
        org.jfree.chart.plot.ValueMarker valueMarker64 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color46, stroke48);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent65 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) valueMarker64);
        java.awt.Stroke stroke66 = valueMarker64.getOutlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D69 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font71 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D69.setTickLabelFont((java.lang.Comparable) (short) 10, font71);
        org.jfree.chart.text.TextFragment textFragment73 = new org.jfree.chart.text.TextFragment("hi!", font71);
        float float74 = textFragment73.getBaselineOffset();
        java.awt.Paint paint75 = textFragment73.getPaint();
        org.jfree.chart.plot.RingPlot ringPlot76 = new org.jfree.chart.plot.RingPlot();
        java.lang.Object obj77 = ringPlot76.clone();
        java.awt.Graphics2D graphics2D78 = null;
        java.awt.geom.Rectangle2D rectangle2D79 = null;
        org.jfree.chart.plot.RingPlot ringPlot80 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint81 = ringPlot80.getLabelBackgroundPaint();
        ringPlot80.setShadowXOffset((double) (-1.0f));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo85 = null;
        org.jfree.chart.plot.PiePlotState piePlotState86 = ringPlot76.initialise(graphics2D78, rectangle2D79, (org.jfree.chart.plot.PiePlot) ringPlot80, (java.lang.Integer) 200, plotRenderingInfo85);
        java.awt.Stroke stroke87 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot76.setSeparatorStroke(stroke87);
        org.jfree.chart.plot.ValueMarker valueMarker90 = new org.jfree.chart.plot.ValueMarker((double) 200, paint43, stroke66, paint75, stroke87, (float) (byte) 0);
        categoryAxis3D1.setAxisLineStroke(stroke87);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(strokeArray36);
        org.junit.Assert.assertNotNull(strokeArray37);
        org.junit.Assert.assertNotNull(shapeArray39);
        org.junit.Assert.assertNull(stroke41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(font71);
        org.junit.Assert.assertTrue("'" + float74 + "' != '" + 0.0f + "'", float74 == 0.0f);
        org.junit.Assert.assertNotNull(paint75);
        org.junit.Assert.assertNotNull(obj77);
        org.junit.Assert.assertNotNull(paint81);
        org.junit.Assert.assertNotNull(piePlotState86);
        org.junit.Assert.assertNotNull(stroke87);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        categoryPlot0.setAnchorValue(0.0d);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace4);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer6 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset5, waferMapRenderer6);
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        waferMapPlot7.setDataset(waferMapDataset8);
        waferMapPlot7.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot7);
        jFreeChart12.setBackgroundImageAlpha(1.0f);
        jFreeChart12.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = jFreeChart12.getPadding();
        org.jfree.chart.block.LineBorder lineBorder18 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color2, stroke3, rectangleInsets17);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color1, stroke3);
        valueMarker19.setLabel("TextAnchor.CENTER");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0, (double) 100.0f);
        size2D2.height = (short) -1;
        size2D2.height = (byte) 10;
        size2D2.setWidth((double) (short) 1);
        double double9 = size2D2.getHeight();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double[] doubleArray4 = new double[] { 0.4d, (-1) };
        double[] doubleArray7 = new double[] { 0.4d, (-1) };
        double[] doubleArray10 = new double[] { 0.4d, (-1) };
        double[] doubleArray13 = new double[] { 0.4d, (-1) };
        double[] doubleArray16 = new double[] { 0.4d, (-1) };
        double[] doubleArray19 = new double[] { 0.4d, (-1) };
        double[][] doubleArray20 = new double[][] { doubleArray4, doubleArray7, doubleArray10, doubleArray13, doubleArray16, doubleArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "{0}", doubleArray20);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset21);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset21, true);
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset21);
        java.lang.Number number26 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset21);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 2.4d + "'", number25.equals(2.4d));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (-1.0d) + "'", number26.equals((-1.0d)));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape7 = dateAxis6.getDownArrow();
        java.awt.Shape shape8 = dateAxis6.getUpArrow();
        dateAxis6.centerRange((double) (short) 1);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset14 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer15 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot16 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset14, waferMapRenderer15);
        org.jfree.data.general.WaferMapDataset waferMapDataset17 = null;
        waferMapPlot16.setDataset(waferMapDataset17);
        waferMapPlot16.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot16);
        jFreeChart21.setBackgroundImageAlpha(1.0f);
        jFreeChart21.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = jFreeChart21.getPadding();
        org.jfree.chart.block.LineBorder lineBorder27 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color11, stroke12, rectangleInsets26);
        dateAxis6.setTickMarkStroke(stroke12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis6, xYItemRenderer29);
        boolean boolean31 = textBlockAnchor0.equals((java.lang.Object) xYDataset1);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.Color color5 = java.awt.Color.getColor("", color4);
        int int6 = color4.getRGB();
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        int int8 = color4.getRGB();
        int int9 = color4.getBlue();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.Object obj1 = ringPlot0.clone();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint5 = ringPlot4.getLabelBackgroundPaint();
        ringPlot4.setShadowXOffset((double) (-1.0f));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.PiePlotState piePlotState10 = ringPlot0.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.PiePlot) ringPlot4, (java.lang.Integer) 200, plotRenderingInfo9);
        boolean boolean11 = ringPlot0.getIgnoreZeroValues();
        double double12 = ringPlot0.getShadowYOffset();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(piePlotState10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getURLText();
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle1.setBackgroundPaint(paint3);
        textTitle1.setHeight((double) ' ');
        org.jfree.chart.util.Size2D size2D7 = new org.jfree.chart.util.Size2D();
        boolean boolean8 = textTitle1.equals((java.lang.Object) size2D7);
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer11 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset10, waferMapRenderer11);
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        waferMapPlot12.setDataset(waferMapDataset13);
        waferMapPlot12.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot12);
        java.awt.Stroke stroke18 = jFreeChart17.getBorderStroke();
        boolean boolean19 = jFreeChart17.isBorderVisible();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.data.general.WaferMapDataset waferMapDataset21 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer22 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot23 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset21, waferMapRenderer22);
        org.jfree.data.general.WaferMapDataset waferMapDataset24 = null;
        waferMapPlot23.setDataset(waferMapDataset24);
        boolean boolean26 = chartChangeEventType20.equals((java.lang.Object) waferMapPlot23);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textTitle1, jFreeChart17, chartChangeEventType20);
        org.jfree.chart.plot.Plot plot28 = jFreeChart17.getPlot();
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint32 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot31.setRangeZeroBaselinePaint(paint32);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray35 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer34 };
        xYPlot31.setRenderers(xYItemRendererArray35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        xYPlot31.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo39, point2D40);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder42 = xYPlot31.getDatasetRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint47 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot46.setRangeZeroBaselinePaint(paint47);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray50 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer49 };
        xYPlot46.setRenderers(xYItemRendererArray50);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        java.awt.geom.Point2D point2D55 = null;
        xYPlot46.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo54, point2D55);
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        xYPlot46.setFixedRangeAxisSpace(axisSpace57);
        java.awt.Stroke stroke59 = xYPlot46.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D60 = xYPlot46.getQuadrantOrigin();
        xYPlot31.zoomDomainAxes((double) 10.0f, (double) 2.0f, plotRenderingInfo45, point2D60);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo62 = null;
        try {
            jFreeChart17.draw(graphics2D29, rectangle2D30, point2D60, chartRenderingInfo62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(plot28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(xYItemRendererArray35);
        org.junit.Assert.assertNotNull(datasetRenderingOrder42);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(xYItemRendererArray50);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(point2D60);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 1, 0);
        categoryPlot0.setDrawSharedDomainAxis(true);
        java.lang.Object obj6 = categoryPlot0.clone();
        categoryPlot0.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isAngleGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        polarPlot0.setDataset(xYDataset2);
        java.awt.Font font4 = polarPlot0.getAngleLabelFont();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color11 = java.awt.Color.ORANGE;
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset15 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer16 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot17 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset15, waferMapRenderer16);
        org.jfree.data.general.WaferMapDataset waferMapDataset18 = null;
        waferMapPlot17.setDataset(waferMapDataset18);
        waferMapPlot17.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot17);
        jFreeChart22.setBackgroundImageAlpha(1.0f);
        jFreeChart22.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = jFreeChart22.getPadding();
        org.jfree.chart.block.LineBorder lineBorder28 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color12, stroke13, rectangleInsets27);
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color11, stroke13);
        polarPlot9.setRadiusGridlineStroke(stroke13);
        java.awt.Stroke stroke31 = polarPlot9.getRadiusGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint36 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot35.setRangeZeroBaselinePaint(paint36);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray39 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer38 };
        xYPlot35.setRenderers(xYItemRendererArray39);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        java.awt.geom.Point2D point2D44 = null;
        xYPlot35.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo43, point2D44);
        org.jfree.chart.axis.AxisSpace axisSpace46 = null;
        xYPlot35.setFixedRangeAxisSpace(axisSpace46);
        java.awt.Stroke stroke48 = xYPlot35.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D49 = xYPlot35.getQuadrantOrigin();
        polarPlot9.zoomDomainAxes(0.05d, 0.05d, plotRenderingInfo34, point2D49);
        try {
            polarPlot0.zoomRangeAxes((double) 1, plotRenderingInfo8, point2D49, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(xYItemRendererArray39);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(point2D49);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(8.0d, plotRenderingInfo4, point2D5);
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.LEFT;
        legendTitle7.setLegendItemGraphicLocation(rectangleAnchor8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            legendTitle7.draw(graphics2D10, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getDomainAxis();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = xYPlot0.getOrientation();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(plotOrientation4);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint12 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot11.setRangeZeroBaselinePaint(paint12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray15 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer14 };
        xYPlot11.setRenderers(xYItemRendererArray15);
        xYPlot0.setRenderers(xYItemRendererArray15);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape20 = dateAxis19.getDownArrow();
        java.awt.Shape shape21 = dateAxis19.getUpArrow();
        dateAxis19.centerRange((double) (short) 1);
        dateAxis19.setRange(0.0d, (double) '#');
        dateAxis19.setAutoRange(false);
        dateAxis19.setRangeWithMargins((double) 'a', (double) 100.0f);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = new org.jfree.chart.axis.ValueAxis[] { dateAxis19 };
        xYPlot0.setRangeAxes(valueAxisArray32);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape37 = dateAxis36.getDownArrow();
        java.awt.Shape shape38 = dateAxis36.getUpArrow();
        dateAxis36.centerRange((double) (short) 1);
        dateAxis36.setRange(0.0d, (double) '#');
        boolean boolean44 = dateAxis36.isNegativeArrowVisible();
        java.awt.Paint paint45 = dateAxis36.getTickLabelPaint();
        xYPlot0.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) dateAxis36);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(xYItemRendererArray15);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(valueAxisArray32);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setUpperMargin((double) 100L);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        java.awt.Shape shape7 = dateAxis5.getUpArrow();
        dateAxis5.centerRange((double) (short) 1);
        dateAxis5.setRange(0.0d, (double) '#');
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis5.setStandardTickUnits(tickUnitSource13);
        org.jfree.chart.plot.Plot plot15 = dateAxis5.getPlot();
        double[] doubleArray20 = new double[] { 0.4d, (-1) };
        double[] doubleArray23 = new double[] { 0.4d, (-1) };
        double[] doubleArray26 = new double[] { 0.4d, (-1) };
        double[] doubleArray29 = new double[] { 0.4d, (-1) };
        double[] doubleArray32 = new double[] { 0.4d, (-1) };
        double[] doubleArray35 = new double[] { 0.4d, (-1) };
        double[][] doubleArray36 = new double[][] { doubleArray20, doubleArray23, doubleArray26, doubleArray29, doubleArray32, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "{0}", doubleArray36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset37);
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset37, true);
        dateAxis5.setRange(range40);
        dateAxis1.setRange(range40, false, false);
        double double45 = dateAxis1.getFixedAutoRange();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(tickUnitSource13);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "RectangleEdge.TOP", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "");
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str7 = projectInfo6.getLicenceText();
        org.jfree.chart.ui.Library[] libraryArray8 = projectInfo6.getLibraries();
        basicProjectInfo5.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo6);
        boolean boolean10 = textBlock0.equals((java.lang.Object) projectInfo6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(libraryArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        boolean boolean14 = jFreeChart8.isNotify();
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart8.getLegend(200);
        jFreeChart8.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.data.general.WaferMapDataset waferMapDataset19 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer20 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot21 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset19, waferMapRenderer20);
        org.jfree.data.general.WaferMapDataset waferMapDataset22 = null;
        waferMapPlot21.setDataset(waferMapDataset22);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent24 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) waferMapPlot21);
        org.jfree.chart.JFreeChart jFreeChart25 = plotChangeEvent24.getChart();
        jFreeChart8.plotChanged(plotChangeEvent24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = null;
        java.awt.image.BufferedImage bufferedImage32 = jFreeChart8.createBufferedImage((int) (byte) 1, (int) (short) 100, (double) (short) 0, (double) (byte) 10, chartRenderingInfo31);
        java.awt.image.BufferedImage bufferedImage35 = jFreeChart8.createBufferedImage((int) 'a', (int) (byte) 10);
        java.awt.Color color36 = java.awt.Color.ORANGE;
        int int37 = color36.getGreen();
        jFreeChart8.setBackgroundPaint((java.awt.Paint) color36);
        java.awt.RenderingHints renderingHints39 = null;
        try {
            jFreeChart8.setRenderingHints(renderingHints39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(legendTitle16);
        org.junit.Assert.assertNull(jFreeChart25);
        org.junit.Assert.assertNotNull(bufferedImage32);
        org.junit.Assert.assertNotNull(bufferedImage35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 200 + "'", int37 == 200);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 10L, (double) 100.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot5.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomDomainAxes(8.0d, plotRenderingInfo9, point2D10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot5);
        java.awt.Font font13 = legendTitle12.getItemFont();
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset17 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer18 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot19 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset17, waferMapRenderer18);
        org.jfree.data.general.WaferMapDataset waferMapDataset20 = null;
        waferMapPlot19.setDataset(waferMapDataset20);
        waferMapPlot19.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot19);
        jFreeChart24.setBackgroundImageAlpha(1.0f);
        jFreeChart24.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = jFreeChart24.getPadding();
        org.jfree.chart.block.LineBorder lineBorder30 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color14, stroke15, rectangleInsets29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = lineBorder30.getInsets();
        columnArrangement4.add((org.jfree.chart.block.Block) legendTitle12, (java.lang.Object) rectangleInsets31);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.lang.String str34 = rectangleAnchor33.toString();
        legendTitle12.setLegendItemGraphicLocation(rectangleAnchor33);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str34.equals("RectangleAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        xYPlot0.zoom((double) (short) -1);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ThreadContext");
        java.text.AttributedString attributedString18 = standardPieSectionLabelGenerator16.getAttributedLabel((int) (byte) -1);
        java.text.NumberFormat numberFormat19 = standardPieSectionLabelGenerator16.getPercentFormat();
        boolean boolean20 = xYPlot0.equals((java.lang.Object) standardPieSectionLabelGenerator16);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(attributedString18);
        org.junit.Assert.assertNotNull(numberFormat19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.block.Arrangement arrangement2 = blockContainer1.getArrangement();
        java.lang.Object obj3 = null;
        boolean boolean4 = blockContainer1.equals(obj3);
        org.junit.Assert.assertNotNull(arrangement2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isAngleGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        polarPlot0.setDataset(xYDataset2);
        java.awt.Paint paint4 = polarPlot0.getRadiusGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color9 = java.awt.Color.ORANGE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer14 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot15 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset13, waferMapRenderer14);
        org.jfree.data.general.WaferMapDataset waferMapDataset16 = null;
        waferMapPlot15.setDataset(waferMapDataset16);
        waferMapPlot15.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot15);
        jFreeChart20.setBackgroundImageAlpha(1.0f);
        jFreeChart20.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = jFreeChart20.getPadding();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color10, stroke11, rectangleInsets25);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color9, stroke11);
        polarPlot7.setRadiusGridlineStroke(stroke11);
        java.awt.Stroke stroke29 = polarPlot7.getRadiusGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint34 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot33.setRangeZeroBaselinePaint(paint34);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray37 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer36 };
        xYPlot33.setRenderers(xYItemRendererArray37);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Point2D point2D42 = null;
        xYPlot33.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo41, point2D42);
        org.jfree.chart.axis.AxisSpace axisSpace44 = null;
        xYPlot33.setFixedRangeAxisSpace(axisSpace44);
        java.awt.Stroke stroke46 = xYPlot33.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D47 = xYPlot33.getQuadrantOrigin();
        polarPlot7.zoomDomainAxes(0.05d, 0.05d, plotRenderingInfo32, point2D47);
        try {
            polarPlot0.zoomRangeAxes((double) 200, plotRenderingInfo6, point2D47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(xYItemRendererArray37);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(point2D47);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0, (double) 100.0f);
        double double3 = size2D2.getHeight();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean2 = numberAxis0.isAutoRange();
        numberAxis0.setLabelAngle((double) '4');
        java.awt.Font font5 = numberAxis0.getLabelFont();
        numberAxis0.setAutoRangeIncludesZero(false);
        boolean boolean8 = numberAxis0.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = piePlotState1.getExplodedPieArea();
        piePlotState1.setPassesRequired(2);
        piePlotState1.setPassesRequired(10);
        org.junit.Assert.assertNull(rectangle2D2);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint3 = categoryPlot2.getNoDataMessagePaint();
        categoryPlot2.setAnchorValue(0.0d);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getURLText();
        java.awt.Paint paint9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle7.setBackgroundPaint(paint9);
        categoryPlot2.setDomainGridlinePaint(paint9);
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint9);
        java.util.List list13 = textBlock12.getLines();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        textBlock12.draw(graphics2D14, 10.0f, (float) (-16711681), textBlockAnchor17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor22 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        textBlock12.draw(graphics2D19, (-1.0f), 0.0f, textBlockAnchor22, 0.0f, (float) 100, (double) (byte) 1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
        org.junit.Assert.assertNotNull(textBlockAnchor22);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        float float7 = waferMapPlot4.getBackgroundImageAlpha();
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot4);
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer11 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset10, waferMapRenderer11);
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        waferMapPlot12.setDataset(waferMapDataset13);
        waferMapPlot12.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot12);
        jFreeChart17.setBackgroundImageAlpha(1.0f);
        jFreeChart17.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = jFreeChart17.getPadding();
        boolean boolean23 = jFreeChart17.isNotify();
        waferMapPlot4.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart17);
        jFreeChart17.removeLegend();
        java.lang.Object obj26 = jFreeChart17.clone();
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color2 = java.awt.Color.ORANGE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer7 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6, waferMapRenderer7);
        org.jfree.data.general.WaferMapDataset waferMapDataset9 = null;
        waferMapPlot8.setDataset(waferMapDataset9);
        waferMapPlot8.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot8);
        jFreeChart13.setBackgroundImageAlpha(1.0f);
        jFreeChart13.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = jFreeChart13.getPadding();
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color3, stroke4, rectangleInsets18);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color2, stroke4);
        polarPlot0.setRadiusGridlineStroke(stroke4);
        polarPlot0.removeCornerTextItem("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        ringPlot24.setIgnoreZeroValues(true);
        java.awt.Stroke stroke27 = ringPlot24.getLabelLinkStroke();
        polarPlot0.setOutlineStroke(stroke27);
        polarPlot0.setAngleLabelsVisible(false);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        polarPlot0.setDataset(xYDataset31);
        float float33 = polarPlot0.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 1.0f + "'", float33 == 1.0f);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getURLText();
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle1.setBackgroundPaint(paint3);
        textTitle1.setHeight((double) ' ');
        org.jfree.chart.util.Size2D size2D7 = new org.jfree.chart.util.Size2D();
        boolean boolean8 = textTitle1.equals((java.lang.Object) size2D7);
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer11 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset10, waferMapRenderer11);
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        waferMapPlot12.setDataset(waferMapDataset13);
        waferMapPlot12.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot12);
        java.awt.Stroke stroke18 = jFreeChart17.getBorderStroke();
        boolean boolean19 = jFreeChart17.isBorderVisible();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.data.general.WaferMapDataset waferMapDataset21 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer22 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot23 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset21, waferMapRenderer22);
        org.jfree.data.general.WaferMapDataset waferMapDataset24 = null;
        waferMapPlot23.setDataset(waferMapDataset24);
        boolean boolean26 = chartChangeEventType20.equals((java.lang.Object) waferMapPlot23);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textTitle1, jFreeChart17, chartChangeEventType20);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot28 = jFreeChart17.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.WaferMapPlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.block.Arrangement arrangement2 = blockContainer1.getArrangement();
        java.lang.String str3 = blockContainer1.getID();
        org.junit.Assert.assertNotNull(arrangement2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.awt.Image image2 = null;
        waferMapPlot1.setBackgroundImage(image2);
        java.lang.String str4 = waferMapPlot1.getPlotType();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "WMAP_Plot" + "'", str4.equals("WMAP_Plot"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.Object obj1 = ringPlot0.clone();
        double double2 = ringPlot0.getMaximumExplodePercent();
        double double3 = ringPlot0.getInnerSeparatorExtension();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint5 = ringPlot4.getLabelBackgroundPaint();
        ringPlot4.setShadowXOffset((double) (-1.0f));
        org.jfree.chart.util.Rotation rotation8 = ringPlot4.getDirection();
        java.lang.String str9 = rotation8.toString();
        ringPlot0.setDirection(rotation8);
        java.awt.Color color12 = java.awt.Color.green;
        ringPlot0.setSectionPaint((java.lang.Comparable) 0.5f, (java.awt.Paint) color12);
        int int14 = ringPlot0.getPieIndex();
        try {
            ringPlot0.setInteriorGap(10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (10.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rotation8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Rotation.CLOCKWISE" + "'", str9.equals("Rotation.CLOCKWISE"));
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxisForDataset((-1));
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str9 = projectInfo8.getLicenceText();
        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo8.getLibraries();
        boolean boolean11 = categoryPlot0.equals((java.lang.Object) projectInfo8);
        boolean boolean12 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(libraryArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.data.category.CategoryDataset categoryDataset6 = categoryPlot0.getDataset(1);
        categoryPlot0.clearRangeMarkers((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(categoryDataset6);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getURLText();
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle1.setBackgroundPaint(paint3);
        textTitle1.setHeight((double) ' ');
        java.awt.Paint paint7 = textTitle1.getBackgroundPaint();
        textTitle1.setToolTipText("ChartChangeEventType.DATASET_UPDATED");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        dateAxis1.setAutoRange(false);
        dateAxis1.setAxisLineVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        xYPlot13.clearDomainAxes();
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot13);
        java.text.DateFormat dateFormat16 = dateAxis1.getDateFormatOverride();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(dateFormat16);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("ThreadContext");
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("ThreadContext");
        textLine1.removeFragment(textFragment3);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint17 = categoryPlot16.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot16.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation18);
        int int20 = xYPlot0.getWeight();
        boolean boolean21 = xYPlot0.isRangeZoomable();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot0.setRenderer(xYItemRenderer22);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = xYPlot0.getDomainMarkers(layer24);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(collection25);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        categoryPlot0.setAnchorValue(0.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str6 = textTitle5.getURLText();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle5.setBackgroundPaint(paint7);
        categoryPlot0.setDomainGridlinePaint(paint7);
        categoryPlot0.setWeight((int) (byte) -1);
        categoryPlot0.setAnchorValue(90.0d, false);
        double[] doubleArray19 = new double[] { 0.4d, (-1) };
        double[] doubleArray22 = new double[] { 0.4d, (-1) };
        double[] doubleArray25 = new double[] { 0.4d, (-1) };
        double[] doubleArray28 = new double[] { 0.4d, (-1) };
        double[] doubleArray31 = new double[] { 0.4d, (-1) };
        double[] doubleArray34 = new double[] { 0.4d, (-1) };
        double[][] doubleArray35 = new double[][] { doubleArray19, doubleArray22, doubleArray25, doubleArray28, doubleArray31, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "{0}", doubleArray35);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset36);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = categoryPlot0.getRendererForDataset(categoryDataset36);
        java.lang.Number number39 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset36);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset36, true);
        try {
            java.lang.Number number42 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset36);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNull(categoryItemRenderer38);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 0.4d + "'", number39.equals(0.4d));
        org.junit.Assert.assertNotNull(range41);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.Color color5 = java.awt.Color.getColor("", color4);
        int int6 = color4.getRGB();
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        xYPlot0.setRangeCrosshairValue((double) '4', true);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            boolean boolean14 = xYPlot0.removeRangeMarker((int) (byte) 1, marker12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.awt.Color color0 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint3 = textTitle2.getPaint();
        java.awt.Color color4 = java.awt.Color.red;
        java.awt.Color color5 = java.awt.Color.red;
        java.awt.Color color6 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color0, paint3, color4, color5, color6 };
        java.awt.Paint[] paintArray8 = null;
        java.awt.Stroke stroke9 = null;
        java.awt.Stroke[] strokeArray10 = new java.awt.Stroke[] { stroke9 };
        java.awt.Stroke[] strokeArray11 = new java.awt.Stroke[] {};
        java.awt.Shape shape12 = null;
        java.awt.Shape[] shapeArray13 = new java.awt.Shape[] { shape12 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray8, strokeArray10, strokeArray11, shapeArray13);
        java.awt.Stroke stroke15 = defaultDrawingSupplier14.getNextStroke();
        java.awt.Paint paint16 = defaultDrawingSupplier14.getNextFillPaint();
        java.lang.Object obj17 = defaultDrawingSupplier14.clone();
        java.lang.Object obj18 = defaultDrawingSupplier14.clone();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(strokeArray11);
        org.junit.Assert.assertNotNull(shapeArray13);
        org.junit.Assert.assertNull(stroke15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        float float7 = waferMapPlot4.getBackgroundImageAlpha();
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot4);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) waferMapPlot4);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(8.0d, plotRenderingInfo4, point2D5);
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        java.awt.Paint paint8 = legendTitle7.getBackgroundPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        boolean boolean9 = dateAxis1.isNegativeArrowVisible();
        double double10 = dateAxis1.getFixedDimension();
        boolean boolean11 = dateAxis1.isPositiveArrowVisible();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        org.jfree.data.general.WaferMapDataset waferMapDataset7 = null;
        waferMapPlot6.setDataset(waferMapDataset7);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) waferMapPlot6);
        categoryPlot0.notifyListeners(plotChangeEvent9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.zoomRangeAxes(0.0d, (double) (short) -1, plotRenderingInfo13, point2D14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str18 = categoryAxis3D17.getLabelURL();
        double double19 = categoryAxis3D17.getCategoryMargin();
        categoryAxis3D17.setLabelURL("RectangleEdge.TOP");
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis3D17.setTickMarkStroke(stroke22);
        java.awt.Font font25 = categoryAxis3D17.getTickLabelFont((java.lang.Comparable) (short) 100);
        java.awt.Paint paint27 = null;
        categoryAxis3D17.setTickLabelPaint((java.lang.Comparable) (-1L), paint27);
        java.util.List list29 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D17);
        categoryPlot0.setWeight((int) (short) 100);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2d + "'", double19 == 0.2d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(list29);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke2);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        categoryPlot0.clearRangeMarkers((int) (byte) 10);
        int int7 = categoryPlot0.getWeight();
        double[] doubleArray14 = new double[] { 0.4d, (-1) };
        double[] doubleArray17 = new double[] { 0.4d, (-1) };
        double[] doubleArray20 = new double[] { 0.4d, (-1) };
        double[] doubleArray23 = new double[] { 0.4d, (-1) };
        double[] doubleArray26 = new double[] { 0.4d, (-1) };
        double[] doubleArray29 = new double[] { 0.4d, (-1) };
        double[][] doubleArray30 = new double[][] { doubleArray14, doubleArray17, doubleArray20, doubleArray23, doubleArray26, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "{0}", doubleArray30);
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "ClassContext", doubleArray30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset32);
        categoryPlot0.setDataset(categoryDataset32);
        java.lang.Number number35 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset32);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 2.4d + "'", number35.equals(2.4d));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        org.jfree.data.general.WaferMapDataset waferMapDataset7 = null;
        waferMapPlot6.setDataset(waferMapDataset7);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) waferMapPlot6);
        categoryPlot0.notifyListeners(plotChangeEvent9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.zoomRangeAxes(0.0d, (double) (short) -1, plotRenderingInfo13, point2D14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot0.getRangeAxisLocation(2);
        categoryPlot0.setWeight(10);
        try {
            categoryPlot0.zoom(2.4d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.ValueAxis valueAxis16 = xYPlot0.getRangeAxisForDataset(0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNull(valueAxis16);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        java.awt.Color color2 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint5 = textTitle4.getPaint();
        java.awt.Color color6 = java.awt.Color.red;
        java.awt.Color color7 = java.awt.Color.red;
        java.awt.Color color8 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color2, paint5, color6, color7, color8 };
        java.awt.Paint[] paintArray10 = null;
        java.awt.Stroke stroke11 = null;
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] { stroke11 };
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] {};
        java.awt.Shape shape14 = null;
        java.awt.Shape[] shapeArray15 = new java.awt.Shape[] { shape14 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray10, strokeArray12, strokeArray13, shapeArray15);
        java.awt.Stroke stroke17 = defaultDrawingSupplier16.getNextStroke();
        java.awt.Paint paint18 = defaultDrawingSupplier16.getNextFillPaint();
        java.awt.Paint paint19 = defaultDrawingSupplier16.getNextPaint();
        categoryPlot0.setRangeGridlinePaint(paint19);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset25 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer26 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot27 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset25, waferMapRenderer26);
        org.jfree.data.general.WaferMapDataset waferMapDataset28 = null;
        waferMapPlot27.setDataset(waferMapDataset28);
        float float30 = waferMapPlot27.getBackgroundImageAlpha();
        valueMarker24.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot27);
        java.awt.Font font32 = valueMarker24.getLabelFont();
        dateAxis22.setTickLabelFont(font32);
        org.jfree.data.Range range34 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis22);
        boolean boolean35 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection36 = categoryPlot0.getFixedLegendItems();
        categoryPlot0.setRangeCrosshairVisible(false);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        boolean boolean43 = categoryPlot0.render(graphics2D39, rectangle2D40, (int) (short) 1, plotRenderingInfo42);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.5f + "'", float30 == 0.5f);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(legendItemCollection36);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        boolean boolean9 = dateAxis1.isNegativeArrowVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = dateAxis1.getStandardTickUnits();
        boolean boolean11 = dateAxis1.isAutoRange();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(tickUnitSource10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) 0, (double) 100.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.data.Range range4 = rectangleConstraint2.getHeightRange();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape7 = dateAxis6.getDownArrow();
        java.awt.Shape shape8 = dateAxis6.getUpArrow();
        dateAxis6.centerRange((double) (short) 1);
        dateAxis6.setRange(0.0d, (double) '#');
        org.jfree.data.Range range16 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis6.setRange(range16, false, false);
        org.jfree.data.Range range21 = org.jfree.data.Range.shift(range16, 8.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = rectangleConstraint2.toRangeWidth(range16);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType23 = rectangleConstraint22.getHeightConstraintType();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType24 = rectangleConstraint22.getHeightConstraintType();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
        org.junit.Assert.assertNotNull(lengthConstraintType23);
        org.junit.Assert.assertNotNull(lengthConstraintType24);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        boolean boolean2 = unitType0.equals((java.lang.Object) textBlockAnchor1);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 10);
        pieLabelDistributor1.sort();
        pieLabelDistributor1.distributeLabels(100.0d, (double) 1L);
        pieLabelDistributor1.sort();
        pieLabelDistributor1.distributeLabels((double) 255, (double) (short) 100);
        int int10 = pieLabelDistributor1.getItemCount();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceText();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape8 = dateAxis7.getDownArrow();
        java.awt.Shape shape9 = dateAxis7.getUpArrow();
        dateAxis7.centerRange((double) (short) 1);
        dateAxis7.setRange(0.0d, (double) '#');
        dateAxis7.setAutoRange(false);
        categoryPlot2.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis7);
        java.util.Date date18 = dateAxis7.getMinimumDate();
        java.awt.Paint paint19 = dateAxis7.getAxisLinePaint();
        boolean boolean20 = projectInfo0.equals((java.lang.Object) dateAxis7);
        java.util.Date date21 = dateAxis7.getMinimumDate();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("java.awt.Color[r=255,g=200,b=0]", graphics2D1, 0.8f, 1.0f, (double) 1, (float) 15, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot0.getRenderer(0);
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot0.getDomainAxisForDataset((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint17 = categoryPlot16.getNoDataMessagePaint();
        java.awt.Color color18 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint21 = textTitle20.getPaint();
        java.awt.Color color22 = java.awt.Color.red;
        java.awt.Color color23 = java.awt.Color.red;
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] { color18, paint21, color22, color23, color24 };
        java.awt.Paint[] paintArray26 = null;
        java.awt.Stroke stroke27 = null;
        java.awt.Stroke[] strokeArray28 = new java.awt.Stroke[] { stroke27 };
        java.awt.Stroke[] strokeArray29 = new java.awt.Stroke[] {};
        java.awt.Shape shape30 = null;
        java.awt.Shape[] shapeArray31 = new java.awt.Shape[] { shape30 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier32 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray25, paintArray26, strokeArray28, strokeArray29, shapeArray31);
        java.awt.Stroke stroke33 = defaultDrawingSupplier32.getNextStroke();
        java.awt.Paint paint34 = defaultDrawingSupplier32.getNextFillPaint();
        java.awt.Paint paint35 = defaultDrawingSupplier32.getNextPaint();
        categoryPlot16.setRangeGridlinePaint(paint35);
        java.util.List list37 = categoryPlot16.getCategories();
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot16.getRangeAxisLocation((int) '#');
        org.jfree.chart.plot.PlotOrientation plotOrientation40 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation39, plotOrientation40);
        xYPlot0.setDomainAxisLocation(0, axisLocation39, false);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        org.jfree.chart.plot.CrosshairState crosshairState48 = null;
        boolean boolean49 = xYPlot0.render(graphics2D44, rectangle2D45, (int) (byte) -1, plotRenderingInfo47, crosshairState48);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(strokeArray28);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(shapeArray31);
        org.junit.Assert.assertNull(stroke33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNull(list37);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(plotOrientation40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        java.lang.String str2 = numberAxis0.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = numberAxis0.getMarkerBand();
        numberAxis0.setAutoRange(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(markerAxisBand3);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        ringPlot0.setShadowXOffset((double) (-1.0f));
        org.jfree.chart.util.Rotation rotation4 = ringPlot0.getDirection();
        org.jfree.data.general.PieDataset pieDataset5 = ringPlot0.getDataset();
        double double7 = ringPlot0.getExplodePercent((java.lang.Comparable) "java.awt.Color[r=255,g=200,b=0]");
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNull(pieDataset5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint12 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot11.setRangeZeroBaselinePaint(paint12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray15 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer14 };
        xYPlot11.setRenderers(xYItemRendererArray15);
        xYPlot0.setRenderers(xYItemRendererArray15);
        org.jfree.chart.plot.Plot plot18 = xYPlot0.getParent();
        java.awt.Stroke stroke19 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis21.resizeRange((double) 'a', (double) (short) 10);
        int int25 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(xYItemRendererArray15);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D2.setTickLabelFont((java.lang.Comparable) (short) 10, font4);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font4, paint6);
        java.util.List list8 = textBlock7.getLines();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("Category Plot", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "RectangleEdge.TOP", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "");
        basicProjectInfo4.setName("");
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 100.0f, plotRenderingInfo5, point2D6);
        java.util.List list8 = categoryPlot0.getAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomRangeAxes((double) 'a', plotRenderingInfo10, point2D11, true);
        org.jfree.data.general.WaferMapDataset waferMapDataset15 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer16 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot17 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset15, waferMapRenderer16);
        org.jfree.data.general.WaferMapDataset waferMapDataset18 = null;
        waferMapPlot17.setDataset(waferMapDataset18);
        waferMapPlot17.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot17);
        jFreeChart22.setBackgroundImageAlpha(1.0f);
        jFreeChart22.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = jFreeChart22.getPadding();
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = textTitle29.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = textTitle29.getPosition();
        jFreeChart22.setTitle(textTitle29);
        java.awt.Color color33 = java.awt.Color.gray;
        jFreeChart22.setBackgroundPaint((java.awt.Paint) color33);
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart22);
        int int36 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        double double2 = categoryAxis3D1.getCategoryMargin();
        categoryAxis3D1.configure();
        categoryAxis3D1.configure();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str2 = categoryAxis3D1.getLabelURL();
        java.awt.Paint paint4 = categoryAxis3D1.getTickLabelPaint((java.lang.Comparable) "ThreadContext");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font8 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D6.setTickLabelFont((java.lang.Comparable) (short) 10, font8);
        int int10 = categoryAxis3D6.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke11 = categoryAxis3D6.getAxisLineStroke();
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        double double13 = piePlot3D12.getMaximumLabelWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean15 = piePlot3D12.equals((java.lang.Object) rectangleAnchor14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        piePlot3D12.setLabelPadding(rectangleInsets16);
        categoryAxis3D6.setLabelInsets(rectangleInsets16);
        categoryAxis3D1.setLabelInsets(rectangleInsets16);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint21 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot20.setRangeZeroBaselinePaint(paint21);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint24 = categoryPlot23.getNoDataMessagePaint();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot23.setRangeCrosshairStroke(stroke25);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot23.getDomainAxisLocation();
        xYPlot20.setRangeAxisLocation(axisLocation27, false);
        boolean boolean30 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) categoryAxis3D1, (java.lang.Object) axisLocation27);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.14d + "'", double13 == 0.14d);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxisForDataset((-1));
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str9 = projectInfo8.getLicenceText();
        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo8.getLibraries();
        boolean boolean11 = categoryPlot0.equals((java.lang.Object) projectInfo8);
        org.jfree.chart.ui.Library[] libraryArray12 = projectInfo8.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray13 = projectInfo8.getLibraries();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(libraryArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(libraryArray12);
        org.junit.Assert.assertNotNull(libraryArray13);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Color color6 = java.awt.Color.white;
        java.awt.Color color7 = java.awt.Color.getColor("", color6);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str14 = categoryAxis3D13.getLabelURL();
        double double15 = categoryAxis3D13.getCategoryMargin();
        categoryAxis3D13.setLabelURL("RectangleEdge.TOP");
        float float18 = categoryAxis3D13.getMaximumCategoryLabelWidthRatio();
        categoryPlot0.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D13);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.2d + "'", double15 == 0.2d);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNull(valueAxis20);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isAngleGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        polarPlot0.setDataset(xYDataset2);
        boolean boolean4 = polarPlot0.isRadiusGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D2.setTickLabelFont((java.lang.Comparable) (short) 10, font4);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font4, paint6);
        org.jfree.chart.text.TextLine textLine8 = textBlock7.getLastLine();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean13 = polarPlot12.isAngleGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        polarPlot12.setDataset(xYDataset14);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = polarPlot12.getRenderer();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        boolean boolean18 = polarPlot12.equals((java.lang.Object) textBlockAnchor17);
        try {
            textBlock7.draw(graphics2D9, 2.0f, (float) 200, textBlockAnchor17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(textLine8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(polarItemRenderer16);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.awt.Image image2 = null;
        waferMapPlot1.setBackgroundImage(image2);
        java.awt.Paint paint4 = waferMapPlot1.getNoDataMessagePaint();
        java.awt.Paint paint5 = waferMapPlot1.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        dateAxis1.resizeRange(1.0E-5d, 0.025d);
        org.junit.Assert.assertNotNull(dateTickUnit2);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        dateAxis1.setAutoRange(false);
        dateAxis1.setAxisLineVisible(false);
        dateAxis1.centerRange((double) 100.0f);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        java.awt.Shape shape18 = dateAxis16.getUpArrow();
        dateAxis16.centerRange((double) (short) 1);
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset24 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer25 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot26 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset24, waferMapRenderer25);
        org.jfree.data.general.WaferMapDataset waferMapDataset27 = null;
        waferMapPlot26.setDataset(waferMapDataset27);
        waferMapPlot26.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart31 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot26);
        jFreeChart31.setBackgroundImageAlpha(1.0f);
        jFreeChart31.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = jFreeChart31.getPadding();
        org.jfree.chart.block.LineBorder lineBorder37 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color21, stroke22, rectangleInsets36);
        dateAxis16.setTickMarkStroke(stroke22);
        dateAxis1.setTickMarkStroke(stroke22);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets36);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.resizeRange((double) 'a', (double) (short) 10);
        java.awt.Stroke stroke5 = dateAxis1.getAxisLineStroke();
        java.awt.Paint paint6 = null;
        try {
            dateAxis1.setTickLabelPaint(paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double[] doubleArray6 = new double[] { 0.4d, (-1) };
        double[] doubleArray9 = new double[] { 0.4d, (-1) };
        double[] doubleArray12 = new double[] { 0.4d, (-1) };
        double[] doubleArray15 = new double[] { 0.4d, (-1) };
        double[] doubleArray18 = new double[] { 0.4d, (-1) };
        double[] doubleArray21 = new double[] { 0.4d, (-1) };
        double[][] doubleArray22 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15, doubleArray18, doubleArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "{0}", doubleArray22);
        org.jfree.data.category.CategoryDataset categoryDataset24 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "ClassContext", doubleArray22);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset24);
        boolean boolean28 = range25.intersects((double) '4', (double) ' ');
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getURLText();
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle1.setBackgroundPaint(paint3);
        textTitle1.setHeight((double) ' ');
        org.jfree.chart.util.Size2D size2D7 = new org.jfree.chart.util.Size2D();
        boolean boolean8 = textTitle1.equals((java.lang.Object) size2D7);
        double double9 = size2D7.getWidth();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint11 = categoryPlot10.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = null;
        categoryPlot10.setFixedLegendItems(legendItemCollection12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot10.getRangeAxisForDataset((-1));
        categoryPlot10.setDomainGridlinesVisible(false);
        org.jfree.chart.ui.ProjectInfo projectInfo18 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str19 = projectInfo18.getLicenceText();
        org.jfree.chart.ui.Library[] libraryArray20 = projectInfo18.getLibraries();
        boolean boolean21 = categoryPlot10.equals((java.lang.Object) projectInfo18);
        java.lang.String str22 = projectInfo18.toString();
        boolean boolean23 = size2D7.equals((java.lang.Object) projectInfo18);
        size2D7.width = 0.14d;
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(libraryArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str22.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        int int3 = xYPlot0.getIndexOf(xYItemRenderer2);
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setRangeCrosshairValue((double) 200, false);
        boolean boolean10 = categoryPlot6.isRangeCrosshairVisible();
        java.awt.Color color12 = java.awt.Color.white;
        java.awt.Color color13 = java.awt.Color.getColor("", color12);
        categoryPlot6.setNoDataMessagePaint((java.awt.Paint) color12);
        valueMarker5.setOutlinePaint((java.awt.Paint) color12);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = valueMarker5.getLabelOffset();
        java.awt.Font font17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        valueMarker5.setLabelFont(font17);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker5);
        xYPlot0.setDomainCrosshairVisible(false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        java.awt.Stroke stroke9 = jFreeChart8.getBorderStroke();
        float float10 = jFreeChart8.getBackgroundImageAlpha();
        java.awt.RenderingHints renderingHints11 = null;
        try {
            jFreeChart8.setRenderingHints(renderingHints11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setRangeCrosshairValue((double) 200, false);
        boolean boolean6 = categoryPlot2.isRangeCrosshairVisible();
        java.awt.Color color8 = java.awt.Color.white;
        java.awt.Color color9 = java.awt.Color.getColor("", color8);
        categoryPlot2.setNoDataMessagePaint((java.awt.Paint) color8);
        valueMarker1.setOutlinePaint((java.awt.Paint) color8);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = valueMarker1.getLabelOffset();
        valueMarker1.setAlpha(0.5f);
        org.jfree.chart.text.TextAnchor textAnchor15 = valueMarker1.getLabelTextAnchor();
        java.lang.String str16 = valueMarker1.getLabel();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint18 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot17.setRangeZeroBaselinePaint(paint18);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray21 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer20 };
        xYPlot17.setRenderers(xYItemRendererArray21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot17.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo25, point2D26);
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint29 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot28.setRangeZeroBaselinePaint(paint29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray32 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer31 };
        xYPlot28.setRenderers(xYItemRendererArray32);
        xYPlot17.setRenderers(xYItemRendererArray32);
        org.jfree.chart.plot.Plot plot35 = xYPlot17.getParent();
        java.awt.Stroke stroke36 = xYPlot17.getRangeGridlineStroke();
        boolean boolean37 = xYPlot17.isDomainGridlinesVisible();
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot17);
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset41 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer42 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot43 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset41, waferMapRenderer42);
        org.jfree.data.general.WaferMapDataset waferMapDataset44 = null;
        waferMapPlot43.setDataset(waferMapDataset44);
        float float46 = waferMapPlot43.getBackgroundImageAlpha();
        valueMarker40.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot43);
        java.awt.Paint paint48 = valueMarker40.getPaint();
        try {
            boolean boolean49 = xYPlot17.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(xYItemRendererArray21);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(xYItemRendererArray32);
        org.junit.Assert.assertNull(plot35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + float46 + "' != '" + 0.5f + "'", float46 == 0.5f);
        org.junit.Assert.assertNotNull(paint48);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.UnitType unitType1 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(unitType1, (double) '4', (double) 200, (double) 1, (double) 10.0f);
        boolean boolean7 = horizontalAlignment0.equals((java.lang.Object) unitType1);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        java.awt.Shape shape13 = dateAxis11.getUpArrow();
        dateAxis11.centerRange((double) (short) 1);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.lang.Object obj18 = dateAxis17.clone();
        java.awt.Shape shape19 = dateAxis17.getUpArrow();
        dateAxis11.setUpArrow(shape19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer21);
        boolean boolean23 = horizontalAlignment0.equals((java.lang.Object) dateAxis11);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "{0}", "hi!");
        java.lang.String str6 = chartEntity5.getShapeCoords();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0,0,-2,-2,2,-2,2,-2" + "'", str6.equals("0,0,-2,-2,2,-2,2,-2"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str4 = textTitle3.getURLText();
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle3.setBackgroundPaint(paint5);
        textTitle3.setHeight((double) ' ');
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D();
        boolean boolean10 = textTitle3.equals((java.lang.Object) size2D9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle3.getMargin();
        boolean boolean12 = numberAxis0.equals((java.lang.Object) textTitle3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot0.getDomainAxisEdge();
        java.util.List list14 = xYPlot0.getAnnotations();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        int int16 = xYPlot0.indexOf(xYDataset15);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj2 = categoryAxis3D1.clone();
        boolean boolean3 = rotation0.equals((java.lang.Object) categoryAxis3D1);
        java.awt.Paint paint4 = null;
        try {
            categoryAxis3D1.setAxisLinePaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint12 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot11.setRangeZeroBaselinePaint(paint12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray15 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer14 };
        xYPlot11.setRenderers(xYItemRendererArray15);
        xYPlot0.setRenderers(xYItemRendererArray15);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape20 = dateAxis19.getDownArrow();
        java.awt.Shape shape21 = dateAxis19.getUpArrow();
        dateAxis19.centerRange((double) (short) 1);
        dateAxis19.setRange(0.0d, (double) '#');
        dateAxis19.setAutoRange(false);
        dateAxis19.setRangeWithMargins((double) 'a', (double) 100.0f);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = new org.jfree.chart.axis.ValueAxis[] { dateAxis19 };
        xYPlot0.setRangeAxes(valueAxisArray32);
        org.jfree.data.xy.XYDataset xYDataset35 = xYPlot0.getDataset((int) (short) 0);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        int int37 = xYPlot0.indexOf(xYDataset36);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(xYItemRendererArray15);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(valueAxisArray32);
        org.junit.Assert.assertNull(xYDataset35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.Color color3 = java.awt.Color.getColor("", color2);
        ringPlot0.setLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = ringPlot0.getLabelLinksVisible();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator6);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D2.setTickLabelFont((java.lang.Comparable) (short) 10, font4);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font4, paint6);
        org.jfree.chart.text.TextLine textLine8 = textBlock7.getLastLine();
        boolean boolean10 = textBlock7.equals((java.lang.Object) "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=90.0]");
        java.lang.Object obj11 = null;
        boolean boolean12 = textBlock7.equals(obj11);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(textLine8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.Color color3 = java.awt.Color.getColor("", color2);
        ringPlot0.setLabelPaint((java.awt.Paint) color3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = ringPlot0.getLabelPadding();
        ringPlot0.setSimpleLabels(false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        boolean boolean9 = dateAxis1.isNegativeArrowVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = dateAxis1.getStandardTickUnits();
        dateAxis1.setTickMarksVisible(true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(tickUnitSource10);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        boolean boolean14 = jFreeChart8.isNotify();
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart8.getLegend(200);
        org.jfree.chart.title.Title title18 = jFreeChart8.getSubtitle(0);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(legendTitle16);
        org.junit.Assert.assertNotNull(title18);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isAngleGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        polarPlot0.setDataset(xYDataset2);
        java.awt.Font font4 = polarPlot0.getAngleLabelFont();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.data.xy.XYDataset xYDataset7 = polarPlot0.getDataset();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = polarPlot0.getLegendItems();
        polarPlot0.removeCornerTextItem("WMAP_Plot");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNotNull(legendItemCollection8);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getVersion();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2.0-pre" + "'", str1.equals("1.2.0-pre"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        boolean boolean9 = dateAxis1.isNegativeArrowVisible();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font12 = textTitle11.getFont();
        dateAxis1.setLabelFont(font12);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setInfo("hi!");
        projectInfo0.setInfo("");
        org.jfree.chart.ui.ProjectInfo projectInfo5 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str6 = projectInfo5.getLicenceText();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo5);
        java.lang.String str8 = projectInfo5.getCopyright();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.data.category.CategoryDataset categoryDataset6 = categoryPlot0.getDataset(1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        try {
            categoryPlot0.setDomainAxisLocation((int) (short) 0, axisLocation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(categoryDataset6);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        xYPlot0.clearDomainMarkers(1);
        org.jfree.chart.axis.ValueAxis valueAxis16 = xYPlot0.getRangeAxis(0);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset20 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer21 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot22 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset20, waferMapRenderer21);
        org.jfree.data.general.WaferMapDataset waferMapDataset23 = null;
        waferMapPlot22.setDataset(waferMapDataset23);
        float float25 = waferMapPlot22.getBackgroundImageAlpha();
        valueMarker19.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot22);
        java.awt.Paint paint27 = valueMarker19.getPaint();
        java.awt.Paint paint28 = valueMarker19.getLabelPaint();
        org.jfree.chart.util.Layer layer29 = null;
        try {
            xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) valueMarker19, layer29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getURLText();
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle1.setBackgroundPaint(paint3);
        textTitle1.setHeight((double) ' ');
        org.jfree.chart.util.Size2D size2D7 = new org.jfree.chart.util.Size2D();
        boolean boolean8 = textTitle1.equals((java.lang.Object) size2D7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = null;
        try {
            textTitle1.setTextAlignment(horizontalAlignment9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 1, 0);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getDomainAxisEdge((int) (byte) 10);
        categoryPlot0.configureDomainAxes();
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot0.getRenderer(0);
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot0.getDomainAxisForDataset((int) (byte) 0);
        xYPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray18 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer17 };
        xYPlot0.setRenderers(xYItemRendererArray18);
        java.awt.Stroke stroke20 = xYPlot0.getRangeCrosshairStroke();
        org.jfree.chart.plot.Plot plot21 = xYPlot0.getRootPlot();
        xYPlot0.clearRangeMarkers();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(xYItemRendererArray18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(plot21);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.Color color5 = java.awt.Color.getColor("", color4);
        int int6 = color4.getRGB();
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        xYPlot0.setRangeCrosshairValue((double) '4', true);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.lang.String str12 = rectangleInsets11.toString();
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray14 = null;
        float[] floatArray15 = color13.getRGBComponents(floatArray14);
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder(rectangleInsets11, (java.awt.Paint) color13);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color13);
        double double18 = xYPlot0.getDomainCrosshairValue();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str12.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.awt.Color color0 = java.awt.Color.WHITE;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setUpperMargin((double) 100L);
        dateAxis1.setRange((double) 2.0f, (double) (short) 100);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getMaximumLabelWidth();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot3D0.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.14d + "'", double1 == 0.14d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 10L, (double) 100.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot5.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomDomainAxes(8.0d, plotRenderingInfo9, point2D10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot5);
        java.awt.Font font13 = legendTitle12.getItemFont();
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset17 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer18 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot19 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset17, waferMapRenderer18);
        org.jfree.data.general.WaferMapDataset waferMapDataset20 = null;
        waferMapPlot19.setDataset(waferMapDataset20);
        waferMapPlot19.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot19);
        jFreeChart24.setBackgroundImageAlpha(1.0f);
        jFreeChart24.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = jFreeChart24.getPadding();
        org.jfree.chart.block.LineBorder lineBorder30 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color14, stroke15, rectangleInsets29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = lineBorder30.getInsets();
        columnArrangement4.add((org.jfree.chart.block.Block) legendTitle12, (java.lang.Object) rectangleInsets31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = legendTitle12.getLegendItemGraphicEdge();
        legendTitle12.setWidth((double) 0L);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape40 = dateAxis39.getDownArrow();
        java.awt.Shape shape41 = dateAxis39.getUpArrow();
        dateAxis39.centerRange((double) (short) 1);
        dateAxis39.setRange(0.0d, (double) '#');
        org.jfree.data.Range range49 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis39.setRange(range49, false, false);
        org.jfree.data.Range range54 = org.jfree.data.Range.shift(range49, 8.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = new org.jfree.chart.block.RectangleConstraint(10.0d, range54);
        org.jfree.chart.util.Size2D size2D56 = legendTitle12.arrange(graphics2D36, rectangleConstraint55);
        java.lang.String str57 = rectangleConstraint55.toString();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertNotNull(size2D56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]" + "'", str57.equals("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D1.setTickLabelFont((java.lang.Comparable) (short) 10, font3);
        int int5 = categoryAxis3D1.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke6 = categoryAxis3D1.getAxisLineStroke();
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        double double8 = piePlot3D7.getMaximumLabelWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean10 = piePlot3D7.equals((java.lang.Object) rectangleAnchor9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        piePlot3D7.setLabelPadding(rectangleInsets11);
        categoryAxis3D1.setLabelInsets(rectangleInsets11);
        double double15 = rectangleInsets11.extendHeight((double) 100L);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.14d + "'", double8 == 0.14d);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 108.0d + "'", double15 == 108.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        xYPlot0.zoom((double) (short) -1);
        java.util.List list15 = xYPlot0.getAnnotations();
        java.util.Collection collection16 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list15);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(collection16);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        boolean boolean9 = dateAxis1.isNegativeArrowVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = dateAxis1.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset15 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer16 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot17 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset15, waferMapRenderer16);
        org.jfree.data.general.WaferMapDataset waferMapDataset18 = null;
        waferMapPlot17.setDataset(waferMapDataset18);
        float float20 = waferMapPlot17.getBackgroundImageAlpha();
        valueMarker14.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot17);
        java.awt.Font font22 = valueMarker14.getLabelFont();
        dateAxis12.setTickLabelFont(font22);
        org.jfree.data.Range range26 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis12.setRangeWithMargins(range26);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition28 = dateAxis12.getTickMarkPosition();
        dateAxis1.setTickMarkPosition(dateTickMarkPosition28);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(tickUnitSource10);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.5f + "'", float20 == 0.5f);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(dateTickMarkPosition28);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isAngleGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        polarPlot0.setDataset(xYDataset2);
        java.awt.Font font4 = polarPlot0.getAngleLabelFont();
        java.awt.Font font5 = polarPlot0.getAngleLabelFont();
        java.lang.Object obj6 = polarPlot0.clone();
        java.awt.Paint paint7 = polarPlot0.getAngleGridlinePaint();
        java.awt.Stroke stroke8 = polarPlot0.getRadiusGridlineStroke();
        boolean boolean9 = polarPlot0.isAngleLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str4 = categoryAxis3D3.getLabelURL();
        double double5 = categoryAxis3D3.getCategoryMargin();
        categoryAxis3D3.setLabelURL("RectangleEdge.TOP");
        double double8 = categoryAxis3D3.getLowerMargin();
        boolean boolean9 = objectList0.equals((java.lang.Object) double8);
        objectList0.clear();
        java.lang.Object obj11 = null;
        boolean boolean12 = objectList0.equals(obj11);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.Object obj1 = ringPlot0.clone();
        double double2 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setRangeCrosshairValue((double) 200, false);
        boolean boolean8 = categoryPlot4.isRangeCrosshairVisible();
        java.awt.Color color10 = java.awt.Color.white;
        java.awt.Color color11 = java.awt.Color.getColor("", color10);
        categoryPlot4.setNoDataMessagePaint((java.awt.Paint) color10);
        piePlot3D3.setLabelLinkPaint((java.awt.Paint) color10);
        double double14 = piePlot3D3.getDepthFactor();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date18 = dateAxis16.calculateHighestVisibleTickValue(dateTickUnit17);
        java.awt.Paint paint19 = piePlot3D3.getSectionPaint((java.lang.Comparable) date18);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint21 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot20.setRangeZeroBaselinePaint(paint21);
        java.awt.Color color24 = java.awt.Color.white;
        java.awt.Color color25 = java.awt.Color.getColor("", color24);
        int int26 = color24.getRGB();
        xYPlot20.setRangeGridlinePaint((java.awt.Paint) color24);
        java.awt.Stroke stroke28 = xYPlot20.getDomainCrosshairStroke();
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) date18, stroke28);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.12d + "'", double14 == 0.12d);
        org.junit.Assert.assertNotNull(dateTickUnit17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot0.getDomainAxisEdge();
        java.util.List list14 = xYPlot0.getAnnotations();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color22 = java.awt.Color.ORANGE;
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset26 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer27 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot28 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset26, waferMapRenderer27);
        org.jfree.data.general.WaferMapDataset waferMapDataset29 = null;
        waferMapPlot28.setDataset(waferMapDataset29);
        waferMapPlot28.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot28);
        jFreeChart33.setBackgroundImageAlpha(1.0f);
        jFreeChart33.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = jFreeChart33.getPadding();
        org.jfree.chart.block.LineBorder lineBorder39 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color23, stroke24, rectangleInsets38);
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color22, stroke24);
        polarPlot20.setRadiusGridlineStroke(stroke24);
        polarPlot20.removeCornerTextItem("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.plot.RingPlot ringPlot44 = new org.jfree.chart.plot.RingPlot();
        ringPlot44.setIgnoreZeroValues(true);
        java.awt.Stroke stroke47 = ringPlot44.getLabelLinkStroke();
        polarPlot20.setOutlineStroke(stroke47);
        polarPlot20.setAngleLabelsVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        org.jfree.chart.plot.PolarPlot polarPlot53 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean54 = polarPlot53.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint58 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot57.setRangeZeroBaselinePaint(paint58);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray61 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer60 };
        xYPlot57.setRenderers(xYItemRendererArray61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        xYPlot57.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo65, point2D66);
        org.jfree.chart.axis.AxisSpace axisSpace68 = null;
        xYPlot57.setFixedRangeAxisSpace(axisSpace68);
        java.awt.Stroke stroke70 = xYPlot57.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D71 = xYPlot57.getQuadrantOrigin();
        polarPlot53.zoomDomainAxes(1.0E-8d, plotRenderingInfo56, point2D71);
        polarPlot20.zoomDomainAxes((double) 100.0f, plotRenderingInfo52, point2D71);
        xYPlot0.zoomDomainAxes(10.0d, (double) 0, plotRenderingInfo19, point2D71);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(xYItemRendererArray61);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(point2D71);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        xYPlot0.clearDomainMarkers(1);
        org.jfree.chart.axis.ValueAxis valueAxis16 = xYPlot0.getRangeAxis(0);
        java.awt.geom.Point2D point2D17 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot0.getDomainMarkers(layer18);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNotNull(point2D17);
        org.junit.Assert.assertNull(collection19);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        boolean boolean14 = jFreeChart8.isNotify();
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart8.getLegend(200);
        jFreeChart8.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.data.general.WaferMapDataset waferMapDataset19 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer20 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot21 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset19, waferMapRenderer20);
        org.jfree.data.general.WaferMapDataset waferMapDataset22 = null;
        waferMapPlot21.setDataset(waferMapDataset22);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent24 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) waferMapPlot21);
        org.jfree.chart.JFreeChart jFreeChart25 = plotChangeEvent24.getChart();
        jFreeChart8.plotChanged(plotChangeEvent24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = null;
        java.awt.image.BufferedImage bufferedImage32 = jFreeChart8.createBufferedImage((int) (byte) 1, (int) (short) 100, (double) (short) 0, (double) (byte) 10, chartRenderingInfo31);
        java.awt.image.BufferedImage bufferedImage35 = jFreeChart8.createBufferedImage((int) 'a', (int) (byte) 10);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = null;
        try {
            jFreeChart8.handleClick(2, (-16711681), chartRenderingInfo38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(legendTitle16);
        org.junit.Assert.assertNull(jFreeChart25);
        org.junit.Assert.assertNotNull(bufferedImage32);
        org.junit.Assert.assertNotNull(bufferedImage35);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Range[100.0,100.0]", graphics2D1, 0.0f, (float) ' ', 0.0d, (float) 1, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Color color6 = java.awt.Color.white;
        java.awt.Color color7 = java.awt.Color.getColor("", color6);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot0.getDomainAxis();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(categoryAxis9);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "{0}", "hi!");
        java.lang.String str6 = chartEntity5.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ChartEntity: tooltip = {0}" + "'", str6.equals("ChartEntity: tooltip = {0}"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer6 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset5, waferMapRenderer6);
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        waferMapPlot7.setDataset(waferMapDataset8);
        float float10 = waferMapPlot7.getBackgroundImageAlpha();
        valueMarker4.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot7);
        java.awt.Font font12 = valueMarker4.getLabelFont();
        dateAxis2.setTickLabelFont(font12);
        org.jfree.data.Range range16 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis2.setRangeWithMargins(range16);
        double double18 = range16.getCentralValue();
        java.lang.String str19 = range16.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint(1.0d, 90.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType23 = rectangleConstraint22.getWidthConstraintType();
        org.jfree.chart.util.UnitType unitType24 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean25 = lengthConstraintType23.equals((java.lang.Object) unitType24);
        java.lang.String str26 = lengthConstraintType23.toString();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset32 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer33 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot34 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset32, waferMapRenderer33);
        org.jfree.data.general.WaferMapDataset waferMapDataset35 = null;
        waferMapPlot34.setDataset(waferMapDataset35);
        float float37 = waferMapPlot34.getBackgroundImageAlpha();
        valueMarker31.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot34);
        java.awt.Font font39 = valueMarker31.getLabelFont();
        dateAxis29.setTickLabelFont(font39);
        org.jfree.data.Range range43 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis29.setRangeWithMargins(range43);
        double double45 = range43.getCentralValue();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType46 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint47 = new org.jfree.chart.block.RectangleConstraint((double) 500, range16, lengthConstraintType23, 1.0d, range43, lengthConstraintType46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'heightType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18 == 100.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Range[100.0,100.0]" + "'", str19.equals("Range[100.0,100.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType23);
        org.junit.Assert.assertNotNull(unitType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "LengthConstraintType.FIXED" + "'", str26.equals("LengthConstraintType.FIXED"));
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 0.5f + "'", float37 == 0.5f);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 100.0d + "'", double45 == 100.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        int int3 = java.awt.Color.HSBtoRGB((float) 'a', (float) (short) 10, 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint12 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot11.setRangeZeroBaselinePaint(paint12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray15 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer14 };
        xYPlot11.setRenderers(xYItemRendererArray15);
        xYPlot0.setRenderers(xYItemRendererArray15);
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.chart.util.Layer layer20 = null;
        try {
            boolean boolean21 = xYPlot0.removeDomainMarker((int) (short) 0, marker19, layer20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(xYItemRendererArray15);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        java.awt.Shape shape4 = dateAxis2.getUpArrow();
        dateAxis2.centerRange((double) (short) 1);
        boolean boolean7 = dateAxis2.isPositiveArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape10 = dateAxis9.getDownArrow();
        java.awt.Shape shape11 = dateAxis9.getUpArrow();
        dateAxis9.centerRange((double) (short) 1);
        dateAxis9.setRange(0.0d, (double) '#');
        dateAxis9.setAutoRange(false);
        dateAxis9.setRangeWithMargins((double) 'a', (double) 100.0f);
        java.awt.Font font22 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        dateAxis9.setTickLabelFont(font22);
        dateAxis2.setLabelFont(font22);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape27 = dateAxis26.getDownArrow();
        java.awt.Shape shape28 = dateAxis26.getUpArrow();
        dateAxis26.centerRange((double) (short) 1);
        dateAxis26.setRange(0.0d, (double) '#');
        boolean boolean34 = dateAxis26.isNegativeArrowVisible();
        java.awt.Paint paint35 = dateAxis26.getTickMarkPaint();
        org.jfree.chart.text.TextFragment textFragment37 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font22, paint35, 10.0f);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        boolean boolean14 = jFreeChart8.isNotify();
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart8.getLegend(200);
        jFreeChart8.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.data.general.WaferMapDataset waferMapDataset19 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer20 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot21 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset19, waferMapRenderer20);
        org.jfree.data.general.WaferMapDataset waferMapDataset22 = null;
        waferMapPlot21.setDataset(waferMapDataset22);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent24 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) waferMapPlot21);
        org.jfree.chart.JFreeChart jFreeChart25 = plotChangeEvent24.getChart();
        jFreeChart8.plotChanged(plotChangeEvent24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = null;
        java.awt.image.BufferedImage bufferedImage32 = jFreeChart8.createBufferedImage((int) (byte) 1, (int) (short) 100, (double) (short) 0, (double) (byte) 10, chartRenderingInfo31);
        java.awt.image.BufferedImage bufferedImage35 = jFreeChart8.createBufferedImage((int) 'a', (int) (byte) 10);
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str38 = textTitle37.getURLText();
        java.awt.Paint paint39 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle37.setBackgroundPaint(paint39);
        java.lang.String str41 = textTitle37.getURLText();
        jFreeChart8.addSubtitle((org.jfree.chart.title.Title) textTitle37);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(legendTitle16);
        org.junit.Assert.assertNull(jFreeChart25);
        org.junit.Assert.assertNotNull(bufferedImage32);
        org.junit.Assert.assertNotNull(bufferedImage35);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNull(str41);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getNoDataMessagePaint();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot3.setRangeCrosshairStroke(stroke5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot3.getDomainAxisLocation();
        xYPlot0.setRangeAxisLocation(axisLocation7, false);
        xYPlot0.setOutlineVisible(false);
        boolean boolean12 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        int int14 = xYPlot0.getIndexOf(xYItemRenderer13);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxisForDataset((-1));
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(valueAxis5);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        piePlot3D1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        double double4 = piePlot3D1.getLabelLinkMargin();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        boolean boolean6 = dateAxis1.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis1.getTickLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = null;
        try {
            java.util.Date date10 = dateAxis1.calculateHighestVisibleTickValue(dateTickUnit9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.Color color3 = java.awt.Color.getColor("", color2);
        ringPlot0.setLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = ringPlot0.getLabelLinksVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint7 = categoryPlot6.getNoDataMessagePaint();
        categoryPlot6.setAnchorValue(0.0d);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str12 = textTitle11.getURLText();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle11.setBackgroundPaint(paint13);
        categoryPlot6.setDomainGridlinePaint(paint13);
        ringPlot0.setLabelBackgroundPaint(paint13);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle18.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = textTitle18.getPosition();
        java.lang.String str21 = rectangleEdge20.toString();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str24 = categoryAxis3D23.getLabelURL();
        double double25 = categoryAxis3D23.getCategoryMargin();
        categoryAxis3D23.setLabelURL("RectangleEdge.TOP");
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis3D23.setTickMarkStroke(stroke28);
        boolean boolean30 = rectangleEdge20.equals((java.lang.Object) stroke28);
        ringPlot0.setLabelOutlineStroke(stroke28);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "RectangleEdge.TOP" + "'", str21.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.2d + "'", double25 == 0.2d);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        org.jfree.data.general.WaferMapDataset waferMapDataset7 = null;
        waferMapPlot6.setDataset(waferMapDataset7);
        float float9 = waferMapPlot6.getBackgroundImageAlpha();
        valueMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot6);
        java.awt.Font font11 = valueMarker3.getLabelFont();
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        boolean boolean14 = textAnchor12.equals((java.lang.Object) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        valueMarker3.setLabelTextAnchor(textAnchor12);
        valueMarker1.setLabelTextAnchor(textAnchor12);
        java.awt.Font font17 = valueMarker1.getLabelFont();
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5f + "'", float9 == 0.5f);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        double[] doubleArray6 = new double[] { 0.4d, (-1) };
        double[] doubleArray9 = new double[] { 0.4d, (-1) };
        double[] doubleArray12 = new double[] { 0.4d, (-1) };
        double[] doubleArray15 = new double[] { 0.4d, (-1) };
        double[] doubleArray18 = new double[] { 0.4d, (-1) };
        double[] doubleArray21 = new double[] { 0.4d, (-1) };
        double[][] doubleArray22 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15, doubleArray18, doubleArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "{0}", doubleArray22);
        org.jfree.data.category.CategoryDataset categoryDataset24 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "ClassContext", doubleArray22);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset24);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Rotation.CLOCKWISE");
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        java.awt.Shape shape7 = dateAxis5.getUpArrow();
        dateAxis5.centerRange((double) (short) 1);
        dateAxis5.setRange(0.0d, (double) '#');
        dateAxis5.setAutoRange(false);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.util.Date date16 = dateAxis5.getMinimumDate();
        java.awt.Paint paint17 = dateAxis5.getAxisLinePaint();
        org.jfree.data.Range range20 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis5.setRangeWithMargins(range20);
        boolean boolean24 = range20.intersects((double) (byte) 1, 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.Color color3 = java.awt.Color.getColor("", color2);
        ringPlot0.setLabelPaint((java.awt.Paint) color3);
        ringPlot0.setOuterSeparatorExtension((double) (byte) 0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Color color6 = java.awt.Color.white;
        java.awt.Color color7 = java.awt.Color.getColor("", color6);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint13 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot12.setRangeZeroBaselinePaint(paint13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray16 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer15 };
        xYPlot12.setRenderers(xYItemRendererArray16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot12.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo20, point2D21);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = xYPlot12.getDatasetRenderingOrder();
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder23);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(xYItemRendererArray16);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0, (double) 100.0f);
        double double3 = size2D2.width;
        size2D2.setWidth((-1.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.Color color3 = java.awt.Color.getColor("", color2);
        ringPlot0.setLabelPaint((java.awt.Paint) color3);
        org.jfree.data.general.PieDataset pieDataset5 = ringPlot0.getDataset();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D8.setTickLabelFont((java.lang.Comparable) (short) 10, font10);
        java.awt.Paint paint12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font10, paint12);
        boolean boolean14 = ringPlot0.equals((java.lang.Object) font10);
        double double15 = ringPlot0.getInteriorGap();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint17 = categoryPlot16.getNoDataMessagePaint();
        java.awt.Color color18 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint21 = textTitle20.getPaint();
        java.awt.Color color22 = java.awt.Color.red;
        java.awt.Color color23 = java.awt.Color.red;
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] { color18, paint21, color22, color23, color24 };
        java.awt.Paint[] paintArray26 = null;
        java.awt.Stroke stroke27 = null;
        java.awt.Stroke[] strokeArray28 = new java.awt.Stroke[] { stroke27 };
        java.awt.Stroke[] strokeArray29 = new java.awt.Stroke[] {};
        java.awt.Shape shape30 = null;
        java.awt.Shape[] shapeArray31 = new java.awt.Shape[] { shape30 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier32 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray25, paintArray26, strokeArray28, strokeArray29, shapeArray31);
        java.awt.Stroke stroke33 = defaultDrawingSupplier32.getNextStroke();
        java.awt.Paint paint34 = defaultDrawingSupplier32.getNextFillPaint();
        java.awt.Paint paint35 = defaultDrawingSupplier32.getNextPaint();
        categoryPlot16.setRangeGridlinePaint(paint35);
        ringPlot0.setBaseSectionOutlinePaint(paint35);
        ringPlot0.setOuterSeparatorExtension((double) (short) 10);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(pieDataset5);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08d + "'", double15 == 0.08d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(strokeArray28);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(shapeArray31);
        org.junit.Assert.assertNull(stroke33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint13 = categoryPlot12.getNoDataMessagePaint();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot12.setRangeCrosshairStroke(stroke14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot12.getDomainAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation16, plotOrientation17);
        xYPlot0.setRangeAxisLocation(axisLocation16, false);
        org.jfree.chart.block.ColumnArrangement columnArrangement21 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean22 = xYPlot0.equals((java.lang.Object) columnArrangement21);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        boolean boolean14 = jFreeChart8.isNotify();
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart8.getLegend(200);
        jFreeChart8.setBackgroundImageAlignment((int) (byte) -1);
        jFreeChart8.setTextAntiAlias(false);
        boolean boolean21 = jFreeChart8.getAntiAlias();
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(legendTitle16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection4);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot0.getOrientation();
        try {
            categoryPlot0.zoom(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation6);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource9);
        java.lang.Object obj11 = dateAxis1.clone();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint13 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot12.setRangeZeroBaselinePaint(paint13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray16 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer15 };
        xYPlot12.setRenderers(xYItemRendererArray16);
        java.awt.Paint paint18 = xYPlot12.getDomainTickBandPaint();
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset22 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer23 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot24 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset22, waferMapRenderer23);
        org.jfree.data.general.WaferMapDataset waferMapDataset25 = null;
        waferMapPlot24.setDataset(waferMapDataset25);
        waferMapPlot24.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot24);
        jFreeChart29.setBackgroundImageAlpha(1.0f);
        jFreeChart29.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = jFreeChart29.getPadding();
        org.jfree.chart.block.LineBorder lineBorder35 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color19, stroke20, rectangleInsets34);
        xYPlot12.setDomainZeroBaselineStroke(stroke20);
        dateAxis1.setTickMarkStroke(stroke20);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(xYItemRendererArray16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets34);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection4);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot0.getOrientation();
        int int7 = categoryPlot0.getWeight();
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = textTitle1.getPosition();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer7 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6, waferMapRenderer7);
        org.jfree.data.general.WaferMapDataset waferMapDataset9 = null;
        waferMapPlot8.setDataset(waferMapDataset9);
        float float11 = waferMapPlot8.getBackgroundImageAlpha();
        valueMarker5.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot8);
        java.awt.Paint paint13 = valueMarker5.getPaint();
        java.awt.Paint paint14 = valueMarker5.getLabelPaint();
        boolean boolean15 = textTitle1.equals((java.lang.Object) valueMarker5);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.Color color3 = java.awt.Color.getColor("", color2);
        ringPlot0.setLabelPaint((java.awt.Paint) color3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = ringPlot0.getLabelPadding();
        double double7 = rectangleInsets5.calculateRightInset(0.05d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D2.setTickLabelFont((java.lang.Comparable) (short) 10, font4);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font4, paint6);
        org.jfree.chart.text.TextLine textLine8 = textBlock7.getLastLine();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = textBlock7.getLineAlignment();
        java.lang.String str10 = horizontalAlignment9.toString();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(textLine8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "HorizontalAlignment.CENTER" + "'", str10.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        java.lang.String str2 = numberAxis0.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = numberAxis0.getMarkerBand();
        java.awt.Paint paint4 = numberAxis0.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(markerAxisBand3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str2 = categoryAxis3D1.getLabelURL();
        double double3 = categoryAxis3D1.getCategoryMargin();
        categoryAxis3D1.setLabelURL("RectangleEdge.TOP");
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis3D1.setTickMarkStroke(stroke6);
        java.awt.Font font9 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) (short) 100);
        java.awt.Paint paint11 = null;
        categoryAxis3D1.setTickLabelPaint((java.lang.Comparable) (-1L), paint11);
        java.awt.Paint paint13 = categoryAxis3D1.getTickMarkPaint();
        categoryAxis3D1.setFixedDimension((double) (-1L));
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio((float) (short) 0);
        int int18 = categoryAxis3D1.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        org.jfree.data.Range range11 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis1.setRange(range11, false, false);
        org.jfree.data.Range range16 = org.jfree.data.Range.shift(range11, 8.0d);
        org.jfree.data.Range range18 = org.jfree.data.Range.shift(range16, 0.0d);
        org.jfree.data.Range range21 = org.jfree.data.Range.expand(range18, (double) '#', (double) 10L);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range21);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace2 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        org.junit.Assert.assertNull(axisSpace2);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        boolean boolean2 = blockContainer0.equals((java.lang.Object) (-9.0d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = piePlotState1.getExplodedPieArea();
        piePlotState1.setPassesRequired(2);
        double double5 = piePlotState1.getLatestAngle();
        org.junit.Assert.assertNull(rectangle2D2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        ringPlot0.setShadowXOffset((double) (-1.0f));
        org.jfree.chart.util.Rotation rotation4 = ringPlot0.getDirection();
        ringPlot0.setInnerSeparatorExtension((double) 1L);
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer9 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot10 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset8, waferMapRenderer9);
        org.jfree.data.general.WaferMapDataset waferMapDataset11 = null;
        waferMapPlot10.setDataset(waferMapDataset11);
        waferMapPlot10.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot10);
        jFreeChart15.setBackgroundImageAlpha(1.0f);
        jFreeChart15.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = jFreeChart15.getPadding();
        boolean boolean21 = jFreeChart15.isNotify();
        org.jfree.chart.title.LegendTitle legendTitle23 = jFreeChart15.getLegend(200);
        org.jfree.chart.title.LegendTitle legendTitle25 = jFreeChart15.getLegend((int) 'a');
        ringPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart15);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(legendTitle23);
        org.junit.Assert.assertNull(legendTitle25);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.Color color3 = java.awt.Color.getColor("", color2);
        ringPlot0.setLabelPaint((java.awt.Paint) color3);
        org.jfree.data.general.PieDataset pieDataset5 = ringPlot0.getDataset();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D8.setTickLabelFont((java.lang.Comparable) (short) 10, font10);
        java.awt.Paint paint12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font10, paint12);
        boolean boolean14 = ringPlot0.equals((java.lang.Object) font10);
        double double15 = ringPlot0.getInteriorGap();
        ringPlot0.setCircular(false);
        ringPlot0.setMaximumLabelWidth((double) (-1L));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(pieDataset5);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08d + "'", double15 == 0.08d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D2.setTickLabelFont((java.lang.Comparable) (short) 10, font4);
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("hi!", font4);
        float float7 = textFragment6.getBaselineOffset();
        java.awt.Color color9 = java.awt.Color.ORANGE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer14 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot15 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset13, waferMapRenderer14);
        org.jfree.data.general.WaferMapDataset waferMapDataset16 = null;
        waferMapPlot15.setDataset(waferMapDataset16);
        waferMapPlot15.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot15);
        jFreeChart20.setBackgroundImageAlpha(1.0f);
        jFreeChart20.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = jFreeChart20.getPadding();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color10, stroke11, rectangleInsets25);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color9, stroke11);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) valueMarker27);
        boolean boolean29 = textFragment6.equals((java.lang.Object) valueMarker27);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint31 = categoryPlot30.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation32 = categoryPlot30.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        categoryPlot30.zoomDomainAxes(8.0d, plotRenderingInfo34, point2D35);
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot30);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = org.jfree.chart.util.RectangleAnchor.LEFT;
        legendTitle37.setLegendItemGraphicLocation(rectangleAnchor38);
        valueMarker27.setLabelAnchor(rectangleAnchor38);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getURLText();
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle1.setBackgroundPaint(paint3);
        textTitle1.setHeight((double) ' ');
        org.jfree.chart.util.Size2D size2D7 = new org.jfree.chart.util.Size2D();
        boolean boolean8 = textTitle1.equals((java.lang.Object) size2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = textTitle1.getMargin();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = null;
        try {
            org.jfree.chart.util.Size2D size2D12 = textTitle1.arrange(graphics2D10, rectangleConstraint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint12 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot11.setRangeZeroBaselinePaint(paint12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray15 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer14 };
        xYPlot11.setRenderers(xYItemRendererArray15);
        xYPlot0.setRenderers(xYItemRendererArray15);
        org.jfree.chart.plot.Plot plot18 = xYPlot0.getParent();
        java.awt.Stroke stroke19 = xYPlot0.getRangeGridlineStroke();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke20);
        java.awt.Color color22 = java.awt.Color.darkGray;
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color22);
        java.awt.color.ColorSpace colorSpace24 = null;
        java.awt.Color color25 = java.awt.Color.gray;
        java.awt.Color color26 = java.awt.Color.green;
        java.awt.Color color27 = java.awt.Color.red;
        float[] floatArray33 = new float[] { '4', (-1L), 10L, 10.0f, 0 };
        float[] floatArray34 = color27.getComponents(floatArray33);
        float[] floatArray35 = color26.getColorComponents(floatArray33);
        float[] floatArray36 = color25.getComponents(floatArray35);
        try {
            float[] floatArray37 = color22.getComponents(colorSpace24, floatArray35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(xYItemRendererArray15);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint14 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot13.setRangeZeroBaselinePaint(paint14);
        java.awt.Color color16 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint19 = textTitle18.getPaint();
        java.awt.Color color20 = java.awt.Color.red;
        java.awt.Color color21 = java.awt.Color.red;
        java.awt.Color color22 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray23 = new java.awt.Paint[] { color16, paint19, color20, color21, color22 };
        java.awt.Paint[] paintArray24 = null;
        java.awt.Stroke stroke25 = null;
        java.awt.Stroke[] strokeArray26 = new java.awt.Stroke[] { stroke25 };
        java.awt.Stroke[] strokeArray27 = new java.awt.Stroke[] {};
        java.awt.Shape shape28 = null;
        java.awt.Shape[] shapeArray29 = new java.awt.Shape[] { shape28 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray23, paintArray24, strokeArray26, strokeArray27, shapeArray29);
        java.awt.Stroke stroke31 = defaultDrawingSupplier30.getNextStroke();
        java.awt.Paint paint32 = defaultDrawingSupplier30.getNextFillPaint();
        java.awt.Paint paint33 = defaultDrawingSupplier30.getNextPaint();
        xYPlot13.setRangeGridlinePaint(paint33);
        org.jfree.chart.plot.PiePlot3D piePlot3D35 = new org.jfree.chart.plot.PiePlot3D();
        double double36 = piePlot3D35.getMaximumLabelWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean38 = piePlot3D35.equals((java.lang.Object) rectangleAnchor37);
        double double39 = piePlot3D35.getLabelLinkMargin();
        java.awt.Stroke stroke40 = piePlot3D35.getLabelLinkStroke();
        xYPlot13.setRangeCrosshairStroke(stroke40);
        jFreeChart8.setBorderStroke(stroke40);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(strokeArray26);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNotNull(shapeArray29);
        org.junit.Assert.assertNull(stroke31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.14d + "'", double36 == 0.14d);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.025d + "'", double39 == 0.025d);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.Color color3 = java.awt.Color.getColor("", color2);
        ringPlot0.setLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = ringPlot0.getLabelLinksVisible();
        double double6 = ringPlot0.getMaximumLabelWidth();
        double double7 = ringPlot0.getStartAngle();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.14d + "'", double6 == 0.14d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 90.0d + "'", double7 == 90.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.Object obj1 = ringPlot0.clone();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint5 = ringPlot4.getLabelBackgroundPaint();
        ringPlot4.setShadowXOffset((double) (-1.0f));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.PiePlotState piePlotState10 = ringPlot0.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.PiePlot) ringPlot4, (java.lang.Integer) 200, plotRenderingInfo9);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis13.resizeRange((double) 'a', (double) (short) 10);
        java.awt.Stroke stroke17 = dateAxis13.getAxisLineStroke();
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) "", stroke17);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(piePlotState10);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceText();
        java.lang.String str2 = projectInfo0.getInfo();
        org.jfree.chart.ui.ProjectInfo projectInfo3 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo3.setInfo("hi!");
        projectInfo3.setInfo("");
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str9 = projectInfo8.getLicenceText();
        projectInfo3.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo8);
        java.lang.String str11 = projectInfo3.getInfo();
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo3);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        boolean boolean2 = ringPlot0.isCircular();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setRangeCrosshairValue((double) 200, false);
        boolean boolean9 = categoryPlot5.isRangeCrosshairVisible();
        java.awt.Color color11 = java.awt.Color.white;
        java.awt.Color color12 = java.awt.Color.getColor("", color11);
        categoryPlot5.setNoDataMessagePaint((java.awt.Paint) color11);
        valueMarker4.setOutlinePaint((java.awt.Paint) color11);
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color11);
        double double16 = ringPlot0.getInteriorGap();
        float float17 = ringPlot0.getBackgroundAlpha();
        ringPlot0.setShadowYOffset(108.0d);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.08d + "'", double16 == 0.08d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        dateAxis1.setAutoRange(false);
        dateAxis1.setAxisLineVisible(false);
        dateAxis1.centerRange((double) 100.0f);
        dateAxis1.setRange(0.08d, 0.14d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        double double7 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = xYPlot0.getRangeAxisEdge(1);
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot0.getRangeAxis(0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNull(valueAxis11);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(8.0d, plotRenderingInfo4, point2D5);
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        java.awt.Font font8 = legendTitle7.getItemFont();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        xYPlot9.clearDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset11 = xYPlot9.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = xYPlot9.getAxisOffset();
        legendTitle7.setLegendItemGraphicPadding(rectangleInsets12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = legendTitle7.getLegendItemGraphicLocation();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(xYDataset11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        java.awt.Shape shape4 = dateAxis2.getUpArrow();
        dateAxis2.centerRange((double) (short) 1);
        dateAxis2.setRange(0.0d, (double) '#');
        org.jfree.data.Range range12 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis2.setRange(range12, false, false);
        org.jfree.data.Range range17 = org.jfree.data.Range.shift(range12, 8.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(10.0d, range17);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint18.toFixedWidth(0.12d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = rectangleConstraint18.toFixedHeight((double) (short) 1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(rectangleConstraint20);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke2);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer(categoryItemRenderer5, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getNoDataMessagePaint();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot9.setRangeCrosshairStroke(stroke11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot9.getDomainAxisLocation();
        categoryPlot0.setRangeAxisLocation(500, axisLocation13, true);
        categoryPlot0.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = piePlotState1.getExplodedPieArea();
        piePlotState1.setPassesRequired(2);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        piePlotState1.setLinkArea(rectangle2D5);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlotState1.setExplodedPieArea(rectangle2D7);
        org.junit.Assert.assertNull(rectangle2D2);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.junit.Assert.assertNotNull(dateRange0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint13 = categoryPlot12.getNoDataMessagePaint();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot12.setRangeCrosshairStroke(stroke14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot12.getDomainAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation16, plotOrientation17);
        xYPlot0.setRangeAxisLocation(axisLocation16, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint22 = categoryPlot21.getNoDataMessagePaint();
        java.awt.Color color23 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint26 = textTitle25.getPaint();
        java.awt.Color color27 = java.awt.Color.red;
        java.awt.Color color28 = java.awt.Color.red;
        java.awt.Color color29 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray30 = new java.awt.Paint[] { color23, paint26, color27, color28, color29 };
        java.awt.Paint[] paintArray31 = null;
        java.awt.Stroke stroke32 = null;
        java.awt.Stroke[] strokeArray33 = new java.awt.Stroke[] { stroke32 };
        java.awt.Stroke[] strokeArray34 = new java.awt.Stroke[] {};
        java.awt.Shape shape35 = null;
        java.awt.Shape[] shapeArray36 = new java.awt.Shape[] { shape35 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier37 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray30, paintArray31, strokeArray33, strokeArray34, shapeArray36);
        java.awt.Stroke stroke38 = defaultDrawingSupplier37.getNextStroke();
        java.awt.Paint paint39 = defaultDrawingSupplier37.getNextFillPaint();
        java.awt.Paint paint40 = defaultDrawingSupplier37.getNextPaint();
        categoryPlot21.setRangeGridlinePaint(paint40);
        java.util.List list42 = categoryPlot21.getCategories();
        java.awt.Stroke stroke43 = categoryPlot21.getDomainGridlineStroke();
        xYPlot0.setDomainCrosshairStroke(stroke43);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paintArray30);
        org.junit.Assert.assertNotNull(strokeArray33);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(shapeArray36);
        org.junit.Assert.assertNull(stroke38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(list42);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint2 = categoryPlot1.getNoDataMessagePaint();
        java.awt.Color color3 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint6 = textTitle5.getPaint();
        java.awt.Color color7 = java.awt.Color.red;
        java.awt.Color color8 = java.awt.Color.red;
        java.awt.Color color9 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray10 = new java.awt.Paint[] { color3, paint6, color7, color8, color9 };
        java.awt.Paint[] paintArray11 = null;
        java.awt.Stroke stroke12 = null;
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] { stroke12 };
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] {};
        java.awt.Shape shape15 = null;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] { shape15 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray10, paintArray11, strokeArray13, strokeArray14, shapeArray16);
        java.awt.Stroke stroke18 = defaultDrawingSupplier17.getNextStroke();
        java.awt.Paint paint19 = defaultDrawingSupplier17.getNextFillPaint();
        java.awt.Paint paint20 = defaultDrawingSupplier17.getNextPaint();
        categoryPlot1.setRangeGridlinePaint(paint20);
        java.awt.Color color23 = java.awt.Color.ORANGE;
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset27 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer28 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot29 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset27, waferMapRenderer28);
        org.jfree.data.general.WaferMapDataset waferMapDataset30 = null;
        waferMapPlot29.setDataset(waferMapDataset30);
        waferMapPlot29.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot29);
        jFreeChart34.setBackgroundImageAlpha(1.0f);
        jFreeChart34.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = jFreeChart34.getPadding();
        org.jfree.chart.block.LineBorder lineBorder40 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color24, stroke25, rectangleInsets39);
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color23, stroke25);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent42 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) valueMarker41);
        java.awt.Stroke stroke43 = valueMarker41.getOutlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D46 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font48 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D46.setTickLabelFont((java.lang.Comparable) (short) 10, font48);
        org.jfree.chart.text.TextFragment textFragment50 = new org.jfree.chart.text.TextFragment("hi!", font48);
        float float51 = textFragment50.getBaselineOffset();
        java.awt.Paint paint52 = textFragment50.getPaint();
        org.jfree.chart.plot.RingPlot ringPlot53 = new org.jfree.chart.plot.RingPlot();
        java.lang.Object obj54 = ringPlot53.clone();
        java.awt.Graphics2D graphics2D55 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.plot.RingPlot ringPlot57 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint58 = ringPlot57.getLabelBackgroundPaint();
        ringPlot57.setShadowXOffset((double) (-1.0f));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo62 = null;
        org.jfree.chart.plot.PiePlotState piePlotState63 = ringPlot53.initialise(graphics2D55, rectangle2D56, (org.jfree.chart.plot.PiePlot) ringPlot57, (java.lang.Integer) 200, plotRenderingInfo62);
        java.awt.Stroke stroke64 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot53.setSeparatorStroke(stroke64);
        org.jfree.chart.plot.ValueMarker valueMarker67 = new org.jfree.chart.plot.ValueMarker((double) 200, paint20, stroke43, paint52, stroke64, (float) (byte) 0);
        java.lang.Object obj68 = valueMarker67.clone();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertTrue("'" + float51 + "' != '" + 0.0f + "'", float51 == 0.0f);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(obj54);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(piePlotState63);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(obj68);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        java.awt.Color color2 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint5 = textTitle4.getPaint();
        java.awt.Color color6 = java.awt.Color.red;
        java.awt.Color color7 = java.awt.Color.red;
        java.awt.Color color8 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color2, paint5, color6, color7, color8 };
        java.awt.Paint[] paintArray10 = null;
        java.awt.Stroke stroke11 = null;
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] { stroke11 };
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] {};
        java.awt.Shape shape14 = null;
        java.awt.Shape[] shapeArray15 = new java.awt.Shape[] { shape14 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray10, strokeArray12, strokeArray13, shapeArray15);
        java.awt.Stroke stroke17 = defaultDrawingSupplier16.getNextStroke();
        java.awt.Paint paint18 = defaultDrawingSupplier16.getNextFillPaint();
        java.awt.Paint paint19 = defaultDrawingSupplier16.getNextPaint();
        categoryPlot0.setRangeGridlinePaint(paint19);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset25 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer26 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot27 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset25, waferMapRenderer26);
        org.jfree.data.general.WaferMapDataset waferMapDataset28 = null;
        waferMapPlot27.setDataset(waferMapDataset28);
        float float30 = waferMapPlot27.getBackgroundImageAlpha();
        valueMarker24.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot27);
        java.awt.Font font32 = valueMarker24.getLabelFont();
        dateAxis22.setTickLabelFont(font32);
        org.jfree.data.Range range34 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis22);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = categoryPlot0.getRangeMarkers(layer37);
        org.jfree.chart.axis.AxisLocation axisLocation40 = categoryPlot0.getRangeAxisLocation((int) (short) -1);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.5f + "'", float30 == 0.5f);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertNotNull(axisLocation40);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Color color6 = java.awt.Color.white;
        java.awt.Color color7 = java.awt.Color.getColor("", color6);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreZeroValues(true);
        java.awt.Stroke stroke3 = ringPlot0.getLabelLinkStroke();
        boolean boolean4 = ringPlot0.getLabelLinksVisible();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ThreadContext");
        java.text.AttributedString attributedString3 = standardPieSectionLabelGenerator1.getAttributedLabel((int) (byte) -1);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        try {
            java.text.AttributedString attributedString6 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel(pieDataset4, (java.lang.Comparable) 8.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(attributedString3);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getURLText();
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle1.setBackgroundPaint(paint3);
        textTitle1.setHeight((double) ' ');
        org.jfree.chart.util.Size2D size2D7 = new org.jfree.chart.util.Size2D();
        boolean boolean8 = textTitle1.equals((java.lang.Object) size2D7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = org.jfree.chart.block.RectangleConstraint.NONE;
        try {
            org.jfree.chart.util.Size2D size2D11 = textTitle1.arrange(graphics2D9, rectangleConstraint10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape4 = dateAxis3.getDownArrow();
        dateAxis1.setUpArrow(shape4);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape9, "{0}", "hi!");
        chartEntity6.setArea(shape9);
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape9, "1.2.0-pre");
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke1 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer4 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset3, waferMapRenderer4);
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        waferMapPlot5.setDataset(waferMapDataset6);
        waferMapPlot5.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot5);
        jFreeChart10.setBackgroundImageAlpha(1.0f);
        jFreeChart10.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = jFreeChart10.getPadding();
        org.jfree.chart.block.LineBorder lineBorder16 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = lineBorder16.getInsets();
        java.awt.Paint paint18 = lineBorder16.getPaint();
        java.awt.Stroke stroke19 = lineBorder16.getStroke();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean2 = numberAxis0.isAutoRange();
        numberAxis0.setLabelAngle((double) '4');
        org.jfree.data.RangeType rangeType5 = numberAxis0.getRangeType();
        double double6 = numberAxis0.getUpperMargin();
        numberAxis0.resizeRange((double) (short) -1, 0.14d);
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = numberAxis0.getStandardTickUnits();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rangeType5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(tickUnitSource10);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 'a');
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = chartChangeEvent1.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        chartChangeEvent1.setType(chartChangeEventType3);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer6 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset5, waferMapRenderer6);
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        waferMapPlot7.setDataset(waferMapDataset8);
        float float10 = waferMapPlot7.getBackgroundImageAlpha();
        valueMarker4.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot7);
        java.awt.Font font12 = valueMarker4.getLabelFont();
        dateAxis2.setTickLabelFont(font12);
        org.jfree.data.Range range16 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis2.setRangeWithMargins(range16);
        float float18 = dateAxis2.getTickMarkInsideLength();
        dateAxis2.setLowerMargin(0.0d);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer21 = null;
        org.jfree.chart.plot.PolarPlot polarPlot22 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        try {
            polarPlot22.drawOutline(graphics2D23, rectangle2D24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("LengthConstraintType.FIXED", graphics2D1, (double) 1L, (-1.0f), 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint3 = categoryPlot2.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = null;
        categoryPlot2.setFixedLegendItems(legendItemCollection4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot2.getRangeAxisForDataset((-1));
        categoryPlot2.setDomainGridlinesVisible(false);
        categoryAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset14 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer15 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot16 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset14, waferMapRenderer15);
        org.jfree.data.general.WaferMapDataset waferMapDataset17 = null;
        waferMapPlot16.setDataset(waferMapDataset17);
        float float19 = waferMapPlot16.getBackgroundImageAlpha();
        valueMarker13.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot16);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker13.setLabelAnchor(rectangleAnchor21);
        java.awt.Paint paint23 = valueMarker13.getOutlinePaint();
        java.awt.Stroke stroke24 = valueMarker13.getStroke();
        org.jfree.chart.util.Layer layer25 = null;
        try {
            boolean boolean26 = categoryPlot2.removeRangeMarker(15, (org.jfree.chart.plot.Marker) valueMarker13, layer25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.5f + "'", float19 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke2);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer(categoryItemRenderer5, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getNoDataMessagePaint();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot9.setRangeCrosshairStroke(stroke11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot9.getDomainAxisLocation();
        categoryPlot0.setRangeAxisLocation(500, axisLocation13, true);
        java.awt.Paint paint16 = null;
        try {
            categoryPlot0.setRangeGridlinePaint(paint16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(8.0d, plotRenderingInfo4, point2D5);
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle7.getLegendItemGraphicEdge();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.data.general.WaferMapDataset waferMapDataset11 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer12 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset11, waferMapRenderer12);
        org.jfree.data.general.WaferMapDataset waferMapDataset14 = null;
        waferMapPlot13.setDataset(waferMapDataset14);
        waferMapPlot13.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot13);
        jFreeChart18.setBackgroundImageAlpha(1.0f);
        jFreeChart18.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = jFreeChart18.getPadding();
        boolean boolean24 = jFreeChart18.isNotify();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color9, jFreeChart18, chartChangeEventType25);
        boolean boolean27 = legendTitle7.equals((java.lang.Object) color9);
        int int28 = color9.getRGB();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-8388480) + "'", int28 == (-8388480));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        float float7 = waferMapPlot4.getBackgroundImageAlpha();
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot4);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean12 = polarPlot11.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint16 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot15.setRangeZeroBaselinePaint(paint16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray19 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer18 };
        xYPlot15.setRenderers(xYItemRendererArray19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot15.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo23, point2D24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        xYPlot15.setFixedRangeAxisSpace(axisSpace26);
        java.awt.Stroke stroke28 = xYPlot15.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D29 = xYPlot15.getQuadrantOrigin();
        polarPlot11.zoomDomainAxes(1.0E-8d, plotRenderingInfo14, point2D29);
        org.jfree.chart.plot.PlotState plotState31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        try {
            waferMapPlot4.draw(graphics2D9, rectangle2D10, point2D29, plotState31, plotRenderingInfo32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(xYItemRendererArray19);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(point2D29);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace2 = xYPlot0.getFixedRangeAxisSpace();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        xYPlot0.drawBackgroundImage(graphics2D3, rectangle2D4);
        boolean boolean6 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = null;
        try {
            xYPlot0.setDomainAxes(valueAxisArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint3 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot2.setRangeZeroBaselinePaint(paint3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getNoDataMessagePaint();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot5.setRangeCrosshairStroke(stroke7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot5.getDomainAxisLocation();
        xYPlot2.setRangeAxisLocation(axisLocation9, false);
        xYPlot2.setOutlineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = xYPlot2.getDatasetRenderingOrder();
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = null;
        try {
            categoryPlot0.setDomainGridlinePosition(categoryAnchor16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color2 = java.awt.Color.ORANGE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer7 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6, waferMapRenderer7);
        org.jfree.data.general.WaferMapDataset waferMapDataset9 = null;
        waferMapPlot8.setDataset(waferMapDataset9);
        waferMapPlot8.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot8);
        jFreeChart13.setBackgroundImageAlpha(1.0f);
        jFreeChart13.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = jFreeChart13.getPadding();
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color3, stroke4, rectangleInsets18);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color2, stroke4);
        polarPlot0.setRadiusGridlineStroke(stroke4);
        polarPlot0.setRadiusGridlinesVisible(false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setRangeCrosshairValue((double) 200, false);
        boolean boolean7 = categoryPlot3.isRangeCrosshairVisible();
        java.awt.Color color9 = java.awt.Color.white;
        java.awt.Color color10 = java.awt.Color.getColor("", color9);
        categoryPlot3.setNoDataMessagePaint((java.awt.Paint) color9);
        valueMarker2.setOutlinePaint((java.awt.Paint) color9);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = valueMarker2.getLabelOffset();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets13);
        java.awt.Paint paint16 = piePlot3D0.getSectionPaint((java.lang.Comparable) "1.2.0-pre");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(paint16);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint2 = ringPlot1.getLabelBackgroundPaint();
        boolean boolean3 = ringPlot1.isCircular();
        java.awt.Stroke stroke4 = ringPlot1.getLabelLinkStroke();
        dateAxis0.setTickMarkStroke(stroke4);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis7.setUpperMargin((double) 100L);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        java.awt.Shape shape13 = dateAxis11.getUpArrow();
        dateAxis11.centerRange((double) (short) 1);
        dateAxis11.setRange(0.0d, (double) '#');
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis11.setStandardTickUnits(tickUnitSource19);
        org.jfree.chart.plot.Plot plot21 = dateAxis11.getPlot();
        double[] doubleArray26 = new double[] { 0.4d, (-1) };
        double[] doubleArray29 = new double[] { 0.4d, (-1) };
        double[] doubleArray32 = new double[] { 0.4d, (-1) };
        double[] doubleArray35 = new double[] { 0.4d, (-1) };
        double[] doubleArray38 = new double[] { 0.4d, (-1) };
        double[] doubleArray41 = new double[] { 0.4d, (-1) };
        double[][] doubleArray42 = new double[][] { doubleArray26, doubleArray29, doubleArray32, doubleArray35, doubleArray38, doubleArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "{0}", doubleArray42);
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset43);
        org.jfree.data.Range range46 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset43, true);
        dateAxis11.setRange(range46);
        dateAxis7.setRange(range46, false, false);
        dateAxis0.setRange(range46);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(range46);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        boolean boolean2 = ringPlot0.isCircular();
        java.awt.Stroke stroke3 = ringPlot0.getLabelLinkStroke();
        java.awt.Paint paint4 = ringPlot0.getShadowPaint();
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean6 = polarPlot5.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint10 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot9.setRangeZeroBaselinePaint(paint10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray13 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer12 };
        xYPlot9.setRenderers(xYItemRendererArray13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        xYPlot9.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo17, point2D18);
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        xYPlot9.setFixedRangeAxisSpace(axisSpace20);
        java.awt.Stroke stroke22 = xYPlot9.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D23 = xYPlot9.getQuadrantOrigin();
        polarPlot5.zoomDomainAxes(1.0E-8d, plotRenderingInfo8, point2D23);
        ringPlot0.setParent((org.jfree.chart.plot.Plot) polarPlot5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment27 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement30 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment26, verticalAlignment27, (double) 10L, (double) 100.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint32 = categoryPlot31.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation33 = categoryPlot31.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot31.zoomDomainAxes(8.0d, plotRenderingInfo35, point2D36);
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot31);
        java.awt.Font font39 = legendTitle38.getItemFont();
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset43 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer44 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot45 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset43, waferMapRenderer44);
        org.jfree.data.general.WaferMapDataset waferMapDataset46 = null;
        waferMapPlot45.setDataset(waferMapDataset46);
        waferMapPlot45.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot45);
        jFreeChart50.setBackgroundImageAlpha(1.0f);
        jFreeChart50.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = jFreeChart50.getPadding();
        org.jfree.chart.block.LineBorder lineBorder56 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color40, stroke41, rectangleInsets55);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = lineBorder56.getInsets();
        columnArrangement30.add((org.jfree.chart.block.Block) legendTitle38, (java.lang.Object) rectangleInsets57);
        columnArrangement30.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement60 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle61 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0, (org.jfree.chart.block.Arrangement) columnArrangement30, (org.jfree.chart.block.Arrangement) flowArrangement60);
        org.jfree.chart.block.BlockContainer blockContainer62 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D63 = null;
        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape67 = dateAxis66.getDownArrow();
        java.awt.Shape shape68 = dateAxis66.getUpArrow();
        dateAxis66.centerRange((double) (short) 1);
        dateAxis66.setRange(0.0d, (double) '#');
        org.jfree.data.Range range76 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis66.setRange(range76, false, false);
        org.jfree.data.Range range81 = org.jfree.data.Range.shift(range76, 8.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint82 = new org.jfree.chart.block.RectangleConstraint(10.0d, range81);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint84 = rectangleConstraint82.toFixedWidth(0.12d);
        org.jfree.chart.util.Size2D size2D85 = flowArrangement60.arrange(blockContainer62, graphics2D63, rectangleConstraint82);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(xYItemRendererArray13);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(point2D23);
        org.junit.Assert.assertNotNull(verticalAlignment27);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(shape67);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertNotNull(range81);
        org.junit.Assert.assertNotNull(rectangleConstraint84);
        org.junit.Assert.assertNotNull(size2D85);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.8f, 0.0f, (float) (byte) 100);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart8.getLegend((int) (byte) -1);
        java.lang.Object obj15 = jFreeChart8.getTextAntiAlias();
        java.awt.RenderingHints renderingHints16 = null;
        try {
            jFreeChart8.setRenderingHints(renderingHints16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNull(obj15);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 1, 0);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str8 = categoryAxis3D7.getLabelURL();
        double double9 = categoryAxis3D7.getCategoryMargin();
        java.lang.Object obj10 = categoryAxis3D7.clone();
        categoryAxis3D7.setCategoryMargin((double) 10L);
        java.util.List list13 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D7);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint15 = categoryPlot14.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = null;
        categoryPlot14.setFixedLegendItems(legendItemCollection16);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot14.getRangeAxisForDataset((-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryPlot14.getAxisOffset();
        categoryPlot0.setAxisOffset(rectangleInsets20);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        java.awt.Shape shape7 = dateAxis5.getUpArrow();
        dateAxis5.centerRange((double) (short) 1);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer14 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot15 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset13, waferMapRenderer14);
        org.jfree.data.general.WaferMapDataset waferMapDataset16 = null;
        waferMapPlot15.setDataset(waferMapDataset16);
        waferMapPlot15.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot15);
        jFreeChart20.setBackgroundImageAlpha(1.0f);
        jFreeChart20.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = jFreeChart20.getPadding();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color10, stroke11, rectangleInsets25);
        dateAxis5.setTickMarkStroke(stroke11);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer28);
        dateAxis5.setTickMarkInsideLength((float) 'a');
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        java.lang.Object obj7 = xYPlot0.clone();
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = xYPlot0.getRangeMarkers(layer8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getRangeAxis();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color11);
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color15 = java.awt.Color.ORANGE;
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset19 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer20 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot21 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset19, waferMapRenderer20);
        org.jfree.data.general.WaferMapDataset waferMapDataset22 = null;
        waferMapPlot21.setDataset(waferMapDataset22);
        waferMapPlot21.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot21);
        jFreeChart26.setBackgroundImageAlpha(1.0f);
        jFreeChart26.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = jFreeChart26.getPadding();
        org.jfree.chart.block.LineBorder lineBorder32 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color16, stroke17, rectangleInsets31);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color15, stroke17);
        polarPlot13.setRadiusGridlineStroke(stroke17);
        org.jfree.chart.plot.PlotOrientation plotOrientation35 = polarPlot13.getOrientation();
        xYPlot0.setOrientation(plotOrientation35);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(plotOrientation35);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        org.jfree.data.general.WaferMapDataset waferMapDataset7 = null;
        waferMapPlot6.setDataset(waferMapDataset7);
        float float9 = waferMapPlot6.getBackgroundImageAlpha();
        valueMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot6);
        java.awt.Font font11 = valueMarker3.getLabelFont();
        dateAxis1.setTickLabelFont(font11);
        org.jfree.data.Range range15 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis1.setRangeWithMargins(range15);
        java.lang.String str17 = dateAxis1.getLabelToolTip();
        org.jfree.data.Range range18 = dateAxis1.getRange();
        boolean boolean19 = dateAxis1.isInverted();
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5f + "'", float9 == 0.5f);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        float float7 = waferMapPlot4.getBackgroundImageAlpha();
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot4);
        java.awt.Font font9 = valueMarker1.getLabelFont();
        java.lang.Object obj10 = null;
        boolean boolean11 = valueMarker1.equals(obj10);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "1.2.0-pre", "RectangleAnchor.BOTTOM_LEFT");
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.Object obj1 = ringPlot0.clone();
        double double2 = ringPlot0.getMaximumExplodePercent();
        double double3 = ringPlot0.getInnerSeparatorExtension();
        java.awt.Paint paint4 = ringPlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke5 = ringPlot0.getBaseSectionOutlineStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = ringPlot0.getLegendLabelGenerator();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        boolean boolean2 = ringPlot0.isCircular();
        java.awt.Paint paint3 = ringPlot0.getSeparatorPaint();
        ringPlot0.setSectionOutlinesVisible(false);
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) -1, 100.0d);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(0, (int) (byte) 10, (int) (byte) 10);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        categoryPlot0.setAnchorValue(0.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str6 = textTitle5.getURLText();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle5.setBackgroundPaint(paint7);
        categoryPlot0.setDomainGridlinePaint(paint7);
        boolean boolean10 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot0.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot0.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        java.awt.Color color2 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint5 = textTitle4.getPaint();
        java.awt.Color color6 = java.awt.Color.red;
        java.awt.Color color7 = java.awt.Color.red;
        java.awt.Color color8 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color2, paint5, color6, color7, color8 };
        java.awt.Paint[] paintArray10 = null;
        java.awt.Stroke stroke11 = null;
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] { stroke11 };
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] {};
        java.awt.Shape shape14 = null;
        java.awt.Shape[] shapeArray15 = new java.awt.Shape[] { shape14 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray10, strokeArray12, strokeArray13, shapeArray15);
        java.awt.Stroke stroke17 = defaultDrawingSupplier16.getNextStroke();
        java.awt.Paint paint18 = defaultDrawingSupplier16.getNextFillPaint();
        java.awt.Paint paint19 = defaultDrawingSupplier16.getNextPaint();
        categoryPlot0.setRangeGridlinePaint(paint19);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset25 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer26 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot27 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset25, waferMapRenderer26);
        org.jfree.data.general.WaferMapDataset waferMapDataset28 = null;
        waferMapPlot27.setDataset(waferMapDataset28);
        float float30 = waferMapPlot27.getBackgroundImageAlpha();
        valueMarker24.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot27);
        java.awt.Font font32 = valueMarker24.getLabelFont();
        dateAxis22.setTickLabelFont(font32);
        org.jfree.data.Range range34 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis22);
        boolean boolean35 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection36 = categoryPlot0.getFixedLegendItems();
        categoryPlot0.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace39 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.5f + "'", float30 == 0.5f);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(legendItemCollection36);
        org.junit.Assert.assertNull(axisSpace39);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        org.jfree.data.general.WaferMapDataset waferMapDataset7 = null;
        waferMapPlot6.setDataset(waferMapDataset7);
        float float9 = waferMapPlot6.getBackgroundImageAlpha();
        valueMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot6);
        java.awt.Font font11 = valueMarker3.getLabelFont();
        dateAxis1.setTickLabelFont(font11);
        org.jfree.data.Range range15 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis1.setRangeWithMargins(range15);
        java.lang.String str17 = dateAxis1.getLabelToolTip();
        org.jfree.data.Range range18 = dateAxis1.getRange();
        java.awt.Color color19 = java.awt.Color.darkGray;
        boolean boolean20 = range18.equals((java.lang.Object) color19);
        int int21 = color19.getRGB();
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5f + "'", float9 == 0.5f);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-12566464) + "'", int21 == (-12566464));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint12 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot11.setRangeZeroBaselinePaint(paint12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray15 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer14 };
        xYPlot11.setRenderers(xYItemRendererArray15);
        xYPlot0.setRenderers(xYItemRendererArray15);
        org.jfree.chart.plot.Plot plot18 = xYPlot0.getParent();
        java.awt.Stroke stroke19 = xYPlot0.getRangeGridlineStroke();
        xYPlot0.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(xYItemRendererArray15);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot0.getDomainAxisEdge();
        java.util.List list14 = xYPlot0.getAnnotations();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.setRangeCrosshairValue((double) 200, false);
        boolean boolean21 = categoryPlot17.isRangeCrosshairVisible();
        java.awt.Color color23 = java.awt.Color.white;
        java.awt.Color color24 = java.awt.Color.getColor("", color23);
        categoryPlot17.setNoDataMessagePaint((java.awt.Paint) color23);
        valueMarker16.setOutlinePaint((java.awt.Paint) color23);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = valueMarker16.getLabelOffset();
        java.awt.Font font28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        valueMarker16.setLabelFont(font28);
        org.jfree.chart.util.Layer layer30 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer30);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset();
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.setDomainZeroBaselineVisible(true);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNull(axisSpace3);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean2 = polarPlot1.isAngleGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        polarPlot1.setDataset(xYDataset3);
        java.awt.Font font5 = polarPlot1.getAngleLabelFont();
        java.awt.Font font6 = polarPlot1.getAngleLabelFont();
        java.awt.Paint paint7 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("TextAnchor.HALF_ASCENT_CENTER", font6, paint7, (float) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint12 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot11.setRangeZeroBaselinePaint(paint12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray15 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer14 };
        xYPlot11.setRenderers(xYItemRendererArray15);
        xYPlot0.setRenderers(xYItemRendererArray15);
        org.jfree.chart.plot.Plot plot18 = xYPlot0.getParent();
        java.awt.Stroke stroke19 = xYPlot0.getRangeGridlineStroke();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke20);
        java.awt.Color color22 = java.awt.Color.darkGray;
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color22);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = xYPlot0.getRendererForDataset(xYDataset24);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(xYItemRendererArray15);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(xYItemRenderer25);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer11 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset10, waferMapRenderer11);
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        waferMapPlot12.setDataset(waferMapDataset13);
        waferMapPlot12.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot12);
        jFreeChart17.setBackgroundImageAlpha(1.0f);
        jFreeChart17.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = jFreeChart17.getPadding();
        org.jfree.chart.block.LineBorder lineBorder23 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color7, stroke8, rectangleInsets22);
        xYPlot0.setDomainZeroBaselineStroke(stroke8);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape27 = dateAxis26.getDownArrow();
        java.awt.Shape shape28 = dateAxis26.getUpArrow();
        dateAxis26.centerRange((double) (short) 1);
        dateAxis26.setRange(0.0d, (double) '#');
        boolean boolean34 = dateAxis26.isNegativeArrowVisible();
        java.awt.Paint paint35 = dateAxis26.getTickMarkPaint();
        xYPlot0.setRangeCrosshairPaint(paint35);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = xYPlot0.getDomainAxisEdge((int) (short) 100);
        org.jfree.chart.ui.ProjectInfo projectInfo39 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean41 = numberAxis40.getAutoRangeIncludesZero();
        java.lang.String str42 = numberAxis40.getLabelURL();
        numberAxis40.setFixedAutoRange((double) 0);
        boolean boolean45 = projectInfo39.equals((java.lang.Object) numberAxis40);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis40);
        java.awt.Font font47 = numberAxis40.getLabelFont();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(projectInfo39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(font47);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color2 = java.awt.Color.ORANGE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer7 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6, waferMapRenderer7);
        org.jfree.data.general.WaferMapDataset waferMapDataset9 = null;
        waferMapPlot8.setDataset(waferMapDataset9);
        waferMapPlot8.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot8);
        jFreeChart13.setBackgroundImageAlpha(1.0f);
        jFreeChart13.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = jFreeChart13.getPadding();
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color3, stroke4, rectangleInsets18);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color2, stroke4);
        polarPlot0.setRadiusGridlineStroke(stroke4);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("hi!", font23);
        java.awt.Font font25 = textTitle24.getFont();
        polarPlot0.setAngleLabelFont(font25);
        java.awt.Paint paint27 = polarPlot0.getAngleLabelPaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 10L, (double) 100.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot5.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomDomainAxes(8.0d, plotRenderingInfo9, point2D10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot5);
        java.awt.Font font13 = legendTitle12.getItemFont();
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset17 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer18 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot19 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset17, waferMapRenderer18);
        org.jfree.data.general.WaferMapDataset waferMapDataset20 = null;
        waferMapPlot19.setDataset(waferMapDataset20);
        waferMapPlot19.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot19);
        jFreeChart24.setBackgroundImageAlpha(1.0f);
        jFreeChart24.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = jFreeChart24.getPadding();
        org.jfree.chart.block.LineBorder lineBorder30 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color14, stroke15, rectangleInsets29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = lineBorder30.getInsets();
        columnArrangement4.add((org.jfree.chart.block.Block) legendTitle12, (java.lang.Object) rectangleInsets31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = legendTitle12.getLegendItemGraphicEdge();
        java.awt.Color color38 = java.awt.Color.gray;
        org.jfree.chart.block.BlockBorder blockBorder39 = new org.jfree.chart.block.BlockBorder((double) 0.5f, (double) (byte) -1, 0.0d, (double) (byte) 0, (java.awt.Paint) color38);
        java.awt.Paint paint40 = blockBorder39.getPaint();
        legendTitle12.setBackgroundPaint(paint40);
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        try {
            legendTitle12.setBounds(rectangle2D42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        boolean boolean2 = blockParams0.getGenerateEntities();
        double double3 = blockParams0.getTranslateY();
        blockParams0.setTranslateY(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint16 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot15.setRangeZeroBaselinePaint(paint16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray19 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer18 };
        xYPlot15.setRenderers(xYItemRendererArray19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot15.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo23, point2D24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        xYPlot15.setFixedRangeAxisSpace(axisSpace26);
        java.awt.Stroke stroke28 = xYPlot15.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D29 = xYPlot15.getQuadrantOrigin();
        xYPlot0.zoomDomainAxes((double) 10.0f, (double) 2.0f, plotRenderingInfo14, point2D29);
        double double31 = xYPlot0.getRangeCrosshairValue();
        java.awt.Paint paint32 = xYPlot0.getDomainGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot0.getRangeAxis();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(xYItemRendererArray19);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(valueAxis33);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setGenerateEntities(false);
        blockParams0.setTranslateX((double) '#');
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.Color color3 = java.awt.Color.getColor("", color2);
        ringPlot0.setLabelPaint((java.awt.Paint) color3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = ringPlot0.getLabelPadding();
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color8 = java.awt.Color.ORANGE;
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset12 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer13 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot14 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset12, waferMapRenderer13);
        org.jfree.data.general.WaferMapDataset waferMapDataset15 = null;
        waferMapPlot14.setDataset(waferMapDataset15);
        waferMapPlot14.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot14);
        jFreeChart19.setBackgroundImageAlpha(1.0f);
        jFreeChart19.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = jFreeChart19.getPadding();
        org.jfree.chart.block.LineBorder lineBorder25 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color9, stroke10, rectangleInsets24);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color8, stroke10);
        polarPlot6.setRadiusGridlineStroke(stroke10);
        polarPlot6.removeCornerTextItem("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.plot.RingPlot ringPlot30 = new org.jfree.chart.plot.RingPlot();
        ringPlot30.setIgnoreZeroValues(true);
        java.awt.Stroke stroke33 = ringPlot30.getLabelLinkStroke();
        polarPlot6.setOutlineStroke(stroke33);
        ringPlot0.setSeparatorStroke(stroke33);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color3 = java.awt.Color.ORANGE;
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset7 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer8 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset7, waferMapRenderer8);
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        waferMapPlot9.setDataset(waferMapDataset10);
        waferMapPlot9.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot9);
        jFreeChart14.setBackgroundImageAlpha(1.0f);
        jFreeChart14.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = jFreeChart14.getPadding();
        org.jfree.chart.block.LineBorder lineBorder20 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color4, stroke5, rectangleInsets19);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color3, stroke5);
        polarPlot1.setRadiusGridlineStroke(stroke5);
        java.awt.Stroke stroke23 = polarPlot1.getRadiusGridlineStroke();
        boolean boolean24 = lineBorder0.equals((java.lang.Object) polarPlot1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 10);
        int int2 = pieLabelDistributor1.getItemCount();
        java.lang.String str3 = pieLabelDistributor1.toString();
        pieLabelDistributor1.sort();
        java.lang.String str5 = pieLabelDistributor1.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = xYPlot0.getDomainAxisEdge();
        int int15 = xYPlot0.getSeriesCount();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        java.awt.Color color2 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint5 = textTitle4.getPaint();
        java.awt.Color color6 = java.awt.Color.red;
        java.awt.Color color7 = java.awt.Color.red;
        java.awt.Color color8 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color2, paint5, color6, color7, color8 };
        java.awt.Paint[] paintArray10 = null;
        java.awt.Stroke stroke11 = null;
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] { stroke11 };
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] {};
        java.awt.Shape shape14 = null;
        java.awt.Shape[] shapeArray15 = new java.awt.Shape[] { shape14 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray10, strokeArray12, strokeArray13, shapeArray15);
        java.awt.Stroke stroke17 = defaultDrawingSupplier16.getNextStroke();
        java.awt.Paint paint18 = defaultDrawingSupplier16.getNextFillPaint();
        java.awt.Paint paint19 = defaultDrawingSupplier16.getNextPaint();
        categoryPlot0.setRangeGridlinePaint(paint19);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset25 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer26 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot27 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset25, waferMapRenderer26);
        org.jfree.data.general.WaferMapDataset waferMapDataset28 = null;
        waferMapPlot27.setDataset(waferMapDataset28);
        float float30 = waferMapPlot27.getBackgroundImageAlpha();
        valueMarker24.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot27);
        java.awt.Font font32 = valueMarker24.getLabelFont();
        dateAxis22.setTickLabelFont(font32);
        org.jfree.data.Range range34 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis22);
        boolean boolean35 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection36 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis37 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.5f + "'", float30 == 0.5f);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(legendItemCollection36);
        org.junit.Assert.assertNull(valueAxis37);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        waferMapPlot4.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot4);
        jFreeChart9.setBackgroundImageAlpha(1.0f);
        jFreeChart9.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = jFreeChart9.getPadding();
        boolean boolean15 = jFreeChart9.isNotify();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart9, chartChangeEventType16);
        org.jfree.chart.event.ChartProgressListener chartProgressListener18 = null;
        jFreeChart9.addProgressListener(chartProgressListener18);
        jFreeChart9.setTextAntiAlias(false);
        try {
            java.awt.image.BufferedImage bufferedImage24 = jFreeChart9.createBufferedImage(255, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (255) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        boolean boolean2 = ringPlot0.isCircular();
        java.awt.Paint paint3 = ringPlot0.getSeparatorPaint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat5 = standardPieSectionLabelGenerator4.getNumberFormat();
        java.lang.Object obj6 = standardPieSectionLabelGenerator4.clone();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.text.AttributedString attributedString9 = standardPieSectionLabelGenerator4.getAttributedLabel((int) (short) 1);
        java.lang.Object obj10 = standardPieSectionLabelGenerator4.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(numberFormat5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(attributedString9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        double double2 = blockParams0.getTranslateY();
        double double3 = blockParams0.getTranslateX();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot0.getDomainAxisEdge();
        java.util.List list14 = xYPlot0.getAnnotations();
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint16 = ringPlot15.getLabelBackgroundPaint();
        boolean boolean17 = ringPlot15.isCircular();
        java.awt.Stroke stroke18 = ringPlot15.getLabelLinkStroke();
        java.awt.Paint paint19 = ringPlot15.getShadowPaint();
        xYPlot0.setRangeZeroBaselinePaint(paint19);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) 10L, (double) 100.0f);
        java.lang.Object obj6 = null;
        boolean boolean7 = verticalAlignment2.equals(obj6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer11 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset10, waferMapRenderer11);
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        waferMapPlot12.setDataset(waferMapDataset13);
        waferMapPlot12.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot12);
        jFreeChart17.setBackgroundImageAlpha(1.0f);
        jFreeChart17.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = jFreeChart17.getPadding();
        boolean boolean23 = jFreeChart17.isNotify();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType24 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color8, jFreeChart17, chartChangeEventType24);
        org.jfree.chart.JFreeChart jFreeChart26 = chartChangeEvent25.getChart();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = chartChangeEvent25.getType();
        boolean boolean28 = verticalAlignment2.equals((java.lang.Object) chartChangeEvent25);
        org.jfree.chart.block.FlowArrangement flowArrangement31 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment2, (-9.0d), (double) 0);
        java.lang.Object obj32 = null;
        boolean boolean33 = flowArrangement31.equals(obj32);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(jFreeChart26);
        org.junit.Assert.assertNull(chartChangeEventType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        java.awt.Stroke stroke13 = xYPlot0.getDomainCrosshairStroke();
        java.awt.Stroke stroke14 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.axis.AxisSpace axisSpace15 = xYPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape19 = dateAxis18.getDownArrow();
        java.awt.Shape shape20 = dateAxis18.getUpArrow();
        dateAxis18.centerRange((double) (short) 1);
        dateAxis18.setRange(0.0d, (double) '#');
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset30 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer31 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot32 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset30, waferMapRenderer31);
        org.jfree.data.general.WaferMapDataset waferMapDataset33 = null;
        waferMapPlot32.setDataset(waferMapDataset33);
        float float35 = waferMapPlot32.getBackgroundImageAlpha();
        valueMarker29.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot32);
        java.awt.Font font37 = valueMarker29.getLabelFont();
        dateAxis27.setTickLabelFont(font37);
        org.jfree.data.Range range41 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis27.setRangeWithMargins(range41);
        java.util.TimeZone timeZone43 = dateAxis27.getTimeZone();
        dateAxis18.setTimeZone(timeZone43);
        xYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis18, false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(axisSpace15);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.5f + "'", float35 == 0.5f);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(timeZone43);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        xYPlot0.zoom((double) (short) -1);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = xYPlot0.getDomainMarkers(layer15);
        try {
            java.awt.Paint paint18 = xYPlot0.getQuadrantPaint((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (-1) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(collection16);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 1, 0);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str8 = categoryAxis3D7.getLabelURL();
        double double9 = categoryAxis3D7.getCategoryMargin();
        java.lang.Object obj10 = categoryAxis3D7.clone();
        categoryAxis3D7.setCategoryMargin((double) 10L);
        java.util.List list13 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D7);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot0.getRangeAxisEdge();
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        java.awt.Shape shape4 = dateAxis2.getUpArrow();
        dateAxis2.centerRange((double) (short) 1);
        dateAxis2.setRange(0.0d, (double) '#');
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis2.setStandardTickUnits(tickUnitSource10);
        org.jfree.data.Range range12 = dateAxis2.getRange();
        boolean boolean13 = rectangleInsets0.equals((java.lang.Object) range12);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(tickUnitSource10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "{0}", "hi!");
        java.lang.Object obj6 = chartEntity5.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainAxes();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str3 = projectInfo2.getLicenceText();
        java.lang.String str4 = projectInfo2.getInfo();
        projectInfo2.setCopyright("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=90.0]");
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer9 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot10 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset8, waferMapRenderer9);
        org.jfree.data.general.WaferMapDataset waferMapDataset11 = null;
        waferMapPlot10.setDataset(waferMapDataset11);
        waferMapPlot10.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot10);
        jFreeChart15.setBackgroundImageAlpha(1.0f);
        jFreeChart15.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = jFreeChart15.getPadding();
        boolean boolean21 = jFreeChart15.isNotify();
        org.jfree.chart.title.LegendTitle legendTitle23 = jFreeChart15.getLegend(200);
        jFreeChart15.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.data.general.WaferMapDataset waferMapDataset26 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer27 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot28 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset26, waferMapRenderer27);
        org.jfree.data.general.WaferMapDataset waferMapDataset29 = null;
        waferMapPlot28.setDataset(waferMapDataset29);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent31 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) waferMapPlot28);
        org.jfree.chart.JFreeChart jFreeChart32 = plotChangeEvent31.getChart();
        jFreeChart15.plotChanged(plotChangeEvent31);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = null;
        java.awt.image.BufferedImage bufferedImage39 = jFreeChart15.createBufferedImage((int) (byte) 1, (int) (short) 100, (double) (short) 0, (double) (byte) 10, chartRenderingInfo38);
        java.awt.image.BufferedImage bufferedImage42 = jFreeChart15.createBufferedImage((int) 'a', (int) (byte) 10);
        projectInfo2.setLogo((java.awt.Image) bufferedImage42);
        xYPlot0.setBackgroundImage((java.awt.Image) bufferedImage42);
        int int45 = xYPlot0.getDomainAxisCount();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(legendTitle23);
        org.junit.Assert.assertNull(jFreeChart32);
        org.junit.Assert.assertNotNull(bufferedImage39);
        org.junit.Assert.assertNotNull(bufferedImage42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        java.awt.Color color0 = java.awt.Color.red;
        java.awt.Color color1 = java.awt.Color.gray;
        java.awt.Color color2 = java.awt.Color.green;
        java.awt.Color color3 = java.awt.Color.red;
        float[] floatArray9 = new float[] { '4', (-1L), 10L, 10.0f, 0 };
        float[] floatArray10 = color3.getComponents(floatArray9);
        float[] floatArray11 = color2.getColorComponents(floatArray9);
        float[] floatArray12 = color1.getComponents(floatArray11);
        float[] floatArray13 = color0.getComponents(floatArray12);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D2.setTickLabelFont((java.lang.Comparable) (short) 10, font4);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font4, paint6);
        org.jfree.chart.text.TextLine textLine8 = textBlock7.getLastLine();
        org.jfree.chart.text.TextFragment textFragment9 = textLine8.getLastTextFragment();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        try {
            textFragment9.draw(graphics2D10, (float) (short) -1, (float) (-1L), textAnchor13, (float) 255, (float) (short) 100, 4.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(textLine8);
        org.junit.Assert.assertNotNull(textFragment9);
        org.junit.Assert.assertNotNull(textAnchor13);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Color color6 = java.awt.Color.white;
        java.awt.Color color7 = java.awt.Color.getColor("", color6);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str12 = categoryAxis3D11.getLabelURL();
        double double13 = categoryAxis3D11.getCategoryMargin();
        categoryAxis3D11.setLabelURL("RectangleEdge.TOP");
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis3D11.setTickMarkStroke(stroke16);
        java.awt.Font font19 = categoryAxis3D11.getTickLabelFont((java.lang.Comparable) (short) 100);
        java.awt.Paint paint21 = null;
        categoryAxis3D11.setTickLabelPaint((java.lang.Comparable) (-1L), paint21);
        int int23 = categoryAxis3D11.getMaximumCategoryLabelLines();
        categoryPlot0.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D11);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = categoryPlot0.getDomainMarkers(layer25);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.2d + "'", double13 == 0.2d);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNull(collection26);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getNoDataMessagePaint();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot3.setRangeCrosshairStroke(stroke5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot3.getDomainAxisLocation();
        xYPlot0.setRangeAxisLocation(axisLocation7, false);
        xYPlot0.setOutlineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = xYPlot0.getDatasetRenderingOrder();
        java.awt.Paint paint13 = xYPlot0.getRangeCrosshairPaint();
        double double14 = xYPlot0.getDomainCrosshairValue();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (short) 0, 0.0f, 0.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        boolean boolean14 = jFreeChart8.isNotify();
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart8.getLegend(200);
        jFreeChart8.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.data.general.WaferMapDataset waferMapDataset19 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer20 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot21 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset19, waferMapRenderer20);
        org.jfree.data.general.WaferMapDataset waferMapDataset22 = null;
        waferMapPlot21.setDataset(waferMapDataset22);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent24 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) waferMapPlot21);
        org.jfree.chart.JFreeChart jFreeChart25 = plotChangeEvent24.getChart();
        jFreeChart8.plotChanged(plotChangeEvent24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = null;
        java.awt.image.BufferedImage bufferedImage32 = jFreeChart8.createBufferedImage((int) (byte) 1, (int) (short) 100, (double) (short) 0, (double) (byte) 10, chartRenderingInfo31);
        java.awt.image.BufferedImage bufferedImage35 = jFreeChart8.createBufferedImage((int) 'a', (int) (byte) 10);
        java.awt.Color color36 = java.awt.Color.ORANGE;
        int int37 = color36.getGreen();
        jFreeChart8.setBackgroundPaint((java.awt.Paint) color36);
        java.awt.Stroke stroke39 = jFreeChart8.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = null;
        java.awt.image.BufferedImage bufferedImage45 = jFreeChart8.createBufferedImage((int) '#', 100, (double) 0, (double) (byte) 1, chartRenderingInfo44);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(legendTitle16);
        org.junit.Assert.assertNull(jFreeChart25);
        org.junit.Assert.assertNotNull(bufferedImage32);
        org.junit.Assert.assertNotNull(bufferedImage35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 200 + "'", int37 == 200);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(bufferedImage45);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxisForDataset((-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getAxisOffset();
        boolean boolean7 = categoryPlot0.isDomainZoomable();
        categoryPlot0.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = categoryPlot0.getDomainGridlinePosition();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(categoryAnchor10);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        org.jfree.data.general.WaferMapDataset waferMapDataset7 = null;
        waferMapPlot6.setDataset(waferMapDataset7);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) waferMapPlot6);
        categoryPlot0.notifyListeners(plotChangeEvent9);
        boolean boolean11 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.data.category.CategoryDataset categoryDataset13 = categoryPlot0.getDataset((int) (byte) 100);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(categoryDataset13);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("hi!", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getLabelLinkMargin();
        double double2 = piePlot3D0.getLabelGap();
        piePlot3D0.setDarkerSides(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        waferMapPlot4.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot4);
        jFreeChart9.setBackgroundImageAlpha(1.0f);
        jFreeChart9.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = jFreeChart9.getPadding();
        boolean boolean15 = jFreeChart9.isNotify();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart9, chartChangeEventType16);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str20 = textTitle19.getURLText();
        jFreeChart9.removeSubtitle((org.jfree.chart.title.Title) textTitle19);
        jFreeChart9.setBackgroundImageAlpha((float) 0L);
        jFreeChart9.setTextAntiAlias(true);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        try {
            jFreeChart9.draw(graphics2D26, rectangle2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean2 = numberAxis0.isAutoRange();
        numberAxis0.setLabelAngle((double) '4');
        org.jfree.data.RangeType rangeType5 = numberAxis0.getRangeType();
        double double6 = numberAxis0.getUpperMargin();
        numberAxis0.resizeRange((double) (short) -1, 0.14d);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint15 = categoryPlot14.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot14.zoomDomainAxes(8.0d, plotRenderingInfo18, point2D19);
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot14);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = legendTitle21.getLegendItemGraphicEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        try {
            org.jfree.chart.axis.AxisState axisState24 = numberAxis0.draw(graphics2D10, 0.0d, rectangle2D12, rectangle2D13, rectangleEdge22, plotRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rangeType5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color2 = java.awt.Color.ORANGE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer7 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6, waferMapRenderer7);
        org.jfree.data.general.WaferMapDataset waferMapDataset9 = null;
        waferMapPlot8.setDataset(waferMapDataset9);
        waferMapPlot8.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot8);
        jFreeChart13.setBackgroundImageAlpha(1.0f);
        jFreeChart13.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = jFreeChart13.getPadding();
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color3, stroke4, rectangleInsets18);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color2, stroke4);
        polarPlot0.setRadiusGridlineStroke(stroke4);
        polarPlot0.removeCornerTextItem("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        xYPlot24.clearDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset26 = xYPlot24.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = xYPlot24.getAxisOffset();
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint30 = textTitle29.getPaint();
        xYPlot24.setDomainGridlinePaint(paint30);
        boolean boolean32 = polarPlot0.equals((java.lang.Object) paint30);
        org.jfree.chart.axis.ValueAxis valueAxis33 = polarPlot0.getAxis();
        java.lang.String str34 = polarPlot0.getPlotType();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNull(xYDataset26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(valueAxis33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Polar Plot" + "'", str34.equals("Polar Plot"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getRGBComponents(floatArray1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        boolean boolean14 = jFreeChart8.isNotify();
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart8.getLegend(200);
        org.jfree.chart.title.LegendTitle legendTitle18 = jFreeChart8.getLegend((int) 'a');
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        try {
            jFreeChart8.handleClick((int) (short) 0, (int) (short) 10, chartRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(legendTitle16);
        org.junit.Assert.assertNull(legendTitle18);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        java.awt.Color color2 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint5 = textTitle4.getPaint();
        java.awt.Color color6 = java.awt.Color.red;
        java.awt.Color color7 = java.awt.Color.red;
        java.awt.Color color8 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color2, paint5, color6, color7, color8 };
        java.awt.Paint[] paintArray10 = null;
        java.awt.Stroke stroke11 = null;
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] { stroke11 };
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] {};
        java.awt.Shape shape14 = null;
        java.awt.Shape[] shapeArray15 = new java.awt.Shape[] { shape14 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray10, strokeArray12, strokeArray13, shapeArray15);
        java.awt.Stroke stroke17 = defaultDrawingSupplier16.getNextStroke();
        java.awt.Paint paint18 = defaultDrawingSupplier16.getNextFillPaint();
        java.awt.Paint paint19 = defaultDrawingSupplier16.getNextPaint();
        categoryPlot0.setRangeGridlinePaint(paint19);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset25 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer26 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot27 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset25, waferMapRenderer26);
        org.jfree.data.general.WaferMapDataset waferMapDataset28 = null;
        waferMapPlot27.setDataset(waferMapDataset28);
        float float30 = waferMapPlot27.getBackgroundImageAlpha();
        valueMarker24.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot27);
        java.awt.Font font32 = valueMarker24.getLabelFont();
        dateAxis22.setTickLabelFont(font32);
        org.jfree.data.Range range34 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis22);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset38 = categoryPlot0.getDataset(100);
        java.awt.Paint paint39 = categoryPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.5f + "'", float30 == 0.5f);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNull(categoryDataset38);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxisForDataset((-1));
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str9 = projectInfo8.getLicenceText();
        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo8.getLibraries();
        boolean boolean11 = categoryPlot0.equals((java.lang.Object) projectInfo8);
        projectInfo8.setCopyright("WMAP_Plot");
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(libraryArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getMaximumLabelWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean3 = piePlot3D0.equals((java.lang.Object) rectangleAnchor2);
        double double4 = piePlot3D0.getLabelLinkMargin();
        piePlot3D0.setIgnoreNullValues(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.14d + "'", double1 == 0.14d);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        dateAxis1.setAutoRangeMinimumSize((double) 10.0f, true);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline8 = dateAxis7.getTimeline();
        dateAxis1.setTimeline(timeline8);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(timeline8);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getNoDataMessagePaint();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot5.setRangeCrosshairStroke(stroke7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot5.getDomainAxisLocation();
        categoryPlot0.setRangeAxisLocation(axisLocation9);
        categoryPlot0.setWeight(1);
        int int13 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getInteriorGap();
        boolean boolean2 = piePlot3D0.getDarkerSides();
        java.awt.Color color3 = java.awt.Color.ORANGE;
        int int4 = color3.getGreen();
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color3.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        boolean boolean11 = piePlot3D0.equals((java.lang.Object) colorModel5);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator13 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat14 = standardPieSectionLabelGenerator13.getNumberFormat();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ThreadContext");
        java.text.AttributedString attributedString18 = standardPieSectionLabelGenerator16.getAttributedLabel((int) (byte) -1);
        java.text.NumberFormat numberFormat19 = standardPieSectionLabelGenerator16.getPercentFormat();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator20 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleEdge.TOP", numberFormat14, numberFormat19);
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint22 = ringPlot21.getLabelBackgroundPaint();
        boolean boolean23 = standardPieSectionLabelGenerator20.equals((java.lang.Object) ringPlot21);
        piePlot3D0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator20);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08d + "'", double1 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 200 + "'", int4 == 200);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(numberFormat14);
        org.junit.Assert.assertNull(attributedString18);
        org.junit.Assert.assertNotNull(numberFormat19);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        java.lang.String str2 = numberAxis0.getLabelURL();
        numberAxis0.setFixedAutoRange((double) 0);
        java.awt.Paint paint5 = numberAxis0.getTickMarkPaint();
        numberAxis0.configure();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        java.lang.Object obj3 = null;
        boolean boolean4 = categoryPlot0.equals(obj3);
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(axisSpace6);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getMaximumLabelWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean3 = piePlot3D0.equals((java.lang.Object) rectangleAnchor2);
        double double4 = piePlot3D0.getLabelLinkMargin();
        java.awt.Color color9 = java.awt.Color.gray;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((double) 0.5f, (double) (byte) -1, 0.0d, (double) (byte) 0, (java.awt.Paint) color9);
        boolean boolean11 = piePlot3D0.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.14d + "'", double1 == 0.14d);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean2 = numberAxis0.isAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean4 = numberAxis3.getAutoRangeIncludesZero();
        boolean boolean5 = numberAxis3.isAutoRange();
        numberAxis3.setLabelAngle((double) '4');
        org.jfree.data.RangeType rangeType8 = numberAxis3.getRangeType();
        numberAxis0.setRangeType(rangeType8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rangeType8);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 1, 0);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str8 = categoryAxis3D7.getLabelURL();
        double double9 = categoryAxis3D7.getCategoryMargin();
        java.lang.Object obj10 = categoryAxis3D7.clone();
        categoryAxis3D7.setCategoryMargin((double) 10L);
        java.util.List list13 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D7);
        float float14 = categoryAxis3D7.getTickMarkInsideLength();
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("ChartChangeEventType.DATASET_UPDATED");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D3.setTickLabelFont((java.lang.Comparable) (short) 10, font5);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("", font5);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement16 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment12, verticalAlignment13, (double) 10L, (double) 100.0f);
        java.lang.Object obj17 = null;
        boolean boolean18 = verticalAlignment13.equals(obj17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.data.general.WaferMapDataset waferMapDataset21 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer22 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot23 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset21, waferMapRenderer22);
        org.jfree.data.general.WaferMapDataset waferMapDataset24 = null;
        waferMapPlot23.setDataset(waferMapDataset24);
        waferMapPlot23.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot23);
        jFreeChart28.setBackgroundImageAlpha(1.0f);
        jFreeChart28.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = jFreeChart28.getPadding();
        boolean boolean34 = jFreeChart28.isNotify();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType35 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent36 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color19, jFreeChart28, chartChangeEventType35);
        org.jfree.chart.JFreeChart jFreeChart37 = chartChangeEvent36.getChart();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType38 = chartChangeEvent36.getType();
        boolean boolean39 = verticalAlignment13.equals((java.lang.Object) chartChangeEvent36);
        org.jfree.chart.block.FlowArrangement flowArrangement42 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment11, verticalAlignment13, (-9.0d), (double) 0);
        org.jfree.chart.util.UnitType unitType43 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = new org.jfree.chart.util.RectangleInsets(unitType43, (double) '4', (double) 200, (double) 1, (double) 10.0f);
        double double49 = rectangleInsets48.getLeft();
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle("RectangleAnchor.BOTTOM_LEFT", font5, (java.awt.Paint) color8, rectangleEdge9, horizontalAlignment10, verticalAlignment13, rectangleInsets48);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jFreeChart37);
        org.junit.Assert.assertNull(chartChangeEventType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(unitType43);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 200.0d + "'", double49 == 200.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        boolean boolean2 = ringPlot0.isCircular();
        java.awt.Paint paint3 = ringPlot0.getSeparatorPaint();
        ringPlot0.setSectionOutlinesVisible(false);
        boolean boolean6 = ringPlot0.getSeparatorsVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean2 = numberAxis0.isAutoRange();
        numberAxis0.setLabelAngle((double) '4');
        numberAxis0.configure();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color2 = java.awt.Color.ORANGE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer7 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6, waferMapRenderer7);
        org.jfree.data.general.WaferMapDataset waferMapDataset9 = null;
        waferMapPlot8.setDataset(waferMapDataset9);
        waferMapPlot8.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot8);
        jFreeChart13.setBackgroundImageAlpha(1.0f);
        jFreeChart13.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = jFreeChart13.getPadding();
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color3, stroke4, rectangleInsets18);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color2, stroke4);
        polarPlot0.setRadiusGridlineStroke(stroke4);
        java.awt.Stroke stroke22 = polarPlot0.getRadiusGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint27 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot26.setRangeZeroBaselinePaint(paint27);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray30 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer29 };
        xYPlot26.setRenderers(xYItemRendererArray30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        xYPlot26.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo34, point2D35);
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        xYPlot26.setFixedRangeAxisSpace(axisSpace37);
        java.awt.Stroke stroke39 = xYPlot26.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D40 = xYPlot26.getQuadrantOrigin();
        polarPlot0.zoomDomainAxes(0.05d, 0.05d, plotRenderingInfo25, point2D40);
        java.awt.Image image42 = polarPlot0.getBackgroundImage();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(xYItemRendererArray30);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(point2D40);
        org.junit.Assert.assertNull(image42);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection4);
        categoryPlot0.configureRangeAxes();
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        java.util.Date date3 = dateAxis1.getMinimumDate();
        org.jfree.data.Range range4 = null;
        try {
            dateAxis1.setDefaultAutoRange(range4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textBlock0.getLineAlignment();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        piePlot3D1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        int int4 = color2.getTransparency();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(8.0d, plotRenderingInfo4, point2D5);
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        boolean boolean8 = categoryPlot0.isSubplot();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.Color color5 = java.awt.Color.getColor("", color4);
        int int6 = color4.getRGB();
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace8);
        int int10 = xYPlot0.getDatasetCount();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        java.awt.Shape shape14 = dateAxis12.getUpArrow();
        dateAxis12.centerRange((double) (short) 1);
        dateAxis12.setRange(0.0d, (double) '#');
        org.jfree.data.Range range22 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis12.setRange(range22, false, false);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis12);
        java.awt.Stroke stroke27 = xYPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = piePlotState1.getExplodedPieArea();
        piePlotState1.setPassesRequired(2);
        double double5 = piePlotState1.getTotal();
        java.awt.geom.Rectangle2D rectangle2D6 = piePlotState1.getLinkArea();
        org.junit.Assert.assertNull(rectangle2D2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D6);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 1, 0);
        categoryPlot0.setDrawSharedDomainAxis(true);
        java.awt.Paint paint6 = null;
        categoryPlot0.setOutlinePaint(paint6);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace2 = xYPlot0.getFixedRangeAxisSpace();
        boolean boolean3 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Stroke stroke5 = null;
        try {
            xYPlot0.setRangeZeroBaselineStroke(stroke5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0, (double) 100.0f);
        size2D2.width = 0.0d;
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        double double2 = categoryAxis3D1.getCategoryMargin();
        java.awt.Font font3 = categoryAxis3D1.getLabelFont();
        boolean boolean4 = categoryAxis3D1.isTickLabelsVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxisForDataset((-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getAxisOffset();
        boolean boolean7 = categoryPlot0.isDomainZoomable();
        categoryPlot0.setRangeCrosshairVisible(false);
        java.lang.Object obj10 = categoryPlot0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getURLText();
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle1.setBackgroundPaint(paint3);
        textTitle1.setHeight((double) ' ');
        org.jfree.chart.util.Size2D size2D7 = new org.jfree.chart.util.Size2D();
        boolean boolean8 = textTitle1.equals((java.lang.Object) size2D7);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        textTitle1.setVerticalAlignment(verticalAlignment9);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(verticalAlignment9);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        double double1 = rotation0.getFactor();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0, (double) 100.0f);
        double double3 = size2D2.width;
        double double4 = size2D2.width;
        double double5 = size2D2.width;
        size2D2.width = (byte) 1;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot8.setRangeZeroBaselinePaint(paint9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray12 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer11 };
        xYPlot8.setRenderers(xYItemRendererArray12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        xYPlot8.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo16, point2D17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        xYPlot8.setFixedRangeAxisSpace(axisSpace19);
        java.awt.Stroke stroke21 = xYPlot8.getDomainCrosshairStroke();
        java.awt.Stroke stroke22 = xYPlot8.getDomainCrosshairStroke();
        org.jfree.chart.axis.AxisSpace axisSpace23 = xYPlot8.getFixedDomainAxisSpace();
        boolean boolean24 = size2D2.equals((java.lang.Object) axisSpace23);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(xYItemRendererArray12);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(axisSpace23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color6 = java.awt.Color.ORANGE;
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer11 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset10, waferMapRenderer11);
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        waferMapPlot12.setDataset(waferMapDataset13);
        waferMapPlot12.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot12);
        jFreeChart17.setBackgroundImageAlpha(1.0f);
        jFreeChart17.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = jFreeChart17.getPadding();
        org.jfree.chart.block.LineBorder lineBorder23 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color7, stroke8, rectangleInsets22);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color6, stroke8);
        polarPlot4.setRadiusGridlineStroke(stroke8);
        polarPlot4.removeCornerTextItem("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.plot.RingPlot ringPlot28 = new org.jfree.chart.plot.RingPlot();
        ringPlot28.setIgnoreZeroValues(true);
        java.awt.Stroke stroke31 = ringPlot28.getLabelLinkStroke();
        polarPlot4.setOutlineStroke(stroke31);
        polarPlot4.setAngleLabelsVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean38 = polarPlot37.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint42 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot41.setRangeZeroBaselinePaint(paint42);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray45 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer44 };
        xYPlot41.setRenderers(xYItemRendererArray45);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        java.awt.geom.Point2D point2D50 = null;
        xYPlot41.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo49, point2D50);
        org.jfree.chart.axis.AxisSpace axisSpace52 = null;
        xYPlot41.setFixedRangeAxisSpace(axisSpace52);
        java.awt.Stroke stroke54 = xYPlot41.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D55 = xYPlot41.getQuadrantOrigin();
        polarPlot37.zoomDomainAxes(1.0E-8d, plotRenderingInfo40, point2D55);
        polarPlot4.zoomDomainAxes((double) 100.0f, plotRenderingInfo36, point2D55);
        categoryPlot0.zoomDomainAxes((double) 10, plotRenderingInfo3, point2D55);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(xYItemRendererArray45);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(point2D55);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 10L, (double) 100.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot5.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomDomainAxes(8.0d, plotRenderingInfo9, point2D10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot5);
        java.awt.Font font13 = legendTitle12.getItemFont();
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset17 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer18 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot19 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset17, waferMapRenderer18);
        org.jfree.data.general.WaferMapDataset waferMapDataset20 = null;
        waferMapPlot19.setDataset(waferMapDataset20);
        waferMapPlot19.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot19);
        jFreeChart24.setBackgroundImageAlpha(1.0f);
        jFreeChart24.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = jFreeChart24.getPadding();
        org.jfree.chart.block.LineBorder lineBorder30 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color14, stroke15, rectangleInsets29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = lineBorder30.getInsets();
        columnArrangement4.add((org.jfree.chart.block.Block) legendTitle12, (java.lang.Object) rectangleInsets31);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape35 = dateAxis34.getDownArrow();
        java.awt.Shape shape36 = dateAxis34.getUpArrow();
        dateAxis34.centerRange((double) (short) 1);
        dateAxis34.setRange(0.0d, (double) '#');
        org.jfree.chart.axis.TickUnitSource tickUnitSource42 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis34.setStandardTickUnits(tickUnitSource42);
        java.lang.Object obj44 = dateAxis34.clone();
        boolean boolean45 = legendTitle12.equals((java.lang.Object) dateAxis34);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(tickUnitSource42);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = null;
        try {
            numberAxis0.setTickUnit(numberTickUnit3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isAngleGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        polarPlot0.setDataset(xYDataset2);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = polarPlot0.getRenderer();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        boolean boolean6 = polarPlot0.equals((java.lang.Object) textBlockAnchor5);
        java.awt.Stroke stroke7 = polarPlot0.getAngleGridlineStroke();
        java.awt.Stroke stroke8 = polarPlot0.getAngleGridlineStroke();
        polarPlot0.setAngleLabelsVisible(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(polarItemRenderer4);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint2 = categoryPlot1.getNoDataMessagePaint();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot1.setRangeCrosshairStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot1.getDomainAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation5, plotOrientation6);
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getURLText();
        java.lang.String str3 = textTitle1.getURLText();
        double double4 = textTitle1.getContentYOffset();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle1.getTextAlignment();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.Object obj1 = ringPlot0.clone();
        double double2 = ringPlot0.getMaximumExplodePercent();
        double double3 = ringPlot0.getInnerSeparatorExtension();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint5 = ringPlot4.getLabelBackgroundPaint();
        ringPlot4.setShadowXOffset((double) (-1.0f));
        org.jfree.chart.util.Rotation rotation8 = ringPlot4.getDirection();
        java.lang.String str9 = rotation8.toString();
        ringPlot0.setDirection(rotation8);
        java.awt.Font font11 = ringPlot0.getLabelFont();
        java.awt.Paint paint12 = null;
        try {
            ringPlot0.setLabelPaint(paint12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rotation8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Rotation.CLOCKWISE" + "'", str9.equals("Rotation.CLOCKWISE"));
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D2.setTickLabelFont((java.lang.Comparable) (short) 10, font4);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font4, paint6);
        org.jfree.chart.text.TextLine textLine8 = textBlock7.getLastLine();
        boolean boolean10 = textBlock7.equals((java.lang.Object) "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=90.0]");
        java.util.List list11 = textBlock7.getLines();
        org.jfree.chart.text.TextLine textLine12 = textBlock7.getLastLine();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(textLine8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(textLine12);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color2 = java.awt.Color.ORANGE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer7 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6, waferMapRenderer7);
        org.jfree.data.general.WaferMapDataset waferMapDataset9 = null;
        waferMapPlot8.setDataset(waferMapDataset9);
        waferMapPlot8.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot8);
        jFreeChart13.setBackgroundImageAlpha(1.0f);
        jFreeChart13.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = jFreeChart13.getPadding();
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color3, stroke4, rectangleInsets18);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color2, stroke4);
        polarPlot0.setRadiusGridlineStroke(stroke4);
        polarPlot0.removeCornerTextItem("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        ringPlot24.setIgnoreZeroValues(true);
        java.awt.Stroke stroke27 = ringPlot24.getLabelLinkStroke();
        polarPlot0.setOutlineStroke(stroke27);
        polarPlot0.setAngleLabelsVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.plot.PolarPlot polarPlot33 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean34 = polarPlot33.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint38 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot37.setRangeZeroBaselinePaint(paint38);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray41 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer40 };
        xYPlot37.setRenderers(xYItemRendererArray41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        java.awt.geom.Point2D point2D46 = null;
        xYPlot37.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo45, point2D46);
        org.jfree.chart.axis.AxisSpace axisSpace48 = null;
        xYPlot37.setFixedRangeAxisSpace(axisSpace48);
        java.awt.Stroke stroke50 = xYPlot37.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D51 = xYPlot37.getQuadrantOrigin();
        polarPlot33.zoomDomainAxes(1.0E-8d, plotRenderingInfo36, point2D51);
        polarPlot0.zoomDomainAxes((double) 100.0f, plotRenderingInfo32, point2D51);
        boolean boolean54 = polarPlot0.isRadiusGridlinesVisible();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(xYItemRendererArray41);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(point2D51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.Object obj1 = ringPlot0.clone();
        double double2 = ringPlot0.getMaximumExplodePercent();
        double double3 = ringPlot0.getInnerSeparatorExtension();
        boolean boolean4 = ringPlot0.getIgnoreNullValues();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        ringPlot0.setInsets(rectangleInsets5);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator8 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Range[100.0,100.0]");
        ringPlot0.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator8);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = piePlotState1.getExplodedPieArea();
        piePlotState1.setPassesRequired(2);
        double double5 = piePlotState1.getPieWRadius();
        double double6 = piePlotState1.getPieCenterX();
        org.junit.Assert.assertNull(rectangle2D2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getURLText();
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle1.setBackgroundPaint(paint3);
        textTitle1.setHeight((double) ' ');
        org.jfree.chart.util.Size2D size2D7 = new org.jfree.chart.util.Size2D();
        boolean boolean8 = textTitle1.equals((java.lang.Object) size2D7);
        double double9 = size2D7.getWidth();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint11 = categoryPlot10.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = null;
        categoryPlot10.setFixedLegendItems(legendItemCollection12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot10.getRangeAxisForDataset((-1));
        categoryPlot10.setDomainGridlinesVisible(false);
        org.jfree.chart.ui.ProjectInfo projectInfo18 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str19 = projectInfo18.getLicenceText();
        org.jfree.chart.ui.Library[] libraryArray20 = projectInfo18.getLibraries();
        boolean boolean21 = categoryPlot10.equals((java.lang.Object) projectInfo18);
        java.lang.String str22 = projectInfo18.toString();
        boolean boolean23 = size2D7.equals((java.lang.Object) projectInfo18);
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str26 = textTitle25.getURLText();
        java.awt.Paint paint27 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle25.setBackgroundPaint(paint27);
        textTitle25.setHeight((double) ' ');
        org.jfree.chart.util.Size2D size2D31 = new org.jfree.chart.util.Size2D();
        boolean boolean32 = textTitle25.equals((java.lang.Object) size2D31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = textTitle25.getMargin();
        boolean boolean34 = size2D7.equals((java.lang.Object) textTitle25);
        java.lang.String str35 = size2D7.toString();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(libraryArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str22.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str35.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 1.0E-8d, (double) 10, 0, (java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setAxisLineVisible(false);
        java.awt.Font font4 = dateAxis1.getLabelFont();
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 1, 0);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str8 = categoryAxis3D7.getLabelURL();
        double double9 = categoryAxis3D7.getCategoryMargin();
        java.lang.Object obj10 = categoryAxis3D7.clone();
        categoryAxis3D7.setCategoryMargin((double) 10L);
        java.util.List list13 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D7);
        int int14 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot0.getRenderer(0);
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double16 = rectangleInsets14.calculateBottomInset(0.0d);
        xYPlot0.setAxisOffset(rectangleInsets14);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        categoryPlot0.setAnchorValue(0.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str6 = textTitle5.getURLText();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle5.setBackgroundPaint(paint7);
        categoryPlot0.setDomainGridlinePaint(paint7);
        boolean boolean10 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot0.getLegendItems();
        java.awt.Image image12 = categoryPlot0.getBackgroundImage();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNull(image12);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint16 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot15.setRangeZeroBaselinePaint(paint16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray19 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer18 };
        xYPlot15.setRenderers(xYItemRendererArray19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot15.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo23, point2D24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        xYPlot15.setFixedRangeAxisSpace(axisSpace26);
        java.awt.Stroke stroke28 = xYPlot15.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D29 = xYPlot15.getQuadrantOrigin();
        xYPlot0.zoomDomainAxes((double) 10.0f, (double) 2.0f, plotRenderingInfo14, point2D29);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = xYPlot0.getDomainMarkers(layer31);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(xYItemRendererArray19);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertNull(collection32);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        java.lang.Object obj3 = null;
        boolean boolean4 = categoryPlot0.equals(obj3);
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomRangeAxes(4.0d, plotRenderingInfo7, point2D8);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str12 = categoryAxis3D11.getLabelURL();
        double double13 = categoryAxis3D11.getCategoryMargin();
        categoryAxis3D11.setLabelURL("RectangleEdge.TOP");
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str18 = textTitle17.getURLText();
        java.awt.Paint paint19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle17.setBackgroundPaint(paint19);
        java.lang.String str21 = textTitle17.getURLText();
        boolean boolean22 = categoryAxis3D11.equals((java.lang.Object) str21);
        boolean boolean23 = categoryAxis3D11.isTickLabelsVisible();
        categoryPlot0.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D11);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.LegendItemCollection legendItemCollection29 = null;
        categoryPlot25.setFixedLegendItems(legendItemCollection29);
        org.jfree.chart.plot.PlotOrientation plotOrientation31 = categoryPlot25.getOrientation();
        categoryPlot25.setBackgroundImageAlignment((int) (short) 100);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = textTitle35.getPadding();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = textTitle35.getTextAlignment();
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint39 = categoryPlot38.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation40 = categoryPlot38.getDomainAxisLocation();
        boolean boolean41 = horizontalAlignment37.equals((java.lang.Object) categoryPlot38);
        org.jfree.chart.plot.Plot plot42 = categoryPlot38.getParent();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor43 = categoryPlot38.getDomainGridlinePosition();
        categoryPlot25.setDomainGridlinePosition(categoryAnchor43);
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint49 = categoryPlot48.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection50 = null;
        categoryPlot48.setFixedLegendItems(legendItemCollection50);
        org.jfree.chart.axis.ValueAxis valueAxis53 = categoryPlot48.getRangeAxisForDataset((-1));
        categoryPlot48.setDomainGridlinesVisible(false);
        org.jfree.chart.ui.ProjectInfo projectInfo56 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str57 = projectInfo56.getLicenceText();
        org.jfree.chart.ui.Library[] libraryArray58 = projectInfo56.getLibraries();
        boolean boolean59 = categoryPlot48.equals((java.lang.Object) projectInfo56);
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = categoryPlot48.getDomainAxisEdge(0);
        try {
            double double62 = categoryAxis3D11.getCategoryJava2DCoordinate(categoryAnchor43, (int) '4', 500, rectangle2D47, rectangleEdge61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.2d + "'", double13 == 0.2d);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(plotOrientation31);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(plot42);
        org.junit.Assert.assertNotNull(categoryAnchor43);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNull(valueAxis53);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertNotNull(libraryArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleEdge61);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint12 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot11.setRangeZeroBaselinePaint(paint12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray15 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer14 };
        xYPlot11.setRenderers(xYItemRendererArray15);
        xYPlot0.setRenderers(xYItemRendererArray15);
        org.jfree.chart.plot.Plot plot18 = xYPlot0.getParent();
        java.awt.Stroke stroke19 = xYPlot0.getRangeGridlineStroke();
        boolean boolean20 = xYPlot0.isDomainGridlinesVisible();
        java.lang.String str21 = xYPlot0.getNoDataMessage();
        java.lang.String str22 = xYPlot0.getNoDataMessage();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(xYItemRendererArray15);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        ringPlot0.setShadowXOffset((double) (-1.0f));
        org.jfree.chart.util.Rotation rotation4 = ringPlot0.getDirection();
        org.jfree.data.general.WaferMapDataset waferMapDataset7 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer8 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset7, waferMapRenderer8);
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        waferMapPlot9.setDataset(waferMapDataset10);
        waferMapPlot9.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot9);
        jFreeChart14.setBackgroundImageAlpha(1.0f);
        jFreeChart14.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = jFreeChart14.getPadding();
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = textTitle21.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = textTitle21.getPosition();
        jFreeChart14.setTitle(textTitle21);
        java.awt.Color color25 = java.awt.Color.gray;
        jFreeChart14.setBackgroundPaint((java.awt.Paint) color25);
        java.awt.Stroke stroke27 = jFreeChart14.getBorderStroke();
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) 0, stroke27);
        boolean boolean30 = ringPlot0.equals((java.lang.Object) 1.0E-8d);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator31 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator31);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator33 = null;
        ringPlot0.setURLGenerator(pieURLGenerator33);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setRangeCrosshairValue((double) 200, false);
        boolean boolean5 = categoryPlot1.isRangeCrosshairVisible();
        java.awt.Color color7 = java.awt.Color.white;
        java.awt.Color color8 = java.awt.Color.getColor("", color7);
        categoryPlot1.setNoDataMessagePaint((java.awt.Paint) color7);
        piePlot3D0.setLabelLinkPaint((java.awt.Paint) color7);
        double double11 = piePlot3D0.getDepthFactor();
        piePlot3D0.setNoDataMessage("RectangleAnchor.BOTTOM_LEFT");
        piePlot3D0.setDepthFactor((double) 15);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.12d + "'", double11 == 0.12d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        waferMapPlot4.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot4);
        jFreeChart9.setBackgroundImageAlpha(1.0f);
        jFreeChart9.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = jFreeChart9.getPadding();
        boolean boolean15 = jFreeChart9.isNotify();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart9, chartChangeEventType16);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str20 = textTitle19.getURLText();
        jFreeChart9.removeSubtitle((org.jfree.chart.title.Title) textTitle19);
        double double22 = textTitle19.getWidth();
        org.jfree.chart.StrokeMap strokeMap23 = new org.jfree.chart.StrokeMap();
        strokeMap23.clear();
        boolean boolean25 = textTitle19.equals((java.lang.Object) strokeMap23);
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = textTitle29.getPadding();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment31 = textTitle29.getTextAlignment();
        textTitle27.setHorizontalAlignment(horizontalAlignment31);
        textTitle19.setTextAlignment(horizontalAlignment31);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor35 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 10);
        int int36 = pieLabelDistributor35.getItemCount();
        java.lang.String str37 = pieLabelDistributor35.toString();
        pieLabelDistributor35.clear();
        boolean boolean39 = horizontalAlignment31.equals((java.lang.Object) pieLabelDistributor35);
        pieLabelDistributor35.sort();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(horizontalAlignment31);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        float float7 = waferMapPlot4.getBackgroundImageAlpha();
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot4);
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer11 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset10, waferMapRenderer11);
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        waferMapPlot12.setDataset(waferMapDataset13);
        waferMapPlot12.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot12);
        jFreeChart17.setBackgroundImageAlpha(1.0f);
        jFreeChart17.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = jFreeChart17.getPadding();
        boolean boolean23 = jFreeChart17.isNotify();
        waferMapPlot4.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart17);
        jFreeChart17.removeLegend();
        jFreeChart17.setBackgroundImageAlpha((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.block.Arrangement arrangement2 = blockContainer1.getArrangement();
        org.jfree.chart.block.Block block3 = null;
        java.lang.Object obj4 = null;
        blockContainer1.add(block3, obj4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getURLText();
        java.awt.Paint paint9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle7.setBackgroundPaint(paint9);
        textTitle7.setHeight((double) ' ');
        org.jfree.chart.util.Size2D size2D13 = new org.jfree.chart.util.Size2D();
        boolean boolean14 = textTitle7.equals((java.lang.Object) size2D13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = textTitle7.getMargin();
        blockContainer1.add((org.jfree.chart.block.Block) textTitle7);
        org.junit.Assert.assertNotNull(arrangement2);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        java.awt.Shape shape7 = dateAxis5.getUpArrow();
        dateAxis5.centerRange((double) (short) 1);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer14 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot15 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset13, waferMapRenderer14);
        org.jfree.data.general.WaferMapDataset waferMapDataset16 = null;
        waferMapPlot15.setDataset(waferMapDataset16);
        waferMapPlot15.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot15);
        jFreeChart20.setBackgroundImageAlpha(1.0f);
        jFreeChart20.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = jFreeChart20.getPadding();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color10, stroke11, rectangleInsets25);
        dateAxis5.setTickMarkStroke(stroke11);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer28);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis31 = xYPlot29.getDomainAxisForDataset((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 1 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getFirstTextFragment();
        org.jfree.chart.text.TextFragment textFragment3 = textLine1.getFirstTextFragment();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        try {
            textFragment3.draw(graphics2D4, (float) 2, (float) 10L, textAnchor7, (float) (-16711681), (float) 100L, (double) 0.5f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textFragment2);
        org.junit.Assert.assertNotNull(textFragment3);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        boolean boolean6 = dateAxis1.isPositiveArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        java.awt.Shape shape10 = dateAxis8.getUpArrow();
        dateAxis8.centerRange((double) (short) 1);
        dateAxis8.setRange(0.0d, (double) '#');
        dateAxis8.setAutoRange(false);
        dateAxis8.setRangeWithMargins((double) 'a', (double) 100.0f);
        java.awt.Font font21 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        dateAxis8.setTickLabelFont(font21);
        dateAxis1.setLabelFont(font21);
        try {
            dateAxis1.setRangeAboutValue((double) (-1), (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (-0.5) <= upper (-1.5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font21);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getMaximumLabelWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean3 = piePlot3D0.equals((java.lang.Object) rectangleAnchor2);
        double double4 = piePlot3D0.getLabelLinkMargin();
        java.lang.String str5 = piePlot3D0.getPlotType();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.14d + "'", double1 == 0.14d);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie 3D Plot" + "'", str5.equals("Pie 3D Plot"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean2 = numberAxis0.isAutoRange();
        numberAxis0.setLabelAngle((double) '4');
        java.awt.Shape shape5 = numberAxis0.getUpArrow();
        numberAxis0.setAutoRangeStickyZero(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape14 = dateAxis13.getDownArrow();
        java.awt.Shape shape15 = dateAxis13.getUpArrow();
        dateAxis13.centerRange((double) (short) 1);
        dateAxis13.setRange(0.0d, (double) '#');
        dateAxis13.setAutoRange(false);
        categoryPlot8.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis13);
        java.lang.String str24 = categoryPlot8.getPlotType();
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot8.getDomainMarkers((int) (short) 1, layer26);
        boolean boolean28 = categoryPlot8.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape32 = dateAxis31.getDownArrow();
        java.awt.Shape shape33 = dateAxis31.getUpArrow();
        dateAxis31.centerRange((double) (short) 1);
        dateAxis31.setRange(0.0d, (double) '#');
        org.jfree.chart.axis.TickUnitSource tickUnitSource39 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis31.setStandardTickUnits(tickUnitSource39);
        org.jfree.chart.plot.Plot plot41 = dateAxis31.getPlot();
        boolean boolean42 = dateAxis31.isInverted();
        dateAxis31.setRangeAboutValue(0.0d, (double) 10);
        categoryPlot8.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) dateAxis31);
        java.util.TimeZone timeZone47 = dateAxis31.getTimeZone();
        boolean boolean48 = numberAxis0.equals((java.lang.Object) timeZone47);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Category Plot" + "'", str24.equals("Category Plot"));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(tickUnitSource39);
        org.junit.Assert.assertNull(plot41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource9);
        java.lang.Object obj11 = dateAxis1.clone();
        dateAxis1.zoomRange(0.0d, 100.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        java.awt.Color color0 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint3 = textTitle2.getPaint();
        java.awt.Color color4 = java.awt.Color.red;
        java.awt.Color color5 = java.awt.Color.red;
        java.awt.Color color6 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color0, paint3, color4, color5, color6 };
        java.awt.Paint[] paintArray8 = null;
        java.awt.Stroke stroke9 = null;
        java.awt.Stroke[] strokeArray10 = new java.awt.Stroke[] { stroke9 };
        java.awt.Stroke[] strokeArray11 = new java.awt.Stroke[] {};
        java.awt.Shape shape12 = null;
        java.awt.Shape[] shapeArray13 = new java.awt.Shape[] { shape12 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray8, strokeArray10, strokeArray11, shapeArray13);
        java.awt.Stroke stroke15 = defaultDrawingSupplier14.getNextStroke();
        java.awt.Paint paint16 = defaultDrawingSupplier14.getNextFillPaint();
        java.awt.Paint paint17 = defaultDrawingSupplier14.getNextPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint19 = categoryPlot18.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection20 = null;
        categoryPlot18.setFixedLegendItems(legendItemCollection20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot18.getDomainAxisEdge((int) (byte) 10);
        boolean boolean24 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint17, (java.lang.Object) categoryPlot18);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        boolean boolean29 = categoryPlot18.render(graphics2D25, rectangle2D26, (int) 'a', plotRenderingInfo28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot32.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape38 = dateAxis37.getDownArrow();
        java.awt.Shape shape39 = dateAxis37.getUpArrow();
        dateAxis37.centerRange((double) (short) 1);
        dateAxis37.setRange(0.0d, (double) '#');
        dateAxis37.setAutoRange(false);
        categoryPlot32.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis37);
        java.lang.String str48 = categoryPlot32.getPlotType();
        org.jfree.chart.util.Layer layer50 = null;
        java.util.Collection collection51 = categoryPlot32.getDomainMarkers((int) (short) 1, layer50);
        boolean boolean52 = categoryPlot32.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint57 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot56.setRangeZeroBaselinePaint(paint57);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer59 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray60 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer59 };
        xYPlot56.setRenderers(xYItemRendererArray60);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        java.awt.geom.Point2D point2D65 = null;
        xYPlot56.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo64, point2D65);
        org.jfree.chart.axis.AxisSpace axisSpace67 = null;
        xYPlot56.setFixedRangeAxisSpace(axisSpace67);
        xYPlot56.clearDomainMarkers(1);
        org.jfree.chart.axis.ValueAxis valueAxis72 = xYPlot56.getRangeAxis(0);
        java.awt.geom.Point2D point2D73 = xYPlot56.getQuadrantOrigin();
        categoryPlot32.zoomDomainAxes((double) 100.0f, (double) (short) 1, plotRenderingInfo55, point2D73);
        categoryPlot18.zoomRangeAxes(0.4d, plotRenderingInfo31, point2D73);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(strokeArray11);
        org.junit.Assert.assertNotNull(shapeArray13);
        org.junit.Assert.assertNull(stroke15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Category Plot" + "'", str48.equals("Category Plot"));
        org.junit.Assert.assertNull(collection51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(xYItemRendererArray60);
        org.junit.Assert.assertNull(valueAxis72);
        org.junit.Assert.assertNotNull(point2D73);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer6 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset5, waferMapRenderer6);
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        waferMapPlot7.setDataset(waferMapDataset8);
        waferMapPlot7.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot7);
        jFreeChart12.setBackgroundImageAlpha(1.0f);
        jFreeChart12.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = jFreeChart12.getPadding();
        org.jfree.chart.block.LineBorder lineBorder18 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color2, stroke3, rectangleInsets17);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color1, stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = valueMarker19.getLabelOffset();
        org.jfree.data.general.WaferMapDataset waferMapDataset21 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer22 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot23 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset21, waferMapRenderer22);
        org.jfree.data.general.WaferMapDataset waferMapDataset24 = null;
        waferMapPlot23.setDataset(waferMapDataset24);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) waferMapPlot23);
        org.jfree.chart.plot.Plot plot27 = plotChangeEvent26.getPlot();
        java.lang.Class<?> wildcardClass28 = plot27.getClass();
        java.util.EventListener[] eventListenerArray29 = valueMarker19.getListeners((java.lang.Class) wildcardClass28);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(plot27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(eventListenerArray29);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getPadding();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle1.getTextAlignment();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer7 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6, waferMapRenderer7);
        org.jfree.data.general.WaferMapDataset waferMapDataset9 = null;
        waferMapPlot8.setDataset(waferMapDataset9);
        float float11 = waferMapPlot8.getBackgroundImageAlpha();
        java.lang.Object obj12 = textTitle1.draw(graphics2D4, rectangle2D5, (java.lang.Object) waferMapPlot8);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.setRangeCrosshairValue((double) 200, false);
        boolean boolean17 = categoryPlot13.isRangeCrosshairVisible();
        java.awt.Color color19 = java.awt.Color.white;
        java.awt.Color color20 = java.awt.Color.getColor("", color19);
        categoryPlot13.setNoDataMessagePaint((java.awt.Paint) color19);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryPlot13.getAxisOffset();
        waferMapPlot8.setInsets(rectangleInsets22);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection24 = waferMapPlot8.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.Color color3 = java.awt.Color.getColor("", color2);
        ringPlot0.setLabelPaint((java.awt.Paint) color3);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = ringPlot0.getLegendLabelToolTipGenerator();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint9 = categoryPlot8.getNoDataMessagePaint();
        categoryPlot8.setAnchorValue(0.0d);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str14 = textTitle13.getURLText();
        java.awt.Paint paint15 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle13.setBackgroundPaint(paint15);
        categoryPlot8.setDomainGridlinePaint(paint15);
        boolean boolean18 = categoryPlot8.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        org.jfree.chart.plot.PolarPlot polarPlot22 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset28 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer29 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot30 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset28, waferMapRenderer29);
        org.jfree.data.general.WaferMapDataset waferMapDataset31 = null;
        waferMapPlot30.setDataset(waferMapDataset31);
        waferMapPlot30.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot30);
        jFreeChart35.setBackgroundImageAlpha(1.0f);
        jFreeChart35.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = jFreeChart35.getPadding();
        org.jfree.chart.block.LineBorder lineBorder41 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color25, stroke26, rectangleInsets40);
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color24, stroke26);
        polarPlot22.setRadiusGridlineStroke(stroke26);
        polarPlot22.removeCornerTextItem("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.plot.RingPlot ringPlot46 = new org.jfree.chart.plot.RingPlot();
        ringPlot46.setIgnoreZeroValues(true);
        java.awt.Stroke stroke49 = ringPlot46.getLabelLinkStroke();
        polarPlot22.setOutlineStroke(stroke49);
        polarPlot22.setAngleLabelsVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.chart.plot.PolarPlot polarPlot55 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean56 = polarPlot55.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint60 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot59.setRangeZeroBaselinePaint(paint60);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer62 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray63 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer62 };
        xYPlot59.setRenderers(xYItemRendererArray63);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = null;
        java.awt.geom.Point2D point2D68 = null;
        xYPlot59.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo67, point2D68);
        org.jfree.chart.axis.AxisSpace axisSpace70 = null;
        xYPlot59.setFixedRangeAxisSpace(axisSpace70);
        java.awt.Stroke stroke72 = xYPlot59.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D73 = xYPlot59.getQuadrantOrigin();
        polarPlot55.zoomDomainAxes(1.0E-8d, plotRenderingInfo58, point2D73);
        polarPlot22.zoomDomainAxes((double) 100.0f, plotRenderingInfo54, point2D73);
        categoryPlot8.zoomDomainAxes((double) (byte) -1, (double) (short) -1, plotRenderingInfo21, point2D73);
        org.jfree.chart.plot.PlotState plotState77 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo78 = null;
        try {
            ringPlot0.draw(graphics2D6, rectangle2D7, point2D73, plotState77, plotRenderingInfo78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(xYItemRendererArray63);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertNotNull(point2D73);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getURLText();
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle1.setBackgroundPaint(paint3);
        textTitle1.setHeight((double) ' ');
        org.jfree.chart.util.Size2D size2D7 = new org.jfree.chart.util.Size2D();
        boolean boolean8 = textTitle1.equals((java.lang.Object) size2D7);
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer11 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset10, waferMapRenderer11);
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        waferMapPlot12.setDataset(waferMapDataset13);
        waferMapPlot12.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot12);
        java.awt.Stroke stroke18 = jFreeChart17.getBorderStroke();
        boolean boolean19 = jFreeChart17.isBorderVisible();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.data.general.WaferMapDataset waferMapDataset21 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer22 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot23 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset21, waferMapRenderer22);
        org.jfree.data.general.WaferMapDataset waferMapDataset24 = null;
        waferMapPlot23.setDataset(waferMapDataset24);
        boolean boolean26 = chartChangeEventType20.equals((java.lang.Object) waferMapPlot23);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textTitle1, jFreeChart17, chartChangeEventType20);
        org.jfree.chart.plot.Plot plot28 = jFreeChart17.getPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = jFreeChart17.getPadding();
        try {
            java.awt.image.BufferedImage bufferedImage32 = jFreeChart17.createBufferedImage((int) '#', (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(plot28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        java.awt.Shape shape7 = dateAxis5.getUpArrow();
        dateAxis5.centerRange((double) (short) 1);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer14 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot15 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset13, waferMapRenderer14);
        org.jfree.data.general.WaferMapDataset waferMapDataset16 = null;
        waferMapPlot15.setDataset(waferMapDataset16);
        waferMapPlot15.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot15);
        jFreeChart20.setBackgroundImageAlpha(1.0f);
        jFreeChart20.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = jFreeChart20.getPadding();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color10, stroke11, rectangleInsets25);
        dateAxis5.setTickMarkStroke(stroke11);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer28);
        org.jfree.chart.axis.AxisLocation axisLocation30 = null;
        try {
            xYPlot29.setRangeAxisLocation(axisLocation30, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj2 = categoryAxis3D1.clone();
        boolean boolean3 = horizontalAlignment0.equals(obj2);
        java.lang.String str4 = horizontalAlignment0.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "HorizontalAlignment.LEFT" + "'", str4.equals("HorizontalAlignment.LEFT"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        boolean boolean2 = ringPlot0.isCircular();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setRangeCrosshairValue((double) 200, false);
        boolean boolean9 = categoryPlot5.isRangeCrosshairVisible();
        java.awt.Color color11 = java.awt.Color.white;
        java.awt.Color color12 = java.awt.Color.getColor("", color11);
        categoryPlot5.setNoDataMessagePaint((java.awt.Paint) color11);
        valueMarker4.setOutlinePaint((java.awt.Paint) color11);
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color11);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = ringPlot0.getDrawingSupplier();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(drawingSupplier16);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        boolean boolean3 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint7 = categoryPlot6.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot6.getRangeAxisForDataset((-1));
        categoryPlot6.setDomainGridlinesVisible(false);
        java.util.List list14 = categoryPlot6.getAnnotations();
        xYPlot0.drawRangeTickBands(graphics2D4, rectangle2D5, list14);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Color color6 = java.awt.Color.white;
        java.awt.Color color7 = java.awt.Color.getColor("", color6);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        categoryPlot0.setForegroundAlpha((float) 0L);
        double double12 = categoryPlot0.getAnchorValue();
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean14 = polarPlot13.isAngleGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        polarPlot13.setDataset(xYDataset15);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = polarPlot13.getRenderer();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        boolean boolean19 = polarPlot13.equals((java.lang.Object) textBlockAnchor18);
        java.awt.Stroke stroke20 = polarPlot13.getAngleGridlineStroke();
        categoryPlot0.setRangeGridlineStroke(stroke20);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(polarItemRenderer17);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Color color2 = java.awt.Color.gray;
        java.awt.Color color3 = java.awt.Color.green;
        java.awt.Color color4 = java.awt.Color.red;
        float[] floatArray10 = new float[] { '4', (-1L), 10L, 10.0f, 0 };
        float[] floatArray11 = color4.getComponents(floatArray10);
        float[] floatArray12 = color3.getColorComponents(floatArray10);
        float[] floatArray13 = color2.getComponents(floatArray12);
        float[] floatArray14 = color1.getComponents(floatArray12);
        java.awt.Color color15 = java.awt.Color.getColor("TextAnchor.HALF_ASCENT_CENTER", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        float float7 = waferMapPlot4.getBackgroundImageAlpha();
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot4);
        java.awt.Stroke stroke9 = valueMarker1.getOutlineStroke();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker1.setStroke(stroke10);
        org.jfree.chart.StrokeMap strokeMap12 = new org.jfree.chart.StrokeMap();
        strokeMap12.clear();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer15 = new org.jfree.chart.text.G2TextMeasurer(graphics2D14);
        boolean boolean16 = strokeMap12.equals((java.lang.Object) graphics2D14);
        boolean boolean17 = valueMarker1.equals((java.lang.Object) graphics2D14);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        categoryPlot0.setAnchorValue(0.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str6 = textTitle5.getURLText();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle5.setBackgroundPaint(paint7);
        categoryPlot0.setDomainGridlinePaint(paint7);
        categoryPlot0.setWeight((int) (byte) -1);
        categoryPlot0.setAnchorValue(90.0d, false);
        boolean boolean15 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot0.getRangeAxisForDataset((int) (byte) -1);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(valueAxis17);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color2 = java.awt.Color.getColor("Rotation.CLOCKWISE", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer6 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset5, waferMapRenderer6);
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        waferMapPlot7.setDataset(waferMapDataset8);
        float float10 = waferMapPlot7.getBackgroundImageAlpha();
        valueMarker4.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot7);
        java.awt.Font font12 = valueMarker4.getLabelFont();
        dateAxis2.setTickLabelFont(font12);
        org.jfree.data.Range range16 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis2.setRangeWithMargins(range16);
        java.util.TimeZone timeZone18 = dateAxis2.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis20.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        try {
            xYPlot24.handleClick(200, (int) '#', plotRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(timeZone18);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 1, 0);
        categoryPlot0.setDrawSharedDomainAxis(true);
        java.lang.Object obj6 = categoryPlot0.clone();
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot0.getRangeMarkers(layer7);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(collection8);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setInfo("hi!");
        projectInfo0.setInfo("");
        projectInfo0.setInfo("");
        projectInfo0.setInfo("{0}");
        java.lang.String str9 = projectInfo0.getCopyright();
        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo0.getLibraries();
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(libraryArray10);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isAngleGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        polarPlot0.setDataset(xYDataset2);
        java.awt.Font font4 = polarPlot0.getAngleLabelFont();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo();
        java.awt.Color color6 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint9 = textTitle8.getPaint();
        java.awt.Color color10 = java.awt.Color.red;
        java.awt.Color color11 = java.awt.Color.red;
        java.awt.Color color12 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color6, paint9, color10, color11, color12 };
        java.awt.Paint[] paintArray14 = null;
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Stroke[] strokeArray17 = new java.awt.Stroke[] {};
        java.awt.Shape shape18 = null;
        java.awt.Shape[] shapeArray19 = new java.awt.Shape[] { shape18 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier20 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray13, paintArray14, strokeArray16, strokeArray17, shapeArray19);
        java.awt.Paint paint21 = defaultDrawingSupplier20.getNextPaint();
        boolean boolean22 = basicProjectInfo5.equals((java.lang.Object) paint21);
        boolean boolean23 = polarPlot0.equals((java.lang.Object) paint21);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(strokeArray17);
        org.junit.Assert.assertNotNull(shapeArray19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        java.awt.Shape shape7 = dateAxis5.getUpArrow();
        dateAxis5.centerRange((double) (short) 1);
        dateAxis5.setRange(0.0d, (double) '#');
        dateAxis5.setAutoRange(false);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.lang.String str16 = categoryPlot0.getPlotType();
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot0.getDomainMarkers((int) (short) 1, layer18);
        boolean boolean20 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(axisLocation21);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) waferMapPlot4);
        org.jfree.chart.plot.Plot plot8 = plotChangeEvent7.getPlot();
        java.lang.Class<?> wildcardClass9 = plot8.getClass();
        java.net.URL uRL10 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ChartChangeEventType.DATASET_UPDATED", (java.lang.Class) wildcardClass9);
        java.lang.Object obj11 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass9);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(uRL10);
        org.junit.Assert.assertNull(obj11);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle2.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle2.getPosition();
        java.lang.String str5 = rectangleEdge4.toString();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str8 = categoryAxis3D7.getLabelURL();
        double double9 = categoryAxis3D7.getCategoryMargin();
        categoryAxis3D7.setLabelURL("RectangleEdge.TOP");
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis3D7.setTickMarkStroke(stroke12);
        boolean boolean14 = rectangleEdge4.equals((java.lang.Object) stroke12);
        try {
            double double15 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleEdge.TOP" + "'", str5.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.Color color5 = java.awt.Color.getColor("", color4);
        int int6 = color4.getRGB();
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot0.getRenderer((int) (byte) 10);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        java.awt.Shape shape14 = dateAxis12.getUpArrow();
        dateAxis12.centerRange((double) (short) 1);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        java.lang.Object obj19 = dateAxis18.clone();
        java.awt.Shape shape20 = dateAxis18.getUpArrow();
        dateAxis12.setUpArrow(shape20);
        xYPlot0.setRangeAxis(500, (org.jfree.chart.axis.ValueAxis) dateAxis12, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        org.jfree.data.general.WaferMapDataset waferMapDataset7 = null;
        waferMapPlot6.setDataset(waferMapDataset7);
        float float9 = waferMapPlot6.getBackgroundImageAlpha();
        valueMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot6);
        java.awt.Font font11 = valueMarker3.getLabelFont();
        dateAxis1.setTickLabelFont(font11);
        org.jfree.data.Range range15 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis1.setRangeWithMargins(range15);
        float float17 = dateAxis1.getTickMarkInsideLength();
        dateAxis1.setLowerMargin(0.0d);
        double double20 = dateAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5f + "'", float9 == 0.5f);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", graphics2D1, (float) (short) 1, (float) 100L, (double) (byte) 10, (float) (byte) 1, (float) 500);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke2);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer(categoryItemRenderer5, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getNoDataMessagePaint();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot9.setRangeCrosshairStroke(stroke11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot9.getDomainAxisLocation();
        categoryPlot0.setRangeAxisLocation(500, axisLocation13, true);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getDownArrow();
        java.awt.Shape shape19 = dateAxis17.getUpArrow();
        dateAxis17.centerRange((double) (short) 1);
        boolean boolean22 = dateAxis17.isPositiveArrowVisible();
        org.jfree.data.Range range23 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = categoryPlot0.getRenderer(10);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNull(categoryItemRenderer25);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 10L, (double) 100.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot5.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomDomainAxes(8.0d, plotRenderingInfo9, point2D10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot5);
        java.awt.Font font13 = legendTitle12.getItemFont();
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset17 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer18 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot19 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset17, waferMapRenderer18);
        org.jfree.data.general.WaferMapDataset waferMapDataset20 = null;
        waferMapPlot19.setDataset(waferMapDataset20);
        waferMapPlot19.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot19);
        jFreeChart24.setBackgroundImageAlpha(1.0f);
        jFreeChart24.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = jFreeChart24.getPadding();
        org.jfree.chart.block.LineBorder lineBorder30 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color14, stroke15, rectangleInsets29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = lineBorder30.getInsets();
        columnArrangement4.add((org.jfree.chart.block.Block) legendTitle12, (java.lang.Object) rectangleInsets31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = legendTitle12.getLegendItemGraphicEdge();
        legendTitle12.setWidth((double) 0L);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape40 = dateAxis39.getDownArrow();
        java.awt.Shape shape41 = dateAxis39.getUpArrow();
        dateAxis39.centerRange((double) (short) 1);
        dateAxis39.setRange(0.0d, (double) '#');
        org.jfree.data.Range range49 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis39.setRange(range49, false, false);
        org.jfree.data.Range range54 = org.jfree.data.Range.shift(range49, 8.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = new org.jfree.chart.block.RectangleConstraint(10.0d, range54);
        org.jfree.chart.util.Size2D size2D56 = legendTitle12.arrange(graphics2D36, rectangleConstraint55);
        double double57 = rectangleConstraint55.getWidth();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertNotNull(size2D56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.data.Range range2 = new org.jfree.data.Range(1.0E-8d, (double) 0.5f);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getMaximumLabelWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean3 = piePlot3D0.equals((java.lang.Object) rectangleAnchor2);
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke6 = polarPlot5.getAngleGridlineStroke();
        piePlot3D0.setSectionOutlineStroke((java.lang.Comparable) (short) -1, stroke6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.14d + "'", double1 == 0.14d);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, 2.4d, (double) (short) 1, (double) (-1.0f));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxisForDataset((-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getAxisOffset();
        java.awt.Color color7 = java.awt.Color.white;
        boolean boolean8 = categoryPlot0.equals((java.lang.Object) color7);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Paint paint10 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        java.awt.Shape shape7 = dateAxis5.getUpArrow();
        dateAxis5.centerRange((double) (short) 1);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer14 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot15 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset13, waferMapRenderer14);
        org.jfree.data.general.WaferMapDataset waferMapDataset16 = null;
        waferMapPlot15.setDataset(waferMapDataset16);
        waferMapPlot15.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot15);
        jFreeChart20.setBackgroundImageAlpha(1.0f);
        jFreeChart20.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = jFreeChart20.getPadding();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color10, stroke11, rectangleInsets25);
        dateAxis5.setTickMarkStroke(stroke11);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer28);
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot29.getDomainAxisLocation((int) (byte) 100);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot29.getRangeAxisLocation(0);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(axisLocation33);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("1.2.0-pre");
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        double[] doubleArray4 = new double[] { 0.4d, (-1) };
        double[] doubleArray7 = new double[] { 0.4d, (-1) };
        double[] doubleArray10 = new double[] { 0.4d, (-1) };
        double[] doubleArray13 = new double[] { 0.4d, (-1) };
        double[] doubleArray16 = new double[] { 0.4d, (-1) };
        double[] doubleArray19 = new double[] { 0.4d, (-1) };
        double[][] doubleArray20 = new double[][] { doubleArray4, doubleArray7, doubleArray10, doubleArray13, doubleArray16, doubleArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "{0}", doubleArray20);
        java.lang.Number number22 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset21);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0.4d + "'", number22.equals(0.4d));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint1 = piePlot3D0.getBaseSectionOutlinePaint();
        java.awt.Color color2 = java.awt.Color.ORANGE;
        int int3 = color2.getGreen();
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color2.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        piePlot3D0.setBackgroundPaint((java.awt.Paint) color2);
        boolean boolean11 = piePlot3D0.getDarkerSides();
        java.lang.String str12 = piePlot3D0.getPlotType();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 200 + "'", int3 == 200);
        org.junit.Assert.assertNotNull(paintContext9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pie 3D Plot" + "'", str12.equals("Pie 3D Plot"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        org.jfree.data.general.WaferMapDataset waferMapDataset7 = null;
        waferMapPlot6.setDataset(waferMapDataset7);
        float float9 = waferMapPlot6.getBackgroundImageAlpha();
        valueMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot6);
        java.awt.Font font11 = valueMarker3.getLabelFont();
        dateAxis1.setTickLabelFont(font11);
        org.jfree.data.Range range15 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis1.setRangeWithMargins(range15);
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean18 = polarPlot17.isAngleGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        polarPlot17.setDataset(xYDataset19);
        java.awt.Paint paint21 = polarPlot17.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = new org.jfree.chart.util.RectangleInsets(3.0d, (double) 100.0f, (double) (byte) 0, (double) 100.0f);
        polarPlot17.setInsets(rectangleInsets26, false);
        dateAxis1.setTickLabelInsets(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5f + "'", float9 == 0.5f);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxisForDataset((-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getAxisOffset();
        boolean boolean7 = categoryPlot0.isDomainZoomable();
        categoryPlot0.setRangeCrosshairVisible(false);
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        xYPlot0.clearDomainMarkers(1);
        org.jfree.chart.axis.ValueAxis valueAxis16 = xYPlot0.getRangeAxis(0);
        int int17 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        xYPlot0.setRenderer((int) (short) 0, xYItemRenderer19);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot0.getDomainAxisEdge();
        java.util.List list14 = xYPlot0.getAnnotations();
        xYPlot0.clearDomainAxes();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.mapDatasetToDomainAxis((int) (short) 1, 0);
        categoryPlot18.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str26 = categoryAxis3D25.getLabelURL();
        double double27 = categoryAxis3D25.getCategoryMargin();
        java.lang.Object obj28 = categoryAxis3D25.clone();
        categoryAxis3D25.setCategoryMargin((double) 10L);
        java.util.List list31 = categoryPlot18.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        xYPlot0.drawRangeTickBands(graphics2D16, rectangle2D17, list31);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.2d + "'", double27 == 0.2d);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(list31);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.awt.Font font3 = textTitle2.getFont();
        java.awt.Font font4 = textTitle2.getFont();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer11 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset10, waferMapRenderer11);
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        waferMapPlot12.setDataset(waferMapDataset13);
        float float15 = waferMapPlot12.getBackgroundImageAlpha();
        valueMarker9.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot12);
        java.awt.Font font17 = valueMarker9.getLabelFont();
        dateAxis7.setTickLabelFont(font17);
        org.jfree.data.Range range21 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis7.setRangeWithMargins(range21);
        double double23 = dateAxis7.getFixedAutoRange();
        java.awt.Paint paint24 = dateAxis7.getTickMarkPaint();
        dateAxis7.setAutoRange(true);
        dateAxis7.setLabelAngle((double) (-1L));
        java.awt.Font font29 = dateAxis7.getTickLabelFont();
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("", font29);
        textTitle2.setFont(font29);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.block.Arrangement arrangement2 = blockContainer1.getArrangement();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(1.0d, 90.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = rectangleConstraint5.getWidthConstraintType();
        org.jfree.chart.util.UnitType unitType7 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean8 = lengthConstraintType6.equals((java.lang.Object) unitType7);
        java.lang.String str9 = lengthConstraintType6.toString();
        boolean boolean10 = blockContainer1.equals((java.lang.Object) lengthConstraintType6);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = blockContainer1.arrange(graphics2D11);
        org.jfree.chart.block.Arrangement arrangement13 = null;
        try {
            blockContainer1.setArrangement(arrangement13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(arrangement2);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
        org.junit.Assert.assertNotNull(unitType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "LengthConstraintType.FIXED" + "'", str9.equals("LengthConstraintType.FIXED"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(size2D12);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 100.0f, plotRenderingInfo5, point2D6);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str11 = categoryAxis3D10.getLabelURL();
        double double12 = categoryAxis3D10.getCategoryMargin();
        boolean boolean13 = categoryPlot0.equals((java.lang.Object) double12);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset16 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer17 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot18 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset16, waferMapRenderer17);
        org.jfree.data.general.WaferMapDataset waferMapDataset19 = null;
        waferMapPlot18.setDataset(waferMapDataset19);
        float float21 = waferMapPlot18.getBackgroundImageAlpha();
        valueMarker15.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot18);
        java.awt.Font font23 = valueMarker15.getLabelFont();
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        boolean boolean26 = textAnchor24.equals((java.lang.Object) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        valueMarker15.setLabelTextAnchor(textAnchor24);
        org.jfree.chart.util.Layer layer28 = null;
        try {
            boolean boolean29 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker15, layer28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.5f + "'", float21 == 0.5f);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Color color6 = java.awt.Color.white;
        java.awt.Color color7 = java.awt.Color.getColor("", color6);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str14 = categoryAxis3D13.getLabelURL();
        double double15 = categoryAxis3D13.getCategoryMargin();
        categoryAxis3D13.setLabelURL("RectangleEdge.TOP");
        float float18 = categoryAxis3D13.getMaximumCategoryLabelWidthRatio();
        categoryPlot0.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean24 = polarPlot23.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint28 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot27.setRangeZeroBaselinePaint(paint28);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray31 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer30 };
        xYPlot27.setRenderers(xYItemRendererArray31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        xYPlot27.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo35, point2D36);
        org.jfree.chart.axis.AxisSpace axisSpace38 = null;
        xYPlot27.setFixedRangeAxisSpace(axisSpace38);
        java.awt.Stroke stroke40 = xYPlot27.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D41 = xYPlot27.getQuadrantOrigin();
        polarPlot23.zoomDomainAxes(1.0E-8d, plotRenderingInfo26, point2D41);
        categoryPlot0.zoomRangeAxes((-7.0d), (double) 10L, plotRenderingInfo22, point2D41);
        java.lang.String str44 = categoryPlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.2d + "'", double15 == 0.2d);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(xYItemRendererArray31);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(point2D41);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Category Plot" + "'", str44.equals("Category Plot"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        paintMap0.clear();
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = xYPlot0.getDatasetRenderingOrder();
        boolean boolean12 = xYPlot0.isDomainCrosshairLockedOnData();
        xYPlot0.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        xYPlot0.clearDomainMarkers(1);
        org.jfree.chart.axis.ValueAxis valueAxis16 = xYPlot0.getRangeAxis(0);
        int int17 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot19.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot19.getRangeAxisLocation(0);
        try {
            xYPlot0.setDomainAxisLocation((-8388480), axisLocation24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(axisLocation24);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot0.getRenderer(0);
        xYPlot0.clearRangeMarkers();
        int int14 = xYPlot0.getDomainAxisCount();
        java.awt.Color color16 = java.awt.Color.green;
        try {
            xYPlot0.setQuadrantPaint((-8388480), (java.awt.Paint) color16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (-8388480) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        categoryPlot0.setAnchorValue(0.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str6 = textTitle5.getURLText();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle5.setBackgroundPaint(paint7);
        categoryPlot0.setDomainGridlinePaint(paint7);
        categoryPlot0.setWeight((int) (byte) -1);
        categoryPlot0.setAnchorValue(90.0d, false);
        double[] doubleArray19 = new double[] { 0.4d, (-1) };
        double[] doubleArray22 = new double[] { 0.4d, (-1) };
        double[] doubleArray25 = new double[] { 0.4d, (-1) };
        double[] doubleArray28 = new double[] { 0.4d, (-1) };
        double[] doubleArray31 = new double[] { 0.4d, (-1) };
        double[] doubleArray34 = new double[] { 0.4d, (-1) };
        double[][] doubleArray35 = new double[][] { doubleArray19, doubleArray22, doubleArray25, doubleArray28, doubleArray31, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "{0}", doubleArray35);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset36);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = categoryPlot0.getRendererForDataset(categoryDataset36);
        java.lang.Number number39 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset36);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D41 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font43 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D41.setTickLabelFont((java.lang.Comparable) (short) 10, font43);
        int int45 = categoryAxis3D41.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke46 = categoryAxis3D41.getAxisLineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean48 = numberAxis47.getAutoRangeIncludesZero();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D41, (org.jfree.chart.axis.ValueAxis) numberAxis47, categoryItemRenderer51);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset36, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNull(categoryItemRenderer38);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 0.4d + "'", number39.equals(0.4d));
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(range54);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        waferMapPlot4.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot4);
        jFreeChart9.setBackgroundImageAlpha(1.0f);
        jFreeChart9.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = jFreeChart9.getPadding();
        boolean boolean15 = jFreeChart9.isNotify();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart9, chartChangeEventType16);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str20 = textTitle19.getURLText();
        jFreeChart9.removeSubtitle((org.jfree.chart.title.Title) textTitle19);
        double double22 = textTitle19.getWidth();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = textTitle19.getTextAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment23, verticalAlignment24, (double) 500, (double) (-1L));
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(verticalAlignment24);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint17 = categoryPlot16.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot16.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation18);
        int int20 = xYPlot0.getWeight();
        boolean boolean21 = xYPlot0.isRangeZoomable();
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = xYPlot0.getDomainMarkers(layer22);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(collection23);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Rotation.CLOCKWISE");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        java.lang.String str4 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset2, (java.lang.Comparable) 0.025d);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        waferMapPlot2.setDataset(waferMapDataset3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = waferMapPlot2.getDataset();
        org.junit.Assert.assertNull(waferMapDataset5);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        org.jfree.data.Range range11 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis1.setRange(range11, false, false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset19 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer20 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot21 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset19, waferMapRenderer20);
        org.jfree.data.general.WaferMapDataset waferMapDataset22 = null;
        waferMapPlot21.setDataset(waferMapDataset22);
        float float24 = waferMapPlot21.getBackgroundImageAlpha();
        valueMarker18.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot21);
        java.awt.Font font26 = valueMarker18.getLabelFont();
        dateAxis16.setTickLabelFont(font26);
        org.jfree.data.Range range30 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis16.setRangeWithMargins(range30);
        java.lang.String str32 = dateAxis16.getLabelToolTip();
        org.jfree.data.Range range33 = dateAxis16.getRange();
        java.awt.Color color34 = java.awt.Color.darkGray;
        boolean boolean35 = range33.equals((java.lang.Object) color34);
        dateAxis1.setAxisLinePaint((java.awt.Paint) color34);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.5f + "'", float24 == 0.5f);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreZeroValues(true);
        ringPlot0.setLabelGap(90.0d);
        boolean boolean5 = ringPlot0.getSimpleLabels();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        java.awt.Color color3 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint6 = textTitle5.getPaint();
        java.awt.Color color7 = java.awt.Color.red;
        java.awt.Color color8 = java.awt.Color.red;
        java.awt.Color color9 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray10 = new java.awt.Paint[] { color3, paint6, color7, color8, color9 };
        java.awt.Paint[] paintArray11 = null;
        java.awt.Stroke stroke12 = null;
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] { stroke12 };
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] {};
        java.awt.Shape shape15 = null;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] { shape15 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray10, paintArray11, strokeArray13, strokeArray14, shapeArray16);
        java.awt.Stroke stroke18 = defaultDrawingSupplier17.getNextStroke();
        java.awt.Paint paint19 = defaultDrawingSupplier17.getNextFillPaint();
        java.awt.Paint paint20 = defaultDrawingSupplier17.getNextPaint();
        xYPlot0.setRangeGridlinePaint(paint20);
        org.jfree.chart.plot.PiePlot3D piePlot3D22 = new org.jfree.chart.plot.PiePlot3D();
        double double23 = piePlot3D22.getMaximumLabelWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean25 = piePlot3D22.equals((java.lang.Object) rectangleAnchor24);
        double double26 = piePlot3D22.getLabelLinkMargin();
        java.awt.Stroke stroke27 = piePlot3D22.getLabelLinkStroke();
        xYPlot0.setRangeCrosshairStroke(stroke27);
        float float29 = xYPlot0.getForegroundAlpha();
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot0.getDataset((int) (short) -1);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.14d + "'", double23 == 0.14d);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.025d + "'", double26 == 0.025d);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 1.0f + "'", float29 == 1.0f);
        org.junit.Assert.assertNull(xYDataset31);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 1, 0);
        categoryPlot0.setDrawSharedDomainAxis(true);
        java.lang.Object obj6 = categoryPlot0.clone();
        int int7 = categoryPlot0.getDomainAxisCount();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint2 = textTitle1.getPaint();
        double double3 = textTitle1.getContentYOffset();
        java.awt.Paint paint4 = textTitle1.getBackgroundPaint();
        java.awt.Paint paint5 = textTitle1.getPaint();
        textTitle1.setPadding(0.12d, 0.14d, (double) 200, (double) (byte) 10);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer6 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset5, waferMapRenderer6);
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        waferMapPlot7.setDataset(waferMapDataset8);
        waferMapPlot7.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot7);
        jFreeChart12.setBackgroundImageAlpha(1.0f);
        jFreeChart12.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = jFreeChart12.getPadding();
        org.jfree.chart.block.LineBorder lineBorder18 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color2, stroke3, rectangleInsets17);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color1, stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = valueMarker19.getLabelOffset();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint22 = categoryPlot21.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection23 = null;
        categoryPlot21.setFixedLegendItems(legendItemCollection23);
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot21.getRangeAxisForDataset((-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryPlot21.getAxisOffset();
        java.awt.Color color28 = java.awt.Color.white;
        boolean boolean29 = categoryPlot21.equals((java.lang.Object) color28);
        valueMarker19.setOutlinePaint((java.awt.Paint) color28);
        java.awt.Paint paint31 = valueMarker19.getLabelPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(paint31);
    }
}

