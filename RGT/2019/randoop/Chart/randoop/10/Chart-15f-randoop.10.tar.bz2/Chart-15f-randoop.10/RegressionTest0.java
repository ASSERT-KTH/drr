import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("hi!", font1, paint2, rectangleEdge3, horizontalAlignment4, verticalAlignment5, rectangleInsets6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!", font1, paint2, (float) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.combine(range0, range1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        try {
            waferMapPlot2.setBackgroundImageAlpha((float) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test011");
//        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ThreadContext", "ThreadContext");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        waferMapPlot2.setDataset(waferMapDataset3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = null;
        try {
            waferMapPlot2.setInsets(rectangleInsets5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = null;
        try {
            textTitle1.setPosition(rectangleEdge2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.lang.Comparable[] comparableArray4 = new java.lang.Comparable[] { (short) 1, "hi!", false, 0L };
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { (byte) -1 };
        double[] doubleArray11 = new double[] { 0.0d, 0.5f, 1.0d, 10.0f };
        double[] doubleArray16 = new double[] { 0.0d, 0.5f, 1.0d, 10.0f };
        double[][] doubleArray17 = new double[][] { doubleArray11, doubleArray16 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray4, comparableArray6, doubleArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray4);
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        float[] floatArray2 = new float[] { (short) 100 };
        try {
            float[] floatArray3 = color0.getComponents(floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceText();
        java.awt.Image image2 = null;
        projectInfo0.setLogo(image2);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceText();
        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo0.getOptionalLibraries();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(libraryArray2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) 10, 0.5f, textAnchor4, (double) (byte) -1, 100.0f, (float) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.plot.Plot plot2 = waferMapPlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        try {
            plot2.datasetChanged(datasetChangeEvent3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double[][] doubleArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ThreadContext", graphics2D1, (float) (short) -1, (float) 1L, textAnchor4, (double) (-1), textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.TimeZone timeZone2 = null;
        try {
            dateAxis1.setTimeZone(timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Color color0 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint3 = textTitle2.getPaint();
        java.awt.Color color4 = java.awt.Color.red;
        java.awt.Color color5 = java.awt.Color.red;
        java.awt.Color color6 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color0, paint3, color4, color5, color6 };
        java.awt.Paint[] paintArray8 = null;
        java.awt.Stroke stroke9 = null;
        java.awt.Stroke[] strokeArray10 = new java.awt.Stroke[] { stroke9 };
        java.awt.Stroke[] strokeArray11 = new java.awt.Stroke[] {};
        java.awt.Shape shape12 = null;
        java.awt.Shape[] shapeArray13 = new java.awt.Shape[] { shape12 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray8, strokeArray10, strokeArray11, shapeArray13);
        try {
            java.awt.Paint paint15 = defaultDrawingSupplier14.getNextOutlinePaint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(strokeArray11);
        org.junit.Assert.assertNotNull(shapeArray13);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.plot.Plot plot2 = waferMapPlot1.getParent();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            plot2.drawBackground(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        try {
            jFreeChart8.handleClick(0, (int) (short) 100, chartRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.plot.Plot plot2 = waferMapPlot1.getParent();
        java.awt.Paint paint3 = null;
        waferMapPlot1.setBackgroundPaint(paint3);
        org.junit.Assert.assertNull(plot2);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleEdge.TOP", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        waferMapPlot2.setDataset(waferMapDataset3);
        float float5 = waferMapPlot2.getBackgroundImageAlpha();
        float float6 = waferMapPlot2.getBackgroundImageAlpha();
        try {
            waferMapPlot2.setBackgroundImageAlpha((float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.5f + "'", float6 == 0.5f);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getURLText();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(1.0d, 90.0d);
        try {
            org.jfree.chart.util.Size2D size2D7 = textTitle1.arrange(graphics2D3, rectangleConstraint6);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) waferMapRenderer1, jFreeChart3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        double double3 = rectangleInsets0.extendWidth((double) 1L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str1.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 17.0d + "'", double3 == 17.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.AxisState axisState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = textTitle5.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = textTitle5.getPosition();
        try {
            java.util.List list8 = numberAxis0.refreshTicks(graphics2D1, axisState2, rectangle2D3, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str4 = categoryAxis3D3.getLabelURL();
        try {
            categoryPlot0.setDomainAxis((int) (byte) -1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.awt.Color color0 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint3 = textTitle2.getPaint();
        java.awt.Color color4 = java.awt.Color.red;
        java.awt.Color color5 = java.awt.Color.red;
        java.awt.Color color6 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color0, paint3, color4, color5, color6 };
        java.awt.Paint[] paintArray8 = null;
        java.awt.Stroke stroke9 = null;
        java.awt.Stroke[] strokeArray10 = new java.awt.Stroke[] { stroke9 };
        java.awt.Stroke[] strokeArray11 = new java.awt.Stroke[] {};
        java.awt.Shape shape12 = null;
        java.awt.Shape[] shapeArray13 = new java.awt.Shape[] { shape12 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray8, strokeArray10, strokeArray11, shapeArray13);
        java.awt.Stroke stroke15 = defaultDrawingSupplier14.getNextStroke();
        try {
            java.awt.Stroke stroke16 = defaultDrawingSupplier14.getNextOutlineStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(strokeArray11);
        org.junit.Assert.assertNotNull(shapeArray13);
        org.junit.Assert.assertNull(stroke15);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D2.setTickLabelFont((java.lang.Comparable) (short) 10, font4);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font4, paint6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        try {
            textBlock7.draw(graphics2D8, (-1.0f), (float) 'a', textBlockAnchor11, (float) (byte) -1, (float) (-1), (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        float float7 = waferMapPlot4.getBackgroundImageAlpha();
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot4);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = null;
        try {
            valueMarker1.setLabelOffsetType(lengthAdjustmentType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D1.setTickLabelFont((java.lang.Comparable) (short) 10, font3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = textTitle9.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = textTitle9.getPosition();
        java.lang.String str12 = rectangleEdge11.toString();
        try {
            java.util.List list13 = categoryAxis3D1.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleEdge.TOP" + "'", str12.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        org.jfree.data.general.WaferMapDataset waferMapDataset7 = null;
        waferMapPlot6.setDataset(waferMapDataset7);
        float float9 = waferMapPlot6.getBackgroundImageAlpha();
        valueMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot6);
        java.awt.Font font11 = valueMarker3.getLabelFont();
        dateAxis1.setTickLabelFont(font11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = textTitle17.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = textTitle17.getPosition();
        try {
            java.util.List list20 = dateAxis1.refreshTicks(graphics2D13, axisState14, rectangle2D15, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5f + "'", float9 == 0.5f);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getURLText();
        java.lang.String str3 = textTitle1.getURLText();
        java.lang.String str4 = textTitle1.getText();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        boolean boolean2 = textAnchor0.equals((java.lang.Object) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        java.lang.String str3 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.HALF_ASCENT_CENTER" + "'", str3.equals("TextAnchor.HALF_ASCENT_CENTER"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke1 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer4 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset3, waferMapRenderer4);
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        waferMapPlot5.setDataset(waferMapDataset6);
        waferMapPlot5.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot5);
        jFreeChart10.setBackgroundImageAlpha(1.0f);
        jFreeChart10.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = jFreeChart10.getPadding();
        org.jfree.chart.block.LineBorder lineBorder16 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets15);
        java.awt.color.ColorSpace colorSpace17 = null;
        java.awt.Color color18 = java.awt.Color.red;
        float[] floatArray24 = new float[] { '4', (-1L), 10L, 10.0f, 0 };
        float[] floatArray25 = color18.getComponents(floatArray24);
        try {
            float[] floatArray26 = color0.getComponents(colorSpace17, floatArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        java.util.List list11 = null;
        try {
            jFreeChart8.setSubtitles(list11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'subtitles' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        java.awt.Stroke stroke9 = jFreeChart8.getBorderStroke();
        float float10 = jFreeChart8.getBackgroundImageAlpha();
        try {
            org.jfree.chart.title.Title title12 = jFreeChart8.getSubtitle((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("ThreadContext", "ThreadContext", "ChartChangeEventType.DATASET_UPDATED", "");
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        java.awt.Stroke stroke9 = jFreeChart8.getBorderStroke();
        float float10 = jFreeChart8.getBackgroundImageAlpha();
        org.jfree.chart.plot.Plot plot11 = jFreeChart8.getPlot();
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
        org.junit.Assert.assertNotNull(plot11);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = textTitle12.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = textTitle12.getPosition();
        try {
            double double15 = dateAxis1.java2DToValue((double) (-1L), rectangle2D10, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Color color1 = java.awt.Color.getColor("ThreadContext");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.lang.Comparable[] comparableArray4 = new java.lang.Comparable[] { 4.0d, 1, (short) 0, 1 };
        java.lang.Comparable[] comparableArray10 = new java.lang.Comparable[] { 100, (byte) 1, (short) 100, (short) 1, "ChartChangeEventType.DATASET_UPDATED" };
        double[] doubleArray14 = new double[] { (short) -1, 0, (short) 10 };
        double[] doubleArray18 = new double[] { (short) -1, 0, (short) 10 };
        double[] doubleArray22 = new double[] { (short) -1, 0, (short) 10 };
        double[] doubleArray26 = new double[] { (short) -1, 0, (short) 10 };
        double[] doubleArray30 = new double[] { (short) -1, 0, (short) 10 };
        double[][] doubleArray31 = new double[][] { doubleArray14, doubleArray18, doubleArray22, doubleArray26, doubleArray30 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray4, comparableArray10, doubleArray31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Duplicate items in 'rowKeys'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray4);
        org.junit.Assert.assertNotNull(comparableArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceText();
        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo0.getLibraries();
        projectInfo0.setVersion("");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(libraryArray2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation5 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 10);
        int int2 = pieLabelDistributor1.getItemCount();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D1.setTickLabelFont((java.lang.Comparable) (short) 10, font3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle10.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = textTitle10.getPosition();
        java.lang.String str13 = rectangleEdge12.toString();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        try {
            org.jfree.chart.axis.AxisState axisState15 = categoryAxis3D1.draw(graphics2D5, (double) 0.0f, rectangle2D7, rectangle2D8, rectangleEdge12, plotRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleEdge.TOP" + "'", str13.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("Range[100.0,100.0]", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean2 = numberAxis0.isAutoRange();
        numberAxis0.setLabelAngle((double) '4');
        org.jfree.data.RangeType rangeType5 = numberAxis0.getRangeType();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = null;
        try {
            numberAxis0.setTickUnit(numberTickUnit6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rangeType5);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.lang.Object obj0 = null;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'object' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        float float7 = waferMapPlot4.getBackgroundImageAlpha();
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        waferMapPlot4.rendererChanged(rendererChangeEvent9);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setAxisLineVisible(false);
        float float4 = dateAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxisForDataset((-1));
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer9 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot10 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset8, waferMapRenderer9);
        org.jfree.data.general.WaferMapDataset waferMapDataset11 = null;
        waferMapPlot10.setDataset(waferMapDataset11);
        float float13 = waferMapPlot10.getBackgroundImageAlpha();
        valueMarker7.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot10);
        java.awt.Font font15 = valueMarker7.getLabelFont();
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        boolean boolean18 = textAnchor16.equals((java.lang.Object) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        valueMarker7.setLabelTextAnchor(textAnchor16);
        org.jfree.chart.util.Layer layer20 = null;
        try {
            boolean boolean21 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker7, layer20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = textTitle5.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = textTitle5.getPosition();
        java.lang.String str8 = rectangleEdge7.toString();
        try {
            double double9 = numberAxis0.valueToJava2D((double) (byte) -1, rectangle2D3, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleEdge.TOP" + "'", str8.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        try {
            org.jfree.chart.plot.PiePlotState piePlotState6 = ringPlot0.initialise(graphics2D1, rectangle2D2, piePlot3, (java.lang.Integer) 1, plotRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str2 = categoryAxis3D1.getLabelURL();
        double double3 = categoryAxis3D1.getCategoryMargin();
        categoryAxis3D1.setLabelURL("RectangleEdge.TOP");
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getURLText();
        java.awt.Paint paint9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle7.setBackgroundPaint(paint9);
        java.lang.String str11 = textTitle7.getURLText();
        boolean boolean12 = categoryAxis3D1.equals((java.lang.Object) str11);
        categoryAxis3D1.setUpperMargin((double) '#');
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("ClassContext", "Range[100.0,100.0]", "RectangleEdge.TOP", "TextAnchor.HALF_ASCENT_CENTER");
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        boolean boolean2 = rotation0.equals((java.lang.Object) paint1);
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean2 = numberAxis0.isAutoRange();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = textTitle8.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = textTitle8.getPosition();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            org.jfree.chart.axis.AxisState axisState12 = numberAxis0.draw(graphics2D3, (double) (byte) 100, rectangle2D5, rectangle2D6, rectangleEdge10, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke1 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer4 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset3, waferMapRenderer4);
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        waferMapPlot5.setDataset(waferMapDataset6);
        waferMapPlot5.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot5);
        jFreeChart10.setBackgroundImageAlpha(1.0f);
        jFreeChart10.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = jFreeChart10.getPadding();
        org.jfree.chart.block.LineBorder lineBorder16 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets15);
        double double18 = rectangleInsets15.calculateRightInset(0.0d);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 10);
        int int2 = pieLabelDistributor1.getItemCount();
        java.lang.String str3 = pieLabelDistributor1.toString();
        pieLabelDistributor1.clear();
        int int5 = pieLabelDistributor1.getItemCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        double double2 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.Object obj1 = ringPlot0.clone();
        double double2 = ringPlot0.getMaximumExplodePercent();
        ringPlot0.setCircular(false);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Point2D point2D7 = null;
        org.jfree.chart.plot.PlotState plotState8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            ringPlot0.draw(graphics2D5, rectangle2D6, point2D7, plotState8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateLeftInset((double) (-1.0f));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        waferMapPlot2.setDataset(waferMapDataset3);
        float float5 = waferMapPlot2.getBackgroundImageAlpha();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        waferMapPlot2.datasetChanged(datasetChangeEvent6);
        java.awt.Color color9 = java.awt.Color.white;
        java.awt.Color color10 = java.awt.Color.getColor("", color9);
        int int11 = color9.getRGB();
        waferMapPlot2.setOutlinePaint((java.awt.Paint) color9);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = null;
        waferMapPlot2.notifyListeners(plotChangeEvent13);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.lang.Object obj0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) 10, 10.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Color color6 = java.awt.Color.white;
        java.awt.Color color7 = java.awt.Color.getColor("", color6);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color6);
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            boolean boolean11 = categoryPlot0.removeRangeMarker(marker9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        java.awt.Stroke stroke9 = jFreeChart8.getBorderStroke();
        java.util.List list10 = null;
        try {
            jFreeChart8.setSubtitles(list10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'subtitles' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        categoryPlot0.setAnchorValue(0.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str6 = textTitle5.getURLText();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle5.setBackgroundPaint(paint7);
        categoryPlot0.setDomainGridlinePaint(paint7);
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        try {
            categoryPlot0.addDomainMarker(0, categoryMarker11, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke1 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer4 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset3, waferMapRenderer4);
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        waferMapPlot5.setDataset(waferMapDataset6);
        waferMapPlot5.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot5);
        jFreeChart10.setBackgroundImageAlpha(1.0f);
        jFreeChart10.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = jFreeChart10.getPadding();
        org.jfree.chart.block.LineBorder lineBorder16 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets15);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets15.createInsetRectangle(rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean2 = numberAxis0.isAutoRange();
        numberAxis0.setLabelAngle((double) '4');
        org.jfree.data.RangeType rangeType5 = numberAxis0.getRangeType();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            org.jfree.chart.axis.AxisState axisState12 = numberAxis0.draw(graphics2D6, 0.0d, rectangle2D8, rectangle2D9, rectangleEdge10, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rangeType5);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 0.05d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        waferMapPlot4.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot4);
        jFreeChart9.setBackgroundImageAlpha(1.0f);
        jFreeChart9.setBorderVisible(true);
        boolean boolean14 = objectList0.equals((java.lang.Object) true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font19 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D17.setTickLabelFont((java.lang.Comparable) (short) 10, font19);
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("hi!", font19);
        boolean boolean22 = objectList0.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        boolean boolean6 = chartChangeEventType0.equals((java.lang.Object) waferMapPlot3);
        java.lang.String str7 = chartChangeEventType0.toString();
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        boolean boolean9 = chartChangeEventType0.equals((java.lang.Object) textAnchor8);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str7.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        boolean boolean6 = textAnchor4.equals((java.lang.Object) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = org.jfree.chart.text.TextUtilities.drawAlignedString("TextAnchor.HALF_ASCENT_CENTER", graphics2D1, (float) (short) 10, (float) (-1L), textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=90.0]", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = waferMapPlot1.getDataset();
        org.junit.Assert.assertNull(waferMapDataset2);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            org.jfree.chart.axis.AxisState axisState8 = numberAxis0.draw(graphics2D2, (double) 1L, rectangle2D4, rectangle2D5, rectangleEdge6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        ringPlot0.setShadowXOffset((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        java.awt.Stroke stroke9 = jFreeChart8.getBorderStroke();
        jFreeChart8.setBackgroundImageAlpha((float) 100);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("LengthConstraintType.FIXED", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        java.lang.String str2 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str1.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str2.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.awt.Image image2 = null;
        waferMapPlot1.setBackgroundImage(image2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Point2D point2D6 = null;
        org.jfree.chart.plot.PlotState plotState7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            waferMapPlot1.draw(graphics2D4, rectangle2D5, point2D6, plotState7, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = textTitle15.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = textTitle15.getPosition();
        jFreeChart8.setTitle(textTitle15);
        textTitle15.setURLText("RectangleEdge.TOP");
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        try {
            textTitle15.setBounds(rectangle2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("ClassContext", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        dateAxis1.setAutoRange(false);
        java.util.Date date11 = null;
        try {
            dateAxis1.setMaximumDate(date11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'maximumDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("RectangleEdge.TOP");
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        try {
            java.awt.Paint paint2 = xYPlot0.getQuadrantPaint((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (100) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.lang.String str2 = rectangleInsets1.toString();
        double double4 = rectangleInsets1.trimHeight((double) (-1.0f));
        double double5 = rectangleInsets1.getBottom();
        double double7 = rectangleInsets1.calculateLeftInset((double) 200);
        boolean boolean8 = chartChangeEventType0.equals((java.lang.Object) 200);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str2.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-9.0d) + "'", double4 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 8.0d + "'", double7 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = null;
        try {
            xYPlot0.setRangeCrosshairPaint(paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceText();
        java.awt.Image image2 = projectInfo0.getLogo();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(image2);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.awt.Color color0 = java.awt.Color.red;
        int int1 = color0.getGreen();
        int int2 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        double double3 = rectangleInsets0.trimHeight((double) (-1.0f));
        double double4 = rectangleInsets0.getBottom();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createOutsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str1.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-9.0d) + "'", double3 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D2.setTickLabelFont((java.lang.Comparable) (short) 10, font4);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font4, paint6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = null;
        try {
            textBlock7.draw(graphics2D8, (float) 10L, (-1.0f), textBlockAnchor11, 0.0f, (float) (-1), (-7.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock7);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        dateAxis1.setAutoRange(false);
        dateAxis1.setRangeWithMargins((double) 'a', (double) 100.0f);
        dateAxis1.zoomRange(8.0d, 17.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) 0, (double) (short) 100, (double) (-1.0f), 100.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.lang.String str6 = rectangleInsets5.toString();
        double double8 = rectangleInsets5.trimHeight((double) (-1.0f));
        double double9 = rectangleInsets5.getBottom();
        boolean boolean10 = blockBorder4.equals((java.lang.Object) rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str6.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-9.0d) + "'", double8 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.block.BlockContainer blockContainer2 = null;
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(1.0d, 90.0d);
        try {
            org.jfree.chart.util.Size2D size2D7 = columnArrangement0.arrange(blockContainer2, graphics2D3, rectangleConstraint6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=90.0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=90.0], locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0, (double) 100.0f);
        size2D2.height = (short) -1;
        size2D2.width = 2.0f;
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 10);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxisForDataset((-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getAxisOffset();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        try {
            int int8 = categoryPlot0.getRangeAxisIndex(valueAxis7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        waferMapPlot2.setDataset(waferMapDataset3);
        float float5 = waferMapPlot2.getBackgroundImageAlpha();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        waferMapPlot2.datasetChanged(datasetChangeEvent6);
        java.awt.Color color9 = java.awt.Color.white;
        java.awt.Color color10 = java.awt.Color.getColor("", color9);
        int int11 = color9.getRGB();
        waferMapPlot2.setOutlinePaint((java.awt.Paint) color9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        waferMapPlot2.rendererChanged(rendererChangeEvent13);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxisForDataset((-1));
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Point2D point2D8 = null;
        org.jfree.chart.plot.PlotState plotState9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            categoryPlot0.draw(graphics2D6, rectangle2D7, point2D8, plotState9, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(valueAxis5);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        categoryPlot0.setAnchorValue(0.0d);
        float float4 = categoryPlot0.getBackgroundImageAlpha();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.5f + "'", float4 == 0.5f);
        org.junit.Assert.assertNull(collection6);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis0.setMarkerBand(markerAxisBand2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint8 = categoryPlot7.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = null;
        categoryPlot7.setFixedLegendItems(legendItemCollection9);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot7.getDomainAxisEdge((int) (byte) 10);
        boolean boolean13 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge12);
        try {
            java.util.List list14 = numberAxis0.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setRangeCrosshairValue((double) 200, false);
        boolean boolean10 = categoryPlot6.isRangeCrosshairVisible();
        java.awt.Color color12 = java.awt.Color.white;
        java.awt.Color color13 = java.awt.Color.getColor("", color12);
        categoryPlot6.setNoDataMessagePaint((java.awt.Paint) color12);
        valueMarker5.setOutlinePaint((java.awt.Paint) color12);
        org.jfree.chart.util.Layer layer16 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker5, layer16);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint3 = ringPlot2.getLabelBackgroundPaint();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace7 = categoryAxis3D0.reserveSpace(graphics2D1, (org.jfree.chart.plot.Plot) ringPlot2, rectangle2D4, rectangleEdge5, axisSpace6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setRangeCrosshairValue((double) 200, false);
        boolean boolean7 = categoryPlot3.isRangeCrosshairVisible();
        java.awt.Color color9 = java.awt.Color.white;
        java.awt.Color color10 = java.awt.Color.getColor("", color9);
        categoryPlot3.setNoDataMessagePaint((java.awt.Paint) color9);
        valueMarker2.setOutlinePaint((java.awt.Paint) color9);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = valueMarker2.getLabelOffset();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets13);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset19 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer20 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot21 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset19, waferMapRenderer20);
        org.jfree.data.general.WaferMapDataset waferMapDataset22 = null;
        waferMapPlot21.setDataset(waferMapDataset22);
        float float24 = waferMapPlot21.getBackgroundImageAlpha();
        valueMarker18.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot21);
        java.awt.Font font26 = valueMarker18.getLabelFont();
        dateAxis16.setTickLabelFont(font26);
        org.jfree.data.Range range30 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis16.setRangeWithMargins(range30);
        boolean boolean33 = range30.contains((double) 100L);
        boolean boolean35 = range30.contains((double) (short) 10);
        boolean boolean36 = piePlot3D0.equals((java.lang.Object) range30);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.5f + "'", float24 == 0.5f);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        ringPlot0.setShadowXOffset((double) (-1.0f));
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            org.jfree.chart.plot.PiePlotState piePlotState9 = ringPlot0.initialise(graphics2D4, rectangle2D5, piePlot6, (java.lang.Integer) 0, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Color color6 = java.awt.Color.white;
        java.awt.Color color7 = java.awt.Color.getColor("", color6);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot0.getDataset();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(categoryDataset10);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 10L, (double) 100.0f);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str7 = textTitle6.getURLText();
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle6.setBackgroundPaint(paint8);
        textTitle6.setHeight((double) ' ');
        java.awt.Paint paint12 = textTitle6.getBackgroundPaint();
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        java.lang.Object obj14 = ringPlot13.clone();
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle6, obj14);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double[] doubleArray4 = new double[] { 0.4d, (-1) };
        double[] doubleArray7 = new double[] { 0.4d, (-1) };
        double[] doubleArray10 = new double[] { 0.4d, (-1) };
        double[] doubleArray13 = new double[] { 0.4d, (-1) };
        double[] doubleArray16 = new double[] { 0.4d, (-1) };
        double[] doubleArray19 = new double[] { 0.4d, (-1) };
        double[][] doubleArray20 = new double[][] { doubleArray4, doubleArray7, doubleArray10, doubleArray13, doubleArray16, doubleArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "{0}", doubleArray20);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset21);
        try {
            org.jfree.data.general.PieDataset pieDataset24 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset21, (java.lang.Comparable) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(range22);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder1 = null;
        try {
            xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke1 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer4 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset3, waferMapRenderer4);
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        waferMapPlot5.setDataset(waferMapDataset6);
        waferMapPlot5.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot5);
        jFreeChart10.setBackgroundImageAlpha(1.0f);
        jFreeChart10.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = jFreeChart10.getPadding();
        org.jfree.chart.block.LineBorder lineBorder16 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        try {
            lineBorder16.draw(graphics2D17, rectangle2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getPadding();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle1.getTextAlignment();
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer9 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot10 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset8, waferMapRenderer9);
        org.jfree.data.general.WaferMapDataset waferMapDataset11 = null;
        waferMapPlot10.setDataset(waferMapDataset11);
        boolean boolean13 = chartChangeEventType7.equals((java.lang.Object) waferMapPlot10);
        java.awt.Font font14 = waferMapPlot10.getNoDataMessageFont();
        dateAxis6.setTickLabelFont(font14);
        textTitle1.setFont(font14);
        org.jfree.chart.block.BlockFrame blockFrame17 = textTitle1.getFrame();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(blockFrame17);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.awt.Color color1 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint4 = textTitle3.getPaint();
        java.awt.Color color5 = java.awt.Color.red;
        java.awt.Color color6 = java.awt.Color.red;
        java.awt.Color color7 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { color1, paint4, color5, color6, color7 };
        java.awt.Paint[] paintArray9 = null;
        java.awt.Stroke stroke10 = null;
        java.awt.Stroke[] strokeArray11 = new java.awt.Stroke[] { stroke10 };
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] {};
        java.awt.Shape shape13 = null;
        java.awt.Shape[] shapeArray14 = new java.awt.Shape[] { shape13 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray8, paintArray9, strokeArray11, strokeArray12, shapeArray14);
        java.awt.Paint paint16 = defaultDrawingSupplier15.getNextPaint();
        boolean boolean17 = basicProjectInfo0.equals((java.lang.Object) paint16);
        basicProjectInfo0.setVersion("");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(strokeArray11);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(shapeArray14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        categoryPlot0.setAnchorValue(0.0d);
        java.awt.Color color5 = java.awt.Color.ORANGE;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset9 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer10 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot11 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset9, waferMapRenderer10);
        org.jfree.data.general.WaferMapDataset waferMapDataset12 = null;
        waferMapPlot11.setDataset(waferMapDataset12);
        waferMapPlot11.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot11);
        jFreeChart16.setBackgroundImageAlpha(1.0f);
        jFreeChart16.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = jFreeChart16.getPadding();
        org.jfree.chart.block.LineBorder lineBorder22 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color6, stroke7, rectangleInsets21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color5, stroke7);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) valueMarker23);
        java.awt.Stroke stroke25 = valueMarker23.getOutlineStroke();
        try {
            boolean boolean26 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator1.getNumberFormat();
        java.text.NumberFormat numberFormat3 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ThreadContext", numberFormat2, numberFormat3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'percentFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, (double) '4', (double) 2.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.awt.Color color4 = java.awt.Color.gray;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 0.5f, (double) (byte) -1, 0.0d, (double) (byte) 0, (java.awt.Paint) color4);
        java.awt.Paint paint6 = blockBorder5.getPaint();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            blockBorder5.draw(graphics2D7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.Range range2 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        double double3 = range2.getCentralValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        waferMapPlot2.setDataset(waferMapDataset3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) waferMapPlot2);
        waferMapPlot2.zoom(90.0d);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        waferMapPlot2.rendererChanged(rendererChangeEvent8);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        java.lang.String str2 = numberAxis0.getLabelURL();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint8 = categoryPlot7.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = null;
        categoryPlot7.setFixedLegendItems(legendItemCollection9);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot7.getDomainAxisEdge((int) (byte) 10);
        boolean boolean13 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        try {
            org.jfree.chart.axis.AxisState axisState15 = numberAxis0.draw(graphics2D3, 0.2d, rectangle2D5, rectangle2D6, rectangleEdge12, plotRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 1.0f, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        try {
            boolean boolean7 = categoryPlot0.removeRangeMarker(marker5, layer6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("Range[100.0,100.0]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.Point2D point2D16 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        try {
            jFreeChart8.draw(graphics2D14, rectangle2D15, point2D16, chartRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        waferMapPlot2.setDataset(waferMapDataset3);
        float float5 = waferMapPlot2.getBackgroundImageAlpha();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        waferMapPlot2.datasetChanged(datasetChangeEvent6);
        java.awt.Color color9 = java.awt.Color.white;
        java.awt.Color color10 = java.awt.Color.getColor("", color9);
        int int11 = color9.getRGB();
        waferMapPlot2.setOutlinePaint((java.awt.Paint) color9);
        java.awt.Paint paint13 = waferMapPlot2.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setRangeCrosshairValue((double) 200, false);
        boolean boolean6 = categoryPlot2.isRangeCrosshairVisible();
        java.awt.Color color8 = java.awt.Color.white;
        java.awt.Color color9 = java.awt.Color.getColor("", color8);
        categoryPlot2.setNoDataMessagePaint((java.awt.Paint) color8);
        valueMarker1.setOutlinePaint((java.awt.Paint) color8);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = valueMarker1.getLabelOffset();
        java.lang.Class class13 = null;
        try {
            java.util.EventListener[] eventListenerArray14 = valueMarker1.getListeners(class13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        boolean boolean14 = jFreeChart8.isNotify();
        boolean boolean15 = jFreeChart8.isNotify();
        jFreeChart8.removeLegend();
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D2.setTickLabelFont((java.lang.Comparable) (short) 10, font4);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font4, paint6);
        org.jfree.chart.text.TextLine textLine8 = textBlock7.getLastLine();
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("ThreadContext");
        textLine8.removeFragment(textFragment10);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(textLine8);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer3 };
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("ClassContext", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        java.awt.Stroke stroke9 = jFreeChart8.getBorderStroke();
        boolean boolean10 = jFreeChart8.isBorderVisible();
        jFreeChart8.setTextAntiAlias(false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.resizeRange((double) 'a', (double) (short) 10);
        org.jfree.data.Range range5 = null;
        try {
            dateAxis1.setRange(range5, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        categoryPlot0.setAnchorValue(0.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str6 = textTitle5.getURLText();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle5.setBackgroundPaint(paint7);
        categoryPlot0.setDomainGridlinePaint(paint7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        try {
            categoryPlot0.setRangeAxisLocation(axisLocation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection4);
        java.awt.Color color8 = java.awt.Color.ORANGE;
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset12 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer13 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot14 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset12, waferMapRenderer13);
        org.jfree.data.general.WaferMapDataset waferMapDataset15 = null;
        waferMapPlot14.setDataset(waferMapDataset15);
        waferMapPlot14.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot14);
        jFreeChart19.setBackgroundImageAlpha(1.0f);
        jFreeChart19.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = jFreeChart19.getPadding();
        org.jfree.chart.block.LineBorder lineBorder25 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color9, stroke10, rectangleInsets24);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color8, stroke10);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) valueMarker26);
        org.jfree.chart.util.Layer layer28 = null;
        try {
            boolean boolean29 = categoryPlot0.removeRangeMarker((int) ' ', (org.jfree.chart.plot.Marker) valueMarker26, layer28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets24);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double[] doubleArray4 = new double[] { 0.4d, (-1) };
        double[] doubleArray7 = new double[] { 0.4d, (-1) };
        double[] doubleArray10 = new double[] { 0.4d, (-1) };
        double[] doubleArray13 = new double[] { 0.4d, (-1) };
        double[] doubleArray16 = new double[] { 0.4d, (-1) };
        double[] doubleArray19 = new double[] { 0.4d, (-1) };
        double[][] doubleArray20 = new double[][] { doubleArray4, doubleArray7, doubleArray10, doubleArray13, doubleArray16, doubleArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "{0}", doubleArray20);
        try {
            org.jfree.data.general.PieDataset pieDataset23 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset21, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("RectangleEdge.TOP", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        ringPlot0.setLabelLinksVisible(false);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.Object obj2 = categoryAxis3D1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getFixedAutoRange();
        try {
            dateAxis0.setAutoRangeMinimumSize((double) 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        java.awt.Color color15 = java.awt.Color.ORANGE;
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset19 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer20 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot21 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset19, waferMapRenderer20);
        org.jfree.data.general.WaferMapDataset waferMapDataset22 = null;
        waferMapPlot21.setDataset(waferMapDataset22);
        waferMapPlot21.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot21);
        jFreeChart26.setBackgroundImageAlpha(1.0f);
        jFreeChart26.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = jFreeChart26.getPadding();
        org.jfree.chart.block.LineBorder lineBorder32 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color16, stroke17, rectangleInsets31);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color15, stroke17);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent34 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) valueMarker33);
        java.awt.Stroke stroke35 = valueMarker33.getOutlineStroke();
        org.jfree.chart.util.Layer layer36 = null;
        try {
            boolean boolean37 = xYPlot0.removeRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker33, layer36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getPadding();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle1.getTextAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = textTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createOutsetRectangle(rectangle2D5, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 1, 0);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke4);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        waferMapPlot4.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot4);
        jFreeChart9.setBackgroundImageAlpha(1.0f);
        jFreeChart9.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = jFreeChart9.getPadding();
        boolean boolean15 = jFreeChart9.isNotify();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart9, chartChangeEventType16);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str20 = textTitle19.getURLText();
        jFreeChart9.removeSubtitle((org.jfree.chart.title.Title) textTitle19);
        double double22 = textTitle19.getWidth();
        java.awt.Graphics2D graphics2D23 = null;
        try {
            org.jfree.chart.util.Size2D size2D24 = textTitle19.arrange(graphics2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        java.awt.Stroke stroke3 = ringPlot0.getSectionOutlineStroke((java.lang.Comparable) '#');
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(stroke3);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("{0}", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("hi!");
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        java.awt.Stroke stroke7 = null;
        try {
            xYPlot0.setRangeGridlineStroke(stroke7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setRangeCrosshairValue((double) 200, false);
        boolean boolean7 = categoryPlot3.isRangeCrosshairVisible();
        java.awt.Color color9 = java.awt.Color.white;
        java.awt.Color color10 = java.awt.Color.getColor("", color9);
        categoryPlot3.setNoDataMessagePaint((java.awt.Paint) color9);
        valueMarker2.setOutlinePaint((java.awt.Paint) color9);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = valueMarker2.getLabelOffset();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets13);
        double double16 = rectangleInsets13.calculateRightOutset((double) ' ');
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3.0d + "'", double16 == 3.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Range[100.0,100.0]");
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = null;
        categoryPlot2.setFixedLegendItems(legendItemCollection6);
        boolean boolean8 = unitType1.equals((java.lang.Object) legendItemCollection6);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.util.Layer layer10 = null;
        try {
            boolean boolean11 = xYPlot0.removeRangeMarker((int) 'a', (org.jfree.chart.plot.Marker) valueMarker9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setInfo("hi!");
        java.awt.Image image3 = null;
        projectInfo0.setLogo(image3);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer6 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset5, waferMapRenderer6);
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        waferMapPlot7.setDataset(waferMapDataset8);
        waferMapPlot7.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot7);
        jFreeChart12.setBackgroundImageAlpha(1.0f);
        jFreeChart12.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = jFreeChart12.getPadding();
        org.jfree.chart.block.LineBorder lineBorder18 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color2, stroke3, rectangleInsets17);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color1, stroke3);
        org.jfree.chart.text.TextAnchor textAnchor20 = null;
        try {
            valueMarker19.setLabelTextAnchor(textAnchor20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        java.awt.Color color2 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint5 = textTitle4.getPaint();
        java.awt.Color color6 = java.awt.Color.red;
        java.awt.Color color7 = java.awt.Color.red;
        java.awt.Color color8 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color2, paint5, color6, color7, color8 };
        java.awt.Paint[] paintArray10 = null;
        java.awt.Stroke stroke11 = null;
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] { stroke11 };
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] {};
        java.awt.Shape shape14 = null;
        java.awt.Shape[] shapeArray15 = new java.awt.Shape[] { shape14 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray10, strokeArray12, strokeArray13, shapeArray15);
        java.awt.Stroke stroke17 = defaultDrawingSupplier16.getNextStroke();
        java.awt.Paint paint18 = defaultDrawingSupplier16.getNextFillPaint();
        java.awt.Paint paint19 = defaultDrawingSupplier16.getNextPaint();
        categoryPlot0.setRangeGridlinePaint(paint19);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset25 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer26 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot27 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset25, waferMapRenderer26);
        org.jfree.data.general.WaferMapDataset waferMapDataset28 = null;
        waferMapPlot27.setDataset(waferMapDataset28);
        float float30 = waferMapPlot27.getBackgroundImageAlpha();
        valueMarker24.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot27);
        java.awt.Font font32 = valueMarker24.getLabelFont();
        dateAxis22.setTickLabelFont(font32);
        org.jfree.data.Range range34 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis22);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent35 = null;
        categoryPlot0.markerChanged(markerChangeEvent35);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.5f + "'", float30 == 0.5f);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNull(range34);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        dateAxis1.setAutoRange(false);
        dateAxis1.setAxisLineVisible(false);
        java.awt.Font font13 = dateAxis1.getLabelFont();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        java.awt.Color color2 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint5 = textTitle4.getPaint();
        java.awt.Color color6 = java.awt.Color.red;
        java.awt.Color color7 = java.awt.Color.red;
        java.awt.Color color8 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color2, paint5, color6, color7, color8 };
        java.awt.Paint[] paintArray10 = null;
        java.awt.Stroke stroke11 = null;
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] { stroke11 };
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] {};
        java.awt.Shape shape14 = null;
        java.awt.Shape[] shapeArray15 = new java.awt.Shape[] { shape14 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray10, strokeArray12, strokeArray13, shapeArray15);
        java.awt.Stroke stroke17 = defaultDrawingSupplier16.getNextStroke();
        java.awt.Paint paint18 = defaultDrawingSupplier16.getNextFillPaint();
        java.awt.Paint paint19 = defaultDrawingSupplier16.getNextPaint();
        categoryPlot0.setRangeGridlinePaint(paint19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(axisSpace21);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getPieWRadius();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getLabelLinkMargin();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str4 = textTitle3.getURLText();
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle3.setBackgroundPaint(paint5);
        textTitle3.setHeight((double) ' ');
        java.awt.Paint paint9 = textTitle3.getBackgroundPaint();
        piePlot3D0.setNoDataMessagePaint(paint9);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceText();
        java.lang.String str2 = projectInfo0.getName();
        java.lang.String str3 = projectInfo0.getLicenceText();
        projectInfo0.setLicenceText("{0}");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setInfo("hi!");
        projectInfo0.setInfo("");
        java.lang.String str5 = projectInfo0.getLicenceName();
        java.awt.Image image6 = projectInfo0.getLogo();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(image6);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textLine1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke2);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer(categoryItemRenderer5, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder8);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        jFreeChart8.setTitle("");
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        boolean boolean2 = ringPlot0.isCircular();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setRangeCrosshairValue((double) 200, false);
        boolean boolean9 = categoryPlot5.isRangeCrosshairVisible();
        java.awt.Color color11 = java.awt.Color.white;
        java.awt.Color color12 = java.awt.Color.getColor("", color11);
        categoryPlot5.setNoDataMessagePaint((java.awt.Paint) color11);
        valueMarker4.setOutlinePaint((java.awt.Paint) color11);
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color11);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) '#', stroke17);
        ringPlot0.setInteriorGap(0.0d);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(1.0d, 90.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        java.lang.String str4 = lengthConstraintType3.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "LengthConstraintType.FIXED" + "'", str4.equals("LengthConstraintType.FIXED"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 1, 0);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset9 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer10 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot11 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset9, waferMapRenderer10);
        org.jfree.data.general.WaferMapDataset waferMapDataset12 = null;
        waferMapPlot11.setDataset(waferMapDataset12);
        float float14 = waferMapPlot11.getBackgroundImageAlpha();
        valueMarker8.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot11);
        java.awt.Font font16 = valueMarker8.getLabelFont();
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        boolean boolean19 = textAnchor17.equals((java.lang.Object) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        valueMarker8.setLabelTextAnchor(textAnchor17);
        try {
            boolean boolean21 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D15.setTickLabelFont((java.lang.Comparable) (short) 10, font17);
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("hi!", font17);
        float float20 = textFragment19.getBaselineOffset();
        java.awt.Color color22 = java.awt.Color.ORANGE;
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset26 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer27 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot28 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset26, waferMapRenderer27);
        org.jfree.data.general.WaferMapDataset waferMapDataset29 = null;
        waferMapPlot28.setDataset(waferMapDataset29);
        waferMapPlot28.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot28);
        jFreeChart33.setBackgroundImageAlpha(1.0f);
        jFreeChart33.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = jFreeChart33.getPadding();
        org.jfree.chart.block.LineBorder lineBorder39 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color23, stroke24, rectangleInsets38);
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color22, stroke24);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent41 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) valueMarker40);
        boolean boolean42 = textFragment19.equals((java.lang.Object) valueMarker40);
        org.jfree.chart.util.Layer layer43 = null;
        try {
            boolean boolean44 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker40, layer43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        float float7 = waferMapPlot4.getBackgroundImageAlpha();
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot4);
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer11 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset10, waferMapRenderer11);
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        waferMapPlot12.setDataset(waferMapDataset13);
        waferMapPlot12.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot12);
        jFreeChart17.setBackgroundImageAlpha(1.0f);
        jFreeChart17.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = jFreeChart17.getPadding();
        boolean boolean23 = jFreeChart17.isNotify();
        waferMapPlot4.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart17);
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint26 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot25.setRangeZeroBaselinePaint(paint26);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray29 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer28 };
        xYPlot25.setRenderers(xYItemRendererArray29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        xYPlot25.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo33, point2D34);
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint37 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot36.setRangeZeroBaselinePaint(paint37);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray40 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer39 };
        xYPlot36.setRenderers(xYItemRendererArray40);
        xYPlot25.setRenderers(xYItemRendererArray40);
        try {
            jFreeChart17.setTextAntiAlias((java.lang.Object) xYPlot25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.plot.XYPlot@37e67978 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(xYItemRendererArray29);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(xYItemRendererArray40);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 100.0f, plotRenderingInfo5, point2D6);
        java.util.List list8 = categoryPlot0.getAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomRangeAxes((double) 'a', plotRenderingInfo10, point2D11, true);
        org.jfree.data.general.WaferMapDataset waferMapDataset15 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer16 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot17 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset15, waferMapRenderer16);
        org.jfree.data.general.WaferMapDataset waferMapDataset18 = null;
        waferMapPlot17.setDataset(waferMapDataset18);
        waferMapPlot17.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot17);
        jFreeChart22.setBackgroundImageAlpha(1.0f);
        jFreeChart22.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = jFreeChart22.getPadding();
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = textTitle29.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = textTitle29.getPosition();
        jFreeChart22.setTitle(textTitle29);
        java.awt.Color color33 = java.awt.Color.gray;
        jFreeChart22.setBackgroundPaint((java.awt.Paint) color33);
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart22);
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset38 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer39 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot40 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset38, waferMapRenderer39);
        org.jfree.data.general.WaferMapDataset waferMapDataset41 = null;
        waferMapPlot40.setDataset(waferMapDataset41);
        float float43 = waferMapPlot40.getBackgroundImageAlpha();
        valueMarker37.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot40);
        java.awt.Stroke stroke45 = valueMarker37.getOutlineStroke();
        try {
            boolean boolean46 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.5f + "'", float43 == 0.5f);
        org.junit.Assert.assertNotNull(stroke45);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        jFreeChart8.removeLegend();
        org.jfree.chart.event.ChartProgressListener chartProgressListener15 = null;
        jFreeChart8.removeProgressListener(chartProgressListener15);
        jFreeChart8.setTitle("UnitType.ABSOLUTE");
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        int int3 = java.awt.Color.HSBtoRGB(0.5f, (float) (short) 1, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16711681) + "'", int3 == (-16711681));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        double double3 = rectangleInsets0.trimHeight((double) (-1.0f));
        double double5 = rectangleInsets0.trimHeight(1.0d);
        org.jfree.chart.util.UnitType unitType6 = rectangleInsets0.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str1.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-9.0d) + "'", double3 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-7.0d) + "'", double5 == (-7.0d));
        org.junit.Assert.assertNotNull(unitType6);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setRangeCrosshairValue((double) 200, false);
        boolean boolean6 = categoryPlot2.isRangeCrosshairVisible();
        java.awt.Color color8 = java.awt.Color.white;
        java.awt.Color color9 = java.awt.Color.getColor("", color8);
        categoryPlot2.setNoDataMessagePaint((java.awt.Paint) color8);
        valueMarker1.setOutlinePaint((java.awt.Paint) color8);
        try {
            valueMarker1.setAlpha((float) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getURLText();
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle1.setBackgroundPaint(paint3);
        textTitle1.setHeight((double) ' ');
        java.awt.Paint paint7 = textTitle1.getBackgroundPaint();
        java.awt.Color color9 = java.awt.Color.ORANGE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer14 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot15 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset13, waferMapRenderer14);
        org.jfree.data.general.WaferMapDataset waferMapDataset16 = null;
        waferMapPlot15.setDataset(waferMapDataset16);
        waferMapPlot15.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot15);
        jFreeChart20.setBackgroundImageAlpha(1.0f);
        jFreeChart20.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = jFreeChart20.getPadding();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color10, stroke11, rectangleInsets25);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color9, stroke11);
        textTitle1.setPaint((java.awt.Paint) color9);
        textTitle1.setText("RectangleEdge.TOP");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = xYPlot0.getDomainAxisEdge();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis16 = xYPlot0.getDomainAxisForDataset(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 15 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean3 = numberAxis2.getAutoRangeIncludesZero();
        boolean boolean4 = numberAxis2.isAutoRange();
        numberAxis2.setLabelAngle((double) '4');
        org.jfree.data.RangeType rangeType7 = numberAxis2.getRangeType();
        numberAxis0.setRangeType(rangeType7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rangeType7);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        waferMapPlot4.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot4);
        jFreeChart9.setBackgroundImageAlpha(1.0f);
        jFreeChart9.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = jFreeChart9.getPadding();
        boolean boolean15 = jFreeChart9.isNotify();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart9, chartChangeEventType16);
        org.jfree.chart.JFreeChart jFreeChart18 = chartChangeEvent17.getChart();
        org.jfree.chart.title.LegendTitle legendTitle19 = null;
        try {
            jFreeChart18.addLegend(legendTitle19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(jFreeChart18);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getPadding();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle1.getTextAlignment();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint5 = categoryPlot4.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot4.getDomainAxisLocation();
        boolean boolean7 = horizontalAlignment3.equals((java.lang.Object) categoryPlot4);
        org.jfree.chart.plot.Plot plot8 = categoryPlot4.getParent();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset15 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer16 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot17 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset15, waferMapRenderer16);
        org.jfree.data.general.WaferMapDataset waferMapDataset18 = null;
        waferMapPlot17.setDataset(waferMapDataset18);
        float float20 = waferMapPlot17.getBackgroundImageAlpha();
        valueMarker14.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot17);
        java.awt.Font font22 = valueMarker14.getLabelFont();
        dateAxis12.setTickLabelFont(font22);
        org.jfree.data.Range range26 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis12.setRangeWithMargins(range26);
        java.util.TimeZone timeZone28 = dateAxis12.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("", timeZone28);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("hi!", timeZone28);
        org.jfree.data.Range range31 = categoryPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis30);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.5f + "'", float20 == 0.5f);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(range31);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer9 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot10 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset8, waferMapRenderer9);
        org.jfree.data.general.WaferMapDataset waferMapDataset11 = null;
        waferMapPlot10.setDataset(waferMapDataset11);
        float float13 = waferMapPlot10.getBackgroundImageAlpha();
        valueMarker7.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot10);
        java.awt.Font font15 = valueMarker7.getLabelFont();
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        boolean boolean18 = textAnchor16.equals((java.lang.Object) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        valueMarker7.setLabelTextAnchor(textAnchor16);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("TextAnchor.HALF_ASCENT_CENTER", graphics2D1, (float) (byte) -1, (float) (short) 100, textAnchor4, 8.0d, textAnchor16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint3 = categoryPlot2.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = null;
        categoryPlot2.setFixedLegendItems(legendItemCollection4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot2.getRangeAxisForDataset((-1));
        categoryPlot2.setDomainGridlinesVisible(false);
        categoryAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        categoryAxis3D1.configure();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(valueAxis7);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        org.jfree.data.general.WaferMapDataset waferMapDataset7 = null;
        waferMapPlot6.setDataset(waferMapDataset7);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) waferMapPlot6);
        categoryPlot0.notifyListeners(plotChangeEvent9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            categoryPlot0.drawBackground(graphics2D11, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str2 = categoryAxis3D1.getLabelURL();
        java.awt.Paint paint4 = categoryAxis3D1.getTickLabelPaint((java.lang.Comparable) "ThreadContext");
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.mapDatasetToDomainAxis((int) (short) 1, 0);
        categoryPlot8.setDrawSharedDomainAxis(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot8.getDomainAxisEdge((int) (byte) 10);
        try {
            double double16 = categoryAxis3D1.getCategoryMiddle((int) (short) 1, (int) (short) 10, rectangle2D7, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getPadding();
        double double3 = rectangleInsets2.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean2 = numberAxis0.isAutoRange();
        numberAxis0.setLabelAngle((double) '4');
        org.jfree.data.RangeType rangeType5 = numberAxis0.getRangeType();
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis0.getStandardTickUnits();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rangeType5);
        org.junit.Assert.assertNotNull(tickUnitSource6);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("UnitType.ABSOLUTE", graphics2D1, (-9.0d), (float) (-16711681), 2.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getNoDataMessagePaint();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot3.setRangeCrosshairStroke(stroke5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot3.getDomainAxisLocation();
        xYPlot0.setRangeAxisLocation(axisLocation7, false);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot0.getDomainAxisForDataset((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index -1 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str2 = categoryAxis3D1.getLabelURL();
        double double3 = categoryAxis3D1.getLowerMargin();
        double double4 = categoryAxis3D1.getCategoryMargin();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        int int1 = color0.getGreen();
        int int2 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 200 + "'", int1 == 200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        java.awt.Stroke stroke9 = jFreeChart8.getBorderStroke();
        boolean boolean10 = jFreeChart8.isBorderVisible();
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str13 = textTitle12.getURLText();
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle12.setBackgroundPaint(paint14);
        textTitle12.setPadding((double) 0, (double) '#', (double) (byte) 0, (-7.0d));
        jFreeChart8.setTitle(textTitle12);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getURLText();
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle1.setBackgroundPaint(paint3);
        textTitle1.setHeight((double) ' ');
        org.jfree.chart.util.Size2D size2D7 = new org.jfree.chart.util.Size2D();
        boolean boolean8 = textTitle1.equals((java.lang.Object) size2D7);
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer11 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset10, waferMapRenderer11);
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        waferMapPlot12.setDataset(waferMapDataset13);
        waferMapPlot12.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot12);
        java.awt.Stroke stroke18 = jFreeChart17.getBorderStroke();
        boolean boolean19 = jFreeChart17.isBorderVisible();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.data.general.WaferMapDataset waferMapDataset21 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer22 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot23 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset21, waferMapRenderer22);
        org.jfree.data.general.WaferMapDataset waferMapDataset24 = null;
        waferMapPlot23.setDataset(waferMapDataset24);
        boolean boolean26 = chartChangeEventType20.equals((java.lang.Object) waferMapPlot23);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textTitle1, jFreeChart17, chartChangeEventType20);
        java.lang.String str28 = chartChangeEvent27.toString();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D2.setTickLabelFont((java.lang.Comparable) (short) 10, font4);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font4, paint6);
        org.jfree.chart.text.TextLine textLine8 = textBlock7.getLastLine();
        org.jfree.chart.text.TextFragment textFragment9 = null;
        textLine8.addFragment(textFragment9);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(textLine8);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        java.lang.String str2 = unitType1.toString();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        boolean boolean4 = unitType1.equals((java.lang.Object) textBlockAnchor3);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UnitType.ABSOLUTE" + "'", str2.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.awt.Color color1 = java.awt.Color.getColor("Rotation.CLOCKWISE");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.resizeRange((double) 'a', (double) (short) 10);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = null;
        try {
            dateAxis1.setTickMarkPosition(dateTickMarkPosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        xYPlot0.setRangeCrosshairValue((double) 2, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        java.awt.Color color1 = java.awt.Color.DARK_GRAY;
        boolean boolean2 = lengthConstraintType0.equals((java.lang.Object) color1);
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isRadiusGridlinesVisible();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.Point point5 = polarPlot0.translateValueThetaRadiusToJava2D((double) 1L, (-7.0d), rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke1 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer4 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset3, waferMapRenderer4);
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        waferMapPlot5.setDataset(waferMapDataset6);
        waferMapPlot5.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot5);
        jFreeChart10.setBackgroundImageAlpha(1.0f);
        jFreeChart10.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = jFreeChart10.getPadding();
        org.jfree.chart.block.LineBorder lineBorder16 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets15);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets15.createInsetRectangle(rectangle2D17, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        strokeMap0.clear();
        java.awt.Stroke stroke3 = strokeMap0.getStroke((java.lang.Comparable) 'a');
        org.junit.Assert.assertNull(stroke3);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets2.createOutsetRectangle(rectangle2D3, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D3.setTickLabelFont((java.lang.Comparable) (short) 10, font5);
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("hi!", font5);
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("ClassContext", font5);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        try {
            categoryPlot0.setRangeAxis((int) (short) -1, valueAxis5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace14 = xYPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNull(axisSpace14);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke1 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer4 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset3, waferMapRenderer4);
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        waferMapPlot5.setDataset(waferMapDataset6);
        waferMapPlot5.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot5);
        jFreeChart10.setBackgroundImageAlpha(1.0f);
        jFreeChart10.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = jFreeChart10.getPadding();
        org.jfree.chart.block.LineBorder lineBorder16 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets15);
        java.lang.String str17 = rectangleInsets15.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str17.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        org.jfree.data.Range range11 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis1.setRange(range11, false, false);
        org.jfree.data.Range range16 = org.jfree.data.Range.shift(range11, (double) (short) 0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        java.lang.Object obj3 = null;
        boolean boolean4 = categoryPlot0.equals(obj3);
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        java.awt.Shape shape14 = dateAxis12.getUpArrow();
        dateAxis12.centerRange((double) (short) 1);
        dateAxis12.setRange(0.0d, (double) '#');
        dateAxis12.setAutoRange(false);
        categoryPlot7.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis12);
        categoryPlot0.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        boolean boolean2 = ringPlot0.isCircular();
        java.awt.Paint paint3 = ringPlot0.getSeparatorPaint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat5 = standardPieSectionLabelGenerator4.getNumberFormat();
        java.lang.Object obj6 = standardPieSectionLabelGenerator4.clone();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.lang.String str8 = standardPieSectionLabelGenerator4.getLabelFormat();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(numberFormat5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "{0}" + "'", str8.equals("{0}"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer6 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset5, waferMapRenderer6);
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        waferMapPlot7.setDataset(waferMapDataset8);
        waferMapPlot7.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot7);
        jFreeChart12.setBackgroundImageAlpha(1.0f);
        jFreeChart12.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = jFreeChart12.getPadding();
        org.jfree.chart.block.LineBorder lineBorder18 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color2, stroke3, rectangleInsets17);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color1, stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = valueMarker19.getLabelOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = null;
        try {
            valueMarker19.setLabelOffset(rectangleInsets21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangleInsets20);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getInteriorGap();
        boolean boolean2 = piePlot3D0.getDarkerSides();
        java.awt.Color color3 = java.awt.Color.ORANGE;
        int int4 = color3.getGreen();
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color3.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        boolean boolean11 = piePlot3D0.equals((java.lang.Object) colorModel5);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint13 = ringPlot12.getLabelBackgroundPaint();
        ringPlot12.setShadowXOffset((double) (-1.0f));
        org.jfree.chart.util.Rotation rotation16 = ringPlot12.getDirection();
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint18 = ringPlot17.getLabelBackgroundPaint();
        boolean boolean19 = ringPlot17.isCircular();
        java.awt.Paint paint20 = ringPlot17.getSeparatorPaint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator21 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat22 = standardPieSectionLabelGenerator21.getNumberFormat();
        java.lang.Object obj23 = standardPieSectionLabelGenerator21.clone();
        ringPlot17.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator21);
        ringPlot12.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator21);
        piePlot3D0.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator21);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08d + "'", double1 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 200 + "'", int4 == 200);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rotation16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(numberFormat22);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        categoryPlot3.setFixedLegendItems(legendItemCollection5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot3.getDomainAxisEdge((int) (byte) 10);
        textTitle2.setPosition(rectangleEdge8);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        categoryPlot0.setAnchorValue(0.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str6 = textTitle5.getURLText();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle5.setBackgroundPaint(paint7);
        categoryPlot0.setDomainGridlinePaint(paint7);
        boolean boolean10 = categoryPlot0.isDomainGridlinesVisible();
        int int11 = categoryPlot0.getWeight();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace1);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        try {
            xYPlot0.addDomainMarker((int) (byte) 10, marker4, layer5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getPadding();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle1.getTextAlignment();
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        java.awt.Paint paint5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        textTitle1.setPaint(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getURLText();
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle1.setBackgroundPaint(paint3);
        java.lang.String str5 = textTitle1.getURLText();
        java.lang.Object obj6 = textTitle1.clone();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setRangeCrosshairValue((double) 200, false);
        boolean boolean5 = categoryPlot1.isRangeCrosshairVisible();
        java.awt.Color color7 = java.awt.Color.white;
        java.awt.Color color8 = java.awt.Color.getColor("", color7);
        categoryPlot1.setNoDataMessagePaint((java.awt.Paint) color7);
        piePlot3D0.setLabelLinkPaint((java.awt.Paint) color7);
        piePlot3D0.setSectionOutlinesVisible(false);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            piePlot3D0.drawOutline(graphics2D13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        waferMapPlot4.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot4);
        jFreeChart9.setBackgroundImageAlpha(1.0f);
        jFreeChart9.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = jFreeChart9.getPadding();
        boolean boolean15 = jFreeChart9.isNotify();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart9, chartChangeEventType16);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str20 = textTitle19.getURLText();
        jFreeChart9.removeSubtitle((org.jfree.chart.title.Title) textTitle19);
        jFreeChart9.setBackgroundImageAlpha((float) 0L);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot24.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot24.zoomDomainAxes((double) 100.0f, plotRenderingInfo29, point2D30);
        java.util.List list32 = categoryPlot24.getAnnotations();
        jFreeChart9.setSubtitles(list32);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(list32);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke1 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer4 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset3, waferMapRenderer4);
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        waferMapPlot5.setDataset(waferMapDataset6);
        waferMapPlot5.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot5);
        jFreeChart10.setBackgroundImageAlpha(1.0f);
        jFreeChart10.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = jFreeChart10.getPadding();
        org.jfree.chart.block.LineBorder lineBorder16 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets15);
        java.awt.Paint paint17 = lineBorder16.getPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.HALF_ASCENT_CENTER");
        numberAxis1.setAutoRangeIncludesZero(true);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint7 = categoryPlot6.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge((int) (byte) 10);
        boolean boolean12 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge11);
        try {
            double double13 = numberAxis1.java2DToValue((double) 200, rectangle2D5, rectangleEdge11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 10.0d, 0.14d, 0, (java.lang.Comparable) "{0}");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "RectangleEdge.TOP", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "");
        org.jfree.chart.ui.ProjectInfo projectInfo5 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str6 = projectInfo5.getLicenceText();
        org.jfree.chart.ui.Library[] libraryArray7 = projectInfo5.getLibraries();
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo5);
        java.lang.String str9 = projectInfo5.getLicenceText();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(libraryArray7);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer6 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset5, waferMapRenderer6);
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        waferMapPlot7.setDataset(waferMapDataset8);
        float float10 = waferMapPlot7.getBackgroundImageAlpha();
        valueMarker4.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot7);
        java.awt.Font font12 = valueMarker4.getLabelFont();
        dateAxis2.setTickLabelFont(font12);
        org.jfree.data.Range range16 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis2.setRangeWithMargins(range16);
        java.util.TimeZone timeZone18 = dateAxis2.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("", timeZone18);
        dateAxis19.setRange((double) (short) 10, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(timeZone18);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.awt.Color color0 = java.awt.Color.red;
        float[] floatArray6 = new float[] { '4', (-1L), 10L, 10.0f, 0 };
        float[] floatArray7 = color0.getComponents(floatArray6);
        java.awt.color.ColorSpace colorSpace8 = null;
        java.awt.Color color9 = java.awt.Color.gray;
        java.awt.Color color10 = java.awt.Color.green;
        java.awt.Color color11 = java.awt.Color.red;
        float[] floatArray17 = new float[] { '4', (-1L), 10L, 10.0f, 0 };
        float[] floatArray18 = color11.getComponents(floatArray17);
        float[] floatArray19 = color10.getColorComponents(floatArray17);
        float[] floatArray20 = color9.getComponents(floatArray19);
        try {
            float[] floatArray21 = color0.getComponents(colorSpace8, floatArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray5 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[100.0,100.0]", "Category Plot", numberArray5);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        java.awt.Color color2 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint5 = textTitle4.getPaint();
        java.awt.Color color6 = java.awt.Color.red;
        java.awt.Color color7 = java.awt.Color.red;
        java.awt.Color color8 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color2, paint5, color6, color7, color8 };
        java.awt.Paint[] paintArray10 = null;
        java.awt.Stroke stroke11 = null;
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] { stroke11 };
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] {};
        java.awt.Shape shape14 = null;
        java.awt.Shape[] shapeArray15 = new java.awt.Shape[] { shape14 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray10, strokeArray12, strokeArray13, shapeArray15);
        java.awt.Stroke stroke17 = defaultDrawingSupplier16.getNextStroke();
        java.awt.Paint paint18 = defaultDrawingSupplier16.getNextFillPaint();
        java.awt.Paint paint19 = defaultDrawingSupplier16.getNextPaint();
        categoryPlot0.setRangeGridlinePaint(paint19);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset25 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer26 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot27 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset25, waferMapRenderer26);
        org.jfree.data.general.WaferMapDataset waferMapDataset28 = null;
        waferMapPlot27.setDataset(waferMapDataset28);
        float float30 = waferMapPlot27.getBackgroundImageAlpha();
        valueMarker24.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot27);
        java.awt.Font font32 = valueMarker24.getLabelFont();
        dateAxis22.setTickLabelFont(font32);
        org.jfree.data.Range range34 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis22);
        boolean boolean35 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        categoryPlot0.setRenderer((int) ' ', categoryItemRenderer37, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.5f + "'", float30 == 0.5f);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("ClassContext");
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        ringPlot0.setShadowXOffset((double) (-1.0f));
        ringPlot0.setExplodePercent((java.lang.Comparable) "ThreadContext", (double) (-1.0f));
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = textTitle15.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = textTitle15.getPosition();
        jFreeChart8.setTitle(textTitle15);
        org.jfree.chart.block.BlockFrame blockFrame19 = textTitle15.getFrame();
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(blockFrame19);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", graphics2D1, 0.0d, (float) (short) -1, (float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getFixedAutoRange();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        double double3 = dateAxis0.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setInfo("hi!");
        projectInfo0.setInfo("");
        org.jfree.chart.ui.ProjectInfo projectInfo5 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str6 = projectInfo5.getLicenceText();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo5);
        java.lang.String str8 = projectInfo0.getLicenceText();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        float float7 = waferMapPlot4.getBackgroundImageAlpha();
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker1.setLabelAnchor(rectangleAnchor9);
        java.awt.Paint paint11 = valueMarker1.getOutlinePaint();
        float float12 = valueMarker1.getAlpha();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape15 = dateAxis14.getDownArrow();
        java.awt.Shape shape16 = dateAxis14.getUpArrow();
        dateAxis14.centerRange((double) (short) 1);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset22 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer23 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot24 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset22, waferMapRenderer23);
        org.jfree.data.general.WaferMapDataset waferMapDataset25 = null;
        waferMapPlot24.setDataset(waferMapDataset25);
        waferMapPlot24.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot24);
        jFreeChart29.setBackgroundImageAlpha(1.0f);
        jFreeChart29.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = jFreeChart29.getPadding();
        org.jfree.chart.block.LineBorder lineBorder35 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color19, stroke20, rectangleInsets34);
        dateAxis14.setTickMarkStroke(stroke20);
        valueMarker1.setStroke(stroke20);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.8f + "'", float12 == 0.8f);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets34);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 100.0f, plotRenderingInfo5, point2D6);
        java.util.List list8 = categoryPlot0.getAnnotations();
        org.jfree.chart.util.SortOrder sortOrder9 = null;
        try {
            categoryPlot0.setColumnRenderingOrder(sortOrder9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("ChartChangeEventType.DATASET_UPDATED");
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke2);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer(categoryItemRenderer5, true);
        java.awt.Stroke stroke8 = null;
        try {
            categoryPlot0.setRangeGridlineStroke(stroke8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.block.Arrangement arrangement2 = blockContainer1.getArrangement();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset9 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer10 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot11 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset9, waferMapRenderer10);
        org.jfree.data.general.WaferMapDataset waferMapDataset12 = null;
        waferMapPlot11.setDataset(waferMapDataset12);
        float float14 = waferMapPlot11.getBackgroundImageAlpha();
        valueMarker8.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot11);
        java.awt.Font font16 = valueMarker8.getLabelFont();
        dateAxis6.setTickLabelFont(font16);
        try {
            java.lang.Object obj18 = blockContainer1.draw(graphics2D3, rectangle2D4, (java.lang.Object) font16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrangement2);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        java.awt.Shape shape7 = dateAxis5.getUpArrow();
        dateAxis5.centerRange((double) (short) 1);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer14 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot15 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset13, waferMapRenderer14);
        org.jfree.data.general.WaferMapDataset waferMapDataset16 = null;
        waferMapPlot15.setDataset(waferMapDataset16);
        waferMapPlot15.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot15);
        jFreeChart20.setBackgroundImageAlpha(1.0f);
        jFreeChart20.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = jFreeChart20.getPadding();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color10, stroke11, rectangleInsets25);
        dateAxis5.setTickMarkStroke(stroke11);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer28);
        dateAxis5.zoomRange((double) (-1), (double) (byte) 100);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.Color color3 = java.awt.Color.getColor("", color2);
        ringPlot0.setLabelPaint((java.awt.Paint) color3);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = ringPlot0.getLegendLabelToolTipGenerator();
        java.lang.String str6 = ringPlot0.getPlotType();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Pie Plot" + "'", str6.equals("Pie Plot"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 0.14d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        java.lang.Class class2 = null;
        try {
            java.util.EventListener[] eventListenerArray3 = valueMarker1.getListeners(class2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 10);
        int int2 = pieLabelDistributor1.getItemCount();
        java.lang.String str3 = pieLabelDistributor1.toString();
        pieLabelDistributor1.sort();
        int int5 = pieLabelDistributor1.getItemCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        boolean boolean9 = dateAxis1.isNegativeArrowVisible();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = dateAxis1.valueToJava2D(0.12d, rectangle2D11, rectangleEdge12);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape4 = dateAxis3.getDownArrow();
        dateAxis1.setUpArrow(shape4);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer11 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset10, waferMapRenderer11);
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        waferMapPlot12.setDataset(waferMapDataset13);
        float float15 = waferMapPlot12.getBackgroundImageAlpha();
        valueMarker9.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot12);
        java.awt.Font font17 = valueMarker9.getLabelFont();
        dateAxis7.setTickLabelFont(font17);
        org.jfree.data.Range range21 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis7.setRangeWithMargins(range21);
        dateAxis1.setRange(range21);
        double double24 = dateAxis1.getLowerMargin();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        java.awt.Color color2 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint5 = textTitle4.getPaint();
        java.awt.Color color6 = java.awt.Color.red;
        java.awt.Color color7 = java.awt.Color.red;
        java.awt.Color color8 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color2, paint5, color6, color7, color8 };
        java.awt.Paint[] paintArray10 = null;
        java.awt.Stroke stroke11 = null;
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] { stroke11 };
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] {};
        java.awt.Shape shape14 = null;
        java.awt.Shape[] shapeArray15 = new java.awt.Shape[] { shape14 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray10, strokeArray12, strokeArray13, shapeArray15);
        java.awt.Stroke stroke17 = defaultDrawingSupplier16.getNextStroke();
        java.awt.Paint paint18 = defaultDrawingSupplier16.getNextFillPaint();
        java.awt.Paint paint19 = defaultDrawingSupplier16.getNextPaint();
        categoryPlot0.setRangeGridlinePaint(paint19);
        java.util.List list21 = categoryPlot0.getCategories();
        java.awt.Stroke stroke22 = categoryPlot0.getDomainGridlineStroke();
        boolean boolean23 = categoryPlot0.isRangeZoomable();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(list21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint17 = categoryPlot16.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot16.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation18);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset22 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer23 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot24 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset22, waferMapRenderer23);
        org.jfree.data.general.WaferMapDataset waferMapDataset25 = null;
        waferMapPlot24.setDataset(waferMapDataset25);
        float float27 = waferMapPlot24.getBackgroundImageAlpha();
        valueMarker21.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot24);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker21.setLabelAnchor(rectangleAnchor29);
        java.awt.Paint paint31 = valueMarker21.getOutlinePaint();
        try {
            boolean boolean32 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.5f + "'", float27 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint5 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot4.setRangeZeroBaselinePaint(paint5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray8 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer7 };
        xYPlot4.setRenderers(xYItemRendererArray8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot4.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo12, point2D13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace15);
        java.awt.Stroke stroke17 = xYPlot4.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D18 = xYPlot4.getQuadrantOrigin();
        polarPlot0.zoomDomainAxes(1.0E-8d, plotRenderingInfo3, point2D18);
        try {
            double double20 = polarPlot0.getMaxRadius();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(xYItemRendererArray8);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(point2D18);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getRangeAxisLocation();
        java.awt.Paint paint5 = categoryPlot0.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot0.getRenderer(0);
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot0.getDomainAxisForDataset((int) (byte) 0);
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNull(valueAxis14);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        java.awt.Color color2 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint5 = textTitle4.getPaint();
        java.awt.Color color6 = java.awt.Color.red;
        java.awt.Color color7 = java.awt.Color.red;
        java.awt.Color color8 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color2, paint5, color6, color7, color8 };
        java.awt.Paint[] paintArray10 = null;
        java.awt.Stroke stroke11 = null;
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] { stroke11 };
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] {};
        java.awt.Shape shape14 = null;
        java.awt.Shape[] shapeArray15 = new java.awt.Shape[] { shape14 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray10, strokeArray12, strokeArray13, shapeArray15);
        java.awt.Stroke stroke17 = defaultDrawingSupplier16.getNextStroke();
        java.awt.Paint paint18 = defaultDrawingSupplier16.getNextFillPaint();
        java.awt.Paint paint19 = defaultDrawingSupplier16.getNextPaint();
        categoryPlot0.setRangeGridlinePaint(paint19);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset25 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer26 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot27 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset25, waferMapRenderer26);
        org.jfree.data.general.WaferMapDataset waferMapDataset28 = null;
        waferMapPlot27.setDataset(waferMapDataset28);
        float float30 = waferMapPlot27.getBackgroundImageAlpha();
        valueMarker24.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot27);
        java.awt.Font font32 = valueMarker24.getLabelFont();
        dateAxis22.setTickLabelFont(font32);
        org.jfree.data.Range range34 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis22);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = categoryPlot0.getRangeMarkers(layer37);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder39 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.5f + "'", float30 == 0.5f);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertNotNull(datasetRenderingOrder39);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(categoryAxis5);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color7 = java.awt.Color.ORANGE;
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset11 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer12 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset11, waferMapRenderer12);
        org.jfree.data.general.WaferMapDataset waferMapDataset14 = null;
        waferMapPlot13.setDataset(waferMapDataset14);
        waferMapPlot13.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot13);
        jFreeChart18.setBackgroundImageAlpha(1.0f);
        jFreeChart18.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = jFreeChart18.getPadding();
        org.jfree.chart.block.LineBorder lineBorder24 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color8, stroke9, rectangleInsets23);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color7, stroke9);
        polarPlot5.setRadiusGridlineStroke(stroke9);
        java.awt.Stroke stroke27 = polarPlot5.getRadiusGridlineStroke();
        categoryPlot0.setDomainGridlineStroke(stroke27);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.block.Arrangement arrangement2 = blockContainer1.getArrangement();
        java.util.List list3 = blockContainer1.getBlocks();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer11 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset10, waferMapRenderer11);
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        waferMapPlot12.setDataset(waferMapDataset13);
        float float15 = waferMapPlot12.getBackgroundImageAlpha();
        valueMarker9.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot12);
        java.awt.Font font17 = valueMarker9.getLabelFont();
        dateAxis7.setTickLabelFont(font17);
        org.jfree.data.Range range21 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis7.setRangeWithMargins(range21);
        double double23 = range21.getCentralValue();
        java.lang.String str24 = range21.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint(1.0E-5d, range21);
        try {
            org.jfree.chart.util.Size2D size2D26 = blockContainer1.arrange(graphics2D4, rectangleConstraint25);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(arrangement2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.0d + "'", double23 == 100.0d);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Range[100.0,100.0]" + "'", str24.equals("Range[100.0,100.0]"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        boolean boolean2 = ringPlot0.isCircular();
        java.awt.Paint paint3 = ringPlot0.getSeparatorPaint();
        double double4 = ringPlot0.getSectionDepth();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 100.0f, plotRenderingInfo5, point2D6);
        java.util.List list8 = categoryPlot0.getAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomRangeAxes((double) 'a', plotRenderingInfo10, point2D11, true);
        java.awt.Stroke stroke14 = null;
        try {
            categoryPlot0.setRangeCrosshairStroke(stroke14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        boolean boolean2 = ringPlot0.isCircular();
        java.awt.Paint paint3 = ringPlot0.getSeparatorPaint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat5 = standardPieSectionLabelGenerator4.getNumberFormat();
        java.lang.Object obj6 = standardPieSectionLabelGenerator4.clone();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.text.NumberFormat numberFormat8 = standardPieSectionLabelGenerator4.getPercentFormat();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(numberFormat5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(numberFormat8);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        waferMapPlot4.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot4);
        jFreeChart9.setBackgroundImageAlpha(1.0f);
        jFreeChart9.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = jFreeChart9.getPadding();
        boolean boolean15 = jFreeChart9.isNotify();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart9, chartChangeEventType16);
        org.jfree.chart.event.ChartProgressListener chartProgressListener18 = null;
        jFreeChart9.addProgressListener(chartProgressListener18);
        org.jfree.chart.plot.Plot plot20 = jFreeChart9.getPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font25 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D23.setTickLabelFont((java.lang.Comparable) (short) 10, font25);
        java.awt.Paint paint27 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextBlock textBlock28 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font25, paint27);
        plot20.setNoDataMessageFont(font25);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(plot20);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(textBlock28);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        java.awt.Color color2 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint5 = textTitle4.getPaint();
        java.awt.Color color6 = java.awt.Color.red;
        java.awt.Color color7 = java.awt.Color.red;
        java.awt.Color color8 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color2, paint5, color6, color7, color8 };
        java.awt.Paint[] paintArray10 = null;
        java.awt.Stroke stroke11 = null;
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] { stroke11 };
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] {};
        java.awt.Shape shape14 = null;
        java.awt.Shape[] shapeArray15 = new java.awt.Shape[] { shape14 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray10, strokeArray12, strokeArray13, shapeArray15);
        java.awt.Stroke stroke17 = defaultDrawingSupplier16.getNextStroke();
        java.awt.Paint paint18 = defaultDrawingSupplier16.getNextFillPaint();
        java.awt.Paint paint19 = defaultDrawingSupplier16.getNextPaint();
        categoryPlot0.setRangeGridlinePaint(paint19);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset25 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer26 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot27 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset25, waferMapRenderer26);
        org.jfree.data.general.WaferMapDataset waferMapDataset28 = null;
        waferMapPlot27.setDataset(waferMapDataset28);
        float float30 = waferMapPlot27.getBackgroundImageAlpha();
        valueMarker24.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot27);
        java.awt.Font font32 = valueMarker24.getLabelFont();
        dateAxis22.setTickLabelFont(font32);
        org.jfree.data.Range range34 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis22);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = categoryPlot0.getRangeMarkers(layer37);
        categoryPlot0.clearAnnotations();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.5f + "'", float30 == 0.5f);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNull(collection38);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str2 = categoryAxis3D1.getLabelURL();
        double double3 = categoryAxis3D1.getCategoryMargin();
        categoryAxis3D1.setLabelURL("RectangleEdge.TOP");
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getURLText();
        java.awt.Paint paint9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle7.setBackgroundPaint(paint9);
        java.lang.String str11 = textTitle7.getURLText();
        boolean boolean12 = categoryAxis3D1.equals((java.lang.Object) str11);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint17 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot16.setRangeZeroBaselinePaint(paint17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer19 };
        xYPlot16.setRenderers(xYItemRendererArray20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        xYPlot16.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo24, point2D25);
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        xYPlot16.setFixedRangeAxisSpace(axisSpace27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot16.getDomainAxisEdge();
        try {
            double double30 = categoryAxis3D1.getCategoryEnd(255, 255, rectangle2D15, rectangleEdge29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = null;
        double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getNoDataMessagePaint();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot3.setRangeCrosshairStroke(stroke5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot3.getDomainAxisLocation();
        xYPlot0.setRangeAxisLocation(axisLocation7, false);
        try {
            java.awt.Paint paint11 = xYPlot0.getQuadrantPaint((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (35) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str2 = categoryAxis3D1.getLabelURL();
        double double3 = categoryAxis3D1.getCategoryMargin();
        categoryAxis3D1.setLabelURL("RectangleEdge.TOP");
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis3D1.setTickMarkStroke(stroke6);
        java.awt.Font font9 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) (short) 100);
        java.awt.Paint paint11 = null;
        categoryAxis3D1.setTickLabelPaint((java.lang.Comparable) (-1L), paint11);
        java.awt.Paint paint13 = categoryAxis3D1.getTickMarkPaint();
        categoryAxis3D1.removeCategoryLabelToolTip((java.lang.Comparable) (-1.0f));
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = waferMapPlot2.getDrawingSupplier();
        org.junit.Assert.assertNotNull(drawingSupplier3);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getURLText();
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle1.setBackgroundPaint(paint3);
        textTitle1.setHeight((double) ' ');
        textTitle1.setHeight((double) 10);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.awt.Font font3 = textTitle2.getFont();
        java.lang.String str4 = textTitle2.getID();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str2 = categoryAxis3D1.getLabelURL();
        java.awt.Paint paint4 = categoryAxis3D1.getTickLabelPaint((java.lang.Comparable) "ThreadContext");
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setRangeCrosshairValue((double) 200, false);
        boolean boolean12 = categoryPlot8.isRangeCrosshairVisible();
        java.awt.Color color14 = java.awt.Color.white;
        java.awt.Color color15 = java.awt.Color.getColor("", color14);
        categoryPlot8.setNoDataMessagePaint((java.awt.Paint) color14);
        valueMarker7.setOutlinePaint((java.awt.Paint) color14);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = valueMarker7.getLabelOffset();
        java.awt.Font font19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        valueMarker7.setLabelFont(font19);
        categoryAxis3D1.setTickLabelFont((java.lang.Comparable) 4.0d, font19);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 10);
        pieLabelDistributor1.sort();
        pieLabelDistributor1.distributeLabels(100.0d, (double) 1L);
        pieLabelDistributor1.sort();
        pieLabelDistributor1.distributeLabels((double) (-1L), 0.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        boolean boolean9 = dateAxis1.isNegativeArrowVisible();
        double double10 = dateAxis1.getFixedDimension();
        dateAxis1.setNegativeArrowVisible(false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean2 = numberAxis0.isAutoRange();
        numberAxis0.setLabelAngle((double) '4');
        java.awt.Font font5 = numberAxis0.getLabelFont();
        numberAxis0.setAutoRangeIncludesZero(false);
        boolean boolean8 = numberAxis0.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint12 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot11.setRangeZeroBaselinePaint(paint12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray15 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer14 };
        xYPlot11.setRenderers(xYItemRendererArray15);
        xYPlot0.setRenderers(xYItemRendererArray15);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape20 = dateAxis19.getDownArrow();
        java.awt.Shape shape21 = dateAxis19.getUpArrow();
        dateAxis19.centerRange((double) (short) 1);
        dateAxis19.setRange(0.0d, (double) '#');
        dateAxis19.setAutoRange(false);
        dateAxis19.setRangeWithMargins((double) 'a', (double) 100.0f);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = new org.jfree.chart.axis.ValueAxis[] { dateAxis19 };
        xYPlot0.setRangeAxes(valueAxisArray32);
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        valueMarker35.setValue((double) 1.0f);
        try {
            boolean boolean38 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(xYItemRendererArray15);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(valueAxisArray32);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        categoryPlot0.setAnchorValue(0.0d);
        categoryPlot0.setOutlineVisible(false);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Color color6 = java.awt.Color.white;
        java.awt.Color color7 = java.awt.Color.getColor("", color6);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        categoryPlot0.setForegroundAlpha((float) 0L);
        java.util.List list12 = categoryPlot0.getCategories();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(list12);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        categoryPlot0.setAnchorValue(0.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str6 = textTitle5.getURLText();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle5.setBackgroundPaint(paint7);
        categoryPlot0.setDomainGridlinePaint(paint7);
        categoryPlot0.setWeight((int) (byte) -1);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot0.getDomainMarkers((int) (short) 0, layer13);
        categoryPlot0.clearDomainMarkers(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot0.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot0.getRenderer(0);
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot0.getDomainAxisForDataset((int) (byte) 0);
        xYPlot0.setDomainGridlinesVisible(true);
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNull(valueAxis14);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray3 = null;
        float[] floatArray4 = color2.getRGBComponents(floatArray3);
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color2);
        java.awt.Paint paint6 = blockBorder5.getPaint();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str1.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.clearCategoryLabelToolTips();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.mapDatasetToDomainAxis((int) (short) 1, 0);
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot6.getDomainAxisEdge((int) (byte) 10);
        try {
            double double14 = categoryAxis3D0.getCategoryJava2DCoordinate(categoryAnchor2, (int) (short) 1, (int) (byte) 10, rectangle2D5, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        java.awt.Color color2 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint5 = textTitle4.getPaint();
        java.awt.Color color6 = java.awt.Color.red;
        java.awt.Color color7 = java.awt.Color.red;
        java.awt.Color color8 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color2, paint5, color6, color7, color8 };
        java.awt.Paint[] paintArray10 = null;
        java.awt.Stroke stroke11 = null;
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] { stroke11 };
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] {};
        java.awt.Shape shape14 = null;
        java.awt.Shape[] shapeArray15 = new java.awt.Shape[] { shape14 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray10, strokeArray12, strokeArray13, shapeArray15);
        java.awt.Stroke stroke17 = defaultDrawingSupplier16.getNextStroke();
        java.awt.Paint paint18 = defaultDrawingSupplier16.getNextFillPaint();
        java.awt.Paint paint19 = defaultDrawingSupplier16.getNextPaint();
        categoryPlot0.setRangeGridlinePaint(paint19);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset25 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer26 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot27 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset25, waferMapRenderer26);
        org.jfree.data.general.WaferMapDataset waferMapDataset28 = null;
        waferMapPlot27.setDataset(waferMapDataset28);
        float float30 = waferMapPlot27.getBackgroundImageAlpha();
        valueMarker24.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot27);
        java.awt.Font font32 = valueMarker24.getLabelFont();
        dateAxis22.setTickLabelFont(font32);
        org.jfree.data.Range range34 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis22);
        boolean boolean35 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection36 = categoryPlot0.getFixedLegendItems();
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        try {
            categoryPlot0.drawBackground(graphics2D37, rectangle2D38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.5f + "'", float30 == 0.5f);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(legendItemCollection36);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.Object obj1 = ringPlot0.clone();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint5 = ringPlot4.getLabelBackgroundPaint();
        ringPlot4.setShadowXOffset((double) (-1.0f));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.PiePlotState piePlotState10 = ringPlot0.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.PiePlot) ringPlot4, (java.lang.Integer) 200, plotRenderingInfo9);
        double double11 = ringPlot0.getInnerSeparatorExtension();
        ringPlot0.setInnerSeparatorExtension((double) 100.0f);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(piePlotState10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 100.0f, plotRenderingInfo5, point2D6);
        java.util.List list8 = categoryPlot0.getAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomRangeAxes((double) 'a', plotRenderingInfo10, point2D11, true);
        org.jfree.data.general.WaferMapDataset waferMapDataset15 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer16 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot17 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset15, waferMapRenderer16);
        org.jfree.data.general.WaferMapDataset waferMapDataset18 = null;
        waferMapPlot17.setDataset(waferMapDataset18);
        waferMapPlot17.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot17);
        jFreeChart22.setBackgroundImageAlpha(1.0f);
        jFreeChart22.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = jFreeChart22.getPadding();
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = textTitle29.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = textTitle29.getPosition();
        jFreeChart22.setTitle(textTitle29);
        java.awt.Color color33 = java.awt.Color.gray;
        jFreeChart22.setBackgroundPaint((java.awt.Paint) color33);
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart22);
        categoryPlot0.clearDomainMarkers((int) ' ');
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(color33);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        xYPlot0.zoom((double) (short) -1);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = xYPlot0.getDomainMarkers(layer15);
        java.awt.Color color19 = java.awt.Color.ORANGE;
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset23 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer24 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot25 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset23, waferMapRenderer24);
        org.jfree.data.general.WaferMapDataset waferMapDataset26 = null;
        waferMapPlot25.setDataset(waferMapDataset26);
        waferMapPlot25.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot25);
        jFreeChart30.setBackgroundImageAlpha(1.0f);
        jFreeChart30.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = jFreeChart30.getPadding();
        org.jfree.chart.block.LineBorder lineBorder36 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color20, stroke21, rectangleInsets35);
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color19, stroke21);
        try {
            xYPlot0.setQuadrantPaint((int) 'a', (java.awt.Paint) color19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (97) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets35);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0, (double) 100.0f);
        double double3 = size2D2.width;
        size2D2.width = '4';
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint3 = categoryPlot2.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = null;
        categoryPlot2.setFixedLegendItems(legendItemCollection4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot2.getRangeAxisForDataset((-1));
        categoryPlot2.setDomainGridlinesVisible(false);
        categoryAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        categoryPlot2.setRangeAxis(200, (org.jfree.chart.axis.ValueAxis) dateAxis12, true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(valueAxis7);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceText();
        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo0.getLibraries();
        java.util.List list3 = projectInfo0.getContributors();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(libraryArray2);
        org.junit.Assert.assertNull(list3);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection4);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = categoryPlot0.getOrientation();
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        java.lang.Object obj8 = ringPlot7.clone();
        java.awt.Paint paint9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        ringPlot7.setBaseSectionPaint(paint9);
        java.awt.Paint paint11 = ringPlot7.getLabelPaint();
        categoryPlot0.setDomainGridlinePaint(paint11);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.AxisState axisState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint5 = categoryPlot4.getNoDataMessagePaint();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot4.setRangeCrosshairStroke(stroke6);
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot4.getDomainAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation8, plotOrientation9);
        try {
            java.util.List list11 = categoryAxis3D0.refreshTicks(graphics2D1, axisState2, rectangle2D3, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 255, 0.0f, (float) '4');
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        categoryPlot0.setAnchorValue(0.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str6 = textTitle5.getURLText();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle5.setBackgroundPaint(paint7);
        categoryPlot0.setDomainGridlinePaint(paint7);
        categoryPlot0.setWeight((int) (byte) -1);
        categoryPlot0.setAnchorValue(90.0d, false);
        boolean boolean15 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean2 = numberAxis0.isAutoRange();
        numberAxis0.setLabelAngle((double) '4');
        java.awt.Shape shape5 = numberAxis0.getUpArrow();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = null;
        try {
            numberAxis0.setTickUnit(numberTickUnit6, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        waferMapPlot2.setDataset(waferMapDataset3);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        waferMapPlot2.setRenderer(waferMapRenderer5);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        double double2 = ringPlot0.getOuterSeparatorExtension();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = textTitle15.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = textTitle15.getPosition();
        jFreeChart8.setTitle(textTitle15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = null;
        try {
            java.awt.image.BufferedImage bufferedImage23 = jFreeChart8.createBufferedImage(15, 1, (int) 'a', chartRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str2 = categoryAxis3D1.getLabelURL();
        java.awt.Paint paint4 = categoryAxis3D1.getTickLabelPaint((java.lang.Comparable) "ThreadContext");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis3D1.getCategoryLabelPositions();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        org.jfree.data.general.WaferMapDataset waferMapDataset7 = null;
        waferMapPlot6.setDataset(waferMapDataset7);
        float float9 = waferMapPlot6.getBackgroundImageAlpha();
        valueMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot6);
        java.awt.Font font11 = valueMarker3.getLabelFont();
        dateAxis1.setTickLabelFont(font11);
        org.jfree.data.Range range15 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis1.setRangeWithMargins(range15);
        java.lang.String str17 = dateAxis1.getLabelToolTip();
        org.jfree.data.Range range18 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date22 = dateAxis20.calculateHighestVisibleTickValue(dateTickUnit21);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint25 = categoryPlot24.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection26 = null;
        categoryPlot24.setFixedLegendItems(legendItemCollection26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot24.getDomainAxisEdge((int) (byte) 10);
        try {
            double double30 = dateAxis1.dateToJava2D(date22, rectangle2D23, rectangleEdge29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5f + "'", float9 == 0.5f);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(dateTickUnit21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        java.awt.Shape shape7 = dateAxis5.getUpArrow();
        dateAxis5.centerRange((double) (short) 1);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer14 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot15 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset13, waferMapRenderer14);
        org.jfree.data.general.WaferMapDataset waferMapDataset16 = null;
        waferMapPlot15.setDataset(waferMapDataset16);
        waferMapPlot15.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot15);
        jFreeChart20.setBackgroundImageAlpha(1.0f);
        jFreeChart20.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = jFreeChart20.getPadding();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color10, stroke11, rectangleInsets25);
        dateAxis5.setTickMarkStroke(stroke11);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer28);
        xYPlot29.setDomainCrosshairValue((double) (short) 10, false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setRangeCrosshairValue((double) 200, false);
        boolean boolean7 = categoryPlot3.isRangeCrosshairVisible();
        java.awt.Color color9 = java.awt.Color.white;
        java.awt.Color color10 = java.awt.Color.getColor("", color9);
        categoryPlot3.setNoDataMessagePaint((java.awt.Paint) color9);
        valueMarker2.setOutlinePaint((java.awt.Paint) color9);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = valueMarker2.getLabelOffset();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets13);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = piePlot3D0.getLegendItems();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(legendItemCollection15);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getNoDataMessagePaint();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot3.setRangeCrosshairStroke(stroke5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot3.getDomainAxisLocation();
        xYPlot0.setRangeAxisLocation(axisLocation7, false);
        xYPlot0.setOutlineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot0.getDomainAxis((int) (short) -1);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
        org.junit.Assert.assertNull(valueAxis14);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint12 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot11.setRangeZeroBaselinePaint(paint12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray15 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer14 };
        xYPlot11.setRenderers(xYItemRendererArray15);
        xYPlot0.setRenderers(xYItemRendererArray15);
        org.jfree.chart.plot.Plot plot18 = xYPlot0.getParent();
        java.awt.Stroke stroke19 = xYPlot0.getRangeGridlineStroke();
        java.awt.Paint paint20 = xYPlot0.getDomainCrosshairPaint();
        xYPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(xYItemRendererArray15);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.awt.Color color2 = java.awt.Color.getColor("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=90.0]", 200);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer14 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot15 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset13, waferMapRenderer14);
        org.jfree.data.general.WaferMapDataset waferMapDataset16 = null;
        waferMapPlot15.setDataset(waferMapDataset16);
        float float18 = waferMapPlot15.getBackgroundImageAlpha();
        valueMarker12.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot15);
        java.awt.Font font20 = valueMarker12.getLabelFont();
        dateAxis10.setTickLabelFont(font20);
        org.jfree.data.Range range24 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis10.setRangeWithMargins(range24);
        java.util.TimeZone timeZone26 = dateAxis10.getTimeZone();
        dateAxis1.setTimeZone(timeZone26);
        org.jfree.chart.axis.TickUnitSource tickUnitSource28 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone26);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.5f + "'", float18 == 0.5f);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(tickUnitSource28);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = null;
        try {
            categoryPlot0.setRenderer((-16711681), categoryItemRenderer2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer6 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset5, waferMapRenderer6);
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        waferMapPlot7.setDataset(waferMapDataset8);
        float float10 = waferMapPlot7.getBackgroundImageAlpha();
        valueMarker4.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot7);
        java.awt.Font font12 = valueMarker4.getLabelFont();
        dateAxis2.setTickLabelFont(font12);
        org.jfree.data.Range range16 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis2.setRangeWithMargins(range16);
        java.util.TimeZone timeZone18 = dateAxis2.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis20.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer23);
        xYPlot24.setRangeCrosshairVisible(true);
        boolean boolean27 = xYPlot24.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        ringPlot0.setShadowXOffset((double) (-1.0f));
        org.jfree.chart.util.Rotation rotation4 = ringPlot0.getDirection();
        org.jfree.data.general.WaferMapDataset waferMapDataset7 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer8 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset7, waferMapRenderer8);
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        waferMapPlot9.setDataset(waferMapDataset10);
        waferMapPlot9.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot9);
        jFreeChart14.setBackgroundImageAlpha(1.0f);
        jFreeChart14.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = jFreeChart14.getPadding();
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = textTitle21.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = textTitle21.getPosition();
        jFreeChart14.setTitle(textTitle21);
        java.awt.Color color25 = java.awt.Color.gray;
        jFreeChart14.setBackgroundPaint((java.awt.Paint) color25);
        java.awt.Stroke stroke27 = jFreeChart14.getBorderStroke();
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) 0, stroke27);
        double double29 = ringPlot0.getInteriorGap();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.08d + "'", double29 == 0.08d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D2.setTickLabelFont((java.lang.Comparable) (short) 10, font4);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font4, paint6);
        org.jfree.chart.text.TextLine textLine8 = textBlock7.getLastLine();
        org.jfree.chart.text.TextFragment textFragment9 = textLine8.getLastTextFragment();
        java.awt.Font font10 = textFragment9.getFont();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(textLine8);
        org.junit.Assert.assertNotNull(textFragment9);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        java.awt.Paint paint2 = ringPlot0.getSeparatorPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.2d, 0.025d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = piePlotState1.getLinkArea();
        double double3 = piePlotState1.getTotal();
        java.awt.geom.Rectangle2D rectangle2D4 = piePlotState1.getExplodedPieArea();
        piePlotState1.setPieCenterX(0.0d);
        org.junit.Assert.assertNull(rectangle2D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D4);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.lang.String str2 = categoryAxis3D1.getLabelURL();
        double double3 = categoryAxis3D1.getCategoryMargin();
        categoryAxis3D1.setLabelURL("RectangleEdge.TOP");
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis3D1.setTickMarkStroke(stroke6);
        java.awt.Font font9 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) (short) 100);
        java.awt.Paint paint11 = null;
        categoryAxis3D1.setTickLabelPaint((java.lang.Comparable) (-1L), paint11);
        java.awt.Paint paint13 = categoryAxis3D1.getTickMarkPaint();
        categoryAxis3D1.setFixedDimension((double) (-1L));
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio((float) (short) 0);
        categoryAxis3D1.configure();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        dateAxis1.setAutoRange(false);
        dateAxis1.setAxisLineVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        xYPlot13.clearDomainAxes();
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot13);
        try {
            xYPlot13.setBackgroundImageAlpha((float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke1 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer4 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset3, waferMapRenderer4);
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        waferMapPlot5.setDataset(waferMapDataset6);
        waferMapPlot5.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot5);
        jFreeChart10.setBackgroundImageAlpha(1.0f);
        jFreeChart10.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = jFreeChart10.getPadding();
        org.jfree.chart.block.LineBorder lineBorder16 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = lineBorder16.getInsets();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            lineBorder16.draw(graphics2D18, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 100.0f, plotRenderingInfo5, point2D6);
        java.util.List list8 = categoryPlot0.getAnnotations();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        java.awt.Color color10 = java.awt.Color.green;
        boolean boolean12 = color10.equals((java.lang.Object) 100.0d);
        try {
            jFreeChart9.setTextAntiAlias((java.lang.Object) boolean12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: false incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxisForDataset((-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getAxisOffset();
        double double8 = rectangleInsets6.trimHeight((double) (byte) 1);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-7.0d) + "'", double8 == (-7.0d));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getURLText();
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle1.setBackgroundPaint(paint3);
        textTitle1.setHeight((double) ' ');
        textTitle1.setID("UnitType.ABSOLUTE");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D1.setTickLabelFont((java.lang.Comparable) (short) 10, font3);
        int int5 = categoryAxis3D1.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke6 = categoryAxis3D1.getAxisLineStroke();
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        double double8 = piePlot3D7.getMaximumLabelWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean10 = piePlot3D7.equals((java.lang.Object) rectangleAnchor9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        piePlot3D7.setLabelPadding(rectangleInsets11);
        categoryAxis3D1.setLabelInsets(rectangleInsets11);
        java.awt.Paint paint15 = categoryAxis3D1.getTickLabelPaint((java.lang.Comparable) 2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.14d + "'", double8 == 0.14d);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.awt.Color color4 = java.awt.Color.gray;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 0.5f, (double) (byte) -1, 0.0d, (double) (byte) 0, (java.awt.Paint) color4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockBorder5.getInsets();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(8.0d, plotRenderingInfo4, point2D5);
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = null;
        try {
            legendTitle7.setLegendItemGraphicPadding(rectangleInsets8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceText();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape8 = dateAxis7.getDownArrow();
        java.awt.Shape shape9 = dateAxis7.getUpArrow();
        dateAxis7.centerRange((double) (short) 1);
        dateAxis7.setRange(0.0d, (double) '#');
        dateAxis7.setAutoRange(false);
        categoryPlot2.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis7);
        java.util.Date date18 = dateAxis7.getMinimumDate();
        java.awt.Paint paint19 = dateAxis7.getAxisLinePaint();
        boolean boolean20 = projectInfo0.equals((java.lang.Object) dateAxis7);
        projectInfo0.setVersion("{0}");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint2 = textTitle1.getPaint();
        double double3 = textTitle1.getContentYOffset();
        java.awt.Paint paint4 = textTitle1.getBackgroundPaint();
        java.lang.String str5 = textTitle1.getURLText();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean2 = numberAxis0.isAutoRange();
        numberAxis0.setLabelAngle((double) '4');
        java.awt.Shape shape5 = numberAxis0.getUpArrow();
        numberAxis0.setAutoRangeStickyZero(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = null;
        try {
            numberAxis0.setTickUnit(numberTickUnit8, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxis((int) (short) 10);
        java.awt.Color color9 = java.awt.Color.ORANGE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer14 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot15 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset13, waferMapRenderer14);
        org.jfree.data.general.WaferMapDataset waferMapDataset16 = null;
        waferMapPlot15.setDataset(waferMapDataset16);
        waferMapPlot15.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot15);
        jFreeChart20.setBackgroundImageAlpha(1.0f);
        jFreeChart20.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = jFreeChart20.getPadding();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color10, stroke11, rectangleInsets25);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color9, stroke11);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = valueMarker27.getLabelOffset();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint30 = categoryPlot29.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection31 = null;
        categoryPlot29.setFixedLegendItems(legendItemCollection31);
        org.jfree.chart.axis.ValueAxis valueAxis34 = categoryPlot29.getRangeAxisForDataset((-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = categoryPlot29.getAxisOffset();
        java.awt.Color color36 = java.awt.Color.white;
        boolean boolean37 = categoryPlot29.equals((java.lang.Object) color36);
        valueMarker27.setOutlinePaint((java.awt.Paint) color36);
        org.jfree.chart.util.Layer layer39 = null;
        try {
            boolean boolean40 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker27, layer39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(valueAxis34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.Color color5 = java.awt.Color.getColor("", color4);
        int int6 = color4.getRGB();
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        xYPlot0.setRangeCrosshairValue((double) '4', true);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot0.getAxisOffset();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.block.Arrangement arrangement2 = blockContainer1.getArrangement();
        boolean boolean3 = blockContainer1.isEmpty();
        org.junit.Assert.assertNotNull(arrangement2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color2 = java.awt.Color.ORANGE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer7 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6, waferMapRenderer7);
        org.jfree.data.general.WaferMapDataset waferMapDataset9 = null;
        waferMapPlot8.setDataset(waferMapDataset9);
        waferMapPlot8.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot8);
        jFreeChart13.setBackgroundImageAlpha(1.0f);
        jFreeChart13.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = jFreeChart13.getPadding();
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color3, stroke4, rectangleInsets18);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color2, stroke4);
        polarPlot0.setRadiusGridlineStroke(stroke4);
        java.awt.Stroke stroke22 = polarPlot0.getRadiusGridlineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection23 = polarPlot0.getLegendItems();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(legendItemCollection23);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setRangeCrosshairValue((double) 200, false);
        boolean boolean7 = categoryPlot3.isRangeCrosshairVisible();
        java.awt.Color color9 = java.awt.Color.white;
        java.awt.Color color10 = java.awt.Color.getColor("", color9);
        categoryPlot3.setNoDataMessagePaint((java.awt.Paint) color9);
        valueMarker2.setOutlinePaint((java.awt.Paint) color9);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = valueMarker2.getLabelOffset();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets13);
        piePlot3D0.setIgnoreNullValues(false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        waferMapPlot4.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot4);
        jFreeChart9.setBackgroundImageAlpha(1.0f);
        jFreeChart9.setBorderVisible(true);
        boolean boolean14 = objectList0.equals((java.lang.Object) true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.plot.PiePlotState piePlotState17 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo16);
        java.awt.geom.Rectangle2D rectangle2D18 = piePlotState17.getLinkArea();
        double double19 = piePlotState17.getTotal();
        objectList0.set((int) (byte) 10, (java.lang.Object) double19);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getMaximumLabelWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean3 = piePlot3D0.equals((java.lang.Object) rectangleAnchor2);
        double double4 = piePlot3D0.getLabelLinkMargin();
        java.awt.Paint paint5 = piePlot3D0.getLabelShadowPaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.14d + "'", double1 == 0.14d);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        org.jfree.data.Range range11 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis1.setRange(range11, false, false);
        double double15 = range11.getUpperBound();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        org.jfree.data.general.WaferMapDataset waferMapDataset7 = null;
        waferMapPlot6.setDataset(waferMapDataset7);
        float float9 = waferMapPlot6.getBackgroundImageAlpha();
        valueMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot6);
        java.awt.Font font11 = valueMarker3.getLabelFont();
        dateAxis1.setTickLabelFont(font11);
        org.jfree.data.Range range15 = new org.jfree.data.Range(100.0d, (double) (byte) 100);
        dateAxis1.setRangeWithMargins(range15);
        java.lang.String str17 = dateAxis1.getLabelToolTip();
        org.jfree.data.Range range18 = dateAxis1.getRange();
        double double19 = range18.getUpperBound();
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5f + "'", float9 == 0.5f);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 100.0d + "'", double19 == 100.0d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("RectangleEdge.TOP");
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        waferMapPlot4.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot4);
        jFreeChart9.setBackgroundImageAlpha(1.0f);
        jFreeChart9.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = jFreeChart9.getPadding();
        boolean boolean15 = jFreeChart9.isNotify();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart9, chartChangeEventType16);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str20 = textTitle19.getURLText();
        jFreeChart9.removeSubtitle((org.jfree.chart.title.Title) textTitle19);
        double double22 = textTitle19.getWidth();
        org.jfree.chart.StrokeMap strokeMap23 = new org.jfree.chart.StrokeMap();
        strokeMap23.clear();
        boolean boolean25 = textTitle19.equals((java.lang.Object) strokeMap23);
        java.lang.Comparable comparable26 = null;
        try {
            boolean boolean27 = strokeMap23.containsKey(comparable26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.text.NumberFormat numberFormat1 = null;
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ThreadContext");
        java.text.AttributedString attributedString5 = standardPieSectionLabelGenerator3.getAttributedLabel((int) (byte) -1);
        java.text.NumberFormat numberFormat6 = standardPieSectionLabelGenerator3.getPercentFormat();
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Pie Plot", numberFormat1, numberFormat6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(attributedString5);
        org.junit.Assert.assertNotNull(numberFormat6);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setRangeCrosshairValue((double) 200, false);
        boolean boolean7 = categoryPlot3.isRangeCrosshairVisible();
        java.awt.Color color9 = java.awt.Color.white;
        java.awt.Color color10 = java.awt.Color.getColor("", color9);
        categoryPlot3.setNoDataMessagePaint((java.awt.Paint) color9);
        valueMarker2.setOutlinePaint((java.awt.Paint) color9);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = valueMarker2.getLabelOffset();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets13);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D16 = rectangleInsets13.createOutsetRectangle(rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        java.awt.Stroke stroke13 = xYPlot0.getDomainCrosshairStroke();
        java.awt.Stroke stroke14 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation16 = null;
        try {
            boolean boolean17 = xYPlot0.removeAnnotation(xYAnnotation16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        boolean boolean14 = jFreeChart8.isNotify();
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart8.getLegend(200);
        jFreeChart8.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.data.general.WaferMapDataset waferMapDataset19 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer20 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot21 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset19, waferMapRenderer20);
        org.jfree.data.general.WaferMapDataset waferMapDataset22 = null;
        waferMapPlot21.setDataset(waferMapDataset22);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent24 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) waferMapPlot21);
        org.jfree.chart.JFreeChart jFreeChart25 = plotChangeEvent24.getChart();
        jFreeChart8.plotChanged(plotChangeEvent24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = null;
        java.awt.image.BufferedImage bufferedImage32 = jFreeChart8.createBufferedImage((int) (byte) 1, (int) (short) 100, (double) (short) 0, (double) (byte) 10, chartRenderingInfo31);
        boolean boolean33 = jFreeChart8.isBorderVisible();
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(legendTitle16);
        org.junit.Assert.assertNull(jFreeChart25);
        org.junit.Assert.assertNotNull(bufferedImage32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getInteriorGap();
        boolean boolean2 = piePlot3D0.getDarkerSides();
        java.awt.Color color3 = java.awt.Color.ORANGE;
        int int4 = color3.getGreen();
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color3.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        boolean boolean11 = piePlot3D0.equals((java.lang.Object) colorModel5);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        java.lang.Object obj14 = dateAxis13.clone();
        java.awt.Shape shape15 = dateAxis13.getUpArrow();
        piePlot3D0.setLegendItemShape(shape15);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08d + "'", double1 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 200 + "'", int4 == 200);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateLeftInset((double) 10);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot4.setDataset(waferMapDataset5);
        float float7 = waferMapPlot4.getBackgroundImageAlpha();
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker1.setLabelAnchor(rectangleAnchor9);
        java.awt.Paint paint11 = valueMarker1.getOutlinePaint();
        float float12 = valueMarker1.getAlpha();
        java.awt.Paint paint13 = valueMarker1.getPaint();
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.8f + "'", float12 == 0.8f);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.Color color3 = java.awt.Color.getColor("", color2);
        ringPlot0.setLabelPaint((java.awt.Paint) color3);
        org.jfree.data.general.PieDataset pieDataset5 = ringPlot0.getDataset();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D8.setTickLabelFont((java.lang.Comparable) (short) 10, font10);
        java.awt.Paint paint12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font10, paint12);
        boolean boolean14 = ringPlot0.equals((java.lang.Object) font10);
        double double15 = ringPlot0.getInteriorGap();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator16 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator16);
        ringPlot0.setPieIndex(500);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(pieDataset5);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08d + "'", double15 == 0.08d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        boolean boolean3 = textTitle1.equals((java.lang.Object) (short) 0);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) (short) 0, (double) 100.0f);
        org.jfree.data.Range range8 = rectangleConstraint7.getWidthRange();
        try {
            org.jfree.chart.util.Size2D size2D9 = textTitle1.arrange(graphics2D4, rectangleConstraint7);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = textTitle1.getPosition();
        java.lang.String str4 = rectangleEdge3.toString();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot5.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomDomainAxes(8.0d, plotRenderingInfo9, point2D10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot5);
        boolean boolean13 = rectangleEdge3.equals((java.lang.Object) categoryPlot5);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleEdge.TOP" + "'", str4.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        java.lang.String str2 = standardPieSectionLabelGenerator1.getLabelFormat();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        boolean boolean14 = jFreeChart8.isNotify();
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart8.getLegend(200);
        jFreeChart8.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint20 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot19.setRangeZeroBaselinePaint(paint20);
        jFreeChart8.setBorderPaint(paint20);
        org.jfree.chart.plot.Plot plot23 = jFreeChart8.getPlot();
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(legendTitle16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(plot23);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.awt.Color color0 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint3 = textTitle2.getPaint();
        java.awt.Color color4 = java.awt.Color.red;
        java.awt.Color color5 = java.awt.Color.red;
        java.awt.Color color6 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color0, paint3, color4, color5, color6 };
        java.awt.Paint[] paintArray8 = null;
        java.awt.Stroke stroke9 = null;
        java.awt.Stroke[] strokeArray10 = new java.awt.Stroke[] { stroke9 };
        java.awt.Stroke[] strokeArray11 = new java.awt.Stroke[] {};
        java.awt.Shape shape12 = null;
        java.awt.Shape[] shapeArray13 = new java.awt.Shape[] { shape12 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray8, strokeArray10, strokeArray11, shapeArray13);
        java.awt.Stroke stroke15 = defaultDrawingSupplier14.getNextStroke();
        try {
            java.awt.Paint paint16 = defaultDrawingSupplier14.getNextOutlinePaint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(strokeArray11);
        org.junit.Assert.assertNotNull(shapeArray13);
        org.junit.Assert.assertNull(stroke15);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        double[] doubleArray4 = new double[] { 0.4d, (-1) };
        double[] doubleArray7 = new double[] { 0.4d, (-1) };
        double[] doubleArray10 = new double[] { 0.4d, (-1) };
        double[] doubleArray13 = new double[] { 0.4d, (-1) };
        double[] doubleArray16 = new double[] { 0.4d, (-1) };
        double[] doubleArray19 = new double[] { 0.4d, (-1) };
        double[][] doubleArray20 = new double[][] { doubleArray4, doubleArray7, doubleArray10, doubleArray13, doubleArray16, doubleArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "{0}", doubleArray20);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset21);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset21, true);
        try {
            org.jfree.data.general.PieDataset pieDataset26 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset21, (java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range24);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getURLText();
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle1.setBackgroundPaint(paint3);
        textTitle1.setHeight((double) ' ');
        org.jfree.chart.util.Size2D size2D7 = new org.jfree.chart.util.Size2D();
        boolean boolean8 = textTitle1.equals((java.lang.Object) size2D7);
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer11 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset10, waferMapRenderer11);
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        waferMapPlot12.setDataset(waferMapDataset13);
        waferMapPlot12.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot12);
        java.awt.Stroke stroke18 = jFreeChart17.getBorderStroke();
        boolean boolean19 = jFreeChart17.isBorderVisible();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.data.general.WaferMapDataset waferMapDataset21 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer22 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot23 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset21, waferMapRenderer22);
        org.jfree.data.general.WaferMapDataset waferMapDataset24 = null;
        waferMapPlot23.setDataset(waferMapDataset24);
        boolean boolean26 = chartChangeEventType20.equals((java.lang.Object) waferMapPlot23);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textTitle1, jFreeChart17, chartChangeEventType20);
        org.jfree.chart.plot.Plot plot28 = jFreeChart17.getPlot();
        boolean boolean29 = jFreeChart17.isNotify();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(plot28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        boolean boolean2 = ringPlot0.isCircular();
        java.awt.Stroke stroke3 = ringPlot0.getLabelLinkStroke();
        java.awt.Paint paint4 = ringPlot0.getShadowPaint();
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean6 = polarPlot5.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint10 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot9.setRangeZeroBaselinePaint(paint10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray13 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer12 };
        xYPlot9.setRenderers(xYItemRendererArray13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        xYPlot9.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo17, point2D18);
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        xYPlot9.setFixedRangeAxisSpace(axisSpace20);
        java.awt.Stroke stroke22 = xYPlot9.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D23 = xYPlot9.getQuadrantOrigin();
        polarPlot5.zoomDomainAxes(1.0E-8d, plotRenderingInfo8, point2D23);
        ringPlot0.setParent((org.jfree.chart.plot.Plot) polarPlot5);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = polarPlot5.getRenderer();
        int int27 = polarPlot5.getSeriesCount();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(xYItemRendererArray13);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(point2D23);
        org.junit.Assert.assertNull(polarItemRenderer26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("RectangleAnchor.BOTTOM_LEFT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name RectangleAnchor.BOTTOM_LEFT, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ThreadContext");
        java.text.AttributedString attributedString3 = standardPieSectionLabelGenerator1.getAttributedLabel((int) (byte) -1);
        java.text.NumberFormat numberFormat4 = standardPieSectionLabelGenerator1.getPercentFormat();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setRangeCrosshairValue((double) 200, false);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        java.awt.Shape shape12 = dateAxis10.getUpArrow();
        dateAxis10.centerRange((double) (short) 1);
        dateAxis10.setRange(0.0d, (double) '#');
        dateAxis10.setAutoRange(false);
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        java.util.Date date21 = dateAxis10.getMinimumDate();
        java.awt.Paint paint22 = dateAxis10.getAxisLinePaint();
        boolean boolean23 = standardPieSectionLabelGenerator1.equals((java.lang.Object) paint22);
        org.junit.Assert.assertNull(attributedString3);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        categoryPlot0.setAnchorValue(0.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str6 = textTitle5.getURLText();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle5.setBackgroundPaint(paint7);
        categoryPlot0.setDomainGridlinePaint(paint7);
        categoryPlot0.setWeight((int) (byte) -1);
        categoryPlot0.setAnchorValue(90.0d, false);
        boolean boolean15 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        try {
            categoryPlot0.handleClick((int) (short) 1, 2, plotRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        boolean boolean14 = jFreeChart8.isNotify();
        boolean boolean15 = jFreeChart8.isNotify();
        jFreeChart8.setTitle("RectangleEdge.TOP");
        org.jfree.chart.plot.PiePlot3D piePlot3D18 = new org.jfree.chart.plot.PiePlot3D();
        double double19 = piePlot3D18.getMaximumLabelWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean21 = piePlot3D18.equals((java.lang.Object) rectangleAnchor20);
        double double22 = piePlot3D18.getLabelLinkMargin();
        try {
            jFreeChart8.setTextAntiAlias((java.lang.Object) double22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 0.025 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.14d + "'", double19 == 0.14d);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.025d + "'", double22 == 0.025d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.lang.Comparable[] comparableArray2 = new java.lang.Comparable[] { 1.0f, 15 };
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date9 = dateAxis7.calculateHighestVisibleTickValue(dateTickUnit8);
        java.lang.Comparable[] comparableArray11 = new java.lang.Comparable[] { true, 2, "UnitType.ABSOLUTE", date9, "{0}" };
        double[] doubleArray16 = new double[] { 0.4d, (-1) };
        double[] doubleArray19 = new double[] { 0.4d, (-1) };
        double[] doubleArray22 = new double[] { 0.4d, (-1) };
        double[] doubleArray25 = new double[] { 0.4d, (-1) };
        double[] doubleArray28 = new double[] { 0.4d, (-1) };
        double[] doubleArray31 = new double[] { 0.4d, (-1) };
        double[][] doubleArray32 = new double[][] { doubleArray16, doubleArray19, doubleArray22, doubleArray25, doubleArray28, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "{0}", doubleArray32);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray2, comparableArray11, doubleArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray2);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(comparableArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        boolean boolean14 = jFreeChart8.isNotify();
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart8.getLegend(200);
        jFreeChart8.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.data.general.WaferMapDataset waferMapDataset19 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer20 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot21 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset19, waferMapRenderer20);
        org.jfree.data.general.WaferMapDataset waferMapDataset22 = null;
        waferMapPlot21.setDataset(waferMapDataset22);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent24 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) waferMapPlot21);
        org.jfree.chart.JFreeChart jFreeChart25 = plotChangeEvent24.getChart();
        jFreeChart8.plotChanged(plotChangeEvent24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = null;
        java.awt.image.BufferedImage bufferedImage32 = jFreeChart8.createBufferedImage((int) (byte) 1, (int) (short) 100, (double) (short) 0, (double) (byte) 10, chartRenderingInfo31);
        try {
            java.awt.image.BufferedImage bufferedImage35 = jFreeChart8.createBufferedImage(0, 200);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (200) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(legendTitle16);
        org.junit.Assert.assertNull(jFreeChart25);
        org.junit.Assert.assertNotNull(bufferedImage32);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.Object obj1 = ringPlot0.clone();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint5 = ringPlot4.getLabelBackgroundPaint();
        ringPlot4.setShadowXOffset((double) (-1.0f));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.PiePlotState piePlotState10 = ringPlot0.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.PiePlot) ringPlot4, (java.lang.Integer) 200, plotRenderingInfo9);
        double double11 = ringPlot0.getInnerSeparatorExtension();
        double double12 = ringPlot0.getOuterSeparatorExtension();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(piePlotState10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getNoDataMessagePaint();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot3.setRangeCrosshairStroke(stroke5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot3.getDomainAxisLocation();
        xYPlot0.setRangeAxisLocation(axisLocation7, false);
        xYPlot0.setOutlineVisible(false);
        boolean boolean12 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation13 = null;
        try {
            xYPlot0.setRangeAxisLocation(axisLocation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("Category Plot");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name Category Plot, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        boolean boolean2 = ringPlot0.isCircular();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setRangeCrosshairValue((double) 200, false);
        boolean boolean9 = categoryPlot5.isRangeCrosshairVisible();
        java.awt.Color color11 = java.awt.Color.white;
        java.awt.Color color12 = java.awt.Color.getColor("", color11);
        categoryPlot5.setNoDataMessagePaint((java.awt.Paint) color11);
        valueMarker4.setOutlinePaint((java.awt.Paint) color11);
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color11);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) '#', stroke17);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator19 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator19);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot0.getRenderer(0);
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot0.getDomainAxisForDataset((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot0.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.LEFT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        jFreeChart8.removeLegend();
        org.jfree.chart.event.ChartProgressListener chartProgressListener15 = null;
        jFreeChart8.removeProgressListener(chartProgressListener15);
        java.awt.RenderingHints renderingHints17 = null;
        try {
            jFreeChart8.setRenderingHints(renderingHints17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getURLText();
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle1.setBackgroundPaint(paint3);
        textTitle1.setExpandToFitSpace(false);
        java.awt.Color color7 = java.awt.Color.lightGray;
        textTitle1.setBackgroundPaint((java.awt.Paint) color7);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        categoryPlot0.setAnchorValue(0.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str6 = textTitle5.getURLText();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle5.setBackgroundPaint(paint7);
        categoryPlot0.setDomainGridlinePaint(paint7);
        categoryPlot0.setWeight((int) (byte) -1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot0.setRenderer(categoryItemRenderer12, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        dateAxis1.setAutoRange(false);
        dateAxis1.setAxisLineVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        xYPlot13.clearDomainAxes();
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot13);
        org.jfree.chart.LegendItemCollection legendItemCollection16 = xYPlot13.getFixedLegendItems();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendItemCollection16);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        java.lang.Object obj3 = null;
        boolean boolean4 = categoryPlot0.equals(obj3);
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getUpperMargin();
        double[] doubleArray10 = new double[] { 0.4d, (-1) };
        double[] doubleArray13 = new double[] { 0.4d, (-1) };
        double[] doubleArray16 = new double[] { 0.4d, (-1) };
        double[] doubleArray19 = new double[] { 0.4d, (-1) };
        double[] doubleArray22 = new double[] { 0.4d, (-1) };
        double[] doubleArray25 = new double[] { 0.4d, (-1) };
        double[][] doubleArray26 = new double[][] { doubleArray10, doubleArray13, doubleArray16, doubleArray19, doubleArray22, doubleArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "{0}", doubleArray26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.HALF_ASCENT_CENTER", "ClassContext", doubleArray26);
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint33 = categoryPlot32.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection34 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection34);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot32.getDomainAxisEdge((int) (byte) 10);
        boolean boolean38 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge37);
        boolean boolean39 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge37);
        try {
            double double40 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) 0.0f, (java.lang.Comparable) 3.0d, categoryDataset28, (double) '4', rectangle2D31, rectangleEdge37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource9);
        boolean boolean12 = dateAxis1.isHiddenValue((long) ' ');
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint17 = categoryPlot16.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection18 = null;
        categoryPlot16.setFixedLegendItems(legendItemCollection18);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot16.getRangeAxisForDataset((-1));
        categoryPlot16.setDomainGridlinesVisible(false);
        org.jfree.chart.ui.ProjectInfo projectInfo24 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str25 = projectInfo24.getLicenceText();
        org.jfree.chart.ui.Library[] libraryArray26 = projectInfo24.getLibraries();
        boolean boolean27 = categoryPlot16.equals((java.lang.Object) projectInfo24);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot16.getDomainAxisEdge(0);
        try {
            java.util.List list30 = dateAxis1.refreshTicks(graphics2D13, axisState14, rectangle2D15, rectangleEdge29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(libraryArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint2 = categoryPlot1.getNoDataMessagePaint();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot1.setRangeCrosshairStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot1.getDomainAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6, true);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace9);
        boolean boolean11 = rectangleAnchor0.equals((java.lang.Object) categoryPlot1);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot3.setDataset(waferMapDataset4);
        waferMapPlot3.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart8.setBackgroundImageAlpha(1.0f);
        jFreeChart8.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart8.getPadding();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = textTitle15.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = textTitle15.getPosition();
        jFreeChart8.setTitle(textTitle15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D21 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font23 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D21.setTickLabelFont((java.lang.Comparable) (short) 10, font23);
        java.awt.Paint paint25 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font23, paint25);
        textTitle15.setBackgroundPaint(paint25);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint(1.0d, 90.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType32 = rectangleConstraint31.getWidthConstraintType();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType33 = rectangleConstraint31.getWidthConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D34 = textTitle15.arrange(graphics2D28, rectangleConstraint31);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(textBlock26);
        org.junit.Assert.assertNotNull(lengthConstraintType32);
        org.junit.Assert.assertNotNull(lengthConstraintType33);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        xYPlot0.clearDomainMarkers(1);
        org.jfree.chart.axis.AxisSpace axisSpace15 = xYPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(axisSpace15);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Shape shape3 = dateAxis1.getUpArrow();
        dateAxis1.centerRange((double) (short) 1);
        dateAxis1.setRange(0.0d, (double) '#');
        dateAxis1.setAutoRange(false);
        dateAxis1.setAxisLineVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        xYPlot13.clearDomainAxes();
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot13);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean19 = polarPlot18.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint23 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot22.setRangeZeroBaselinePaint(paint23);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray26 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer25 };
        xYPlot22.setRenderers(xYItemRendererArray26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        xYPlot22.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo30, point2D31);
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        xYPlot22.setFixedRangeAxisSpace(axisSpace33);
        java.awt.Stroke stroke35 = xYPlot22.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D36 = xYPlot22.getQuadrantOrigin();
        polarPlot18.zoomDomainAxes(1.0E-8d, plotRenderingInfo21, point2D36);
        org.jfree.chart.plot.PlotState plotState38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        try {
            xYPlot13.draw(graphics2D16, rectangle2D17, point2D36, plotState38, plotRenderingInfo39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(xYItemRendererArray26);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(point2D36);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeZeroBaselinePaint(paint1);
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.Color color5 = java.awt.Color.getColor("", color4);
        int int6 = color4.getRGB();
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        java.awt.Stroke stroke8 = xYPlot0.getDomainCrosshairStroke();
        boolean boolean9 = xYPlot0.isDomainGridlinesVisible();
        boolean boolean10 = xYPlot0.isRangeZoomable();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isAngleGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        polarPlot0.setDataset(xYDataset2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean7 = polarPlot6.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot10.setRangeZeroBaselinePaint(paint11);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray14 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer13 };
        xYPlot10.setRenderers(xYItemRendererArray14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        xYPlot10.zoomRangeAxes(0.0d, 1.0E-8d, plotRenderingInfo18, point2D19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace21);
        java.awt.Stroke stroke23 = xYPlot10.getDomainCrosshairStroke();
        java.awt.geom.Point2D point2D24 = xYPlot10.getQuadrantOrigin();
        polarPlot6.zoomDomainAxes(1.0E-8d, plotRenderingInfo9, point2D24);
        polarPlot0.zoomDomainAxes(0.0d, plotRenderingInfo5, point2D24, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(xYItemRendererArray14);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(point2D24);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis3D2.setTickLabelFont((java.lang.Comparable) (short) 10, font4);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font4, paint6);
        org.jfree.chart.text.TextLine textLine8 = textBlock7.getLastLine();
        org.jfree.chart.text.TextFragment textFragment9 = textLine8.getLastTextFragment();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer14 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot15 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset13, waferMapRenderer14);
        org.jfree.data.general.WaferMapDataset waferMapDataset16 = null;
        waferMapPlot15.setDataset(waferMapDataset16);
        boolean boolean18 = chartChangeEventType12.equals((java.lang.Object) waferMapPlot15);
        java.awt.Font font19 = waferMapPlot15.getNoDataMessageFont();
        dateAxis11.setTickLabelFont(font19);
        boolean boolean21 = textLine8.equals((java.lang.Object) font19);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(textLine8);
        org.junit.Assert.assertNotNull(textFragment9);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.awt.Color color0 = java.awt.Color.red;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint3 = textTitle2.getPaint();
        java.awt.Color color4 = java.awt.Color.red;
        java.awt.Color color5 = java.awt.Color.red;
        java.awt.Color color6 = java.awt.Color.ORANGE;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color0, paint3, color4, color5, color6 };
        java.awt.Paint[] paintArray8 = null;
        java.awt.Stroke stroke9 = null;
        java.awt.Stroke[] strokeArray10 = new java.awt.Stroke[] { stroke9 };
        java.awt.Stroke[] strokeArray11 = new java.awt.Stroke[] {};
        java.awt.Shape shape12 = null;
        java.awt.Shape[] shapeArray13 = new java.awt.Shape[] { shape12 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray8, strokeArray10, strokeArray11, shapeArray13);
        try {
            java.awt.Stroke stroke15 = defaultDrawingSupplier14.getNextOutlineStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(strokeArray11);
        org.junit.Assert.assertNotNull(shapeArray13);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxisForDataset((-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getAxisOffset();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets6.createOutsetRectangle(rectangle2D7, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelBackgroundPaint();
        boolean boolean2 = ringPlot0.isCircular();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setRangeCrosshairValue((double) 200, false);
        boolean boolean9 = categoryPlot5.isRangeCrosshairVisible();
        java.awt.Color color11 = java.awt.Color.white;
        java.awt.Color color12 = java.awt.Color.getColor("", color11);
        categoryPlot5.setNoDataMessagePaint((java.awt.Paint) color11);
        valueMarker4.setOutlinePaint((java.awt.Paint) color11);
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color11);
        try {
            ringPlot0.setInteriorGap((double) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (255.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
    }
}

