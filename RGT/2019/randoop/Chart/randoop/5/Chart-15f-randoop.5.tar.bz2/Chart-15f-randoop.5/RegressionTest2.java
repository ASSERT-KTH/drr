import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        java.lang.Object obj3 = ringPlot0.clone();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D2.getCategoryStart((-1), (int) ' ', rectangle2D5, rectangleEdge6);
        java.util.List list8 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        categoryPlot0.drawBackgroundImage(graphics2D9, rectangle2D10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot0.getRangeAxis((int) (short) 100);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(valueAxis14);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D1 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder2 = xYPlot0.getSeriesRenderingOrder();
        org.junit.Assert.assertNotNull(point2D1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder2);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.mapDatasetToRangeAxis((int) (byte) 1, (int) '4');
        boolean boolean12 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        categoryPlot0.removeChangeListener(plotChangeListener13);
        categoryPlot0.mapDatasetToRangeAxis((int) '4', (int) (short) 10);
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot0.getDomainAxisLocation(8);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Image image1 = polarPlot0.getBackgroundImage();
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = polarPlot0.getOrientation();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        piePlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.plot.Plot plot8 = piePlot4.getRootPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D11.setMaximumCategoryLabelWidthRatio(10.0f);
        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color15 = java.awt.Color.BLACK;
        categoryAxis3D11.setTickLabelPaint((java.lang.Comparable) date14, (java.awt.Paint) color15);
        piePlot4.setSectionPaint((java.lang.Comparable) "ThreadContext", (java.awt.Paint) color15);
        polarPlot0.setRadiusGridlinePaint((java.awt.Paint) color15);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNotNull(plotOrientation2);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getSeparatorStroke();
        java.awt.Paint paint2 = ringPlot0.getShadowPaint();
        org.jfree.chart.util.Rotation rotation3 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        ringPlot0.setDirection(rotation3);
        ringPlot0.setSectionOutlinesVisible(true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rotation3);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.mapDatasetToRangeAxis((int) (byte) 1, (int) '4');
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = xYPlot0.getDataRange(valueAxis2);
        java.awt.Stroke stroke4 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getDomainAxis(192);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("org.jfree.chart.event.ChartChangeEvent[source=hi!]", "Polar Plot", numberArray8);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset9);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset9);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Paint paint5 = piePlot3.getSectionPaint((java.lang.Comparable) 8);
        boolean boolean6 = piePlot3D1.equals((java.lang.Object) 8);
        java.lang.Object obj7 = piePlot3D1.clone();
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font3 = categoryAxis3D2.getLabelFont();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) color4, (float) (byte) 100);
        java.awt.Paint paint7 = textFragment6.getPaint();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        double double10 = textTitle9.getContentYOffset();
        java.lang.String str11 = textTitle9.getURLText();
        boolean boolean12 = textFragment6.equals((java.lang.Object) textTitle9);
        textTitle9.setURLText("Range[97.0,97.0]");
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainZeroBaselineStroke();
        double double2 = xYPlot0.getDomainCrosshairValue();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers((int) (byte) 10, layer4);
        boolean boolean6 = xYPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        xYPlot5.setRenderer(8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot5.setFixedDomainAxisSpace(axisSpace11);
        xYPlot5.setWeight((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, (double) (-1.0f));
        org.jfree.data.Range range3 = rectangleConstraint2.getWidthRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint2.getWidthConstraintType();
        java.lang.String str5 = rectangleConstraint2.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint2.toFixedHeight((double) 'a');
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=-1.0]" + "'", str5.equals("RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=-1.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint7);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat1 = standardPieSectionLabelGenerator0.getPercentFormat();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double8 = numberAxis3D7.getFixedAutoRange();
        double double9 = numberAxis3D7.getUpperBound();
        java.awt.Shape shape10 = numberAxis3D7.getUpArrow();
        numberAxis3D4.setUpArrow(shape10);
        int int12 = xYPlot2.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D4);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        int int14 = xYPlot2.indexOf(xYDataset13);
        java.awt.Paint paint15 = xYPlot2.getDomainTickBandPaint();
        boolean boolean16 = standardPieSectionLabelGenerator0.equals((java.lang.Object) xYPlot2);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double6 = numberAxis3D5.getFixedAutoRange();
        double double7 = numberAxis3D5.getUpperBound();
        java.awt.Shape shape8 = numberAxis3D5.getUpArrow();
        numberAxis3D2.setUpArrow(shape8);
        int int10 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D2);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        int int12 = xYPlot0.indexOf(xYDataset11);
        java.awt.Paint paint13 = xYPlot0.getDomainTickBandPaint();
        xYPlot0.clearRangeMarkers();
        java.awt.Stroke stroke15 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        xYPlot0.zoomDomainAxes((double) 10.0f, (-1.95d), plotRenderingInfo18, point2D19);
        java.awt.Color color25 = java.awt.Color.getHSBColor((float) (short) -1, (float) 1L, (float) (short) -1);
        try {
            xYPlot0.setQuadrantPaint((-1), (java.awt.Paint) color25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (-1) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextPaint();
        java.lang.Object obj3 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Paint paint2 = textTitle1.getBackgroundPaint();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot3);
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = legendTitle4.getVerticalAlignment();
        textTitle1.setVerticalAlignment(verticalAlignment5);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = textTitle1.getVerticalAlignment();
        double double8 = textTitle1.getContentXOffset();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        categoryAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot2);
        boolean boolean4 = polarPlot2.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        polarPlot2.zoomDomainAxes(98.0d, plotRenderingInfo6, point2D7);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomRangeAxes(10.0d, plotRenderingInfo2, point2D3, false);
        java.lang.Object obj6 = xYPlot0.clone();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        int int8 = xYPlot0.indexOf(xYDataset7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot0.getRangeAxisEdge((-1));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("org.jfree.chart.event.ChartChangeEvent[source=hi!]", "Polar Plot", numberArray8);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset9);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset9);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getInfo();
        java.lang.String str2 = basicProjectInfo0.getName();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        float float4 = ringPlot3.getForegroundAlpha();
        ringPlot3.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke9 = xYPlot8.getDomainGridlineStroke();
        boolean boolean10 = ringPlot3.equals((java.lang.Object) xYPlot8);
        org.jfree.chart.axis.AxisLocation axisLocation12 = xYPlot8.getDomainAxisLocation(255);
        xYPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation12, true);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke16 = xYPlot15.getDomainGridlineStroke();
        java.awt.Paint paint17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot15.setRangeCrosshairPaint(paint17);
        xYPlot0.setRangeZeroBaselinePaint(paint17);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "");
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "hi!", jFreeChart6, chartChangeEventType7);
        java.lang.Object obj9 = chartChangeEvent8.getSource();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo15 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "");
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "hi!", jFreeChart16, chartChangeEventType17);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = chartChangeEvent18.getType();
        java.awt.Font font21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace23 = categoryPlot22.getFixedDomainAxisSpace();
        categoryPlot22.clearRangeAxes();
        categoryPlot22.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray27 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer26 };
        categoryPlot22.setRenderers(categoryItemRendererArray27);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("Pie Plot", font21, (org.jfree.chart.plot.Plot) categoryPlot22, true);
        java.awt.RenderingHints renderingHints31 = jFreeChart30.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle32 = jFreeChart30.getLegend();
        jFreeChart30.setTextAntiAlias(true);
        chartChangeEvent18.setChart(jFreeChart30);
        chartChangeEvent8.setChart(jFreeChart30);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = null;
        try {
            java.awt.image.BufferedImage bufferedImage41 = jFreeChart30.createBufferedImage(0, (int) (short) 1, 0, chartRenderingInfo40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + obj9 + "' != '" + "hi!" + "'", obj9.equals("hi!"));
        org.junit.Assert.assertNull(chartChangeEventType19);
        org.junit.Assert.assertNull(axisSpace23);
        org.junit.Assert.assertNotNull(categoryItemRendererArray27);
        org.junit.Assert.assertNotNull(renderingHints31);
        org.junit.Assert.assertNotNull(legendTitle32);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.configureDomainAxes();
        java.awt.Font font4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        categoryPlot0.setNoDataMessageFont(font4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getRangeAxisLocation();
        double double7 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent8);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairValue((double) (short) 1, true);
        boolean boolean4 = xYPlot0.isRangeZoomable();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("Pie 3D Plot");
        int int7 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D6);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis3D6.setMarkerBand(markerAxisBand8);
        java.awt.Shape shape10 = numberAxis3D6.getLeftArrow();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getLegendItems();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double5 = numberAxis3D4.getFixedAutoRange();
        numberAxis3D4.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean9 = numberAxis3D4.isPositiveArrowVisible();
        java.lang.Object obj10 = numberAxis3D4.clone();
        java.text.NumberFormat numberFormat11 = null;
        numberAxis3D4.setNumberFormatOverride(numberFormat11);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double15 = numberAxis3D14.getFixedAutoRange();
        double double16 = numberAxis3D14.getUpperBound();
        java.awt.Shape shape17 = numberAxis3D14.getUpArrow();
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis3D14.setAxisLineStroke(stroke18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range22 = numberAxis3D21.getRange();
        org.jfree.data.Range range24 = org.jfree.data.Range.shift(range22, (double) (-1.0f));
        numberAxis3D14.setDefaultAutoRange(range22);
        numberAxis3D4.setRangeWithMargins(range22);
        numberAxis3D4.setLowerMargin((double) (short) 1);
        int int29 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D4);
        java.awt.Paint paint30 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D2.getCategoryStart((-1), (int) ' ', rectangle2D5, rectangleEdge6);
        java.util.List list8 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.awt.Paint paint9 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot0.getIndexOf(categoryItemRenderer10);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj13 = defaultDrawingSupplier12.clone();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        try {
            int int16 = categoryPlot0.getRangeAxisIndex(valueAxis15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("org.jfree.chart.event.ChartChangeEvent[source=hi!]", "Polar Plot", numberArray8);
        java.lang.Number number10 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset9);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset9);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.0d + "'", number10.equals(0.0d));
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font3 = categoryAxis3D2.getLabelFont();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) color4, (float) (byte) 100);
        java.awt.Paint paint7 = textFragment6.getPaint();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        double double10 = textTitle9.getContentYOffset();
        java.lang.String str11 = textTitle9.getURLText();
        boolean boolean12 = textFragment6.equals((java.lang.Object) textTitle9);
        org.jfree.chart.text.TextBlock textBlock13 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = textBlock13.getLineAlignment();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        textBlock13.draw(graphics2D15, (float) ' ', (float) 10L, textBlockAnchor18, (float) (short) 1, 0.0f, (double) (byte) 1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = textBlock13.getLineAlignment();
        textTitle9.setTextAlignment(horizontalAlignment23);
        textTitle9.setURLText("XY Plot");
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D2.getCategoryStart((-1), (int) ' ', rectangle2D5, rectangleEdge6);
        java.util.List list8 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        categoryPlot0.drawBackgroundImage(graphics2D9, rectangle2D10);
        int int12 = categoryPlot0.getDatasetCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke17 = xYPlot16.getDomainGridlineStroke();
        java.awt.Paint paint18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot16.setRangeCrosshairPaint(paint18);
        xYPlot16.clearRangeMarkers(8);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double25 = numberAxis3D24.getFixedAutoRange();
        numberAxis3D24.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean29 = numberAxis3D24.isPositiveArrowVisible();
        java.lang.Object obj30 = numberAxis3D24.clone();
        java.text.NumberFormat numberFormat31 = null;
        numberAxis3D24.setNumberFormatOverride(numberFormat31);
        numberAxis3D24.setTickLabelsVisible(false);
        java.lang.String str35 = numberAxis3D24.getLabel();
        xYPlot16.setDomainAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis3D24, false);
        float float38 = xYPlot16.getForegroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D43 = xYPlot42.getQuadrantOrigin();
        xYPlot16.zoomRangeAxes((double) (short) 0, (double) 3, plotRenderingInfo41, point2D43);
        categoryPlot0.zoomDomainAxes(Double.NaN, 10.0d, plotRenderingInfo15, point2D43);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 1.0f + "'", float38 == 1.0f);
        org.junit.Assert.assertNotNull(point2D43);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=-1.0]", graphics2D1, 0.0f, (float) 100L, textAnchor4, 0.0d, (float) (byte) -1, (float) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 1, (double) 10);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot5);
        flowArrangement4.add((org.jfree.chart.block.Block) legendTitle6, (java.lang.Object) 2);
        legendTitle6.setWidth((double) 1L);
        legendTitle6.setHeight(1.0d);
        java.awt.Font font13 = legendTitle6.getItemFont();
        org.jfree.chart.block.BlockContainer blockContainer14 = legendTitle6.getItemContainer();
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(blockContainer14);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        double double3 = numberAxis3D1.getUpperBound();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = numberAxis3D1.getLabelInsets();
        numberAxis3D1.setLowerBound(98.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean6 = numberAxis3D1.isPositiveArrowVisible();
        java.lang.Object obj7 = numberAxis3D1.clone();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat8);
        numberAxis3D1.setTickLabelsVisible(false);
        java.lang.String str12 = numberAxis3D1.getLabel();
        boolean boolean13 = numberAxis3D1.getAutoRangeIncludesZero();
        numberAxis3D1.configure();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMinimumArcAngleToDraw();
        piePlot1.setExplodePercent((java.lang.Comparable) 10.0f, (double) (-1L));
        piePlot1.setLabelGap((double) (-4144960));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-5d + "'", double2 == 1.0E-5d);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot2.getFixedDomainAxisSpace();
        categoryPlot2.clearRangeAxes();
        categoryPlot2.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, true);
        java.awt.RenderingHints renderingHints11 = jFreeChart10.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle12 = jFreeChart10.getLegend();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = null;
        dateAxis14.setTickUnit(dateTickUnit15);
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = null;
        dateAxis14.setTickUnit(dateTickUnit17);
        java.text.DateFormat dateFormat19 = null;
        dateAxis14.setDateFormatOverride(dateFormat19);
        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range24 = numberAxis3D23.getRange();
        boolean boolean25 = numberAxis3D23.isVerticalTickLabels();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range29 = numberAxis3D28.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double32 = numberAxis3D31.getFixedAutoRange();
        double double33 = numberAxis3D31.getUpperBound();
        java.awt.Shape shape34 = numberAxis3D31.getUpArrow();
        numberAxis3D28.setUpArrow(shape34);
        int int36 = xYPlot26.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D28);
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        int int38 = xYPlot26.indexOf(xYDataset37);
        java.awt.Paint paint39 = xYPlot26.getDomainTickBandPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = xYPlot26.getRenderer(0);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double45 = numberAxis3D44.getFixedAutoRange();
        numberAxis3D44.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean49 = numberAxis3D44.isPositiveArrowVisible();
        numberAxis3D44.centerRange(0.2d);
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D55 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = null;
        double double60 = categoryAxis3D55.getCategoryStart((-1), (int) ' ', rectangle2D58, rectangleEdge59);
        boolean boolean61 = textTitle53.equals((java.lang.Object) categoryAxis3D55);
        textTitle53.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color64 = java.awt.Color.BLACK;
        textTitle53.setBackgroundPaint((java.awt.Paint) color64);
        java.awt.geom.Rectangle2D rectangle2D66 = textTitle53.getBounds();
        numberAxis3D44.setLeftArrow((java.awt.Shape) rectangle2D66);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D69 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D69.setAutoTickUnitSelection(true, false);
        boolean boolean73 = numberAxis3D69.isTickLabelsVisible();
        java.lang.Object obj74 = numberAxis3D69.clone();
        java.awt.Graphics2D graphics2D75 = null;
        org.jfree.chart.axis.AxisState axisState76 = null;
        java.awt.geom.Rectangle2D rectangle2D77 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = null;
        java.util.List list79 = numberAxis3D69.refreshTicks(graphics2D75, axisState76, rectangle2D77, rectangleEdge78);
        xYPlot26.drawDomainTickBands(graphics2D42, rectangle2D66, list79);
        numberAxis3D23.setDownArrow((java.awt.Shape) rectangle2D66);
        org.jfree.chart.plot.CategoryPlot categoryPlot82 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace83 = categoryPlot82.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot84 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke85 = ringPlot84.getSeparatorStroke();
        categoryPlot82.setDomainGridlineStroke(stroke85);
        org.jfree.chart.axis.AxisLocation axisLocation88 = null;
        categoryPlot82.setDomainAxisLocation((int) ' ', axisLocation88);
        org.jfree.chart.util.RectangleEdge rectangleEdge90 = categoryPlot82.getRangeAxisEdge();
        double double91 = dateAxis14.dateToJava2D(date21, rectangle2D66, rectangleEdge90);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo92 = null;
        try {
            jFreeChart10.draw(graphics2D13, rectangle2D66, chartRenderingInfo92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertNotNull(renderingHints11);
        org.junit.Assert.assertNotNull(legendTitle12);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNull(xYItemRenderer41);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNotNull(obj74);
        org.junit.Assert.assertNotNull(list79);
        org.junit.Assert.assertNull(axisSpace83);
        org.junit.Assert.assertNotNull(stroke85);
        org.junit.Assert.assertNotNull(rectangleEdge90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) (byte) 1, (double) 10);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot6);
        flowArrangement5.add((org.jfree.chart.block.Block) legendTitle7, (java.lang.Object) 2);
        flowArrangement5.clear();
        boolean boolean11 = size2D0.equals((java.lang.Object) flowArrangement5);
        java.lang.String str12 = size2D0.toString();
        double double13 = size2D0.width;
        double double14 = size2D0.getWidth();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str12.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.zoom(100.0d);
        double double3 = ringPlot0.getInteriorGap();
        ringPlot0.setLabelLinksVisible(true);
        java.awt.Stroke stroke6 = ringPlot0.getSeparatorStroke();
        ringPlot0.setPieIndex((int) '#');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.configureDomainAxes();
        java.awt.Font font4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        categoryPlot0.setNoDataMessageFont(font4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace7 = categoryPlot0.getFixedRangeAxisSpace();
        java.lang.Object obj8 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) categoryPlot0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot0.setRenderer((int) (byte) 10, categoryItemRenderer10, false);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNull(axisSpace7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        objectList0.set((int) (byte) 1, (java.lang.Object) color3);
        int int5 = objectList0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = legendTitle1.getVerticalAlignment();
        double double3 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle1.getPadding();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray5 = legendTitle1.getSources();
        java.awt.geom.Rectangle2D rectangle2D6 = legendTitle1.getBounds();
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(legendItemSourceArray5);
        org.junit.Assert.assertNotNull(rectangle2D6);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setAutoTickUnitSelection(true, false);
        boolean boolean5 = numberAxis3D1.isTickLabelsVisible();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range8 = numberAxis3D7.getRange();
        boolean boolean10 = range8.contains((double) (byte) 100);
        numberAxis3D1.setDefaultAutoRange(range8);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot();
        categoryAxis3D13.removeChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot14);
        numberAxis3D1.setPlot((org.jfree.chart.plot.Plot) polarPlot14);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, (double) (-1.0f));
        org.jfree.data.Range range20 = rectangleConstraint19.getWidthRange();
        org.jfree.data.Range range21 = null;
        org.jfree.data.Range range23 = org.jfree.data.Range.expandToInclude(range21, (double) 'a');
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range26 = numberAxis3D25.getRange();
        org.jfree.data.Range range27 = org.jfree.data.Range.combine(range21, range26);
        org.jfree.data.Range range29 = org.jfree.data.Range.shift(range27, 1.0E-5d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = rectangleConstraint19.toRangeWidth(range27);
        numberAxis3D1.setRange(range27, true, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairValue((double) (short) 1, true);
        java.awt.Stroke stroke4 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        float float6 = ringPlot5.getForegroundAlpha();
        ringPlot5.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke11 = xYPlot10.getDomainGridlineStroke();
        boolean boolean12 = ringPlot5.equals((java.lang.Object) xYPlot10);
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot10.getDomainAxisLocation(255);
        xYPlot0.setRangeAxisLocation(axisLocation14, true);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke19 = xYPlot18.getDomainGridlineStroke();
        java.awt.Paint paint20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot18.setRangeCrosshairPaint(paint20);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double24 = numberAxis3D23.getFixedAutoRange();
        double double25 = numberAxis3D23.getUpperBound();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = numberAxis3D23.getLabelInsets();
        xYPlot18.setAxisOffset(rectangleInsets26);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot18.getRenderer();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent29 = null;
        xYPlot18.rendererChanged(rendererChangeEvent29);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double33 = numberAxis3D32.getFixedAutoRange();
        numberAxis3D32.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean37 = numberAxis3D32.isPositiveArrowVisible();
        java.lang.Object obj38 = numberAxis3D32.clone();
        java.text.NumberFormat numberFormat39 = null;
        numberAxis3D32.setNumberFormatOverride(numberFormat39);
        numberAxis3D32.setTickMarkOutsideLength((float) 2);
        xYPlot18.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D32);
        xYPlot0.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) numberAxis3D32);
        java.awt.Stroke stroke45 = xYPlot0.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(stroke45);
    }
}

