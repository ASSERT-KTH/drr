import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", graphics2D1, 1.0f, (float) (short) 10, (double) 100, (float) 0L, 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.combine(range0, range1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test016");
//        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.plot.Plot plot5 = piePlot1.getRootPlot();
        java.awt.Shape shape6 = null;
        try {
            piePlot1.setLegendItemShape(shape6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plot5);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        categoryAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot2);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double10 = categoryAxis3D1.getCategorySeriesMiddle((java.lang.Comparable) 1L, (java.lang.Comparable) 0.0f, categoryDataset6, (double) 10L, rectangle2D8, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke2 = categoryAxis3D1.getTickMarkStroke();
        java.awt.Paint paint3 = categoryAxis3D1.getTickLabelPaint();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            org.jfree.chart.axis.AxisState axisState10 = categoryAxis3D1.draw(graphics2D4, (double) (byte) -1, rectangle2D6, rectangle2D7, rectangleEdge8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = null;
        try {
            piePlot1.setLegendLabelGenerator(pieSectionLabelGenerator5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "");
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "hi!", jFreeChart6, chartChangeEventType7);
        java.lang.Object obj9 = chartChangeEvent8.getSource();
        org.jfree.chart.JFreeChart jFreeChart10 = chartChangeEvent8.getChart();
        org.junit.Assert.assertTrue("'" + obj9 + "' != '" + "hi!" + "'", obj9.equals("hi!"));
        org.junit.Assert.assertNull(jFreeChart10);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", graphics2D1, 0.0f, (float) (short) -1, textAnchor4, (double) 2, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        polarPlot0.addChangeListener(plotChangeListener2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        try {
            polarPlot0.zoomRangeAxes((double) (-1.0f), plotRenderingInfo5, point2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "hi!", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = null;
        try {
            numberAxis3D1.setTickUnit(numberTickUnit2, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryStart((-1), (int) ' ', rectangle2D4, rectangleEdge5);
        java.awt.Paint paint7 = null;
        try {
            categoryAxis3D1.setTickLabelPaint(paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        try {
            ringPlot0.setInteriorGap((double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (52.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        polarPlot0.setDataset(xYDataset1);
        try {
            polarPlot0.zoom(1.0E-5d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) ' ', (double) (byte) 100, 100.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double1 = rectangleInsets0.getTop();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets0.createOutsetRectangle(rectangle2D2, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) -1);
        pieLabelDistributor1.clear();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = null;
        try {
            numberAxis3D1.setTickUnit(numberTickUnit3, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = ringPlot0.getToolTipGenerator();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            ringPlot0.drawBackground(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(pieToolTipGenerator2);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) '#', (double) (short) -1, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape1 = null;
        try {
            ringPlot0.setLegendItemShape(shape1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            legendTitle1.setBounds(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.setVerticalTickLabels(false);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double8 = numberAxis3D1.valueToJava2D((double) 10, rectangle2D6, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        try {
            categoryPlot0.handleClick(2, (int) (short) 0, plotRenderingInfo3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = null;
        try {
            categoryPlot0.setRangeAxisLocation(axisLocation1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.zoomRange((double) (short) 0, (double) 1L);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            org.jfree.chart.axis.AxisState axisState12 = numberAxis3D1.draw(graphics2D6, (double) '4', rectangle2D8, rectangle2D9, rectangleEdge10, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) ' ', (int) (byte) 0, 500);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) ' ', axisLocation6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            categoryPlot0.drawBackground(graphics2D8, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font3 = categoryAxis3D2.getLabelFont();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font3);
        java.awt.Graphics2D graphics2D5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = textLine4.calculateDimensions(graphics2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        boolean boolean2 = categoryPlot0.isOutlineVisible();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.Point point5 = polarPlot0.translateValueThetaRadiusToJava2D((double) 2, 0.0d, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getSeparatorStroke();
        java.awt.Paint paint2 = ringPlot0.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double4 = rectangleInsets3.getTop();
        ringPlot0.setLabelPadding(rectangleInsets3);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets3.createAdjustedRectangle(rectangle2D6, lengthAdjustmentType7, lengthAdjustmentType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        try {
            categoryPlot0.setDomainAxisLocation(axisLocation4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) ' ', axisLocation6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.plot.PlotState plotState11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            categoryPlot0.draw(graphics2D8, rectangle2D9, point2D10, plotState11, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) -1);
        pieLabelDistributor1.clear();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord4 = pieLabelDistributor1.getPieLabelRecord((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("ThreadContext", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.awt.Color color0 = java.awt.Color.white;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = polarPlot0.getLegendItems();
        java.util.Iterator iterator2 = legendItemCollection1.iterator();
        int int3 = legendItemCollection1.getItemCount();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(iterator2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        double double3 = numberAxis3D1.getUpperBound();
        numberAxis3D1.setAutoRangeStickyZero(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryStart((-1), (int) ' ', rectangle2D4, rectangleEdge5);
        java.awt.Paint paint7 = categoryAxis3D1.getLabelPaint();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            org.jfree.chart.axis.AxisState axisState14 = categoryAxis3D1.draw(graphics2D8, (double) 10.0f, rectangle2D10, rectangle2D11, rectangleEdge12, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean6 = numberAxis3D1.isPositiveArrowVisible();
        java.lang.Object obj7 = numberAxis3D1.clone();
        org.jfree.data.RangeType rangeType8 = null;
        try {
            numberAxis3D1.setRangeType(rangeType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.08d, 10.0d, (double) (byte) 10, (double) '#');
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets4.createInsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ThreadContext", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.zoomRange((double) (short) 0, (double) 1L);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        numberAxis3D1.setAxisLineStroke(stroke6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 1, (double) 10);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot5);
        flowArrangement4.add((org.jfree.chart.block.Block) legendTitle6, (java.lang.Object) 2);
        org.jfree.chart.block.BlockContainer blockContainer9 = null;
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, (double) (-1.0f));
        org.jfree.data.Range range14 = rectangleConstraint13.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint13.toFixedHeight((double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint13.toFixedWidth((double) 100L);
        try {
            org.jfree.chart.util.Size2D size2D19 = flowArrangement4.arrange(blockContainer9, graphics2D10, rectangleConstraint18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.08d, 10.0d, (double) (byte) 10, (double) '#');
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            rectangleInsets4.trim(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (double) (byte) 0, (float) 100L, (float) 8);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.mapDatasetToRangeAxis((int) (byte) 1, (int) '4');
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation12 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double1 = rectangleInsets0.getTop();
        double double2 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        legendTitle1.setID("");
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Point2D point2D7 = null;
        org.jfree.chart.plot.PlotState plotState8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            categoryPlot0.draw(graphics2D5, rectangle2D6, point2D7, plotState8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font2 = categoryAxis3D1.getLabelFont();
        categoryAxis3D1.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 'a');
        double double3 = range2.getUpperBound();
        double double5 = range2.constrain((double) (short) 1);
        try {
            java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) range2);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.0d + "'", double5 == 97.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint3 = piePlot1.getSectionPaint((java.lang.Comparable) 8);
        double double4 = piePlot1.getMaximumLabelWidth();
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.14d + "'", double4 == 0.14d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font3 = categoryAxis3D2.getLabelFont();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) color4, (float) (byte) 100);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        try {
            float float9 = textFragment6.calculateBaselineOffset(graphics2D7, textAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.zoom(100.0d);
        boolean boolean3 = ringPlot0.getSeparatorsVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            org.jfree.chart.plot.PiePlotState piePlotState9 = ringPlot0.initialise(graphics2D4, rectangle2D5, piePlot6, (java.lang.Integer) 0, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        polarPlot1.setDataset(xYDataset2);
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = polarPlot1.getOrientation();
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation4);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) 500);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font3 = categoryAxis3D2.getLabelFont();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            textLine4.draw(graphics2D5, (float) 0, 0.0f, textAnchor8, (float) 100, (float) 1L, (double) 500);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        double double3 = numberAxis3D1.getUpperBound();
        double double4 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.setRange(0.2d, 2.4d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 1, (double) 10);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot5);
        flowArrangement4.add((org.jfree.chart.block.Block) legendTitle6, (java.lang.Object) 2);
        double double9 = legendTitle6.getContentXOffset();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "ThreadContext");
        java.lang.String str3 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.BOTTOM_LEFT" + "'", str1.equals("TextBlockAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.plot.Plot plot9 = piePlot5.getRootPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = ringPlot0.initialise(graphics2D2, rectangle2D3, piePlot5, (java.lang.Integer) 10, plotRenderingInfo11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        ringPlot0.markerChanged(markerChangeEvent13);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator15 = null;
        try {
            ringPlot0.setLegendLabelGenerator(pieSectionLabelGenerator15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(piePlotState12);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        polarPlot0.addCornerTextItem("hi!");
        org.jfree.chart.plot.Plot plot4 = polarPlot0.getRootPlot();
        plot4.setForegroundAlpha((float) '4');
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(plot4);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.awt.Paint paint0 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getInfo();
        basicProjectInfo0.setName("hi!");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot0.getRangeAxisEdge((int) (byte) 100);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.Range range3 = new org.jfree.data.Range((-1.0d), 100.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, (double) (-1.0f));
        org.jfree.data.Range range7 = rectangleConstraint6.getWidthRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = rectangleConstraint6.getWidthConstraintType();
        org.jfree.data.Range range10 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, (double) (-1.0f));
        org.jfree.data.Range range14 = rectangleConstraint13.getWidthRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint13.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) ' ', range3, lengthConstraintType8, (double) (byte) 0, range10, lengthConstraintType15);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (short) 0);
        boolean boolean20 = lengthConstraintType8.equals((java.lang.Object) '4');
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.plot.Plot plot5 = piePlot1.getRootPlot();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) 1, (java.awt.Paint) color7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.Point2D point2D11 = null;
        org.jfree.chart.plot.PlotState plotState12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            piePlot1.draw(graphics2D9, rectangle2D10, point2D11, plotState12, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        try {
            boolean boolean4 = categoryPlot0.removeAnnotation(categoryAnnotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=-1.0]", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D2.getCategoryStart((-1), (int) ' ', rectangle2D5, rectangleEdge6);
        java.util.List list8 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.awt.Paint paint9 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot0.getIndexOf(categoryItemRenderer10);
        org.jfree.chart.plot.Marker marker13 = null;
        org.jfree.chart.util.Layer layer14 = null;
        try {
            boolean boolean15 = categoryPlot0.removeRangeMarker((int) 'a', marker13, layer14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getLegendItems();
        double double2 = categoryPlot0.getRangeCrosshairValue();
        float float3 = categoryPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.5f + "'", float3 == 0.5f);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (byte) 100, (double) 255, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = polarPlot0.getLegendItems();
        boolean boolean2 = polarPlot0.isAngleGridlinesVisible();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Image image5 = polarPlot4.getBackgroundImage();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        polarPlot4.setRenderer(polarItemRenderer6);
        java.awt.Font font8 = polarPlot4.getAngleLabelFont();
        java.awt.Paint paint9 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("UnitType.RELATIVE", font8, paint9, 10.0f);
        polarPlot0.setAngleLabelFont(font8);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.Point2D point2D15 = null;
        org.jfree.chart.plot.PlotState plotState16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            polarPlot0.draw(graphics2D13, rectangle2D14, point2D15, plotState16, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(image5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.String str1 = unitType0.toString();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double4 = numberAxis3D3.getFixedAutoRange();
        double double5 = numberAxis3D3.getUpperBound();
        java.awt.Font font6 = numberAxis3D3.getTickLabelFont();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis3D3.java2DToValue((double) 10L, rectangle2D8, rectangleEdge9);
        boolean boolean11 = unitType0.equals((java.lang.Object) double10);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE" + "'", str1.equals("UnitType.RELATIVE"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.POSITIVE_INFINITY + "'", double10 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range4 = numberAxis3D3.getRange();
        boolean boolean6 = range4.contains((double) (byte) 100);
        numberAxis3D1.setRange(range4, false, true);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 0.2d, (-1.95d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.configureDomainAxes();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Point2D point2D6 = null;
        org.jfree.chart.plot.PlotState plotState7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            categoryPlot0.draw(graphics2D4, rectangle2D5, point2D6, plotState7, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord4 = abstractPieLabelDistributor2.getPieLabelRecord(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.zoom(100.0d);
        ringPlot0.setLabelLinksVisible(false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            xYPlot5.addRangeMarker(2, marker9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke2 = categoryAxis3D1.getTickMarkStroke();
        int int3 = categoryAxis3D1.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis3D1.getCategoryLabelPositions();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot10.getFixedDomainAxisSpace();
        categoryPlot10.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot10.getDomainAxisEdge();
        try {
            double double14 = categoryAxis3D1.getCategorySeriesMiddle((java.lang.Comparable) ' ', (java.lang.Comparable) "RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=-1.0]", categoryDataset7, (double) 10.0f, rectangle2D9, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.plot.Plot plot9 = piePlot5.getRootPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = ringPlot0.initialise(graphics2D2, rectangle2D3, piePlot5, (java.lang.Integer) 10, plotRenderingInfo11);
        java.awt.Paint paint13 = null;
        ringPlot0.setLabelShadowPaint(paint13);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(piePlotState12);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        java.awt.Paint paint4 = ringPlot2.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double6 = rectangleInsets5.getTop();
        ringPlot2.setLabelPadding(rectangleInsets5);
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        ringPlot2.setLabelBackgroundPaint((java.awt.Paint) color8);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        try {
            categoryPlot0.handleClick(100, (int) (byte) 0, plotRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D2.getCategoryStart((-1), (int) ' ', rectangle2D5, rectangleEdge6);
        java.util.List list8 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        categoryPlot0.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot0.setRangeGridlineStroke(stroke12);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.awt.Color color1 = java.awt.Color.getColor("hi!");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot5.getDomainAxisLocation(255);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot5.getRendererForDataset(xYDataset10);
        xYPlot5.setRangeCrosshairValue(0.0d);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        piePlot15.drawBackgroundImage(graphics2D16, rectangle2D17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot15.setShadowPaint((java.awt.Paint) color19);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke23 = categoryAxis3D22.getTickMarkStroke();
        piePlot15.setLabelLinkStroke(stroke23);
        xYPlot5.setDomainCrosshairStroke(stroke23);
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot();
        float float28 = ringPlot27.getForegroundAlpha();
        ringPlot27.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke33 = xYPlot32.getDomainGridlineStroke();
        boolean boolean34 = ringPlot27.equals((java.lang.Object) xYPlot32);
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot32.getDomainAxisLocation(255);
        try {
            xYPlot5.setDomainAxisLocation((int) (byte) -1, axisLocation36, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(xYItemRenderer11);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 1.0f + "'", float28 == 1.0f);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(axisLocation36);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) "RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=-1.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceText("");
        projectInfo0.setInfo("ThreadContext");
        projectInfo0.setName("TextBlockAnchor.BOTTOM_LEFT");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke6 = categoryAxis3D5.getTickMarkStroke();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] { stroke2, stroke3, stroke6, stroke7, stroke8 };
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke12 = categoryAxis3D11.getTickMarkStroke();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke16 = categoryAxis3D15.getTickMarkStroke();
        java.awt.Stroke stroke17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] { stroke12, stroke13, stroke16, stroke17 };
        java.awt.Shape shape19 = null;
        java.awt.Shape[] shapeArray20 = new java.awt.Shape[] { shape19 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray9, strokeArray18, shapeArray20);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis3D23.getCategoryStart((-1), (int) ' ', rectangle2D26, rectangleEdge27);
        boolean boolean29 = defaultDrawingSupplier21.equals((java.lang.Object) rectangleEdge27);
        java.awt.Paint paint30 = defaultDrawingSupplier21.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(shapeArray20);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D2.getCategoryStart((-1), (int) ' ', rectangle2D5, rectangleEdge6);
        java.util.List list8 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.awt.Paint paint9 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot0.getIndexOf(categoryItemRenderer10);
        org.jfree.chart.plot.Marker marker12 = null;
        try {
            boolean boolean13 = categoryPlot0.removeDomainMarker(marker12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=-1.0]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 'a');
        double double3 = range2.getLength();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font3 = categoryAxis3D2.getLabelFont();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) color4, (float) (byte) 100);
        java.awt.Paint paint7 = textFragment6.getPaint();
        java.awt.Font font8 = textFragment6.getFont();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.setVerticalTickLabels(false);
        java.awt.Stroke stroke5 = numberAxis3D1.getTickMarkStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        legendTitle1.setHeight((double) (byte) 100);
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = polarPlot4.getLegendItems();
        java.util.Iterator iterator6 = legendItemCollection5.iterator();
        boolean boolean7 = legendTitle1.equals((java.lang.Object) legendItemCollection5);
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder();
        legendTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder8);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = legendTitle1.getHorizontalAlignment();
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(iterator6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.plot.Plot plot5 = piePlot1.getRootPlot();
        double double6 = piePlot1.getMinimumArcAngleToDraw();
        java.awt.Paint paint7 = piePlot1.getLabelShadowPaint();
        piePlot1.setIgnoreNullValues(false);
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-5d + "'", double6 == 1.0E-5d);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Image image2 = polarPlot1.getBackgroundImage();
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = polarPlot1.getOrientation();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        double double6 = piePlot5.getMinimumArcAngleToDraw();
        boolean boolean7 = plotOrientation3.equals((java.lang.Object) double6);
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-5d + "'", double6 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.trimHeight(0.05d);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.95d) + "'", double2 == (-1.95d));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double1 = rectangleInsets0.getTop();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D3.setMaximumCategoryLabelWidthRatio(10.0f);
        boolean boolean6 = rectangleInsets0.equals((java.lang.Object) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets0.createOutsetRectangle(rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        double double2 = blockParams0.getTranslateX();
        blockParams0.setTranslateY((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot5.getDomainAxisLocation(255);
        java.awt.Stroke stroke10 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.Marker marker11 = null;
        try {
            boolean boolean12 = xYPlot5.removeDomainMarker(marker11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("TextBlockAnchor.BOTTOM_LEFT", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, (double) (-1.0f));
        org.jfree.data.Range range3 = rectangleConstraint2.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toFixedHeight((double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint5.toUnconstrainedHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint5.toFixedWidth((double) (short) -1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) "UnitType.RELATIVE");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        boolean boolean3 = objectList0.equals((java.lang.Object) 100.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.zoom(100.0d);
        double double3 = ringPlot0.getInteriorGap();
        ringPlot0.setLabelLinksVisible(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        piePlot8.drawBackgroundImage(graphics2D9, rectangle2D10);
        org.jfree.chart.plot.Plot plot12 = piePlot8.getRootPlot();
        double double13 = piePlot8.getMinimumArcAngleToDraw();
        java.awt.Paint paint14 = piePlot8.getLabelShadowPaint();
        ringPlot0.setSectionPaint((java.lang.Comparable) 10, paint14);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(plot12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0E-5d + "'", double13 == 1.0E-5d);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot2.getFixedDomainAxisSpace();
        categoryPlot2.clearRangeAxes();
        categoryPlot2.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, true);
        java.awt.RenderingHints renderingHints11 = jFreeChart10.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle12 = jFreeChart10.getLegend();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        try {
            java.awt.image.BufferedImage bufferedImage17 = jFreeChart10.createBufferedImage((int) (short) 0, 255, (int) (short) 1, chartRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (255) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertNotNull(renderingHints11);
        org.junit.Assert.assertNotNull(legendTitle12);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.awt.geom.Point2D point2D3 = null;
        org.jfree.chart.plot.PlotState plotState4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        try {
            polarPlot0.draw(graphics2D1, rectangle2D2, point2D3, plotState4, plotRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font2 = categoryAxis3D1.getLabelFont();
        categoryAxis3D1.setLabelAngle((double) (-1));
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryAxis3D1.setTickLabelPaint((java.lang.Comparable) 97.0d, paint6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            org.jfree.chart.axis.AxisState axisState14 = categoryAxis3D1.draw(graphics2D8, (double) 1, rectangle2D10, rectangle2D11, rectangleEdge12, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 0.2d, 0.0d, (int) 'a', (java.lang.Comparable) 97.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        java.awt.Paint paint4 = ringPlot2.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double6 = rectangleInsets5.getTop();
        ringPlot2.setLabelPadding(rectangleInsets5);
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        ringPlot2.setLabelBackgroundPaint((java.awt.Paint) color8);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color8);
        categoryPlot0.clearDomainMarkers();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ThreadContext", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.trimHeight(0.05d);
        org.jfree.chart.util.Size2D size2D3 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment4, verticalAlignment5, (double) (byte) 1, (double) 10);
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot9);
        flowArrangement8.add((org.jfree.chart.block.Block) legendTitle10, (java.lang.Object) 2);
        flowArrangement8.clear();
        boolean boolean14 = size2D3.equals((java.lang.Object) flowArrangement8);
        boolean boolean15 = rectangleInsets0.equals((java.lang.Object) boolean14);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.95d) + "'", double2 == (-1.95d));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        xYPlot5.setRenderer(8, xYItemRenderer9);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            xYPlot5.addDomainMarker(500, marker12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.plot.Plot plot9 = piePlot5.getRootPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = ringPlot0.initialise(graphics2D2, rectangle2D3, piePlot5, (java.lang.Integer) 10, plotRenderingInfo11);
        int int13 = ringPlot0.getPieIndex();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Size2D[width=0.0, height=0.0]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke6 = categoryAxis3D5.getTickMarkStroke();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] { stroke2, stroke3, stroke6, stroke7, stroke8 };
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke12 = categoryAxis3D11.getTickMarkStroke();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke16 = categoryAxis3D15.getTickMarkStroke();
        java.awt.Stroke stroke17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] { stroke12, stroke13, stroke16, stroke17 };
        java.awt.Shape shape19 = null;
        java.awt.Shape[] shapeArray20 = new java.awt.Shape[] { shape19 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray9, strokeArray18, shapeArray20);
        org.jfree.chart.plot.RingPlot ringPlot22 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot22);
        legendTitle23.setHeight((double) (byte) 100);
        boolean boolean26 = defaultDrawingSupplier21.equals((java.lang.Object) legendTitle23);
        org.jfree.chart.block.BlockContainer blockContainer27 = null;
        legendTitle23.setWrapper(blockContainer27);
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(shapeArray20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        double double3 = numberAxis3D1.getUpperBound();
        java.awt.Font font4 = numberAxis3D1.getTickLabelFont();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis3D1.java2DToValue((double) 10L, rectangle2D6, rectangleEdge7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot11);
        legendTitle12.setHeight((double) (byte) 100);
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = polarPlot15.getLegendItems();
        java.util.Iterator iterator17 = legendItemCollection16.iterator();
        boolean boolean18 = legendTitle12.equals((java.lang.Object) legendItemCollection16);
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder();
        legendTitle12.setFrame((org.jfree.chart.block.BlockFrame) blockBorder19);
        double double21 = legendTitle12.getHeight();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace23 = categoryPlot22.getFixedDomainAxisSpace();
        categoryPlot22.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot22.getDomainAxisEdge();
        legendTitle12.setLegendItemGraphicEdge(rectangleEdge25);
        try {
            double double27 = numberAxis3D1.valueToJava2D((double) 100.0f, rectangle2D10, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertNotNull(iterator17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNull(axisSpace23);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.plot.Plot plot9 = piePlot5.getRootPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = ringPlot0.initialise(graphics2D2, rectangle2D3, piePlot5, (java.lang.Integer) 10, plotRenderingInfo11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        ringPlot0.markerChanged(markerChangeEvent13);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator15 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator15);
        java.awt.Paint paint17 = ringPlot0.getLabelBackgroundPaint();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font2 = categoryAxis3D1.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot7);
        legendTitle8.setHeight((double) (byte) 100);
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = polarPlot11.getLegendItems();
        java.util.Iterator iterator13 = legendItemCollection12.iterator();
        boolean boolean14 = legendTitle8.equals((java.lang.Object) legendItemCollection12);
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder();
        legendTitle8.setFrame((org.jfree.chart.block.BlockFrame) blockBorder15);
        double double17 = legendTitle8.getHeight();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot18.getFixedDomainAxisSpace();
        categoryPlot18.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot18.getDomainAxisEdge();
        legendTitle8.setLegendItemGraphicEdge(rectangleEdge21);
        try {
            double double23 = categoryAxis3D1.getCategoryJava2DCoordinate(categoryAnchor3, 100, (int) 'a', rectangle2D6, rectangleEdge21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(iterator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.0d + "'", double17 == 100.0d);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot2.getFixedDomainAxisSpace();
        categoryPlot2.clearRangeAxes();
        categoryPlot2.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, true);
        java.awt.RenderingHints renderingHints11 = jFreeChart10.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle12 = jFreeChart10.getLegend();
        jFreeChart10.setTitle("hi!");
        try {
            jFreeChart10.setTextAntiAlias((java.lang.Object) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: false incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertNotNull(renderingHints11);
        org.junit.Assert.assertNotNull(legendTitle12);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.08d, 10.0d, (double) (byte) 10, (double) '#');
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets4, (java.awt.Paint) color5);
        double double8 = rectangleInsets4.calculateRightInset((double) ' ');
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot5.getDomainAxisLocation(255);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot5.getRendererForDataset(xYDataset10);
        xYPlot5.setRangeCrosshairValue(0.0d);
        org.jfree.chart.plot.Marker marker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        try {
            boolean boolean16 = xYPlot5.removeDomainMarker(marker14, layer15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(xYItemRenderer11);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D2.getCategoryStart((-1), (int) ' ', rectangle2D5, rectangleEdge6);
        java.util.List list8 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        categoryPlot0.drawBackgroundImage(graphics2D9, rectangle2D10);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            boolean boolean14 = categoryPlot0.removeRangeMarker(marker12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getLegendItems();
        double double2 = categoryPlot0.getRangeCrosshairValue();
        java.util.List list3 = categoryPlot0.getAnnotations();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list1 = projectInfo0.getContributors();
        org.junit.Assert.assertNull(list1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.awt.Color color1 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.Color color3 = java.awt.Color.getColor("Size2D[width=0.0, height=0.0]", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceText("");
        projectInfo0.setInfo("ThreadContext");
        projectInfo0.setName("{0}");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        polarPlot0.addCornerTextItem("hi!");
        org.jfree.chart.plot.Plot plot4 = polarPlot0.getRootPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        polarPlot0.addChangeListener(plotChangeListener5);
        boolean boolean7 = polarPlot0.isRangeZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        try {
            polarPlot0.zoomRangeAxes(0.08d, (double) 100, plotRenderingInfo10, point2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot2.getFixedDomainAxisSpace();
        categoryPlot2.clearRangeAxes();
        categoryPlot2.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, true);
        java.awt.RenderingHints renderingHints11 = jFreeChart10.getRenderingHints();
        java.awt.Stroke stroke12 = jFreeChart10.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        try {
            java.awt.image.BufferedImage bufferedImage17 = jFreeChart10.createBufferedImage((int) (byte) 0, (int) (byte) 0, (int) (byte) -1, chartRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertNotNull(renderingHints11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setDarkerSides(true);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Point2D point2D5 = null;
        org.jfree.chart.plot.PlotState plotState6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            piePlot3D0.draw(graphics2D3, rectangle2D4, point2D5, plotState6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, (double) (-1.0f));
        org.jfree.data.Range range3 = rectangleConstraint2.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toFixedHeight((double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint2.toFixedWidth((double) 100L);
        java.lang.String str8 = rectangleConstraint7.toString();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=-1.0]" + "'", str8.equals("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=-1.0]"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation2 = null;
        try {
            boolean boolean3 = xYPlot0.removeAnnotation(xYAnnotation2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setExplodedPieArea(rectangle2D2);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        piePlotState1.setLinkArea(rectangle2D4);
        java.awt.geom.Rectangle2D rectangle2D6 = piePlotState1.getLinkArea();
        org.junit.Assert.assertNull(rectangle2D6);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio(10.0f);
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color5 = java.awt.Color.BLACK;
        categoryAxis3D1.setTickLabelPaint((java.lang.Comparable) date4, (java.awt.Paint) color5);
        categoryAxis3D1.setTickMarkInsideLength((float) 8);
        categoryAxis3D1.setUpperMargin(0.0d);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        legendTitle1.setID("hi!");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot5.setShadowPaint((java.awt.Paint) color9);
        boolean boolean11 = legendTitle1.equals((java.lang.Object) piePlot5);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke13 = ringPlot12.getSeparatorStroke();
        java.awt.Paint paint14 = ringPlot12.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double16 = rectangleInsets15.getTop();
        ringPlot12.setLabelPadding(rectangleInsets15);
        legendTitle1.setMargin(rectangleInsets15);
        double double20 = rectangleInsets15.calculateBottomOutset(0.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setTickMarkOutsideLength(0.0f);
        categoryAxis3D1.setLabelAngle(49.5d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.awt.Font font2 = null;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, (java.awt.Paint) color3, (float) (-1L), textMeasurer5);
        org.jfree.chart.text.TextLine textLine7 = null;
        textBlock6.addLine(textLine7);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font12 = categoryAxis3D11.getLabelFont();
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        textBlock6.addLine("Pie Plot", font12, (java.awt.Paint) color13);
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        ringPlot15.zoom(100.0d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke20 = categoryAxis3D19.getTickMarkStroke();
        java.awt.Paint paint21 = categoryAxis3D19.getTickLabelPaint();
        ringPlot15.setLabelPaint(paint21);
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("ThreadContext", font12, paint21);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        try {
            textFragment23.draw(graphics2D24, (float) 2, (float) '#', textAnchor27, (float) (-1), (float) 1L, (double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(textAnchor27);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        polarPlot0.addCornerTextItem("hi!");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        polarPlot0.zoomDomainAxes((double) (short) 10, plotRenderingInfo5, point2D6);
        java.awt.Font font8 = polarPlot0.getAngleLabelFont();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        try {
            polarPlot0.zoomRangeAxes(0.0d, (double) 1L, plotRenderingInfo11, point2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.mapDatasetToRangeAxis((int) (byte) 1, (int) '4');
        boolean boolean12 = categoryPlot0.getDrawSharedDomainAxis();
        java.awt.Paint paint13 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.chart.util.Layer layer16 = null;
        try {
            boolean boolean17 = categoryPlot0.removeRangeMarker((int) (byte) 100, marker15, layer16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font3 = categoryAxis3D2.getLabelFont();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font3);
        org.jfree.chart.text.TextFragment textFragment5 = null;
        textLine4.addFragment(textFragment5);
        java.awt.Graphics2D graphics2D7 = null;
        try {
            org.jfree.chart.util.Size2D size2D8 = textLine4.calculateDimensions(graphics2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Paint paint2 = textTitle1.getBackgroundPaint();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot3);
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = legendTitle4.getVerticalAlignment();
        textTitle1.setVerticalAlignment(verticalAlignment5);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = textTitle1.getVerticalAlignment();
        textTitle1.setPadding((double) 100.0f, (double) (byte) 1, (double) 2, (double) 0L);
        java.lang.String str13 = textTitle1.getText();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = categoryPlot0.getDrawingSupplier();
        int int3 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot0.getDomainMarkers(layer4);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNull(collection5);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.setRangeCrosshairVisible(true);
        categoryPlot0.configureRangeAxes();
        org.junit.Assert.assertNull(axisSpace1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        legendTitle1.setHeight((double) (byte) 100);
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = polarPlot4.getLegendItems();
        java.util.Iterator iterator6 = legendItemCollection5.iterator();
        boolean boolean7 = legendTitle1.equals((java.lang.Object) legendItemCollection5);
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder();
        legendTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder8);
        double double10 = legendTitle1.getHeight();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace12 = categoryPlot11.getFixedDomainAxisSpace();
        categoryPlot11.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot11.getDomainAxisEdge();
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge14);
        boolean boolean16 = legendTitle1.getNotify();
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(iterator6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot5.getDomainAxisLocation(255);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot5.getRendererForDataset(xYDataset10);
        xYPlot5.setRangeCrosshairValue(0.0d);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        piePlot15.drawBackgroundImage(graphics2D16, rectangle2D17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot15.setShadowPaint((java.awt.Paint) color19);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke23 = categoryAxis3D22.getTickMarkStroke();
        piePlot15.setLabelLinkStroke(stroke23);
        xYPlot5.setDomainCrosshairStroke(stroke23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        try {
            xYPlot5.handleClick((int) (short) 0, 1, plotRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(xYItemRenderer11);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getSeparatorStroke();
        int int2 = ringPlot0.getPieIndex();
        java.awt.Paint paint3 = ringPlot0.getBaseSectionPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot5.getDomainAxisLocation(255);
        java.awt.Stroke stroke10 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            boolean boolean14 = xYPlot5.removeRangeMarker(0, marker12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (-1L), (double) 10.0f, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        double double3 = numberAxis3D1.getUpperBound();
        double double4 = numberAxis3D1.getFixedAutoRange();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment7, verticalAlignment8, (double) (byte) 1, (double) 10);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot12);
        flowArrangement11.add((org.jfree.chart.block.Block) legendTitle13, (java.lang.Object) 2);
        legendTitle13.setWidth((double) 1L);
        legendTitle13.setHeight(1.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = legendTitle13.getPosition();
        boolean boolean21 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge20);
        try {
            double double22 = numberAxis3D1.valueToJava2D(1.0E-5d, rectangle2D6, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Multiple Pie Plot", graphics2D1, (float) 0L, (float) (byte) 100, (double) (short) 1, (float) (byte) -1, (float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot2.getFixedDomainAxisSpace();
        categoryPlot2.clearRangeAxes();
        categoryPlot2.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        try {
            java.awt.image.BufferedImage bufferedImage15 = jFreeChart10.createBufferedImage(0, 255, (int) (byte) 1, chartRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (255) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D2.getCategoryStart((-1), (int) ' ', rectangle2D5, rectangleEdge6);
        java.util.List list8 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.lang.Object obj9 = categoryAxis3D2.clone();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot2.getFixedDomainAxisSpace();
        categoryPlot2.clearRangeAxes();
        categoryPlot2.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, true);
        java.awt.RenderingHints renderingHints11 = jFreeChart10.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle12 = jFreeChart10.getLegend();
        jFreeChart10.setTextAntiAlias(true);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            jFreeChart10.draw(graphics2D15, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertNotNull(renderingHints11);
        org.junit.Assert.assertNotNull(legendTitle12);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = ringPlot0.getToolTipGenerator();
        ringPlot0.setSectionDepth((double) (byte) -1);
        ringPlot0.setStartAngle((double) 10.0f);
        java.lang.Object obj7 = null;
        boolean boolean8 = ringPlot0.equals(obj7);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        boolean boolean11 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        try {
            categoryPlot0.setRangeAxisLocation(axisLocation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font3 = categoryAxis3D2.getLabelFont();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font3);
        org.jfree.chart.text.TextFragment textFragment5 = null;
        textLine4.addFragment(textFragment5);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font10 = categoryAxis3D9.getLabelFont();
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("hi!", font10);
        org.jfree.chart.text.TextFragment textFragment12 = null;
        textLine11.addFragment(textFragment12);
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Image image16 = polarPlot15.getBackgroundImage();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        polarPlot15.setRenderer(polarItemRenderer17);
        java.awt.Font font19 = polarPlot15.getAngleLabelFont();
        java.awt.Paint paint20 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("UnitType.RELATIVE", font19, paint20, 10.0f);
        textLine11.addFragment(textFragment22);
        textLine4.addFragment(textFragment22);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(image16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        double double2 = textTitle1.getContentYOffset();
        java.lang.String str3 = textTitle1.getURLText();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot4);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = ringPlot4.getLabelDistributor();
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace8 = color7.getColorSpace();
        java.awt.color.ColorSpace colorSpace9 = color7.getColorSpace();
        ringPlot4.setLabelShadowPaint((java.awt.Paint) color7);
        textTitle1.setBackgroundPaint((java.awt.Paint) color7);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.Color color14 = java.awt.Color.BLACK;
        int int15 = color14.getRed();
        java.lang.Object obj16 = textTitle1.draw(graphics2D12, rectangle2D13, (java.lang.Object) color14);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(colorSpace8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(obj16);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D2.getCategoryStart((-1), (int) ' ', rectangle2D5, rectangleEdge6);
        java.util.List list8 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets(0.08d, 10.0d, (double) (byte) 10, (double) '#');
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder(rectangleInsets15, (java.awt.Paint) color16);
        boolean boolean18 = categoryPlot0.equals((java.lang.Object) blockBorder17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder17.getInsets();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot2.getFixedDomainAxisSpace();
        categoryPlot2.clearRangeAxes();
        categoryPlot2.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, true);
        java.awt.RenderingHints renderingHints11 = jFreeChart10.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle12 = jFreeChart10.getLegend();
        jFreeChart10.setTextAntiAlias(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart10.createBufferedImage(10, (int) (byte) 10, chartRenderingInfo17);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = null;
        try {
            java.awt.image.BufferedImage bufferedImage23 = jFreeChart10.createBufferedImage((int) 'a', 0, (int) (short) 10, chartRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (97) and height (0) must be > 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertNotNull(renderingHints11);
        org.junit.Assert.assertNotNull(legendTitle12);
        org.junit.Assert.assertNotNull(bufferedImage18);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D2.getCategoryStart((-1), (int) ' ', rectangle2D5, rectangleEdge6);
        java.util.List list8 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        categoryPlot0.drawBackgroundImage(graphics2D9, rectangle2D10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 10, plotRenderingInfo13, point2D14, true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("XY Plot");
        categoryAxis3D18.setLabelToolTip("ThreadContext");
        categoryPlot0.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D18);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        float float4 = ringPlot3.getForegroundAlpha();
        ringPlot3.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke9 = xYPlot8.getDomainGridlineStroke();
        boolean boolean10 = ringPlot3.equals((java.lang.Object) xYPlot8);
        org.jfree.chart.axis.AxisLocation axisLocation12 = xYPlot8.getDomainAxisLocation(255);
        xYPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation12, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double17 = numberAxis3D16.getFixedAutoRange();
        numberAxis3D16.setLabelAngle((double) 10L);
        org.jfree.data.Range range20 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D16);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        xYPlot23.setRangeCrosshairValue((double) (short) 1, true);
        java.awt.Stroke stroke27 = xYPlot23.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.RingPlot ringPlot28 = new org.jfree.chart.plot.RingPlot();
        float float29 = ringPlot28.getForegroundAlpha();
        ringPlot28.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke34 = xYPlot33.getDomainGridlineStroke();
        boolean boolean35 = ringPlot28.equals((java.lang.Object) xYPlot33);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot33.getDomainAxisLocation(255);
        xYPlot23.setRangeAxisLocation(axisLocation37, true);
        org.jfree.chart.plot.PolarPlot polarPlot40 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        polarPlot40.setDataset(xYDataset41);
        org.jfree.chart.plot.PlotOrientation plotOrientation43 = polarPlot40.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation37, plotOrientation43);
        try {
            double double45 = numberAxis3D16.java2DToValue((double) 0.5f, rectangle2D22, rectangleEdge44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 1.0f + "'", float29 == 1.0f);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(plotOrientation43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getLowerMargin();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke7 = ringPlot6.getSeparatorStroke();
        categoryPlot4.setDomainGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        categoryPlot4.setDomainAxisLocation((int) ' ', axisLocation10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot4.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot4.setRenderer(categoryItemRenderer13);
        boolean boolean15 = categoryPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot4.getRangeAxis((int) '4');
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot19.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke22 = ringPlot21.getSeparatorStroke();
        categoryPlot19.setDomainGridlineStroke(stroke22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = null;
        categoryPlot19.setDomainAxisLocation((int) ' ', axisLocation25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot19.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace29 = numberAxis3D1.reserveSpace(graphics2D3, (org.jfree.chart.plot.Plot) categoryPlot4, rectangle2D18, rectangleEdge27, axisSpace28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairValue((double) (short) 1, true);
        java.awt.Stroke stroke4 = xYPlot0.getRangeZeroBaselineStroke();
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setDomainZeroBaselinePaint(paint5);
        java.awt.Paint paint7 = xYPlot0.getDomainTickBandPaint();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) 1, (double) 1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D2.getCategoryStart((-1), (int) ' ', rectangle2D5, rectangleEdge6);
        java.util.List list8 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        categoryPlot0.drawBackgroundImage(graphics2D9, rectangle2D10);
        org.jfree.chart.plot.Marker marker12 = null;
        try {
            boolean boolean13 = categoryPlot0.removeRangeMarker(marker12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.plot.Plot plot9 = piePlot5.getRootPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = ringPlot0.initialise(graphics2D2, rectangle2D3, piePlot5, (java.lang.Integer) 10, plotRenderingInfo11);
        boolean boolean13 = ringPlot0.getSeparatorsVisible();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor14 = ringPlot0.getLabelDistributor();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor14);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        legendTitle1.setID("hi!");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot5.setShadowPaint((java.awt.Paint) color9);
        boolean boolean11 = legendTitle1.equals((java.lang.Object) piePlot5);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke13 = ringPlot12.getSeparatorStroke();
        java.awt.Paint paint14 = ringPlot12.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double16 = rectangleInsets15.getTop();
        ringPlot12.setLabelPadding(rectangleInsets15);
        legendTitle1.setMargin(rectangleInsets15);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets15.createOutsetRectangle(rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace4 = color3.getColorSpace();
        java.awt.color.ColorSpace colorSpace5 = color3.getColorSpace();
        ringPlot0.setLabelShadowPaint((java.awt.Paint) color3);
        double double7 = ringPlot0.getOuterSeparatorExtension();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range(97.0d, 49.5d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (97.0) <= upper (49.5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setExplodedPieArea(rectangle2D2);
        piePlotState1.setPieHRadius(0.05d);
        java.awt.geom.Rectangle2D rectangle2D6 = piePlotState1.getPieArea();
        org.junit.Assert.assertNull(rectangle2D6);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.configureDomainAxes();
        java.awt.Font font4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        categoryPlot0.setNoDataMessageFont(font4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        categoryPlot0.setRangeAxis(1, valueAxis8);
        java.awt.Paint paint10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setRangeGridlinePaint(paint10);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        categoryPlot0.setAnchorValue((double) '#', true);
        java.awt.Paint paint7 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        polarPlot0.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font6 = polarPlot5.getAngleLabelFont();
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke8 = ringPlot7.getSeparatorStroke();
        java.awt.Paint paint9 = ringPlot7.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double11 = rectangleInsets10.getTop();
        ringPlot7.setLabelPadding(rectangleInsets10);
        java.awt.Color color13 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace14 = color13.getColorSpace();
        ringPlot7.setLabelBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("", font6, (java.awt.Paint) color13);
        polarPlot0.setRadiusGridlinePaint((java.awt.Paint) color13);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = polarPlot0.getRenderer();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNull(polarItemRenderer18);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("UnitType.RELATIVE");
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setExplodedPieArea(rectangle2D2);
        double double4 = piePlotState1.getTotal();
        piePlotState1.setTotal((double) (byte) 100);
        java.awt.geom.Rectangle2D rectangle2D7 = piePlotState1.getExplodedPieArea();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D7);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.trimHeight(0.05d);
        double double4 = rectangleInsets0.calculateTopInset((double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.95d) + "'", double2 == (-1.95d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace4 = color3.getColorSpace();
        java.awt.color.ColorSpace colorSpace5 = color3.getColorSpace();
        ringPlot0.setLabelShadowPaint((java.awt.Paint) color3);
        double double7 = ringPlot0.getLabelLinkMargin();
        org.jfree.data.general.DatasetGroup datasetGroup8 = ringPlot0.getDatasetGroup();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.025d + "'", double7 == 0.025d);
        org.junit.Assert.assertNull(datasetGroup8);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        piePlot1.setSimpleLabelOffset(rectangleInsets5);
        java.awt.Paint paint7 = piePlot1.getLabelOutlinePaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator8);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.zoomRange((double) (short) 0, (double) 1L);
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis3D1.setDownArrow(shape6);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape6, "UnitType.RELATIVE");
        java.lang.String str10 = chartEntity9.getToolTipText();
        chartEntity9.setURLText("TextBlockAnchor.BOTTOM_LEFT");
        java.lang.String str13 = chartEntity9.getToolTipText();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UnitType.RELATIVE" + "'", str10.equals("UnitType.RELATIVE"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UnitType.RELATIVE" + "'", str13.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) (byte) 1, (double) 10);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot6);
        flowArrangement5.add((org.jfree.chart.block.Block) legendTitle7, (java.lang.Object) 2);
        flowArrangement5.clear();
        boolean boolean11 = size2D0.equals((java.lang.Object) flowArrangement5);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, (double) (-1.0f));
        org.jfree.data.Range range17 = rectangleConstraint16.getWidthRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType18 = rectangleConstraint16.getWidthConstraintType();
        org.jfree.chart.util.Size2D size2D19 = flowArrangement5.arrange(blockContainer12, graphics2D13, rectangleConstraint16);
        double double20 = size2D19.getWidth();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(lengthConstraintType18);
        org.junit.Assert.assertNotNull(size2D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-1.0d) + "'", double20 == (-1.0d));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot2.getFixedDomainAxisSpace();
        categoryPlot2.clearRangeAxes();
        categoryPlot2.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, true);
        java.awt.RenderingHints renderingHints11 = jFreeChart10.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle12 = jFreeChart10.getLegend();
        jFreeChart10.setTitle("hi!");
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart10.getLegend(8);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertNotNull(renderingHints11);
        org.junit.Assert.assertNotNull(legendTitle12);
        org.junit.Assert.assertNull(legendTitle16);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis3D3.getCategoryStart((-1), (int) ' ', rectangle2D6, rectangleEdge7);
        boolean boolean9 = textTitle1.equals((java.lang.Object) categoryAxis3D3);
        textTitle1.setURLText("XY Plot");
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getSeparatorStroke();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        int int3 = color2.getRed();
        ringPlot0.setSeparatorPaint((java.awt.Paint) color2);
        boolean boolean5 = ringPlot0.getSeparatorsVisible();
        ringPlot0.setLabelGap(0.05d);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets(0.08d, 10.0d, (double) (byte) 10, (double) '#');
        java.awt.Color color13 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder(rectangleInsets12, (java.awt.Paint) color13);
        java.awt.Color color15 = java.awt.Color.MAGENTA;
        java.awt.Color color16 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace17 = color16.getColorSpace();
        java.awt.color.ColorSpace colorSpace18 = color16.getColorSpace();
        float[] floatArray25 = new float[] { (short) 10, 0L, '4', ' ', 10L, 'a' };
        float[] floatArray26 = color15.getComponents(colorSpace18, floatArray25);
        float[] floatArray27 = color13.getRGBColorComponents(floatArray25);
        ringPlot0.setBackgroundPaint((java.awt.Paint) color13);
        ringPlot0.setIgnoreNullValues(false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(colorSpace17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.configureDomainAxes();
        java.awt.Font font4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        categoryPlot0.setNoDataMessageFont(font4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        categoryPlot0.setRangeAxis(1, valueAxis8);
        java.util.List list10 = categoryPlot0.getCategories();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        try {
            categoryPlot0.setDomainAxisLocation(0, axisLocation12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(list10);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        polarPlot0.addCornerTextItem("hi!");
        polarPlot0.removeCornerTextItem("");
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = polarPlot0.getOrientation();
        org.jfree.chart.axis.ValueAxis valueAxis7 = polarPlot0.getAxis();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNull(valueAxis7);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateTopInset((double) (short) 0);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createInsetRectangle(rectangle2D3, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.zoomRange((double) (short) 0, (double) 1L);
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis3D1.setDownArrow(shape6);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape6, "UnitType.RELATIVE");
        java.lang.String str10 = chartEntity9.getToolTipText();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator11 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator12 = null;
        try {
            java.lang.String str13 = chartEntity9.getImageMapAreaTag(toolTipTagFragmentGenerator11, uRLTagFragmentGenerator12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UnitType.RELATIVE" + "'", str10.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainGridlineStroke();
        java.awt.Paint paint2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeCrosshairPaint(paint2);
        xYPlot0.clearRangeMarkers(8);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double9 = numberAxis3D8.getFixedAutoRange();
        numberAxis3D8.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean13 = numberAxis3D8.isPositiveArrowVisible();
        java.lang.Object obj14 = numberAxis3D8.clone();
        java.text.NumberFormat numberFormat15 = null;
        numberAxis3D8.setNumberFormatOverride(numberFormat15);
        numberAxis3D8.setTickLabelsVisible(false);
        java.lang.String str19 = numberAxis3D8.getLabel();
        xYPlot0.setDomainAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis3D8, false);
        org.jfree.chart.plot.Marker marker22 = null;
        org.jfree.chart.util.Layer layer23 = null;
        try {
            boolean boolean24 = xYPlot0.removeDomainMarker(marker22, layer23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.plot.Marker marker5 = null;
        try {
            boolean boolean6 = categoryPlot0.removeRangeMarker(marker5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.zoomRange((double) (short) 0, (double) 1L);
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis3D1.setDownArrow(shape6);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape6, "XY Plot", "Range[97.0,97.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("UnitType.RELATIVE", graphics2D1, 10.0f, (float) 10L, 100.0d, 0.0f, (float) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainGridlineStroke();
        java.awt.Paint paint2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeCrosshairPaint(paint2);
        xYPlot0.clearRangeMarkers(8);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double9 = numberAxis3D8.getFixedAutoRange();
        numberAxis3D8.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean13 = numberAxis3D8.isPositiveArrowVisible();
        java.lang.Object obj14 = numberAxis3D8.clone();
        java.text.NumberFormat numberFormat15 = null;
        numberAxis3D8.setNumberFormatOverride(numberFormat15);
        numberAxis3D8.setTickLabelsVisible(false);
        java.lang.String str19 = numberAxis3D8.getLabel();
        xYPlot0.setDomainAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis3D8, false);
        try {
            java.awt.Paint paint23 = xYPlot0.getQuadrantPaint((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (10) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D2.getCategoryStart((-1), (int) ' ', rectangle2D5, rectangleEdge6);
        java.util.List list8 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.awt.Paint paint9 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot0.getIndexOf(categoryItemRenderer10);
        int int12 = categoryPlot0.getDomainAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot0.getDataset((int) (short) 10);
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNull(axisSpace15);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double6 = numberAxis3D5.getFixedAutoRange();
        double double7 = numberAxis3D5.getUpperBound();
        java.awt.Shape shape8 = numberAxis3D5.getUpArrow();
        numberAxis3D2.setUpArrow(shape8);
        int int10 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D2);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            org.jfree.chart.axis.AxisState axisState17 = numberAxis3D2.draw(graphics2D11, (double) ' ', rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge();
        java.lang.String str9 = rectangleEdge8.toString();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleEdge.LEFT" + "'", str9.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Image image2 = polarPlot1.getBackgroundImage();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        polarPlot1.setRenderer(polarItemRenderer3);
        java.awt.Font font5 = polarPlot1.getAngleLabelFont();
        java.awt.Paint paint6 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer8 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("Range[97.0,97.0]", font5, paint6, (float) 100, textMeasurer8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        categoryAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D7 = xYPlot6.getQuadrantOrigin();
        try {
            polarPlot2.zoomRangeAxes(0.0d, plotRenderingInfo5, point2D7, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(point2D7);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D2.getCategoryStart((-1), (int) ' ', rectangle2D5, rectangleEdge6);
        java.util.List list8 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.util.Collection collection9 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list8);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(collection9);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.zoom(100.0d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke5 = categoryAxis3D4.getTickMarkStroke();
        java.awt.Paint paint6 = categoryAxis3D4.getTickLabelPaint();
        ringPlot0.setLabelPaint(paint6);
        ringPlot0.setIgnoreZeroValues(false);
        ringPlot0.zoom((double) (byte) 100);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        double double3 = numberAxis3D1.getUpperBound();
        java.awt.Shape shape4 = numberAxis3D1.getUpArrow();
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis3D1.setAxisLineStroke(stroke5);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range9 = numberAxis3D8.getRange();
        org.jfree.data.Range range11 = org.jfree.data.Range.shift(range9, (double) (-1.0f));
        numberAxis3D1.setDefaultAutoRange(range9);
        java.text.NumberFormat numberFormat13 = numberAxis3D1.getNumberFormatOverride();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(numberFormat13);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        double double2 = ringPlot0.getMaximumExplodePercent();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            ringPlot0.drawBackground(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        legendTitle1.setHeight((double) (byte) 100);
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = polarPlot4.getLegendItems();
        java.util.Iterator iterator6 = legendItemCollection5.iterator();
        boolean boolean7 = legendTitle1.equals((java.lang.Object) legendItemCollection5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor8);
        java.lang.String str10 = rectangleAnchor8.toString();
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(iterator6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleAnchor.TOP_LEFT" + "'", str10.equals("RectangleAnchor.TOP_LEFT"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D2.getCategoryStart((-1), (int) ' ', rectangle2D5, rectangleEdge6);
        java.util.List list8 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.awt.Paint paint9 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot0.getIndexOf(categoryItemRenderer10);
        int int12 = categoryPlot0.getDomainAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot0.getDataset((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = categoryPlot0.getOrientation();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(plotOrientation15);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.Marker marker3 = null;
        org.jfree.chart.util.Layer layer4 = null;
        try {
            boolean boolean5 = xYPlot0.removeRangeMarker(0, marker3, layer4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Image image2 = polarPlot1.getBackgroundImage();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        polarPlot1.setRenderer(polarItemRenderer3);
        java.awt.Font font5 = polarPlot1.getAngleLabelFont();
        java.awt.Paint paint6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("UnitType.RELATIVE", font5, paint6, 10.0f);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        try {
            float float11 = textFragment8.calculateBaselineOffset(graphics2D9, textAnchor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.setTickMarkInsideLength((float) '4');
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = categoryAxis3D10.getCategoryStart((-1), (int) ' ', rectangle2D13, rectangleEdge14);
        boolean boolean16 = textTitle8.equals((java.lang.Object) categoryAxis3D10);
        textTitle8.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color19 = java.awt.Color.BLACK;
        textTitle8.setBackgroundPaint((java.awt.Paint) color19);
        java.awt.geom.Rectangle2D rectangle2D21 = textTitle8.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.plot.PiePlotState piePlotState23 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo22);
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        piePlotState23.setExplodedPieArea(rectangle2D24);
        double double26 = piePlotState23.getTotal();
        piePlotState23.setLatestAngle((double) (short) -1);
        java.awt.geom.Rectangle2D rectangle2D29 = piePlotState23.getLinkArea();
        org.jfree.chart.entity.EntityCollection entityCollection30 = piePlotState23.getEntityCollection();
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = categoryAxis3D34.getCategoryStart((-1), (int) ' ', rectangle2D37, rectangleEdge38);
        boolean boolean40 = textTitle32.equals((java.lang.Object) categoryAxis3D34);
        textTitle32.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color43 = java.awt.Color.BLACK;
        textTitle32.setBackgroundPaint((java.awt.Paint) color43);
        java.awt.geom.Rectangle2D rectangle2D45 = textTitle32.getBounds();
        piePlotState23.setLinkArea(rectangle2D45);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment47 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment48 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement51 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment47, verticalAlignment48, (double) (byte) 1, (double) 10);
        org.jfree.chart.plot.RingPlot ringPlot52 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot52);
        flowArrangement51.add((org.jfree.chart.block.Block) legendTitle53, (java.lang.Object) 2);
        legendTitle53.setWidth((double) 1L);
        legendTitle53.setHeight(1.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = legendTitle53.getPosition();
        boolean boolean61 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge60);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo62 = null;
        try {
            org.jfree.chart.axis.AxisState axisState63 = numberAxis3D1.draw(graphics2D5, (double) (short) 10, rectangle2D21, rectangle2D45, rectangleEdge60, plotRenderingInfo62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D29);
        org.junit.Assert.assertNull(entityCollection30);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        polarPlot0.addCornerTextItem("hi!");
        java.awt.Stroke stroke4 = polarPlot0.getRadiusGridlineStroke();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.mapDatasetToRangeAxis((int) (byte) 1, (int) '4');
        boolean boolean12 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        categoryPlot0.removeChangeListener(plotChangeListener13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot0.getRendererForDataset(categoryDataset15);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke19 = xYPlot18.getDomainGridlineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        float float22 = ringPlot21.getForegroundAlpha();
        ringPlot21.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke27 = xYPlot26.getDomainGridlineStroke();
        boolean boolean28 = ringPlot21.equals((java.lang.Object) xYPlot26);
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot26.getDomainAxisLocation(255);
        xYPlot18.setRangeAxisLocation((int) (byte) 10, axisLocation30, true);
        try {
            categoryPlot0.setRangeAxisLocation((int) (byte) -1, axisLocation30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(axisLocation30);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        java.awt.Paint paint2 = ringPlot0.getLabelShadowPaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        ringPlot0.setInnerSeparatorExtension((double) (short) 100);
        boolean boolean4 = ringPlot0.getSectionOutlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot5.getDomainAxisLocation(255);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot5.getRendererForDataset(xYDataset10);
        xYPlot5.setRangeCrosshairValue(0.0d);
        org.jfree.chart.plot.Marker marker14 = null;
        try {
            boolean boolean15 = xYPlot5.removeRangeMarker(marker14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(xYItemRenderer11);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getSeparatorStroke();
        double double2 = ringPlot0.getInnerSeparatorExtension();
        java.lang.String str3 = ringPlot0.getPlotType();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = ringPlot0.getLegendLabelURLGenerator();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        float float6 = ringPlot5.getForegroundAlpha();
        ringPlot5.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke11 = xYPlot10.getDomainGridlineStroke();
        boolean boolean12 = ringPlot5.equals((java.lang.Object) xYPlot10);
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot10.getDomainAxisLocation(255);
        java.lang.String str15 = xYPlot10.getPlotType();
        java.awt.Paint paint16 = xYPlot10.getDomainZeroBaselinePaint();
        ringPlot0.setShadowPaint(paint16);
        ringPlot0.setStartAngle((double) 100.0f);
        java.awt.Stroke stroke21 = ringPlot0.getSectionOutlineStroke((java.lang.Comparable) (-1.0f));
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pie Plot" + "'", str3.equals("Pie Plot"));
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "XY Plot" + "'", str15.equals("XY Plot"));
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(stroke21);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        numberAxis3D1.setTickMarkStroke(stroke3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setAutoTickUnitSelection(true, false);
        boolean boolean5 = numberAxis3D1.isTickLabelsVisible();
        java.lang.Object obj6 = numberAxis3D1.clone();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        java.util.List list11 = numberAxis3D1.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double16 = numberAxis3D15.getLowerMargin();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        piePlot18.drawBackgroundImage(graphics2D19, rectangle2D20);
        org.jfree.chart.plot.Plot plot22 = piePlot18.getRootPlot();
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot18.setSectionOutlinePaint((java.lang.Comparable) 1, (java.awt.Paint) color24);
        numberAxis3D15.setLabelPaint((java.awt.Paint) color24);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D31 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        double double36 = categoryAxis3D31.getCategoryStart((-1), (int) ' ', rectangle2D34, rectangleEdge35);
        boolean boolean37 = textTitle29.equals((java.lang.Object) categoryAxis3D31);
        textTitle29.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color40 = java.awt.Color.BLACK;
        textTitle29.setBackgroundPaint((java.awt.Paint) color40);
        java.awt.geom.Rectangle2D rectangle2D42 = textTitle29.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace44 = categoryPlot43.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot45 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke46 = ringPlot45.getSeparatorStroke();
        categoryPlot43.setDomainGridlineStroke(stroke46);
        org.jfree.chart.axis.AxisLocation axisLocation49 = null;
        categoryPlot43.setDomainAxisLocation((int) ' ', axisLocation49);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = categoryPlot43.getRangeAxisEdge();
        double double52 = numberAxis3D15.valueToJava2D(0.0d, rectangle2D42, rectangleEdge51);
        org.jfree.chart.title.TextTitle textTitle54 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D56 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        double double61 = categoryAxis3D56.getCategoryStart((-1), (int) ' ', rectangle2D59, rectangleEdge60);
        boolean boolean62 = textTitle54.equals((java.lang.Object) categoryAxis3D56);
        textTitle54.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color65 = java.awt.Color.BLACK;
        textTitle54.setBackgroundPaint((java.awt.Paint) color65);
        java.awt.geom.Rectangle2D rectangle2D67 = textTitle54.getBounds();
        org.jfree.chart.plot.XYPlot xYPlot68 = new org.jfree.chart.plot.XYPlot();
        xYPlot68.setRangeCrosshairValue((double) (short) 1, true);
        java.awt.Stroke stroke72 = xYPlot68.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.RingPlot ringPlot73 = new org.jfree.chart.plot.RingPlot();
        float float74 = ringPlot73.getForegroundAlpha();
        ringPlot73.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot78 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke79 = xYPlot78.getDomainGridlineStroke();
        boolean boolean80 = ringPlot73.equals((java.lang.Object) xYPlot78);
        org.jfree.chart.axis.AxisLocation axisLocation82 = xYPlot78.getDomainAxisLocation(255);
        xYPlot68.setRangeAxisLocation(axisLocation82, true);
        org.jfree.chart.plot.PolarPlot polarPlot85 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.xy.XYDataset xYDataset86 = null;
        polarPlot85.setDataset(xYDataset86);
        org.jfree.chart.plot.PlotOrientation plotOrientation88 = polarPlot85.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge89 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation82, plotOrientation88);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo90 = null;
        try {
            org.jfree.chart.axis.AxisState axisState91 = numberAxis3D1.draw(graphics2D12, 0.0d, rectangle2D42, rectangle2D67, rectangleEdge89, plotRenderingInfo90);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(plot22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNull(axisSpace44);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertTrue("'" + float74 + "' != '" + 1.0f + "'", float74 == 1.0f);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(axisLocation82);
        org.junit.Assert.assertNotNull(plotOrientation88);
        org.junit.Assert.assertNotNull(rectangleEdge89);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D2.getCategoryStart((-1), (int) ' ', rectangle2D5, rectangleEdge6);
        java.util.List list8 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets(0.08d, 10.0d, (double) (byte) 10, (double) '#');
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder(rectangleInsets15, (java.awt.Paint) color16);
        boolean boolean18 = categoryPlot0.equals((java.lang.Object) blockBorder17);
        java.awt.Paint paint19 = blockBorder17.getPaint();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D1.setTickMarkInsideLength((float) (byte) 1);
        java.awt.Stroke stroke4 = categoryAxis3D1.getTickMarkStroke();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace7 = categoryPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke9 = ringPlot8.getSeparatorStroke();
        categoryPlot6.setDomainGridlineStroke(stroke9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot6.setDomainAxisLocation((int) ' ', axisLocation12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot6.getRangeAxisEdge();
        categoryPlot6.mapDatasetToRangeAxis((int) (byte) 1, (int) '4');
        boolean boolean18 = categoryPlot6.getDrawSharedDomainAxis();
        java.awt.Paint paint19 = categoryPlot6.getRangeCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = null;
        categoryPlot6.datasetChanged(datasetChangeEvent20);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double27 = numberAxis3D26.getFixedAutoRange();
        double double28 = numberAxis3D26.getUpperBound();
        java.awt.Shape shape29 = numberAxis3D26.getUpArrow();
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis3D26.setAxisLineStroke(stroke30);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset23, valueAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis3D26, xYItemRenderer32);
        org.jfree.chart.plot.RingPlot ringPlot34 = new org.jfree.chart.plot.RingPlot();
        float float35 = ringPlot34.getForegroundAlpha();
        ringPlot34.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke40 = xYPlot39.getDomainGridlineStroke();
        boolean boolean41 = ringPlot34.equals((java.lang.Object) xYPlot39);
        org.jfree.chart.axis.AxisLocation axisLocation43 = xYPlot39.getDomainAxisLocation(255);
        xYPlot33.setRangeAxisLocation(axisLocation43, true);
        categoryPlot6.setRangeAxisLocation(0, axisLocation43);
        categoryPlot6.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D52 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        double double57 = categoryAxis3D52.getCategoryStart((-1), (int) ' ', rectangle2D55, rectangleEdge56);
        boolean boolean58 = textTitle50.equals((java.lang.Object) categoryAxis3D52);
        textTitle50.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color61 = java.awt.Color.BLACK;
        textTitle50.setBackgroundPaint((java.awt.Paint) color61);
        java.awt.geom.Rectangle2D rectangle2D63 = textTitle50.getBounds();
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot();
        xYPlot64.setRangeCrosshairValue((double) (short) 1, true);
        java.awt.Stroke stroke68 = xYPlot64.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.RingPlot ringPlot69 = new org.jfree.chart.plot.RingPlot();
        float float70 = ringPlot69.getForegroundAlpha();
        ringPlot69.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot74 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke75 = xYPlot74.getDomainGridlineStroke();
        boolean boolean76 = ringPlot69.equals((java.lang.Object) xYPlot74);
        org.jfree.chart.axis.AxisLocation axisLocation78 = xYPlot74.getDomainAxisLocation(255);
        xYPlot64.setRangeAxisLocation(axisLocation78, true);
        org.jfree.chart.plot.PolarPlot polarPlot81 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.xy.XYDataset xYDataset82 = null;
        polarPlot81.setDataset(xYDataset82);
        org.jfree.chart.plot.PlotOrientation plotOrientation84 = polarPlot81.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge85 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation78, plotOrientation84);
        org.jfree.chart.axis.AxisSpace axisSpace86 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace87 = categoryAxis3D1.reserveSpace(graphics2D5, (org.jfree.chart.plot.Plot) categoryPlot6, rectangle2D63, rectangleEdge85, axisSpace86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(axisSpace7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 1.0f + "'", float35 == 1.0f);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertTrue("'" + float70 + "' != '" + 1.0f + "'", float70 == 1.0f);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(axisLocation78);
        org.junit.Assert.assertNotNull(plotOrientation84);
        org.junit.Assert.assertNotNull(rectangleEdge85);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        legendTitle1.setHeight((double) (byte) 100);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = new org.jfree.chart.LegendItemSource[] {};
        legendTitle1.setSources(legendItemSourceArray4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = null;
        try {
            legendTitle1.setLegendItemGraphicPadding(rectangleInsets6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getSeparatorStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator2);
        java.awt.Paint paint4 = ringPlot0.getLabelOutlinePaint();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double8 = numberAxis3D7.getLowerMargin();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        piePlot10.drawBackgroundImage(graphics2D11, rectangle2D12);
        org.jfree.chart.plot.Plot plot14 = piePlot10.getRootPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot10.setSectionOutlinePaint((java.lang.Comparable) 1, (java.awt.Paint) color16);
        numberAxis3D7.setLabelPaint((java.awt.Paint) color16);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis3D23.getCategoryStart((-1), (int) ' ', rectangle2D26, rectangleEdge27);
        boolean boolean29 = textTitle21.equals((java.lang.Object) categoryAxis3D23);
        textTitle21.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color32 = java.awt.Color.BLACK;
        textTitle21.setBackgroundPaint((java.awt.Paint) color32);
        java.awt.geom.Rectangle2D rectangle2D34 = textTitle21.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace36 = categoryPlot35.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot37 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke38 = ringPlot37.getSeparatorStroke();
        categoryPlot35.setDomainGridlineStroke(stroke38);
        org.jfree.chart.axis.AxisLocation axisLocation41 = null;
        categoryPlot35.setDomainAxisLocation((int) ' ', axisLocation41);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot35.getRangeAxisEdge();
        double double44 = numberAxis3D7.valueToJava2D(0.0d, rectangle2D34, rectangleEdge43);
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D46 = xYPlot45.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState47 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        try {
            ringPlot0.draw(graphics2D5, rectangle2D34, point2D46, plotState47, plotRenderingInfo48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(plot14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(axisSpace36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(point2D46);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getSeparatorStroke();
        java.awt.Paint paint2 = ringPlot0.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double4 = rectangleInsets3.getTop();
        ringPlot0.setLabelPadding(rectangleInsets3);
        java.awt.Color color6 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace7 = color6.getColorSpace();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color6);
        java.lang.String str9 = ringPlot0.getPlotType();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(colorSpace7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pie Plot" + "'", str9.equals("Pie Plot"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryStart((-1), (int) ' ', rectangle2D4, rectangleEdge5);
        java.awt.Paint paint7 = categoryAxis3D1.getLabelPaint();
        float float8 = categoryAxis3D1.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D2.getCategoryStart((-1), (int) ' ', rectangle2D5, rectangleEdge6);
        java.util.List list8 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.awt.Paint paint9 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot0.getRendererForDataset(categoryDataset10);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemRenderer11);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot2.getFixedDomainAxisSpace();
        categoryPlot2.clearRangeAxes();
        categoryPlot2.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, true);
        java.awt.RenderingHints renderingHints11 = jFreeChart10.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle12 = jFreeChart10.getLegend();
        jFreeChart10.setTitle("hi!");
        jFreeChart10.setBorderVisible(true);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertNotNull(renderingHints11);
        org.junit.Assert.assertNotNull(legendTitle12);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        int int7 = categoryPlot0.getDatasetCount();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.lang.String str2 = piePlot3D1.getPlotType();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie 3D Plot" + "'", str2.equals("Pie 3D Plot"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getSeparatorStroke();
        java.awt.Paint paint2 = ringPlot0.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLabelGenerator();
        boolean boolean4 = ringPlot0.getLabelLinksVisible();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.trimWidth((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 98.0d + "'", double2 == 98.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = legendTitle1.getVerticalAlignment();
        double double3 = legendTitle1.getHeight();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.plot.PiePlotState piePlotState6 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo5);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlotState6.setExplodedPieArea(rectangle2D7);
        double double9 = piePlotState6.getTotal();
        piePlotState6.setLatestAngle((double) (short) -1);
        java.awt.geom.Rectangle2D rectangle2D12 = piePlotState6.getLinkArea();
        org.jfree.chart.entity.EntityCollection entityCollection13 = piePlotState6.getEntityCollection();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis3D17.getCategoryStart((-1), (int) ' ', rectangle2D20, rectangleEdge21);
        boolean boolean23 = textTitle15.equals((java.lang.Object) categoryAxis3D17);
        textTitle15.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color26 = java.awt.Color.BLACK;
        textTitle15.setBackgroundPaint((java.awt.Paint) color26);
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle15.getBounds();
        piePlotState6.setLinkArea(rectangle2D28);
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        xYPlot30.setRangeCrosshairValue((double) (short) 1, true);
        java.awt.Stroke stroke34 = xYPlot30.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.RingPlot ringPlot35 = new org.jfree.chart.plot.RingPlot();
        float float36 = ringPlot35.getForegroundAlpha();
        ringPlot35.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke41 = xYPlot40.getDomainGridlineStroke();
        boolean boolean42 = ringPlot35.equals((java.lang.Object) xYPlot40);
        org.jfree.chart.axis.AxisLocation axisLocation44 = xYPlot40.getDomainAxisLocation(255);
        xYPlot30.setRangeAxisLocation(axisLocation44, true);
        org.jfree.chart.plot.PolarPlot polarPlot47 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.xy.XYDataset xYDataset48 = null;
        polarPlot47.setDataset(xYDataset48);
        org.jfree.chart.plot.PlotOrientation plotOrientation50 = polarPlot47.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation44, plotOrientation50);
        try {
            java.lang.Object obj52 = legendTitle1.draw(graphics2D4, rectangle2D28, (java.lang.Object) plotOrientation50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D12);
        org.junit.Assert.assertNull(entityCollection13);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 1.0f + "'", float36 == 1.0f);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(plotOrientation50);
        org.junit.Assert.assertNotNull(rectangleEdge51);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        blockParams0.setTranslateY(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.Range range3 = new org.jfree.data.Range((-1.0d), 100.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, (double) (-1.0f));
        org.jfree.data.Range range7 = rectangleConstraint6.getWidthRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = rectangleConstraint6.getWidthConstraintType();
        org.jfree.data.Range range10 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, (double) (-1.0f));
        org.jfree.data.Range range14 = rectangleConstraint13.getWidthRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint13.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) ' ', range3, lengthConstraintType8, (double) (byte) 0, range10, lengthConstraintType15);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        ringPlot17.zoom(100.0d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D21 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke22 = categoryAxis3D21.getTickMarkStroke();
        java.awt.Paint paint23 = categoryAxis3D21.getTickLabelPaint();
        ringPlot17.setLabelPaint(paint23);
        java.awt.Paint paint25 = ringPlot17.getBaseSectionOutlinePaint();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        ringPlot17.setBaseSectionOutlinePaint((java.awt.Paint) color26);
        boolean boolean28 = lengthConstraintType15.equals((java.lang.Object) ringPlot17);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        double double2 = textTitle1.getContentYOffset();
        java.lang.String str3 = textTitle1.getURLText();
        java.awt.Paint paint4 = textTitle1.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.zoomRange((double) (short) 0, (double) 1L);
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis3D1.setDownArrow(shape6);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape6, "UnitType.RELATIVE");
        java.lang.String str10 = chartEntity9.getToolTipText();
        chartEntity9.setURLText("TextBlockAnchor.BOTTOM_LEFT");
        chartEntity9.setToolTipText("RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=-1.0]");
        java.lang.String str15 = chartEntity9.getURLText();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UnitType.RELATIVE" + "'", str10.equals("UnitType.RELATIVE"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TextBlockAnchor.BOTTOM_LEFT" + "'", str15.equals("TextBlockAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Paint paint2 = textTitle1.getBackgroundPaint();
        java.lang.Object obj3 = textTitle1.clone();
        textTitle1.setExpandToFitSpace(true);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.FlowArrangement flowArrangement1 = new org.jfree.chart.block.FlowArrangement();
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement1);
        java.util.List list3 = blockContainer0.getBlocks();
        boolean boolean4 = blockContainer0.isEmpty();
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.data.Range range4 = org.jfree.data.Range.shift(range2, (double) (-1.0f));
        double double5 = range4.getUpperBound();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("Range[97.0,97.0]", graphics2D1, 10.0f, (float) '4', textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.resizeRange(10.0d, (double) (short) 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double1 = rectangleInsets0.getTop();
        double double2 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 1, (double) 10);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot5);
        flowArrangement4.add((org.jfree.chart.block.Block) legendTitle6, (java.lang.Object) 2);
        legendTitle6.setWidth((double) 1L);
        legendTitle6.setHeight(1.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = legendTitle6.getPosition();
        boolean boolean14 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge13);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairValue((double) (short) 1, true);
        java.awt.Stroke stroke4 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        float float6 = ringPlot5.getForegroundAlpha();
        ringPlot5.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke11 = xYPlot10.getDomainGridlineStroke();
        boolean boolean12 = ringPlot5.equals((java.lang.Object) xYPlot10);
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot10.getDomainAxisLocation(255);
        xYPlot0.setRangeAxisLocation(axisLocation14, true);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        xYPlot0.datasetChanged(datasetChangeEvent17);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.plot.Plot plot9 = piePlot5.getRootPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = ringPlot0.initialise(graphics2D2, rectangle2D3, piePlot5, (java.lang.Integer) 10, plotRenderingInfo11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        ringPlot0.markerChanged(markerChangeEvent13);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator15 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator15);
        java.awt.Font font18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot19.getFixedDomainAxisSpace();
        categoryPlot19.clearRangeAxes();
        categoryPlot19.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray24 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer23 };
        categoryPlot19.setRenderers(categoryItemRendererArray24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("Pie Plot", font18, (org.jfree.chart.plot.Plot) categoryPlot19, true);
        java.awt.RenderingHints renderingHints28 = jFreeChart27.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle29 = jFreeChart27.getLegend();
        boolean boolean30 = ringPlot0.equals((java.lang.Object) legendTitle29);
        org.jfree.data.general.PieDataset pieDataset32 = null;
        org.jfree.chart.plot.PiePlot piePlot33 = new org.jfree.chart.plot.PiePlot(pieDataset32);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        piePlot33.drawBackgroundImage(graphics2D34, rectangle2D35);
        org.jfree.chart.plot.Plot plot37 = piePlot33.getRootPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D40 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D40.setMaximumCategoryLabelWidthRatio(10.0f);
        java.util.Date date43 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color44 = java.awt.Color.BLACK;
        categoryAxis3D40.setTickLabelPaint((java.lang.Comparable) date43, (java.awt.Paint) color44);
        piePlot33.setSectionPaint((java.lang.Comparable) "ThreadContext", (java.awt.Paint) color44);
        java.lang.String str47 = color44.toString();
        ringPlot0.setSectionOutlinePaint((java.lang.Comparable) 0L, (java.awt.Paint) color44);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertNotNull(categoryItemRendererArray24);
        org.junit.Assert.assertNotNull(renderingHints28);
        org.junit.Assert.assertNotNull(legendTitle29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(plot37);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "java.awt.Color[r=0,g=0,b=0]" + "'", str47.equals("java.awt.Color[r=0,g=0,b=0]"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainZeroBaselineStroke();
        double double2 = xYPlot0.getDomainCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceText("");
        java.lang.Object obj3 = null;
        boolean boolean4 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) projectInfo0, obj3);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        boolean boolean3 = numberAxis3D1.isVerticalTickLabels();
        double double4 = numberAxis3D1.getUpperBound();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateLeftInset((double) 1.0f);
        double double4 = rectangleInsets0.calculateRightOutset(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Multiple Pie Plot", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getInfo();
        basicProjectInfo0.setInfo("Pie Plot");
        org.jfree.chart.ui.Library[] libraryArray4 = basicProjectInfo0.getLibraries();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(libraryArray4);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double6 = numberAxis3D5.getFixedAutoRange();
        double double7 = numberAxis3D5.getUpperBound();
        java.awt.Shape shape8 = numberAxis3D5.getUpArrow();
        numberAxis3D2.setUpArrow(shape8);
        int int10 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D2);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        int int12 = xYPlot0.indexOf(xYDataset11);
        java.awt.Paint paint13 = xYPlot0.getDomainTickBandPaint();
        java.awt.Stroke stroke14 = xYPlot0.getDomainZeroBaselineStroke();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot5.getDomainAxisLocation(255);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation10 = null;
        try {
            boolean boolean11 = xYPlot5.removeAnnotation(xYAnnotation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textBlock0.getLineAlignment();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.setAutoTickUnitSelection(true, false);
        boolean boolean7 = numberAxis3D3.isTickLabelsVisible();
        boolean boolean8 = horizontalAlignment1.equals((java.lang.Object) boolean7);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.data.Range range4 = org.jfree.data.Range.shift(range2, (double) (-1.0f));
        boolean boolean7 = range2.intersects((double) (short) -1, (double) (short) -1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        double double2 = textTitle1.getContentYOffset();
        java.lang.String str3 = textTitle1.getURLText();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot4);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = ringPlot4.getLabelDistributor();
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace8 = color7.getColorSpace();
        java.awt.color.ColorSpace colorSpace9 = color7.getColorSpace();
        ringPlot4.setLabelShadowPaint((java.awt.Paint) color7);
        textTitle1.setBackgroundPaint((java.awt.Paint) color7);
        int int12 = color7.getAlpha();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(colorSpace8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.awt.Paint paint0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainGridlineStroke();
        java.awt.Paint paint2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeCrosshairPaint(paint2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double6 = numberAxis3D5.getFixedAutoRange();
        double double7 = numberAxis3D5.getUpperBound();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D5.getLabelInsets();
        xYPlot0.setAxisOffset(rectangleInsets8);
        org.jfree.chart.plot.Marker marker10 = null;
        try {
            xYPlot0.addRangeMarker(marker10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke2 = categoryAxis3D1.getTickMarkStroke();
        java.awt.Paint paint3 = categoryAxis3D1.getTickLabelPaint();
        java.lang.String str5 = categoryAxis3D1.getCategoryLabelToolTip((java.lang.Comparable) "RectangleEdge.LEFT");
        categoryAxis3D1.clearCategoryLabelToolTips();
        categoryAxis3D1.setCategoryMargin(0.4d);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getInfo();
        org.jfree.chart.ui.Library[] libraryArray2 = basicProjectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo8 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "hi!", "hi!");
        basicProjectInfo8.setCopyright("hi!");
        java.lang.String str11 = basicProjectInfo8.getName();
        basicProjectInfo8.setVersion("Pie Plot");
        basicProjectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo8);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(libraryArray2);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=-1.0]", graphics2D1, 0.0f, (float) (short) 10, 98.0d, 10.0f, (float) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setAutoTickUnitSelection(true, false);
        boolean boolean5 = numberAxis3D1.isTickLabelsVisible();
        java.lang.Object obj6 = numberAxis3D1.clone();
        double double7 = numberAxis3D1.getUpperMargin();
        boolean boolean8 = numberAxis3D1.isVerticalTickLabels();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairValue((double) (short) 1, true);
        java.awt.Stroke stroke4 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        float float6 = ringPlot5.getForegroundAlpha();
        ringPlot5.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke11 = xYPlot10.getDomainGridlineStroke();
        boolean boolean12 = ringPlot5.equals((java.lang.Object) xYPlot10);
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot10.getDomainAxisLocation(255);
        xYPlot0.setRangeAxisLocation(axisLocation14, true);
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        polarPlot17.setDataset(xYDataset18);
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = polarPlot17.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation14, plotOrientation20);
        java.lang.Class<?> wildcardClass22 = plotOrientation20.getClass();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis3D6.getCategoryStart((-1), (int) ' ', rectangle2D9, rectangleEdge10);
        java.util.List list12 = categoryPlot4.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D6);
        java.awt.Paint paint13 = categoryPlot4.getRangeGridlinePaint();
        categoryPlot0.setRangeCrosshairPaint(paint13);
        categoryPlot0.mapDatasetToRangeAxis((int) (byte) 1, (int) (short) -1);
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace18);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        boolean boolean11 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot0.getRangeAxis((int) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        try {
            categoryPlot0.setRenderer((int) (short) -1, categoryItemRenderer15, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(valueAxis13);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot0.getDomainMarkers(layer6);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(collection7);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("UnitType.RELATIVE", graphics2D1, (double) 100L, (float) 0, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot2.getFixedDomainAxisSpace();
        categoryPlot2.clearRangeAxes();
        categoryPlot2.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, true);
        jFreeChart10.setBorderVisible(false);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double16 = numberAxis3D15.getLowerMargin();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        piePlot18.drawBackgroundImage(graphics2D19, rectangle2D20);
        org.jfree.chart.plot.Plot plot22 = piePlot18.getRootPlot();
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot18.setSectionOutlinePaint((java.lang.Comparable) 1, (java.awt.Paint) color24);
        numberAxis3D15.setLabelPaint((java.awt.Paint) color24);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D31 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        double double36 = categoryAxis3D31.getCategoryStart((-1), (int) ' ', rectangle2D34, rectangleEdge35);
        boolean boolean37 = textTitle29.equals((java.lang.Object) categoryAxis3D31);
        textTitle29.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color40 = java.awt.Color.BLACK;
        textTitle29.setBackgroundPaint((java.awt.Paint) color40);
        java.awt.geom.Rectangle2D rectangle2D42 = textTitle29.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace44 = categoryPlot43.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot45 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke46 = ringPlot45.getSeparatorStroke();
        categoryPlot43.setDomainGridlineStroke(stroke46);
        org.jfree.chart.axis.AxisLocation axisLocation49 = null;
        categoryPlot43.setDomainAxisLocation((int) ' ', axisLocation49);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = categoryPlot43.getRangeAxisEdge();
        double double52 = numberAxis3D15.valueToJava2D(0.0d, rectangle2D42, rectangleEdge51);
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D54 = xYPlot53.getQuadrantOrigin();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo55 = null;
        try {
            jFreeChart10.draw(graphics2D13, rectangle2D42, point2D54, chartRenderingInfo55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(plot22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNull(axisSpace44);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(point2D54);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.Range range3 = new org.jfree.data.Range((-1.0d), 100.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, (double) (-1.0f));
        org.jfree.data.Range range7 = rectangleConstraint6.getWidthRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = rectangleConstraint6.getWidthConstraintType();
        org.jfree.data.Range range10 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, (double) (-1.0f));
        org.jfree.data.Range range14 = rectangleConstraint13.getWidthRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint13.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) ' ', range3, lengthConstraintType8, (double) (byte) 0, range10, lengthConstraintType15);
        double double18 = range10.constrain(1.0E-5d);
        org.jfree.data.Range range21 = org.jfree.data.Range.shift(range10, (double) 10.0f, true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0E-5d + "'", double18 == 1.0E-5d);
        org.junit.Assert.assertNotNull(range21);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomRangeAxes(10.0d, plotRenderingInfo2, point2D3, false);
        boolean boolean6 = xYPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomRangeAxes(10.0d, plotRenderingInfo2, point2D3, false);
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        try {
            xYPlot0.setQuadrantPaint((int) '4', paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (52) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) boolean7);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        categoryAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot2);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke6 = categoryAxis3D5.getTickMarkStroke();
        int int7 = categoryAxis3D5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = categoryAxis3D5.getCategoryLabelPositions();
        categoryAxis3D1.setCategoryLabelPositions(categoryLabelPositions8);
        boolean boolean10 = categoryAxis3D1.isAxisLineVisible();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) 2.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot5.getDomainAxisLocation(255);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        try {
            xYPlot5.addDomainMarker((int) (byte) 0, marker11, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.TOP_RIGHT" + "'", str1.equals("RectangleAnchor.TOP_RIGHT"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.08d, 10.0d, (double) (byte) 10, (double) '#');
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets4, (java.awt.Paint) color5);
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        java.awt.color.ColorSpace colorSpace10 = color8.getColorSpace();
        float[] floatArray17 = new float[] { (short) 10, 0L, '4', ' ', 10L, 'a' };
        float[] floatArray18 = color7.getComponents(colorSpace10, floatArray17);
        float[] floatArray19 = color5.getRGBColorComponents(floatArray17);
        int int20 = color5.getRGB();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-4144960) + "'", int20 == (-4144960));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot2.getFixedDomainAxisSpace();
        categoryPlot2.clearRangeAxes();
        categoryPlot2.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, true);
        java.awt.RenderingHints renderingHints11 = jFreeChart10.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle12 = jFreeChart10.getLegend();
        jFreeChart10.setTitle("hi!");
        java.awt.Stroke stroke15 = jFreeChart10.getBorderStroke();
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertNotNull(renderingHints11);
        org.junit.Assert.assertNotNull(legendTitle12);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font3 = categoryAxis3D2.getLabelFont();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) color4, (float) (byte) 100);
        java.awt.Color color7 = color4.darker();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, (double) (-1.0f));
        org.jfree.data.Range range3 = rectangleConstraint2.getHeightRange();
        java.lang.String str4 = rectangleConstraint2.toString();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=-1.0]" + "'", str4.equals("RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=-1.0]"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.setLabel("Size2D[width=0.0, height=0.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        categoryPlot0.clearDomainMarkers((int) (byte) 10);
        categoryPlot0.configureDomainAxes();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double4 = numberAxis3D3.getFixedAutoRange();
        double double5 = numberAxis3D3.getUpperBound();
        java.awt.Font font6 = numberAxis3D3.getTickLabelFont();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis3D3.java2DToValue((double) 10L, rectangle2D8, rectangleEdge9);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        try {
            categoryPlot12.handleClick((int) (byte) 10, (int) (byte) -1, plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.POSITIVE_INFINITY + "'", double10 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("XY Plot");
        categoryAxis3D1.setLabelToolTip("ThreadContext");
        categoryAxis3D1.setLowerMargin(0.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.plot.Plot plot9 = piePlot5.getRootPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = ringPlot0.initialise(graphics2D2, rectangle2D3, piePlot5, (java.lang.Integer) 10, plotRenderingInfo11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        ringPlot0.markerChanged(markerChangeEvent13);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator15 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator15);
        ringPlot0.setIgnoreZeroValues(false);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(piePlotState12);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        legendTitle1.setHeight((double) (byte) 100);
        org.jfree.chart.block.BlockContainer blockContainer4 = legendTitle1.getItemContainer();
        java.util.List list5 = blockContainer4.getBlocks();
        org.junit.Assert.assertNotNull(blockContainer4);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean6 = numberAxis3D1.isPositiveArrowVisible();
        numberAxis3D1.centerRange(0.2d);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        double double13 = rectangleInsets11.trimHeight(0.05d);
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis3D17.getCategoryStart((-1), (int) ' ', rectangle2D20, rectangleEdge21);
        boolean boolean23 = textTitle15.equals((java.lang.Object) categoryAxis3D17);
        textTitle15.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color26 = java.awt.Color.BLACK;
        textTitle15.setBackgroundPaint((java.awt.Paint) color26);
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle15.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType29 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets11.createAdjustedRectangle(rectangle2D28, lengthAdjustmentType29, lengthAdjustmentType30);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double34 = numberAxis3D33.getLowerMargin();
        org.jfree.data.general.PieDataset pieDataset35 = null;
        org.jfree.chart.plot.PiePlot piePlot36 = new org.jfree.chart.plot.PiePlot(pieDataset35);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        piePlot36.drawBackgroundImage(graphics2D37, rectangle2D38);
        org.jfree.chart.plot.Plot plot40 = piePlot36.getRootPlot();
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot36.setSectionOutlinePaint((java.lang.Comparable) 1, (java.awt.Paint) color42);
        numberAxis3D33.setLabelPaint((java.awt.Paint) color42);
        org.jfree.chart.title.TextTitle textTitle47 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D49 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        double double54 = categoryAxis3D49.getCategoryStart((-1), (int) ' ', rectangle2D52, rectangleEdge53);
        boolean boolean55 = textTitle47.equals((java.lang.Object) categoryAxis3D49);
        textTitle47.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color58 = java.awt.Color.BLACK;
        textTitle47.setBackgroundPaint((java.awt.Paint) color58);
        java.awt.geom.Rectangle2D rectangle2D60 = textTitle47.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace62 = categoryPlot61.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot63 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke64 = ringPlot63.getSeparatorStroke();
        categoryPlot61.setDomainGridlineStroke(stroke64);
        org.jfree.chart.axis.AxisLocation axisLocation67 = null;
        categoryPlot61.setDomainAxisLocation((int) ' ', axisLocation67);
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = categoryPlot61.getRangeAxisEdge();
        double double70 = numberAxis3D33.valueToJava2D(0.0d, rectangle2D60, rectangleEdge69);
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo72 = null;
        try {
            org.jfree.chart.axis.AxisState axisState73 = numberAxis3D1.draw(graphics2D9, 0.0d, rectangle2D31, rectangle2D60, rectangleEdge71, plotRenderingInfo72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.95d) + "'", double13 == (-1.95d));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
        org.junit.Assert.assertNotNull(plot40);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNull(axisSpace62);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(rectangleEdge69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range(98.0d, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (98.0) <= upper (10.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str1.equals("Rotation.ANTICLOCKWISE"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "ThreadContext");
        java.lang.String str3 = contributor2.getEmail();
        java.lang.String str4 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ThreadContext" + "'", str3.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot1.setShadowPaint((java.awt.Paint) color5);
        java.awt.Paint paint7 = piePlot1.getLabelOutlinePaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = piePlot1.getToolTipGenerator();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        java.awt.Paint paint4 = ringPlot2.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double6 = rectangleInsets5.getTop();
        ringPlot2.setLabelPadding(rectangleInsets5);
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        ringPlot2.setLabelBackgroundPaint((java.awt.Paint) color8);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color8);
        org.jfree.chart.axis.AxisLocation axisLocation13 = null;
        categoryPlot0.setRangeAxisLocation(100, axisLocation13, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        try {
            boolean boolean20 = categoryPlot0.removeRangeMarker(10, marker18, layer19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertNull(categoryItemRenderer16);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "VerticalAlignment.CENTER", "hi!", "hi!");
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font4 = categoryAxis3D3.getLabelFont();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("", font4, (java.awt.Paint) color5, (float) (byte) 100);
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("ThreadContext", font4);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            textFragment8.draw(graphics2D9, (float) 100, (float) 500, textAnchor12, (float) 8, (float) 8, 0.08d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainZeroBaselineStroke();
        double double2 = xYPlot0.getDomainCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset3 = xYPlot0.getDataset();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(xYDataset3);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        piePlot1.setSimpleLabelOffset(rectangleInsets5);
        java.awt.Stroke stroke7 = piePlot1.getOutlineStroke();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Image image1 = polarPlot0.getBackgroundImage();
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = polarPlot0.getOrientation();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        double double5 = piePlot4.getMinimumArcAngleToDraw();
        boolean boolean6 = plotOrientation2.equals((java.lang.Object) double5);
        boolean boolean8 = plotOrientation2.equals((java.lang.Object) (byte) 0);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNotNull(plotOrientation2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-5d + "'", double5 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setDarkerSides(true);
        piePlot3D0.setDarkerSides(false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("TextBlockAnchor.BOTTOM_LEFT", font1);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D2.getCategoryStart((-1), (int) ' ', rectangle2D5, rectangleEdge6);
        java.util.List list8 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        categoryAxis3D2.setTickMarkInsideLength((float) ' ');
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "hi!", "hi!");
        basicProjectInfo5.setCopyright("hi!");
        java.lang.String str8 = basicProjectInfo5.getName();
        java.lang.String str9 = basicProjectInfo5.getLicenceName();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke6 = categoryAxis3D5.getTickMarkStroke();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] { stroke2, stroke3, stroke6, stroke7, stroke8 };
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke12 = categoryAxis3D11.getTickMarkStroke();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke16 = categoryAxis3D15.getTickMarkStroke();
        java.awt.Stroke stroke17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] { stroke12, stroke13, stroke16, stroke17 };
        java.awt.Shape shape19 = null;
        java.awt.Shape[] shapeArray20 = new java.awt.Shape[] { shape19 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray9, strokeArray18, shapeArray20);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis3D23.getCategoryStart((-1), (int) ' ', rectangle2D26, rectangleEdge27);
        boolean boolean29 = defaultDrawingSupplier21.equals((java.lang.Object) rectangleEdge27);
        java.awt.Paint paint30 = defaultDrawingSupplier21.getNextFillPaint();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(shapeArray20);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font3 = categoryAxis3D2.getLabelFont();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font3);
        org.jfree.chart.text.TextFragment textFragment5 = null;
        textLine4.addFragment(textFragment5);
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Image image9 = polarPlot8.getBackgroundImage();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        polarPlot8.setRenderer(polarItemRenderer10);
        java.awt.Font font12 = polarPlot8.getAngleLabelFont();
        java.awt.Paint paint13 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("UnitType.RELATIVE", font12, paint13, 10.0f);
        textLine4.addFragment(textFragment15);
        java.awt.Graphics2D graphics2D17 = null;
        try {
            org.jfree.chart.util.Size2D size2D18 = textLine4.calculateDimensions(graphics2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(image9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.plot.Plot plot9 = piePlot5.getRootPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = ringPlot0.initialise(graphics2D2, rectangle2D3, piePlot5, (java.lang.Integer) 10, plotRenderingInfo11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        ringPlot0.markerChanged(markerChangeEvent13);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator15 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator15);
        ringPlot0.setOutlineVisible(false);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(piePlotState12);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getSeparatorStroke();
        double double2 = ringPlot0.getInnerSeparatorExtension();
        java.lang.String str3 = ringPlot0.getPlotType();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = ringPlot0.getLegendLabelURLGenerator();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        float float6 = ringPlot5.getForegroundAlpha();
        ringPlot5.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke11 = xYPlot10.getDomainGridlineStroke();
        boolean boolean12 = ringPlot5.equals((java.lang.Object) xYPlot10);
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot10.getDomainAxisLocation(255);
        java.lang.String str15 = xYPlot10.getPlotType();
        java.awt.Paint paint16 = xYPlot10.getDomainZeroBaselinePaint();
        ringPlot0.setShadowPaint(paint16);
        double double18 = ringPlot0.getInnerSeparatorExtension();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pie Plot" + "'", str3.equals("Pie Plot"));
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "XY Plot" + "'", str15.equals("XY Plot"));
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setExplodedPieArea(rectangle2D2);
        double double4 = piePlotState1.getTotal();
        double double5 = piePlotState1.getTotal();
        double double6 = piePlotState1.getPieCenterX();
        piePlotState1.setPieWRadius((double) (-1L));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = polarPlot0.getLegendItems();
        int int2 = legendItemCollection1.getItemCount();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setDarkerSides(true);
        piePlot3D0.setDepthFactor((double) 3);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double double0 = org.jfree.chart.plot.PolarPlot.DEFAULT_ANGLE_TICK_UNIT_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 45.0d + "'", double0 == 45.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        legendTitle1.setHeight((double) (byte) 100);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = new org.jfree.chart.LegendItemSource[] {};
        legendTitle1.setSources(legendItemSourceArray4);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray6 = null;
        try {
            legendTitle1.setSources(legendItemSourceArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'sources' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "ThreadContext");
        java.lang.String str3 = contributor2.getEmail();
        java.lang.String str4 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ThreadContext" + "'", str3.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ThreadContext" + "'", str4.equals("ThreadContext"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        polarPlot0.addCornerTextItem("hi!");
        polarPlot0.removeCornerTextItem("");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D10 = xYPlot9.getQuadrantOrigin();
        try {
            polarPlot0.zoomRangeAxes((double) 100.0f, 2.0d, plotRenderingInfo8, point2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(point2D10);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        categoryPlot4.clearRangeAxes();
        categoryPlot4.configureDomainAxes();
        java.awt.Font font8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        categoryPlot4.setNoDataMessageFont(font8);
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("Rotation.ANTICLOCKWISE", font8);
        ringPlot0.setLabelFont(font8);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot0.getDomainMarkers(layer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset(10);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNull(categoryAxis7);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = null;
        java.awt.Paint paint1 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        try {
            org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setAutoTickUnitSelection(true, false);
        boolean boolean5 = numberAxis3D1.isTickLabelsVisible();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range8 = numberAxis3D7.getRange();
        boolean boolean10 = range8.contains((double) (byte) 100);
        numberAxis3D1.setDefaultAutoRange(range8);
        numberAxis3D1.setLabelAngle(97.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) (short) 0);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getHeightConstraintType();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("{0}");
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D2.getCategoryStart((-1), (int) ' ', rectangle2D5, rectangleEdge6);
        java.util.List list8 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot12.getFixedDomainAxisSpace();
        categoryPlot12.clearRangeAxes();
        categoryPlot12.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray17 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer16 };
        categoryPlot12.setRenderers(categoryItemRendererArray17);
        categoryPlot0.setRenderers(categoryItemRendererArray17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot0.getRenderer();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNotNull(categoryItemRendererArray17);
        org.junit.Assert.assertNull(categoryItemRenderer20);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("Pie 3D Plot");
        java.lang.String str2 = numberAxis3D1.getLabelURL();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) (-1L), textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = null;
        textBlock5.addLine(textLine6);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font11 = categoryAxis3D10.getLabelFont();
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        textBlock5.addLine("Pie Plot", font11, (java.awt.Paint) color12);
        java.awt.Graphics2D graphics2D14 = null;
        try {
            org.jfree.chart.util.Size2D size2D15 = textBlock5.calculateDimensions(graphics2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean6 = numberAxis3D1.isPositiveArrowVisible();
        java.lang.Object obj7 = numberAxis3D1.clone();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double12 = numberAxis3D11.getLowerMargin();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        piePlot14.drawBackgroundImage(graphics2D15, rectangle2D16);
        org.jfree.chart.plot.Plot plot18 = piePlot14.getRootPlot();
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot14.setSectionOutlinePaint((java.lang.Comparable) 1, (java.awt.Paint) color20);
        numberAxis3D11.setLabelPaint((java.awt.Paint) color20);
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D27 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = categoryAxis3D27.getCategoryStart((-1), (int) ' ', rectangle2D30, rectangleEdge31);
        boolean boolean33 = textTitle25.equals((java.lang.Object) categoryAxis3D27);
        textTitle25.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color36 = java.awt.Color.BLACK;
        textTitle25.setBackgroundPaint((java.awt.Paint) color36);
        java.awt.geom.Rectangle2D rectangle2D38 = textTitle25.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace40 = categoryPlot39.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot41 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke42 = ringPlot41.getSeparatorStroke();
        categoryPlot39.setDomainGridlineStroke(stroke42);
        org.jfree.chart.axis.AxisLocation axisLocation45 = null;
        categoryPlot39.setDomainAxisLocation((int) ' ', axisLocation45);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot39.getRangeAxisEdge();
        double double48 = numberAxis3D11.valueToJava2D(0.0d, rectangle2D38, rectangleEdge47);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D50 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double51 = numberAxis3D50.getFixedAutoRange();
        numberAxis3D50.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean55 = numberAxis3D50.isPositiveArrowVisible();
        numberAxis3D50.centerRange(0.2d);
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D61 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = null;
        double double66 = categoryAxis3D61.getCategoryStart((-1), (int) ' ', rectangle2D64, rectangleEdge65);
        boolean boolean67 = textTitle59.equals((java.lang.Object) categoryAxis3D61);
        textTitle59.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color70 = java.awt.Color.BLACK;
        textTitle59.setBackgroundPaint((java.awt.Paint) color70);
        java.awt.geom.Rectangle2D rectangle2D72 = textTitle59.getBounds();
        numberAxis3D50.setLeftArrow((java.awt.Shape) rectangle2D72);
        org.jfree.chart.plot.CategoryPlot categoryPlot74 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace75 = categoryPlot74.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot76 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke77 = ringPlot76.getSeparatorStroke();
        categoryPlot74.setDomainGridlineStroke(stroke77);
        org.jfree.chart.axis.AxisLocation axisLocation80 = null;
        categoryPlot74.setDomainAxisLocation((int) ' ', axisLocation80);
        org.jfree.chart.util.RectangleEdge rectangleEdge82 = categoryPlot74.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo83 = null;
        try {
            org.jfree.chart.axis.AxisState axisState84 = numberAxis3D1.draw(graphics2D8, Double.POSITIVE_INFINITY, rectangle2D38, rectangle2D72, rectangleEdge82, plotRenderingInfo83);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(plot18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNull(axisSpace40);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNotNull(rectangle2D72);
        org.junit.Assert.assertNull(axisSpace75);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(rectangleEdge82);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        double double3 = numberAxis3D1.getUpperBound();
        java.awt.Shape shape4 = numberAxis3D1.getUpArrow();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, 0, (int) (byte) 10, (java.lang.Comparable) 1.0d, "ThreadContext", "hi!");
        pieSectionEntity11.setSectionKey((java.lang.Comparable) (short) 1);
        org.jfree.data.general.PieDataset pieDataset14 = pieSectionEntity11.getDataset();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(pieDataset14);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot5.getDomainAxisLocation(255);
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke11 = ringPlot10.getSeparatorStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = null;
        ringPlot10.setLegendLabelURLGenerator(pieURLGenerator12);
        java.awt.Paint paint14 = ringPlot10.getLabelOutlinePaint();
        xYPlot5.setDomainCrosshairPaint(paint14);
        java.awt.Paint paint16 = xYPlot5.getDomainZeroBaselinePaint();
        xYPlot5.setDomainCrosshairVisible(false);
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.chart.util.Layer layer20 = null;
        try {
            boolean boolean21 = xYPlot5.removeDomainMarker(marker19, layer20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) (byte) 1, (double) 10);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot6);
        flowArrangement5.add((org.jfree.chart.block.Block) legendTitle7, (java.lang.Object) 2);
        flowArrangement5.clear();
        boolean boolean11 = size2D0.equals((java.lang.Object) flowArrangement5);
        java.lang.String str12 = size2D0.toString();
        size2D0.width = (byte) -1;
        double double15 = size2D0.height;
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str12.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Pie 3D Plot", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        categoryAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot2);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke6 = categoryAxis3D5.getTickMarkStroke();
        int int7 = categoryAxis3D5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = categoryAxis3D5.getCategoryLabelPositions();
        categoryAxis3D1.setCategoryLabelPositions(categoryLabelPositions8);
        java.awt.Paint paint10 = categoryAxis3D1.getAxisLinePaint();
        categoryAxis3D1.setUpperMargin((double) (byte) 10);
        categoryAxis3D1.removeCategoryLabelToolTip((java.lang.Comparable) 98.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double6 = numberAxis3D5.getFixedAutoRange();
        double double7 = numberAxis3D5.getUpperBound();
        java.awt.Shape shape8 = numberAxis3D5.getUpArrow();
        numberAxis3D2.setUpArrow(shape8);
        int int10 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D2);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke12 = xYPlot11.getDomainGridlineStroke();
        java.awt.Paint paint13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot11.setRangeCrosshairPaint(paint13);
        int int15 = xYPlot11.getDomainAxisCount();
        numberAxis3D2.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot11);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        polarPlot0.addCornerTextItem("hi!");
        org.jfree.chart.plot.Plot plot4 = polarPlot0.getRootPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        polarPlot0.addChangeListener(plotChangeListener5);
        java.lang.Object obj7 = polarPlot0.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot2.getFixedDomainAxisSpace();
        categoryPlot2.clearRangeAxes();
        categoryPlot2.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, true);
        jFreeChart10.setBorderVisible(false);
        jFreeChart10.fireChartChanged();
        java.lang.Object obj14 = jFreeChart10.clone();
        java.lang.Object obj15 = jFreeChart10.clone();
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator2);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        piePlot1.setSimpleLabelOffset(rectangleInsets5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot1.getSimpleLabelOffset();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D11 = xYPlot10.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            piePlot1.draw(graphics2D8, rectangle2D9, point2D11, plotState12, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(point2D11);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot2.getFixedDomainAxisSpace();
        categoryPlot2.clearRangeAxes();
        categoryPlot2.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, true);
        jFreeChart10.setBorderVisible(false);
        jFreeChart10.fireChartChanged();
        jFreeChart10.removeLegend();
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.zoomRange((double) (short) 0, (double) 1L);
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis3D1.setDownArrow(shape6);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape6, "UnitType.RELATIVE");
        java.lang.String str10 = chartEntity9.getToolTipText();
        chartEntity9.setURLText("TextBlockAnchor.BOTTOM_LEFT");
        chartEntity9.setToolTipText("Rotation.ANTICLOCKWISE");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UnitType.RELATIVE" + "'", str10.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color1 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.color.ColorSpace colorSpace3 = color1.getColorSpace();
        int int4 = color1.getBlue();
        java.awt.Color color5 = java.awt.Color.white;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color0, color1, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        int int8 = color7.getRed();
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        float float10 = ringPlot9.getForegroundAlpha();
        ringPlot9.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke15 = xYPlot14.getDomainGridlineStroke();
        boolean boolean16 = ringPlot9.equals((java.lang.Object) xYPlot14);
        java.awt.Paint paint17 = ringPlot9.getLabelBackgroundPaint();
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { color7, paint17 };
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D20.setTickMarkInsideLength((float) (byte) 1);
        java.awt.Stroke stroke23 = categoryAxis3D20.getTickMarkStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D25.setTickMarkInsideLength((float) (byte) 1);
        java.awt.Stroke stroke28 = categoryAxis3D25.getTickMarkStroke();
        java.awt.Stroke[] strokeArray29 = new java.awt.Stroke[] { stroke23, stroke28 };
        java.awt.Paint[] paintArray30 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray31 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke36 = categoryAxis3D35.getTickMarkStroke();
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke38 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray39 = new java.awt.Stroke[] { stroke32, stroke33, stroke36, stroke37, stroke38 };
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D41 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke42 = categoryAxis3D41.getTickMarkStroke();
        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D45 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke46 = categoryAxis3D45.getTickMarkStroke();
        java.awt.Stroke stroke47 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray48 = new java.awt.Stroke[] { stroke42, stroke43, stroke46, stroke47 };
        java.awt.Shape shape49 = null;
        java.awt.Shape[] shapeArray50 = new java.awt.Shape[] { shape49 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier51 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray30, paintArray31, strokeArray39, strokeArray48, shapeArray50);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D53 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double54 = numberAxis3D53.getFixedAutoRange();
        double double55 = numberAxis3D53.getUpperBound();
        java.awt.Shape shape56 = numberAxis3D53.getUpArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D58 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range59 = numberAxis3D58.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D61 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double62 = numberAxis3D61.getFixedAutoRange();
        double double63 = numberAxis3D61.getUpperBound();
        java.awt.Shape shape64 = numberAxis3D61.getUpArrow();
        numberAxis3D58.setUpArrow(shape64);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D67 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range68 = numberAxis3D67.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D70 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double71 = numberAxis3D70.getFixedAutoRange();
        double double72 = numberAxis3D70.getUpperBound();
        java.awt.Shape shape73 = numberAxis3D70.getUpArrow();
        numberAxis3D67.setUpArrow(shape73);
        java.awt.Shape shape75 = numberAxis3D67.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D77 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double78 = numberAxis3D77.getFixedAutoRange();
        numberAxis3D77.zoomRange((double) (short) 0, (double) 1L);
        java.awt.Shape shape82 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis3D77.setDownArrow(shape82);
        java.awt.Shape[] shapeArray84 = new java.awt.Shape[] { shape56, shape64, shape75, shape82 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier85 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray18, strokeArray29, strokeArray39, shapeArray84);
        java.awt.Shape shape86 = defaultDrawingSupplier85.getNextShape();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 255 + "'", int4 == 255);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(paintArray30);
        org.junit.Assert.assertNotNull(paintArray31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(strokeArray39);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(strokeArray48);
        org.junit.Assert.assertNotNull(shapeArray50);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.0d + "'", double55 == 1.0d);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(range59);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(range68);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 1.0d + "'", double72 == 1.0d);
        org.junit.Assert.assertNotNull(shape73);
        org.junit.Assert.assertNotNull(shape75);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(shape82);
        org.junit.Assert.assertNotNull(shapeArray84);
        org.junit.Assert.assertNotNull(shape86);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.setRangeCrosshairValue((double) (short) 1, true);
        java.awt.Stroke stroke8 = xYPlot4.getRangeZeroBaselineStroke();
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot4.setDomainZeroBaselinePaint(paint9);
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder(0.05d, 0.0d, 98.0d, (double) (short) 0, paint9);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) (byte) 1, (double) 10);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot6);
        flowArrangement5.add((org.jfree.chart.block.Block) legendTitle7, (java.lang.Object) 2);
        flowArrangement5.clear();
        boolean boolean11 = size2D0.equals((java.lang.Object) flowArrangement5);
        java.lang.String str12 = size2D0.toString();
        double double13 = size2D0.width;
        java.lang.String str14 = size2D0.toString();
        size2D0.setHeight(0.0d);
        size2D0.setWidth((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str12.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str14.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean6 = numberAxis3D1.isPositiveArrowVisible();
        java.lang.Object obj7 = numberAxis3D1.clone();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat8);
        numberAxis3D1.setTickLabelsVisible(false);
        numberAxis3D1.setTickMarksVisible(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean6 = numberAxis3D1.isPositiveArrowVisible();
        java.lang.Object obj7 = numberAxis3D1.clone();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat8);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double12 = numberAxis3D11.getFixedAutoRange();
        double double13 = numberAxis3D11.getUpperBound();
        java.awt.Shape shape14 = numberAxis3D11.getUpArrow();
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis3D11.setAxisLineStroke(stroke15);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range19 = numberAxis3D18.getRange();
        org.jfree.data.Range range21 = org.jfree.data.Range.shift(range19, (double) (-1.0f));
        numberAxis3D11.setDefaultAutoRange(range19);
        numberAxis3D1.setRangeWithMargins(range19);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = numberAxis3D1.getMarkerBand();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNull(markerAxisBand24);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.data.Range range4 = org.jfree.data.Range.shift(range2, (double) (-1.0f));
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range2, (double) 0.5f, false);
        boolean boolean10 = range7.intersects((double) 8, 10.0d);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.zoom(100.0d);
        boolean boolean3 = ringPlot0.getSeparatorsVisible();
        int int4 = ringPlot0.getPieIndex();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("TextBlockAnchor.BOTTOM_LEFT");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        try {
            textFragment1.draw(graphics2D2, (float) (-4144960), (float) 2, textAnchor5, (float) (short) 0, 0.0f, 0.05d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) (short) 10, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "");
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "hi!", jFreeChart6, chartChangeEventType7);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = chartChangeEvent8.getType();
        java.awt.Font font11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot12.getFixedDomainAxisSpace();
        categoryPlot12.clearRangeAxes();
        categoryPlot12.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray17 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer16 };
        categoryPlot12.setRenderers(categoryItemRendererArray17);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("Pie Plot", font11, (org.jfree.chart.plot.Plot) categoryPlot12, true);
        java.awt.RenderingHints renderingHints21 = jFreeChart20.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle22 = jFreeChart20.getLegend();
        jFreeChart20.setTextAntiAlias(true);
        chartChangeEvent8.setChart(jFreeChart20);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = jFreeChart20.getCategoryPlot();
        org.junit.Assert.assertNull(chartChangeEventType9);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNotNull(categoryItemRendererArray17);
        org.junit.Assert.assertNotNull(renderingHints21);
        org.junit.Assert.assertNotNull(legendTitle22);
        org.junit.Assert.assertNotNull(categoryPlot26);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setExplodedPieArea(rectangle2D2);
        double double4 = piePlotState1.getTotal();
        piePlotState1.setPassesRequired(0);
        double double7 = piePlotState1.getPieCenterX();
        java.awt.geom.Rectangle2D rectangle2D8 = piePlotState1.getPieArea();
        double double9 = piePlotState1.getLatestAngle();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        xYPlot5.setRenderer(8, xYItemRenderer9);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot5.getRangeAxisEdge(255);
        org.jfree.chart.plot.Marker marker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        try {
            boolean boolean16 = xYPlot5.removeDomainMarker(0, marker14, layer15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.block.BlockFrame blockFrame2 = legendTitle1.getFrame();
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle1.getItemContainer();
        legendTitle1.setID("PieSection: 0, 10(1)");
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertNotNull(blockContainer3);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateTopInset((double) (short) 0);
        double double4 = rectangleInsets0.calculateLeftOutset(0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot1);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor3 = ringPlot1.getLabelDistributor();
        java.awt.Color color4 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        java.awt.color.ColorSpace colorSpace6 = color4.getColorSpace();
        ringPlot1.setLabelShadowPaint((java.awt.Paint) color4);
        java.lang.Class<?> wildcardClass8 = ringPlot1.getClass();
        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass8);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(colorSpace6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(uRL9);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) (byte) 1, (double) 10);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot6);
        flowArrangement5.add((org.jfree.chart.block.Block) legendTitle7, (java.lang.Object) 2);
        flowArrangement5.clear();
        boolean boolean11 = size2D0.equals((java.lang.Object) flowArrangement5);
        java.lang.String str12 = size2D0.toString();
        size2D0.width = (byte) -1;
        double double15 = size2D0.getHeight();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str12.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.plot.Plot plot9 = piePlot5.getRootPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = ringPlot0.initialise(graphics2D2, rectangle2D3, piePlot5, (java.lang.Integer) 10, plotRenderingInfo11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        ringPlot0.markerChanged(markerChangeEvent13);
        ringPlot0.setMinimumArcAngleToDraw((double) 100.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(piePlotState12);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        java.awt.Font font2 = null;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, (java.awt.Paint) color3, (float) (-1L), textMeasurer5);
        org.jfree.chart.text.TextLine textLine7 = null;
        textBlock6.addLine(textLine7);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font12 = categoryAxis3D11.getLabelFont();
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        textBlock6.addLine("Pie Plot", font12, (java.awt.Paint) color13);
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        ringPlot15.zoom(100.0d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke20 = categoryAxis3D19.getTickMarkStroke();
        java.awt.Paint paint21 = categoryAxis3D19.getTickLabelPaint();
        ringPlot15.setLabelPaint(paint21);
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("ThreadContext", font12, paint21);
        java.lang.String str24 = textFragment23.getText();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ThreadContext" + "'", str24.equals("ThreadContext"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font14 = categoryAxis3D13.getLabelFont();
        categoryAxis3D13.setLabelAngle((double) (-1));
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryAxis3D13.setTickLabelPaint((java.lang.Comparable) 97.0d, paint18);
        categoryAxis3D13.setLabelAngle((double) 1L);
        categoryAxis3D13.setUpperMargin((double) 10.0f);
        try {
            categoryPlot0.setDomainAxis((-4144960), (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot5.getDomainAxisLocation(255);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot5.getRendererForDataset(xYDataset10);
        boolean boolean12 = xYPlot5.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(xYItemRenderer11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        double double3 = numberAxis3D1.getUpperBound();
        java.awt.Shape shape4 = numberAxis3D1.getUpArrow();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, 0, (int) (byte) 10, (java.lang.Comparable) 1.0d, "ThreadContext", "hi!");
        pieSectionEntity11.setSectionKey((java.lang.Comparable) (short) 1);
        java.lang.String str14 = pieSectionEntity11.toString();
        java.lang.String str15 = pieSectionEntity11.getShapeCoords();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PieSection: 0, 10(1)" + "'", str14.equals("PieSection: 0, 10(1)"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0,0,-2,2,2,2,2,2" + "'", str15.equals("0,0,-2,2,2,2,2,2"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("XY Plot");
        categoryAxis3D1.setLabelToolTip("ThreadContext");
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double8 = numberAxis3D7.getLowerMargin();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        piePlot10.drawBackgroundImage(graphics2D11, rectangle2D12);
        org.jfree.chart.plot.Plot plot14 = piePlot10.getRootPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot10.setSectionOutlinePaint((java.lang.Comparable) 1, (java.awt.Paint) color16);
        numberAxis3D7.setLabelPaint((java.awt.Paint) color16);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis3D23.getCategoryStart((-1), (int) ' ', rectangle2D26, rectangleEdge27);
        boolean boolean29 = textTitle21.equals((java.lang.Object) categoryAxis3D23);
        textTitle21.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color32 = java.awt.Color.BLACK;
        textTitle21.setBackgroundPaint((java.awt.Paint) color32);
        java.awt.geom.Rectangle2D rectangle2D34 = textTitle21.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace36 = categoryPlot35.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot37 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke38 = ringPlot37.getSeparatorStroke();
        categoryPlot35.setDomainGridlineStroke(stroke38);
        org.jfree.chart.axis.AxisLocation axisLocation41 = null;
        categoryPlot35.setDomainAxisLocation((int) ' ', axisLocation41);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot35.getRangeAxisEdge();
        double double44 = numberAxis3D7.valueToJava2D(0.0d, rectangle2D34, rectangleEdge43);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        java.util.List list46 = categoryAxis3D1.refreshTicks(graphics2D4, axisState5, rectangle2D34, rectangleEdge45);
        org.jfree.chart.entity.ChartEntity chartEntity47 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D34);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(plot14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(axisSpace36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(list46);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.String str2 = multiplePiePlot1.getPlotType();
        double double3 = multiplePiePlot1.getLimit();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = multiplePiePlot1.getLegendItems();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection4);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 1, (double) 10);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot5);
        flowArrangement4.add((org.jfree.chart.block.Block) legendTitle6, (java.lang.Object) 2);
        legendTitle6.setWidth((double) 1L);
        legendTitle6.setHeight(1.0d);
        java.awt.Font font13 = legendTitle6.getItemFont();
        java.awt.Font font15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot16.getFixedDomainAxisSpace();
        categoryPlot16.clearRangeAxes();
        categoryPlot16.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray21 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer20 };
        categoryPlot16.setRenderers(categoryItemRendererArray21);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("Pie Plot", font15, (org.jfree.chart.plot.Plot) categoryPlot16, true);
        java.awt.RenderingHints renderingHints25 = jFreeChart24.getRenderingHints();
        java.awt.Stroke stroke26 = jFreeChart24.getBorderStroke();
        legendTitle6.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart24);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D29 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D29.setTickMarkInsideLength((float) (byte) 1);
        java.awt.Stroke stroke32 = categoryAxis3D29.getTickMarkStroke();
        java.awt.Font font34 = categoryAxis3D29.getTickLabelFont((java.lang.Comparable) "{0}");
        legendTitle6.setItemFont(font34);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(categoryItemRendererArray21);
        org.junit.Assert.assertNotNull(renderingHints25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(font34);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.awt.Font font2 = null;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, (java.awt.Paint) color3, (float) (-1L), textMeasurer5);
        java.awt.Color color7 = java.awt.Color.getColor("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=-1.0]", color3);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D1.setTickMarkInsideLength((float) (byte) 1);
        java.awt.Stroke stroke4 = categoryAxis3D1.getTickMarkStroke();
        java.awt.Stroke stroke5 = categoryAxis3D1.getAxisLineStroke();
        categoryAxis3D1.setLabelAngle(0.0d);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.zoom(100.0d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke5 = categoryAxis3D4.getTickMarkStroke();
        java.awt.Paint paint6 = categoryAxis3D4.getTickLabelPaint();
        ringPlot0.setLabelPaint(paint6);
        ringPlot0.setIgnoreZeroValues(false);
        ringPlot0.setSimpleLabels(true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(15);
        pieLabelDistributor1.sort();
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("java.awt.Color[r=0,g=0,b=0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name java.awt.Color[r=0,g=0,b=0], locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        blockParams0.setTranslateX(0.2d);
        blockParams0.setGenerateEntities(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 1, (double) 10);
        boolean boolean6 = flowArrangement4.equals((java.lang.Object) 0.0d);
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = polarPlot7.getLegendItems();
        java.util.Iterator iterator9 = legendItemCollection8.iterator();
        boolean boolean10 = flowArrangement4.equals((java.lang.Object) iterator9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double14 = numberAxis3D13.getFixedAutoRange();
        double double15 = numberAxis3D13.getUpperBound();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range18 = numberAxis3D17.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double21 = numberAxis3D20.getFixedAutoRange();
        double double22 = numberAxis3D20.getUpperBound();
        java.awt.Shape shape23 = numberAxis3D20.getUpArrow();
        numberAxis3D17.setUpArrow(shape23);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, xYItemRenderer25);
        java.awt.Paint paint27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot26.setDomainGridlinePaint(paint27);
        boolean boolean29 = flowArrangement4.equals((java.lang.Object) xYPlot26);
        java.awt.Paint paint30 = xYPlot26.getDomainTickBandPaint();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(iterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(paint30);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.plot.Plot plot5 = piePlot1.getRootPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D8.setMaximumCategoryLabelWidthRatio(10.0f);
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color12 = java.awt.Color.BLACK;
        categoryAxis3D8.setTickLabelPaint((java.lang.Comparable) date11, (java.awt.Paint) color12);
        piePlot1.setSectionPaint((java.lang.Comparable) "ThreadContext", (java.awt.Paint) color12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        piePlot1.setDataset(pieDataset16);
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D2.getCategoryStart((-1), (int) ' ', rectangle2D5, rectangleEdge6);
        java.util.List list8 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        categoryPlot0.drawBackgroundImage(graphics2D9, rectangle2D10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 10, plotRenderingInfo13, point2D14, true);
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        try {
            boolean boolean20 = categoryPlot0.removeRangeMarker((int) 'a', marker18, layer19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "");
        java.lang.String str6 = basicProjectInfo5.getInfo();
        basicProjectInfo5.setLicenceName("Rotation.ANTICLOCKWISE");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        java.awt.Paint paint4 = ringPlot2.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double6 = rectangleInsets5.getTop();
        ringPlot2.setLabelPadding(rectangleInsets5);
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        ringPlot2.setLabelBackgroundPaint((java.awt.Paint) color8);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color8);
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) categoryPlot0);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("RectangleAnchor.TOP_LEFT", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getBaseSectionOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double1 = rectangleInsets0.getTop();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment3, (double) (byte) 1, (double) 10);
        boolean boolean8 = flowArrangement6.equals((java.lang.Object) 0.0d);
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = polarPlot9.getLegendItems();
        java.util.Iterator iterator11 = legendItemCollection10.iterator();
        boolean boolean12 = flowArrangement6.equals((java.lang.Object) iterator11);
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot13);
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = legendTitle14.getVerticalAlignment();
        double double16 = legendTitle14.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle14.getPadding();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.PiePlotState piePlotState19 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo18);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        piePlotState19.setExplodedPieArea(rectangle2D20);
        double double22 = piePlotState19.getTotal();
        piePlotState19.setLatestAngle((double) (short) -1);
        java.awt.geom.Rectangle2D rectangle2D25 = piePlotState19.getLinkArea();
        org.jfree.chart.entity.EntityCollection entityCollection26 = piePlotState19.getEntityCollection();
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D30 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = null;
        double double35 = categoryAxis3D30.getCategoryStart((-1), (int) ' ', rectangle2D33, rectangleEdge34);
        boolean boolean36 = textTitle28.equals((java.lang.Object) categoryAxis3D30);
        textTitle28.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color39 = java.awt.Color.BLACK;
        textTitle28.setBackgroundPaint((java.awt.Paint) color39);
        java.awt.geom.Rectangle2D rectangle2D41 = textTitle28.getBounds();
        piePlotState19.setLinkArea(rectangle2D41);
        flowArrangement6.add((org.jfree.chart.block.Block) legendTitle14, (java.lang.Object) rectangle2D41);
        rectangleInsets0.trim(rectangle2D41);
        org.jfree.chart.entity.ChartEntity chartEntity45 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D41);
        java.awt.Shape shape46 = chartEntity45.getArea();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(iterator11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D25);
        org.junit.Assert.assertNull(entityCollection26);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(shape46);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.plot.Plot plot5 = piePlot1.getRootPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D8.setMaximumCategoryLabelWidthRatio(10.0f);
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color12 = java.awt.Color.BLACK;
        categoryAxis3D8.setTickLabelPaint((java.lang.Comparable) date11, (java.awt.Paint) color12);
        piePlot1.setSectionPaint((java.lang.Comparable) "ThreadContext", (java.awt.Paint) color12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.plot.Plot plot16 = plotChangeEvent15.getPlot();
        org.jfree.chart.plot.Plot plot17 = null;
        plot16.setParent(plot17);
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(plot16);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) (-1L), textMeasurer4);
        java.util.List list6 = textBlock5.getLines();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font2 = categoryAxis3D1.getLabelFont();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis3D1.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("RectangleAnchor.TOP_RIGHT", 100, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.lang.Comparable[] comparableArray2 = new java.lang.Comparable[] { "RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=-1.0]", 10.0f };
        java.lang.Comparable[] comparableArray3 = new java.lang.Comparable[] {};
        double[][] doubleArray4 = new double[][] {};
        try {
            org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray2, comparableArray3, doubleArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray2);
        org.junit.Assert.assertNotNull(comparableArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }
}

