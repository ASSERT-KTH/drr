import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot1.setShadowPaint((java.awt.Paint) color5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        piePlot8.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot8.setShadowPaint((java.awt.Paint) color12);
        java.awt.Image image14 = piePlot8.getBackgroundImage();
        java.awt.Paint paint15 = piePlot8.getLabelShadowPaint();
        piePlot1.setShadowPaint(paint15);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(image14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        legendTitle1.setID("hi!");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot5.setShadowPaint((java.awt.Paint) color9);
        boolean boolean11 = legendTitle1.equals((java.lang.Object) piePlot5);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke13 = ringPlot12.getSeparatorStroke();
        java.awt.Paint paint14 = ringPlot12.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double16 = rectangleInsets15.getTop();
        ringPlot12.setLabelPadding(rectangleInsets15);
        legendTitle1.setMargin(rectangleInsets15);
        double double19 = legendTitle1.getContentXOffset();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, (double) (-1.0f));
        org.jfree.data.Range range24 = rectangleConstraint23.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = rectangleConstraint23.toFixedHeight((double) (byte) -1);
        org.jfree.chart.util.Size2D size2D27 = legendTitle1.arrange(graphics2D20, rectangleConstraint23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        xYPlot29.zoomRangeAxes(10.0d, plotRenderingInfo31, point2D32, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        xYPlot29.setRenderer((int) (short) 1, xYItemRenderer36);
        boolean boolean38 = rectangleAnchor28.equals((java.lang.Object) xYPlot29);
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor28);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.util.Size2D size2D41 = legendTitle1.arrange(graphics2D40);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(size2D41);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double6 = numberAxis3D5.getFixedAutoRange();
        double double7 = numberAxis3D5.getUpperBound();
        java.awt.Shape shape8 = numberAxis3D5.getUpArrow();
        numberAxis3D2.setUpArrow(shape8);
        java.awt.Color color10 = java.awt.Color.green;
        numberAxis3D2.setTickLabelPaint((java.awt.Paint) color10);
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.plot.Plot plot9 = piePlot5.getRootPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = ringPlot0.initialise(graphics2D2, rectangle2D3, piePlot5, (java.lang.Integer) 10, plotRenderingInfo11);
        boolean boolean13 = ringPlot0.getSeparatorsVisible();
        java.awt.Paint paint14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot0.setLabelOutlinePaint(paint14);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setExplodedPieArea(rectangle2D2);
        double double4 = piePlotState1.getTotal();
        piePlotState1.setLatestAngle((double) (short) -1);
        org.jfree.chart.entity.EntityCollection entityCollection7 = piePlotState1.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D8 = piePlotState1.getPieArea();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(entityCollection7);
        org.junit.Assert.assertNull(rectangle2D8);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double6 = numberAxis3D5.getFixedAutoRange();
        double double7 = numberAxis3D5.getUpperBound();
        java.awt.Shape shape8 = numberAxis3D5.getUpArrow();
        numberAxis3D2.setUpArrow(shape8);
        int int10 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D2);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        int int12 = xYPlot0.indexOf(xYDataset11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot0.getRangeAxisLocation((-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot0.getInsets();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.mapDatasetToRangeAxis((int) (byte) 1, (int) '4');
        categoryPlot0.setBackgroundImageAlignment((int) (byte) 100);
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font16 = polarPlot15.getAngleLabelFont();
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke18 = ringPlot17.getSeparatorStroke();
        java.awt.Paint paint19 = ringPlot17.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double21 = rectangleInsets20.getTop();
        ringPlot17.setLabelPadding(rectangleInsets20);
        java.awt.Color color23 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace24 = color23.getColorSpace();
        ringPlot17.setLabelBackgroundPaint((java.awt.Paint) color23);
        org.jfree.chart.text.TextFragment textFragment26 = new org.jfree.chart.text.TextFragment("", font16, (java.awt.Paint) color23);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D28.setAutoTickUnitSelection(true, false);
        boolean boolean32 = numberAxis3D28.isTickLabelsVisible();
        java.lang.Object obj33 = numberAxis3D28.clone();
        boolean boolean34 = textFragment26.equals((java.lang.Object) numberAxis3D28);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit35 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D28.setTickUnit(numberTickUnit35);
        int int37 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D28);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(colorSpace24);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(numberTickUnit35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot0.getRangeAxisForDataset((int) '#');
        boolean boolean11 = categoryPlot0.getDrawSharedDomainAxis();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getBaseSectionPaint();
        piePlot1.setPieIndex(255);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        double double2 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLegendLabelGenerator();
        java.awt.Paint paint4 = ringPlot0.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairValue((double) (short) 1, true);
        java.awt.Stroke stroke4 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace5);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean6 = numberAxis3D1.isPositiveArrowVisible();
        numberAxis3D1.centerRange(0.2d);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis3D12.getCategoryStart((-1), (int) ' ', rectangle2D15, rectangleEdge16);
        boolean boolean18 = textTitle10.equals((java.lang.Object) categoryAxis3D12);
        textTitle10.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color21 = java.awt.Color.BLACK;
        textTitle10.setBackgroundPaint((java.awt.Paint) color21);
        java.awt.geom.Rectangle2D rectangle2D23 = textTitle10.getBounds();
        numberAxis3D1.setLeftArrow((java.awt.Shape) rectangle2D23);
        org.jfree.data.Range range25 = null;
        try {
            numberAxis3D1.setDefaultAutoRange(range25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(rectangle2D23);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        float float4 = ringPlot3.getForegroundAlpha();
        ringPlot3.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke9 = xYPlot8.getDomainGridlineStroke();
        boolean boolean10 = ringPlot3.equals((java.lang.Object) xYPlot8);
        org.jfree.chart.axis.AxisLocation axisLocation12 = xYPlot8.getDomainAxisLocation(255);
        xYPlot0.setRangeAxisLocation(500, axisLocation12);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.configureDomainAxes();
        java.awt.Font font4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        categoryPlot0.setNoDataMessageFont(font4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        categoryPlot0.setRangeAxis(1, valueAxis8);
        java.util.List list10 = categoryPlot0.getCategories();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D("RectangleEdge.LEFT");
        boolean boolean13 = categoryPlot0.equals((java.lang.Object) "RectangleEdge.LEFT");
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(list10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        double double3 = numberAxis3D1.getUpperBound();
        java.awt.Shape shape4 = numberAxis3D1.getUpArrow();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, 0, (int) (byte) 10, (java.lang.Comparable) 1.0d, "ThreadContext", "hi!");
        pieSectionEntity11.setSectionKey((java.lang.Comparable) (short) 1);
        java.lang.String str14 = pieSectionEntity11.toString();
        java.lang.String str15 = pieSectionEntity11.getShapeType();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator16 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator17 = null;
        try {
            java.lang.String str18 = pieSectionEntity11.getImageMapAreaTag(toolTipTagFragmentGenerator16, uRLTagFragmentGenerator17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PieSection: 0, 10(1)" + "'", str14.equals("PieSection: 0, 10(1)"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "poly" + "'", str15.equals("poly"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "");
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "hi!", jFreeChart6, chartChangeEventType7);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = chartChangeEvent8.getType();
        java.awt.Font font11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot12.getFixedDomainAxisSpace();
        categoryPlot12.clearRangeAxes();
        categoryPlot12.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray17 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer16 };
        categoryPlot12.setRenderers(categoryItemRendererArray17);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("Pie Plot", font11, (org.jfree.chart.plot.Plot) categoryPlot12, true);
        java.awt.RenderingHints renderingHints21 = jFreeChart20.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle22 = jFreeChart20.getLegend();
        jFreeChart20.setTextAntiAlias(true);
        chartChangeEvent8.setChart(jFreeChart20);
        java.util.List list26 = jFreeChart20.getSubtitles();
        jFreeChart20.setAntiAlias(false);
        java.awt.image.BufferedImage bufferedImage31 = jFreeChart20.createBufferedImage((int) '4', 255);
        java.awt.Image image32 = jFreeChart20.getBackgroundImage();
        org.junit.Assert.assertNull(chartChangeEventType9);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNotNull(categoryItemRendererArray17);
        org.junit.Assert.assertNotNull(renderingHints21);
        org.junit.Assert.assertNotNull(legendTitle22);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertNotNull(bufferedImage31);
        org.junit.Assert.assertNull(image32);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomRangeAxes(10.0d, plotRenderingInfo2, point2D3, false);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = polarPlot6.getLegendItems();
        boolean boolean8 = polarPlot6.isAngleGridlinesVisible();
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Image image11 = polarPlot10.getBackgroundImage();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        polarPlot10.setRenderer(polarItemRenderer12);
        java.awt.Font font14 = polarPlot10.getAngleLabelFont();
        java.awt.Paint paint15 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("UnitType.RELATIVE", font14, paint15, 10.0f);
        polarPlot6.setAngleLabelFont(font14);
        boolean boolean19 = polarPlot6.isRangeZoomable();
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot6.setAngleGridlineStroke(stroke20);
        xYPlot0.setDomainZeroBaselineStroke(stroke20);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot1.zoomRangeAxes(10.0d, plotRenderingInfo3, point2D4, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot1.setRenderer((int) (short) 1, xYItemRenderer8);
        boolean boolean10 = rectangleAnchor0.equals((java.lang.Object) xYPlot1);
        boolean boolean11 = xYPlot1.isRangeCrosshairLockedOnData();
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot1.getDataset();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(xYDataset12);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 'a');
        double double3 = range2.getUpperBound();
        boolean boolean6 = range2.intersects((double) 500, (double) 1L);
        java.awt.Color color7 = java.awt.Color.white;
        boolean boolean8 = range2.equals((java.lang.Object) color7);
        org.jfree.data.Range range10 = null;
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude(range10, (double) 'a');
        double double13 = range12.getUpperBound();
        double double15 = range12.constrain((double) (short) 1);
        org.jfree.data.Range range17 = org.jfree.data.Range.expandToInclude(range12, (double) 8);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType18 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range20 = null;
        org.jfree.data.Range range22 = org.jfree.data.Range.expandToInclude(range20, (double) 'a');
        double double23 = range22.getUpperBound();
        double double25 = range22.constrain((double) (short) 1);
        org.jfree.data.Range range27 = org.jfree.data.Range.expandToInclude(range22, (double) 8);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType28 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint(1.0E-8d, range17, lengthConstraintType18, (double) 10L, range27, lengthConstraintType28);
        boolean boolean30 = color7.equals((java.lang.Object) 10L);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 97.0d + "'", double13 == 97.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 97.0d + "'", double15 == 97.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(lengthConstraintType18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 97.0d + "'", double23 == 97.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 97.0d + "'", double25 == 97.0d);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(lengthConstraintType28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Stroke stroke2 = ringPlot1.getSeparatorStroke();
        ringPlot1.setSectionOutlinesVisible(true);
        ringPlot1.setInnerSeparatorExtension((double) (-4144960));
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=-1.0]", graphics2D1, (float) (-4144960), (float) 0L, (double) (byte) -1, (float) 'a', (float) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomRangeAxes(10.0d, plotRenderingInfo2, point2D3, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getDomainAxis();
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot5.getDomainAxisLocation(255);
        java.lang.String str10 = xYPlot5.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation12 = xYPlot5.getDomainAxisLocation((int) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "XY Plot" + "'", str10.equals("XY Plot"));
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Comparable comparable1 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        float float4 = ringPlot3.getForegroundAlpha();
        ringPlot3.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke9 = xYPlot8.getDomainGridlineStroke();
        boolean boolean10 = ringPlot3.equals((java.lang.Object) xYPlot8);
        org.jfree.chart.axis.AxisLocation axisLocation12 = xYPlot8.getDomainAxisLocation(255);
        xYPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation12, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double17 = numberAxis3D16.getFixedAutoRange();
        numberAxis3D16.setLabelAngle((double) 10L);
        org.jfree.data.Range range20 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D16);
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font24 = polarPlot23.getAngleLabelFont();
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke26 = ringPlot25.getSeparatorStroke();
        java.awt.Paint paint27 = ringPlot25.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double29 = rectangleInsets28.getTop();
        ringPlot25.setLabelPadding(rectangleInsets28);
        java.awt.Color color31 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace32 = color31.getColorSpace();
        ringPlot25.setLabelBackgroundPaint((java.awt.Paint) color31);
        org.jfree.chart.text.TextFragment textFragment34 = new org.jfree.chart.text.TextFragment("", font24, (java.awt.Paint) color31);
        java.awt.Paint paint35 = textFragment34.getPaint();
        xYPlot0.setQuadrantPaint(0, paint35);
        org.jfree.chart.axis.ValueAxis valueAxis37 = xYPlot0.getRangeAxis();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.plot.RingPlot ringPlot39 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke40 = ringPlot39.getSeparatorStroke();
        java.awt.Paint paint41 = ringPlot39.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double43 = rectangleInsets42.getTop();
        ringPlot39.setLabelPadding(rectangleInsets42);
        double double46 = rectangleInsets42.extendWidth(0.4d);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D48 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double49 = numberAxis3D48.getLowerMargin();
        org.jfree.data.general.PieDataset pieDataset50 = null;
        org.jfree.chart.plot.PiePlot piePlot51 = new org.jfree.chart.plot.PiePlot(pieDataset50);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        piePlot51.drawBackgroundImage(graphics2D52, rectangle2D53);
        org.jfree.chart.plot.Plot plot55 = piePlot51.getRootPlot();
        java.awt.Color color57 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot51.setSectionOutlinePaint((java.lang.Comparable) 1, (java.awt.Paint) color57);
        numberAxis3D48.setLabelPaint((java.awt.Paint) color57);
        org.jfree.chart.title.TextTitle textTitle62 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D64 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = null;
        double double69 = categoryAxis3D64.getCategoryStart((-1), (int) ' ', rectangle2D67, rectangleEdge68);
        boolean boolean70 = textTitle62.equals((java.lang.Object) categoryAxis3D64);
        textTitle62.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color73 = java.awt.Color.BLACK;
        textTitle62.setBackgroundPaint((java.awt.Paint) color73);
        java.awt.geom.Rectangle2D rectangle2D75 = textTitle62.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot76 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace77 = categoryPlot76.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot78 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke79 = ringPlot78.getSeparatorStroke();
        categoryPlot76.setDomainGridlineStroke(stroke79);
        org.jfree.chart.axis.AxisLocation axisLocation82 = null;
        categoryPlot76.setDomainAxisLocation((int) ' ', axisLocation82);
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = categoryPlot76.getRangeAxisEdge();
        double double85 = numberAxis3D48.valueToJava2D(0.0d, rectangle2D75, rectangleEdge84);
        rectangleInsets42.trim(rectangle2D75);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo87 = null;
        xYPlot0.drawAnnotations(graphics2D38, rectangle2D75, plotRenderingInfo87);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(colorSpace32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNull(valueAxis37);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 2.4d + "'", double46 == 2.4d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.05d + "'", double49 == 0.05d);
        org.junit.Assert.assertNotNull(plot55);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(color73);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertNull(axisSpace77);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(rectangleEdge84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainGridlineStroke();
        java.awt.Paint paint2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeCrosshairPaint(paint2);
        int int4 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = xYPlot0.getDomainMarkers(layer5);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNull(collection6);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double6 = numberAxis3D5.getFixedAutoRange();
        double double7 = numberAxis3D5.getUpperBound();
        java.awt.Shape shape8 = numberAxis3D5.getUpArrow();
        numberAxis3D2.setUpArrow(shape8);
        int int10 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D2);
        numberAxis3D2.setRangeAboutValue((double) 1L, (double) 10);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        double double3 = numberAxis3D1.getUpperBound();
        java.awt.Shape shape4 = numberAxis3D1.getUpArrow();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, 0, (int) (byte) 10, (java.lang.Comparable) 1.0d, "ThreadContext", "hi!");
        pieSectionEntity11.setSectionKey((java.lang.Comparable) (short) 1);
        java.lang.String str14 = pieSectionEntity11.toString();
        pieSectionEntity11.setSectionIndex((int) 'a');
        java.lang.String str17 = pieSectionEntity11.getShapeCoords();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PieSection: 0, 10(1)" + "'", str14.equals("PieSection: 0, 10(1)"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0,0,-2,2,2,2,2,2" + "'", str17.equals("0,0,-2,2,2,2,2,2"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textBlock0.getLineAlignment();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        textBlock0.draw(graphics2D2, (float) ' ', (float) 10L, textBlockAnchor5, (float) (short) 1, 0.0f, (double) (byte) 1);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.util.Size2D size2D11 = textBlock0.calculateDimensions(graphics2D10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape19 = textBlock0.calculateBounds(graphics2D12, (float) (short) 10, (-1.0f), textBlockAnchor15, (float) 100, 0.0f, (double) (short) 100);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(size2D11);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        int int2 = categoryPlot0.getDomainAxisCount();
        org.jfree.chart.util.SortOrder sortOrder3 = null;
        try {
            categoryPlot0.setRowRenderingOrder(sortOrder3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D1.setTickMarkInsideLength((float) (byte) 1);
        categoryAxis3D1.setCategoryLabelPositionOffset(0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.plot.Plot plot5 = piePlot1.getRootPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D8.setMaximumCategoryLabelWidthRatio(10.0f);
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color12 = java.awt.Color.BLACK;
        categoryAxis3D8.setTickLabelPaint((java.lang.Comparable) date11, (java.awt.Paint) color12);
        piePlot1.setSectionPaint((java.lang.Comparable) "ThreadContext", (java.awt.Paint) color12);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        boolean boolean16 = piePlot1.equals((java.lang.Object) defaultDrawingSupplier15);
        java.awt.Image image17 = piePlot1.getBackgroundImage();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor18 = piePlot1.getLabelDistributor();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord20 = abstractPieLabelDistributor18.getPieLabelRecord(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor18);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        categoryPlot0.setAnchorValue((double) '#', true);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = null;
        try {
            categoryPlot0.setAxisOffset(rectangleInsets7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        legendTitle1.setID("hi!");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot5.setShadowPaint((java.awt.Paint) color9);
        boolean boolean11 = legendTitle1.equals((java.lang.Object) piePlot5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        piePlot5.handleClick((int) (short) -1, (int) (byte) 10, plotRenderingInfo14);
        piePlot5.setCircular(true, true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairValue((double) (short) 1, true);
        boolean boolean4 = xYPlot0.isRangeZoomable();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("Pie 3D Plot");
        int int7 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D6);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis3D6.setMarkerBand(markerAxisBand8);
        boolean boolean10 = numberAxis3D6.isInverted();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = null;
        try {
            dateAxis0.setTickMarkPosition(dateTickMarkPosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.String str2 = multiplePiePlot1.getPlotType();
        java.lang.String str3 = multiplePiePlot1.getPlotType();
        java.lang.String str4 = multiplePiePlot1.getPlotType();
        java.lang.Comparable comparable5 = multiplePiePlot1.getAggregatedItemsKey();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Multiple Pie Plot" + "'", str3.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Multiple Pie Plot" + "'", str4.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "Other" + "'", comparable5.equals("Other"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double6 = numberAxis3D5.getFixedAutoRange();
        double double7 = numberAxis3D5.getUpperBound();
        java.awt.Shape shape8 = numberAxis3D5.getUpArrow();
        numberAxis3D2.setUpArrow(shape8);
        int int10 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D2);
        boolean boolean11 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = null;
        try {
            xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setExplodedPieArea(rectangle2D2);
        double double4 = piePlotState1.getTotal();
        piePlotState1.setLatestAngle((double) (short) -1);
        java.awt.geom.Rectangle2D rectangle2D7 = piePlotState1.getLinkArea();
        java.awt.geom.Rectangle2D rectangle2D8 = piePlotState1.getPieArea();
        piePlotState1.setTotal(0.14d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D7);
        org.junit.Assert.assertNull(rectangle2D8);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        xYPlot5.setRenderer(8, xYItemRenderer9);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot5.getRangeAxisEdge(255);
        java.awt.Color color13 = java.awt.Color.red;
        xYPlot5.setDomainTickBandPaint((java.awt.Paint) color13);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.trimWidth(35.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 33.0d + "'", double2 == 33.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) (short) -1, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.zoom(100.0d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke5 = categoryAxis3D4.getTickMarkStroke();
        java.awt.Paint paint6 = categoryAxis3D4.getTickLabelPaint();
        ringPlot0.setLabelPaint(paint6);
        ringPlot0.setIgnoreZeroValues(false);
        org.jfree.data.general.DatasetGroup datasetGroup10 = ringPlot0.getDatasetGroup();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(datasetGroup10);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        java.lang.String str1 = waferMapPlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "WMAP_Plot" + "'", str1.equals("WMAP_Plot"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceText("");
        org.jfree.chart.ui.Library[] libraryArray3 = projectInfo0.getLibraries();
        projectInfo0.setLicenceName("Pie 3D Plot");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font8 = categoryAxis3D7.getLabelFont();
        categoryAxis3D7.setLabelAngle((double) (-1));
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryAxis3D7.setTickLabelPaint((java.lang.Comparable) 97.0d, paint12);
        boolean boolean14 = projectInfo0.equals((java.lang.Object) 97.0d);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray3);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.Marker marker4 = null;
        try {
            categoryPlot0.addRangeMarker(marker4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.awt.Color color0 = java.awt.Color.white;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo6 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "");
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "hi!", jFreeChart7, chartChangeEventType8);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = chartChangeEvent9.getType();
        java.awt.Font font12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot13.getFixedDomainAxisSpace();
        categoryPlot13.clearRangeAxes();
        categoryPlot13.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray18 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer17 };
        categoryPlot13.setRenderers(categoryItemRendererArray18);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("Pie Plot", font12, (org.jfree.chart.plot.Plot) categoryPlot13, true);
        java.awt.RenderingHints renderingHints22 = jFreeChart21.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle23 = jFreeChart21.getLegend();
        jFreeChart21.setTextAntiAlias(true);
        chartChangeEvent9.setChart(jFreeChart21);
        java.util.List list27 = jFreeChart21.getSubtitles();
        jFreeChart21.setAntiAlias(false);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType30 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart21, chartChangeEventType30);
        jFreeChart21.setNotify(false);
        org.jfree.chart.title.Title title34 = null;
        jFreeChart21.removeSubtitle(title34);
        java.awt.Image image36 = jFreeChart21.getBackgroundImage();
        jFreeChart21.setNotify(true);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNull(chartChangeEventType10);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(categoryItemRendererArray18);
        org.junit.Assert.assertNotNull(renderingHints22);
        org.junit.Assert.assertNotNull(legendTitle23);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertNotNull(chartChangeEventType30);
        org.junit.Assert.assertNull(image36);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis3D3.getCategoryStart((-1), (int) ' ', rectangle2D6, rectangleEdge7);
        boolean boolean9 = textTitle1.equals((java.lang.Object) categoryAxis3D3);
        float float10 = categoryAxis3D3.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.plot.Plot plot5 = piePlot1.getRootPlot();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) 1, (java.awt.Paint) color7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot1.getToolTipGenerator();
        org.jfree.chart.util.Rotation rotation10 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        piePlot1.setDirection(rotation10);
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(rotation10);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.Range range3 = new org.jfree.data.Range((-1.0d), 100.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, (double) (-1.0f));
        org.jfree.data.Range range7 = rectangleConstraint6.getWidthRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = rectangleConstraint6.getWidthConstraintType();
        org.jfree.data.Range range10 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, (double) (-1.0f));
        org.jfree.data.Range range14 = rectangleConstraint13.getWidthRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint13.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) ' ', range3, lengthConstraintType8, (double) (byte) 0, range10, lengthConstraintType15);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint16.toUnconstrainedHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint17.toUnconstrainedWidth();
        double double19 = rectangleConstraint17.getHeight();
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.String str2 = multiplePiePlot1.getPlotType();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = multiplePiePlot1.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset4 = multiplePiePlot1.getDataset();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(categoryDataset4);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        piePlot1.setSimpleLabelOffset(rectangleInsets5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot1.getSimpleLabelOffset();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D9.setMaximumCategoryLabelWidthRatio(10.0f);
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color13 = java.awt.Color.BLACK;
        categoryAxis3D9.setTickLabelPaint((java.lang.Comparable) date12, (java.awt.Paint) color13);
        piePlot1.setLabelPaint((java.awt.Paint) color13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range19 = numberAxis3D18.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double22 = numberAxis3D21.getFixedAutoRange();
        double double23 = numberAxis3D21.getUpperBound();
        java.awt.Shape shape24 = numberAxis3D21.getUpArrow();
        numberAxis3D18.setUpArrow(shape24);
        int int26 = xYPlot16.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D18);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        int int28 = xYPlot16.indexOf(xYDataset27);
        java.awt.Paint paint29 = xYPlot16.getDomainTickBandPaint();
        xYPlot16.clearRangeMarkers();
        java.awt.Stroke stroke31 = xYPlot16.getDomainCrosshairStroke();
        piePlot1.setBaseSectionOutlineStroke(stroke31);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        piePlot1.setSimpleLabelOffset(rectangleInsets5);
        double double8 = rectangleInsets5.calculateLeftInset(97.0d);
        double double10 = rectangleInsets5.calculateLeftInset((double) (-1));
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.plot.Plot plot5 = piePlot1.getRootPlot();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) 1, (java.awt.Paint) color7);
        java.awt.Color color9 = java.awt.Color.BLUE;
        piePlot1.setLabelShadowPaint((java.awt.Paint) color9);
        piePlot1.setShadowYOffset((double) 1.0f);
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=-1.0]", (int) (short) 1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double7 = numberAxis3D6.getFixedAutoRange();
        double double8 = numberAxis3D6.getUpperBound();
        java.awt.Font font9 = numberAxis3D6.getTickLabelFont();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis3D6.java2DToValue((double) 10L, rectangle2D11, rectangleEdge12);
        categoryPlot0.setRangeAxis(500, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, true);
        java.awt.Font font17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot18.getFixedDomainAxisSpace();
        categoryPlot18.clearRangeAxes();
        categoryPlot18.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray23 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer22 };
        categoryPlot18.setRenderers(categoryItemRendererArray23);
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("Pie Plot", font17, (org.jfree.chart.plot.Plot) categoryPlot18, true);
        java.awt.RenderingHints renderingHints27 = jFreeChart26.getRenderingHints();
        java.awt.Stroke stroke28 = jFreeChart26.getBorderStroke();
        categoryPlot0.setRangeGridlineStroke(stroke28);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D32 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D32.setMaximumCategoryLabelWidthRatio(10.0f);
        java.util.Date date35 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color36 = java.awt.Color.BLACK;
        categoryAxis3D32.setTickLabelPaint((java.lang.Comparable) date35, (java.awt.Paint) color36);
        categoryAxis3D32.configure();
        categoryPlot0.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D32);
        org.jfree.chart.plot.CategoryMarker categoryMarker40 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertNotNull(categoryItemRendererArray23);
        org.junit.Assert.assertNotNull(renderingHints27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(color36);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot1.zoomRangeAxes(10.0d, plotRenderingInfo3, point2D4, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot1.setRenderer((int) (short) 1, xYItemRenderer8);
        boolean boolean10 = rectangleAnchor0.equals((java.lang.Object) xYPlot1);
        boolean boolean11 = xYPlot1.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot1.getDomainAxis();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(valueAxis12);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        java.lang.String str2 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font3 = categoryAxis3D2.getLabelFont();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font3);
        org.jfree.chart.text.TextFragment textFragment5 = null;
        textLine4.addFragment(textFragment5);
        org.jfree.chart.text.TextBlock textBlock7 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textBlock7.getLineAlignment();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        textBlock7.draw(graphics2D9, (float) ' ', (float) 10L, textBlockAnchor12, (float) (short) 1, 0.0f, (double) (byte) 1);
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine();
        textBlock7.addLine(textLine17);
        java.awt.Font font21 = null;
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.jfree.chart.text.TextMeasurer textMeasurer24 = null;
        org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("", font21, (java.awt.Paint) color22, (float) (-1L), textMeasurer24);
        org.jfree.chart.text.TextLine textLine26 = null;
        textBlock25.addLine(textLine26);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D30 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font31 = categoryAxis3D30.getLabelFont();
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        textBlock25.addLine("Pie Plot", font31, (java.awt.Paint) color32);
        org.jfree.chart.plot.RingPlot ringPlot34 = new org.jfree.chart.plot.RingPlot();
        ringPlot34.zoom(100.0d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D38 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke39 = categoryAxis3D38.getTickMarkStroke();
        java.awt.Paint paint40 = categoryAxis3D38.getTickLabelPaint();
        ringPlot34.setLabelPaint(paint40);
        org.jfree.chart.text.TextFragment textFragment42 = new org.jfree.chart.text.TextFragment("ThreadContext", font31, paint40);
        textLine17.removeFragment(textFragment42);
        textLine4.addFragment(textFragment42);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(textBlock25);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainGridlineStroke();
        java.awt.Paint paint2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeCrosshairPaint(paint2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot0.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.zoom(100.0d);
        java.awt.Paint paint3 = ringPlot0.getLabelBackgroundPaint();
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceText("");
        org.jfree.chart.ui.Library[] libraryArray3 = projectInfo0.getLibraries();
        projectInfo0.setLicenceName("Pie 3D Plot");
        projectInfo0.setVersion("Rotation.ANTICLOCKWISE");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray3);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.plot.Plot plot5 = piePlot1.getRootPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D8.setMaximumCategoryLabelWidthRatio(10.0f);
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color12 = java.awt.Color.BLACK;
        categoryAxis3D8.setTickLabelPaint((java.lang.Comparable) date11, (java.awt.Paint) color12);
        piePlot1.setSectionPaint((java.lang.Comparable) "ThreadContext", (java.awt.Paint) color12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Font font16 = piePlot1.getLabelFont();
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Color color2 = java.awt.Color.RED;
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color2);
        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
        projectInfo4.setLicenceText("");
        org.jfree.chart.ui.Library[] libraryArray7 = projectInfo4.getLibraries();
        boolean boolean8 = color2.equals((java.lang.Object) libraryArray7);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(projectInfo4);
        org.junit.Assert.assertNotNull(libraryArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D2.getCategoryStart((-1), (int) ' ', rectangle2D5, rectangleEdge6);
        java.util.List list8 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        categoryPlot0.drawBackgroundImage(graphics2D9, rectangle2D10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 10, plotRenderingInfo13, point2D14, true);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot0.getDomainAxisLocation((int) (byte) 1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent19);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot2.getFixedDomainAxisSpace();
        categoryPlot2.clearRangeAxes();
        categoryPlot2.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, true);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment12, verticalAlignment13, (double) (byte) 1, (double) 10);
        boolean boolean18 = flowArrangement16.equals((java.lang.Object) 0.0d);
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection20 = polarPlot19.getLegendItems();
        java.util.Iterator iterator21 = legendItemCollection20.iterator();
        boolean boolean22 = flowArrangement16.equals((java.lang.Object) iterator21);
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot23);
        org.jfree.chart.util.VerticalAlignment verticalAlignment25 = legendTitle24.getVerticalAlignment();
        double double26 = legendTitle24.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendTitle24.getPadding();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        org.jfree.chart.plot.PiePlotState piePlotState29 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo28);
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        piePlotState29.setExplodedPieArea(rectangle2D30);
        double double32 = piePlotState29.getTotal();
        piePlotState29.setLatestAngle((double) (short) -1);
        java.awt.geom.Rectangle2D rectangle2D35 = piePlotState29.getLinkArea();
        org.jfree.chart.entity.EntityCollection entityCollection36 = piePlotState29.getEntityCollection();
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D40 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = categoryAxis3D40.getCategoryStart((-1), (int) ' ', rectangle2D43, rectangleEdge44);
        boolean boolean46 = textTitle38.equals((java.lang.Object) categoryAxis3D40);
        textTitle38.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color49 = java.awt.Color.BLACK;
        textTitle38.setBackgroundPaint((java.awt.Paint) color49);
        java.awt.geom.Rectangle2D rectangle2D51 = textTitle38.getBounds();
        piePlotState29.setLinkArea(rectangle2D51);
        flowArrangement16.add((org.jfree.chart.block.Block) legendTitle24, (java.lang.Object) rectangle2D51);
        try {
            categoryPlot2.drawBackground(graphics2D11, rectangle2D51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertNotNull(iterator21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(verticalAlignment25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D35);
        org.junit.Assert.assertNull(entityCollection36);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(rectangle2D51);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double1 = rectangleInsets0.getTop();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment3, (double) (byte) 1, (double) 10);
        boolean boolean8 = flowArrangement6.equals((java.lang.Object) 0.0d);
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = polarPlot9.getLegendItems();
        java.util.Iterator iterator11 = legendItemCollection10.iterator();
        boolean boolean12 = flowArrangement6.equals((java.lang.Object) iterator11);
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot13);
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = legendTitle14.getVerticalAlignment();
        double double16 = legendTitle14.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle14.getPadding();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.PiePlotState piePlotState19 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo18);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        piePlotState19.setExplodedPieArea(rectangle2D20);
        double double22 = piePlotState19.getTotal();
        piePlotState19.setLatestAngle((double) (short) -1);
        java.awt.geom.Rectangle2D rectangle2D25 = piePlotState19.getLinkArea();
        org.jfree.chart.entity.EntityCollection entityCollection26 = piePlotState19.getEntityCollection();
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D30 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = null;
        double double35 = categoryAxis3D30.getCategoryStart((-1), (int) ' ', rectangle2D33, rectangleEdge34);
        boolean boolean36 = textTitle28.equals((java.lang.Object) categoryAxis3D30);
        textTitle28.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color39 = java.awt.Color.BLACK;
        textTitle28.setBackgroundPaint((java.awt.Paint) color39);
        java.awt.geom.Rectangle2D rectangle2D41 = textTitle28.getBounds();
        piePlotState19.setLinkArea(rectangle2D41);
        flowArrangement6.add((org.jfree.chart.block.Block) legendTitle14, (java.lang.Object) rectangle2D41);
        rectangleInsets0.trim(rectangle2D41);
        org.jfree.chart.entity.ChartEntity chartEntity45 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D41);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator46 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator47 = null;
        java.lang.String str48 = chartEntity45.getImageMapAreaTag(toolTipTagFragmentGenerator46, uRLTagFragmentGenerator47);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(iterator11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D25);
        org.junit.Assert.assertNull(entityCollection26);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "" + "'", str48.equals(""));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.plot.Plot plot5 = piePlot1.getRootPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = null;
        piePlot1.setLabelGenerator(pieSectionLabelGenerator6);
        piePlot1.setStartAngle(2.0d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke12 = categoryAxis3D11.getTickMarkStroke();
        piePlot1.setBaseSectionOutlineStroke(stroke12);
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.String str2 = multiplePiePlot1.getPlotType();
        double double3 = multiplePiePlot1.getLimit();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        float float5 = ringPlot4.getForegroundAlpha();
        ringPlot4.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke10 = xYPlot9.getDomainGridlineStroke();
        boolean boolean11 = ringPlot4.equals((java.lang.Object) xYPlot9);
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot9.getDomainAxisLocation(255);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        multiplePiePlot1.setOutlineStroke(stroke14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double3 = numberAxis3D2.getFixedAutoRange();
        double double4 = numberAxis3D2.getUpperBound();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range7 = numberAxis3D6.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double10 = numberAxis3D9.getFixedAutoRange();
        double double11 = numberAxis3D9.getUpperBound();
        java.awt.Shape shape12 = numberAxis3D9.getUpArrow();
        numberAxis3D6.setUpArrow(shape12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, xYItemRenderer14);
        java.awt.Paint paint16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot15.setDomainGridlinePaint(paint16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.plot.PiePlotState piePlotState20 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        piePlotState20.setExplodedPieArea(rectangle2D21);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        piePlotState20.setLinkArea(rectangle2D23);
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke26 = ringPlot25.getSeparatorStroke();
        java.awt.Paint paint27 = ringPlot25.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double29 = rectangleInsets28.getTop();
        ringPlot25.setLabelPadding(rectangleInsets28);
        double double32 = rectangleInsets28.extendWidth(0.4d);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double35 = numberAxis3D34.getLowerMargin();
        org.jfree.data.general.PieDataset pieDataset36 = null;
        org.jfree.chart.plot.PiePlot piePlot37 = new org.jfree.chart.plot.PiePlot(pieDataset36);
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        piePlot37.drawBackgroundImage(graphics2D38, rectangle2D39);
        org.jfree.chart.plot.Plot plot41 = piePlot37.getRootPlot();
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot37.setSectionOutlinePaint((java.lang.Comparable) 1, (java.awt.Paint) color43);
        numberAxis3D34.setLabelPaint((java.awt.Paint) color43);
        org.jfree.chart.title.TextTitle textTitle48 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D50 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        double double55 = categoryAxis3D50.getCategoryStart((-1), (int) ' ', rectangle2D53, rectangleEdge54);
        boolean boolean56 = textTitle48.equals((java.lang.Object) categoryAxis3D50);
        textTitle48.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color59 = java.awt.Color.BLACK;
        textTitle48.setBackgroundPaint((java.awt.Paint) color59);
        java.awt.geom.Rectangle2D rectangle2D61 = textTitle48.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace63 = categoryPlot62.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot64 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke65 = ringPlot64.getSeparatorStroke();
        categoryPlot62.setDomainGridlineStroke(stroke65);
        org.jfree.chart.axis.AxisLocation axisLocation68 = null;
        categoryPlot62.setDomainAxisLocation((int) ' ', axisLocation68);
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = categoryPlot62.getRangeAxisEdge();
        double double71 = numberAxis3D34.valueToJava2D(0.0d, rectangle2D61, rectangleEdge70);
        rectangleInsets28.trim(rectangle2D61);
        piePlotState20.setLinkArea(rectangle2D61);
        try {
            xYPlot15.drawBackground(graphics2D18, rectangle2D61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 2.4d + "'", double32 == 2.4d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.05d + "'", double35 == 0.05d);
        org.junit.Assert.assertNotNull(plot41);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNull(axisSpace63);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(rectangleEdge70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.setLabelAngle((double) 10L);
        numberAxis3D1.resizeRange((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double7 = numberAxis3D6.getFixedAutoRange();
        double double8 = numberAxis3D6.getUpperBound();
        java.awt.Font font9 = numberAxis3D6.getTickLabelFont();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis3D6.java2DToValue((double) 10L, rectangle2D11, rectangleEdge12);
        categoryPlot0.setRangeAxis(500, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, true);
        java.awt.Font font17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot18.getFixedDomainAxisSpace();
        categoryPlot18.clearRangeAxes();
        categoryPlot18.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray23 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer22 };
        categoryPlot18.setRenderers(categoryItemRendererArray23);
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("Pie Plot", font17, (org.jfree.chart.plot.Plot) categoryPlot18, true);
        java.awt.RenderingHints renderingHints27 = jFreeChart26.getRenderingHints();
        java.awt.Stroke stroke28 = jFreeChart26.getBorderStroke();
        categoryPlot0.setRangeGridlineStroke(stroke28);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D32 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D32.setMaximumCategoryLabelWidthRatio(10.0f);
        java.util.Date date35 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color36 = java.awt.Color.BLACK;
        categoryAxis3D32.setTickLabelPaint((java.lang.Comparable) date35, (java.awt.Paint) color36);
        categoryAxis3D32.configure();
        categoryPlot0.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D32);
        categoryPlot0.setAnchorValue((-1.0d));
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertNotNull(categoryItemRendererArray23);
        org.junit.Assert.assertNotNull(renderingHints27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(color36);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        double double3 = numberAxis3D1.getUpperBound();
        java.awt.Font font4 = numberAxis3D1.getTickLabelFont();
        java.lang.String str5 = numberAxis3D1.getLabelURL();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        categoryPlot0.setAnchorValue((double) '#', true);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem9 = legendItemCollection7.get(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(legendItemCollection7);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getSeparatorStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator2);
        java.awt.Paint paint4 = ringPlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke5 = ringPlot0.getLabelOutlineStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setTickMarkOutsideLength(0.0f);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke6 = categoryAxis3D5.getTickMarkStroke();
        int int7 = categoryAxis3D5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = categoryAxis3D5.getCategoryLabelPositions();
        categoryAxis3D1.setCategoryLabelPositions(categoryLabelPositions8);
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) (-1.95d), "Pie 3D Plot");
        double double13 = categoryAxis3D1.getLowerMargin();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        double double3 = numberAxis3D1.getUpperBound();
        boolean boolean4 = numberAxis3D1.isAxisLineVisible();
        numberAxis3D1.setTickMarkOutsideLength(0.5f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean6 = numberAxis3D1.isPositiveArrowVisible();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range9 = numberAxis3D8.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double12 = numberAxis3D11.getFixedAutoRange();
        double double13 = numberAxis3D11.getUpperBound();
        java.awt.Shape shape14 = numberAxis3D11.getUpArrow();
        numberAxis3D8.setUpArrow(shape14);
        numberAxis3D1.setDownArrow(shape14);
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape14);
        java.lang.String str18 = chartEntity17.getToolTipText();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        double double3 = numberAxis3D1.getUpperBound();
        java.awt.Shape shape4 = numberAxis3D1.getUpArrow();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, 0, (int) (byte) 10, (java.lang.Comparable) 1.0d, "ThreadContext", "hi!");
        pieSectionEntity11.setSectionKey((java.lang.Comparable) (short) 1);
        pieSectionEntity11.setSectionIndex(3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot2.getFixedDomainAxisSpace();
        categoryPlot2.clearRangeAxes();
        categoryPlot2.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, true);
        java.awt.RenderingHints renderingHints11 = jFreeChart10.getRenderingHints();
        java.awt.Stroke stroke12 = jFreeChart10.getBorderStroke();
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart10.removeProgressListener(chartProgressListener13);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertNotNull(renderingHints11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        legendTitle1.setHeight((double) (byte) 100);
        org.jfree.chart.block.BlockContainer blockContainer4 = legendTitle1.getItemContainer();
        boolean boolean5 = blockContainer4.isEmpty();
        boolean boolean6 = blockContainer4.isEmpty();
        java.lang.Object obj7 = blockContainer4.clone();
        org.junit.Assert.assertNotNull(blockContainer4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.configureDomainAxes();
        java.awt.Font font4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        categoryPlot0.setNoDataMessageFont(font4);
        org.jfree.chart.plot.Marker marker6 = null;
        try {
            boolean boolean7 = categoryPlot0.removeRangeMarker(marker6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("", (int) ' ', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomRangeAxes(10.0d, plotRenderingInfo2, point2D3, false);
        java.awt.Stroke stroke6 = xYPlot0.getDomainGridlineStroke();
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = null;
        dateAxis0.setTimeline(timeline1);
        try {
            boolean boolean4 = dateAxis0.isHiddenValue((long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis3D3.getCategoryStart((-1), (int) ' ', rectangle2D6, rectangleEdge7);
        boolean boolean9 = textTitle1.equals((java.lang.Object) categoryAxis3D3);
        textTitle1.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color12 = java.awt.Color.BLACK;
        textTitle1.setBackgroundPaint((java.awt.Paint) color12);
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle1.getBounds();
        textTitle1.setExpandToFitSpace(false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(rectangle2D14);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomRangeAxes(10.0d, plotRenderingInfo2, point2D3, false);
        java.awt.Stroke stroke6 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.Plot plot7 = xYPlot0.getParent();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(plot7);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getSeparatorStroke();
        java.awt.Paint paint2 = ringPlot0.getShadowPaint();
        org.jfree.chart.util.Rotation rotation3 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        ringPlot0.setDirection(rotation3);
        double double5 = rotation3.getFactor();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        piePlot7.drawBackgroundImage(graphics2D8, rectangle2D9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        piePlot7.setSimpleLabelOffset(rectangleInsets11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot7.getSimpleLabelOffset();
        boolean boolean14 = rotation3.equals((java.lang.Object) rectangleInsets13);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.awt.Color color0 = java.awt.Color.yellow;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        double double2 = textTitle1.getContentYOffset();
        java.lang.String str3 = textTitle1.getURLText();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot4);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = ringPlot4.getLabelDistributor();
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace8 = color7.getColorSpace();
        java.awt.color.ColorSpace colorSpace9 = color7.getColorSpace();
        ringPlot4.setLabelShadowPaint((java.awt.Paint) color7);
        textTitle1.setBackgroundPaint((java.awt.Paint) color7);
        textTitle1.setToolTipText("RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=-1.0]");
        double double14 = textTitle1.getContentXOffset();
        java.lang.String str15 = textTitle1.getURLText();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(colorSpace8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getLegendItems();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double5 = numberAxis3D4.getFixedAutoRange();
        numberAxis3D4.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean9 = numberAxis3D4.isPositiveArrowVisible();
        java.lang.Object obj10 = numberAxis3D4.clone();
        java.text.NumberFormat numberFormat11 = null;
        numberAxis3D4.setNumberFormatOverride(numberFormat11);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double15 = numberAxis3D14.getFixedAutoRange();
        double double16 = numberAxis3D14.getUpperBound();
        java.awt.Shape shape17 = numberAxis3D14.getUpArrow();
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis3D14.setAxisLineStroke(stroke18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range22 = numberAxis3D21.getRange();
        org.jfree.data.Range range24 = org.jfree.data.Range.shift(range22, (double) (-1.0f));
        numberAxis3D14.setDefaultAutoRange(range22);
        numberAxis3D4.setRangeWithMargins(range22);
        numberAxis3D4.setLowerMargin((double) (short) 1);
        int int29 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D4);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot0.getDomainAxis();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNull(categoryAxis30);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        xYPlot5.setRenderer(8, xYItemRenderer9);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        try {
            boolean boolean13 = xYPlot5.removeDomainMarker(marker11, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean6 = numberAxis3D1.isPositiveArrowVisible();
        java.lang.Object obj7 = numberAxis3D1.clone();
        double double8 = numberAxis3D1.getLowerBound();
        numberAxis3D1.setLabelAngle(45.0d);
        boolean boolean11 = numberAxis3D1.isVisible();
        numberAxis3D1.setAutoRangeStickyZero(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D1 = xYPlot0.getQuadrantOrigin();
        java.awt.Stroke stroke2 = xYPlot0.getDomainZeroBaselineStroke();
        org.junit.Assert.assertNotNull(point2D1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot1);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor3 = ringPlot1.getLabelDistributor();
        java.awt.Color color4 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        java.awt.color.ColorSpace colorSpace6 = color4.getColorSpace();
        ringPlot1.setLabelShadowPaint((java.awt.Paint) color4);
        java.lang.Class<?> wildcardClass8 = ringPlot1.getClass();
        java.io.InputStream inputStream9 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("RectangleEdge.LEFT", (java.lang.Class) wildcardClass8);
        java.lang.ClassLoader classLoader10 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass8);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(colorSpace6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(inputStream9);
        org.junit.Assert.assertNotNull(classLoader10);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double3 = numberAxis3D2.getFixedAutoRange();
        double double4 = numberAxis3D2.getUpperBound();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range7 = numberAxis3D6.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double10 = numberAxis3D9.getFixedAutoRange();
        double double11 = numberAxis3D9.getUpperBound();
        java.awt.Shape shape12 = numberAxis3D9.getUpArrow();
        numberAxis3D6.setUpArrow(shape12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, xYItemRenderer14);
        java.awt.Paint paint16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot15.setDomainGridlinePaint(paint16);
        java.awt.Paint paint18 = xYPlot15.getDomainCrosshairPaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot5.getDomainAxisLocation(255);
        java.lang.String str10 = xYPlot5.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        xYPlot5.setRenderer((int) '4', xYItemRenderer12, false);
        xYPlot5.setRangeCrosshairValue(0.08d, true);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "XY Plot" + "'", str10.equals("XY Plot"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        legendTitle1.setHeight((double) (byte) 100);
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = polarPlot4.getLegendItems();
        java.util.Iterator iterator6 = legendItemCollection5.iterator();
        boolean boolean7 = legendTitle1.equals((java.lang.Object) legendItemCollection5);
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder();
        legendTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = blockBorder8.getInsets();
        double double12 = rectangleInsets10.extendWidth((-3.0d));
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(iterator6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font3 = categoryAxis3D2.getLabelFont();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) color4, (float) (byte) 100);
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace8 = color7.getColorSpace();
        java.awt.Color color9 = java.awt.Color.black;
        java.awt.Color color10 = java.awt.Color.MAGENTA;
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace12 = color11.getColorSpace();
        java.awt.color.ColorSpace colorSpace13 = color11.getColorSpace();
        float[] floatArray20 = new float[] { (short) 10, 0L, '4', ' ', 10L, 'a' };
        float[] floatArray21 = color10.getComponents(colorSpace13, floatArray20);
        float[] floatArray22 = color9.getRGBComponents(floatArray21);
        float[] floatArray23 = color7.getRGBColorComponents(floatArray22);
        float[] floatArray24 = color4.getRGBComponents(floatArray23);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(colorSpace8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace12);
        org.junit.Assert.assertNotNull(colorSpace13);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setAutoTickUnitSelection(true, false);
        numberAxis3D1.setUpperMargin(0.05d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot5.getDomainAxisLocation(255);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot5.getRendererForDataset(xYDataset10);
        java.awt.Paint paint12 = xYPlot5.getDomainCrosshairPaint();
        xYPlot5.setDomainGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(xYItemRenderer11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double7 = numberAxis3D6.getFixedAutoRange();
        double double8 = numberAxis3D6.getUpperBound();
        java.awt.Font font9 = numberAxis3D6.getTickLabelFont();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis3D6.java2DToValue((double) 10L, rectangle2D11, rectangleEdge12);
        categoryPlot0.setRangeAxis(500, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, true);
        java.awt.Font font17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot18.getFixedDomainAxisSpace();
        categoryPlot18.clearRangeAxes();
        categoryPlot18.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray23 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer22 };
        categoryPlot18.setRenderers(categoryItemRendererArray23);
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("Pie Plot", font17, (org.jfree.chart.plot.Plot) categoryPlot18, true);
        java.awt.RenderingHints renderingHints27 = jFreeChart26.getRenderingHints();
        java.awt.Stroke stroke28 = jFreeChart26.getBorderStroke();
        categoryPlot0.setRangeGridlineStroke(stroke28);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D32 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D32.setMaximumCategoryLabelWidthRatio(10.0f);
        java.util.Date date35 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color36 = java.awt.Color.BLACK;
        categoryAxis3D32.setTickLabelPaint((java.lang.Comparable) date35, (java.awt.Paint) color36);
        categoryAxis3D32.configure();
        categoryPlot0.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D32);
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertNotNull(categoryItemRendererArray23);
        org.junit.Assert.assertNotNull(renderingHints27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(color36);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke7 = categoryAxis3D6.getTickMarkStroke();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray10 = new java.awt.Stroke[] { stroke3, stroke4, stroke7, stroke8, stroke9 };
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke13 = categoryAxis3D12.getTickMarkStroke();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke17 = categoryAxis3D16.getTickMarkStroke();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray19 = new java.awt.Stroke[] { stroke13, stroke14, stroke17, stroke18 };
        java.awt.Shape shape20 = null;
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] { shape20 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray2, strokeArray10, strokeArray19, shapeArray21);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = categoryAxis3D24.getCategoryStart((-1), (int) ' ', rectangle2D27, rectangleEdge28);
        boolean boolean30 = defaultDrawingSupplier22.equals((java.lang.Object) rectangleEdge28);
        ringPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        java.awt.Paint paint32 = ringPlot0.getLabelBackgroundPaint();
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(strokeArray19);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = ringPlot0.getToolTipGenerator();
        java.awt.Paint paint4 = ringPlot0.getSectionOutlinePaint((java.lang.Comparable) (byte) 10);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = null;
        dateAxis0.setTimeline(timeline1);
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D5.setMaximumCategoryLabelWidthRatio(10.0f);
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color9 = java.awt.Color.BLACK;
        categoryAxis3D5.setTickLabelPaint((java.lang.Comparable) date8, (java.awt.Paint) color9);
        try {
            dateAxis0.setRange(date3, date8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textBlock0.getLineAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, 49.5d, (double) 100);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = polarPlot6.getLegendItems();
        boolean boolean8 = polarPlot6.isAngleGridlinesVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        polarPlot6.datasetChanged(datasetChangeEvent9);
        boolean boolean11 = horizontalAlignment1.equals((java.lang.Object) polarPlot6);
        java.awt.Stroke stroke12 = polarPlot6.getRadiusGridlineStroke();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "");
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "hi!", jFreeChart6, chartChangeEventType7);
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        chartChangeEvent8.setChart(jFreeChart9);
        java.lang.String str11 = chartChangeEvent8.toString();
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=hi!]" + "'", str11.equals("org.jfree.chart.event.ChartChangeEvent[source=hi!]"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.awt.Color color0 = java.awt.Color.pink;
        java.awt.Color color1 = java.awt.Color.green;
        java.awt.Color color2 = java.awt.Color.MAGENTA;
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace4 = color3.getColorSpace();
        java.awt.color.ColorSpace colorSpace5 = color3.getColorSpace();
        float[] floatArray12 = new float[] { (short) 10, 0L, '4', ' ', 10L, 'a' };
        float[] floatArray13 = color2.getComponents(colorSpace5, floatArray12);
        java.awt.Color color14 = java.awt.Color.MAGENTA;
        java.awt.Color color15 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace16 = color15.getColorSpace();
        java.awt.color.ColorSpace colorSpace17 = color15.getColorSpace();
        float[] floatArray24 = new float[] { (short) 10, 0L, '4', ' ', 10L, 'a' };
        float[] floatArray25 = color14.getComponents(colorSpace17, floatArray24);
        float[] floatArray26 = color1.getComponents(colorSpace5, floatArray24);
        float[] floatArray27 = color0.getColorComponents(floatArray26);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(colorSpace16);
        org.junit.Assert.assertNotNull(colorSpace17);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Paint paint2 = textTitle1.getBackgroundPaint();
        java.lang.Object obj3 = textTitle1.clone();
        textTitle1.setText("poly");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle1.getTextAlignment();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.plot.Plot plot9 = piePlot5.getRootPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = ringPlot0.initialise(graphics2D2, rectangle2D3, piePlot5, (java.lang.Integer) 10, plotRenderingInfo11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        ringPlot0.markerChanged(markerChangeEvent13);
        boolean boolean15 = ringPlot0.getLabelLinksVisible();
        org.jfree.chart.util.Rotation rotation16 = ringPlot0.getDirection();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rotation16);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        java.lang.Object obj3 = dateAxis0.clone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = null;
        try {
            java.util.Date date5 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainGridlineStroke();
        java.awt.Paint paint2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeCrosshairPaint(paint2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot0.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        try {
            boolean boolean9 = xYPlot0.removeRangeMarker((int) (short) 1, marker7, layer8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) (-1L), textMeasurer4);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font9 = categoryAxis3D8.getLabelFont();
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("hi!", font9);
        textBlock5.addLine(textLine10);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textBlock5.setLineAlignment(horizontalAlignment12);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = textBlock5.getLineAlignment();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        try {
            textBlock5.draw(graphics2D15, 0.0f, (float) 100L, textBlockAnchor18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setExplodedPieArea(rectangle2D2);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        piePlotState1.setLinkArea(rectangle2D4);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke7 = ringPlot6.getSeparatorStroke();
        java.awt.Paint paint8 = ringPlot6.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double10 = rectangleInsets9.getTop();
        ringPlot6.setLabelPadding(rectangleInsets9);
        double double13 = rectangleInsets9.extendWidth(0.4d);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double16 = numberAxis3D15.getLowerMargin();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        piePlot18.drawBackgroundImage(graphics2D19, rectangle2D20);
        org.jfree.chart.plot.Plot plot22 = piePlot18.getRootPlot();
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot18.setSectionOutlinePaint((java.lang.Comparable) 1, (java.awt.Paint) color24);
        numberAxis3D15.setLabelPaint((java.awt.Paint) color24);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D31 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        double double36 = categoryAxis3D31.getCategoryStart((-1), (int) ' ', rectangle2D34, rectangleEdge35);
        boolean boolean37 = textTitle29.equals((java.lang.Object) categoryAxis3D31);
        textTitle29.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color40 = java.awt.Color.BLACK;
        textTitle29.setBackgroundPaint((java.awt.Paint) color40);
        java.awt.geom.Rectangle2D rectangle2D42 = textTitle29.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace44 = categoryPlot43.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot45 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke46 = ringPlot45.getSeparatorStroke();
        categoryPlot43.setDomainGridlineStroke(stroke46);
        org.jfree.chart.axis.AxisLocation axisLocation49 = null;
        categoryPlot43.setDomainAxisLocation((int) ' ', axisLocation49);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = categoryPlot43.getRangeAxisEdge();
        double double52 = numberAxis3D15.valueToJava2D(0.0d, rectangle2D42, rectangleEdge51);
        rectangleInsets9.trim(rectangle2D42);
        piePlotState1.setLinkArea(rectangle2D42);
        double double55 = piePlotState1.getPieHRadius();
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.4d + "'", double13 == 2.4d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(plot22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNull(axisSpace44);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "");
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "hi!", jFreeChart6, chartChangeEventType7);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = chartChangeEvent8.getType();
        java.awt.Font font11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot12.getFixedDomainAxisSpace();
        categoryPlot12.clearRangeAxes();
        categoryPlot12.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray17 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer16 };
        categoryPlot12.setRenderers(categoryItemRendererArray17);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("Pie Plot", font11, (org.jfree.chart.plot.Plot) categoryPlot12, true);
        java.awt.RenderingHints renderingHints21 = jFreeChart20.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle22 = jFreeChart20.getLegend();
        jFreeChart20.setTextAntiAlias(true);
        chartChangeEvent8.setChart(jFreeChart20);
        java.util.List list26 = jFreeChart20.getSubtitles();
        org.jfree.chart.event.ChartChangeListener chartChangeListener27 = null;
        try {
            jFreeChart20.removeChangeListener(chartChangeListener27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(chartChangeEventType9);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNotNull(categoryItemRendererArray17);
        org.junit.Assert.assertNotNull(renderingHints21);
        org.junit.Assert.assertNotNull(legendTitle22);
        org.junit.Assert.assertNotNull(list26);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNull(valueAxis4);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.String str2 = multiplePiePlot1.getPlotType();
        double double3 = multiplePiePlot1.getLimit();
        org.jfree.chart.util.TableOrder tableOrder4 = null;
        try {
            multiplePiePlot1.setDataExtractOrder(tableOrder4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.zoom(100.0d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke5 = categoryAxis3D4.getTickMarkStroke();
        java.awt.Paint paint6 = categoryAxis3D4.getTickLabelPaint();
        ringPlot0.setLabelPaint(paint6);
        java.awt.Paint paint8 = ringPlot0.getBaseSectionOutlinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        ringPlot0.setBaseSectionOutlinePaint((java.awt.Paint) color9);
        java.awt.Stroke stroke11 = ringPlot0.getLabelOutlineStroke();
        ringPlot0.setLabelLinkMargin((double) 100.0f);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getSeparatorStroke();
        java.awt.Paint paint2 = ringPlot0.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double4 = rectangleInsets3.getTop();
        ringPlot0.setLabelPadding(rectangleInsets3);
        java.awt.Stroke stroke6 = ringPlot0.getSeparatorStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font3 = categoryAxis3D2.getLabelFont();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font3);
        org.jfree.chart.text.TextFragment textFragment5 = null;
        textLine4.addFragment(textFragment5);
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Image image9 = polarPlot8.getBackgroundImage();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        polarPlot8.setRenderer(polarItemRenderer10);
        java.awt.Font font12 = polarPlot8.getAngleLabelFont();
        java.awt.Paint paint13 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("UnitType.RELATIVE", font12, paint13, 10.0f);
        textLine4.addFragment(textFragment15);
        org.jfree.chart.text.TextFragment textFragment17 = textLine4.getLastTextFragment();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(image9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textFragment17);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double4 = numberAxis3D3.getFixedAutoRange();
        double double5 = numberAxis3D3.getUpperBound();
        java.awt.Shape shape6 = numberAxis3D3.getUpArrow();
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis3D3.setAxisLineStroke(stroke7);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer9);
        numberAxis3D3.setLowerMargin((double) (byte) 0);
        numberAxis3D3.setAutoTickUnitSelection(false, true);
        boolean boolean16 = numberAxis3D3.isAutoTickUnitSelection();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(35.0d, (double) (short) 10, (double) (-1L), 49.5d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomRangeAxes(10.0d, plotRenderingInfo2, point2D3, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer((int) (short) 1, xYItemRenderer7);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        double double3 = numberAxis3D1.getUpperBound();
        double double4 = numberAxis3D1.getFixedAutoRange();
        org.jfree.data.RangeType rangeType5 = numberAxis3D1.getRangeType();
        java.lang.String str6 = numberAxis3D1.getLabel();
        boolean boolean7 = numberAxis3D1.isPositiveArrowVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rangeType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D1 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.plot.Marker marker3 = null;
        org.jfree.chart.util.Layer layer4 = null;
        try {
            boolean boolean5 = xYPlot0.removeDomainMarker((int) '4', marker3, layer4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(point2D1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.zoom(100.0d);
        double double3 = ringPlot0.getInteriorGap();
        ringPlot0.setLabelLinksVisible(true);
        java.awt.Paint paint6 = ringPlot0.getBaseSectionOutlinePaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        piePlot1.setSimpleLabelOffset(rectangleInsets5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot1.getSimpleLabelOffset();
        java.awt.Paint paint8 = piePlot1.getLabelPaint();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomRangeAxes(10.0d, plotRenderingInfo2, point2D3, false);
        org.jfree.chart.axis.AxisSpace axisSpace6 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        xYPlot0.setDataset(xYDataset7);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.junit.Assert.assertNull(axisSpace6);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        int int11 = categoryPlot0.getDomainAxisCount();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range14 = numberAxis3D13.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double17 = numberAxis3D16.getFixedAutoRange();
        double double18 = numberAxis3D16.getUpperBound();
        java.awt.Shape shape19 = numberAxis3D16.getUpArrow();
        numberAxis3D13.setUpArrow(shape19);
        java.awt.Color color21 = java.awt.Color.green;
        numberAxis3D13.setTickLabelPaint((java.awt.Paint) color21);
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color21);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets(0.08d, 10.0d, (double) (byte) 10, (double) '#');
        java.awt.Color color29 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.block.BlockBorder blockBorder30 = new org.jfree.chart.block.BlockBorder(rectangleInsets28, (java.awt.Paint) color29);
        java.awt.Color color31 = java.awt.Color.MAGENTA;
        java.awt.Color color32 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace33 = color32.getColorSpace();
        java.awt.color.ColorSpace colorSpace34 = color32.getColorSpace();
        float[] floatArray41 = new float[] { (short) 10, 0L, '4', ' ', 10L, 'a' };
        float[] floatArray42 = color31.getComponents(colorSpace34, floatArray41);
        float[] floatArray43 = color29.getRGBColorComponents(floatArray41);
        float[] floatArray44 = color21.getRGBComponents(floatArray43);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(colorSpace33);
        org.junit.Assert.assertNotNull(colorSpace34);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        categoryPlot0.clearDomainMarkers((int) (byte) 10);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot7.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke10 = ringPlot9.getSeparatorStroke();
        java.awt.Paint paint11 = ringPlot9.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double13 = rectangleInsets12.getTop();
        ringPlot9.setLabelPadding(rectangleInsets12);
        java.awt.Color color15 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace16 = color15.getColorSpace();
        ringPlot9.setLabelBackgroundPaint((java.awt.Paint) color15);
        categoryPlot7.setNoDataMessagePaint((java.awt.Paint) color15);
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot7.setRangeAxisLocation(100, axisLocation20, false);
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot7.getRangeAxisLocation(1);
        categoryPlot0.setRangeAxisLocation(axisLocation24);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(colorSpace16);
        org.junit.Assert.assertNotNull(axisLocation24);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.plot.Plot plot5 = piePlot1.getRootPlot();
        double double6 = piePlot1.getMinimumArcAngleToDraw();
        org.jfree.data.general.DatasetGroup datasetGroup7 = piePlot1.getDatasetGroup();
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-5d + "'", double6 == 1.0E-5d);
        org.junit.Assert.assertNull(datasetGroup7);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot2.getFixedDomainAxisSpace();
        categoryPlot2.clearRangeAxes();
        categoryPlot2.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, true);
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        blockContainer11.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement12);
        java.util.List list14 = blockContainer11.getBlocks();
        jFreeChart10.setSubtitles(list14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double19 = numberAxis3D18.getFixedAutoRange();
        numberAxis3D18.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean23 = numberAxis3D18.isPositiveArrowVisible();
        numberAxis3D18.centerRange(0.2d);
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D29 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = categoryAxis3D29.getCategoryStart((-1), (int) ' ', rectangle2D32, rectangleEdge33);
        boolean boolean35 = textTitle27.equals((java.lang.Object) categoryAxis3D29);
        textTitle27.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color38 = java.awt.Color.BLACK;
        textTitle27.setBackgroundPaint((java.awt.Paint) color38);
        java.awt.geom.Rectangle2D rectangle2D40 = textTitle27.getBounds();
        numberAxis3D18.setLeftArrow((java.awt.Shape) rectangle2D40);
        try {
            jFreeChart10.draw(graphics2D16, rectangle2D40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(rectangle2D40);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateLeftInset((double) 1.0f);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.lang.String str5 = categoryAxis3D4.getLabelURL();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("XY Plot");
        categoryAxis3D9.setLabelToolTip("ThreadContext");
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.AxisState axisState13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double16 = numberAxis3D15.getLowerMargin();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        piePlot18.drawBackgroundImage(graphics2D19, rectangle2D20);
        org.jfree.chart.plot.Plot plot22 = piePlot18.getRootPlot();
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot18.setSectionOutlinePaint((java.lang.Comparable) 1, (java.awt.Paint) color24);
        numberAxis3D15.setLabelPaint((java.awt.Paint) color24);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D31 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        double double36 = categoryAxis3D31.getCategoryStart((-1), (int) ' ', rectangle2D34, rectangleEdge35);
        boolean boolean37 = textTitle29.equals((java.lang.Object) categoryAxis3D31);
        textTitle29.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color40 = java.awt.Color.BLACK;
        textTitle29.setBackgroundPaint((java.awt.Paint) color40);
        java.awt.geom.Rectangle2D rectangle2D42 = textTitle29.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace44 = categoryPlot43.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot45 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke46 = ringPlot45.getSeparatorStroke();
        categoryPlot43.setDomainGridlineStroke(stroke46);
        org.jfree.chart.axis.AxisLocation axisLocation49 = null;
        categoryPlot43.setDomainAxisLocation((int) ' ', axisLocation49);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = categoryPlot43.getRangeAxisEdge();
        double double52 = numberAxis3D15.valueToJava2D(0.0d, rectangle2D42, rectangleEdge51);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        java.util.List list54 = categoryAxis3D9.refreshTicks(graphics2D12, axisState13, rectangle2D42, rectangleEdge53);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double56 = categoryAxis3D4.getCategoryEnd((int) (byte) 10, 500, rectangle2D42, rectangleEdge55);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType57 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = rectangleInsets0.createAdjustedRectangle(rectangle2D42, lengthAdjustmentType57, lengthAdjustmentType58);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(plot22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNull(axisSpace44);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(list54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D59);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Paint paint2 = textTitle1.getBackgroundPaint();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot3);
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = legendTitle4.getVerticalAlignment();
        textTitle1.setVerticalAlignment(verticalAlignment5);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = textTitle1.getVerticalAlignment();
        textTitle1.setPadding((double) 100.0f, (double) (byte) 1, (double) 2, (double) 0L);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, (double) (-1.0f));
        org.jfree.data.Range range17 = rectangleConstraint16.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = rectangleConstraint16.toFixedHeight((double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = rectangleConstraint16.toFixedWidth((double) 100L);
        try {
            org.jfree.chart.util.Size2D size2D22 = textTitle1.arrange(graphics2D13, rectangleConstraint16);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(rectangleConstraint19);
        org.junit.Assert.assertNotNull(rectangleConstraint21);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.plot.Plot plot9 = piePlot5.getRootPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = ringPlot0.initialise(graphics2D2, rectangle2D3, piePlot5, (java.lang.Integer) 10, plotRenderingInfo11);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range15 = numberAxis3D14.getRange();
        org.jfree.data.Range range17 = org.jfree.data.Range.shift(range15, (double) (-1.0f));
        org.jfree.data.Range range20 = org.jfree.data.Range.shift(range15, (double) 0.5f, false);
        boolean boolean21 = ringPlot0.equals((java.lang.Object) range15);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.mapDatasetToRangeAxis((int) (byte) 1, (int) '4');
        boolean boolean12 = categoryPlot0.getDrawSharedDomainAxis();
        java.awt.Paint paint13 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent14);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double21 = numberAxis3D20.getFixedAutoRange();
        double double22 = numberAxis3D20.getUpperBound();
        java.awt.Shape shape23 = numberAxis3D20.getUpArrow();
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis3D20.setAxisLineStroke(stroke24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis3D20, xYItemRenderer26);
        org.jfree.chart.plot.RingPlot ringPlot28 = new org.jfree.chart.plot.RingPlot();
        float float29 = ringPlot28.getForegroundAlpha();
        ringPlot28.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke34 = xYPlot33.getDomainGridlineStroke();
        boolean boolean35 = ringPlot28.equals((java.lang.Object) xYPlot33);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot33.getDomainAxisLocation(255);
        xYPlot27.setRangeAxisLocation(axisLocation37, true);
        categoryPlot0.setRangeAxisLocation(0, axisLocation37);
        float float41 = categoryPlot0.getBackgroundAlpha();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 1.0f + "'", float29 == 1.0f);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 1.0f + "'", float41 == 1.0f);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        categoryPlot0.setAnchorValue((double) '#', true);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getLegendItems();
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot8);
        legendTitle9.setHeight((double) (byte) 100);
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection13 = polarPlot12.getLegendItems();
        java.util.Iterator iterator14 = legendItemCollection13.iterator();
        boolean boolean15 = legendTitle9.equals((java.lang.Object) legendItemCollection13);
        legendItemCollection7.addAll(legendItemCollection13);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(iterator14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        java.awt.color.ColorSpace colorSpace2 = color0.getColorSpace();
        int int3 = color0.getBlue();
        java.awt.Color color4 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        java.awt.color.ColorSpace colorSpace6 = color4.getColorSpace();
        java.awt.Color color7 = java.awt.Color.cyan;
        java.awt.Color color8 = java.awt.Color.green;
        java.awt.Color color9 = java.awt.Color.MAGENTA;
        java.awt.Color color10 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace11 = color10.getColorSpace();
        java.awt.color.ColorSpace colorSpace12 = color10.getColorSpace();
        float[] floatArray19 = new float[] { (short) 10, 0L, '4', ' ', 10L, 'a' };
        float[] floatArray20 = color9.getComponents(colorSpace12, floatArray19);
        java.awt.Color color21 = java.awt.Color.MAGENTA;
        java.awt.Color color22 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace23 = color22.getColorSpace();
        java.awt.color.ColorSpace colorSpace24 = color22.getColorSpace();
        float[] floatArray31 = new float[] { (short) 10, 0L, '4', ' ', 10L, 'a' };
        float[] floatArray32 = color21.getComponents(colorSpace24, floatArray31);
        float[] floatArray33 = color8.getComponents(colorSpace12, floatArray31);
        float[] floatArray34 = color7.getComponents(floatArray33);
        float[] floatArray35 = color0.getComponents(colorSpace6, floatArray34);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(colorSpace6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(colorSpace11);
        org.junit.Assert.assertNotNull(colorSpace12);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(colorSpace23);
        org.junit.Assert.assertNotNull(colorSpace24);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairValue((double) (short) 1, true);
        java.awt.Stroke stroke4 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        float float6 = ringPlot5.getForegroundAlpha();
        ringPlot5.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke11 = xYPlot10.getDomainGridlineStroke();
        boolean boolean12 = ringPlot5.equals((java.lang.Object) xYPlot10);
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot10.getDomainAxisLocation(255);
        xYPlot0.setRangeAxisLocation(axisLocation14, true);
        xYPlot0.setDomainCrosshairValue(0.14d);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7);
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairValue((double) (short) 1, true);
        java.awt.Stroke stroke4 = xYPlot0.getRangeZeroBaselineStroke();
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setDomainZeroBaselinePaint(paint5);
        boolean boolean7 = xYPlot0.isOutlineVisible();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setExplodedPieArea(rectangle2D2);
        double double4 = piePlotState1.getLatestAngle();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D5.setTickMarkInsideLength((float) (byte) 1);
        java.awt.Stroke stroke8 = categoryAxis3D5.getTickMarkStroke();
        java.util.List list9 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D5);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getRangeAxisEdge((int) (short) 10);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairValue((double) (short) 1, true);
        boolean boolean4 = xYPlot0.isRangeZoomable();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("Pie 3D Plot");
        int int7 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D6);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis3D6.setMarkerBand(markerAxisBand8);
        double double10 = numberAxis3D6.getFixedAutoRange();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.lang.String str2 = categoryAxis3D1.getLabelURL();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis3D1.getTickLabelInsets();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        polarPlot0.addCornerTextItem("hi!");
        org.jfree.chart.plot.Plot plot4 = polarPlot0.getRootPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        polarPlot0.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = polarPlot0.getRadiusGridlinePaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainZeroBaselineStroke();
        double double2 = xYPlot0.getDomainCrosshairValue();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers((int) (byte) 10, layer4);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double11 = numberAxis3D10.getFixedAutoRange();
        double double12 = numberAxis3D10.getUpperBound();
        java.awt.Shape shape13 = numberAxis3D10.getUpArrow();
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis3D10.setAxisLineStroke(stroke14);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset7, valueAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer16);
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot();
        float float19 = ringPlot18.getForegroundAlpha();
        ringPlot18.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke24 = xYPlot23.getDomainGridlineStroke();
        boolean boolean25 = ringPlot18.equals((java.lang.Object) xYPlot23);
        org.jfree.chart.axis.AxisLocation axisLocation27 = xYPlot23.getDomainAxisLocation(255);
        xYPlot17.setRangeAxisLocation(axisLocation27, true);
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Image image31 = polarPlot30.getBackgroundImage();
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = polarPlot30.getOrientation();
        org.jfree.data.general.PieDataset pieDataset33 = null;
        org.jfree.chart.plot.PiePlot piePlot34 = new org.jfree.chart.plot.PiePlot(pieDataset33);
        double double35 = piePlot34.getMinimumArcAngleToDraw();
        boolean boolean36 = plotOrientation32.equals((java.lang.Object) double35);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation27, plotOrientation32);
        try {
            xYPlot0.setDomainAxisLocation((int) (short) -1, axisLocation27, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNull(image31);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0E-5d + "'", double35 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace4 = color3.getColorSpace();
        java.awt.color.ColorSpace colorSpace5 = color3.getColorSpace();
        ringPlot0.setLabelShadowPaint((java.awt.Paint) color3);
        try {
            ringPlot0.setInteriorGap((double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (32.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertNotNull(colorSpace5);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        polarPlot0.addCornerTextItem("");
        int int4 = polarPlot0.getSeriesCount();
        java.awt.Stroke stroke5 = polarPlot0.getRadiusGridlineStroke();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setExplodedPieArea(rectangle2D2);
        double double4 = piePlotState1.getTotal();
        piePlotState1.setPassesRequired(0);
        org.jfree.chart.entity.EntityCollection entityCollection7 = piePlotState1.getEntityCollection();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(entityCollection7);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.configureDomainAxes();
        java.awt.Font font4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        categoryPlot0.setNoDataMessageFont(font4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(valueAxis7);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = null;
        waferMapPlot0.rendererChanged(rendererChangeEvent1);
        java.lang.String str3 = waferMapPlot0.getPlotType();
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = waferMapPlot0.getDataset();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        waferMapPlot0.rendererChanged(rendererChangeEvent5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        waferMapPlot0.rendererChanged(rendererChangeEvent7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "WMAP_Plot" + "'", str3.equals("WMAP_Plot"));
        org.junit.Assert.assertNull(waferMapDataset4);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Paint paint2 = textTitle1.getBackgroundPaint();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot3);
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = legendTitle4.getVerticalAlignment();
        textTitle1.setVerticalAlignment(verticalAlignment5);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = textTitle1.getVerticalAlignment();
        textTitle1.setPadding((double) 100.0f, (double) (byte) 1, (double) 2, (double) 0L);
        double double13 = textTitle1.getContentXOffset();
        double double14 = textTitle1.getHeight();
        java.awt.Paint paint15 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        textTitle1.setBackgroundPaint(paint15);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.junit.Assert.assertNotNull(rectangleConstraint0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double7 = numberAxis3D6.getFixedAutoRange();
        double double8 = numberAxis3D6.getUpperBound();
        java.awt.Font font9 = numberAxis3D6.getTickLabelFont();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis3D6.java2DToValue((double) 10L, rectangle2D11, rectangleEdge12);
        categoryPlot0.setRangeAxis(500, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, true);
        java.awt.Font font17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot18.getFixedDomainAxisSpace();
        categoryPlot18.clearRangeAxes();
        categoryPlot18.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray23 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer22 };
        categoryPlot18.setRenderers(categoryItemRendererArray23);
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("Pie Plot", font17, (org.jfree.chart.plot.Plot) categoryPlot18, true);
        java.awt.RenderingHints renderingHints27 = jFreeChart26.getRenderingHints();
        java.awt.Stroke stroke28 = jFreeChart26.getBorderStroke();
        categoryPlot0.setRangeGridlineStroke(stroke28);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D32 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D32.setMaximumCategoryLabelWidthRatio(10.0f);
        java.util.Date date35 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color36 = java.awt.Color.BLACK;
        categoryAxis3D32.setTickLabelPaint((java.lang.Comparable) date35, (java.awt.Paint) color36);
        categoryAxis3D32.configure();
        categoryPlot0.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D32);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot0.getDomainAxis((int) (byte) -1);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertNotNull(categoryItemRendererArray23);
        org.junit.Assert.assertNotNull(renderingHints27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNull(categoryAxis41);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.mapDatasetToRangeAxis((int) (byte) 1, (int) '4');
        categoryPlot0.setBackgroundImageAlignment((int) (byte) 100);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = ringPlot0.getToolTipGenerator();
        ringPlot0.setInnerSeparatorExtension((double) 10.0f);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "");
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "hi!", jFreeChart6, chartChangeEventType7);
        java.lang.Object obj9 = chartChangeEvent8.getSource();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo15 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "");
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "hi!", jFreeChart16, chartChangeEventType17);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = chartChangeEvent18.getType();
        java.awt.Font font21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace23 = categoryPlot22.getFixedDomainAxisSpace();
        categoryPlot22.clearRangeAxes();
        categoryPlot22.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray27 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer26 };
        categoryPlot22.setRenderers(categoryItemRendererArray27);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("Pie Plot", font21, (org.jfree.chart.plot.Plot) categoryPlot22, true);
        java.awt.RenderingHints renderingHints31 = jFreeChart30.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle32 = jFreeChart30.getLegend();
        jFreeChart30.setTextAntiAlias(true);
        chartChangeEvent18.setChart(jFreeChart30);
        chartChangeEvent8.setChart(jFreeChart30);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = jFreeChart30.getCategoryPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent38 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot37);
        org.junit.Assert.assertTrue("'" + obj9 + "' != '" + "hi!" + "'", obj9.equals("hi!"));
        org.junit.Assert.assertNull(chartChangeEventType19);
        org.junit.Assert.assertNull(axisSpace23);
        org.junit.Assert.assertNotNull(categoryItemRendererArray27);
        org.junit.Assert.assertNotNull(renderingHints31);
        org.junit.Assert.assertNotNull(legendTitle32);
        org.junit.Assert.assertNotNull(categoryPlot37);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        categoryPlot0.setAnchorValue((double) '#', true);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.mapDatasetToRangeAxis((int) (byte) 1, (int) '4');
        boolean boolean12 = categoryPlot0.getDrawSharedDomainAxis();
        java.awt.Paint paint13 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent14);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double21 = numberAxis3D20.getFixedAutoRange();
        double double22 = numberAxis3D20.getUpperBound();
        java.awt.Shape shape23 = numberAxis3D20.getUpArrow();
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis3D20.setAxisLineStroke(stroke24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis3D20, xYItemRenderer26);
        org.jfree.chart.plot.RingPlot ringPlot28 = new org.jfree.chart.plot.RingPlot();
        float float29 = ringPlot28.getForegroundAlpha();
        ringPlot28.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke34 = xYPlot33.getDomainGridlineStroke();
        boolean boolean35 = ringPlot28.equals((java.lang.Object) xYPlot33);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot33.getDomainAxisLocation(255);
        xYPlot27.setRangeAxisLocation(axisLocation37, true);
        categoryPlot0.setRangeAxisLocation(0, axisLocation37);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = categoryPlot0.getDomainAxis((int) (byte) 10);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 1.0f + "'", float29 == 1.0f);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(categoryAxis44);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D2.getCategoryStart((-1), (int) ' ', rectangle2D5, rectangleEdge6);
        java.util.List list8 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        categoryAxis3D2.setMaximumCategoryLabelWidthRatio((float) 8);
        categoryAxis3D2.setMaximumCategoryLabelLines((int) 'a');
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        numberAxis3D1.resizeRange((double) (byte) 10, (double) (short) -1);
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = categoryPlot0.getDrawingSupplier();
        int int3 = categoryPlot0.getRangeAxisCount();
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        try {
            dateAxis0.setRange((double) 255, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "");
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "hi!", jFreeChart6, chartChangeEventType7);
        java.lang.Object obj9 = chartChangeEvent8.getSource();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo15 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "");
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "hi!", jFreeChart16, chartChangeEventType17);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = chartChangeEvent18.getType();
        java.awt.Font font21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace23 = categoryPlot22.getFixedDomainAxisSpace();
        categoryPlot22.clearRangeAxes();
        categoryPlot22.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray27 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer26 };
        categoryPlot22.setRenderers(categoryItemRendererArray27);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("Pie Plot", font21, (org.jfree.chart.plot.Plot) categoryPlot22, true);
        java.awt.RenderingHints renderingHints31 = jFreeChart30.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle32 = jFreeChart30.getLegend();
        jFreeChart30.setTextAntiAlias(true);
        chartChangeEvent18.setChart(jFreeChart30);
        chartChangeEvent8.setChart(jFreeChart30);
        org.jfree.chart.title.TextTitle textTitle37 = jFreeChart30.getTitle();
        org.junit.Assert.assertTrue("'" + obj9 + "' != '" + "hi!" + "'", obj9.equals("hi!"));
        org.junit.Assert.assertNull(chartChangeEventType19);
        org.junit.Assert.assertNull(axisSpace23);
        org.junit.Assert.assertNotNull(categoryItemRendererArray27);
        org.junit.Assert.assertNotNull(renderingHints31);
        org.junit.Assert.assertNotNull(legendTitle32);
        org.junit.Assert.assertNotNull(textTitle37);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("poly", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        polarPlot0.addCornerTextItem("hi!");
        org.jfree.chart.plot.Plot plot4 = polarPlot0.getRootPlot();
        java.awt.Paint paint5 = polarPlot0.getRadiusGridlinePaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.zoom(100.0d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke5 = categoryAxis3D4.getTickMarkStroke();
        java.awt.Paint paint6 = categoryAxis3D4.getTickLabelPaint();
        ringPlot0.setLabelPaint(paint6);
        ringPlot0.setIgnoreZeroValues(false);
        java.awt.Paint paint10 = ringPlot0.getLabelOutlinePaint();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        legendTitle1.setHeight((double) (byte) 100);
        org.jfree.chart.block.BlockContainer blockContainer4 = legendTitle1.getItemContainer();
        boolean boolean5 = blockContainer4.isEmpty();
        blockContainer4.setHeight((double) (byte) 10);
        boolean boolean8 = blockContainer4.isEmpty();
        org.junit.Assert.assertNotNull(blockContainer4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace4 = color3.getColorSpace();
        java.awt.color.ColorSpace colorSpace5 = color3.getColorSpace();
        ringPlot0.setLabelShadowPaint((java.awt.Paint) color3);
        double double7 = ringPlot0.getLabelLinkMargin();
        boolean boolean8 = ringPlot0.getSeparatorsVisible();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.025d + "'", double7 == 0.025d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot5.getDomainAxisLocation(255);
        java.lang.String str10 = xYPlot5.getPlotType();
        java.awt.Paint paint11 = xYPlot5.getDomainZeroBaselinePaint();
        xYPlot5.setForegroundAlpha((float) 10L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "XY Plot" + "'", str10.equals("XY Plot"));
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font3 = categoryAxis3D2.getLabelFont();
        categoryAxis3D2.setLabelAngle((double) (-1));
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryAxis3D2.setTickLabelPaint((java.lang.Comparable) 97.0d, paint7);
        java.lang.Object obj9 = categoryAxis3D2.clone();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double12 = numberAxis3D11.getFixedAutoRange();
        numberAxis3D11.zoomRange((double) (short) 0, (double) 1L);
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis3D11.setDownArrow(shape16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, categoryItemRenderer18);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMinimumArcAngleToDraw();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-5d + "'", double2 == 1.0E-5d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Image image3 = polarPlot2.getBackgroundImage();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        polarPlot2.setRenderer(polarItemRenderer4);
        java.awt.Font font6 = polarPlot2.getAngleLabelFont();
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("UnitType.RELATIVE", font6, paint7, 10.0f);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_GREEN;
        int int11 = color10.getRed();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer14 = new org.jfree.chart.text.G2TextMeasurer(graphics2D13);
        try {
            org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("ThreadContext", font6, (java.awt.Paint) color10, 0.0f, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setAutoTickUnitSelection(true, false);
        boolean boolean5 = numberAxis3D1.isTickLabelsVisible();
        java.lang.Object obj6 = numberAxis3D1.clone();
        double double7 = numberAxis3D1.getUpperMargin();
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis3D1.setStandardTickUnits(tickUnitSource8);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(tickUnitSource8);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = xYPlot0.getDataRange(valueAxis2);
        java.awt.Stroke stroke4 = xYPlot0.getRangeZeroBaselineStroke();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace7 = categoryPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke9 = ringPlot8.getSeparatorStroke();
        java.awt.Paint paint10 = ringPlot8.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double12 = rectangleInsets11.getTop();
        ringPlot8.setLabelPadding(rectangleInsets11);
        java.awt.Color color14 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace15 = color14.getColorSpace();
        ringPlot8.setLabelBackgroundPaint((java.awt.Paint) color14);
        categoryPlot6.setNoDataMessagePaint((java.awt.Paint) color14);
        org.jfree.chart.axis.AxisLocation axisLocation19 = null;
        categoryPlot6.setRangeAxisLocation(100, axisLocation19, false);
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot6.getRangeAxisLocation(1);
        xYPlot0.setRangeAxisLocation(axisLocation23);
        org.jfree.chart.axis.ValueAxis valueAxis25 = xYPlot0.getDomainAxis();
        boolean boolean26 = xYPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(axisSpace7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(colorSpace15);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.setRangeCrosshairVisible(true);
        categoryPlot0.clearRangeAxes();
        java.awt.Stroke stroke5 = categoryPlot0.getDomainGridlineStroke();
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setDarkerSides(true);
        java.lang.String str3 = piePlot3D0.getPlotType();
        piePlot3D0.setDepthFactor((-1.0d));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pie 3D Plot" + "'", str3.equals("Pie 3D Plot"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Paint paint2 = textTitle1.getBackgroundPaint();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot3);
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = legendTitle4.getVerticalAlignment();
        textTitle1.setVerticalAlignment(verticalAlignment5);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = textTitle1.getVerticalAlignment();
        textTitle1.setPadding((double) 100.0f, (double) (byte) 1, (double) 2, (double) 0L);
        java.awt.Font font13 = textTitle1.getFont();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) (-1L), textMeasurer4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        textBlock5.draw(graphics2D6, 100.0f, 1.0f, textBlockAnchor9);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        java.awt.Paint paint4 = ringPlot2.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double6 = rectangleInsets5.getTop();
        ringPlot2.setLabelPadding(rectangleInsets5);
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        ringPlot2.setLabelBackgroundPaint((java.awt.Paint) color8);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color8);
        org.jfree.chart.axis.AxisLocation axisLocation13 = null;
        categoryPlot0.setRangeAxisLocation(100, axisLocation13, false);
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot0.getRangeAxisLocation(1);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double22 = numberAxis3D21.getFixedAutoRange();
        numberAxis3D21.setTickMarkInsideLength((float) '4');
        org.jfree.data.Range range25 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D21);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNull(range25);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = polarPlot0.getLegendItems();
        boolean boolean2 = polarPlot0.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        polarPlot0.zoomDomainAxes(0.14d, plotRenderingInfo4, point2D5);
        boolean boolean7 = polarPlot0.isRangeZoomable();
        java.awt.Paint paint8 = polarPlot0.getOutlinePaint();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getInfo();
        basicProjectInfo0.setInfo("Pie Plot");
        basicProjectInfo0.setVersion("Multiple Pie Plot");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        categoryAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot2);
        java.lang.Object obj4 = polarPlot2.clone();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        polarPlot0.addCornerTextItem("hi!");
        org.jfree.chart.plot.Plot plot4 = polarPlot0.getRootPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        polarPlot0.addChangeListener(plotChangeListener5);
        java.awt.Font font8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot9.getFixedDomainAxisSpace();
        categoryPlot9.clearRangeAxes();
        categoryPlot9.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("Pie Plot", font8, (org.jfree.chart.plot.Plot) categoryPlot9, true);
        jFreeChart17.setBorderVisible(false);
        polarPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart17);
        jFreeChart17.fireChartChanged();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        float float4 = ringPlot3.getForegroundAlpha();
        ringPlot3.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke9 = xYPlot8.getDomainGridlineStroke();
        boolean boolean10 = ringPlot3.equals((java.lang.Object) xYPlot8);
        org.jfree.chart.axis.AxisLocation axisLocation12 = xYPlot8.getDomainAxisLocation(255);
        xYPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation12, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double17 = numberAxis3D16.getFixedAutoRange();
        numberAxis3D16.setLabelAngle((double) 10L);
        org.jfree.data.Range range20 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D16);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setDomainZeroBaselineStroke(stroke21);
        boolean boolean23 = xYPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean6 = numberAxis3D1.isPositiveArrowVisible();
        java.lang.Object obj7 = numberAxis3D1.clone();
        double double8 = numberAxis3D1.getLowerBound();
        numberAxis3D1.setLabelAngle(45.0d);
        float float11 = numberAxis3D1.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getDomainMarkers(layer2);
        categoryPlot0.setAnchorValue(Double.POSITIVE_INFINITY, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot0.setDomainAxis(100, categoryAxis8);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(collection3);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "");
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "hi!", jFreeChart6, chartChangeEventType7);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = chartChangeEvent8.getType();
        java.awt.Font font11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot12.getFixedDomainAxisSpace();
        categoryPlot12.clearRangeAxes();
        categoryPlot12.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray17 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer16 };
        categoryPlot12.setRenderers(categoryItemRendererArray17);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("Pie Plot", font11, (org.jfree.chart.plot.Plot) categoryPlot12, true);
        java.awt.RenderingHints renderingHints21 = jFreeChart20.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle22 = jFreeChart20.getLegend();
        jFreeChart20.setTextAntiAlias(true);
        chartChangeEvent8.setChart(jFreeChart20);
        int int26 = jFreeChart20.getBackgroundImageAlignment();
        java.awt.Paint paint27 = jFreeChart20.getBackgroundPaint();
        org.junit.Assert.assertNull(chartChangeEventType9);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNotNull(categoryItemRendererArray17);
        org.junit.Assert.assertNotNull(renderingHints21);
        org.junit.Assert.assertNotNull(legendTitle22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 15 + "'", int26 == 15);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        double double2 = textTitle1.getContentYOffset();
        java.lang.String str3 = textTitle1.getURLText();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot4);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = ringPlot4.getLabelDistributor();
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace8 = color7.getColorSpace();
        java.awt.color.ColorSpace colorSpace9 = color7.getColorSpace();
        ringPlot4.setLabelShadowPaint((java.awt.Paint) color7);
        textTitle1.setBackgroundPaint((java.awt.Paint) color7);
        java.lang.String str12 = textTitle1.getID();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(colorSpace8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot5.getDomainAxisLocation(255);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot5.getRendererForDataset(xYDataset10);
        xYPlot5.setRangeCrosshairValue(0.0d);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        piePlot15.drawBackgroundImage(graphics2D16, rectangle2D17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot15.setShadowPaint((java.awt.Paint) color19);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke23 = categoryAxis3D22.getTickMarkStroke();
        piePlot15.setLabelLinkStroke(stroke23);
        xYPlot5.setDomainCrosshairStroke(stroke23);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D28 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.lang.String str29 = categoryAxis3D28.getLabelURL();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D33 = new org.jfree.chart.axis.CategoryAxis3D("XY Plot");
        categoryAxis3D33.setLabelToolTip("ThreadContext");
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.axis.AxisState axisState37 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double40 = numberAxis3D39.getLowerMargin();
        org.jfree.data.general.PieDataset pieDataset41 = null;
        org.jfree.chart.plot.PiePlot piePlot42 = new org.jfree.chart.plot.PiePlot(pieDataset41);
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        piePlot42.drawBackgroundImage(graphics2D43, rectangle2D44);
        org.jfree.chart.plot.Plot plot46 = piePlot42.getRootPlot();
        java.awt.Color color48 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot42.setSectionOutlinePaint((java.lang.Comparable) 1, (java.awt.Paint) color48);
        numberAxis3D39.setLabelPaint((java.awt.Paint) color48);
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D55 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = null;
        double double60 = categoryAxis3D55.getCategoryStart((-1), (int) ' ', rectangle2D58, rectangleEdge59);
        boolean boolean61 = textTitle53.equals((java.lang.Object) categoryAxis3D55);
        textTitle53.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color64 = java.awt.Color.BLACK;
        textTitle53.setBackgroundPaint((java.awt.Paint) color64);
        java.awt.geom.Rectangle2D rectangle2D66 = textTitle53.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace68 = categoryPlot67.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot69 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke70 = ringPlot69.getSeparatorStroke();
        categoryPlot67.setDomainGridlineStroke(stroke70);
        org.jfree.chart.axis.AxisLocation axisLocation73 = null;
        categoryPlot67.setDomainAxisLocation((int) ' ', axisLocation73);
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = categoryPlot67.getRangeAxisEdge();
        double double76 = numberAxis3D39.valueToJava2D(0.0d, rectangle2D66, rectangleEdge75);
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = null;
        java.util.List list78 = categoryAxis3D33.refreshTicks(graphics2D36, axisState37, rectangle2D66, rectangleEdge77);
        org.jfree.chart.util.RectangleEdge rectangleEdge79 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double80 = categoryAxis3D28.getCategoryEnd((int) (byte) 10, 500, rectangle2D66, rectangleEdge79);
        try {
            xYPlot5.drawBackground(graphics2D26, rectangle2D66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(xYItemRenderer11);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
        org.junit.Assert.assertNotNull(plot46);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertNull(axisSpace68);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(rectangleEdge75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(list78);
        org.junit.Assert.assertNotNull(rectangleEdge79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        legendTitle1.setHeight((double) (byte) 100);
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = polarPlot4.getLegendItems();
        java.util.Iterator iterator6 = legendItemCollection5.iterator();
        boolean boolean7 = legendTitle1.equals((java.lang.Object) legendItemCollection5);
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder();
        legendTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder8);
        double double10 = legendTitle1.getHeight();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace12 = categoryPlot11.getFixedDomainAxisSpace();
        categoryPlot11.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot11.getDomainAxisEdge();
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge14);
        java.awt.Font font16 = legendTitle1.getItemFont();
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(iterator6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        double double2 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.plot.Plot plot3 = ringPlot0.getParent();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis3D3.getCategoryStart((-1), (int) ' ', rectangle2D6, rectangleEdge7);
        boolean boolean9 = textTitle1.equals((java.lang.Object) categoryAxis3D3);
        java.lang.String str10 = categoryAxis3D3.getLabelURL();
        categoryAxis3D3.setLabelToolTip("Pie Plot");
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        objectList0.set((int) (byte) 1, (java.lang.Object) color3);
        java.lang.Object obj5 = objectList0.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot5.getDomainAxisLocation(255);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot5.getDomainMarkers(layer10);
        xYPlot5.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "");
        java.lang.String str6 = basicProjectInfo5.getInfo();
        basicProjectInfo5.addOptionalLibrary("");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("XY Plot");
        categoryAxis3D1.setLabelToolTip("ThreadContext");
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double8 = numberAxis3D7.getLowerMargin();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        piePlot10.drawBackgroundImage(graphics2D11, rectangle2D12);
        org.jfree.chart.plot.Plot plot14 = piePlot10.getRootPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot10.setSectionOutlinePaint((java.lang.Comparable) 1, (java.awt.Paint) color16);
        numberAxis3D7.setLabelPaint((java.awt.Paint) color16);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis3D23.getCategoryStart((-1), (int) ' ', rectangle2D26, rectangleEdge27);
        boolean boolean29 = textTitle21.equals((java.lang.Object) categoryAxis3D23);
        textTitle21.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color32 = java.awt.Color.BLACK;
        textTitle21.setBackgroundPaint((java.awt.Paint) color32);
        java.awt.geom.Rectangle2D rectangle2D34 = textTitle21.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace36 = categoryPlot35.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot37 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke38 = ringPlot37.getSeparatorStroke();
        categoryPlot35.setDomainGridlineStroke(stroke38);
        org.jfree.chart.axis.AxisLocation axisLocation41 = null;
        categoryPlot35.setDomainAxisLocation((int) ' ', axisLocation41);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot35.getRangeAxisEdge();
        double double44 = numberAxis3D7.valueToJava2D(0.0d, rectangle2D34, rectangleEdge43);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        java.util.List list46 = categoryAxis3D1.refreshTicks(graphics2D4, axisState5, rectangle2D34, rectangleEdge45);
        java.util.Collection collection47 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list46);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(plot14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(axisSpace36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(collection47);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace2 = categoryPlot1.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke4 = ringPlot3.getSeparatorStroke();
        categoryPlot1.setDomainGridlineStroke(stroke4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot1.setDomainAxisLocation((int) ' ', axisLocation7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot1.getRangeAxisEdge();
        categoryPlot1.mapDatasetToRangeAxis((int) (byte) 1, (int) '4');
        boolean boolean13 = categoryPlot1.getDrawSharedDomainAxis();
        java.awt.Paint paint14 = categoryPlot1.getRangeCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = null;
        categoryPlot1.datasetChanged(datasetChangeEvent15);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double22 = numberAxis3D21.getFixedAutoRange();
        double double23 = numberAxis3D21.getUpperBound();
        java.awt.Shape shape24 = numberAxis3D21.getUpArrow();
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis3D21.setAxisLineStroke(stroke25);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset18, valueAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, xYItemRenderer27);
        org.jfree.chart.plot.RingPlot ringPlot29 = new org.jfree.chart.plot.RingPlot();
        float float30 = ringPlot29.getForegroundAlpha();
        ringPlot29.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke35 = xYPlot34.getDomainGridlineStroke();
        boolean boolean36 = ringPlot29.equals((java.lang.Object) xYPlot34);
        org.jfree.chart.axis.AxisLocation axisLocation38 = xYPlot34.getDomainAxisLocation(255);
        xYPlot28.setRangeAxisLocation(axisLocation38, true);
        categoryPlot1.setRangeAxisLocation(0, axisLocation38);
        java.lang.Class<?> wildcardClass42 = axisLocation38.getClass();
        java.net.URL uRL43 = org.jfree.chart.util.ObjectUtilities.getResource("RectangleAnchor.TOP_RIGHT", (java.lang.Class) wildcardClass42);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNull(uRL43);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("PieSection: 0, 10(1)", graphics2D1, (float) (byte) 10, 100.0f, textAnchor4, (double) 3, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot2.getFixedDomainAxisSpace();
        categoryPlot2.clearRangeAxes();
        categoryPlot2.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, true);
        java.awt.RenderingHints renderingHints11 = jFreeChart10.getRenderingHints();
        java.awt.Stroke stroke12 = jFreeChart10.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        try {
            java.awt.image.BufferedImage bufferedImage17 = jFreeChart10.createBufferedImage(15, (-4144960), (int) (byte) 1, chartRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (15) and height (-4144960) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertNotNull(renderingHints11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        polarPlot0.addCornerTextItem("");
        int int4 = polarPlot0.getSeriesCount();
        boolean boolean5 = polarPlot0.isSubplot();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot6);
        ringPlot6.setInnerSeparatorExtension((double) (short) 100);
        java.awt.Paint paint10 = ringPlot6.getLabelOutlinePaint();
        java.awt.Paint paint11 = ringPlot6.getLabelShadowPaint();
        polarPlot0.setRadiusGridlinePaint(paint11);
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = polarPlot0.getOrientation();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(plotOrientation13);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        xYPlot5.setRenderer(8, xYItemRenderer9);
        xYPlot5.setDomainCrosshairValue((double) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getSeparatorStroke();
        java.awt.Paint paint2 = ringPlot0.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double4 = rectangleInsets3.getTop();
        ringPlot0.setLabelPadding(rectangleInsets3);
        double double7 = rectangleInsets3.calculateTopInset((double) 100);
        double double9 = rectangleInsets3.calculateBottomInset(33.0d);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        int int3 = abstractPieLabelDistributor2.getItemCount();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMinimumArcAngleToDraw();
        piePlot1.setExplodePercent((java.lang.Comparable) 10.0f, (double) (-1L));
        java.lang.String str6 = piePlot1.getPlotType();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-5d + "'", double2 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Pie Plot" + "'", str6.equals("Pie Plot"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.awt.Color color0 = java.awt.Color.white;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo6 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "");
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "hi!", jFreeChart7, chartChangeEventType8);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = chartChangeEvent9.getType();
        java.awt.Font font12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot13.getFixedDomainAxisSpace();
        categoryPlot13.clearRangeAxes();
        categoryPlot13.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray18 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer17 };
        categoryPlot13.setRenderers(categoryItemRendererArray18);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("Pie Plot", font12, (org.jfree.chart.plot.Plot) categoryPlot13, true);
        java.awt.RenderingHints renderingHints22 = jFreeChart21.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle23 = jFreeChart21.getLegend();
        jFreeChart21.setTextAntiAlias(true);
        chartChangeEvent9.setChart(jFreeChart21);
        java.util.List list27 = jFreeChart21.getSubtitles();
        jFreeChart21.setAntiAlias(false);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType30 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart21, chartChangeEventType30);
        jFreeChart21.setNotify(false);
        org.jfree.chart.title.Title title34 = null;
        jFreeChart21.removeSubtitle(title34);
        java.awt.Image image36 = jFreeChart21.getBackgroundImage();
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D41 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        double double46 = categoryAxis3D41.getCategoryStart((-1), (int) ' ', rectangle2D44, rectangleEdge45);
        boolean boolean47 = textTitle39.equals((java.lang.Object) categoryAxis3D41);
        textTitle39.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color50 = java.awt.Color.BLACK;
        textTitle39.setBackgroundPaint((java.awt.Paint) color50);
        java.awt.geom.Rectangle2D rectangle2D52 = textTitle39.getBounds();
        try {
            jFreeChart21.addSubtitle(500, (org.jfree.chart.title.Title) textTitle39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNull(chartChangeEventType10);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(categoryItemRendererArray18);
        org.junit.Assert.assertNotNull(renderingHints22);
        org.junit.Assert.assertNotNull(legendTitle23);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertNotNull(chartChangeEventType30);
        org.junit.Assert.assertNull(image36);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(rectangle2D52);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        double double3 = numberAxis3D1.getUpperBound();
        java.awt.Shape shape4 = numberAxis3D1.getUpArrow();
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis3D1.setAxisLineStroke(stroke5);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range9 = numberAxis3D8.getRange();
        org.jfree.data.Range range11 = org.jfree.data.Range.shift(range9, (double) (-1.0f));
        numberAxis3D1.setDefaultAutoRange(range9);
        boolean boolean13 = numberAxis3D1.getAutoRangeIncludesZero();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.Color color1 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        java.awt.Color color0 = java.awt.Color.GREEN;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        legendTitle1.setHeight((double) (byte) 100);
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = polarPlot4.getLegendItems();
        java.util.Iterator iterator6 = legendItemCollection5.iterator();
        boolean boolean7 = legendTitle1.equals((java.lang.Object) legendItemCollection5);
        org.jfree.chart.LegendItem legendItem8 = null;
        legendItemCollection5.add(legendItem8);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(iterator6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) polarPlot0);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        waferMapPlot3.rendererChanged(rendererChangeEvent4);
        java.lang.String str6 = waferMapPlot3.getPlotType();
        org.jfree.data.general.WaferMapDataset waferMapDataset7 = waferMapPlot3.getDataset();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        waferMapPlot3.rendererChanged(rendererChangeEvent8);
        boolean boolean10 = polarPlot0.equals((java.lang.Object) rendererChangeEvent8);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "WMAP_Plot" + "'", str6.equals("WMAP_Plot"));
        org.junit.Assert.assertNull(waferMapDataset7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.configureDomainAxes();
        java.awt.Font font4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        categoryPlot0.setNoDataMessageFont(font4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        categoryPlot0.setRangeAxis(1, valueAxis8);
        categoryPlot0.configureRangeAxes();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Paint paint4 = textTitle3.getBackgroundPaint();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot5);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = legendTitle6.getVerticalAlignment();
        textTitle3.setVerticalAlignment(verticalAlignment7);
        java.lang.String str9 = verticalAlignment7.toString();
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment7, 1.0E-5d, (double) (short) 0);
        org.jfree.chart.block.ColumnArrangement columnArrangement15 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment7, 0.0d, (double) 10L);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "VerticalAlignment.CENTER" + "'", str9.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("Multiple Pie Plot");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot5);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = legendTitle6.getVerticalAlignment();
        double double8 = legendTitle6.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle6.getPadding();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.plot.PiePlotState piePlotState11 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        piePlotState11.setExplodedPieArea(rectangle2D12);
        double double14 = piePlotState11.getTotal();
        piePlotState11.setLatestAngle((double) (short) -1);
        java.awt.geom.Rectangle2D rectangle2D17 = piePlotState11.getLinkArea();
        org.jfree.chart.entity.EntityCollection entityCollection18 = piePlotState11.getEntityCollection();
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = categoryAxis3D22.getCategoryStart((-1), (int) ' ', rectangle2D25, rectangleEdge26);
        boolean boolean28 = textTitle20.equals((java.lang.Object) categoryAxis3D22);
        textTitle20.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color31 = java.awt.Color.BLACK;
        textTitle20.setBackgroundPaint((java.awt.Paint) color31);
        java.awt.geom.Rectangle2D rectangle2D33 = textTitle20.getBounds();
        piePlotState11.setLinkArea(rectangle2D33);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType35 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets9.createAdjustedRectangle(rectangle2D33, lengthAdjustmentType35, lengthAdjustmentType36);
        org.jfree.chart.plot.RingPlot ringPlot38 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot38);
        legendTitle39.setHeight((double) (byte) 100);
        org.jfree.chart.plot.PolarPlot polarPlot42 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection43 = polarPlot42.getLegendItems();
        java.util.Iterator iterator44 = legendItemCollection43.iterator();
        boolean boolean45 = legendTitle39.equals((java.lang.Object) legendItemCollection43);
        org.jfree.chart.block.BlockBorder blockBorder46 = new org.jfree.chart.block.BlockBorder();
        legendTitle39.setFrame((org.jfree.chart.block.BlockFrame) blockBorder46);
        double double48 = legendTitle39.getHeight();
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace50 = categoryPlot49.getFixedDomainAxisSpace();
        categoryPlot49.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = categoryPlot49.getDomainAxisEdge();
        legendTitle39.setLegendItemGraphicEdge(rectangleEdge52);
        try {
            double double54 = categoryAxis3D1.getCategoryJava2DCoordinate(categoryAnchor2, (int) 'a', 2, rectangle2D37, rectangleEdge52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D17);
        org.junit.Assert.assertNull(entityCollection18);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(legendItemCollection43);
        org.junit.Assert.assertNotNull(iterator44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 100.0d + "'", double48 == 100.0d);
        org.junit.Assert.assertNull(axisSpace50);
        org.junit.Assert.assertNotNull(rectangleEdge52);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.mapDatasetToRangeAxis((int) (byte) 1, (int) '4');
        boolean boolean12 = categoryPlot0.getDrawSharedDomainAxis();
        java.awt.Paint paint13 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent14);
        java.awt.Paint paint16 = categoryPlot0.getRangeGridlinePaint();
        categoryPlot0.configureRangeAxes();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font2 = categoryAxis3D1.getLabelFont();
        categoryAxis3D1.setLabelAngle((double) (-1));
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryAxis3D1.setTickLabelPaint((java.lang.Comparable) 97.0d, paint6);
        categoryAxis3D1.configure();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D1.setFixedDimension(98.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double6 = numberAxis3D5.getFixedAutoRange();
        double double7 = numberAxis3D5.getUpperBound();
        java.awt.Shape shape8 = numberAxis3D5.getUpArrow();
        numberAxis3D2.setUpArrow(shape8);
        int int10 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D2);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        int int12 = xYPlot0.indexOf(xYDataset11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot0.getRangeAxisLocation((-1));
        xYPlot0.setForegroundAlpha((float) 10);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot2.getFixedDomainAxisSpace();
        categoryPlot2.clearRangeAxes();
        categoryPlot2.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, true);
        java.awt.RenderingHints renderingHints11 = jFreeChart10.getRenderingHints();
        java.awt.Stroke stroke12 = jFreeChart10.getBorderStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        jFreeChart10.setPadding(rectangleInsets13);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D16 = rectangleInsets13.createInsetRectangle(rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertNotNull(renderingHints11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline3 = null;
        dateAxis2.setTimeline(timeline3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getInfo();
        org.jfree.chart.ui.Library[] libraryArray2 = basicProjectInfo0.getOptionalLibraries();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke4 = xYPlot3.getDomainZeroBaselineStroke();
        double double5 = xYPlot3.getDomainCrosshairValue();
        java.awt.Color color6 = java.awt.Color.white;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo12 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "");
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "hi!", jFreeChart13, chartChangeEventType14);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = chartChangeEvent15.getType();
        java.awt.Font font18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot19.getFixedDomainAxisSpace();
        categoryPlot19.clearRangeAxes();
        categoryPlot19.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray24 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer23 };
        categoryPlot19.setRenderers(categoryItemRendererArray24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("Pie Plot", font18, (org.jfree.chart.plot.Plot) categoryPlot19, true);
        java.awt.RenderingHints renderingHints28 = jFreeChart27.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle29 = jFreeChart27.getLegend();
        jFreeChart27.setTextAntiAlias(true);
        chartChangeEvent15.setChart(jFreeChart27);
        java.util.List list33 = jFreeChart27.getSubtitles();
        jFreeChart27.setAntiAlias(false);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType36 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color6, jFreeChart27, chartChangeEventType36);
        jFreeChart27.setNotify(false);
        xYPlot3.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart27);
        boolean boolean41 = jFreeChart27.isNotify();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType42 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent43 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) basicProjectInfo0, jFreeChart27, chartChangeEventType42);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(libraryArray2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(chartChangeEventType16);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertNotNull(categoryItemRendererArray24);
        org.junit.Assert.assertNotNull(renderingHints28);
        org.junit.Assert.assertNotNull(legendTitle29);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNotNull(chartChangeEventType36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType42);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        polarPlot0.addCornerTextItem("");
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font5 = polarPlot4.getAngleLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) polarPlot4);
        polarPlot0.notifyListeners(plotChangeEvent6);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setAutoTickUnitSelection(true, false);
        boolean boolean5 = numberAxis3D1.isTickLabelsVisible();
        java.lang.Object obj6 = numberAxis3D1.clone();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        java.util.List list11 = numberAxis3D1.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge10);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot14.getFixedDomainAxisSpace();
        categoryPlot14.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot14.getDomainAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge17);
        try {
            double double19 = numberAxis3D1.valueToJava2D((double) 0.0f, rectangle2D13, rectangleEdge17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(axisSpace15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Other", graphics2D1, (float) (byte) 10, 0.5f, textAnchor4, (double) 2, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        boolean boolean4 = range2.contains((double) (byte) 100);
        double double5 = range2.getLength();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (short) 100, (double) 10L, (double) 2, (double) 500);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        float float9 = ringPlot8.getForegroundAlpha();
        ringPlot8.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke14 = xYPlot13.getDomainGridlineStroke();
        boolean boolean15 = ringPlot8.equals((java.lang.Object) xYPlot13);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot13.getDomainAxisLocation(255);
        xYPlot5.setRangeAxisLocation((int) (byte) 10, axisLocation17, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double22 = numberAxis3D21.getFixedAutoRange();
        numberAxis3D21.setLabelAngle((double) 10L);
        org.jfree.data.Range range25 = xYPlot5.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D21);
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font29 = polarPlot28.getAngleLabelFont();
        org.jfree.chart.plot.RingPlot ringPlot30 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke31 = ringPlot30.getSeparatorStroke();
        java.awt.Paint paint32 = ringPlot30.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double34 = rectangleInsets33.getTop();
        ringPlot30.setLabelPadding(rectangleInsets33);
        java.awt.Color color36 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace37 = color36.getColorSpace();
        ringPlot30.setLabelBackgroundPaint((java.awt.Paint) color36);
        org.jfree.chart.text.TextFragment textFragment39 = new org.jfree.chart.text.TextFragment("", font29, (java.awt.Paint) color36);
        java.awt.Paint paint40 = textFragment39.getPaint();
        xYPlot5.setQuadrantPaint(0, paint40);
        org.jfree.chart.axis.ValueAxis valueAxis42 = xYPlot5.getRangeAxis();
        boolean boolean43 = blockBorder4.equals((java.lang.Object) valueAxis42);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(colorSpace37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(valueAxis42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D2.getCategoryStart((-1), (int) ' ', rectangle2D5, rectangleEdge6);
        java.util.List list8 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        categoryPlot0.drawBackgroundImage(graphics2D9, rectangle2D10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 10, plotRenderingInfo13, point2D14, true);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent17);
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot0.getDataset((-4144960));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(categoryDataset20);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        categoryAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot2);
        polarPlot2.removeCornerTextItem("Size2D[width=0.0, height=0.0]");
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis0.setTickUnit(dateTickUnit3);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke6 = ringPlot5.getSeparatorStroke();
        java.awt.Paint paint7 = ringPlot5.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double9 = rectangleInsets8.getTop();
        ringPlot5.setLabelPadding(rectangleInsets8);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace12 = color11.getColorSpace();
        ringPlot5.setLabelBackgroundPaint((java.awt.Paint) color11);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets(0.08d, 10.0d, (double) (byte) 10, (double) '#');
        java.awt.Color color20 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder(rectangleInsets19, (java.awt.Paint) color20);
        java.awt.Color color22 = java.awt.Color.MAGENTA;
        java.awt.Color color23 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace24 = color23.getColorSpace();
        java.awt.color.ColorSpace colorSpace25 = color23.getColorSpace();
        float[] floatArray32 = new float[] { (short) 10, 0L, '4', ' ', 10L, 'a' };
        float[] floatArray33 = color22.getComponents(colorSpace25, floatArray32);
        float[] floatArray34 = color20.getRGBColorComponents(floatArray32);
        ringPlot5.setSectionPaint((java.lang.Comparable) "TextBlockAnchor.BOTTOM_LEFT", (java.awt.Paint) color20);
        org.jfree.chart.plot.RingPlot ringPlot36 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke37 = ringPlot36.getSeparatorStroke();
        java.awt.Paint paint38 = ringPlot36.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator39 = ringPlot36.getLabelGenerator();
        ringPlot5.setLabelGenerator(pieSectionLabelGenerator39);
        boolean boolean41 = dateAxis0.equals((java.lang.Object) pieSectionLabelGenerator39);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace12);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(colorSpace24);
        org.junit.Assert.assertNotNull(colorSpace25);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot2.getFixedDomainAxisSpace();
        categoryPlot2.clearRangeAxes();
        categoryPlot2.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, true);
        java.awt.RenderingHints renderingHints11 = jFreeChart10.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle12 = jFreeChart10.getLegend();
        jFreeChart10.setTextAntiAlias(true);
        java.awt.image.BufferedImage bufferedImage17 = jFreeChart10.createBufferedImage(8, 15);
        org.jfree.chart.title.LegendTitle legendTitle18 = jFreeChart10.getLegend();
        float float19 = jFreeChart10.getBackgroundImageAlpha();
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertNotNull(renderingHints11);
        org.junit.Assert.assertNotNull(legendTitle12);
        org.junit.Assert.assertNotNull(bufferedImage17);
        org.junit.Assert.assertNotNull(legendTitle18);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.5f + "'", float19 == 0.5f);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        ringPlot0.setInnerSeparatorExtension((double) (short) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.setRangeCrosshairValue((double) (short) 1, true);
        java.awt.Stroke stroke9 = xYPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot5.setDomainZeroBaselinePaint(paint10);
        ringPlot0.setSectionOutlinePaint((java.lang.Comparable) "Range[97.0,97.0]", paint10);
        ringPlot0.setIgnoreNullValues(true);
        ringPlot0.setOutlineVisible(false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.configureDomainAxes();
        java.awt.Font font4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        categoryPlot0.setNoDataMessageFont(font4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo12 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "");
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "hi!", jFreeChart13, chartChangeEventType14);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = chartChangeEvent15.getType();
        java.awt.Font font18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot19.getFixedDomainAxisSpace();
        categoryPlot19.clearRangeAxes();
        categoryPlot19.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray24 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer23 };
        categoryPlot19.setRenderers(categoryItemRendererArray24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("Pie Plot", font18, (org.jfree.chart.plot.Plot) categoryPlot19, true);
        java.awt.RenderingHints renderingHints28 = jFreeChart27.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle29 = jFreeChart27.getLegend();
        jFreeChart27.setTextAntiAlias(true);
        chartChangeEvent15.setChart(jFreeChart27);
        int int33 = jFreeChart27.getBackgroundImageAlignment();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent36 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryPlot0, jFreeChart27, (int) (short) 1, (int) (short) 0);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(chartChangeEventType16);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertNotNull(categoryItemRendererArray24);
        org.junit.Assert.assertNotNull(renderingHints28);
        org.junit.Assert.assertNotNull(legendTitle29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 15 + "'", int33 == 15);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setAutoTickUnitSelection(true, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = numberAxis3D1.getTickLabelInsets();
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font7 = polarPlot6.getAngleLabelFont();
        polarPlot6.addCornerTextItem("hi!");
        org.jfree.chart.plot.Plot plot10 = polarPlot6.getRootPlot();
        int int11 = polarPlot6.getSeriesCount();
        boolean boolean12 = numberAxis3D1.equals((java.lang.Object) polarPlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = polarPlot6.getInsets();
        java.awt.Font font14 = polarPlot6.getAngleLabelFont();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke2 = ringPlot1.getSeparatorStroke();
        java.awt.Paint paint3 = ringPlot1.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double5 = rectangleInsets4.getTop();
        ringPlot1.setLabelPadding(rectangleInsets4);
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace8 = color7.getColorSpace();
        ringPlot1.setLabelBackgroundPaint((java.awt.Paint) color7);
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color7);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(colorSpace8);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        legendTitle1.setHeight((double) (byte) 100);
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = polarPlot4.getLegendItems();
        java.util.Iterator iterator6 = legendItemCollection5.iterator();
        boolean boolean7 = legendTitle1.equals((java.lang.Object) legendItemCollection5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor8);
        legendTitle1.setNotify(false);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(iterator6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent3);
        int int5 = categoryPlot0.getDatasetCount();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace4 = color3.getColorSpace();
        java.awt.color.ColorSpace colorSpace5 = color3.getColorSpace();
        ringPlot0.setLabelShadowPaint((java.awt.Paint) color3);
        double double7 = ringPlot0.getLabelLinkMargin();
        java.awt.Paint paint8 = ringPlot0.getLabelPaint();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.025d + "'", double7 == 0.025d);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getBaseSectionPaint();
        java.awt.Paint paint4 = piePlot1.getSectionPaint((java.lang.Comparable) 0.025d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.awt.Font font0 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.plot.Plot plot5 = piePlot1.getRootPlot();
        double double6 = piePlot1.getMaximumExplodePercent();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = piePlot1.getLegendLabelURLGenerator();
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(pieURLGenerator7);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.mapDatasetToRangeAxis((int) (byte) 1, (int) '4');
        boolean boolean12 = categoryPlot0.getDrawSharedDomainAxis();
        java.awt.Paint paint13 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        int int17 = categoryPlot0.getIndexOf(categoryItemRenderer16);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setExplodedPieArea(rectangle2D2);
        double double4 = piePlotState1.getTotal();
        piePlotState1.setPassesRequired(0);
        double double7 = piePlotState1.getPieCenterX();
        java.awt.geom.Rectangle2D rectangle2D8 = piePlotState1.getPieArea();
        double double9 = piePlotState1.getTotal();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.mapDatasetToRangeAxis((int) (byte) 1, (int) '4');
        boolean boolean12 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        categoryPlot0.removeChangeListener(plotChangeListener13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke16 = xYPlot15.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.data.Range range18 = xYPlot15.getDataRange(valueAxis17);
        java.awt.Stroke stroke19 = xYPlot15.getRangeZeroBaselineStroke();
        xYPlot15.clearRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace22 = categoryPlot21.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke24 = ringPlot23.getSeparatorStroke();
        java.awt.Paint paint25 = ringPlot23.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double27 = rectangleInsets26.getTop();
        ringPlot23.setLabelPadding(rectangleInsets26);
        java.awt.Color color29 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace30 = color29.getColorSpace();
        ringPlot23.setLabelBackgroundPaint((java.awt.Paint) color29);
        categoryPlot21.setNoDataMessagePaint((java.awt.Paint) color29);
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        categoryPlot21.setRangeAxisLocation(100, axisLocation34, false);
        org.jfree.chart.axis.AxisLocation axisLocation38 = categoryPlot21.getRangeAxisLocation(1);
        xYPlot15.setRangeAxisLocation(axisLocation38);
        categoryPlot0.setDomainAxisLocation(axisLocation38);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(axisSpace22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(colorSpace30);
        org.junit.Assert.assertNotNull(axisLocation38);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.plot.Plot plot5 = piePlot1.getRootPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D8.setMaximumCategoryLabelWidthRatio(10.0f);
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color12 = java.awt.Color.BLACK;
        categoryAxis3D8.setTickLabelPaint((java.lang.Comparable) date11, (java.awt.Paint) color12);
        piePlot1.setSectionPaint((java.lang.Comparable) "ThreadContext", (java.awt.Paint) color12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        double double16 = piePlot1.getInteriorGap();
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.08d + "'", double16 == 0.08d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke6 = categoryAxis3D5.getTickMarkStroke();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] { stroke2, stroke3, stroke6, stroke7, stroke8 };
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke12 = categoryAxis3D11.getTickMarkStroke();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke16 = categoryAxis3D15.getTickMarkStroke();
        java.awt.Stroke stroke17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] { stroke12, stroke13, stroke16, stroke17 };
        java.awt.Shape shape19 = null;
        java.awt.Shape[] shapeArray20 = new java.awt.Shape[] { shape19 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray9, strokeArray18, shapeArray20);
        org.jfree.chart.plot.RingPlot ringPlot22 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot22);
        legendTitle23.setHeight((double) (byte) 100);
        boolean boolean26 = defaultDrawingSupplier21.equals((java.lang.Object) legendTitle23);
        java.lang.Object obj27 = defaultDrawingSupplier21.clone();
        java.awt.Shape shape28 = defaultDrawingSupplier21.getNextShape();
        java.lang.Object obj29 = defaultDrawingSupplier21.clone();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(shapeArray20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNull(shape28);
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        objectList0.clear();
        java.lang.Object obj3 = objectList0.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setExplodedPieArea(rectangle2D2);
        double double4 = piePlotState1.getTotal();
        piePlotState1.setLatestAngle((double) (short) -1);
        org.jfree.chart.entity.EntityCollection entityCollection7 = piePlotState1.getEntityCollection();
        piePlotState1.setPieCenterY((double) (byte) 10);
        double double10 = piePlotState1.getLatestAngle();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(entityCollection7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = legendTitle1.getVerticalAlignment();
        java.awt.Font font4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot5.getFixedDomainAxisSpace();
        categoryPlot5.clearRangeAxes();
        categoryPlot5.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray10 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer9 };
        categoryPlot5.setRenderers(categoryItemRendererArray10);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("Pie Plot", font4, (org.jfree.chart.plot.Plot) categoryPlot5, true);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart13);
        java.awt.RenderingHints renderingHints15 = jFreeChart13.getRenderingHints();
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(categoryItemRendererArray10);
        org.junit.Assert.assertNotNull(renderingHints15);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getLGPL();
        java.lang.String str2 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairValue((double) (short) 1, true);
        boolean boolean4 = xYPlot0.isRangeZoomable();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("Pie 3D Plot");
        int int7 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = xYPlot0.getAxisOffset();
        java.lang.Object obj9 = null;
        boolean boolean10 = xYPlot0.equals(obj9);
        xYPlot0.setDomainGridlinesVisible(true);
        java.awt.Paint paint13 = xYPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean6 = numberAxis3D1.isPositiveArrowVisible();
        java.lang.Object obj7 = numberAxis3D1.clone();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat8);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double12 = numberAxis3D11.getFixedAutoRange();
        double double13 = numberAxis3D11.getUpperBound();
        java.awt.Shape shape14 = numberAxis3D11.getUpArrow();
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis3D11.setAxisLineStroke(stroke15);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range19 = numberAxis3D18.getRange();
        org.jfree.data.Range range21 = org.jfree.data.Range.shift(range19, (double) (-1.0f));
        numberAxis3D11.setDefaultAutoRange(range19);
        numberAxis3D1.setRangeWithMargins(range19);
        numberAxis3D1.setLowerMargin((double) (short) 1);
        numberAxis3D1.setAxisLineVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range21);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D1 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace2);
        org.junit.Assert.assertNotNull(point2D1);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        categoryPlot0.setAnchorValue((double) '#', true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double9 = numberAxis3D8.getFixedAutoRange();
        double double10 = numberAxis3D8.getUpperBound();
        double double11 = numberAxis3D8.getFixedAutoRange();
        org.jfree.data.RangeType rangeType12 = numberAxis3D8.getRangeType();
        org.jfree.data.Range range13 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D8);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rangeType12);
        org.junit.Assert.assertNull(range13);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairValue((double) (short) 1, true);
        java.awt.Stroke stroke4 = xYPlot0.getRangeZeroBaselineStroke();
        int int5 = xYPlot0.getDatasetCount();
        boolean boolean6 = xYPlot0.isDomainZeroBaselineVisible();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font3 = categoryAxis3D2.getLabelFont();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font3);
        org.jfree.chart.text.TextFragment textFragment5 = null;
        textLine4.addFragment(textFragment5);
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Image image9 = polarPlot8.getBackgroundImage();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        polarPlot8.setRenderer(polarItemRenderer10);
        java.awt.Font font12 = polarPlot8.getAngleLabelFont();
        java.awt.Paint paint13 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("UnitType.RELATIVE", font12, paint13, 10.0f);
        textLine4.addFragment(textFragment15);
        java.lang.String str17 = textFragment15.getText();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(image9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UnitType.RELATIVE" + "'", str17.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setAutoTickUnitSelection(true, false);
        boolean boolean5 = numberAxis3D1.isTickLabelsVisible();
        java.lang.String str6 = numberAxis3D1.getLabel();
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude(range7, (double) 'a');
        double double10 = range9.getUpperBound();
        boolean boolean13 = range9.intersects((double) 500, (double) 1L);
        numberAxis3D1.setDefaultAutoRange(range9);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 97.0d + "'", double10 == 97.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = xYPlot0.getDataRange(valueAxis2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = xYPlot0.getRendererForDataset(xYDataset4);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(xYItemRenderer5);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean6 = numberAxis3D1.isPositiveArrowVisible();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range9 = numberAxis3D8.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double12 = numberAxis3D11.getFixedAutoRange();
        double double13 = numberAxis3D11.getUpperBound();
        java.awt.Shape shape14 = numberAxis3D11.getUpArrow();
        numberAxis3D8.setUpArrow(shape14);
        numberAxis3D1.setDownArrow(shape14);
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape14);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape14, "TextBlockAnchor.BOTTOM_LEFT");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        double double2 = textTitle1.getContentYOffset();
        java.lang.String str3 = textTitle1.getURLText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textTitle1.getTextAlignment();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double3 = numberAxis3D2.getFixedAutoRange();
        double double4 = numberAxis3D2.getUpperBound();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range7 = numberAxis3D6.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double10 = numberAxis3D9.getFixedAutoRange();
        double double11 = numberAxis3D9.getUpperBound();
        java.awt.Shape shape12 = numberAxis3D9.getUpArrow();
        numberAxis3D6.setUpArrow(shape12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, xYItemRenderer14);
        java.awt.Paint paint16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot15.setDomainGridlinePaint(paint16);
        java.awt.Stroke stroke18 = xYPlot15.getDomainZeroBaselineStroke();
        java.awt.Paint paint19 = xYPlot15.getDomainZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        polarPlot0.addCornerTextItem("hi!");
        org.jfree.chart.plot.Plot plot4 = polarPlot0.getRootPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        polarPlot0.addChangeListener(plotChangeListener5);
        java.awt.Font font8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot9.getFixedDomainAxisSpace();
        categoryPlot9.clearRangeAxes();
        categoryPlot9.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("Pie Plot", font8, (org.jfree.chart.plot.Plot) categoryPlot9, true);
        jFreeChart17.setBorderVisible(false);
        polarPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart17);
        try {
            double double21 = polarPlot0.getMaxRadius();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio(10.0f);
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color5 = java.awt.Color.BLACK;
        categoryAxis3D1.setTickLabelPaint((java.lang.Comparable) date4, (java.awt.Paint) color5);
        java.lang.Object obj7 = categoryAxis3D1.clone();
        boolean boolean8 = categoryAxis3D1.isAxisLineVisible();
        java.awt.Paint paint9 = categoryAxis3D1.getAxisLinePaint();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        xYPlot5.setRenderer(8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot5.setFixedDomainAxisSpace(axisSpace11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot13.getFixedDomainAxisSpace();
        categoryPlot13.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot13.getDomainAxisEdge();
        categoryPlot13.clearDomainMarkers((int) (byte) 10);
        categoryPlot13.clearRangeMarkers();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot13.getRenderer();
        java.awt.Stroke stroke21 = categoryPlot13.getRangeGridlineStroke();
        xYPlot5.setDomainZeroBaselineStroke(stroke21);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.setRangeCrosshairVisible(true);
        java.awt.Stroke stroke4 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot5.getLegendItems();
        categoryPlot5.clearDomainAxes();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double10 = numberAxis3D9.getFixedAutoRange();
        numberAxis3D9.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean14 = numberAxis3D9.isPositiveArrowVisible();
        java.lang.Object obj15 = numberAxis3D9.clone();
        java.text.NumberFormat numberFormat16 = null;
        numberAxis3D9.setNumberFormatOverride(numberFormat16);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double20 = numberAxis3D19.getFixedAutoRange();
        double double21 = numberAxis3D19.getUpperBound();
        java.awt.Shape shape22 = numberAxis3D19.getUpArrow();
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis3D19.setAxisLineStroke(stroke23);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range27 = numberAxis3D26.getRange();
        org.jfree.data.Range range29 = org.jfree.data.Range.shift(range27, (double) (-1.0f));
        numberAxis3D19.setDefaultAutoRange(range27);
        numberAxis3D9.setRangeWithMargins(range27);
        numberAxis3D9.setLowerMargin((double) (short) 1);
        int int34 = categoryPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D9);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double37 = numberAxis3D36.getFixedAutoRange();
        numberAxis3D36.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean41 = numberAxis3D36.isPositiveArrowVisible();
        numberAxis3D36.centerRange(0.2d);
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D47 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = null;
        double double52 = categoryAxis3D47.getCategoryStart((-1), (int) ' ', rectangle2D50, rectangleEdge51);
        boolean boolean53 = textTitle45.equals((java.lang.Object) categoryAxis3D47);
        textTitle45.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color56 = java.awt.Color.BLACK;
        textTitle45.setBackgroundPaint((java.awt.Paint) color56);
        java.awt.geom.Rectangle2D rectangle2D58 = textTitle45.getBounds();
        numberAxis3D36.setLeftArrow((java.awt.Shape) rectangle2D58);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D61 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double62 = numberAxis3D61.getFixedAutoRange();
        numberAxis3D61.setVerticalTickLabels(false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray65 = new org.jfree.chart.axis.ValueAxis[] { numberAxis3D9, numberAxis3D36, numberAxis3D61 };
        categoryPlot0.setRangeAxes(valueAxisArray65);
        org.jfree.chart.axis.CategoryAxis categoryAxis67 = categoryPlot0.getDomainAxis();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray65);
        org.junit.Assert.assertNull(categoryAxis67);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        polarPlot0.addCornerTextItem("hi!");
        org.jfree.chart.plot.Plot plot4 = polarPlot0.getRootPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        polarPlot0.addChangeListener(plotChangeListener5);
        java.awt.Font font8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot9.getFixedDomainAxisSpace();
        categoryPlot9.clearRangeAxes();
        categoryPlot9.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("Pie Plot", font8, (org.jfree.chart.plot.Plot) categoryPlot9, true);
        jFreeChart17.setBorderVisible(false);
        polarPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart17);
        int int21 = jFreeChart17.getSubtitleCount();
        org.jfree.chart.event.ChartChangeListener chartChangeListener22 = null;
        try {
            jFreeChart17.removeChangeListener(chartChangeListener22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        legendTitle1.setHeight((double) (byte) 100);
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = polarPlot4.getLegendItems();
        java.util.Iterator iterator6 = legendItemCollection5.iterator();
        boolean boolean7 = legendTitle1.equals((java.lang.Object) legendItemCollection5);
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder();
        legendTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = blockBorder8.getInsets();
        java.awt.Paint paint11 = blockBorder8.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot12.getFixedDomainAxisSpace();
        categoryPlot12.clearRangeAxes();
        categoryPlot12.configureDomainAxes();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = categoryPlot12.getDomainMarkers(layer16);
        boolean boolean18 = blockBorder8.equals((java.lang.Object) layer16);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(iterator6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        try {
            java.util.Date date4 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis0.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = null;
        dateAxis0.setTickUnit(dateTickUnit5, true, true);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.Range range3 = new org.jfree.data.Range((-1.0d), 100.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, (double) (-1.0f));
        org.jfree.data.Range range7 = rectangleConstraint6.getWidthRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = rectangleConstraint6.getWidthConstraintType();
        org.jfree.data.Range range10 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, (double) (-1.0f));
        org.jfree.data.Range range14 = rectangleConstraint13.getWidthRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint13.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) ' ', range3, lengthConstraintType8, (double) (byte) 0, range10, lengthConstraintType15);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint16.toUnconstrainedHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = rectangleConstraint17.toFixedWidth(Double.POSITIVE_INFINITY);
        org.jfree.data.Range range20 = null;
        org.jfree.data.Range range22 = org.jfree.data.Range.expandToInclude(range20, (double) 'a');
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range25 = numberAxis3D24.getRange();
        org.jfree.data.Range range26 = org.jfree.data.Range.combine(range20, range25);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint19.toRangeWidth(range26);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNotNull(rectangleConstraint19);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("Size2D[width=0.0, height=0.0]", "Size2D[width=0.0, height=0.0]", "Size2D[width=0.0, height=0.0]", "UnitType.RELATIVE");
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairValue((double) (short) 1, true);
        java.awt.Stroke stroke4 = xYPlot0.getRangeZeroBaselineStroke();
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setDomainZeroBaselinePaint(paint5);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D11.setAutoTickUnitSelection(true, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = numberAxis3D11.getTickLabelInsets();
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font17 = polarPlot16.getAngleLabelFont();
        polarPlot16.addCornerTextItem("hi!");
        org.jfree.chart.plot.Plot plot20 = polarPlot16.getRootPlot();
        int int21 = polarPlot16.getSeriesCount();
        boolean boolean22 = numberAxis3D11.equals((java.lang.Object) polarPlot16);
        xYPlot0.setRangeAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(plot20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis0.setTickUnit(dateTickUnit3);
        java.text.DateFormat dateFormat5 = null;
        dateAxis0.setDateFormatOverride(dateFormat5);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = null;
        dateAxis0.setTickUnit(dateTickUnit7, true, false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = piePlot1.getLabelDistributor();
        int int6 = abstractPieLabelDistributor5.getItemCount();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = null;
        dateAxis1.setTickUnit(dateTickUnit4);
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = null;
        dateAxis1.setTickUnit(dateTickUnit6, false, true);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer10);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        double double3 = numberAxis3D1.getUpperBound();
        double double4 = numberAxis3D1.getFixedAutoRange();
        org.jfree.data.RangeType rangeType5 = numberAxis3D1.getRangeType();
        double double6 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = null;
        try {
            numberAxis3D1.setTickUnit(numberTickUnit7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rangeType5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.awt.Font font4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot5.getFixedDomainAxisSpace();
        categoryPlot5.clearRangeAxes();
        categoryPlot5.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray10 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer9 };
        categoryPlot5.setRenderers(categoryItemRendererArray10);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("Pie Plot", font4, (org.jfree.chart.plot.Plot) categoryPlot5, true);
        java.awt.RenderingHints renderingHints14 = jFreeChart13.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart13.getLegend();
        jFreeChart13.setTextAntiAlias(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        java.awt.image.BufferedImage bufferedImage21 = jFreeChart13.createBufferedImage(10, (int) (byte) 10, chartRenderingInfo20);
        org.jfree.chart.ui.ProjectInfo projectInfo25 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", (java.awt.Image) bufferedImage21, "", "Multiple Pie Plot", "");
        java.util.List list26 = projectInfo25.getContributors();
        java.awt.Image image27 = projectInfo25.getLogo();
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(categoryItemRendererArray10);
        org.junit.Assert.assertNotNull(renderingHints14);
        org.junit.Assert.assertNotNull(legendTitle15);
        org.junit.Assert.assertNotNull(bufferedImage21);
        org.junit.Assert.assertNull(list26);
        org.junit.Assert.assertNotNull(image27);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot5.getDomainAxisLocation(255);
        java.awt.Stroke stroke10 = xYPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint11 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        xYPlot5.setRangeGridlinePaint(paint11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = xYPlot5.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(axisSpace13);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=0.0]", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer(0);
        java.awt.Stroke stroke6 = categoryPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D2.getCategoryStart((-1), (int) ' ', rectangle2D5, rectangleEdge6);
        java.util.List list8 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.awt.Paint paint9 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot0.getIndexOf(categoryItemRenderer10);
        int int12 = categoryPlot0.getDomainAxisCount();
        int int13 = categoryPlot0.getDomainAxisCount();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation14 = null;
        try {
            boolean boolean15 = categoryPlot0.removeAnnotation(categoryAnnotation14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace2);
        java.lang.Object obj4 = categoryPlot0.clone();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double3 = numberAxis3D2.getFixedAutoRange();
        double double4 = numberAxis3D2.getUpperBound();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range7 = numberAxis3D6.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double10 = numberAxis3D9.getFixedAutoRange();
        double double11 = numberAxis3D9.getUpperBound();
        java.awt.Shape shape12 = numberAxis3D9.getUpArrow();
        numberAxis3D6.setUpArrow(shape12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, xYItemRenderer14);
        java.awt.Paint paint16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot15.setDomainGridlinePaint(paint16);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = xYPlot15.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(drawingSupplier18);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean6 = numberAxis3D1.isPositiveArrowVisible();
        java.lang.Object obj7 = numberAxis3D1.clone();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat8);
        numberAxis3D1.setTickMarkOutsideLength((float) 2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double14 = numberAxis3D13.getFixedAutoRange();
        numberAxis3D13.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean18 = numberAxis3D13.isPositiveArrowVisible();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range21 = numberAxis3D20.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double24 = numberAxis3D23.getFixedAutoRange();
        double double25 = numberAxis3D23.getUpperBound();
        java.awt.Shape shape26 = numberAxis3D23.getUpArrow();
        numberAxis3D20.setUpArrow(shape26);
        numberAxis3D13.setDownArrow(shape26);
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity(shape26);
        numberAxis3D1.setDownArrow(shape26);
        org.jfree.chart.plot.PolarPlot polarPlot32 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font33 = polarPlot32.getAngleLabelFont();
        org.jfree.chart.plot.RingPlot ringPlot34 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke35 = ringPlot34.getSeparatorStroke();
        java.awt.Paint paint36 = ringPlot34.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double38 = rectangleInsets37.getTop();
        ringPlot34.setLabelPadding(rectangleInsets37);
        java.awt.Color color40 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace41 = color40.getColorSpace();
        ringPlot34.setLabelBackgroundPaint((java.awt.Paint) color40);
        org.jfree.chart.text.TextFragment textFragment43 = new org.jfree.chart.text.TextFragment("", font33, (java.awt.Paint) color40);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D45 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D45.setAutoTickUnitSelection(true, false);
        boolean boolean49 = numberAxis3D45.isTickLabelsVisible();
        java.lang.Object obj50 = numberAxis3D45.clone();
        boolean boolean51 = textFragment43.equals((java.lang.Object) numberAxis3D45);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit52 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D45.setTickUnit(numberTickUnit52);
        numberAxis3D1.setTickUnit(numberTickUnit52);
        java.awt.Color color55 = java.awt.Color.white;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo61 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "");
        org.jfree.chart.JFreeChart jFreeChart62 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType63 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent64 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "hi!", jFreeChart62, chartChangeEventType63);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType65 = chartChangeEvent64.getType();
        java.awt.Font font67 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace69 = categoryPlot68.getFixedDomainAxisSpace();
        categoryPlot68.clearRangeAxes();
        categoryPlot68.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer72 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray73 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer72 };
        categoryPlot68.setRenderers(categoryItemRendererArray73);
        org.jfree.chart.JFreeChart jFreeChart76 = new org.jfree.chart.JFreeChart("Pie Plot", font67, (org.jfree.chart.plot.Plot) categoryPlot68, true);
        java.awt.RenderingHints renderingHints77 = jFreeChart76.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle78 = jFreeChart76.getLegend();
        jFreeChart76.setTextAntiAlias(true);
        chartChangeEvent64.setChart(jFreeChart76);
        java.util.List list82 = jFreeChart76.getSubtitles();
        jFreeChart76.setAntiAlias(false);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType85 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent86 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color55, jFreeChart76, chartChangeEventType85);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent87 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberTickUnit52, jFreeChart76);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(colorSpace41);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(obj50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(numberTickUnit52);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNull(chartChangeEventType65);
        org.junit.Assert.assertNull(axisSpace69);
        org.junit.Assert.assertNotNull(categoryItemRendererArray73);
        org.junit.Assert.assertNotNull(renderingHints77);
        org.junit.Assert.assertNotNull(legendTitle78);
        org.junit.Assert.assertNotNull(list82);
        org.junit.Assert.assertNotNull(chartChangeEventType85);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D5.setTickMarkInsideLength((float) (byte) 1);
        java.awt.Stroke stroke8 = categoryAxis3D5.getTickMarkStroke();
        java.util.List list9 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot0.getInsets();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.FlowArrangement flowArrangement1 = new org.jfree.chart.block.FlowArrangement();
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement1);
        org.jfree.chart.block.Arrangement arrangement3 = blockContainer0.getArrangement();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot4);
        legendTitle5.setHeight((double) (byte) 100);
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = polarPlot8.getLegendItems();
        java.util.Iterator iterator10 = legendItemCollection9.iterator();
        boolean boolean11 = legendTitle5.equals((java.lang.Object) legendItemCollection9);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder();
        legendTitle5.setFrame((org.jfree.chart.block.BlockFrame) blockBorder12);
        double double14 = legendTitle5.getHeight();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace16 = categoryPlot15.getFixedDomainAxisSpace();
        categoryPlot15.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot15.getDomainAxisEdge();
        legendTitle5.setLegendItemGraphicEdge(rectangleEdge18);
        blockContainer0.add((org.jfree.chart.block.Block) legendTitle5);
        org.junit.Assert.assertNotNull(arrangement3);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(iterator10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        ringPlot0.setInnerSeparatorExtension((double) (short) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.setRangeCrosshairValue((double) (short) 1, true);
        java.awt.Stroke stroke9 = xYPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot5.setDomainZeroBaselinePaint(paint10);
        ringPlot0.setSectionOutlinePaint((java.lang.Comparable) "Range[97.0,97.0]", paint10);
        boolean boolean13 = ringPlot0.getSimpleLabels();
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint3 = piePlot1.getSectionPaint((java.lang.Comparable) 8);
        org.jfree.data.general.DatasetGroup datasetGroup4 = piePlot1.getDatasetGroup();
        piePlot1.setLabelLinkMargin(0.05d);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        piePlot1.handleClick(0, (int) (short) -1, plotRenderingInfo9);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot1.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNull(pieSectionLabelGenerator11);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceText("");
        java.awt.Image image3 = projectInfo0.getLogo();
        java.lang.String str4 = projectInfo0.getLicenceText();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 'a');
        double double3 = range2.getUpperBound();
        java.lang.String str4 = range2.toString();
        org.jfree.data.Range range6 = org.jfree.data.Range.expandToInclude(range2, 0.025d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range2, 0.08d);
        boolean boolean10 = range2.contains((double) 0.5f);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Range[97.0,97.0]" + "'", str4.equals("Range[97.0,97.0]"));
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        java.awt.Font font3 = null;
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color4, (float) (-1L), textMeasurer6);
        org.jfree.chart.text.TextLine textLine8 = null;
        textBlock7.addLine(textLine8);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font13 = categoryAxis3D12.getLabelFont();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        textBlock7.addLine("Pie Plot", font13, (java.awt.Paint) color14);
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        ringPlot16.zoom(100.0d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke21 = categoryAxis3D20.getTickMarkStroke();
        java.awt.Paint paint22 = categoryAxis3D20.getTickLabelPaint();
        ringPlot16.setLabelPaint(paint22);
        org.jfree.chart.text.TextFragment textFragment24 = new org.jfree.chart.text.TextFragment("ThreadContext", font13, paint22);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D26 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D26.setMaximumCategoryLabelWidthRatio(10.0f);
        java.util.Date date29 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color30 = java.awt.Color.BLACK;
        categoryAxis3D26.setTickLabelPaint((java.lang.Comparable) date29, (java.awt.Paint) color30);
        org.jfree.chart.text.TextLine textLine32 = new org.jfree.chart.text.TextLine("Multiple Pie Plot", font13, (java.awt.Paint) color30);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(color30);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Color color2 = java.awt.Color.RED;
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color2);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = multiplePiePlot1.getLegendItems();
        java.awt.Color color5 = java.awt.Color.cyan;
        java.awt.Color color6 = java.awt.Color.green;
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        java.awt.color.ColorSpace colorSpace10 = color8.getColorSpace();
        float[] floatArray17 = new float[] { (short) 10, 0L, '4', ' ', 10L, 'a' };
        float[] floatArray18 = color7.getComponents(colorSpace10, floatArray17);
        java.awt.Color color19 = java.awt.Color.MAGENTA;
        java.awt.Color color20 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace21 = color20.getColorSpace();
        java.awt.color.ColorSpace colorSpace22 = color20.getColorSpace();
        float[] floatArray29 = new float[] { (short) 10, 0L, '4', ' ', 10L, 'a' };
        float[] floatArray30 = color19.getComponents(colorSpace22, floatArray29);
        float[] floatArray31 = color6.getComponents(colorSpace10, floatArray29);
        float[] floatArray32 = color5.getComponents(floatArray31);
        boolean boolean33 = multiplePiePlot1.equals((java.lang.Object) color5);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(colorSpace21);
        org.junit.Assert.assertNotNull(colorSpace22);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.block.BlockFrame blockFrame2 = legendTitle1.getFrame();
        java.awt.Font font4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot5.getFixedDomainAxisSpace();
        categoryPlot5.clearRangeAxes();
        categoryPlot5.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray10 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer9 };
        categoryPlot5.setRenderers(categoryItemRendererArray10);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("Pie Plot", font4, (org.jfree.chart.plot.Plot) categoryPlot5, true);
        jFreeChart13.setBorderVisible(false);
        jFreeChart13.fireChartChanged();
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart13);
        org.jfree.chart.text.TextBlock textBlock18 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = textBlock18.getLineAlignment();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        textBlock18.draw(graphics2D20, (float) ' ', (float) 10L, textBlockAnchor23, (float) (short) 1, 0.0f, (double) (byte) 1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment28 = textBlock18.getLineAlignment();
        legendTitle1.setHorizontalAlignment(horizontalAlignment28);
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(categoryItemRendererArray10);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertNotNull(horizontalAlignment28);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainZeroBaselineStroke();
        double double2 = xYPlot0.getDomainCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double7 = numberAxis3D6.getFixedAutoRange();
        double double8 = numberAxis3D6.getUpperBound();
        java.awt.Shape shape9 = numberAxis3D6.getUpArrow();
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis3D6.setAxisLineStroke(stroke10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset3, valueAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, xYItemRenderer12);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        float float15 = ringPlot14.getForegroundAlpha();
        ringPlot14.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke20 = xYPlot19.getDomainGridlineStroke();
        boolean boolean21 = ringPlot14.equals((java.lang.Object) xYPlot19);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot19.getDomainAxisLocation(255);
        xYPlot13.setRangeAxisLocation(axisLocation23, true);
        xYPlot0.setDomainAxisLocation(axisLocation23);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(axisLocation23);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceText("");
        projectInfo0.setInfo("ThreadContext");
        projectInfo0.setLicenceName("XY Plot");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        java.lang.Object obj3 = dateAxis0.clone();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double8 = rectangleInsets7.getTop();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement13 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment10, (double) (byte) 1, (double) 10);
        boolean boolean15 = flowArrangement13.equals((java.lang.Object) 0.0d);
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection17 = polarPlot16.getLegendItems();
        java.util.Iterator iterator18 = legendItemCollection17.iterator();
        boolean boolean19 = flowArrangement13.equals((java.lang.Object) iterator18);
        org.jfree.chart.plot.RingPlot ringPlot20 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot20);
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = legendTitle21.getVerticalAlignment();
        double double23 = legendTitle21.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle21.getPadding();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.plot.PiePlotState piePlotState26 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo25);
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        piePlotState26.setExplodedPieArea(rectangle2D27);
        double double29 = piePlotState26.getTotal();
        piePlotState26.setLatestAngle((double) (short) -1);
        java.awt.geom.Rectangle2D rectangle2D32 = piePlotState26.getLinkArea();
        org.jfree.chart.entity.EntityCollection entityCollection33 = piePlotState26.getEntityCollection();
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D37 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        double double42 = categoryAxis3D37.getCategoryStart((-1), (int) ' ', rectangle2D40, rectangleEdge41);
        boolean boolean43 = textTitle35.equals((java.lang.Object) categoryAxis3D37);
        textTitle35.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color46 = java.awt.Color.BLACK;
        textTitle35.setBackgroundPaint((java.awt.Paint) color46);
        java.awt.geom.Rectangle2D rectangle2D48 = textTitle35.getBounds();
        piePlotState26.setLinkArea(rectangle2D48);
        flowArrangement13.add((org.jfree.chart.block.Block) legendTitle21, (java.lang.Object) rectangle2D48);
        rectangleInsets7.trim(rectangle2D48);
        org.jfree.chart.entity.ChartEntity chartEntity52 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D48);
        rectangleInsets6.trim(rectangle2D48);
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace55 = categoryPlot54.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot56 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke57 = ringPlot56.getSeparatorStroke();
        categoryPlot54.setDomainGridlineStroke(stroke57);
        org.jfree.chart.axis.AxisLocation axisLocation60 = null;
        categoryPlot54.setDomainAxisLocation((int) ' ', axisLocation60);
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = categoryPlot54.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = null;
        categoryPlot54.setRenderer(categoryItemRenderer63);
        boolean boolean65 = categoryPlot54.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis67 = categoryPlot54.getRangeAxis((int) '4');
        org.jfree.chart.util.Layer layer68 = null;
        java.util.Collection collection69 = categoryPlot54.getDomainMarkers(layer68);
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = categoryPlot54.getRangeAxisEdge();
        try {
            java.util.List list71 = dateAxis0.refreshTicks(graphics2D4, axisState5, rectangle2D48, rectangleEdge70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(legendItemCollection17);
        org.junit.Assert.assertNotNull(iterator18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(verticalAlignment22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D32);
        org.junit.Assert.assertNull(entityCollection33);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNull(axisSpace55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNull(valueAxis67);
        org.junit.Assert.assertNull(collection69);
        org.junit.Assert.assertNotNull(rectangleEdge70);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        polarPlot0.addCornerTextItem("");
        int int4 = polarPlot0.getSeriesCount();
        boolean boolean5 = polarPlot0.isSubplot();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot6);
        ringPlot6.setInnerSeparatorExtension((double) (short) 100);
        java.awt.Paint paint10 = ringPlot6.getLabelOutlinePaint();
        java.awt.Paint paint11 = ringPlot6.getLabelShadowPaint();
        polarPlot0.setRadiusGridlinePaint(paint11);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        polarPlot0.datasetChanged(datasetChangeEvent13);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textBlock0.getLineAlignment();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        textBlock0.draw(graphics2D2, (float) ' ', (float) 10L, textBlockAnchor5, (float) (short) 1, 0.0f, (double) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot10.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke13 = ringPlot12.getSeparatorStroke();
        categoryPlot10.setDomainGridlineStroke(stroke13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        categoryPlot10.setDomainAxisLocation((int) ' ', axisLocation16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot10.getRangeAxisEdge();
        categoryPlot10.mapDatasetToRangeAxis((int) (byte) 1, (int) '4');
        java.awt.Paint paint22 = categoryPlot10.getDomainGridlinePaint();
        categoryPlot10.clearDomainMarkers((int) (short) -1);
        boolean boolean25 = textBlock0.equals((java.lang.Object) categoryPlot10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D29 = xYPlot28.getQuadrantOrigin();
        categoryPlot10.zoomDomainAxes((double) (-1.0f), plotRenderingInfo27, point2D29, true);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(point2D29);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font3 = categoryAxis3D2.getLabelFont();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) color4, (float) (byte) 100);
        java.awt.Paint paint7 = textFragment6.getPaint();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        double double10 = textTitle9.getContentYOffset();
        java.lang.String str11 = textTitle9.getURLText();
        boolean boolean12 = textFragment6.equals((java.lang.Object) textTitle9);
        java.lang.String str13 = textFragment6.getText();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "");
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "hi!", jFreeChart6, chartChangeEventType7);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = chartChangeEvent8.getType();
        java.awt.Font font11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot12.getFixedDomainAxisSpace();
        categoryPlot12.clearRangeAxes();
        categoryPlot12.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray17 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer16 };
        categoryPlot12.setRenderers(categoryItemRendererArray17);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("Pie Plot", font11, (org.jfree.chart.plot.Plot) categoryPlot12, true);
        java.awt.RenderingHints renderingHints21 = jFreeChart20.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle22 = jFreeChart20.getLegend();
        jFreeChart20.setTextAntiAlias(true);
        chartChangeEvent8.setChart(jFreeChart20);
        java.awt.Image image26 = jFreeChart20.getBackgroundImage();
        int int27 = jFreeChart20.getSubtitleCount();
        org.junit.Assert.assertNull(chartChangeEventType9);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNotNull(categoryItemRendererArray17);
        org.junit.Assert.assertNotNull(renderingHints21);
        org.junit.Assert.assertNotNull(legendTitle22);
        org.junit.Assert.assertNull(image26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        float float4 = ringPlot3.getForegroundAlpha();
        ringPlot3.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke9 = xYPlot8.getDomainGridlineStroke();
        boolean boolean10 = ringPlot3.equals((java.lang.Object) xYPlot8);
        org.jfree.chart.axis.AxisLocation axisLocation12 = xYPlot8.getDomainAxisLocation(255);
        xYPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation12, true);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke16 = xYPlot15.getDomainGridlineStroke();
        java.awt.Paint paint17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot15.setRangeCrosshairPaint(paint17);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double21 = numberAxis3D20.getFixedAutoRange();
        double double22 = numberAxis3D20.getUpperBound();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis3D20.getLabelInsets();
        xYPlot15.setAxisOffset(rectangleInsets23);
        double double26 = rectangleInsets23.calculateTopInset((double) (byte) 100);
        xYPlot0.setAxisOffset(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        double double3 = numberAxis3D1.getUpperBound();
        java.awt.Font font4 = numberAxis3D1.getTickLabelFont();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis3D1.java2DToValue((double) 10L, rectangle2D6, rectangleEdge7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double11 = numberAxis3D10.getFixedAutoRange();
        double double12 = numberAxis3D10.getUpperBound();
        double double13 = numberAxis3D10.getFixedAutoRange();
        org.jfree.data.RangeType rangeType14 = numberAxis3D10.getRangeType();
        numberAxis3D1.setRangeType(rangeType14);
        java.text.NumberFormat numberFormat16 = numberAxis3D1.getNumberFormatOverride();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rangeType14);
        org.junit.Assert.assertNull(numberFormat16);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        polarPlot0.addCornerTextItem("");
        int int4 = polarPlot0.getSeriesCount();
        boolean boolean5 = polarPlot0.isSubplot();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        polarPlot0.rendererChanged(rendererChangeEvent6);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainGridlineStroke();
        java.awt.Paint paint2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeCrosshairPaint(paint2);
        xYPlot0.clearRangeMarkers(8);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double9 = numberAxis3D8.getFixedAutoRange();
        numberAxis3D8.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean13 = numberAxis3D8.isPositiveArrowVisible();
        java.lang.Object obj14 = numberAxis3D8.clone();
        java.text.NumberFormat numberFormat15 = null;
        numberAxis3D8.setNumberFormatOverride(numberFormat15);
        numberAxis3D8.setTickLabelsVisible(false);
        java.lang.String str19 = numberAxis3D8.getLabel();
        xYPlot0.setDomainAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis3D8, false);
        float float22 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.plot.Marker marker24 = null;
        org.jfree.chart.util.Layer layer25 = null;
        try {
            boolean boolean26 = xYPlot0.removeRangeMarker((int) (byte) 0, marker24, layer25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.plot.Plot plot5 = piePlot1.getRootPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D8.setMaximumCategoryLabelWidthRatio(10.0f);
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color12 = java.awt.Color.BLACK;
        categoryAxis3D8.setTickLabelPaint((java.lang.Comparable) date11, (java.awt.Paint) color12);
        piePlot1.setSectionPaint((java.lang.Comparable) "ThreadContext", (java.awt.Paint) color12);
        int int15 = color12.getRed();
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font3 = categoryAxis3D2.getLabelFont();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) color4, (float) (byte) 100);
        java.awt.Paint paint7 = textFragment6.getPaint();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        double double10 = textTitle9.getContentYOffset();
        java.lang.String str11 = textTitle9.getURLText();
        boolean boolean12 = textFragment6.equals((java.lang.Object) textTitle9);
        org.jfree.chart.text.TextBlock textBlock13 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = textBlock13.getLineAlignment();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        textBlock13.draw(graphics2D15, (float) ' ', (float) 10L, textBlockAnchor18, (float) (short) 1, 0.0f, (double) (byte) 1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = textBlock13.getLineAlignment();
        textTitle9.setTextAlignment(horizontalAlignment23);
        org.jfree.chart.util.VerticalAlignment verticalAlignment25 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement28 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment23, verticalAlignment25, 98.0d, (double) 0);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke30 = xYPlot29.getDomainZeroBaselineStroke();
        boolean boolean31 = columnArrangement28.equals((java.lang.Object) xYPlot29);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(verticalAlignment25);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        legendTitle1.setID("hi!");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot5.setShadowPaint((java.awt.Paint) color9);
        boolean boolean11 = legendTitle1.equals((java.lang.Object) piePlot5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        piePlot5.handleClick((int) (short) -1, (int) (byte) 10, plotRenderingInfo14);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor16 = piePlot5.getLabelDistributor();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor16);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.zoomRange((double) (short) 0, (double) 1L);
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis3D1.setDownArrow(shape6);
        numberAxis3D1.setTickLabelsVisible(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        legendTitle1.setID("hi!");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot5.setShadowPaint((java.awt.Paint) color9);
        boolean boolean11 = legendTitle1.equals((java.lang.Object) piePlot5);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke13 = ringPlot12.getSeparatorStroke();
        java.awt.Paint paint14 = ringPlot12.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double16 = rectangleInsets15.getTop();
        ringPlot12.setLabelPadding(rectangleInsets15);
        legendTitle1.setMargin(rectangleInsets15);
        java.lang.String str19 = legendTitle1.getID();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        boolean boolean4 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge3);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        double double3 = numberAxis3D1.getUpperBound();
        java.awt.Font font4 = numberAxis3D1.getTickLabelFont();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis3D1.java2DToValue((double) 10L, rectangle2D6, rectangleEdge7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double11 = numberAxis3D10.getFixedAutoRange();
        double double12 = numberAxis3D10.getUpperBound();
        double double13 = numberAxis3D10.getFixedAutoRange();
        org.jfree.data.RangeType rangeType14 = numberAxis3D10.getRangeType();
        numberAxis3D1.setRangeType(rangeType14);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range18 = numberAxis3D17.getRange();
        org.jfree.data.Range range20 = org.jfree.data.Range.shift(range18, (double) (-1.0f));
        numberAxis3D1.setRange(range18, false, false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rangeType14);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range20);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.block.BlockFrame blockFrame2 = legendTitle1.getFrame();
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle1.getItemContainer();
        double double4 = legendTitle1.getHeight();
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertNotNull(blockContainer3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 1, (double) 10);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot5);
        flowArrangement4.add((org.jfree.chart.block.Block) legendTitle6, (java.lang.Object) 2);
        legendTitle6.setWidth((double) 1L);
        legendTitle6.setHeight(1.0d);
        java.awt.Font font13 = legendTitle6.getItemFont();
        java.lang.Object obj14 = legendTitle6.clone();
        double double15 = legendTitle6.getContentYOffset();
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("Pie 3D Plot");
        java.awt.Shape shape2 = numberAxis3D1.getUpArrow();
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str1.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        double double3 = numberAxis3D1.getUpperBound();
        java.awt.Shape shape4 = numberAxis3D1.getUpArrow();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, 0, (int) (byte) 10, (java.lang.Comparable) 1.0d, "ThreadContext", "hi!");
        int int12 = pieSectionEntity11.getSectionIndex();
        pieSectionEntity11.setSectionKey((java.lang.Comparable) 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.mapDatasetToRangeAxis((int) (byte) 1, (int) '4');
        boolean boolean12 = categoryPlot0.getDrawSharedDomainAxis();
        java.awt.Paint paint13 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent14);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double21 = numberAxis3D20.getFixedAutoRange();
        double double22 = numberAxis3D20.getUpperBound();
        java.awt.Shape shape23 = numberAxis3D20.getUpArrow();
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis3D20.setAxisLineStroke(stroke24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis3D20, xYItemRenderer26);
        org.jfree.chart.plot.RingPlot ringPlot28 = new org.jfree.chart.plot.RingPlot();
        float float29 = ringPlot28.getForegroundAlpha();
        ringPlot28.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke34 = xYPlot33.getDomainGridlineStroke();
        boolean boolean35 = ringPlot28.equals((java.lang.Object) xYPlot33);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot33.getDomainAxisLocation(255);
        xYPlot27.setRangeAxisLocation(axisLocation37, true);
        categoryPlot0.setRangeAxisLocation(0, axisLocation37);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor41 = categoryPlot0.getDomainGridlinePosition();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 1.0f + "'", float29 == 1.0f);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(categoryAnchor41);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = categoryPlot0.getDatasetRenderingOrder();
        boolean boolean4 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setAutoTickUnitSelection(true, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = numberAxis3D1.getTickLabelInsets();
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font7 = polarPlot6.getAngleLabelFont();
        polarPlot6.addCornerTextItem("hi!");
        org.jfree.chart.plot.Plot plot10 = polarPlot6.getRootPlot();
        int int11 = polarPlot6.getSeriesCount();
        boolean boolean12 = numberAxis3D1.equals((java.lang.Object) polarPlot6);
        double double13 = numberAxis3D1.getAutoRangeMinimumSize();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        double double16 = rectangleInsets14.trimHeight(0.05d);
        numberAxis3D1.setTickLabelInsets(rectangleInsets14);
        numberAxis3D1.setInverted(true);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0E-8d + "'", double13 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.95d) + "'", double16 == (-1.95d));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot2.getFixedDomainAxisSpace();
        categoryPlot2.clearRangeAxes();
        categoryPlot2.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, true);
        java.awt.RenderingHints renderingHints11 = jFreeChart10.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle12 = jFreeChart10.getLegend();
        jFreeChart10.setTextAntiAlias(true);
        java.awt.image.BufferedImage bufferedImage17 = jFreeChart10.createBufferedImage(8, 15);
        org.jfree.chart.title.LegendTitle legendTitle18 = jFreeChart10.getLegend();
        org.jfree.chart.ui.ProjectInfo projectInfo19 = org.jfree.chart.JFreeChart.INFO;
        projectInfo19.setLicenceText("");
        java.awt.Image image22 = projectInfo19.getLogo();
        jFreeChart10.setBackgroundImage(image22);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertNotNull(renderingHints11);
        org.junit.Assert.assertNotNull(legendTitle12);
        org.junit.Assert.assertNotNull(bufferedImage17);
        org.junit.Assert.assertNotNull(legendTitle18);
        org.junit.Assert.assertNotNull(projectInfo19);
        org.junit.Assert.assertNotNull(image22);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke7 = ringPlot6.getSeparatorStroke();
        categoryPlot4.setDomainGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        categoryPlot4.setDomainAxisLocation((int) ' ', axisLocation10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot4.getRangeAxisEdge();
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 1, (int) '4');
        boolean boolean16 = categoryPlot4.getDrawSharedDomainAxis();
        java.awt.Paint paint17 = categoryPlot4.getRangeCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent18);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double25 = numberAxis3D24.getFixedAutoRange();
        double double26 = numberAxis3D24.getUpperBound();
        java.awt.Shape shape27 = numberAxis3D24.getUpArrow();
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis3D24.setAxisLineStroke(stroke28);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset21, valueAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis3D24, xYItemRenderer30);
        org.jfree.chart.plot.RingPlot ringPlot32 = new org.jfree.chart.plot.RingPlot();
        float float33 = ringPlot32.getForegroundAlpha();
        ringPlot32.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke38 = xYPlot37.getDomainGridlineStroke();
        boolean boolean39 = ringPlot32.equals((java.lang.Object) xYPlot37);
        org.jfree.chart.axis.AxisLocation axisLocation41 = xYPlot37.getDomainAxisLocation(255);
        xYPlot31.setRangeAxisLocation(axisLocation41, true);
        categoryPlot4.setRangeAxisLocation(0, axisLocation41);
        categoryPlot0.setDomainAxisLocation(axisLocation41, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        categoryPlot0.setRenderer(2, categoryItemRenderer48, true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 1.0f + "'", float33 == 1.0f);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(axisLocation41);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) (byte) 1, (double) 10);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot6);
        flowArrangement5.add((org.jfree.chart.block.Block) legendTitle7, (java.lang.Object) 2);
        flowArrangement5.clear();
        boolean boolean11 = size2D0.equals((java.lang.Object) flowArrangement5);
        java.lang.String str12 = size2D0.toString();
        size2D0.width = (byte) -1;
        size2D0.width = (byte) 0;
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str12.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) "UnitType.RELATIVE");
        java.awt.Stroke stroke4 = strokeMap0.getStroke((java.lang.Comparable) "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=-1.0]");
        strokeMap0.clear();
        java.awt.Stroke stroke7 = strokeMap0.getStroke((java.lang.Comparable) 0.4d);
        strokeMap0.clear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNull(stroke7);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke6 = categoryAxis3D5.getTickMarkStroke();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] { stroke2, stroke3, stroke6, stroke7, stroke8 };
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke12 = categoryAxis3D11.getTickMarkStroke();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke16 = categoryAxis3D15.getTickMarkStroke();
        java.awt.Stroke stroke17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] { stroke12, stroke13, stroke16, stroke17 };
        java.awt.Shape shape19 = null;
        java.awt.Shape[] shapeArray20 = new java.awt.Shape[] { shape19 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray9, strokeArray18, shapeArray20);
        org.jfree.chart.plot.RingPlot ringPlot22 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot22);
        legendTitle23.setHeight((double) (byte) 100);
        boolean boolean26 = defaultDrawingSupplier21.equals((java.lang.Object) legendTitle23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = legendTitle23.getLegendItemGraphicAnchor();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(shapeArray20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        double double3 = numberAxis3D1.getUpperBound();
        java.awt.Shape shape4 = numberAxis3D1.getUpArrow();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, 0, (int) (byte) 10, (java.lang.Comparable) 1.0d, "ThreadContext", "hi!");
        pieSectionEntity11.setSectionKey((java.lang.Comparable) (short) 1);
        java.lang.String str14 = pieSectionEntity11.toString();
        pieSectionEntity11.setSectionIndex((int) 'a');
        java.lang.String str17 = pieSectionEntity11.getShapeType();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PieSection: 0, 10(1)" + "'", str14.equals("PieSection: 0, 10(1)"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "poly" + "'", str17.equals("poly"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double4 = numberAxis3D3.getFixedAutoRange();
        double double5 = numberAxis3D3.getUpperBound();
        java.awt.Shape shape6 = numberAxis3D3.getUpArrow();
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis3D3.setAxisLineStroke(stroke7);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer9);
        xYPlot10.setRangeCrosshairValue((double) 500);
        boolean boolean13 = xYPlot10.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairValue((double) (short) 1, true);
        java.awt.Stroke stroke4 = xYPlot0.getRangeZeroBaselineStroke();
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setDomainZeroBaselinePaint(paint5);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        try {
            xYPlot0.setRenderer((-1), xYItemRenderer10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        java.lang.Object obj3 = dateAxis0.clone();
        org.jfree.data.Range range7 = new org.jfree.data.Range((-1.0d), 100.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, (double) (-1.0f));
        org.jfree.data.Range range11 = rectangleConstraint10.getWidthRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType12 = rectangleConstraint10.getWidthConstraintType();
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, (double) (-1.0f));
        org.jfree.data.Range range18 = rectangleConstraint17.getWidthRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = rectangleConstraint17.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((double) ' ', range7, lengthConstraintType12, (double) (byte) 0, range14, lengthConstraintType19);
        dateAxis0.setRange(range7);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(lengthConstraintType12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Stroke stroke2 = ringPlot1.getSeparatorStroke();
        ringPlot1.setSectionOutlinesVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.setRangeCrosshairValue((double) (short) 1, true);
        boolean boolean9 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D("Pie 3D Plot");
        int int12 = xYPlot5.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = xYPlot5.getAxisOffset();
        java.lang.Object obj14 = null;
        boolean boolean15 = xYPlot5.equals(obj14);
        boolean boolean16 = ringPlot1.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace17, true);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setAutoTickUnitSelection(true, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = numberAxis3D1.getTickLabelInsets();
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font7 = polarPlot6.getAngleLabelFont();
        polarPlot6.addCornerTextItem("hi!");
        org.jfree.chart.plot.Plot plot10 = polarPlot6.getRootPlot();
        int int11 = polarPlot6.getSeriesCount();
        boolean boolean12 = numberAxis3D1.equals((java.lang.Object) polarPlot6);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke15 = categoryAxis3D14.getTickMarkStroke();
        java.awt.Paint paint16 = categoryAxis3D14.getTickLabelPaint();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double21 = numberAxis3D20.getFixedAutoRange();
        numberAxis3D20.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean25 = numberAxis3D20.isPositiveArrowVisible();
        numberAxis3D20.centerRange(0.2d);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D31 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        double double36 = categoryAxis3D31.getCategoryStart((-1), (int) ' ', rectangle2D34, rectangleEdge35);
        boolean boolean37 = textTitle29.equals((java.lang.Object) categoryAxis3D31);
        textTitle29.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color40 = java.awt.Color.BLACK;
        textTitle29.setBackgroundPaint((java.awt.Paint) color40);
        java.awt.geom.Rectangle2D rectangle2D42 = textTitle29.getBounds();
        numberAxis3D20.setLeftArrow((java.awt.Shape) rectangle2D42);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        java.util.List list45 = categoryAxis3D14.refreshTicks(graphics2D17, axisState18, rectangle2D42, rectangleEdge44);
        numberAxis3D1.setRightArrow((java.awt.Shape) rectangle2D42);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(list45);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 3, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 'a');
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        org.jfree.data.Range range6 = org.jfree.data.Range.combine(range0, range5);
        org.jfree.data.Range range9 = org.jfree.data.Range.shift(range5, 0.0d, false);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range9);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairValue((double) (short) 1, true);
        java.awt.Stroke stroke4 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        float float6 = ringPlot5.getForegroundAlpha();
        ringPlot5.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke11 = xYPlot10.getDomainGridlineStroke();
        boolean boolean12 = ringPlot5.equals((java.lang.Object) xYPlot10);
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot10.getDomainAxisLocation(255);
        xYPlot0.setRangeAxisLocation(axisLocation14, true);
        xYPlot0.setDomainCrosshairLockedOnData(true);
        xYPlot0.setDomainCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainGridlineStroke();
        java.awt.Paint paint2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeCrosshairPaint(paint2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double6 = numberAxis3D5.getFixedAutoRange();
        double double7 = numberAxis3D5.getUpperBound();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D5.getLabelInsets();
        xYPlot0.setAxisOffset(rectangleInsets8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = xYPlot0.getRenderer();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        xYPlot0.rendererChanged(rendererChangeEvent11);
        xYPlot0.clearDomainMarkers(0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(xYItemRenderer10);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double3 = numberAxis3D2.getFixedAutoRange();
        double double4 = numberAxis3D2.getUpperBound();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range7 = numberAxis3D6.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double10 = numberAxis3D9.getFixedAutoRange();
        double double11 = numberAxis3D9.getUpperBound();
        java.awt.Shape shape12 = numberAxis3D9.getUpArrow();
        numberAxis3D6.setUpArrow(shape12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, xYItemRenderer14);
        org.jfree.chart.plot.Marker marker16 = null;
        try {
            boolean boolean17 = xYPlot15.removeDomainMarker(marker16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        categoryPlot0.clearDomainMarkers((int) (byte) 10);
        java.awt.Paint paint6 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=-1.0]", graphics2D1, (float) (-4144960), 0.0f, textAnchor4, (-1.95d), textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, (double) (-1.0f));
        org.jfree.data.Range range3 = rectangleConstraint2.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toFixedHeight((double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint5.toUnconstrainedHeight();
        double double7 = rectangleConstraint5.getHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint5.toFixedHeight(1.0d);
        double double10 = rectangleConstraint5.getWidth();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        legendTitle1.setID("hi!");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot5.setShadowPaint((java.awt.Paint) color9);
        boolean boolean11 = legendTitle1.equals((java.lang.Object) piePlot5);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle1.arrange(graphics2D12);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(size2D13);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke2 = categoryAxis3D1.getTickMarkStroke();
        java.awt.Paint paint3 = categoryAxis3D1.getTickLabelPaint();
        java.lang.String str5 = categoryAxis3D1.getCategoryLabelToolTip((java.lang.Comparable) "RectangleEdge.LEFT");
        categoryAxis3D1.setLabelAngle((-3.0d));
        java.lang.Object obj8 = categoryAxis3D1.clone();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("Pie Plot", "PieSection: 0, 10(1)", "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=-1.0]", image3, "RectangleEdge.LEFT", "Range[97.0,97.0]", "UnitType.RELATIVE");
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 'a');
        double double3 = range2.getUpperBound();
        boolean boolean6 = range2.intersects((double) (byte) 1, 100.0d);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo7 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str8 = basicProjectInfo7.getInfo();
        org.jfree.chart.ui.Library[] libraryArray9 = basicProjectInfo7.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray10 = basicProjectInfo7.getOptionalLibraries();
        boolean boolean11 = range2.equals((java.lang.Object) basicProjectInfo7);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(libraryArray9);
        org.junit.Assert.assertNotNull(libraryArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getLowerMargin();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        piePlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.plot.Plot plot8 = piePlot4.getRootPlot();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot4.setSectionOutlinePaint((java.lang.Comparable) 1, (java.awt.Paint) color10);
        numberAxis3D1.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis3D17.getCategoryStart((-1), (int) ' ', rectangle2D20, rectangleEdge21);
        boolean boolean23 = textTitle15.equals((java.lang.Object) categoryAxis3D17);
        textTitle15.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color26 = java.awt.Color.BLACK;
        textTitle15.setBackgroundPaint((java.awt.Paint) color26);
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle15.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace30 = categoryPlot29.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot31 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke32 = ringPlot31.getSeparatorStroke();
        categoryPlot29.setDomainGridlineStroke(stroke32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = null;
        categoryPlot29.setDomainAxisLocation((int) ' ', axisLocation35);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot29.getRangeAxisEdge();
        double double38 = numberAxis3D1.valueToJava2D(0.0d, rectangle2D28, rectangleEdge37);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double41 = numberAxis3D40.getFixedAutoRange();
        numberAxis3D40.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean45 = numberAxis3D40.isPositiveArrowVisible();
        java.lang.Object obj46 = numberAxis3D40.clone();
        java.text.NumberFormat numberFormat47 = null;
        numberAxis3D40.setNumberFormatOverride(numberFormat47);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D50 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double51 = numberAxis3D50.getFixedAutoRange();
        double double52 = numberAxis3D50.getUpperBound();
        java.awt.Shape shape53 = numberAxis3D50.getUpArrow();
        java.awt.Stroke stroke54 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis3D50.setAxisLineStroke(stroke54);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D57 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range58 = numberAxis3D57.getRange();
        org.jfree.data.Range range60 = org.jfree.data.Range.shift(range58, (double) (-1.0f));
        numberAxis3D50.setDefaultAutoRange(range58);
        numberAxis3D40.setRangeWithMargins(range58);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit63 = numberAxis3D40.getTickUnit();
        numberAxis3D1.setTickUnit(numberTickUnit63, true, true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNull(axisSpace30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNotNull(range60);
        org.junit.Assert.assertNotNull(numberTickUnit63);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double3 = numberAxis3D2.getFixedAutoRange();
        double double4 = numberAxis3D2.getUpperBound();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range7 = numberAxis3D6.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double10 = numberAxis3D9.getFixedAutoRange();
        double double11 = numberAxis3D9.getUpperBound();
        java.awt.Shape shape12 = numberAxis3D9.getUpArrow();
        numberAxis3D6.setUpArrow(shape12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, xYItemRenderer14);
        java.awt.Paint paint16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot15.setDomainGridlinePaint(paint16);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent18 = null;
        xYPlot15.markerChanged(markerChangeEvent18);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) "UnitType.RELATIVE");
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        categoryPlot4.setRangeCrosshairVisible(true);
        java.awt.Stroke stroke8 = categoryPlot4.getOutlineStroke();
        strokeMap0.put((java.lang.Comparable) 0.05d, stroke8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        try {
            java.awt.Color color1 = java.awt.Color.decode("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot5.getDomainAxisLocation(255);
        java.awt.Stroke stroke10 = xYPlot5.getRangeZeroBaselineStroke();
        int int11 = xYPlot5.getSeriesCount();
        boolean boolean12 = xYPlot5.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot2.getFixedDomainAxisSpace();
        categoryPlot2.clearRangeAxes();
        categoryPlot2.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, true);
        java.awt.RenderingHints renderingHints11 = jFreeChart10.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle12 = jFreeChart10.getLegend();
        jFreeChart10.setTitle("hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment15, verticalAlignment16, (double) (byte) 1, (double) 10);
        org.jfree.chart.plot.RingPlot ringPlot20 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot20);
        flowArrangement19.add((org.jfree.chart.block.Block) legendTitle21, (java.lang.Object) 2);
        legendTitle21.setWidth((double) 1L);
        legendTitle21.setHeight(1.0d);
        java.awt.Font font28 = legendTitle21.getItemFont();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D30.setAutoTickUnitSelection(true, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = numberAxis3D30.getTickLabelInsets();
        org.jfree.chart.plot.PolarPlot polarPlot35 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font36 = polarPlot35.getAngleLabelFont();
        polarPlot35.addCornerTextItem("hi!");
        org.jfree.chart.plot.Plot plot39 = polarPlot35.getRootPlot();
        int int40 = polarPlot35.getSeriesCount();
        boolean boolean41 = numberAxis3D30.equals((java.lang.Object) polarPlot35);
        double double42 = numberAxis3D30.getAutoRangeMinimumSize();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = new org.jfree.chart.util.RectangleInsets();
        double double45 = rectangleInsets43.trimHeight(0.05d);
        numberAxis3D30.setTickLabelInsets(rectangleInsets43);
        legendTitle21.setItemLabelPadding(rectangleInsets43);
        jFreeChart10.setPadding(rectangleInsets43);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertNotNull(renderingHints11);
        org.junit.Assert.assertNotNull(legendTitle12);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(plot39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0E-8d + "'", double42 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + (-1.95d) + "'", double45 == (-1.95d));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setAutoTickUnitSelection(true, false);
        boolean boolean5 = numberAxis3D1.isTickLabelsVisible();
        java.lang.String str6 = numberAxis3D1.getLabel();
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis3D1.setAxisLineStroke(stroke7);
        numberAxis3D1.setFixedDimension(0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setExplodedPieArea(rectangle2D2);
        double double4 = piePlotState1.getTotal();
        piePlotState1.setLatestAngle((double) (short) -1);
        piePlotState1.setPassesRequired(10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 'a');
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        org.jfree.data.Range range6 = org.jfree.data.Range.combine(range0, range5);
        org.jfree.data.Range range8 = org.jfree.data.Range.shift(range6, 1.0E-5d);
        double double10 = range6.constrain(97.0d);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        dateAxis0.setTimeZone(timeZone4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        dateAxis0.setTimeZone(timeZone7);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot2.getFixedDomainAxisSpace();
        categoryPlot2.clearRangeAxes();
        categoryPlot2.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, true);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        categoryPlot2.setNoDataMessagePaint((java.awt.Paint) color11);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double5 = numberAxis3D4.getFixedAutoRange();
        double double6 = numberAxis3D4.getUpperBound();
        java.awt.Shape shape7 = numberAxis3D4.getUpArrow();
        numberAxis3D1.setUpArrow(shape7);
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        numberAxis3D1.setLabel("java.awt.Color[r=0,g=0,b=0]");
        numberAxis3D1.setUpperBound(1.0E-8d);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean6 = numberAxis3D1.isPositiveArrowVisible();
        java.lang.Object obj7 = numberAxis3D1.clone();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat8);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double12 = numberAxis3D11.getFixedAutoRange();
        double double13 = numberAxis3D11.getUpperBound();
        java.awt.Shape shape14 = numberAxis3D11.getUpArrow();
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis3D11.setAxisLineStroke(stroke15);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range19 = numberAxis3D18.getRange();
        org.jfree.data.Range range21 = org.jfree.data.Range.shift(range19, (double) (-1.0f));
        numberAxis3D11.setDefaultAutoRange(range19);
        numberAxis3D1.setRangeWithMargins(range19);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit24 = numberAxis3D1.getTickUnit();
        java.awt.Shape shape25 = numberAxis3D1.getLeftArrow();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(numberTickUnit24);
        org.junit.Assert.assertNotNull(shape25);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke2 = categoryAxis3D1.getTickMarkStroke();
        java.awt.Paint paint3 = categoryAxis3D1.getTickLabelPaint();
        java.lang.String str5 = categoryAxis3D1.getCategoryLabelToolTip((java.lang.Comparable) "RectangleEdge.LEFT");
        float float6 = categoryAxis3D1.getTickMarkInsideLength();
        categoryAxis3D1.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainZeroBaselineStroke();
        double double2 = xYPlot0.getDomainCrosshairValue();
        java.awt.Color color3 = java.awt.Color.white;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo9 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "");
        org.jfree.chart.JFreeChart jFreeChart10 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType11 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "hi!", jFreeChart10, chartChangeEventType11);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = chartChangeEvent12.getType();
        java.awt.Font font15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot16.getFixedDomainAxisSpace();
        categoryPlot16.clearRangeAxes();
        categoryPlot16.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray21 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer20 };
        categoryPlot16.setRenderers(categoryItemRendererArray21);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("Pie Plot", font15, (org.jfree.chart.plot.Plot) categoryPlot16, true);
        java.awt.RenderingHints renderingHints25 = jFreeChart24.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle26 = jFreeChart24.getLegend();
        jFreeChart24.setTextAntiAlias(true);
        chartChangeEvent12.setChart(jFreeChart24);
        java.util.List list30 = jFreeChart24.getSubtitles();
        jFreeChart24.setAntiAlias(false);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType33 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent34 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart24, chartChangeEventType33);
        jFreeChart24.setNotify(false);
        xYPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart24);
        xYPlot0.clearAnnotations();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        xYPlot0.setRenderer(xYItemRenderer39);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(chartChangeEventType13);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(categoryItemRendererArray21);
        org.junit.Assert.assertNotNull(renderingHints25);
        org.junit.Assert.assertNotNull(legendTitle26);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(chartChangeEventType33);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke6 = categoryAxis3D5.getTickMarkStroke();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] { stroke2, stroke3, stroke6, stroke7, stroke8 };
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke12 = categoryAxis3D11.getTickMarkStroke();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke16 = categoryAxis3D15.getTickMarkStroke();
        java.awt.Stroke stroke17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] { stroke12, stroke13, stroke16, stroke17 };
        java.awt.Shape shape19 = null;
        java.awt.Shape[] shapeArray20 = new java.awt.Shape[] { shape19 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray9, strokeArray18, shapeArray20);
        java.awt.Shape shape22 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape23 = defaultDrawingSupplier21.getNextShape();
        java.awt.Paint paint24 = defaultDrawingSupplier21.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(shapeArray20);
        org.junit.Assert.assertNull(shape22);
        org.junit.Assert.assertNull(shape23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 100);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        java.awt.Paint paint4 = ringPlot2.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double6 = rectangleInsets5.getTop();
        ringPlot2.setLabelPadding(rectangleInsets5);
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        ringPlot2.setLabelBackgroundPaint((java.awt.Paint) color8);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color8);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot0.getRangeAxisForDataset(0);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot0.getAxisOffset();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range3 = new org.jfree.data.Range((-1.0d), 100.0d);
        double double4 = range3.getCentralValue();
        org.jfree.data.Range range5 = org.jfree.data.Range.combine(range0, range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 49.5d + "'", double4 == 49.5d);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        java.awt.Paint paint4 = ringPlot2.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double6 = rectangleInsets5.getTop();
        ringPlot2.setLabelPadding(rectangleInsets5);
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        ringPlot2.setLabelBackgroundPaint((java.awt.Paint) color8);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color8);
        org.jfree.chart.axis.AxisLocation axisLocation13 = null;
        categoryPlot0.setRangeAxisLocation(100, axisLocation13, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot0.setRenderer((int) '#', categoryItemRenderer17);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.zoom(100.0d);
        double double3 = ringPlot0.getInteriorGap();
        ringPlot0.setLabelLinksVisible(true);
        java.awt.Stroke stroke6 = ringPlot0.getSeparatorStroke();
        org.jfree.data.general.PieDataset pieDataset7 = ringPlot0.getDataset();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(pieDataset7);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainGridlineStroke();
        java.awt.Paint paint2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeCrosshairPaint(paint2);
        xYPlot0.setBackgroundAlpha(100.0f);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, (double) (-1.0f));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke6 = categoryAxis3D5.getTickMarkStroke();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] { stroke2, stroke3, stroke6, stroke7, stroke8 };
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke12 = categoryAxis3D11.getTickMarkStroke();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke16 = categoryAxis3D15.getTickMarkStroke();
        java.awt.Stroke stroke17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] { stroke12, stroke13, stroke16, stroke17 };
        java.awt.Shape shape19 = null;
        java.awt.Shape[] shapeArray20 = new java.awt.Shape[] { shape19 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray9, strokeArray18, shapeArray20);
        java.awt.Shape shape22 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape23 = defaultDrawingSupplier21.getNextShape();
        java.awt.Stroke stroke24 = defaultDrawingSupplier21.getNextStroke();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(shapeArray20);
        org.junit.Assert.assertNull(shape22);
        org.junit.Assert.assertNull(shape23);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font2 = polarPlot1.getAngleLabelFont();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke4 = ringPlot3.getSeparatorStroke();
        java.awt.Paint paint5 = ringPlot3.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double7 = rectangleInsets6.getTop();
        ringPlot3.setLabelPadding(rectangleInsets6);
        java.awt.Color color9 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace10 = color9.getColorSpace();
        ringPlot3.setLabelBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("", font2, (java.awt.Paint) color9);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D14.setAutoTickUnitSelection(true, false);
        boolean boolean18 = numberAxis3D14.isTickLabelsVisible();
        java.lang.Object obj19 = numberAxis3D14.clone();
        boolean boolean20 = textFragment12.equals((java.lang.Object) numberAxis3D14);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit21 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D14.setTickUnit(numberTickUnit21);
        java.awt.Shape shape23 = numberAxis3D14.getDownArrow();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(numberTickUnit21);
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.setAutoTickUnitSelection(true, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D3.getTickLabelInsets();
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font9 = polarPlot8.getAngleLabelFont();
        polarPlot8.addCornerTextItem("hi!");
        org.jfree.chart.plot.Plot plot12 = polarPlot8.getRootPlot();
        int int13 = polarPlot8.getSeriesCount();
        boolean boolean14 = numberAxis3D3.equals((java.lang.Object) polarPlot8);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = polarPlot8.getInsets();
        legendTitle1.setItemLabelPadding(rectangleInsets15);
        java.awt.Paint paint17 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder(rectangleInsets15, paint17);
        java.awt.Paint paint19 = blockBorder18.getPaint();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(plot12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font4 = categoryAxis3D3.getLabelFont();
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font4);
        org.jfree.chart.text.TextFragment textFragment6 = null;
        textLine5.addFragment(textFragment6);
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Image image10 = polarPlot9.getBackgroundImage();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        polarPlot9.setRenderer(polarItemRenderer11);
        java.awt.Font font13 = polarPlot9.getAngleLabelFont();
        java.awt.Paint paint14 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("UnitType.RELATIVE", font13, paint14, 10.0f);
        textLine5.addFragment(textFragment16);
        textLine0.addFragment(textFragment16);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        piePlot20.drawBackgroundImage(graphics2D21, rectangle2D22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot20.setShadowPaint((java.awt.Paint) color24);
        boolean boolean26 = textFragment16.equals((java.lang.Object) piePlot20);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(image10);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.zoom(100.0d);
        double double3 = ringPlot0.getInteriorGap();
        ringPlot0.setLabelLinksVisible(true);
        java.awt.Stroke stroke6 = ringPlot0.getSeparatorStroke();
        double double7 = ringPlot0.getInnerSeparatorExtension();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        xYPlot5.setRenderer(8, xYItemRenderer9);
        boolean boolean11 = xYPlot5.isRangeZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        polarPlot0.addCornerTextItem("hi!");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        polarPlot0.zoomDomainAxes((double) (short) 10, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        try {
            polarPlot0.zoomRangeAxes(10.0d, plotRenderingInfo9, point2D10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getLegendItems();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation2 = null;
        try {
            boolean boolean3 = categoryPlot0.removeAnnotation(categoryAnnotation2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection1);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double6 = numberAxis3D5.getFixedAutoRange();
        double double7 = numberAxis3D5.getUpperBound();
        java.awt.Shape shape8 = numberAxis3D5.getUpArrow();
        numberAxis3D2.setUpArrow(shape8);
        int int10 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D2);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        int int12 = xYPlot0.indexOf(xYDataset11);
        java.awt.Paint paint13 = xYPlot0.getDomainTickBandPaint();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D16.setAutoTickUnitSelection(true, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = numberAxis3D16.getTickLabelInsets();
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font22 = polarPlot21.getAngleLabelFont();
        polarPlot21.addCornerTextItem("hi!");
        org.jfree.chart.plot.Plot plot25 = polarPlot21.getRootPlot();
        int int26 = polarPlot21.getSeriesCount();
        boolean boolean27 = numberAxis3D16.equals((java.lang.Object) polarPlot21);
        numberAxis3D16.setUpperBound((double) 0.0f);
        numberAxis3D16.setFixedDimension(1.0E-5d);
        org.jfree.data.Range range32 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D16);
        numberAxis3D16.setAutoRangeStickyZero(false);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(plot25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(range32);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomRangeAxes(10.0d, plotRenderingInfo2, point2D3, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer((int) (short) 1, xYItemRenderer7);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = xYPlot0.getFixedLegendItems();
        org.junit.Assert.assertNull(legendItemCollection9);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        java.lang.Object obj3 = dateAxis0.clone();
        java.text.DateFormat dateFormat4 = dateAxis0.getDateFormatOverride();
        java.lang.String str5 = dateAxis0.getLabel();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(dateFormat4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Paint paint2 = textTitle1.getBackgroundPaint();
        java.awt.Paint paint3 = textTitle1.getPaint();
        java.lang.String str4 = textTitle1.getURLText();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = legendTitle1.getVerticalAlignment();
        double double3 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle1.getPadding();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D6.setAutoTickUnitSelection(true, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis3D6.getTickLabelInsets();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font12 = polarPlot11.getAngleLabelFont();
        polarPlot11.addCornerTextItem("hi!");
        org.jfree.chart.plot.Plot plot15 = polarPlot11.getRootPlot();
        int int16 = polarPlot11.getSeriesCount();
        boolean boolean17 = numberAxis3D6.equals((java.lang.Object) polarPlot11);
        double double18 = numberAxis3D6.getAutoRangeMinimumSize();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets();
        double double21 = rectangleInsets19.trimHeight(0.05d);
        numberAxis3D6.setTickLabelInsets(rectangleInsets19);
        double double24 = rectangleInsets19.trimHeight((double) (-1));
        legendTitle1.setItemLabelPadding(rectangleInsets19);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(plot15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0E-8d + "'", double18 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.95d) + "'", double21 == (-1.95d));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-3.0d) + "'", double24 == (-3.0d));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        java.awt.Paint paint8 = ringPlot0.getLabelBackgroundPaint();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D10.setMaximumCategoryLabelWidthRatio(10.0f);
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color14 = java.awt.Color.BLACK;
        categoryAxis3D10.setTickLabelPaint((java.lang.Comparable) date13, (java.awt.Paint) color14);
        try {
            double double16 = ringPlot0.getExplodePercent((java.lang.Comparable) date13);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Short cannot be cast to java.util.Date");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.FlowArrangement flowArrangement1 = new org.jfree.chart.block.FlowArrangement();
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement1);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo8 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "hi!", "hi!");
        basicProjectInfo8.setLicenceName("");
        boolean boolean11 = blockContainer0.equals((java.lang.Object) "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D2.setTickMarkInsideLength((float) (byte) 1);
        java.awt.Stroke stroke5 = categoryAxis3D2.getTickMarkStroke();
        java.awt.Font font7 = categoryAxis3D2.getTickLabelFont((java.lang.Comparable) "{0}");
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace9 = categoryPlot8.getFixedDomainAxisSpace();
        categoryPlot8.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot8.getDomainAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = categoryAxis3D14.getCategoryStart((-1), (int) ' ', rectangle2D17, rectangleEdge18);
        java.util.List list20 = categoryPlot12.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D14);
        java.awt.Paint paint21 = categoryPlot12.getRangeGridlinePaint();
        categoryPlot8.setRangeCrosshairPaint(paint21);
        categoryPlot8.mapDatasetToRangeAxis((int) (byte) 1, (int) (short) -1);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", font7, (org.jfree.chart.plot.Plot) categoryPlot8, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation28 = null;
        try {
            boolean boolean29 = categoryPlot8.removeAnnotation(categoryAnnotation28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        double double3 = numberAxis3D1.getUpperBound();
        java.awt.Shape shape4 = numberAxis3D1.getUpArrow();
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis3D1.setAxisLineStroke(stroke5);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range9 = numberAxis3D8.getRange();
        org.jfree.data.Range range11 = org.jfree.data.Range.shift(range9, (double) (-1.0f));
        numberAxis3D1.setDefaultAutoRange(range9);
        boolean boolean15 = range9.intersects(3.0d, 1.0E-5d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) (byte) 1, (double) 10);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot6);
        flowArrangement5.add((org.jfree.chart.block.Block) legendTitle7, (java.lang.Object) 2);
        flowArrangement5.clear();
        boolean boolean11 = size2D0.equals((java.lang.Object) flowArrangement5);
        java.lang.String str12 = size2D0.toString();
        size2D0.width = (byte) -1;
        size2D0.setWidth(0.025d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str12.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat1 = standardPieSectionLabelGenerator0.getPercentFormat();
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator0.getNumberFormat();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets(0.08d, 10.0d, (double) (byte) 10, (double) '#');
        java.awt.Color color8 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(rectangleInsets7, (java.awt.Paint) color8);
        java.awt.Color color10 = java.awt.Color.MAGENTA;
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace12 = color11.getColorSpace();
        java.awt.color.ColorSpace colorSpace13 = color11.getColorSpace();
        float[] floatArray20 = new float[] { (short) 10, 0L, '4', ' ', 10L, 'a' };
        float[] floatArray21 = color10.getComponents(colorSpace13, floatArray20);
        float[] floatArray22 = color8.getRGBColorComponents(floatArray20);
        boolean boolean23 = standardPieSectionLabelGenerator0.equals((java.lang.Object) floatArray22);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace12);
        org.junit.Assert.assertNotNull(colorSpace13);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        double double3 = numberAxis3D1.getUpperBound();
        java.awt.Shape shape4 = numberAxis3D1.getUpArrow();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, 0, (int) (byte) 10, (java.lang.Comparable) 1.0d, "ThreadContext", "hi!");
        pieSectionEntity11.setSectionKey((java.lang.Comparable) (short) 1);
        java.lang.String str14 = pieSectionEntity11.toString();
        int int15 = pieSectionEntity11.getPieIndex();
        java.lang.String str16 = pieSectionEntity11.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PieSection: 0, 10(1)" + "'", str14.equals("PieSection: 0, 10(1)"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "PieSection: 0, 10(1)" + "'", str16.equals("PieSection: 0, 10(1)"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "");
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "hi!", jFreeChart6, chartChangeEventType7);
        java.lang.Object obj9 = chartChangeEvent8.getSource();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo15 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "");
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "hi!", jFreeChart16, chartChangeEventType17);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = chartChangeEvent18.getType();
        java.awt.Font font21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace23 = categoryPlot22.getFixedDomainAxisSpace();
        categoryPlot22.clearRangeAxes();
        categoryPlot22.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray27 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer26 };
        categoryPlot22.setRenderers(categoryItemRendererArray27);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("Pie Plot", font21, (org.jfree.chart.plot.Plot) categoryPlot22, true);
        java.awt.RenderingHints renderingHints31 = jFreeChart30.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle32 = jFreeChart30.getLegend();
        jFreeChart30.setTextAntiAlias(true);
        chartChangeEvent18.setChart(jFreeChart30);
        chartChangeEvent8.setChart(jFreeChart30);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = jFreeChart30.getCategoryPlot();
        org.jfree.chart.title.LegendTitle legendTitle39 = jFreeChart30.getLegend((int) (short) 10);
        org.junit.Assert.assertTrue("'" + obj9 + "' != '" + "hi!" + "'", obj9.equals("hi!"));
        org.junit.Assert.assertNull(chartChangeEventType19);
        org.junit.Assert.assertNull(axisSpace23);
        org.junit.Assert.assertNotNull(categoryItemRendererArray27);
        org.junit.Assert.assertNotNull(renderingHints31);
        org.junit.Assert.assertNotNull(legendTitle32);
        org.junit.Assert.assertNotNull(categoryPlot37);
        org.junit.Assert.assertNull(legendTitle39);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot2.getFixedDomainAxisSpace();
        categoryPlot2.clearRangeAxes();
        categoryPlot2.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, true);
        java.awt.RenderingHints renderingHints11 = jFreeChart10.getRenderingHints();
        java.awt.Stroke stroke12 = jFreeChart10.getBorderStroke();
        boolean boolean13 = jFreeChart10.isBorderVisible();
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertNotNull(renderingHints11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        org.junit.Assert.assertNull(dateTickUnit3);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("org.jfree.chart.event.ChartChangeEvent[source=hi!]", "Polar Plot", numberArray8);
        java.lang.Number number10 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset9, (java.lang.Comparable) 8);
        double double13 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset12);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.0d + "'", number10.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.String str2 = multiplePiePlot1.getPlotType();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = multiplePiePlot1.getLegendItems();
        java.lang.Comparable comparable4 = multiplePiePlot1.getAggregatedItemsKey();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke6 = ringPlot5.getSeparatorStroke();
        double double7 = ringPlot5.getInnerSeparatorExtension();
        ringPlot5.setLabelLinkMargin(35.0d);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke11 = xYPlot10.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = xYPlot10.getDataRange(valueAxis12);
        java.awt.Stroke stroke14 = xYPlot10.getRangeZeroBaselineStroke();
        ringPlot5.setBaseSectionOutlineStroke(stroke14);
        multiplePiePlot1.setOutlineStroke(stroke14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "Other" + "'", comparable4.equals("Other"));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomRangeAxes(10.0d, plotRenderingInfo2, point2D3, false);
        org.jfree.chart.axis.AxisSpace axisSpace6 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D8 = xYPlot7.getQuadrantOrigin();
        xYPlot0.setQuadrantOrigin(point2D8);
        xYPlot0.configureRangeAxes();
        int int11 = xYPlot0.getDatasetCount();
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(point2D8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) (byte) 10, 49.5d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainGridlineStroke();
        float float2 = xYPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5f + "'", float2 == 0.5f);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double3 = numberAxis3D2.getFixedAutoRange();
        double double4 = numberAxis3D2.getUpperBound();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range7 = numberAxis3D6.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double10 = numberAxis3D9.getFixedAutoRange();
        double double11 = numberAxis3D9.getUpperBound();
        java.awt.Shape shape12 = numberAxis3D9.getUpArrow();
        numberAxis3D6.setUpArrow(shape12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, xYItemRenderer14);
        org.jfree.chart.plot.Plot plot16 = numberAxis3D2.getPlot();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(plot16);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.plot.Plot plot5 = piePlot1.getRootPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D8.setMaximumCategoryLabelWidthRatio(10.0f);
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color12 = java.awt.Color.BLACK;
        categoryAxis3D8.setTickLabelPaint((java.lang.Comparable) date11, (java.awt.Paint) color12);
        piePlot1.setSectionPaint((java.lang.Comparable) "ThreadContext", (java.awt.Paint) color12);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        boolean boolean16 = piePlot1.equals((java.lang.Object) defaultDrawingSupplier15);
        java.awt.Image image17 = piePlot1.getBackgroundImage();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor18 = piePlot1.getLabelDistributor();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord20 = abstractPieLabelDistributor18.getPieLabelRecord(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor18);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("TextBlockAnchor.BOTTOM_LEFT");
        java.lang.String str2 = textFragment1.getText();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextBlockAnchor.BOTTOM_LEFT" + "'", str2.equals("TextBlockAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) polarPlot0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double5 = numberAxis3D4.getFixedAutoRange();
        numberAxis3D4.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean9 = numberAxis3D4.isPositiveArrowVisible();
        java.lang.Object obj10 = numberAxis3D4.clone();
        java.text.NumberFormat numberFormat11 = null;
        numberAxis3D4.setNumberFormatOverride(numberFormat11);
        numberAxis3D4.setTickLabelsVisible(false);
        java.lang.String str15 = numberAxis3D4.getLabel();
        boolean boolean16 = numberAxis3D4.getAutoRangeIncludesZero();
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D4);
        java.lang.String str18 = polarPlot0.getPlotType();
        org.jfree.chart.axis.TickUnit tickUnit19 = polarPlot0.getAngleTickUnit();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Polar Plot" + "'", str18.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(tickUnit19);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 15, 2.4d, 100.0d };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 15, 2.4d, 100.0d };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 15, 2.4d, 100.0d };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 15, 2.4d, 100.0d };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 15, 2.4d, 100.0d };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 15, 2.4d, 100.0d };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Rotation.ANTICLOCKWISE", "0,0,-2,2,2,2,2,2", numberArray26);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.setVerticalTickLabels(false);
        java.awt.Paint paint5 = numberAxis3D1.getTickMarkPaint();
        org.jfree.chart.event.AxisChangeListener axisChangeListener6 = null;
        numberAxis3D1.addChangeListener(axisChangeListener6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot2.getFixedDomainAxisSpace();
        categoryPlot2.clearRangeAxes();
        categoryPlot2.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, true);
        java.awt.RenderingHints renderingHints11 = jFreeChart10.getRenderingHints();
        try {
            org.jfree.chart.title.Title title13 = jFreeChart10.getSubtitle(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertNotNull(renderingHints11);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getTotal();
        double double3 = piePlotState1.getPieCenterY();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        polarPlot0.addCornerTextItem("");
        int int4 = polarPlot0.getSeriesCount();
        org.jfree.chart.axis.TickUnit tickUnit5 = polarPlot0.getAngleTickUnit();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(tickUnit5);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        legendTitle1.setHeight((double) (byte) 100);
        org.jfree.chart.block.BlockContainer blockContainer4 = legendTitle1.getItemContainer();
        boolean boolean5 = blockContainer4.isEmpty();
        blockContainer4.setHeight((double) (byte) 10);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets();
        double double11 = rectangleInsets9.trimHeight(0.05d);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis3D15.getCategoryStart((-1), (int) ' ', rectangle2D18, rectangleEdge19);
        boolean boolean21 = textTitle13.equals((java.lang.Object) categoryAxis3D15);
        textTitle13.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color24 = java.awt.Color.BLACK;
        textTitle13.setBackgroundPaint((java.awt.Paint) color24);
        java.awt.geom.Rectangle2D rectangle2D26 = textTitle13.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType27 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets9.createAdjustedRectangle(rectangle2D26, lengthAdjustmentType27, lengthAdjustmentType28);
        try {
            blockContainer4.draw(graphics2D8, rectangle2D29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockContainer4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.95d) + "'", double11 == (-1.95d));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D29);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font2 = polarPlot1.getAngleLabelFont();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke4 = ringPlot3.getSeparatorStroke();
        java.awt.Paint paint5 = ringPlot3.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double7 = rectangleInsets6.getTop();
        ringPlot3.setLabelPadding(rectangleInsets6);
        java.awt.Color color9 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace10 = color9.getColorSpace();
        ringPlot3.setLabelBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("", font2, (java.awt.Paint) color9);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D14.setAutoTickUnitSelection(true, false);
        boolean boolean18 = numberAxis3D14.isTickLabelsVisible();
        java.lang.Object obj19 = numberAxis3D14.clone();
        boolean boolean20 = textFragment12.equals((java.lang.Object) numberAxis3D14);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit21 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D14.setTickUnit(numberTickUnit21);
        numberAxis3D14.setAutoTickUnitSelection(false);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(numberTickUnit21);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.height = 2.4d;
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        polarPlot0.addCornerTextItem("hi!");
        org.jfree.chart.plot.Plot plot4 = polarPlot0.getRootPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        polarPlot0.addChangeListener(plotChangeListener5);
        java.awt.Font font8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot9.getFixedDomainAxisSpace();
        categoryPlot9.clearRangeAxes();
        categoryPlot9.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("Pie Plot", font8, (org.jfree.chart.plot.Plot) categoryPlot9, true);
        jFreeChart17.setBorderVisible(false);
        polarPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart17);
        int int21 = jFreeChart17.getSubtitleCount();
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        jFreeChart17.setBackgroundPaint((java.awt.Paint) color22);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint3 = piePlot1.getSectionPaint((java.lang.Comparable) 8);
        piePlot1.setShadowYOffset((double) 2);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = legendTitle1.getVerticalAlignment();
        java.lang.Object obj3 = legendTitle1.clone();
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        float float4 = ringPlot3.getForegroundAlpha();
        ringPlot3.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke9 = xYPlot8.getDomainGridlineStroke();
        boolean boolean10 = ringPlot3.equals((java.lang.Object) xYPlot8);
        org.jfree.chart.axis.AxisLocation axisLocation12 = xYPlot8.getDomainAxisLocation(255);
        xYPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation12, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double17 = numberAxis3D16.getFixedAutoRange();
        numberAxis3D16.setLabelAngle((double) 10L);
        org.jfree.data.Range range20 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D16);
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font24 = polarPlot23.getAngleLabelFont();
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke26 = ringPlot25.getSeparatorStroke();
        java.awt.Paint paint27 = ringPlot25.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double29 = rectangleInsets28.getTop();
        ringPlot25.setLabelPadding(rectangleInsets28);
        java.awt.Color color31 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace32 = color31.getColorSpace();
        ringPlot25.setLabelBackgroundPaint((java.awt.Paint) color31);
        org.jfree.chart.text.TextFragment textFragment34 = new org.jfree.chart.text.TextFragment("", font24, (java.awt.Paint) color31);
        java.awt.Paint paint35 = textFragment34.getPaint();
        xYPlot0.setQuadrantPaint(0, paint35);
        org.jfree.chart.axis.ValueAxis valueAxis37 = xYPlot0.getRangeAxis();
        org.jfree.chart.plot.Marker marker38 = null;
        org.jfree.chart.util.Layer layer39 = null;
        try {
            xYPlot0.addDomainMarker(marker38, layer39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(colorSpace32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNull(valueAxis37);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Pie Plot", graphics2D1, 0.0f, 10.0f, textAnchor4, 0.0d, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer4 };
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        org.jfree.chart.axis.AxisSpace axisSpace7 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke11 = categoryAxis3D10.getTickMarkStroke();
        categoryAxis3D10.configure();
        java.lang.Number[] numberArray17 = new java.lang.Number[] {};
        java.lang.Number[] numberArray18 = new java.lang.Number[] {};
        java.lang.Number[] numberArray19 = new java.lang.Number[] {};
        java.lang.Number[] numberArray20 = new java.lang.Number[] {};
        java.lang.Number[] numberArray21 = new java.lang.Number[] {};
        java.lang.Number[] numberArray22 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray23 = new java.lang.Number[][] { numberArray17, numberArray18, numberArray19, numberArray20, numberArray21, numberArray22 };
        org.jfree.data.category.CategoryDataset categoryDataset24 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("org.jfree.chart.event.ChartChangeEvent[source=hi!]", "Polar Plot", numberArray23);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = new org.jfree.chart.util.RectangleInsets();
        double double28 = rectangleInsets26.trimHeight(0.05d);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D32 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = categoryAxis3D32.getCategoryStart((-1), (int) ' ', rectangle2D35, rectangleEdge36);
        boolean boolean38 = textTitle30.equals((java.lang.Object) categoryAxis3D32);
        textTitle30.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color41 = java.awt.Color.BLACK;
        textTitle30.setBackgroundPaint((java.awt.Paint) color41);
        java.awt.geom.Rectangle2D rectangle2D43 = textTitle30.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType44 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets26.createAdjustedRectangle(rectangle2D43, lengthAdjustmentType44, lengthAdjustmentType45);
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer48 = null;
        java.util.Collection collection49 = categoryPlot47.getDomainMarkers(layer48);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = categoryPlot47.getRangeAxisEdge((int) 'a');
        double double52 = categoryAxis3D10.getCategorySeriesMiddle((java.lang.Comparable) "", (java.lang.Comparable) 255, categoryDataset24, (double) 10L, rectangle2D46, rectangleEdge51);
        try {
            categoryPlot0.setDomainAxis((int) (short) -1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertNull(axisSpace7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-1.95d) + "'", double28 == (-1.95d));
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNull(collection49);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        float float4 = ringPlot3.getForegroundAlpha();
        ringPlot3.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke9 = xYPlot8.getDomainGridlineStroke();
        boolean boolean10 = ringPlot3.equals((java.lang.Object) xYPlot8);
        org.jfree.chart.axis.AxisLocation axisLocation12 = xYPlot8.getDomainAxisLocation(255);
        xYPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation12, true);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        int int16 = xYPlot0.indexOf(xYDataset15);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=-1.0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlot1.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        piePlot1.setSimpleLabelOffset(rectangleInsets5);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("XY Plot");
        categoryAxis3D8.setLabelToolTip("ThreadContext");
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double15 = numberAxis3D14.getLowerMargin();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        piePlot17.drawBackgroundImage(graphics2D18, rectangle2D19);
        org.jfree.chart.plot.Plot plot21 = piePlot17.getRootPlot();
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot17.setSectionOutlinePaint((java.lang.Comparable) 1, (java.awt.Paint) color23);
        numberAxis3D14.setLabelPaint((java.awt.Paint) color23);
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D30 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = null;
        double double35 = categoryAxis3D30.getCategoryStart((-1), (int) ' ', rectangle2D33, rectangleEdge34);
        boolean boolean36 = textTitle28.equals((java.lang.Object) categoryAxis3D30);
        textTitle28.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color39 = java.awt.Color.BLACK;
        textTitle28.setBackgroundPaint((java.awt.Paint) color39);
        java.awt.geom.Rectangle2D rectangle2D41 = textTitle28.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace43 = categoryPlot42.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot44 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke45 = ringPlot44.getSeparatorStroke();
        categoryPlot42.setDomainGridlineStroke(stroke45);
        org.jfree.chart.axis.AxisLocation axisLocation48 = null;
        categoryPlot42.setDomainAxisLocation((int) ' ', axisLocation48);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = categoryPlot42.getRangeAxisEdge();
        double double51 = numberAxis3D14.valueToJava2D(0.0d, rectangle2D41, rectangleEdge50);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = null;
        java.util.List list53 = categoryAxis3D8.refreshTicks(graphics2D11, axisState12, rectangle2D41, rectangleEdge52);
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets5.createOutsetRectangle(rectangle2D41, false, false);
        org.jfree.chart.entity.ChartEntity chartEntity59 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D41, "java.awt.Color[r=0,g=0,b=0]", "Multiple Pie Plot");
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(plot21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNull(axisSpace43);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(list53);
        org.junit.Assert.assertNotNull(rectangle2D56);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double6 = numberAxis3D5.getFixedAutoRange();
        double double7 = numberAxis3D5.getUpperBound();
        java.awt.Shape shape8 = numberAxis3D5.getUpArrow();
        numberAxis3D2.setUpArrow(shape8);
        int int10 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D2);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        int int12 = xYPlot0.indexOf(xYDataset11);
        java.awt.Paint paint13 = xYPlot0.getDomainTickBandPaint();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D16.setAutoTickUnitSelection(true, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = numberAxis3D16.getTickLabelInsets();
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font22 = polarPlot21.getAngleLabelFont();
        polarPlot21.addCornerTextItem("hi!");
        org.jfree.chart.plot.Plot plot25 = polarPlot21.getRootPlot();
        int int26 = polarPlot21.getSeriesCount();
        boolean boolean27 = numberAxis3D16.equals((java.lang.Object) polarPlot21);
        numberAxis3D16.setUpperBound((double) 0.0f);
        numberAxis3D16.setFixedDimension(1.0E-5d);
        org.jfree.data.Range range32 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D16);
        org.jfree.data.Range range33 = numberAxis3D16.getRange();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(plot25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNotNull(range33);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double10 = numberAxis3D9.getFixedAutoRange();
        double double11 = numberAxis3D9.getUpperBound();
        java.awt.Shape shape12 = numberAxis3D9.getUpArrow();
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis3D9.setAxisLineStroke(stroke13);
        ringPlot0.setSeparatorStroke(stroke13);
        boolean boolean16 = ringPlot0.isCircular();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getSeparatorStroke();
        double double2 = ringPlot0.getInnerSeparatorExtension();
        java.lang.String str3 = ringPlot0.getPlotType();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = ringPlot0.getLegendLabelURLGenerator();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        float float6 = ringPlot5.getForegroundAlpha();
        ringPlot5.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke11 = xYPlot10.getDomainGridlineStroke();
        boolean boolean12 = ringPlot5.equals((java.lang.Object) xYPlot10);
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot10.getDomainAxisLocation(255);
        java.lang.String str15 = xYPlot10.getPlotType();
        java.awt.Paint paint16 = xYPlot10.getDomainZeroBaselinePaint();
        ringPlot0.setShadowPaint(paint16);
        float float18 = ringPlot0.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pie Plot" + "'", str3.equals("Pie Plot"));
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "XY Plot" + "'", str15.equals("XY Plot"));
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, (double) (-1.0f));
        org.jfree.data.Range range3 = rectangleConstraint2.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toFixedHeight((double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint5.toUnconstrainedHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint6.toUnconstrainedWidth();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getSeparatorStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getInsets();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = ringPlot0.getURLGenerator();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(pieURLGenerator3);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean6 = numberAxis3D1.isPositiveArrowVisible();
        java.lang.Object obj7 = numberAxis3D1.clone();
        numberAxis3D1.setAutoTickUnitSelection(true, false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets();
        double double6 = rectangleInsets4.trimHeight(0.05d);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = categoryAxis3D10.getCategoryStart((-1), (int) ' ', rectangle2D13, rectangleEdge14);
        boolean boolean16 = textTitle8.equals((java.lang.Object) categoryAxis3D10);
        textTitle8.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color19 = java.awt.Color.BLACK;
        textTitle8.setBackgroundPaint((java.awt.Paint) color19);
        java.awt.geom.Rectangle2D rectangle2D21 = textTitle8.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets4.createAdjustedRectangle(rectangle2D21, lengthAdjustmentType22, lengthAdjustmentType23);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double27 = numberAxis3D26.getLowerMargin();
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot(pieDataset28);
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        piePlot29.drawBackgroundImage(graphics2D30, rectangle2D31);
        org.jfree.chart.plot.Plot plot33 = piePlot29.getRootPlot();
        java.awt.Color color35 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot29.setSectionOutlinePaint((java.lang.Comparable) 1, (java.awt.Paint) color35);
        numberAxis3D26.setLabelPaint((java.awt.Paint) color35);
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D42 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        double double47 = categoryAxis3D42.getCategoryStart((-1), (int) ' ', rectangle2D45, rectangleEdge46);
        boolean boolean48 = textTitle40.equals((java.lang.Object) categoryAxis3D42);
        textTitle40.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color51 = java.awt.Color.BLACK;
        textTitle40.setBackgroundPaint((java.awt.Paint) color51);
        java.awt.geom.Rectangle2D rectangle2D53 = textTitle40.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace55 = categoryPlot54.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot56 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke57 = ringPlot56.getSeparatorStroke();
        categoryPlot54.setDomainGridlineStroke(stroke57);
        org.jfree.chart.axis.AxisLocation axisLocation60 = null;
        categoryPlot54.setDomainAxisLocation((int) ' ', axisLocation60);
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = categoryPlot54.getRangeAxisEdge();
        double double63 = numberAxis3D26.valueToJava2D(0.0d, rectangle2D53, rectangleEdge62);
        double double64 = dateAxis0.lengthToJava2D((double) 3, rectangle2D21, rectangleEdge62);
        org.jfree.chart.plot.PolarPlot polarPlot66 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font67 = polarPlot66.getAngleLabelFont();
        org.jfree.chart.plot.RingPlot ringPlot68 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke69 = ringPlot68.getSeparatorStroke();
        java.awt.Paint paint70 = ringPlot68.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double72 = rectangleInsets71.getTop();
        ringPlot68.setLabelPadding(rectangleInsets71);
        java.awt.Color color74 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace75 = color74.getColorSpace();
        ringPlot68.setLabelBackgroundPaint((java.awt.Paint) color74);
        org.jfree.chart.text.TextFragment textFragment77 = new org.jfree.chart.text.TextFragment("", font67, (java.awt.Paint) color74);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D79 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D79.setAutoTickUnitSelection(true, false);
        boolean boolean83 = numberAxis3D79.isTickLabelsVisible();
        java.lang.Object obj84 = numberAxis3D79.clone();
        boolean boolean85 = textFragment77.equals((java.lang.Object) numberAxis3D79);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit86 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D79.setTickUnit(numberTickUnit86);
        boolean boolean88 = rectangleEdge62.equals((java.lang.Object) numberTickUnit86);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.95d) + "'", double6 == (-1.95d));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(plot33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNull(axisSpace55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(font67);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNotNull(rectangleInsets71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 1.0d + "'", double72 == 1.0d);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertNotNull(colorSpace75);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(obj84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(numberTickUnit86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.plot.Plot plot9 = piePlot5.getRootPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = ringPlot0.initialise(graphics2D2, rectangle2D3, piePlot5, (java.lang.Integer) 10, plotRenderingInfo11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        ringPlot0.markerChanged(markerChangeEvent13);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis3D16.getCategoryStart((-1), (int) ' ', rectangle2D19, rectangleEdge20);
        java.awt.Paint paint22 = categoryAxis3D16.getLabelPaint();
        ringPlot0.setLabelPaint(paint22);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double6 = numberAxis3D5.getFixedAutoRange();
        double double7 = numberAxis3D5.getUpperBound();
        java.awt.Shape shape8 = numberAxis3D5.getUpArrow();
        numberAxis3D2.setUpArrow(shape8);
        int int10 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot0.setRenderer(xYItemRenderer11);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        categoryAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot2);
        boolean boolean4 = polarPlot2.isAngleGridlinesVisible();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        float float6 = ringPlot5.getForegroundAlpha();
        ringPlot5.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke11 = xYPlot10.getDomainGridlineStroke();
        boolean boolean12 = ringPlot5.equals((java.lang.Object) xYPlot10);
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot10.getDomainAxisLocation(255);
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke16 = ringPlot15.getSeparatorStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator17 = null;
        ringPlot15.setLegendLabelURLGenerator(pieURLGenerator17);
        java.awt.Paint paint19 = ringPlot15.getLabelOutlinePaint();
        xYPlot10.setDomainCrosshairPaint(paint19);
        polarPlot2.setNoDataMessagePaint(paint19);
        boolean boolean22 = polarPlot2.isAngleLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainGridlineStroke();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = null;
        xYPlot0.datasetChanged(datasetChangeEvent2);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        double double2 = textTitle1.getContentYOffset();
        java.lang.String str3 = textTitle1.getURLText();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot4);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = ringPlot4.getLabelDistributor();
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace8 = color7.getColorSpace();
        java.awt.color.ColorSpace colorSpace9 = color7.getColorSpace();
        ringPlot4.setLabelShadowPaint((java.awt.Paint) color7);
        textTitle1.setBackgroundPaint((java.awt.Paint) color7);
        textTitle1.setToolTipText("RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=-1.0]");
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        piePlot16.drawBackgroundImage(graphics2D17, rectangle2D18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        piePlot16.setSimpleLabelOffset(rectangleInsets20);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D("XY Plot");
        categoryAxis3D23.setLabelToolTip("ThreadContext");
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.AxisState axisState27 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D29 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double30 = numberAxis3D29.getLowerMargin();
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot(pieDataset31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        piePlot32.drawBackgroundImage(graphics2D33, rectangle2D34);
        org.jfree.chart.plot.Plot plot36 = piePlot32.getRootPlot();
        java.awt.Color color38 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot32.setSectionOutlinePaint((java.lang.Comparable) 1, (java.awt.Paint) color38);
        numberAxis3D29.setLabelPaint((java.awt.Paint) color38);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D45 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = null;
        double double50 = categoryAxis3D45.getCategoryStart((-1), (int) ' ', rectangle2D48, rectangleEdge49);
        boolean boolean51 = textTitle43.equals((java.lang.Object) categoryAxis3D45);
        textTitle43.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color54 = java.awt.Color.BLACK;
        textTitle43.setBackgroundPaint((java.awt.Paint) color54);
        java.awt.geom.Rectangle2D rectangle2D56 = textTitle43.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace58 = categoryPlot57.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot59 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke60 = ringPlot59.getSeparatorStroke();
        categoryPlot57.setDomainGridlineStroke(stroke60);
        org.jfree.chart.axis.AxisLocation axisLocation63 = null;
        categoryPlot57.setDomainAxisLocation((int) ' ', axisLocation63);
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = categoryPlot57.getRangeAxisEdge();
        double double66 = numberAxis3D29.valueToJava2D(0.0d, rectangle2D56, rectangleEdge65);
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = null;
        java.util.List list68 = categoryAxis3D23.refreshTicks(graphics2D26, axisState27, rectangle2D56, rectangleEdge67);
        java.awt.geom.Rectangle2D rectangle2D71 = rectangleInsets20.createOutsetRectangle(rectangle2D56, false, false);
        textTitle1.draw(graphics2D14, rectangle2D56);
        boolean boolean73 = textTitle1.getNotify();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(colorSpace8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.05d + "'", double30 == 0.05d);
        org.junit.Assert.assertNotNull(plot36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNull(axisSpace58);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(list68);
        org.junit.Assert.assertNotNull(rectangle2D71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double6 = numberAxis3D5.getFixedAutoRange();
        double double7 = numberAxis3D5.getUpperBound();
        java.awt.Shape shape8 = numberAxis3D5.getUpArrow();
        numberAxis3D2.setUpArrow(shape8);
        int int10 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D2);
        xYPlot0.setRangeCrosshairVisible(true);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = null;
        waferMapPlot0.rendererChanged(rendererChangeEvent1);
        java.lang.String str3 = waferMapPlot0.getPlotType();
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = waferMapPlot0.getDataset();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        waferMapPlot0.rendererChanged(rendererChangeEvent5);
        java.lang.String str7 = waferMapPlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "WMAP_Plot" + "'", str3.equals("WMAP_Plot"));
        org.junit.Assert.assertNull(waferMapDataset4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "WMAP_Plot" + "'", str7.equals("WMAP_Plot"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.plot.Plot plot9 = piePlot5.getRootPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = ringPlot0.initialise(graphics2D2, rectangle2D3, piePlot5, (java.lang.Integer) 10, plotRenderingInfo11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        ringPlot0.markerChanged(markerChangeEvent13);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator15 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator15);
        double double17 = ringPlot0.getOuterSeparatorExtension();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setGenerateEntities(false);
        blockParams0.setGenerateEntities(true);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "");
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "hi!", jFreeChart6, chartChangeEventType7);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = chartChangeEvent8.getType();
        java.awt.Font font11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot12.getFixedDomainAxisSpace();
        categoryPlot12.clearRangeAxes();
        categoryPlot12.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray17 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer16 };
        categoryPlot12.setRenderers(categoryItemRendererArray17);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("Pie Plot", font11, (org.jfree.chart.plot.Plot) categoryPlot12, true);
        java.awt.RenderingHints renderingHints21 = jFreeChart20.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle22 = jFreeChart20.getLegend();
        jFreeChart20.setTextAntiAlias(true);
        chartChangeEvent8.setChart(jFreeChart20);
        java.util.List list26 = jFreeChart20.getSubtitles();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D29 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double33 = numberAxis3D32.getFixedAutoRange();
        numberAxis3D32.setVerticalTickLabels(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = new org.jfree.chart.util.RectangleInsets(0.08d, 10.0d, (double) (byte) 10, (double) '#');
        java.awt.Color color41 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.block.BlockBorder blockBorder42 = new org.jfree.chart.block.BlockBorder(rectangleInsets40, (java.awt.Paint) color41);
        double double44 = rectangleInsets40.calculateTopOutset((double) 100.0f);
        numberAxis3D32.setLabelInsets(rectangleInsets40);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = new org.jfree.chart.util.RectangleInsets();
        double double49 = rectangleInsets47.trimHeight(0.05d);
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D53 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        double double58 = categoryAxis3D53.getCategoryStart((-1), (int) ' ', rectangle2D56, rectangleEdge57);
        boolean boolean59 = textTitle51.equals((java.lang.Object) categoryAxis3D53);
        textTitle51.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color62 = java.awt.Color.BLACK;
        textTitle51.setBackgroundPaint((java.awt.Paint) color62);
        java.awt.geom.Rectangle2D rectangle2D64 = textTitle51.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType65 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType66 = null;
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets47.createAdjustedRectangle(rectangle2D64, lengthAdjustmentType65, lengthAdjustmentType66);
        org.jfree.chart.plot.XYPlot xYPlot68 = new org.jfree.chart.plot.XYPlot();
        xYPlot68.setRangeCrosshairValue((double) (short) 1, true);
        java.awt.Stroke stroke72 = xYPlot68.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.RingPlot ringPlot73 = new org.jfree.chart.plot.RingPlot();
        float float74 = ringPlot73.getForegroundAlpha();
        ringPlot73.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot78 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke79 = xYPlot78.getDomainGridlineStroke();
        boolean boolean80 = ringPlot73.equals((java.lang.Object) xYPlot78);
        org.jfree.chart.axis.AxisLocation axisLocation82 = xYPlot78.getDomainAxisLocation(255);
        xYPlot68.setRangeAxisLocation(axisLocation82, true);
        org.jfree.chart.plot.PolarPlot polarPlot85 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.xy.XYDataset xYDataset86 = null;
        polarPlot85.setDataset(xYDataset86);
        org.jfree.chart.plot.PlotOrientation plotOrientation88 = polarPlot85.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge89 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation82, plotOrientation88);
        double double90 = numberAxis3D32.lengthToJava2D(97.0d, rectangle2D64, rectangleEdge89);
        org.jfree.chart.util.RectangleEdge rectangleEdge91 = null;
        double double92 = numberAxis3D29.valueToJava2D(0.025d, rectangle2D64, rectangleEdge91);
        try {
            jFreeChart20.draw(graphics2D27, rectangle2D64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(chartChangeEventType9);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNotNull(categoryItemRendererArray17);
        org.junit.Assert.assertNotNull(renderingHints21);
        org.junit.Assert.assertNotNull(legendTitle22);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.08d + "'", double44 == 0.08d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + (-1.95d) + "'", double49 == (-1.95d));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertTrue("'" + float74 + "' != '" + 1.0f + "'", float74 == 1.0f);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(axisLocation82);
        org.junit.Assert.assertNotNull(plotOrientation88);
        org.junit.Assert.assertNotNull(rectangleEdge89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        java.awt.Color color0 = java.awt.Color.white;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo6 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "");
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "hi!", jFreeChart7, chartChangeEventType8);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = chartChangeEvent9.getType();
        java.awt.Font font12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot13.getFixedDomainAxisSpace();
        categoryPlot13.clearRangeAxes();
        categoryPlot13.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray18 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer17 };
        categoryPlot13.setRenderers(categoryItemRendererArray18);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("Pie Plot", font12, (org.jfree.chart.plot.Plot) categoryPlot13, true);
        java.awt.RenderingHints renderingHints22 = jFreeChart21.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle23 = jFreeChart21.getLegend();
        jFreeChart21.setTextAntiAlias(true);
        chartChangeEvent9.setChart(jFreeChart21);
        java.util.List list27 = jFreeChart21.getSubtitles();
        jFreeChart21.setAntiAlias(false);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType30 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart21, chartChangeEventType30);
        jFreeChart21.setNotify(false);
        org.jfree.chart.plot.RingPlot ringPlot34 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot34);
        legendTitle35.setID("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = legendTitle35.getLegendItemGraphicPadding();
        try {
            jFreeChart21.setTextAntiAlias((java.lang.Object) rectangleInsets38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNull(chartChangeEventType10);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(categoryItemRendererArray18);
        org.junit.Assert.assertNotNull(renderingHints22);
        org.junit.Assert.assertNotNull(legendTitle23);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertNotNull(chartChangeEventType30);
        org.junit.Assert.assertNotNull(rectangleInsets38);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getAngleLabelFont();
        polarPlot0.addCornerTextItem("hi!");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        polarPlot0.zoomDomainAxes((double) (short) 10, plotRenderingInfo5, point2D6);
        boolean boolean8 = polarPlot0.isAngleLabelsVisible();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 0.0f, 45.0d, (-4144960), (java.lang.Comparable) 192);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        waferMapPlot0.setRenderer(waferMapRenderer1);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.zoom(100.0d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Stroke stroke5 = categoryAxis3D4.getTickMarkStroke();
        java.awt.Paint paint6 = categoryAxis3D4.getTickLabelPaint();
        ringPlot0.setLabelPaint(paint6);
        java.awt.Paint paint8 = ringPlot0.getBaseSectionOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot10.getFixedDomainAxisSpace();
        categoryPlot10.clearRangeAxes();
        categoryPlot10.configureDomainAxes();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double17 = numberAxis3D16.getFixedAutoRange();
        double double18 = numberAxis3D16.getUpperBound();
        java.awt.Font font19 = numberAxis3D16.getTickLabelFont();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = numberAxis3D16.java2DToValue((double) 10L, rectangle2D21, rectangleEdge22);
        categoryPlot10.setRangeAxis(500, (org.jfree.chart.axis.ValueAxis) numberAxis3D16, true);
        java.awt.Font font27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace29 = categoryPlot28.getFixedDomainAxisSpace();
        categoryPlot28.clearRangeAxes();
        categoryPlot28.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray33 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer32 };
        categoryPlot28.setRenderers(categoryItemRendererArray33);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("Pie Plot", font27, (org.jfree.chart.plot.Plot) categoryPlot28, true);
        java.awt.RenderingHints renderingHints37 = jFreeChart36.getRenderingHints();
        java.awt.Stroke stroke38 = jFreeChart36.getBorderStroke();
        categoryPlot10.setRangeGridlineStroke(stroke38);
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) "hi!", stroke38);
        double double41 = ringPlot0.getInteriorGap();
        ringPlot0.setLabelGap((double) (short) 100);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.POSITIVE_INFINITY + "'", double23 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNull(axisSpace29);
        org.junit.Assert.assertNotNull(categoryItemRendererArray33);
        org.junit.Assert.assertNotNull(renderingHints37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.08d + "'", double41 == 0.08d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double2 = numberAxis3D1.getFixedAutoRange();
        numberAxis3D1.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean6 = numberAxis3D1.isPositiveArrowVisible();
        java.lang.Object obj7 = numberAxis3D1.clone();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat8);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double12 = numberAxis3D11.getFixedAutoRange();
        double double13 = numberAxis3D11.getUpperBound();
        java.awt.Shape shape14 = numberAxis3D11.getUpArrow();
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis3D11.setAxisLineStroke(stroke15);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range19 = numberAxis3D18.getRange();
        org.jfree.data.Range range21 = org.jfree.data.Range.shift(range19, (double) (-1.0f));
        numberAxis3D11.setDefaultAutoRange(range19);
        numberAxis3D1.setRangeWithMargins(range19);
        numberAxis3D1.setLowerMargin((double) (short) 1);
        org.jfree.data.Range range26 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis3D1.setDefaultAutoRange(range26);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(range26);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = legendTitle1.getVerticalAlignment();
        double double3 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor4);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double3 = numberAxis3D2.getFixedAutoRange();
        numberAxis3D2.zoomRange((double) (short) 0, (double) 1L);
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis3D2.setDownArrow(shape7);
        numberAxis3D2.setLowerMargin((double) (short) -1);
        java.awt.Font font11 = numberAxis3D2.getLabelFont();
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("VerticalAlignment.CENTER", font11, (java.awt.Paint) color12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        try {
            java.awt.Shape shape21 = textBlock13.calculateBounds(graphics2D14, (float) 10, (float) 0, textBlockAnchor17, 0.5f, 0.0f, Double.NaN);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis0.setTickUnit(dateTickUnit3);
        java.text.DateFormat dateFormat5 = null;
        dateAxis0.setDateFormatOverride(dateFormat5);
        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range10 = numberAxis3D9.getRange();
        boolean boolean11 = numberAxis3D9.isVerticalTickLabels();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.Range range15 = numberAxis3D14.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double18 = numberAxis3D17.getFixedAutoRange();
        double double19 = numberAxis3D17.getUpperBound();
        java.awt.Shape shape20 = numberAxis3D17.getUpArrow();
        numberAxis3D14.setUpArrow(shape20);
        int int22 = xYPlot12.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        int int24 = xYPlot12.indexOf(xYDataset23);
        java.awt.Paint paint25 = xYPlot12.getDomainTickBandPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot12.getRenderer(0);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double31 = numberAxis3D30.getFixedAutoRange();
        numberAxis3D30.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean35 = numberAxis3D30.isPositiveArrowVisible();
        numberAxis3D30.centerRange(0.2d);
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D41 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        double double46 = categoryAxis3D41.getCategoryStart((-1), (int) ' ', rectangle2D44, rectangleEdge45);
        boolean boolean47 = textTitle39.equals((java.lang.Object) categoryAxis3D41);
        textTitle39.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color50 = java.awt.Color.BLACK;
        textTitle39.setBackgroundPaint((java.awt.Paint) color50);
        java.awt.geom.Rectangle2D rectangle2D52 = textTitle39.getBounds();
        numberAxis3D30.setLeftArrow((java.awt.Shape) rectangle2D52);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D55 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D55.setAutoTickUnitSelection(true, false);
        boolean boolean59 = numberAxis3D55.isTickLabelsVisible();
        java.lang.Object obj60 = numberAxis3D55.clone();
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.axis.AxisState axisState62 = null;
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = null;
        java.util.List list65 = numberAxis3D55.refreshTicks(graphics2D61, axisState62, rectangle2D63, rectangleEdge64);
        xYPlot12.drawDomainTickBands(graphics2D28, rectangle2D52, list65);
        numberAxis3D9.setDownArrow((java.awt.Shape) rectangle2D52);
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace69 = categoryPlot68.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot70 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke71 = ringPlot70.getSeparatorStroke();
        categoryPlot68.setDomainGridlineStroke(stroke71);
        org.jfree.chart.axis.AxisLocation axisLocation74 = null;
        categoryPlot68.setDomainAxisLocation((int) ' ', axisLocation74);
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = categoryPlot68.getRangeAxisEdge();
        double double77 = dateAxis0.dateToJava2D(date7, rectangle2D52, rectangleEdge76);
        java.lang.String str78 = rectangleEdge76.toString();
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(obj60);
        org.junit.Assert.assertNotNull(list65);
        org.junit.Assert.assertNull(axisSpace69);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(rectangleEdge76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "RectangleEdge.LEFT" + "'", str78.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font2 = polarPlot1.getAngleLabelFont();
        polarPlot1.addCornerTextItem("hi!");
        org.jfree.chart.plot.Plot plot5 = polarPlot1.getRootPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        polarPlot1.addChangeListener(plotChangeListener6);
        boolean boolean8 = rectangleAnchor0.equals((java.lang.Object) plotChangeListener6);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.trimHeight(0.05d);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis3D6.getCategoryStart((-1), (int) ' ', rectangle2D9, rectangleEdge10);
        boolean boolean12 = textTitle4.equals((java.lang.Object) categoryAxis3D6);
        textTitle4.setText("Size2D[width=0.0, height=0.0]");
        java.awt.Color color15 = java.awt.Color.BLACK;
        textTitle4.setBackgroundPaint((java.awt.Paint) color15);
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle4.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType18 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets0.createAdjustedRectangle(rectangle2D17, lengthAdjustmentType18, lengthAdjustmentType19);
        double double22 = rectangleInsets0.extendWidth(0.14d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.95d) + "'", double2 == (-1.95d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.14d + "'", double22 == 2.14d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 'a');
        double double3 = range2.getUpperBound();
        java.lang.String str4 = range2.toString();
        org.jfree.data.Range range6 = org.jfree.data.Range.expandToInclude(range2, 0.025d);
        double double7 = range2.getLowerBound();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Range[97.0,97.0]" + "'", str4.equals("Range[97.0,97.0]"));
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 97.0d + "'", double7 == 97.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        float float1 = ringPlot0.getForegroundAlpha();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) 1, (double) 100);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainGridlineStroke();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) xYPlot5);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot5.getDomainAxisLocation(255);
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke11 = ringPlot10.getSeparatorStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = null;
        ringPlot10.setLegendLabelURLGenerator(pieURLGenerator12);
        java.awt.Paint paint14 = ringPlot10.getLabelOutlinePaint();
        xYPlot5.setDomainCrosshairPaint(paint14);
        java.lang.Object obj16 = xYPlot5.clone();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double20 = numberAxis3D19.getFixedAutoRange();
        numberAxis3D19.setVerticalTickLabels(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = new org.jfree.chart.util.RectangleInsets(0.08d, 10.0d, (double) (byte) 10, (double) '#');
        java.awt.Color color28 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.block.BlockBorder blockBorder29 = new org.jfree.chart.block.BlockBorder(rectangleInsets27, (java.awt.Paint) color28);
        double double31 = rectangleInsets27.calculateTopOutset((double) 100.0f);
        numberAxis3D19.setLabelInsets(rectangleInsets27);
        xYPlot5.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis3D19);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.08d + "'", double31 == 0.08d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        java.lang.Object obj3 = dateAxis0.clone();
        dateAxis0.setInverted(false);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        java.lang.Comparable[] comparableArray3 = new java.lang.Comparable[] { (-1.0f), 15, 100L };
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { numberTickUnit4, "RectangleAnchor.TOP_RIGHT" };
        double[] doubleArray12 = new double[] { ' ', (short) 100, (-1.0f), 45.0d, 0.05d };
        double[] doubleArray18 = new double[] { ' ', (short) 100, (-1.0f), 45.0d, 0.05d };
        double[] doubleArray24 = new double[] { ' ', (short) 100, (-1.0f), 45.0d, 0.05d };
        double[] doubleArray30 = new double[] { ' ', (short) 100, (-1.0f), 45.0d, 0.05d };
        double[][] doubleArray31 = new double[][] { doubleArray12, doubleArray18, doubleArray24, doubleArray30 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray3, comparableArray6, doubleArray31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray3);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setExplodedPieArea(rectangle2D2);
        double double4 = piePlotState1.getTotal();
        piePlotState1.setTotal((double) (byte) 100);
        piePlotState1.setPieWRadius(0.025d);
        piePlotState1.setPassesRequired(0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 1, (double) 10);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot5);
        flowArrangement4.add((org.jfree.chart.block.Block) legendTitle6, (java.lang.Object) 2);
        legendTitle6.setWidth((double) 1L);
        legendTitle6.setHeight(1.0d);
        boolean boolean13 = legendTitle6.getNotify();
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis3D3.getCategoryStart((-1), (int) ' ', rectangle2D6, rectangleEdge7);
        java.util.List list9 = categoryPlot1.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D3);
        categoryAxis3D3.setMaximumCategoryLabelWidthRatio((float) 8);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot();
        categoryAxis3D13.removeChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font19 = categoryAxis3D18.getLabelFont();
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("hi!", font19);
        categoryAxis3D13.setLabelFont(font19);
        categoryAxis3D3.setTickLabelFont(font19);
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("ThreadContext", font19);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = legendTitle1.getVerticalAlignment();
        double double3 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle1.getPadding();
        double double6 = rectangleInsets4.calculateRightInset((double) (byte) 0);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("org.jfree.chart.event.ChartChangeEvent[source=hi!]", "Polar Plot", numberArray8);
        java.lang.Number number10 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset9, (java.lang.Comparable) 8);
        org.jfree.data.general.PieDataset pieDataset14 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset9, 2);
        org.jfree.data.general.PieDataset pieDataset18 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset14, (java.lang.Comparable) 10, (double) 10L, (int) (byte) -1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.0d + "'", number10.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNotNull(pieDataset14);
        org.junit.Assert.assertNotNull(pieDataset18);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer4 };
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        org.jfree.chart.axis.AxisSpace axisSpace7 = categoryPlot0.getFixedRangeAxisSpace();
        categoryPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertNull(axisSpace7);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairValue((double) (short) 1, true);
        boolean boolean4 = xYPlot0.isRangeZoomable();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("Pie 3D Plot");
        int int7 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D6);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        double double11 = numberAxis3D10.getFixedAutoRange();
        numberAxis3D10.zoomRange((double) (short) 0, (double) 1L);
        boolean boolean15 = numberAxis3D10.isPositiveArrowVisible();
        java.lang.Object obj16 = numberAxis3D10.clone();
        xYPlot0.setRangeAxis(3, (org.jfree.chart.axis.ValueAxis) numberAxis3D10);
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace18, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = xYPlot0.getAxisOffset();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        legendTitle1.setID("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle1.getLegendItemGraphicPadding();
        java.awt.Font font6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot7.getFixedDomainAxisSpace();
        categoryPlot7.clearRangeAxes();
        categoryPlot7.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray12 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer11 };
        categoryPlot7.setRenderers(categoryItemRendererArray12);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("Pie Plot", font6, (org.jfree.chart.plot.Plot) categoryPlot7, true);
        jFreeChart15.setBorderVisible(false);
        jFreeChart15.fireChartChanged();
        java.lang.Object obj19 = jFreeChart15.clone();
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart15);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(categoryItemRendererArray12);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        boolean boolean11 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot0.getRangeAxis((int) '4');
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot0.getDomainMarkers(layer14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.configureRangeAxes();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = null;
        dateAxis0.setTimeline(timeline1);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = null;
        dateAxis3.setTickUnit(dateTickUnit4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        dateAxis3.setTimeZone(timeZone7);
        dateAxis0.setTimeZone(timeZone7);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("VerticalAlignment.CENTER");
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("org.jfree.chart.event.ChartChangeEvent[source=hi!]", "Polar Plot", numberArray8);
        java.lang.Number number10 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset9);
        org.jfree.data.KeyToGroupMap keyToGroupMap11 = null;
        try {
            org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset9, keyToGroupMap11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.0d + "'", number10.equals(0.0d));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = piePlot3D1.getLabelPadding();
        double double4 = rectangleInsets2.calculateBottomInset((double) 'a');
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
    }
}

