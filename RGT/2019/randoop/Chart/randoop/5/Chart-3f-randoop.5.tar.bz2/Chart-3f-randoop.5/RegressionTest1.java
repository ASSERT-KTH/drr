import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.util.Date date6 = regularTimePeriod5.getStart();
        timeSeries1.delete(regularTimePeriod5);
        double double8 = timeSeries1.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (double) (-1.0f));
        timeSeries10.add(timeSeriesDataItem13);
        timeSeries10.setNotify(true);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.util.Date date20 = year19.getEnd();
        boolean boolean22 = year19.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year19);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getEnd();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month26);
        org.jfree.data.time.Year year29 = month26.getYear();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) 1560182842664L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year29.next();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(year29);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        boolean boolean17 = year14.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener21);
        java.util.Collection collection23 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        boolean boolean24 = timeSeries18.isEmpty();
        java.util.Collection collection25 = timeSeries18.getTimePeriods();
        java.lang.String str26 = timeSeries18.getDomainDescription();
        int int27 = day3.compareTo((java.lang.Object) timeSeries18);
        org.jfree.data.time.SerialDate serialDate28 = day3.getSerialDate();
        int int30 = day3.compareTo((java.lang.Object) 100.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day3.next();
        java.lang.String str32 = day3.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "31-December-2019" + "'", str32.equals("31-December-2019"));
    }

//    @Test
//    public void test03() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test03");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        long long9 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond0.getMiddleMillisecond(calendar10);
//        long long12 = fixedMillisecond0.getLastMillisecond();
//        java.util.Date date13 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
//        java.util.TimeZone timeZone15 = null;
//        try {
//            org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date13, timeZone15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182940020L + "'", long1 == 1560182940020L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182940020L + "'", long2 == 1560182940020L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182940020L + "'", long9 == 1560182940020L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182940020L + "'", long11 == 1560182940020L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560182940020L + "'", long12 == 1560182940020L);
//        org.junit.Assert.assertNotNull(date13);
//    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        java.lang.Class<?> wildcardClass6 = timeSeriesDataItem4.getClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        int int9 = timeSeriesDataItem4.compareTo((java.lang.Object) timeSeries8);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        java.lang.String str10 = timeSeries1.getDescription();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) "Time");
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "org.jfree.data.general.SeriesException: hi!", "2019");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, (double) (-1.0f));
        timeSeries13.add(timeSeriesDataItem16);
        timeSeries13.setNotify(true);
        timeSeries13.setNotify(true);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.previous();
        timeSeries13.update((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 100);
        java.lang.Number number27 = null;
        timeSeries13.update((int) (short) 0, number27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries5.addAndOrUpdate(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year32, (double) (-1.0f));
        timeSeries31.add(timeSeriesDataItem34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        java.util.Date date37 = year36.getEnd();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month38.previous();
        int int40 = timeSeriesDataItem34.compareTo((java.lang.Object) month38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month38.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) month38);
        timeSeries3.add(timeSeriesDataItem42, false);
        java.lang.String str45 = timeSeries3.getRangeDescription();
        java.lang.Comparable comparable46 = timeSeries3.getKey();
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "2019" + "'", str45.equals("2019"));
        org.junit.Assert.assertTrue("'" + comparable46 + "' != '" + true + "'", comparable46.equals(true));
    }

//    @Test
//    public void test07() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test07");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getFirstMillisecond(calendar4);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182940521L + "'", long2 == 1560182940521L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560182940521L + "'", long5 == 1560182940521L);
//    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        boolean boolean3 = year0.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "2019", "Value");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.lang.String str9 = timeSeries6.getRangeDescription();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        boolean boolean17 = year14.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener21);
        java.util.Collection collection23 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        boolean boolean24 = timeSeries18.isEmpty();
        java.util.Collection collection25 = timeSeries18.getTimePeriods();
        java.lang.String str26 = timeSeries18.getDomainDescription();
        int int27 = day3.compareTo((java.lang.Object) timeSeries18);
        org.jfree.data.time.SerialDate serialDate28 = day3.getSerialDate();
        int int30 = day3.compareTo((java.lang.Object) 100.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day3.next();
        java.util.Calendar calendar32 = null;
        try {
            long long33 = regularTimePeriod31.getMiddleMillisecond(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        java.lang.Number number7 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (-1.0f));
        timeSeries9.add(timeSeriesDataItem12);
        timeSeries9.setNotify(true);
        timeSeries9.setNotify(true);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        timeSeries9.update((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeries9.getNextTimePeriod();
        java.lang.String str23 = timeSeries9.getDomainDescription();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getEnd();
        boolean boolean27 = year24.equals((java.lang.Object) 100);
        java.util.Date date28 = year24.getEnd();
        java.lang.Number number29 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year24, number29);
        java.lang.Number number31 = timeSeriesDataItem30.getValue();
        timeSeries1.add(timeSeriesDataItem30, true);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeSeriesDataItem30);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 100 + "'", number31.equals(100));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo3);
        java.lang.String str5 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str2.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str5.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "org.jfree.data.general.SeriesException: hi!", "2019");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "org.jfree.data.general.SeriesException: hi!", "2019");
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (double) (-1.0f));
        timeSeries10.add(timeSeriesDataItem13);
        timeSeries10.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) (-1.0f));
        timeSeries18.add(timeSeriesDataItem21);
        timeSeries18.setNotify(true);
        timeSeries18.setNotify(true);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        timeSeries18.update((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) 100);
        java.lang.Number number32 = null;
        timeSeries18.update((int) (short) 0, number32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries10.addAndOrUpdate(timeSeries18);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year37, (double) (-1.0f));
        timeSeries36.add(timeSeriesDataItem39);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        java.util.Date date42 = year41.getEnd();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month43.previous();
        int int45 = timeSeriesDataItem39.compareTo((java.lang.Object) month43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = month43.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) month43);
        timeSeries8.add(timeSeriesDataItem47, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries3.addOrUpdate(timeSeriesDataItem47);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = timeSeriesDataItem50.getPeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(timeSeriesDataItem47);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries1.getNextTimePeriod();
        timeSeries1.removeAgedItems(true);
        timeSeries1.setMaximumItemAge(43830L);
        timeSeries1.setDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean20 = timeSeries14.isEmpty();
        java.util.Collection collection21 = timeSeries14.getTimePeriods();
        java.lang.String str22 = timeSeries14.getDomainDescription();
        timeSeries14.setRangeDescription("31-December-2019");
        long long25 = timeSeries14.getMaximumItemAge();
        timeSeries14.removeAgedItems(true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Time" + "'", str22.equals("Time"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        timeSeries11.add(timeSeriesDataItem14);
        timeSeries11.setNotify(true);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getEnd();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        boolean boolean23 = year20.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year18.next();
        int int27 = year18.compareTo((java.lang.Object) 6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (double) (short) -1);
        timeSeries1.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year34, (double) (-1.0f));
        timeSeries33.add(timeSeriesDataItem36);
        timeSeries33.setNotify(true);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        java.util.Date date41 = year40.getEnd();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        java.util.Date date43 = year42.getEnd();
        boolean boolean45 = year42.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) year40, (org.jfree.data.time.RegularTimePeriod) year42);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        java.util.Date date48 = year47.getEnd();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month49.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries33.getDataItem((org.jfree.data.time.RegularTimePeriod) month49);
        org.jfree.data.time.Year year52 = month49.getYear();
        int int53 = month49.getMonth();
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(11);
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month49, (org.jfree.data.time.RegularTimePeriod) year55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = year55.next();
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(timeSeriesDataItem51);
        org.junit.Assert.assertNotNull(year52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 12 + "'", int53 == 12);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
    }
}

