import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.Object obj0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent(obj0, seriesChangeInfo1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-1), 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test008");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date3 = fixedMillisecond0.getStart();
//        java.util.TimeZone timeZone4 = null;
//        java.util.Locale locale5 = null;
//        try {
//            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3, timeZone4, locale5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182843174L + "'", long1 == 1560182843174L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182843174L + "'", long2 == 1560182843174L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test011");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date3 = fixedMillisecond0.getStart();
//        java.util.TimeZone timeZone4 = null;
//        java.util.Locale locale5 = null;
//        try {
//            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3, timeZone4, locale5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182843313L + "'", long1 == 1560182843313L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182843313L + "'", long2 == 1560182843313L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries(comparable0, "", "org.jfree.data.event.SeriesChangeEvent[source=100]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        java.util.Calendar calendar4 = null;
        try {
            month2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.event.SeriesChangeEvent[source=100]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = null;
        try {
            int int7 = timeSeries1.getIndex(regularTimePeriod6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        boolean boolean3 = year0.equals((java.lang.Object) 100);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        try {
            timeSeries1.delete(0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = null;
        try {
            timeSeries14.add(regularTimePeriod20, (double) (byte) 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        try {
            org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy(9, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test029");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        int int3 = fixedMillisecond0.compareTo((java.lang.Object) 1560182842664L);
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getFirstMillisecond(calendar6);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182848033L + "'", long1 == 1560182848033L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560182848033L + "'", long7 == 1560182848033L);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        java.lang.String str10 = timeSeries1.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 1560182844817L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        boolean boolean6 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (double) (-1.0f));
        timeSeries8.add(timeSeriesDataItem11);
        timeSeries8.setNotify(true);
        timeSeries8.setNotify(true);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        timeSeries8.update((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeries8.getNextTimePeriod();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (double) (-1.0f));
        timeSeries23.add(timeSeriesDataItem26);
        timeSeries23.setNotify(true);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        java.util.Date date31 = year30.getEnd();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.util.Date date33 = year32.getEnd();
        boolean boolean35 = year32.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) year30, (org.jfree.data.time.RegularTimePeriod) year32);
        try {
            org.jfree.data.time.TimeSeries timeSeries37 = timeSeries1.createCopy(regularTimePeriod21, (org.jfree.data.time.RegularTimePeriod) year32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start on or before end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(timeSeries36);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        boolean boolean17 = year14.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1.0f);
        try {
            timeSeries1.delete((int) (short) 1, 6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (-1.0f));
        timeSeries16.add(timeSeriesDataItem19);
        timeSeries16.setNotify(true);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.util.Date date24 = year23.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        java.util.Date date26 = year25.getEnd();
        boolean boolean28 = year25.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) year23, (org.jfree.data.time.RegularTimePeriod) year25);
        try {
            timeSeries14.add((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 1, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeSeries29);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        java.util.Calendar calendar20 = null;
        try {
            long long21 = month17.getLastMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date1, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.next();
        java.util.Calendar calendar16 = null;
        try {
            year8.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.Year year20 = month17.getYear();
        java.util.Calendar calendar21 = null;
        try {
            month17.peg(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(year20);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        boolean boolean6 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (double) (-1.0f));
        timeSeries8.add(timeSeriesDataItem11);
        timeSeries8.setNotify(true);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getEnd();
        boolean boolean20 = year17.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) year15, (org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year15.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, (double) 1560182842702L);
        try {
            timeSeries1.add(timeSeriesDataItem24);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test039");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
//        timeSeries1.add(timeSeriesDataItem4);
//        timeSeries1.setNotify(true);
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        java.util.Date date9 = year8.getEnd();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        java.util.Date date11 = year10.getEnd();
//        boolean boolean13 = year10.equals((java.lang.Object) 100);
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
//        java.lang.Object obj15 = timeSeries1.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        long long17 = fixedMillisecond16.getMiddleMillisecond();
//        long long18 = fixedMillisecond16.getSerialIndex();
//        java.util.Calendar calendar19 = null;
//        fixedMillisecond16.peg(calendar19);
//        boolean boolean22 = fixedMillisecond16.equals((java.lang.Object) (short) 10);
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 0L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(obj15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182849610L + "'", long17 == 1560182849610L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560182849610L + "'", long18 == 1560182849610L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        timeSeriesDataItem2.setValue((java.lang.Number) 0);
        java.lang.Object obj5 = timeSeriesDataItem2.clone();
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test044");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond0.previous();
//        java.lang.String str4 = fixedMillisecond0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182849845L + "'", long1 == 1560182849845L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182849845L + "'", long2 == 1560182849845L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Mon Jun 10 09:07:29 PDT 2019" + "'", str4.equals("Mon Jun 10 09:07:29 PDT 2019"));
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        double double4 = timeSeries1.getMinY();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        long long4 = month2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.previous();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        int int4 = month2.getMonth();
        int int5 = month2.getMonth();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        boolean boolean21 = month17.equals((java.lang.Object) 10L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year8.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 100);
        java.util.Calendar calendar14 = null;
        try {
            year10.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        timeSeries1.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, (double) (-1.0f));
        timeSeries13.add(timeSeriesDataItem16);
        timeSeries13.setNotify(true);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.util.Date date23 = year22.getEnd();
        boolean boolean25 = year22.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.util.Date date28 = year27.getEnd();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) month29);
        org.jfree.data.time.Year year32 = month29.getYear();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month29, (double) 1560182851041L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(year32);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        long long3 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test057");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        long long2 = fixedMillisecond1.getMiddleMillisecond();
//        long long3 = fixedMillisecond1.getSerialIndex();
//        java.util.Date date4 = fixedMillisecond1.getStart();
//        java.util.TimeZone timeZone5 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
//        java.util.TimeZone timeZone7 = null;
//        try {
//            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date4, timeZone7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182852781L + "'", long2 == 1560182852781L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560182852781L + "'", long3 == 1560182852781L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test058");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) 1.0d);
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182852884L + "'", long1 == 1560182852884L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.addChangeListener(seriesChangeListener10);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries21.removePropertyChangeListener(propertyChangeListener22);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (double) (-1.0f));
        timeSeries25.add(timeSeriesDataItem28);
        timeSeries25.setNotify(true);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.util.Date date33 = year32.getEnd();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        java.util.Date date35 = year34.getEnd();
        boolean boolean37 = year34.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) year34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year32.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year32, (double) 1.0f);
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) 10.0d);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries45.setMaximumItemAge((long) 'a');
        boolean boolean48 = year32.equals((java.lang.Object) 'a');
        java.util.Calendar calendar49 = null;
        try {
            long long50 = year32.getFirstMillisecond(calendar49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test062");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        long long2 = fixedMillisecond1.getMiddleMillisecond();
//        long long3 = fixedMillisecond1.getSerialIndex();
//        java.util.Date date4 = fixedMillisecond1.getStart();
//        java.util.TimeZone timeZone5 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
//        java.util.TimeZone timeZone7 = null;
//        try {
//            org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date4, timeZone7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182853636L + "'", long2 == 1560182853636L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560182853636L + "'", long3 == 1560182853636L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test063");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        timeSeries1.setMaximumItemAge((long) 'a');
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        java.util.Date date5 = year4.getEnd();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
//        long long8 = month6.getLastMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        long long10 = fixedMillisecond9.getMiddleMillisecond();
//        long long11 = fixedMillisecond9.getSerialIndex();
//        java.util.Date date12 = fixedMillisecond9.getStart();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date12);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) month14);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start on or before end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560182853653L + "'", long10 == 1560182853653L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182853653L + "'", long11 == 1560182853653L);
//        org.junit.Assert.assertNotNull(date12);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean20 = timeSeries14.isEmpty();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeries14.getTimePeriod((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "");
        java.lang.String str6 = timeSeries5.getRangeDescription();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        timeSeries1.setMaximumItemCount(0);
        boolean boolean7 = timeSeries1.equals((java.lang.Object) 1560182842984L);
        timeSeries1.setDescription("");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        boolean boolean17 = year14.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1.0f);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries1.getDataItem((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) -1);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year22, (double) (-1.0f));
        timeSeries21.add(timeSeriesDataItem24);
        timeSeries21.setNotify(true);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.util.Date date29 = year28.getEnd();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        java.util.Date date31 = year30.getEnd();
        boolean boolean33 = year30.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) year28, (org.jfree.data.time.RegularTimePeriod) year30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year28.next();
        int int37 = year28.compareTo((java.lang.Object) 6);
        java.lang.Number number38 = null;
        try {
            timeSeries16.update((org.jfree.data.time.RegularTimePeriod) year28, number38);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.event.SeriesChangeEvent[source=100]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        boolean boolean3 = year0.equals((java.lang.Object) 100);
        java.util.Date date4 = year0.getEnd();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        int int4 = month2.getMonth();
        long long5 = month2.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (-1.0f));
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month2.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1576526399999L + "'", long5 == 1576526399999L);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
//        timeSeries1.add(timeSeriesDataItem4);
//        timeSeries1.setNotify(true);
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        java.util.Date date9 = year8.getEnd();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        java.util.Date date11 = year10.getEnd();
//        boolean boolean13 = year10.equals((java.lang.Object) 100);
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
//        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timeSeries21.removePropertyChangeListener(propertyChangeListener22);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (double) (-1.0f));
//        timeSeries25.add(timeSeriesDataItem28);
//        timeSeries25.setNotify(true);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        java.util.Date date33 = year32.getEnd();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        java.util.Date date35 = year34.getEnd();
//        boolean boolean37 = year34.equals((java.lang.Object) 100);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) year34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year32.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year32, (double) 1.0f);
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) 10.0d);
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        timeSeries45.setMaximumItemAge((long) 'a');
//        boolean boolean48 = year32.equals((java.lang.Object) 'a');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        long long50 = fixedMillisecond49.getMiddleMillisecond();
//        long long51 = fixedMillisecond49.getSerialIndex();
//        java.util.Date date52 = fixedMillisecond49.getStart();
//        int int53 = year32.compareTo((java.lang.Object) date52);
//        java.util.Calendar calendar54 = null;
//        try {
//            long long55 = year32.getLastMillisecond(calendar54);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560182854781L + "'", long50 == 1560182854781L);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560182854781L + "'", long51 == 1560182854781L);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        boolean boolean16 = year8.equals((java.lang.Object) '#');
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) collection19);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo21 = seriesChangeEvent20.getSummary();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNull(seriesChangeInfo21);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 100, (int) (short) 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        double double10 = timeSeries1.getMaxY();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test082");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182855376L + "'", long1 == 1560182855376L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182855376L + "'", long2 == 1560182855376L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560182855376L + "'", long5 == 1560182855376L);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener13);
        org.junit.Assert.assertNotNull(timeSeries12);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        timeSeries1.setDomainDescription("Mon Jun 10 09:07:29 PDT 2019");
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.Year year20 = month17.getYear();
        java.util.Calendar calendar21 = null;
        try {
            long long22 = month17.getLastMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(year20);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 100);
        java.lang.String str14 = year10.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        int int10 = timeSeriesDataItem4.compareTo((java.lang.Object) month8);
        timeSeriesDataItem4.setSelected(false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
        java.lang.String str13 = timeSeries12.getRangeDescription();
        try {
            org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.createCopy((int) '#', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray5 = seriesException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        boolean boolean4 = year1.equals((java.lang.Object) 100);
        java.util.Date date5 = year1.getEnd();
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        java.util.Calendar calendar4 = null;
        try {
            day3.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries1.getNextTimePeriod();
        timeSeries1.setDomainDescription("hi!");
        boolean boolean17 = timeSeries1.getNotify();
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str5 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str5.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (-1.0f));
        timeSeries16.add(timeSeriesDataItem19);
        timeSeries16.setNotify(true);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.util.Date date24 = year23.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        java.util.Date date26 = year25.getEnd();
        boolean boolean28 = year25.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) year23, (org.jfree.data.time.RegularTimePeriod) year25);
        try {
            timeSeries14.add((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 9999);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeSeries29);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
        timeSeries3.setRangeDescription("Time");
        org.junit.Assert.assertNotNull(timeSeries12);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        boolean boolean15 = year12.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) 1560182842702L);
        java.lang.Object obj20 = timeSeriesDataItem19.clone();
        timeSeries1.add(timeSeriesDataItem19, false);
        timeSeriesDataItem19.setValue((java.lang.Number) 1560182849845L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        timeSeries1.setMaximumItemCount(0);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (byte) -1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) month10);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = month10.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(timeSeries12);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        try {
            timeSeries1.delete(5, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        try {
            org.jfree.data.time.TimeSeries timeSeries17 = timeSeries12.createCopy((int) (short) -1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries12);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        java.lang.String str15 = year8.toString();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        int int4 = fixedMillisecond0.compareTo((java.lang.Object) 1576526399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182864264L + "'", long2 == 1560182864264L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        int int3 = fixedMillisecond0.compareTo((java.lang.Object) 1560182842664L);
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        long long6 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182865239L + "'", long1 == 1560182865239L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182865239L + "'", long6 == 1560182865239L);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
//        timeSeries1.add(timeSeriesDataItem4);
//        timeSeries1.setNotify(true);
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        java.util.Date date9 = year8.getEnd();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        java.util.Date date11 = year10.getEnd();
//        boolean boolean13 = year10.equals((java.lang.Object) 100);
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
//        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
//        boolean boolean20 = timeSeries14.isEmpty();
//        java.util.Collection collection21 = timeSeries14.getTimePeriods();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        long long23 = fixedMillisecond22.getMiddleMillisecond();
//        long long24 = fixedMillisecond22.getSerialIndex();
//        java.util.Calendar calendar25 = null;
//        fixedMillisecond22.peg(calendar25);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (double) 1.0f);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(collection21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560182865356L + "'", long23 == 1560182865356L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560182865356L + "'", long24 == 1560182865356L);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        timeSeries11.add(timeSeriesDataItem14);
        timeSeries11.setNotify(true);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getEnd();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        boolean boolean23 = year20.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year18.next();
        int int27 = year18.compareTo((java.lang.Object) 6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (double) (short) -1);
        timeSeries1.setMaximumItemCount((int) '#');
        java.lang.Object obj32 = timeSeries1.clone();
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(obj32);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        timeSeries1.setDomainDescription("hi!");
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
//        java.util.Date date6 = regularTimePeriod5.getStart();
//        timeSeries1.delete(regularTimePeriod5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getFirstMillisecond(calendar9);
//        try {
//            timeSeries1.setKey((java.lang.Comparable) calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560182865765L + "'", long10 == 1560182865765L);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        timeSeries12.removeAgedItems(1560182842984L, false);
        timeSeries12.removeAgedItems(true);
        try {
            org.jfree.data.time.TimeSeries timeSeries22 = timeSeries12.createCopy((-1), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries12);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (-1.0f));
        timeSeries9.add(timeSeriesDataItem12);
        timeSeries9.setNotify(true);
        timeSeries9.setNotify(true);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        timeSeries9.update((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 100);
        java.lang.Number number23 = null;
        timeSeries9.update((int) (short) 0, number23);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries1.addAndOrUpdate(timeSeries9);
        timeSeries25.setMaximumItemCount(9);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(timeSeries25);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
        try {
            org.jfree.data.time.TimeSeries timeSeries15 = timeSeries12.createCopy(11, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries12);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        java.lang.Object obj15 = timeSeries1.clone();
        java.lang.Class class16 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (-1.0f));
        timeSeries20.add(timeSeriesDataItem23);
        timeSeries20.setNotify(true);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.util.Date date28 = year27.getEnd();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        java.util.Date date30 = year29.getEnd();
        boolean boolean32 = year29.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) year27, (org.jfree.data.time.RegularTimePeriod) year29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year27.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, (double) 1560182842702L);
        java.lang.Object obj37 = timeSeriesDataItem36.clone();
        timeSeriesDataItem36.setSelected(false);
        try {
            timeSeries1.add(timeSeriesDataItem36, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(obj37);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test117");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
//        timeSeries1.add(timeSeriesDataItem4);
//        timeSeries1.setNotify(true);
//        timeSeries1.setNotify(true);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
//        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries1.getNextTimePeriod();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        long long16 = fixedMillisecond15.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) (byte) -1);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate(timeSeriesDataItem18);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560182866254L + "'", long16 == 1560182866254L);
//    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.lang.Class<?> wildcardClass9 = fixedMillisecond0.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182867301L + "'", long1 == 1560182867301L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182867301L + "'", long2 == 1560182867301L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(class12);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        java.lang.Object obj15 = timeSeries1.clone();
        java.lang.Class class16 = timeSeries1.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries1.addChangeListener(seriesChangeListener17);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(class16);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        timeSeries1.setMaximumItemCount(0);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (byte) -1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) month10);
        java.lang.Class class13 = timeSeries1.getTimePeriodClass();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries1.getDataItem(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNull(class13);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        timeSeries12.removeAgedItems(1560182842984L, false);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year20, (double) (-1.0f));
        timeSeries19.add(timeSeriesDataItem22);
        timeSeries19.setNotify(true);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        java.util.Date date27 = year26.getEnd();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.util.Date date29 = year28.getEnd();
        boolean boolean31 = year28.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) year26, (org.jfree.data.time.RegularTimePeriod) year28);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        java.util.Date date34 = year33.getEnd();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month35.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries19.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) month35, (java.lang.Number) 10.0d, true);
        java.util.Calendar calendar41 = null;
        try {
            month35.peg(calendar41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        boolean boolean3 = year0.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "2019", "Value");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = null;
        try {
            timeSeries6.add(regularTimePeriod7, (double) 1560182852884L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        timeSeries1.setMaximumItemCount(0);
        int int6 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
        timeSeries12.setDomainDescription("Mon Jun 10 09:07:29 PDT 2019");
        try {
            timeSeries12.delete((int) ' ', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries12);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(9);
        long long2 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61883280000000L) + "'", long2 == (-61883280000000L));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        boolean boolean17 = year14.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1.0f);
        int int23 = year12.compareTo((java.lang.Object) 0.0f);
        int int25 = year12.compareTo((java.lang.Object) 1560182844600L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "org.jfree.data.general.SeriesException: hi!", "2019");
        long long4 = timeSeries3.getMaximumItemAge();
        try {
            java.lang.Number number6 = timeSeries3.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test129");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1560182847497L);
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        java.util.TimeZone timeZone7 = null;
//        try {
//            org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182868765L + "'", long2 == 1560182868765L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: hi!");
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date3 = fixedMillisecond0.getStart();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        java.lang.String str5 = year4.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182868809L + "'", long1 == 1560182868809L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182868809L + "'", long2 == 1560182868809L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.Year year20 = month17.getYear();
        int int21 = month17.getMonth();
        java.util.Calendar calendar22 = null;
        try {
            long long23 = month17.getFirstMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.removeAgedItems(1560182865213L, false);
        java.lang.Comparable comparable11 = timeSeries1.getKey();
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 1560182842943L + "'", comparable11.equals(1560182842943L));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean20 = timeSeries14.isEmpty();
        java.util.Collection collection21 = timeSeries14.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (double) (-1.0f));
        timeSeries23.add(timeSeriesDataItem26);
        timeSeries23.setNotify(true);
        timeSeries23.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year34, (double) (-1.0f));
        timeSeries33.add(timeSeriesDataItem36);
        timeSeries33.setNotify(true);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        java.util.Date date41 = year40.getEnd();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        java.util.Date date43 = year42.getEnd();
        boolean boolean45 = year42.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) year40, (org.jfree.data.time.RegularTimePeriod) year42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year40.next();
        int int49 = year40.compareTo((java.lang.Object) 6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year40, (double) (short) -1);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = year52.previous();
        java.util.Date date54 = regularTimePeriod53.getStart();
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date54);
        int int56 = timeSeriesDataItem51.compareTo((java.lang.Object) date54);
        try {
            timeSeries14.add(timeSeriesDataItem51, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem51);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo2);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = seriesChangeEvent1.getSummary();
        org.junit.Assert.assertNull(seriesChangeInfo4);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1560182847497L);
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        java.util.TimeZone timeZone7 = null;
//        java.util.Locale locale8 = null;
//        try {
//            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date6, timeZone7, locale8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182869748L + "'", long2 == 1560182869748L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date3 = fixedMillisecond0.getStart();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = year4.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182869778L + "'", long1 == 1560182869778L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182869778L + "'", long2 == 1560182869778L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Time");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        boolean boolean6 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount(0);
        try {
            java.lang.Number number10 = timeSeries1.getValue((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.util.Calendar calendar3 = null;
        try {
            month2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.util.Date date6 = regularTimePeriod5.getStart();
        timeSeries1.delete(regularTimePeriod5);
        double double8 = timeSeries1.getMaxY();
        timeSeries1.removeAgedItems((long) 0, false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        int int4 = month2.getMonth();
        long long5 = month2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1576526399999L + "'", long5 == 1576526399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean20 = timeSeries14.isEmpty();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeries14.getTimePeriod(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        boolean boolean15 = year12.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) 1560182842702L);
        java.lang.Object obj20 = timeSeriesDataItem19.clone();
        timeSeries1.add(timeSeriesDataItem19, false);
        timeSeriesDataItem19.setValue((java.lang.Number) (short) 100);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        int int4 = month2.getMonth();
        int int5 = month2.getMonth();
        long long6 = month2.getLastMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Mon Jun 10 09:07:29 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener10);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries21.removePropertyChangeListener(propertyChangeListener22);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (double) (-1.0f));
        timeSeries25.add(timeSeriesDataItem28);
        timeSeries25.setNotify(true);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.util.Date date33 = year32.getEnd();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        java.util.Date date35 = year34.getEnd();
        boolean boolean37 = year34.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) year34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year32.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year32, (double) 1.0f);
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) 10.0d);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries45.setMaximumItemAge((long) 'a');
        boolean boolean48 = year32.equals((java.lang.Object) 'a');
        java.util.Calendar calendar49 = null;
        try {
            long long50 = year32.getLastMillisecond(calendar49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        int int10 = timeSeriesDataItem4.compareTo((java.lang.Object) month8);
        java.util.Calendar calendar11 = null;
        try {
            month8.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setRangeDescription("");
        try {
            timeSeries1.delete((int) '4', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (-1.0f));
        timeSeries9.add(timeSeriesDataItem12);
        timeSeries9.setNotify(true);
        timeSeries9.setNotify(true);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        timeSeries9.update((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 100);
        java.lang.Number number23 = null;
        timeSeries9.update((int) (short) 0, number23);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries1.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        long long28 = fixedMillisecond27.getMiddleMillisecond();
        java.util.Date date29 = fixedMillisecond27.getTime();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (java.lang.Number) 1560182847497L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
        org.junit.Assert.assertNotNull(date29);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        boolean boolean17 = year14.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener21);
        java.util.Collection collection23 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        boolean boolean24 = timeSeries18.isEmpty();
        java.util.Collection collection25 = timeSeries18.getTimePeriods();
        java.lang.String str26 = timeSeries18.getDomainDescription();
        int int27 = day3.compareTo((java.lang.Object) timeSeries18);
        org.jfree.data.time.SerialDate serialDate28 = day3.getSerialDate();
        java.lang.String str29 = day3.toString();
        int int30 = day3.getDayOfMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "31-December-2019" + "'", str29.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 31 + "'", int30 == 31);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        java.lang.Object obj15 = timeSeries1.clone();
        java.lang.Class class16 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (-1.0f));
        timeSeries20.add(timeSeriesDataItem23);
        try {
            timeSeries1.add(timeSeriesDataItem23);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(class16);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        java.util.Calendar calendar20 = null;
        try {
            month17.peg(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (-1.0f));
        timeSeries9.add(timeSeriesDataItem12);
        timeSeries9.setNotify(true);
        timeSeries9.setNotify(true);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        timeSeries9.update((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 100);
        java.lang.Number number23 = null;
        timeSeries9.update((int) (short) 0, number23);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries1.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year30, (double) (-1.0f));
        timeSeries29.add(timeSeriesDataItem32);
        timeSeries29.setNotify(true);
        timeSeries29.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries27.addAndOrUpdate(timeSeries29);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
        timeSeries38.removeChangeListener(seriesChangeListener39);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries25.addAndOrUpdate(timeSeries38);
        try {
            timeSeries25.delete(5, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(timeSeries41);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (double) 1560182842702L);
        java.lang.Object obj18 = timeSeriesDataItem17.clone();
        timeSeriesDataItem17.setSelected(false);
        boolean boolean21 = timeSeriesDataItem17.isSelected();
        java.lang.Object obj22 = timeSeriesDataItem17.clone();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.util.Date date6 = regularTimePeriod5.getStart();
        timeSeries1.delete(regularTimePeriod5);
        double double8 = timeSeries1.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (double) (-1.0f));
        timeSeries10.add(timeSeriesDataItem13);
        timeSeries10.setNotify(true);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.util.Date date20 = year19.getEnd();
        boolean boolean22 = year19.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year19);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getEnd();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month26);
        org.jfree.data.time.Year year29 = month26.getYear();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) 1560182842664L);
        timeSeries1.clear();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(year29);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        timeSeries1.setDomainDescription("hi!");
//        timeSeries1.setMaximumItemCount(0);
//        boolean boolean7 = timeSeries1.equals((java.lang.Object) 1560182842984L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        int int11 = fixedMillisecond8.compareTo((java.lang.Object) 1560182842664L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 1561964399999L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond8.previous();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182873734L + "'", long9 == 1560182873734L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean20 = timeSeries14.isEmpty();
        java.util.List list21 = timeSeries14.getItems();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(list21);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        timeSeries1.setMaximumItemCount(0);
        java.lang.Class class6 = timeSeries1.getTimePeriodClass();
        org.junit.Assert.assertNull(class6);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        boolean boolean9 = timeSeriesDataItem8.isSelected();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182873882L + "'", long1 == 1560182873882L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182873882L + "'", long2 == 1560182873882L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(10, (int) (byte) 10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        int int2 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        timeSeries1.setMaximumItemCount(0);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (byte) -1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) month10);
        long long13 = year7.getLastMillisecond();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-62072668800001L) + "'", long13 == (-62072668800001L));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.String str3 = seriesException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str3.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        timeSeries12.removeAgedItems(1560182842984L, false);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year20, (double) (-1.0f));
        timeSeries19.add(timeSeriesDataItem22);
        timeSeries19.setNotify(true);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        java.util.Date date27 = year26.getEnd();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.util.Date date29 = year28.getEnd();
        boolean boolean31 = year28.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) year26, (org.jfree.data.time.RegularTimePeriod) year28);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        java.util.Date date34 = year33.getEnd();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month35.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries19.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) month35, (java.lang.Number) 10.0d, true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        long long43 = fixedMillisecond42.getMiddleMillisecond();
        java.util.Date date44 = fixedMillisecond42.getTime();
        try {
            timeSeries12.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (java.lang.Number) 1560182865639L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 100L + "'", long43 == 100L);
        org.junit.Assert.assertNotNull(date44);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1560182847497L);
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond0.getMiddleMillisecond(calendar7);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182875915L + "'", long2 == 1560182875915L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560182875915L + "'", long8 == 1560182875915L);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries1.getNextTimePeriod();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries1.removeChangeListener(seriesChangeListener15);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) 'a');
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '4', 12, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        boolean boolean17 = year14.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener21);
        java.util.Collection collection23 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        boolean boolean24 = timeSeries18.isEmpty();
        java.util.Collection collection25 = timeSeries18.getTimePeriods();
        java.lang.String str26 = timeSeries18.getDomainDescription();
        int int27 = day3.compareTo((java.lang.Object) timeSeries18);
        org.jfree.data.time.SerialDate serialDate28 = day3.getSerialDate();
        int int30 = day3.compareTo((java.lang.Object) 100.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day3.next();
        java.util.Calendar calendar32 = null;
        try {
            long long33 = day3.getLastMillisecond(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
//        timeSeries1.add(timeSeriesDataItem4);
//        boolean boolean6 = timeSeries1.getNotify();
//        timeSeries1.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        long long10 = fixedMillisecond9.getMiddleMillisecond();
//        long long11 = fixedMillisecond9.getSerialIndex();
//        java.util.Calendar calendar12 = null;
//        fixedMillisecond9.peg(calendar12);
//        boolean boolean15 = fixedMillisecond9.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, 0.0d);
//        java.lang.Number number18 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, number18);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries22 = timeSeries1.createCopy(8, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560182876040L + "'", long10 == 1560182876040L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182876040L + "'", long11 == 1560182876040L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        int int4 = month2.getMonth();
        long long5 = month2.getMiddleMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1576526399999L + "'", long5 == 1576526399999L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (double) 1560182842702L);
        timeSeriesDataItem17.setSelected(false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(10, 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Value");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
//        timeSeries1.add(timeSeriesDataItem4);
//        timeSeries1.setNotify(true);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
//        timeSeries11.add(timeSeriesDataItem14);
//        timeSeries11.setNotify(true);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        java.util.Date date19 = year18.getEnd();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        java.util.Date date21 = year20.getEnd();
//        boolean boolean23 = year20.equals((java.lang.Object) 100);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) year20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year18.next();
//        int int27 = year18.compareTo((java.lang.Object) 6);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (double) (short) -1);
//        timeSeries1.setMaximumItemCount((int) '#');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        long long33 = fixedMillisecond32.getMiddleMillisecond();
//        long long34 = fixedMillisecond32.getSerialIndex();
//        java.util.Date date35 = fixedMillisecond32.getStart();
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
//        int int37 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year36);
//        java.util.Calendar calendar38 = null;
//        try {
//            year36.peg(calendar38);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560182876722L + "'", long33 == 1560182876722L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560182876722L + "'", long34 == 1560182876722L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = seriesChangeEvent1.getSummary();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str2.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertNull(seriesChangeInfo4);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        long long3 = month2.getSerialIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24240L + "'", long3 == 24240L);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
//        timeSeries1.add(timeSeriesDataItem4);
//        timeSeries1.setNotify(true);
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        java.util.Date date9 = year8.getEnd();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        java.util.Date date11 = year10.getEnd();
//        boolean boolean13 = year10.equals((java.lang.Object) 100);
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
//        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timeSeries21.removePropertyChangeListener(propertyChangeListener22);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (double) (-1.0f));
//        timeSeries25.add(timeSeriesDataItem28);
//        timeSeries25.setNotify(true);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        java.util.Date date33 = year32.getEnd();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        java.util.Date date35 = year34.getEnd();
//        boolean boolean37 = year34.equals((java.lang.Object) 100);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) year34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year32.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year32, (double) 1.0f);
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) 10.0d);
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        timeSeries45.setMaximumItemAge((long) 'a');
//        boolean boolean48 = year32.equals((java.lang.Object) 'a');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        long long50 = fixedMillisecond49.getMiddleMillisecond();
//        long long51 = fixedMillisecond49.getSerialIndex();
//        java.util.Date date52 = fixedMillisecond49.getStart();
//        int int53 = year32.compareTo((java.lang.Object) date52);
//        java.util.TimeZone timeZone54 = null;
//        java.util.Locale locale55 = null;
//        try {
//            org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date52, timeZone54, locale55);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560182876941L + "'", long50 == 1560182876941L);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560182876941L + "'", long51 == 1560182876941L);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.lang.Class<?> wildcardClass9 = fixedMillisecond0.getClass();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        long long12 = fixedMillisecond11.getMiddleMillisecond();
//        long long13 = fixedMillisecond11.getSerialIndex();
//        java.util.Date date14 = fixedMillisecond11.getStart();
//        java.util.TimeZone timeZone15 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date14, timeZone15);
//        java.util.TimeZone timeZone17 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone17);
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182876982L + "'", long1 == 1560182876982L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182876982L + "'", long2 == 1560182876982L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560182876987L + "'", long12 == 1560182876987L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182876987L + "'", long13 == 1560182876987L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(class19);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        int int4 = month2.getMonth();
        long long5 = month2.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.previous();
        int int9 = month2.getYearValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1576526399999L + "'", long5 == 1576526399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        boolean boolean15 = year12.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) 1560182842702L);
        java.lang.Object obj20 = timeSeriesDataItem19.clone();
        timeSeries1.add(timeSeriesDataItem19, false);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries24.setDomainDescription("hi!");
        timeSeries24.setMaximumItemCount(0);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year((int) (byte) -1);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        java.util.Date date32 = year31.getEnd();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month33.previous();
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) year30, (org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year30, (java.lang.Number) 1560182873327L, false);
        try {
            timeSeries1.delete((int) (byte) 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(timeSeries35);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        boolean boolean17 = year14.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener21);
        java.util.Collection collection23 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        boolean boolean24 = timeSeries18.isEmpty();
        java.util.Collection collection25 = timeSeries18.getTimePeriods();
        java.lang.String str26 = timeSeries18.getDomainDescription();
        int int27 = day3.compareTo((java.lang.Object) timeSeries18);
        org.jfree.data.time.SerialDate serialDate28 = day3.getSerialDate();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        java.util.Date date30 = year29.getEnd();
        boolean boolean32 = year29.equals((java.lang.Object) 100);
        int int33 = day3.compareTo((java.lang.Object) 100);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        int int4 = month2.getMonth();
        java.util.Calendar calendar5 = null;
        try {
            month2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date3 = fixedMillisecond0.getStart();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
//        int int8 = day6.getMonth();
//        long long9 = day6.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182877356L + "'", long1 == 1560182877356L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182877356L + "'", long2 == 1560182877356L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean20 = timeSeries14.isEmpty();
        java.util.Collection collection21 = timeSeries14.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries23.setDomainDescription("hi!");
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.previous();
        java.util.Date date28 = regularTimePeriod27.getStart();
        timeSeries23.delete(regularTimePeriod27);
        double double30 = timeSeries23.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (-1.0f));
        timeSeries32.add(timeSeriesDataItem35);
        timeSeries32.setNotify(true);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        java.util.Date date40 = year39.getEnd();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        java.util.Date date42 = year41.getEnd();
        boolean boolean44 = year41.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) year39, (org.jfree.data.time.RegularTimePeriod) year41);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        java.util.Date date47 = year46.getEnd();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month48.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) month48);
        org.jfree.data.time.Year year51 = month48.getYear();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) year51, (java.lang.Number) 1560182842664L);
        java.util.Collection collection54 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year57, (double) (-1.0f));
        timeSeries56.add(timeSeriesDataItem59);
        timeSeries56.setNotify(true);
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        java.util.Date date64 = year63.getEnd();
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year();
        java.util.Date date66 = year65.getEnd();
        boolean boolean68 = year65.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries56.createCopy((org.jfree.data.time.RegularTimePeriod) year63, (org.jfree.data.time.RegularTimePeriod) year65);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = year63.next();
        int int72 = year63.compareTo((java.lang.Object) 6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year63, (double) 1L);
        boolean boolean76 = timeSeriesDataItem74.equals((java.lang.Object) 1560182873400L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(timeSeriesDataItem50);
        org.junit.Assert.assertNotNull(year51);
        org.junit.Assert.assertNotNull(collection54);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(timeSeries69);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        timeSeries5.setNotify(true);
        timeSeries5.setKey((java.lang.Comparable) 1.0f);
        boolean boolean16 = day3.equals((java.lang.Object) timeSeries5);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod20, (java.lang.Number) 9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod20, (java.lang.Number) 10.0f);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries5.addOrUpdate(timeSeriesDataItem24);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        java.lang.String str4 = month2.toString();
        java.util.Calendar calendar5 = null;
        try {
            month2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "December 2019" + "'", str3.equals("December 2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "December 2019" + "'", str4.equals("December 2019"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1560182855376L, seriesChangeInfo1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
        try {
            int int11 = timeSeries1.getIndex(regularTimePeriod10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date3 = fixedMillisecond0.getStart();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3);
//        java.util.TimeZone timeZone7 = null;
//        java.util.Locale locale8 = null;
//        try {
//            org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date3, timeZone7, locale8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182878506L + "'", long1 == 1560182878506L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182878506L + "'", long2 == 1560182878506L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        timeSeries11.add(timeSeriesDataItem14);
        timeSeries11.setNotify(true);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getEnd();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        boolean boolean23 = year20.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year18.next();
        int int27 = year18.compareTo((java.lang.Object) 6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (double) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year32, (double) (-1.0f));
        timeSeries31.add(timeSeriesDataItem34);
        timeSeries31.setNotify(true);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        java.util.Date date41 = year40.getEnd();
        boolean boolean43 = year40.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries31.createCopy((org.jfree.data.time.RegularTimePeriod) year38, (org.jfree.data.time.RegularTimePeriod) year40);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener47 = null;
        timeSeries46.removePropertyChangeListener(propertyChangeListener47);
        java.util.Collection collection49 = timeSeries44.getTimePeriodsUniqueToOtherSeries(timeSeries46);
        boolean boolean50 = timeSeriesDataItem29.equals((java.lang.Object) timeSeries46);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year53, (double) (-1.0f));
        timeSeries52.add(timeSeriesDataItem55);
        timeSeries52.setNotify(true);
        timeSeries52.setNotify(true);
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year61.previous();
        timeSeries52.update((org.jfree.data.time.RegularTimePeriod) year61, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = timeSeries52.getNextTimePeriod();
        long long66 = regularTimePeriod65.getMiddleMillisecond();
        timeSeries46.delete(regularTimePeriod65);
        try {
            org.jfree.data.time.TimeSeries timeSeries70 = timeSeries46.createCopy(12, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertNotNull(collection49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1593676799999L + "'", long66 == 1593676799999L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182878578L + "'", long2 == 1560182878578L);
//    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test205");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        java.beans.PropertyChangeListener propertyChangeListener2 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getMiddleMillisecond();
//        int int7 = fixedMillisecond4.compareTo((java.lang.Object) 1560182842664L);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (-1.0f));
//        timeSeries9.add(timeSeriesDataItem12);
//        timeSeries9.setNotify(true);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        java.util.Date date17 = year16.getEnd();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        java.util.Date date19 = year18.getEnd();
//        boolean boolean21 = year18.equals((java.lang.Object) 100);
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year18);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        java.beans.PropertyChangeListener propertyChangeListener25 = null;
//        timeSeries24.removePropertyChangeListener(propertyChangeListener25);
//        java.util.Collection collection27 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries24);
//        java.util.List list28 = timeSeries24.getItems();
//        int int29 = fixedMillisecond4.compareTo((java.lang.Object) list28);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 1560182844817L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = null;
//        try {
//            timeSeries1.add(regularTimePeriod32, (java.lang.Number) 9223372036854775807L, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560182878589L + "'", long5 == 1560182878589L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertNotNull(collection27);
//        org.junit.Assert.assertNotNull(list28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
//        timeSeries1.add(timeSeriesDataItem4);
//        boolean boolean6 = timeSeries1.getNotify();
//        timeSeries1.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        long long10 = fixedMillisecond9.getMiddleMillisecond();
//        long long11 = fixedMillisecond9.getSerialIndex();
//        java.util.Calendar calendar12 = null;
//        fixedMillisecond9.peg(calendar12);
//        boolean boolean15 = fixedMillisecond9.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, 0.0d);
//        java.lang.Number number18 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, number18);
//        java.util.Calendar calendar20 = null;
//        fixedMillisecond9.peg(calendar20);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560182878626L + "'", long10 == 1560182878626L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182878626L + "'", long11 == 1560182878626L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.lang.Class<?> wildcardClass9 = fixedMillisecond0.getClass();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond0.getLastMillisecond(calendar10);
//        long long12 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182878855L + "'", long1 == 1560182878855L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182878855L + "'", long2 == 1560182878855L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182878855L + "'", long11 == 1560182878855L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560182878855L + "'", long12 == 1560182878855L);
//    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        long long2 = fixedMillisecond1.getMiddleMillisecond();
//        long long3 = fixedMillisecond1.getSerialIndex();
//        java.util.Date date4 = fixedMillisecond1.getStart();
//        java.util.TimeZone timeZone5 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date4);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182878880L + "'", long2 == 1560182878880L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560182878880L + "'", long3 == 1560182878880L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        timeSeries1.setMaximumItemCount(0);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (byte) -1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, (double) (-1.0f));
        timeSeries14.add(timeSeriesDataItem17);
        timeSeries14.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (double) (-1.0f));
        timeSeries22.add(timeSeriesDataItem25);
        timeSeries22.setNotify(true);
        timeSeries22.setNotify(true);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year31.previous();
        timeSeries22.update((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 100);
        java.lang.Number number36 = null;
        timeSeries22.update((int) (short) 0, number36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries14.addAndOrUpdate(timeSeries22);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year43, (double) (-1.0f));
        timeSeries42.add(timeSeriesDataItem45);
        timeSeries42.setNotify(true);
        timeSeries42.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries40.addAndOrUpdate(timeSeries42);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener52 = null;
        timeSeries51.removeChangeListener(seriesChangeListener52);
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries38.addAndOrUpdate(timeSeries51);
        java.util.Collection collection55 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries1.addOrUpdate(regularTimePeriod56, (java.lang.Number) 1560182844874L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertNotNull(collection55);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        timeSeries1.setNotify(true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        int int3 = fixedMillisecond0.compareTo((java.lang.Object) 1560182842664L);
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        long long6 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182878975L + "'", long1 == 1560182878975L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182878975L + "'", long6 == 1560182878975L);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries21.removePropertyChangeListener(propertyChangeListener22);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (double) (-1.0f));
        timeSeries25.add(timeSeriesDataItem28);
        timeSeries25.setNotify(true);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.util.Date date33 = year32.getEnd();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        java.util.Date date35 = year34.getEnd();
        boolean boolean37 = year34.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) year34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year32.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year32, (double) 1.0f);
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) 10.0d);
        java.lang.Object obj44 = timeSeries16.clone();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(obj44);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "Time", "");
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        boolean boolean20 = timeSeriesDataItem19.isSelected();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getTime();
        boolean boolean5 = fixedMillisecond1.equals((java.lang.Object) 1560182868103L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        timeSeries11.add(timeSeriesDataItem14);
        timeSeries11.setNotify(true);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getEnd();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        boolean boolean23 = year20.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year18.next();
        int int27 = year18.compareTo((java.lang.Object) 6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (double) (short) -1);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.previous();
        java.util.Date date32 = regularTimePeriod31.getStart();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        int int34 = timeSeriesDataItem29.compareTo((java.lang.Object) date32);
        java.util.TimeZone timeZone35 = null;
        java.util.Locale locale36 = null;
        try {
            org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date32, timeZone35, locale36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        timeSeries1.setDomainDescription("hi!");
//        timeSeries1.setMaximumItemCount(0);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (byte) -1);
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        java.util.Date date9 = year8.getEnd();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) month10);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, (double) (-1.0f));
//        timeSeries14.add(timeSeriesDataItem17);
//        timeSeries14.setNotify(true);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (double) (-1.0f));
//        timeSeries22.add(timeSeriesDataItem25);
//        timeSeries22.setNotify(true);
//        timeSeries22.setNotify(true);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year31.previous();
//        timeSeries22.update((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 100);
//        java.lang.Number number36 = null;
//        timeSeries22.update((int) (short) 0, number36);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries14.addAndOrUpdate(timeSeries22);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year43, (double) (-1.0f));
//        timeSeries42.add(timeSeriesDataItem45);
//        timeSeries42.setNotify(true);
//        timeSeries42.setNotify(true);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries40.addAndOrUpdate(timeSeries42);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener52 = null;
//        timeSeries51.removeChangeListener(seriesChangeListener52);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries38.addAndOrUpdate(timeSeries51);
//        java.util.Collection collection55 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
//        long long58 = fixedMillisecond57.getMiddleMillisecond();
//        long long59 = fixedMillisecond57.getSerialIndex();
//        java.util.Calendar calendar60 = null;
//        fixedMillisecond57.peg(calendar60);
//        boolean boolean63 = fixedMillisecond57.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57, 0.0d);
//        java.lang.Class<?> wildcardClass66 = fixedMillisecond57.getClass();
//        java.util.Date date67 = fixedMillisecond57.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond(date67);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries69 = timeSeries38.createCopy(regularTimePeriod56, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond68);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertNotNull(collection55);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560182880193L + "'", long58 == 1560182880193L);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560182880193L + "'", long59 == 1560182880193L);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(wildcardClass66);
//        org.junit.Assert.assertNotNull(date67);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean20 = timeSeries14.isEmpty();
        java.util.Collection collection21 = timeSeries14.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries23.setDomainDescription("hi!");
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.previous();
        java.util.Date date28 = regularTimePeriod27.getStart();
        timeSeries23.delete(regularTimePeriod27);
        double double30 = timeSeries23.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (-1.0f));
        timeSeries32.add(timeSeriesDataItem35);
        timeSeries32.setNotify(true);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        java.util.Date date40 = year39.getEnd();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        java.util.Date date42 = year41.getEnd();
        boolean boolean44 = year41.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) year39, (org.jfree.data.time.RegularTimePeriod) year41);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        java.util.Date date47 = year46.getEnd();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month48.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) month48);
        org.jfree.data.time.Year year51 = month48.getYear();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) year51, (java.lang.Number) 1560182842664L);
        java.util.Collection collection54 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener55 = null;
        timeSeries23.addChangeListener(seriesChangeListener55);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(timeSeriesDataItem50);
        org.junit.Assert.assertNotNull(year51);
        org.junit.Assert.assertNotNull(collection54);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.Year year2 = month0.getYear();
        long long3 = year2.getLastMillisecond();
        boolean boolean5 = year2.equals((java.lang.Object) 1560182844817L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Number number4 = timeSeriesDataItem2.getValue();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (double) 1560182842702L);
        java.lang.Object obj18 = timeSeriesDataItem17.clone();
        timeSeriesDataItem17.setSelected(false);
        boolean boolean21 = timeSeriesDataItem17.isSelected();
        java.lang.Number number22 = timeSeriesDataItem17.getValue();
        timeSeriesDataItem17.setValue((java.lang.Number) 1560182880899L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 1.560182842702E12d + "'", number22.equals(1.560182842702E12d));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.next();
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray18 = seriesException17.getSuppressed();
        int int19 = year8.compareTo((java.lang.Object) throwableArray18);
        long long20 = year8.getSerialIndex();
        int int22 = year8.compareTo((java.lang.Object) 1560182863867L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.removeAgedItems(1560182865213L, false);
        boolean boolean11 = timeSeries1.getNotify();
        java.util.List list12 = timeSeries1.getItems();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        java.lang.String str20 = month17.toString();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        timeSeries24.add(timeSeriesDataItem27);
        timeSeries24.setNotify(true);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        java.util.Date date32 = year31.getEnd();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        java.util.Date date34 = year33.getEnd();
        boolean boolean36 = year33.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) year31, (org.jfree.data.time.RegularTimePeriod) year33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year31.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (double) 1560182842702L);
        java.lang.Object obj41 = timeSeriesDataItem40.clone();
        timeSeries22.add(timeSeriesDataItem40, false);
        timeSeriesDataItem40.setValue((java.lang.Number) 1560182866005L);
        boolean boolean46 = month17.equals((java.lang.Object) 1560182866005L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "December 2019" + "'", str20.equals("December 2019"));
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        boolean boolean3 = year0.equals((java.lang.Object) 100);
        java.util.Date date4 = year0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        java.util.Calendar calendar6 = null;
        try {
            year0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        boolean boolean17 = year14.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener21);
        java.util.Collection collection23 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        boolean boolean24 = timeSeries18.isEmpty();
        java.util.Collection collection25 = timeSeries18.getTimePeriods();
        java.lang.String str26 = timeSeries18.getDomainDescription();
        int int27 = day3.compareTo((java.lang.Object) timeSeries18);
        org.jfree.data.time.SerialDate serialDate28 = day3.getSerialDate();
        int int30 = day3.compareTo((java.lang.Object) 100.0f);
        java.util.Calendar calendar31 = null;
        try {
            long long32 = day3.getFirstMillisecond(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        int int4 = day3.getYear();
        long long5 = day3.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577779200000L + "'", long5 == 1577779200000L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        int int4 = day3.getYear();
        int int5 = day3.getDayOfMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries1.getNextTimePeriod();
        java.lang.String str15 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getEnd();
        boolean boolean19 = year16.equals((java.lang.Object) 100);
        java.util.Date date20 = year16.getEnd();
        java.lang.Number number21 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, number21);
        timeSeries1.setMaximumItemAge(1560182872380L);
        long long25 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560182872380L + "'", long25 == 1560182872380L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        int int4 = month2.getMonth();
        long long5 = month2.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (-1.0d));
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1576526399999L + "'", long5 == 1576526399999L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries1.getNextTimePeriod();
        timeSeries1.removeAgedItems(0L, false);
        timeSeries1.setNotify(false);
        boolean boolean20 = timeSeries1.isEmpty();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.util.Date date22 = year21.getEnd();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod24, (java.lang.Number) 9);
        try {
            timeSeries1.add(timeSeriesDataItem26, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
//        java.util.Date date11 = regularTimePeriod10.getStart();
//        boolean boolean12 = fixedMillisecond0.equals((java.lang.Object) date11);
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond0.getFirstMillisecond(calendar13);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182882148L + "'", long1 == 1560182882148L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182882148L + "'", long2 == 1560182882148L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560182882148L + "'", long14 == 1560182882148L);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.String str3 = year0.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test237");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date3 = fixedMillisecond0.getStart();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3);
//        java.lang.String str7 = day6.toString();
//        java.util.Calendar calendar8 = null;
//        try {
//            day6.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182882190L + "'", long1 == 1560182882190L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182882190L + "'", long2 == 1560182882190L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        timeSeries1.setMaximumItemCount(0);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (byte) -1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, (double) (-1.0f));
        timeSeries14.add(timeSeriesDataItem17);
        timeSeries14.setNotify(true);
        timeSeries14.setNotify(true);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        timeSeries14.update((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries14.getNextTimePeriod();
        java.lang.String str28 = timeSeries14.getDomainDescription();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        java.util.Date date30 = year29.getEnd();
        boolean boolean32 = year29.equals((java.lang.Object) 100);
        java.util.Date date33 = year29.getEnd();
        java.lang.Number number34 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year29, number34);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) 1560182868197L, true);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1560182868197L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Time" + "'", str28.equals("Time"));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeSeriesDataItem35);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.util.Date date6 = regularTimePeriod5.getStart();
        timeSeries1.delete(regularTimePeriod5);
        double double8 = timeSeries1.getMaxY();
        timeSeries1.setNotify(true);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.lang.Class<?> wildcardClass9 = fixedMillisecond0.getClass();
//        java.util.Date date10 = fixedMillisecond0.getTime();
//        java.util.TimeZone timeZone11 = null;
//        java.util.Locale locale12 = null;
//        try {
//            org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date10, timeZone11, locale12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182882934L + "'", long1 == 1560182882934L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182882934L + "'", long2 == 1560182882934L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(date10);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1577865599999L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean20 = timeSeries14.isEmpty();
        java.util.Collection collection21 = timeSeries14.getTimePeriods();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.previous();
        java.util.Date date24 = regularTimePeriod23.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) year25, (double) 1560182865239L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(false);
        java.lang.Comparable comparable10 = timeSeries1.getKey();
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 1560182842943L + "'", comparable10.equals(1560182842943L));
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        java.beans.PropertyChangeListener propertyChangeListener2 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getMiddleMillisecond();
//        int int7 = fixedMillisecond4.compareTo((java.lang.Object) 1560182842664L);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (-1.0f));
//        timeSeries9.add(timeSeriesDataItem12);
//        timeSeries9.setNotify(true);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        java.util.Date date17 = year16.getEnd();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        java.util.Date date19 = year18.getEnd();
//        boolean boolean21 = year18.equals((java.lang.Object) 100);
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year18);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        java.beans.PropertyChangeListener propertyChangeListener25 = null;
//        timeSeries24.removePropertyChangeListener(propertyChangeListener25);
//        java.util.Collection collection27 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries24);
//        java.util.List list28 = timeSeries24.getItems();
//        int int29 = fixedMillisecond4.compareTo((java.lang.Object) list28);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 1560182844817L);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        java.util.Date date33 = year32.getEnd();
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month34.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod35, (java.lang.Number) 9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod35, (java.lang.Number) 10.0f);
//        try {
//            timeSeries1.add(regularTimePeriod35, (java.lang.Number) 1560182868103L, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560182883193L + "'", long5 == 1560182883193L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertNotNull(collection27);
//        org.junit.Assert.assertNotNull(list28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date3 = fixedMillisecond0.getStart();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date3);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182883366L + "'", long1 == 1560182883366L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182883366L + "'", long2 == 1560182883366L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean20 = timeSeries14.isEmpty();
        java.util.Collection collection21 = timeSeries14.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries23.setDomainDescription("hi!");
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.previous();
        java.util.Date date28 = regularTimePeriod27.getStart();
        timeSeries23.delete(regularTimePeriod27);
        double double30 = timeSeries23.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (-1.0f));
        timeSeries32.add(timeSeriesDataItem35);
        timeSeries32.setNotify(true);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        java.util.Date date40 = year39.getEnd();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        java.util.Date date42 = year41.getEnd();
        boolean boolean44 = year41.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) year39, (org.jfree.data.time.RegularTimePeriod) year41);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        java.util.Date date47 = year46.getEnd();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month48.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) month48);
        org.jfree.data.time.Year year51 = month48.getYear();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) year51, (java.lang.Number) 1560182842664L);
        java.util.Collection collection54 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year57, (double) (-1.0f));
        timeSeries56.add(timeSeriesDataItem59);
        timeSeries56.setNotify(true);
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        java.util.Date date64 = year63.getEnd();
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year();
        java.util.Date date66 = year65.getEnd();
        boolean boolean68 = year65.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries56.createCopy((org.jfree.data.time.RegularTimePeriod) year63, (org.jfree.data.time.RegularTimePeriod) year65);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = year63.next();
        int int72 = year63.compareTo((java.lang.Object) 6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year63, (double) 1L);
        long long75 = year63.getSerialIndex();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(timeSeriesDataItem50);
        org.junit.Assert.assertNotNull(year51);
        org.junit.Assert.assertNotNull(collection54);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(timeSeries69);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem74);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 2019L + "'", long75 == 2019L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "org.jfree.data.general.SeriesException: hi!", "2019");
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(2, 4);
        org.junit.Assert.assertNotNull(timeSeries6);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries12.addChangeListener(seriesChangeListener15);
        org.junit.Assert.assertNotNull(timeSeries12);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date3 = fixedMillisecond0.getStart();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        java.util.TimeZone timeZone5 = null;
//        java.util.Locale locale6 = null;
//        try {
//            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date3, timeZone5, locale6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182884206L + "'", long1 == 1560182884206L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182884206L + "'", long2 == 1560182884206L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        boolean boolean17 = year14.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener21);
        java.util.Collection collection23 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        boolean boolean24 = timeSeries18.isEmpty();
        java.util.Collection collection25 = timeSeries18.getTimePeriods();
        java.lang.String str26 = timeSeries18.getDomainDescription();
        int int27 = day3.compareTo((java.lang.Object) timeSeries18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date30 = fixedMillisecond29.getTime();
        boolean boolean31 = day3.equals((java.lang.Object) date30);
        long long32 = day3.getFirstMillisecond();
        int int33 = day3.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577779200000L + "'", long32 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year0);
        int int3 = year0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        boolean boolean17 = year14.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener21);
        java.util.Collection collection23 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        boolean boolean24 = timeSeries18.isEmpty();
        java.util.Collection collection25 = timeSeries18.getTimePeriods();
        java.lang.String str26 = timeSeries18.getDomainDescription();
        int int27 = day3.compareTo((java.lang.Object) timeSeries18);
        org.jfree.data.time.SerialDate serialDate28 = day3.getSerialDate();
        java.lang.String str29 = day3.toString();
        org.jfree.data.time.SerialDate serialDate30 = day3.getSerialDate();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "31-December-2019" + "'", str29.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(serialDate30);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        timeSeries1.removeAgedItems((long) 11, false);
        try {
            timeSeries1.update(10, (java.lang.Number) 1560182875959L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        boolean boolean6 = timeSeries1.getNotify();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = seriesChangeEvent7.getSummary();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(seriesChangeInfo8);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test256");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date3 = fixedMillisecond0.getStart();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3);
//        java.lang.String str7 = day6.toString();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day6.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182884930L + "'", long1 == 1560182884930L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182884930L + "'", long2 == 1560182884930L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        timeSeries14.update((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 1560182880899L);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year20, seriesChangeInfo24);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (-1.0f));
        timeSeries9.add(timeSeriesDataItem12);
        timeSeries9.setNotify(true);
        timeSeries9.setNotify(true);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        timeSeries9.update((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 100);
        java.lang.Number number23 = null;
        timeSeries9.update((int) (short) 0, number23);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries1.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year28, (double) (-1.0f));
        timeSeries27.add(timeSeriesDataItem30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.util.Date date33 = year32.getEnd();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month34.previous();
        int int36 = timeSeriesDataItem30.compareTo((java.lang.Object) month34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month34.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month34);
        java.util.Calendar calendar39 = null;
        try {
            month34.peg(calendar39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(timeSeriesDataItem38);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.util.Date date6 = regularTimePeriod5.getStart();
        timeSeries1.delete(regularTimePeriod5);
        double double8 = timeSeries1.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (double) (-1.0f));
        timeSeries10.add(timeSeriesDataItem13);
        timeSeries10.setNotify(true);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.util.Date date20 = year19.getEnd();
        boolean boolean22 = year19.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year19);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getEnd();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month26);
        org.jfree.data.time.Year year29 = month26.getYear();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) 1560182842664L);
        java.util.List list32 = timeSeries1.getItems();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(year29);
        org.junit.Assert.assertNotNull(list32);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond0.previous();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getLastMillisecond(calendar4);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182885428L + "'", long1 == 1560182885428L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182885428L + "'", long2 == 1560182885428L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560182885428L + "'", long5 == 1560182885428L);
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries1.getNextTimePeriod();
        timeSeries1.setDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timeSeries1.setMaximumItemCount((int) (short) 100);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1576526399999L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) collection19);
        java.lang.Object obj21 = seriesChangeEvent20.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo22 = seriesChangeEvent20.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo23 = null;
        seriesChangeEvent20.setSummary(seriesChangeInfo23);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNull(seriesChangeInfo22);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 100);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (double) (-1.0f));
        timeSeries17.add(timeSeriesDataItem20);
        timeSeries17.setNotify(true);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getEnd();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        java.util.Date date27 = year26.getEnd();
        boolean boolean29 = year26.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) year24, (org.jfree.data.time.RegularTimePeriod) year26);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries32.removePropertyChangeListener(propertyChangeListener33);
        java.util.Collection collection35 = timeSeries30.getTimePeriodsUniqueToOtherSeries(timeSeries32);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries37.removePropertyChangeListener(propertyChangeListener38);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year42, (double) (-1.0f));
        timeSeries41.add(timeSeriesDataItem44);
        timeSeries41.setNotify(true);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        java.util.Date date49 = year48.getEnd();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        java.util.Date date51 = year50.getEnd();
        boolean boolean53 = year50.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries41.createCopy((org.jfree.data.time.RegularTimePeriod) year48, (org.jfree.data.time.RegularTimePeriod) year50);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year48.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year48, (double) 1.0f);
        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) 10.0d);
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year62, (double) (-1.0f));
        timeSeries61.add(timeSeriesDataItem64);
        timeSeries61.setNotify(true);
        timeSeries61.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year72, (double) (-1.0f));
        timeSeries71.add(timeSeriesDataItem74);
        timeSeries71.setNotify(true);
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        java.util.Date date79 = year78.getEnd();
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year();
        java.util.Date date81 = year80.getEnd();
        boolean boolean83 = year80.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries84 = timeSeries71.createCopy((org.jfree.data.time.RegularTimePeriod) year78, (org.jfree.data.time.RegularTimePeriod) year80);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = year78.next();
        int int87 = year78.compareTo((java.lang.Object) 6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem89 = timeSeries61.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year78, (double) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries90 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year48, (org.jfree.data.time.RegularTimePeriod) year78);
        int int91 = timeSeries90.getMaximumItemCount();
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(timeSeries84);
        org.junit.Assert.assertNotNull(regularTimePeriod85);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem89);
        org.junit.Assert.assertNotNull(timeSeries90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 2147483647 + "'", int91 == 2147483647);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "org.jfree.data.general.SeriesException: hi!", "2019");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        long long6 = month5.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month5.next();
        java.lang.Number number8 = timeSeries3.getValue(regularTimePeriod7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.previous();
        int int13 = month11.getMonth();
        long long14 = month11.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month11.previous();
        timeSeries3.setKey((java.lang.Comparable) regularTimePeriod17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date23 = fixedMillisecond22.getTime();
        boolean boolean24 = fixedMillisecond20.equals((java.lang.Object) date23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries26 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, regularTimePeriod25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1576526399999L + "'", long14 == 1576526399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        boolean boolean17 = year14.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1.0f);
        int int23 = year12.compareTo((java.lang.Object) 0.0f);
        java.lang.String str24 = year12.toString();
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries1.getNextTimePeriod();
        timeSeries1.removeAgedItems(true);
        timeSeries1.setMaximumItemAge(43830L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries1.removeChangeListener(seriesChangeListener19);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        int int3 = month2.getYearValue();
        java.util.Calendar calendar4 = null;
        try {
            month2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (-1.0f));
        timeSeries9.add(timeSeriesDataItem12);
        timeSeries9.setNotify(true);
        timeSeries9.setNotify(true);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        timeSeries9.update((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 100);
        java.lang.Number number23 = null;
        timeSeries9.update((int) (short) 0, number23);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries1.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year30, (double) (-1.0f));
        timeSeries29.add(timeSeriesDataItem32);
        timeSeries29.setNotify(true);
        timeSeries29.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries27.addAndOrUpdate(timeSeries29);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
        timeSeries38.removeChangeListener(seriesChangeListener39);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries25.addAndOrUpdate(timeSeries38);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
        timeSeries41.removeChangeListener(seriesChangeListener42);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(timeSeries41);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries1.getNextTimePeriod();
        timeSeries1.removeAgedItems(true);
        timeSeries1.setMaximumItemAge(43830L);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.util.Date date20 = year19.getEnd();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.previous();
        int int23 = month21.getMonth();
        long long24 = month21.getMiddleMillisecond();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 1560182873400L, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 12 + "'", int23 == 12);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1576526399999L + "'", long24 == 1576526399999L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        boolean boolean17 = year14.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener21);
        java.util.Collection collection23 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        boolean boolean24 = timeSeries18.isEmpty();
        java.util.Collection collection25 = timeSeries18.getTimePeriods();
        java.lang.String str26 = timeSeries18.getDomainDescription();
        int int27 = day3.compareTo((java.lang.Object) timeSeries18);
        org.jfree.data.time.SerialDate serialDate28 = day3.getSerialDate();
        int int30 = day3.compareTo((java.lang.Object) 100.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day3.next();
        int int32 = day3.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (-1.0f));
        timeSeries9.add(timeSeriesDataItem12);
        timeSeries9.setNotify(true);
        timeSeries9.setNotify(true);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        timeSeries9.update((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 100);
        java.lang.Number number23 = null;
        timeSeries9.update((int) (short) 0, number23);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries1.addAndOrUpdate(timeSeries9);
        timeSeries9.setRangeDescription("");
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(timeSeries25);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        int int15 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (double) 1560182842702L);
        java.lang.Object obj18 = timeSeriesDataItem17.clone();
        timeSeriesDataItem17.setSelected(false);
        java.lang.Object obj21 = timeSeriesDataItem17.clone();
        timeSeriesDataItem17.setSelected(false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (double) 1560182842702L);
        java.lang.Object obj18 = timeSeriesDataItem17.clone();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.util.Date date20 = year19.getEnd();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month21, "hi!", "");
        int int25 = timeSeriesDataItem17.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year28, (double) (-1.0f));
        timeSeries27.add(timeSeriesDataItem30);
        timeSeries27.setNotify(true);
        timeSeries27.setNotify(true);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year36.previous();
        timeSeries27.update((org.jfree.data.time.RegularTimePeriod) year36, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = timeSeries27.getNextTimePeriod();
        boolean boolean41 = timeSeriesDataItem17.equals((java.lang.Object) regularTimePeriod40);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = fixedMillisecond0.equals(obj2);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        java.util.TimeZone timeZone7 = null;
//        try {
//            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date6, timeZone7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560182888405L + "'", long5 == 1560182888405L);
//        org.junit.Assert.assertNotNull(date6);
//    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.lang.Class<?> wildcardClass9 = fixedMillisecond0.getClass();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        long long12 = fixedMillisecond11.getMiddleMillisecond();
//        long long13 = fixedMillisecond11.getSerialIndex();
//        java.util.Date date14 = fixedMillisecond11.getStart();
//        java.util.TimeZone timeZone15 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date14, timeZone15);
//        java.util.TimeZone timeZone17 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date14);
//        long long20 = day19.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day19.previous();
//        int int22 = day19.getMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182888423L + "'", long1 == 1560182888423L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182888423L + "'", long2 == 1560182888423L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560182888424L + "'", long12 == 1560182888424L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182888424L + "'", long13 == 1560182888424L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560193199999L + "'", long20 == 1560193199999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 100);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (double) (-1.0f));
        timeSeries17.add(timeSeriesDataItem20);
        timeSeries17.setNotify(true);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getEnd();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        java.util.Date date27 = year26.getEnd();
        boolean boolean29 = year26.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) year24, (org.jfree.data.time.RegularTimePeriod) year26);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries32.removePropertyChangeListener(propertyChangeListener33);
        java.util.Collection collection35 = timeSeries30.getTimePeriodsUniqueToOtherSeries(timeSeries32);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries37.removePropertyChangeListener(propertyChangeListener38);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year42, (double) (-1.0f));
        timeSeries41.add(timeSeriesDataItem44);
        timeSeries41.setNotify(true);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        java.util.Date date49 = year48.getEnd();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        java.util.Date date51 = year50.getEnd();
        boolean boolean53 = year50.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries41.createCopy((org.jfree.data.time.RegularTimePeriod) year48, (org.jfree.data.time.RegularTimePeriod) year50);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year48.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year48, (double) 1.0f);
        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) 10.0d);
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year62, (double) (-1.0f));
        timeSeries61.add(timeSeriesDataItem64);
        timeSeries61.setNotify(true);
        timeSeries61.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year72, (double) (-1.0f));
        timeSeries71.add(timeSeriesDataItem74);
        timeSeries71.setNotify(true);
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        java.util.Date date79 = year78.getEnd();
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year();
        java.util.Date date81 = year80.getEnd();
        boolean boolean83 = year80.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries84 = timeSeries71.createCopy((org.jfree.data.time.RegularTimePeriod) year78, (org.jfree.data.time.RegularTimePeriod) year80);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = year78.next();
        int int87 = year78.compareTo((java.lang.Object) 6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem89 = timeSeries61.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year78, (double) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries90 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year48, (org.jfree.data.time.RegularTimePeriod) year78);
        try {
            timeSeries90.update(4, (java.lang.Number) 1560182875959L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(timeSeries84);
        org.junit.Assert.assertNotNull(regularTimePeriod85);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem89);
        org.junit.Assert.assertNotNull(timeSeries90);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) 1.0d);
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        long long5 = fixedMillisecond0.getFirstMillisecond();
//        long long6 = fixedMillisecond0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182888537L + "'", long1 == 1560182888537L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560182888537L + "'", long5 == 1560182888537L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182888537L + "'", long6 == 1560182888537L);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean20 = timeSeries14.isEmpty();
        java.util.Collection collection21 = timeSeries14.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (double) (-1.0f));
        timeSeries23.add(timeSeriesDataItem26);
        timeSeries23.setNotify(true);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        java.util.Date date31 = year30.getEnd();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.util.Date date33 = year32.getEnd();
        boolean boolean35 = year32.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) year30, (org.jfree.data.time.RegularTimePeriod) year32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year30.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year30, (double) 1560182842702L);
        timeSeries14.setKey((java.lang.Comparable) 1560182842702L);
        timeSeries14.setMaximumItemAge(1560182868197L);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year45, (double) (-1.0f));
        timeSeries44.add(timeSeriesDataItem47);
        timeSeries44.setNotify(true);
        timeSeries44.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year55, (double) (-1.0f));
        timeSeries54.add(timeSeriesDataItem57);
        timeSeries54.setNotify(true);
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        java.util.Date date62 = year61.getEnd();
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        java.util.Date date64 = year63.getEnd();
        boolean boolean66 = year63.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries54.createCopy((org.jfree.data.time.RegularTimePeriod) year61, (org.jfree.data.time.RegularTimePeriod) year63);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = year61.next();
        int int70 = year61.compareTo((java.lang.Object) 6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year61, (double) (short) -1);
        timeSeries14.update((org.jfree.data.time.RegularTimePeriod) year61, (java.lang.Number) 1560182855376L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(timeSeries67);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem72);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries1.getNextTimePeriod();
        java.lang.String str15 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getEnd();
        boolean boolean19 = year16.equals((java.lang.Object) 100);
        java.util.Date date20 = year16.getEnd();
        java.lang.Number number21 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, number21);
        try {
            timeSeries1.delete(5, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
//        timeSeries1.add(timeSeriesDataItem4);
//        boolean boolean6 = timeSeries1.getNotify();
//        timeSeries1.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        long long10 = fixedMillisecond9.getMiddleMillisecond();
//        long long11 = fixedMillisecond9.getSerialIndex();
//        java.util.Calendar calendar12 = null;
//        fixedMillisecond9.peg(calendar12);
//        boolean boolean15 = fixedMillisecond9.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, 0.0d);
//        java.lang.Number number18 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, number18);
//        boolean boolean21 = fixedMillisecond9.equals((java.lang.Object) 9);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560182889740L + "'", long10 == 1560182889740L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182889740L + "'", long11 == 1560182889740L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.util.Date date6 = regularTimePeriod5.getStart();
        timeSeries1.delete(regularTimePeriod5);
        double double8 = timeSeries1.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (double) (-1.0f));
        timeSeries10.add(timeSeriesDataItem13);
        timeSeries10.setNotify(true);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.util.Date date20 = year19.getEnd();
        boolean boolean22 = year19.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year17.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) 1560182842702L);
        java.lang.Object obj27 = timeSeriesDataItem26.clone();
        timeSeries1.add(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "", "31-December-2019");
        double double4 = timeSeries3.getMinY();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeries3.getTimePeriod((-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -9999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod3, (java.lang.Number) 9);
        timeSeriesDataItem5.setSelected(false);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.lang.Class<?> wildcardClass9 = fixedMillisecond0.getClass();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond0.getLastMillisecond(calendar10);
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond0.getMiddleMillisecond(calendar12);
//        java.util.Date date14 = fixedMillisecond0.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond0.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182890007L + "'", long1 == 1560182890007L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182890007L + "'", long2 == 1560182890007L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182890007L + "'", long11 == 1560182890007L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182890007L + "'", long13 == 1560182890007L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        timeSeries1.removeAgedItems((long) 11, false);
        java.util.Collection collection23 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(collection23);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        int int4 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
        double double13 = timeSeries1.getMaxY();
        timeSeries1.setDescription("Value");
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date3 = fixedMillisecond0.getStart();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
//        java.lang.String str6 = month5.toString();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = month5.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182890237L + "'", long1 == 1560182890237L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182890237L + "'", long2 == 1560182890237L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
        java.lang.String str13 = timeSeries12.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener14);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
//        timeSeries1.add(timeSeriesDataItem4);
//        timeSeries1.setNotify(true);
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        java.util.Date date9 = year8.getEnd();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        java.util.Date date11 = year10.getEnd();
//        boolean boolean13 = year10.equals((java.lang.Object) 100);
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
//        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timeSeries21.removePropertyChangeListener(propertyChangeListener22);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (double) (-1.0f));
//        timeSeries25.add(timeSeriesDataItem28);
//        timeSeries25.setNotify(true);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        java.util.Date date33 = year32.getEnd();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        java.util.Date date35 = year34.getEnd();
//        boolean boolean37 = year34.equals((java.lang.Object) 100);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) year34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year32.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year32, (double) 1.0f);
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) 10.0d);
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        timeSeries45.setMaximumItemAge((long) 'a');
//        boolean boolean48 = year32.equals((java.lang.Object) 'a');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        long long50 = fixedMillisecond49.getMiddleMillisecond();
//        long long51 = fixedMillisecond49.getSerialIndex();
//        java.util.Date date52 = fixedMillisecond49.getStart();
//        int int53 = year32.compareTo((java.lang.Object) date52);
//        java.util.TimeZone timeZone54 = null;
//        try {
//            org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date52, timeZone54);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560182890520L + "'", long50 == 1560182890520L);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560182890520L + "'", long51 == 1560182890520L);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries1.getNextTimePeriod();
        timeSeries1.removeAgedItems(true);
        long long17 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries1.getNextTimePeriod();
        java.lang.String str15 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getEnd();
        boolean boolean19 = year16.equals((java.lang.Object) 100);
        java.util.Date date20 = year16.getEnd();
        java.lang.Number number21 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, number21);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = year16.getLastMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.util.Date date6 = regularTimePeriod5.getStart();
        timeSeries1.delete(regularTimePeriod5);
        double double8 = timeSeries1.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (double) (-1.0f));
        timeSeries10.add(timeSeriesDataItem13);
        timeSeries10.setNotify(true);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.util.Date date20 = year19.getEnd();
        boolean boolean22 = year19.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year19);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getEnd();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month26);
        org.jfree.data.time.Year year29 = month26.getYear();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) 1560182842664L);
        java.lang.String str32 = year29.toString();
        java.lang.String str33 = year29.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(year29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2019" + "'", str33.equals("2019"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date12 = fixedMillisecond11.getTime();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) (-1));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        java.lang.Number number7 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year4);
        java.util.Calendar calendar8 = null;
        try {
            year4.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean20 = timeSeries14.isEmpty();
        timeSeries14.clear();
        boolean boolean22 = timeSeries14.isEmpty();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries14.removeChangeListener(seriesChangeListener23);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries14.addChangeListener(seriesChangeListener25);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.lang.Class<?> wildcardClass9 = fixedMillisecond0.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.util.Date date11 = null;
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182893814L + "'", long1 == 1560182893814L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182893814L + "'", long2 == 1560182893814L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(class14);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "org.jfree.data.general.SeriesException: hi!", "2019");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        long long6 = month5.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month5.next();
        java.lang.Number number8 = timeSeries3.getValue(regularTimePeriod7);
        try {
            java.lang.Number number10 = timeSeries3.getValue(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(number8);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1560182854921L);
//        java.lang.Object obj6 = timeSeriesDataItem5.clone();
//        boolean boolean7 = timeSeriesDataItem5.isSelected();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182893883L + "'", long2 == 1560182893883L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = null;
        try {
            timeSeries14.add(timeSeriesDataItem15, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "org.jfree.data.general.SeriesException: hi!", "2019");
        long long4 = timeSeries3.getMaximumItemAge();
        java.lang.Object obj5 = timeSeries3.clone();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        int int10 = month8.getMonth();
        long long11 = month8.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) (-1.0f));
        java.lang.Object obj14 = timeSeriesDataItem13.clone();
        timeSeries3.add(timeSeriesDataItem13, false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1576526399999L + "'", long11 == 1576526399999L);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date4 = fixedMillisecond3.getTime();
        boolean boolean5 = fixedMillisecond1.equals((java.lang.Object) date4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.next();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (double) 1560182842702L);
        java.lang.Object obj18 = timeSeriesDataItem17.clone();
        timeSeriesDataItem17.setSelected(true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 100);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (double) (-1.0f));
        timeSeries17.add(timeSeriesDataItem20);
        timeSeries17.setNotify(true);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getEnd();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        java.util.Date date27 = year26.getEnd();
        boolean boolean29 = year26.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) year24, (org.jfree.data.time.RegularTimePeriod) year26);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries32.removePropertyChangeListener(propertyChangeListener33);
        java.util.Collection collection35 = timeSeries30.getTimePeriodsUniqueToOtherSeries(timeSeries32);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries37.removePropertyChangeListener(propertyChangeListener38);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year42, (double) (-1.0f));
        timeSeries41.add(timeSeriesDataItem44);
        timeSeries41.setNotify(true);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        java.util.Date date49 = year48.getEnd();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        java.util.Date date51 = year50.getEnd();
        boolean boolean53 = year50.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries41.createCopy((org.jfree.data.time.RegularTimePeriod) year48, (org.jfree.data.time.RegularTimePeriod) year50);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year48.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year48, (double) 1.0f);
        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) 10.0d);
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year62, (double) (-1.0f));
        timeSeries61.add(timeSeriesDataItem64);
        timeSeries61.setNotify(true);
        timeSeries61.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year72, (double) (-1.0f));
        timeSeries71.add(timeSeriesDataItem74);
        timeSeries71.setNotify(true);
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        java.util.Date date79 = year78.getEnd();
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year();
        java.util.Date date81 = year80.getEnd();
        boolean boolean83 = year80.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries84 = timeSeries71.createCopy((org.jfree.data.time.RegularTimePeriod) year78, (org.jfree.data.time.RegularTimePeriod) year80);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = year78.next();
        int int87 = year78.compareTo((java.lang.Object) 6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem89 = timeSeries61.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year78, (double) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries90 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year48, (org.jfree.data.time.RegularTimePeriod) year78);
        long long91 = year78.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(timeSeries84);
        org.junit.Assert.assertNotNull(regularTimePeriod85);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem89);
        org.junit.Assert.assertNotNull(timeSeries90);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 2019L + "'", long91 == 2019L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        int int10 = timeSeriesDataItem4.compareTo((java.lang.Object) month8);
        boolean boolean12 = timeSeriesDataItem4.equals((java.lang.Object) 1560182851041L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        timeSeries1.setMaximumItemCount(0);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (byte) -1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) month10);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year7.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(timeSeries12);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 0, 3, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'day' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1560182847497L);
//        long long6 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.previous();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182895540L + "'", long2 == 1560182895540L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182895540L + "'", long6 == 1560182895540L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) 1.0d);
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        long long5 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Date date6 = fixedMillisecond0.getStart();
//        java.util.TimeZone timeZone7 = null;
//        try {
//            org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182895560L + "'", long1 == 1560182895560L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560182895560L + "'", long5 == 1560182895560L);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date4 = fixedMillisecond3.getTime();
        boolean boolean5 = fixedMillisecond1.equals((java.lang.Object) date4);
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date4, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date1, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        java.lang.String str4 = month2.toString();
        long long5 = month2.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "December 2019" + "'", str3.equals("December 2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "December 2019" + "'", str4.equals("December 2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1575187200000L + "'", long5 == 1575187200000L);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        timeSeries1.setMaximumItemCount(0);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (byte) -1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = month10.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        try {
            timeSeries1.update((int) (byte) 100, (java.lang.Number) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        boolean boolean17 = year14.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener21);
        java.util.Collection collection23 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        boolean boolean24 = timeSeries18.isEmpty();
        java.util.Collection collection25 = timeSeries18.getTimePeriods();
        java.lang.String str26 = timeSeries18.getDomainDescription();
        int int27 = day3.compareTo((java.lang.Object) timeSeries18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date30 = fixedMillisecond29.getTime();
        boolean boolean31 = day3.equals((java.lang.Object) date30);
        java.util.TimeZone timeZone32 = null;
        java.util.Locale locale33 = null;
        try {
            org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date30, timeZone32, locale33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        int int4 = month2.getMonth();
        int int5 = month2.getMonth();
        long long6 = month2.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (double) (-1.0f));
        timeSeries8.add(timeSeriesDataItem11);
        timeSeries8.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (-1.0f));
        timeSeries16.add(timeSeriesDataItem19);
        timeSeries16.setNotify(true);
        timeSeries16.setNotify(true);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.previous();
        timeSeries16.update((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 100);
        java.lang.Number number30 = null;
        timeSeries16.update((int) (short) 0, number30);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries8.addAndOrUpdate(timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year35, (double) (-1.0f));
        timeSeries34.add(timeSeriesDataItem37);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        java.util.Date date40 = year39.getEnd();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.previous();
        int int43 = timeSeriesDataItem37.compareTo((java.lang.Object) month41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month41.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) month41);
        boolean boolean46 = month2.equals((java.lang.Object) timeSeries16);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(timeSeriesDataItem45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        long long5 = month4.getLastMillisecond();
        org.jfree.data.time.Year year6 = month4.getYear();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year6, (double) 1560182851670L, false);
        java.lang.Class class10 = timeSeries1.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(class10);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date3 = fixedMillisecond0.getStart();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        java.util.Date date6 = year5.getEnd();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "hi!", "");
//        int int11 = year4.compareTo((java.lang.Object) timeSeries10);
//        timeSeries10.setDescription("Mon Jun 10 09:07:29 PDT 2019");
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182896836L + "'", long1 == 1560182896836L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182896836L + "'", long2 == 1560182896836L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43830L + "'", long4 == 43830L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        boolean boolean15 = year12.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) 1560182842702L);
        java.lang.Object obj20 = timeSeriesDataItem19.clone();
        timeSeries1.add(timeSeriesDataItem19, false);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries24.setDomainDescription("hi!");
        timeSeries24.setMaximumItemCount(0);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year((int) (byte) -1);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        java.util.Date date32 = year31.getEnd();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month33.previous();
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) year30, (org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year30, (java.lang.Number) 1560182873327L, false);
        int int39 = year30.getYear();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
//        timeSeries1.add(timeSeriesDataItem4);
//        timeSeries1.setNotify(true);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
//        timeSeries11.add(timeSeriesDataItem14);
//        timeSeries11.setNotify(true);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        java.util.Date date19 = year18.getEnd();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        java.util.Date date21 = year20.getEnd();
//        boolean boolean23 = year20.equals((java.lang.Object) 100);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) year20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year18.next();
//        int int27 = year18.compareTo((java.lang.Object) 6);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (double) (short) -1);
//        timeSeries1.setMaximumItemCount((int) '#');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        long long33 = fixedMillisecond32.getMiddleMillisecond();
//        long long34 = fixedMillisecond32.getSerialIndex();
//        java.util.Date date35 = fixedMillisecond32.getStart();
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
//        int int37 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year36);
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.previous();
//        java.util.Date date40 = regularTimePeriod39.getStart();
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date40);
//        long long42 = year41.getLastMillisecond();
//        int int43 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year41);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560182897267L + "'", long33 == 1560182897267L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560182897267L + "'", long34 == 1560182897267L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1546329599999L + "'", long42 == 1546329599999L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        long long3 = year0.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            year0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (-1.0f));
        timeSeries9.add(timeSeriesDataItem12);
        timeSeries9.setNotify(true);
        timeSeries9.setNotify(true);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        timeSeries9.update((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 100);
        java.lang.Number number23 = null;
        timeSeries9.update((int) (short) 0, number23);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries1.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year28, (double) (-1.0f));
        timeSeries27.add(timeSeriesDataItem30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.util.Date date33 = year32.getEnd();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month34.previous();
        int int36 = timeSeriesDataItem30.compareTo((java.lang.Object) month34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month34.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month34);
        timeSeriesDataItem38.setValue((java.lang.Number) 1.0f);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(timeSeriesDataItem38);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.lang.Class<?> wildcardClass9 = fixedMillisecond0.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        long long11 = fixedMillisecond10.getMiddleMillisecond();
//        long long12 = fixedMillisecond10.getSerialIndex();
//        java.util.Calendar calendar13 = null;
//        fixedMillisecond10.peg(calendar13);
//        boolean boolean16 = fixedMillisecond10.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, 0.0d);
//        java.lang.Class<?> wildcardClass19 = fixedMillisecond10.getClass();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        long long22 = fixedMillisecond21.getMiddleMillisecond();
//        long long23 = fixedMillisecond21.getSerialIndex();
//        java.util.Date date24 = fixedMillisecond21.getStart();
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date24, timeZone25);
//        java.util.TimeZone timeZone27 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date24, timeZone27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date24);
//        java.util.TimeZone timeZone30 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date24, timeZone30);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182897848L + "'", long1 == 1560182897848L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182897848L + "'", long2 == 1560182897848L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182897850L + "'", long11 == 1560182897850L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560182897850L + "'", long12 == 1560182897850L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560182897851L + "'", long22 == 1560182897851L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560182897851L + "'", long23 == 1560182897851L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 100);
        timeSeries1.setDomainDescription("hi!");
        int int16 = timeSeries1.getMaximumItemCount();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries1.getDataItem((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (-1.0f));
        timeSeries9.add(timeSeriesDataItem12);
        timeSeries9.setNotify(true);
        timeSeries9.setNotify(true);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        timeSeries9.update((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 100);
        java.lang.Number number23 = null;
        timeSeries9.update((int) (short) 0, number23);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries1.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year30, (double) (-1.0f));
        timeSeries29.add(timeSeriesDataItem32);
        timeSeries29.setNotify(true);
        timeSeries29.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries27.addAndOrUpdate(timeSeries29);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
        timeSeries38.removeChangeListener(seriesChangeListener39);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries25.addAndOrUpdate(timeSeries38);
        int int42 = timeSeries25.getItemCount();
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean20 = timeSeries14.isEmpty();
        java.util.Collection collection21 = timeSeries14.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries23.setDomainDescription("hi!");
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.previous();
        java.util.Date date28 = regularTimePeriod27.getStart();
        timeSeries23.delete(regularTimePeriod27);
        double double30 = timeSeries23.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (-1.0f));
        timeSeries32.add(timeSeriesDataItem35);
        timeSeries32.setNotify(true);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        java.util.Date date40 = year39.getEnd();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        java.util.Date date42 = year41.getEnd();
        boolean boolean44 = year41.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) year39, (org.jfree.data.time.RegularTimePeriod) year41);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        java.util.Date date47 = year46.getEnd();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month48.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) month48);
        org.jfree.data.time.Year year51 = month48.getYear();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) year51, (java.lang.Number) 1560182842664L);
        java.util.Collection collection54 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year57, (double) (-1.0f));
        timeSeries56.add(timeSeriesDataItem59);
        timeSeries56.setNotify(true);
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        java.util.Date date64 = year63.getEnd();
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year();
        java.util.Date date66 = year65.getEnd();
        boolean boolean68 = year65.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries56.createCopy((org.jfree.data.time.RegularTimePeriod) year63, (org.jfree.data.time.RegularTimePeriod) year65);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = year63.next();
        int int72 = year63.compareTo((java.lang.Object) 6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year63, (double) 1L);
        java.lang.Number number75 = timeSeriesDataItem74.getValue();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(timeSeriesDataItem50);
        org.junit.Assert.assertNotNull(year51);
        org.junit.Assert.assertNotNull(collection54);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(timeSeries69);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem74);
        org.junit.Assert.assertTrue("'" + number75 + "' != '" + 1560182842664L + "'", number75.equals(1560182842664L));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        boolean boolean3 = year0.equals((java.lang.Object) 100);
        java.util.Date date4 = year0.getEnd();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) date4);
        java.lang.String str6 = seriesChangeEvent5.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=Tue Dec 31 23:59:59 PST 2019]" + "'", str6.equals("org.jfree.data.event.SeriesChangeEvent[source=Tue Dec 31 23:59:59 PST 2019]"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        int int4 = month2.getMonth();
        long long5 = month2.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            month2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1575187200000L + "'", long5 == 1575187200000L);
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.lang.Class<?> wildcardClass9 = fixedMillisecond0.getClass();
//        java.util.Date date10 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        long long12 = fixedMillisecond11.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182900621L + "'", long1 == 1560182900621L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182900621L + "'", long2 == 1560182900621L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560182900621L + "'", long12 == 1560182900621L);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        java.lang.String str20 = timeSeries1.getDescription();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries1.getNextTimePeriod();
        timeSeries1.setDomainDescription("hi!");
        timeSeries1.setDescription("2019");
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        boolean boolean3 = year0.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "2019", "Value");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        long long9 = timeSeries6.getMaximumItemAge();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries1.getNextTimePeriod();
        timeSeries1.setDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) (-1.0f));
        timeSeries18.add(timeSeriesDataItem21);
        timeSeries18.setNotify(true);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        java.util.Date date26 = year25.getEnd();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.util.Date date28 = year27.getEnd();
        boolean boolean30 = year27.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) year25, (org.jfree.data.time.RegularTimePeriod) year27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year25.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) 1560182842702L);
        java.lang.Object obj35 = timeSeriesDataItem34.clone();
        timeSeriesDataItem34.setSelected(false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries1.addOrUpdate(timeSeriesDataItem34);
        java.lang.Object obj39 = null;
        boolean boolean40 = timeSeriesDataItem38.equals(obj39);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNotNull(timeSeriesDataItem38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        timeSeries1.setMaximumItemCount(0);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (byte) -1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) month10);
        double double13 = timeSeries1.getMinY();
        java.lang.Class class14 = timeSeries1.getTimePeriodClass();
        java.util.List list15 = timeSeries1.getItems();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (-1.0f));
        timeSeries9.add(timeSeriesDataItem12);
        timeSeries9.setNotify(true);
        timeSeries9.setNotify(true);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        timeSeries9.update((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 100);
        java.lang.Number number23 = null;
        timeSeries9.update((int) (short) 0, number23);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries1.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year28, (double) (-1.0f));
        timeSeries27.add(timeSeriesDataItem30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.util.Date date33 = year32.getEnd();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month34.previous();
        int int36 = timeSeriesDataItem30.compareTo((java.lang.Object) month34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month34.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month34);
        long long39 = month34.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(timeSeriesDataItem38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1575187200000L + "'", long39 == 1575187200000L);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        timeSeries12.removeAgedItems(1560182842984L, false);
        timeSeries12.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year22, (double) (-1.0f));
        timeSeries21.add(timeSeriesDataItem24);
        timeSeries21.setNotify(true);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.util.Date date29 = year28.getEnd();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        java.util.Date date31 = year30.getEnd();
        boolean boolean33 = year30.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) year28, (org.jfree.data.time.RegularTimePeriod) year30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year28.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year28, (double) 1560182842702L);
        java.lang.Object obj38 = timeSeriesDataItem37.clone();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries12.addOrUpdate(timeSeriesDataItem37);
        try {
            timeSeries12.delete(7, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean20 = timeSeries14.isEmpty();
        java.util.Collection collection21 = timeSeries14.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries23.setDomainDescription("hi!");
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.previous();
        java.util.Date date28 = regularTimePeriod27.getStart();
        timeSeries23.delete(regularTimePeriod27);
        double double30 = timeSeries23.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (-1.0f));
        timeSeries32.add(timeSeriesDataItem35);
        timeSeries32.setNotify(true);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        java.util.Date date40 = year39.getEnd();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        java.util.Date date42 = year41.getEnd();
        boolean boolean44 = year41.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) year39, (org.jfree.data.time.RegularTimePeriod) year41);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        java.util.Date date47 = year46.getEnd();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month48.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) month48);
        org.jfree.data.time.Year year51 = month48.getYear();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) year51, (java.lang.Number) 1560182842664L);
        java.util.Collection collection54 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year57, (double) (-1.0f));
        timeSeries56.add(timeSeriesDataItem59);
        timeSeries56.setNotify(true);
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        java.util.Date date64 = year63.getEnd();
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year();
        java.util.Date date66 = year65.getEnd();
        boolean boolean68 = year65.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries56.createCopy((org.jfree.data.time.RegularTimePeriod) year63, (org.jfree.data.time.RegularTimePeriod) year65);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = year63.next();
        int int72 = year63.compareTo((java.lang.Object) 6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year63, (double) 1L);
        java.lang.Class class75 = timeSeries23.getTimePeriodClass();
        java.lang.Object obj76 = timeSeries23.clone();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(timeSeriesDataItem50);
        org.junit.Assert.assertNotNull(year51);
        org.junit.Assert.assertNotNull(collection54);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(timeSeries69);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem74);
        org.junit.Assert.assertNotNull(class75);
        org.junit.Assert.assertNotNull(obj76);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.util.Date date6 = regularTimePeriod5.getStart();
        timeSeries1.delete(regularTimePeriod5);
        double double8 = timeSeries1.getMaxY();
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "", "31-December-2019");
        double double16 = timeSeries15.getMinY();
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        long long19 = month18.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.next();
        long long21 = month18.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (double) 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561964399999L + "'", long21 == 1561964399999L);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        java.beans.PropertyChangeListener propertyChangeListener2 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getMiddleMillisecond();
//        int int7 = fixedMillisecond4.compareTo((java.lang.Object) 1560182842664L);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (-1.0f));
//        timeSeries9.add(timeSeriesDataItem12);
//        timeSeries9.setNotify(true);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        java.util.Date date17 = year16.getEnd();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        java.util.Date date19 = year18.getEnd();
//        boolean boolean21 = year18.equals((java.lang.Object) 100);
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year18);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        java.beans.PropertyChangeListener propertyChangeListener25 = null;
//        timeSeries24.removePropertyChangeListener(propertyChangeListener25);
//        java.util.Collection collection27 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries24);
//        java.util.List list28 = timeSeries24.getItems();
//        int int29 = fixedMillisecond4.compareTo((java.lang.Object) list28);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 1560182844817L);
//        try {
//            timeSeries1.delete((int) (byte) 10, 8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560182904056L + "'", long5 == 1560182904056L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertNotNull(collection27);
//        org.junit.Assert.assertNotNull(list28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1560182847497L);
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod9, (java.lang.Number) 9);
//        int int12 = timeSeriesDataItem5.compareTo((java.lang.Object) 9);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182904191L + "'", long2 == 1560182904191L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560182895540L);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "");
        java.lang.Object obj6 = null;
        boolean boolean7 = month2.equals(obj6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        timeSeries4.add(timeSeriesDataItem7);
        timeSeries4.setNotify(true);
        timeSeries4.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries2.addAndOrUpdate(timeSeries4);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year((int) (byte) -1);
        java.lang.Number number16 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year15);
        java.lang.String str17 = timeSeries2.getDescription();
        boolean boolean18 = day0.equals((java.lang.Object) timeSeries2);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        boolean boolean17 = year14.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener21);
        java.util.Collection collection23 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        boolean boolean24 = timeSeries18.isEmpty();
        java.util.Collection collection25 = timeSeries18.getTimePeriods();
        java.lang.String str26 = timeSeries18.getDomainDescription();
        int int27 = day3.compareTo((java.lang.Object) timeSeries18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date30 = fixedMillisecond29.getTime();
        boolean boolean31 = day3.equals((java.lang.Object) date30);
        long long32 = day3.getFirstMillisecond();
        java.util.Calendar calendar33 = null;
        try {
            long long34 = day3.getLastMillisecond(calendar33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577779200000L + "'", long32 == 1577779200000L);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        long long4 = day3.getLastMillisecond();
        long long5 = day3.getSerialIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43830L + "'", long5 == 43830L);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
        java.lang.String str13 = timeSeries12.getRangeDescription();
        timeSeries12.clear();
        boolean boolean15 = timeSeries12.getNotify();
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str5 = seriesException4.toString();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str5.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Mon Jun 10 09:07:29 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        timeSeries1.setDomainDescription("hi!");
//        timeSeries1.setMaximumItemCount(0);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (byte) -1);
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        java.util.Date date9 = year8.getEnd();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) month10);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, (double) (-1.0f));
//        timeSeries14.add(timeSeriesDataItem17);
//        timeSeries14.setNotify(true);
//        timeSeries14.setNotify(true);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
//        timeSeries14.update((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries14.getNextTimePeriod();
//        java.lang.String str28 = timeSeries14.getDomainDescription();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        java.util.Date date30 = year29.getEnd();
//        boolean boolean32 = year29.equals((java.lang.Object) 100);
//        java.util.Date date33 = year29.getEnd();
//        java.lang.Number number34 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year29, number34);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) 1560182868197L, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        long long40 = fixedMillisecond39.getMiddleMillisecond();
//        long long41 = fixedMillisecond39.getSerialIndex();
//        java.util.Calendar calendar42 = null;
//        fixedMillisecond39.peg(calendar42);
//        boolean boolean45 = fixedMillisecond39.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, 0.0d);
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 1560182847497L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Time" + "'", str28.equals("Time"));
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem35);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560182905879L + "'", long40 == 1560182905879L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560182905879L + "'", long41 == 1560182905879L);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod7, (java.lang.Number) 9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod7, (java.lang.Number) 10.0f);
        boolean boolean12 = fixedMillisecond3.equals((java.lang.Object) timeSeriesDataItem11);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond3.getLastMillisecond(calendar13);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "org.jfree.data.general.SeriesException: hi!", "2019");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, (double) (-1.0f));
        timeSeries13.add(timeSeriesDataItem16);
        timeSeries13.setNotify(true);
        timeSeries13.setNotify(true);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.previous();
        timeSeries13.update((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 100);
        java.lang.Number number27 = null;
        timeSeries13.update((int) (short) 0, number27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries5.addAndOrUpdate(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year32, (double) (-1.0f));
        timeSeries31.add(timeSeriesDataItem34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        java.util.Date date37 = year36.getEnd();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month38.previous();
        int int40 = timeSeriesDataItem34.compareTo((java.lang.Object) month38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month38.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) month38);
        timeSeries3.add(timeSeriesDataItem42, false);
        double double45 = timeSeries3.getMaxY();
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem42);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        boolean boolean6 = timeSeriesDataItem4.isSelected();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        boolean boolean17 = year14.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener21);
        java.util.Collection collection23 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        boolean boolean24 = timeSeries18.isEmpty();
        java.util.Collection collection25 = timeSeries18.getTimePeriods();
        java.lang.String str26 = timeSeries18.getDomainDescription();
        int int27 = day3.compareTo((java.lang.Object) timeSeries18);
        org.jfree.data.time.SerialDate serialDate28 = day3.getSerialDate();
        int int30 = day3.compareTo((java.lang.Object) 100.0f);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        java.util.Date date32 = year31.getEnd();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        boolean boolean34 = day3.equals((java.lang.Object) date32);
        java.lang.String str35 = day3.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "31-December-2019" + "'", str35.equals("31-December-2019"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
        java.lang.String str13 = timeSeries12.getRangeDescription();
        timeSeries12.setDescription("hi!");
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        boolean boolean3 = year0.equals((java.lang.Object) 100);
        java.util.Date date4 = year0.getEnd();
        long long5 = year0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond0.previous();
//        java.lang.Object obj4 = null;
//        int int5 = fixedMillisecond0.compareTo(obj4);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182906880L + "'", long1 == 1560182906880L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182906880L + "'", long2 == 1560182906880L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        long long2 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean20 = timeSeries14.isEmpty();
        java.util.Collection collection21 = timeSeries14.getTimePeriods();
        java.lang.String str22 = timeSeries14.getDomainDescription();
        try {
            timeSeries14.update(4, (java.lang.Number) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Time" + "'", str22.equals("Time"));
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.util.Date date1 = year0.getEnd();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
//        timeSeries5.add(timeSeriesDataItem8);
//        timeSeries5.setNotify(true);
//        timeSeries5.setNotify(true);
//        timeSeries5.setKey((java.lang.Comparable) 1.0f);
//        boolean boolean16 = day3.equals((java.lang.Object) timeSeries5);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        timeSeries18.setDomainDescription("hi!");
//        timeSeries18.setMaximumItemCount(0);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (byte) -1);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        java.util.Date date26 = year25.getEnd();
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month27.previous();
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) year24, (org.jfree.data.time.RegularTimePeriod) month27);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener30 = null;
//        timeSeries18.removeChangeListener(seriesChangeListener30);
//        boolean boolean32 = day3.equals((java.lang.Object) timeSeries18);
//        java.beans.PropertyChangeListener propertyChangeListener33 = null;
//        timeSeries18.removePropertyChangeListener(propertyChangeListener33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        long long36 = fixedMillisecond35.getMiddleMillisecond();
//        boolean boolean38 = fixedMillisecond35.equals((java.lang.Object) 1.0d);
//        java.util.Date date39 = fixedMillisecond35.getTime();
//        long long40 = fixedMillisecond35.getFirstMillisecond();
//        java.util.Date date41 = fixedMillisecond35.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (double) 1560182854594L);
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year46, (double) (-1.0f));
//        timeSeries45.add(timeSeriesDataItem48);
//        timeSeries45.setNotify(true);
//        timeSeries45.setNotify(false);
//        java.util.Collection collection54 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries45);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560182906984L + "'", long36 == 1560182906984L);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560182906984L + "'", long40 == 1560182906984L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//        org.junit.Assert.assertNotNull(collection54);
//    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        long long2 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182907811L + "'", long2 == 1560182907811L);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = null;
        try {
            timeSeries14.add(timeSeriesDataItem20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        long long6 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
        timeSeries12.setDomainDescription("Mon Jun 10 09:07:29 PDT 2019");
        timeSeries12.setDomainDescription("org.jfree.data.event.SeriesChangeEvent[source=Tue Dec 31 23:59:59 PST 2019]");
        org.junit.Assert.assertNotNull(timeSeries12);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        java.beans.PropertyChangeListener propertyChangeListener2 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getMiddleMillisecond();
//        int int7 = fixedMillisecond4.compareTo((java.lang.Object) 1560182842664L);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (-1.0f));
//        timeSeries9.add(timeSeriesDataItem12);
//        timeSeries9.setNotify(true);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        java.util.Date date17 = year16.getEnd();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        java.util.Date date19 = year18.getEnd();
//        boolean boolean21 = year18.equals((java.lang.Object) 100);
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year18);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        java.beans.PropertyChangeListener propertyChangeListener25 = null;
//        timeSeries24.removePropertyChangeListener(propertyChangeListener25);
//        java.util.Collection collection27 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries24);
//        java.util.List list28 = timeSeries24.getItems();
//        int int29 = fixedMillisecond4.compareTo((java.lang.Object) list28);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 1560182844817L);
//        timeSeries1.fireSeriesChanged();
//        long long33 = timeSeries1.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560182907959L + "'", long5 == 1560182907959L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertNotNull(collection27);
//        org.junit.Assert.assertNotNull(list28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        boolean boolean3 = year0.equals((java.lang.Object) 100);
        java.util.Date date4 = year0.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (double) (-1.0f));
        timeSeries8.add(timeSeriesDataItem11);
        timeSeries8.setNotify(true);
        timeSeries8.setRangeDescription("");
        boolean boolean17 = day6.equals((java.lang.Object) "");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test376");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) (byte) -1);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "Value", "hi!");
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries6.getDataItem((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182911266L + "'", long1 == 1560182911266L);
//    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            month0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
        timeSeries12.setDomainDescription("Mon Jun 10 09:07:29 PDT 2019");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries12.removeChangeListener(seriesChangeListener15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (-1.0f));
        timeSeriesDataItem19.setValue((java.lang.Number) 0);
        timeSeries12.add(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(timeSeries12);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        java.lang.Number number7 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year4);
        boolean boolean8 = timeSeries1.isEmpty();
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        boolean boolean17 = year14.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener21);
        java.util.Collection collection23 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        boolean boolean24 = timeSeries18.isEmpty();
        java.util.Collection collection25 = timeSeries18.getTimePeriods();
        java.lang.String str26 = timeSeries18.getDomainDescription();
        int int27 = day3.compareTo((java.lang.Object) timeSeries18);
        org.jfree.data.time.SerialDate serialDate28 = day3.getSerialDate();
        int int30 = day3.compareTo((java.lang.Object) 100.0f);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        java.util.Date date32 = year31.getEnd();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        boolean boolean34 = day3.equals((java.lang.Object) date32);
        java.util.Calendar calendar35 = null;
        try {
            long long36 = day3.getFirstMillisecond(calendar35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
//        timeSeries3.add(timeSeriesDataItem6);
//        timeSeries3.setNotify(true);
//        timeSeries3.setNotify(true);
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries12.removeChangeListener(seriesChangeListener13);
//        timeSeries12.removeAgedItems(1560182842984L, false);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year20, (double) (-1.0f));
//        timeSeries19.add(timeSeriesDataItem22);
//        timeSeries19.setNotify(true);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
//        java.util.Date date27 = year26.getEnd();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        java.util.Date date29 = year28.getEnd();
//        boolean boolean31 = year28.equals((java.lang.Object) 100);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) year26, (org.jfree.data.time.RegularTimePeriod) year28);
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        java.util.Date date34 = year33.getEnd();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month35.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries19.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
//        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) month35, (java.lang.Number) 10.0d, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        long long42 = fixedMillisecond41.getMiddleMillisecond();
//        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = fixedMillisecond41.next();
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560182911426L + "'", long42 == 1560182911426L);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        timeSeries1.setMaximumItemCount(0);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (byte) -1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) month10);
        java.lang.Class class13 = timeSeries1.getTimePeriodClass();
        java.lang.String str14 = timeSeries1.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (-1.0f));
        timeSeries16.add(timeSeriesDataItem19);
        timeSeries16.setNotify(true);
        timeSeries16.setNotify(true);
        java.lang.String str25 = timeSeries16.getDescription();
        java.util.Collection collection26 = timeSeries16.getTimePeriods();
        timeSeries16.setRangeDescription("31-December-2019");
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.addAndOrUpdate(timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries31.removePropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year34, (double) (-1.0f));
        java.lang.Number number37 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) 10.0f);
        java.lang.Class class40 = timeSeries1.getTimePeriodClass();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNull(number37);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(class40);
    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.lang.Class<?> wildcardClass9 = fixedMillisecond0.getClass();
//        java.util.Date date10 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        java.util.TimeZone timeZone12 = null;
//        try {
//            org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date10, timeZone12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182911926L + "'", long1 == 1560182911926L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182911926L + "'", long2 == 1560182911926L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(date10);
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        long long4 = day3.getSerialIndex();
        long long5 = day3.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43830L + "'", long4 == 43830L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1560182847497L);
//        long long6 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar7 = null;
//        fixedMillisecond0.peg(calendar7);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182911992L + "'", long2 == 1560182911992L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182911992L + "'", long6 == 1560182911992L);
//    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.lang.Class<?> wildcardClass9 = fixedMillisecond0.getClass();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        long long12 = fixedMillisecond11.getMiddleMillisecond();
//        long long13 = fixedMillisecond11.getSerialIndex();
//        java.util.Date date14 = fixedMillisecond11.getStart();
//        java.util.TimeZone timeZone15 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date14, timeZone15);
//        java.util.TimeZone timeZone17 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day19.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182912033L + "'", long1 == 1560182912033L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182912033L + "'", long2 == 1560182912033L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560182912034L + "'", long12 == 1560182912034L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182912034L + "'", long13 == 1560182912034L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        long long5 = month4.getLastMillisecond();
        org.jfree.data.time.Year year6 = month4.getYear();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year6, (double) 1560182851670L, false);
        long long10 = year6.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        java.lang.Object obj15 = timeSeries1.clone();
        java.lang.Class class16 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("Time");
        timeSeries1.setDomainDescription("org.jfree.data.general.SeriesException: hi!");
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(class16);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        long long20 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        boolean boolean17 = year14.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener21);
        java.util.Collection collection23 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        boolean boolean24 = timeSeries18.isEmpty();
        java.util.Collection collection25 = timeSeries18.getTimePeriods();
        java.lang.String str26 = timeSeries18.getDomainDescription();
        int int27 = day3.compareTo((java.lang.Object) timeSeries18);
        org.jfree.data.time.SerialDate serialDate28 = day3.getSerialDate();
        int int30 = day3.compareTo((java.lang.Object) 100.0f);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        java.util.Date date32 = year31.getEnd();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        boolean boolean34 = day3.equals((java.lang.Object) date32);
        boolean boolean36 = day3.equals((java.lang.Object) 1560182848978L);
        java.util.Calendar calendar37 = null;
        try {
            long long38 = day3.getLastMillisecond(calendar37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.lang.Class<?> wildcardClass9 = fixedMillisecond0.getClass();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        long long12 = fixedMillisecond11.getMiddleMillisecond();
//        long long13 = fixedMillisecond11.getSerialIndex();
//        java.util.Date date14 = fixedMillisecond11.getStart();
//        java.util.TimeZone timeZone15 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date14, timeZone15);
//        java.util.TimeZone timeZone17 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date14);
//        long long20 = day19.getMiddleMillisecond();
//        long long21 = day19.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182913703L + "'", long1 == 1560182913703L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182913703L + "'", long2 == 1560182913703L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560182913705L + "'", long12 == 1560182913705L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182913705L + "'", long13 == 1560182913705L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560193199999L + "'", long20 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43626L + "'", long21 == 43626L);
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        boolean boolean3 = year0.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "2019", "Value");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) (-1.0f));
        timeSeries6.setKey((java.lang.Comparable) (-1.0f));
        try {
            timeSeries6.update(10, (java.lang.Number) 1560182876970L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) collection19);
        java.lang.String str21 = seriesChangeEvent20.toString();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=[]]" + "'", str21.equals("org.jfree.data.event.SeriesChangeEvent[source=[]]"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "org.jfree.data.general.SeriesException: hi!", "2019");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, (double) (-1.0f));
        timeSeries13.add(timeSeriesDataItem16);
        timeSeries13.setNotify(true);
        timeSeries13.setNotify(true);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.previous();
        timeSeries13.update((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 100);
        java.lang.Number number27 = null;
        timeSeries13.update((int) (short) 0, number27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries5.addAndOrUpdate(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year32, (double) (-1.0f));
        timeSeries31.add(timeSeriesDataItem34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        java.util.Date date37 = year36.getEnd();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month38.previous();
        int int40 = timeSeriesDataItem34.compareTo((java.lang.Object) month38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month38.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) month38);
        timeSeries3.add(timeSeriesDataItem42, false);
        java.lang.String str45 = timeSeries3.getRangeDescription();
        try {
            org.jfree.data.time.TimeSeries timeSeries48 = timeSeries3.createCopy(0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "2019" + "'", str45.equals("2019"));
    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.lang.Class<?> wildcardClass9 = fixedMillisecond0.getClass();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond0.getFirstMillisecond(calendar10);
//        int int13 = fixedMillisecond0.compareTo((java.lang.Object) 1560182877356L);
//        long long14 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182915100L + "'", long1 == 1560182915100L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182915100L + "'", long2 == 1560182915100L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182915100L + "'", long11 == 1560182915100L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560182915100L + "'", long14 == 1560182915100L);
//    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        boolean boolean6 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount(0);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (double) (-1.0f));
        timeSeries10.add(timeSeriesDataItem13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.previous();
        int int19 = timeSeriesDataItem13.compareTo((java.lang.Object) month17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month17.next();
        int int21 = timeSeries1.getIndex(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        boolean boolean3 = year0.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "2019", "Value");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (double) (-1.0f));
        timeSeries12.add(timeSeriesDataItem15);
        timeSeries12.setNotify(true);
        timeSeries12.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries10.addAndOrUpdate(timeSeries12);
        double double22 = timeSeries10.getMaxY();
        boolean boolean23 = timeSeries6.equals((java.lang.Object) timeSeries10);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-1.0d) + "'", double22 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-9999), 9, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date4 = fixedMillisecond3.getTime();
        boolean boolean5 = fixedMillisecond1.equals((java.lang.Object) date4);
        long long6 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        timeSeries1.setMaximumItemCount(0);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (byte) -1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) month10);
        timeSeries1.removeAgedItems(false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(timeSeries12);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("31-December-2019");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.util.Date date1 = year0.getEnd();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
//        timeSeries5.add(timeSeriesDataItem8);
//        timeSeries5.setNotify(true);
//        timeSeries5.setNotify(true);
//        timeSeries5.setKey((java.lang.Comparable) 1.0f);
//        boolean boolean16 = day3.equals((java.lang.Object) timeSeries5);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        timeSeries18.setDomainDescription("hi!");
//        timeSeries18.setMaximumItemCount(0);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (byte) -1);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        java.util.Date date26 = year25.getEnd();
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month27.previous();
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) year24, (org.jfree.data.time.RegularTimePeriod) month27);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener30 = null;
//        timeSeries18.removeChangeListener(seriesChangeListener30);
//        boolean boolean32 = day3.equals((java.lang.Object) timeSeries18);
//        java.beans.PropertyChangeListener propertyChangeListener33 = null;
//        timeSeries18.removePropertyChangeListener(propertyChangeListener33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getFirstMillisecond(calendar36);
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond35.getMiddleMillisecond(calendar38);
//        java.lang.Number number40 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, number40);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560182915319L + "'", long37 == 1560182915319L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560182915319L + "'", long39 == 1560182915319L);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        boolean boolean3 = year0.equals((java.lang.Object) 100);
        java.util.Date date4 = year0.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        long long7 = day6.getSerialIndex();
        int int8 = day6.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43830L + "'", long7 == 43830L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        int int4 = month2.getMonth();
        long long5 = month2.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month2.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1576526399999L + "'", long5 == 1576526399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        long long9 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond0.getMiddleMillisecond(calendar10);
//        long long12 = fixedMillisecond0.getLastMillisecond();
//        java.util.Date date13 = fixedMillisecond0.getTime();
//        java.lang.String str14 = fixedMillisecond0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182916622L + "'", long1 == 1560182916622L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182916622L + "'", long2 == 1560182916622L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182916622L + "'", long9 == 1560182916622L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182916622L + "'", long11 == 1560182916622L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560182916622L + "'", long12 == 1560182916622L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Mon Jun 10 09:08:36 PDT 2019" + "'", str14.equals("Mon Jun 10 09:08:36 PDT 2019"));
//    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
//        timeSeries1.add(timeSeriesDataItem4);
//        timeSeries1.setNotify(true);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (-1.0f));
//        timeSeries9.add(timeSeriesDataItem12);
//        timeSeries9.setNotify(true);
//        timeSeries9.setNotify(true);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
//        timeSeries9.update((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 100);
//        java.lang.Number number23 = null;
//        timeSeries9.update((int) (short) 0, number23);
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries1.addAndOrUpdate(timeSeries9);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year30, (double) (-1.0f));
//        timeSeries29.add(timeSeriesDataItem32);
//        timeSeries29.setNotify(true);
//        timeSeries29.setNotify(true);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries27.addAndOrUpdate(timeSeries29);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries38.removeChangeListener(seriesChangeListener39);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries25.addAndOrUpdate(timeSeries38);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        long long43 = fixedMillisecond42.getMiddleMillisecond();
//        long long44 = fixedMillisecond42.getSerialIndex();
//        java.util.Date date45 = fixedMillisecond42.getStart();
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date45);
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date45);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date45);
//        int int49 = day48.getYear();
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
//        long long51 = month50.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = month50.next();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) day48, (org.jfree.data.time.RegularTimePeriod) month50);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560182916654L + "'", long43 == 1560182916654L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560182916654L + "'", long44 == 1560182916654L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1561964399999L + "'", long51 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(timeSeries53);
//    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        int int4 = timeSeries1.getItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date3 = fixedMillisecond0.getStart();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
//        java.util.TimeZone timeZone6 = null;
//        try {
//            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date3, timeZone6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182917563L + "'", long1 == 1560182917563L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182917563L + "'", long2 == 1560182917563L);
//        org.junit.Assert.assertNotNull(date3);
//    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1560182847497L);
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
//        java.lang.String str8 = year7.toString();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = year7.getLastMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182917603L + "'", long2 == 1560182917603L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        timeSeries1.setMaximumItemCount(0);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (byte) -1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        java.util.Calendar calendar14 = null;
        try {
            month10.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.util.Calendar calendar2 = null;
        try {
            month0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
//        java.util.Date date11 = regularTimePeriod10.getStart();
//        boolean boolean12 = fixedMillisecond0.equals((java.lang.Object) date11);
//        java.util.Calendar calendar13 = null;
//        fixedMillisecond0.peg(calendar13);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182917712L + "'", long1 == 1560182917712L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182917712L + "'", long2 == 1560182917712L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year((int) (byte) -1);
        java.lang.Number number15 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year14, "org.jfree.data.event.SeriesChangeEvent[source=Tue Dec 31 23:59:59 PST 2019]", "");
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNull(number15);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        timeSeries5.setNotify(true);
        timeSeries5.setKey((java.lang.Comparable) 1.0f);
        boolean boolean16 = day3.equals((java.lang.Object) timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries18.setDomainDescription("hi!");
        timeSeries18.setMaximumItemCount(0);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (byte) -1);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        java.util.Date date26 = year25.getEnd();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month27.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) year24, (org.jfree.data.time.RegularTimePeriod) month27);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries18.removeChangeListener(seriesChangeListener30);
        boolean boolean32 = day3.equals((java.lang.Object) timeSeries18);
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries18.removePropertyChangeListener(propertyChangeListener33);
        java.lang.Comparable comparable35 = timeSeries18.getKey();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + comparable35 + "' != '" + 1560182842943L + "'", comparable35.equals(1560182842943L));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        java.lang.String str2 = year1.toString();
        long long3 = year1.getLastMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
//        timeSeries1.add(timeSeriesDataItem4);
//        timeSeries1.setNotify(true);
//        timeSeries1.setNotify(true);
//        java.lang.String str10 = timeSeries1.getDescription();
//        java.util.Collection collection11 = timeSeries1.getTimePeriods();
//        timeSeries1.setRangeDescription("31-December-2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getMiddleMillisecond();
//        long long16 = fixedMillisecond14.getSerialIndex();
//        java.util.Date date17 = fixedMillisecond14.getStart();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        java.util.Date date20 = year19.getEnd();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month21, "hi!", "");
//        int int25 = year18.compareTo((java.lang.Object) timeSeries24);
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year18, (double) 1546329599999L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182918576L + "'", long15 == 1560182918576L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560182918576L + "'", long16 == 1560182918576L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        boolean boolean15 = year12.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) 1560182842702L);
        java.lang.Object obj20 = timeSeriesDataItem19.clone();
        timeSeries1.add(timeSeriesDataItem19, false);
        double double23 = timeSeries1.getMaxY();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getEnd();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year30, (double) (-1.0f));
        timeSeries29.add(timeSeriesDataItem32);
        timeSeries29.setNotify(true);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        java.util.Date date37 = year36.getEnd();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        java.util.Date date39 = year38.getEnd();
        boolean boolean41 = year38.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) year36, (org.jfree.data.time.RegularTimePeriod) year38);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener45 = null;
        timeSeries44.removePropertyChangeListener(propertyChangeListener45);
        java.util.Collection collection47 = timeSeries42.getTimePeriodsUniqueToOtherSeries(timeSeries44);
        boolean boolean48 = timeSeries42.isEmpty();
        java.util.Collection collection49 = timeSeries42.getTimePeriods();
        java.lang.String str50 = timeSeries42.getDomainDescription();
        int int51 = day27.compareTo((java.lang.Object) timeSeries42);
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year54, (double) (-1.0f));
        timeSeries53.add(timeSeriesDataItem56);
        timeSeries53.setNotify(true);
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        java.util.Date date61 = year60.getEnd();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        java.util.Date date63 = year62.getEnd();
        boolean boolean65 = year62.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries53.createCopy((org.jfree.data.time.RegularTimePeriod) year60, (org.jfree.data.time.RegularTimePeriod) year62);
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year();
        java.util.Date date68 = year67.getEnd();
        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month(date68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = month69.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = timeSeries53.getDataItem((org.jfree.data.time.RegularTimePeriod) month69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = timeSeriesDataItem71.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day27, regularTimePeriod72);
        long long74 = day27.getSerialIndex();
        long long75 = day27.getLastMillisecond();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.560182842702E12d + "'", double23 == 1.560182842702E12d);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertNotNull(collection47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(collection49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Time" + "'", str50.equals("Time"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(timeSeries66);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(timeSeriesDataItem71);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(timeSeries73);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 43830L + "'", long74 == 43830L);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1577865599999L + "'", long75 == 1577865599999L);
    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.lang.Class<?> wildcardClass9 = fixedMillisecond0.getClass();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond0.getLastMillisecond(calendar10);
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond0.getMiddleMillisecond(calendar12);
//        java.util.Date date14 = fixedMillisecond0.getTime();
//        java.util.Date date15 = fixedMillisecond0.getTime();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182919595L + "'", long1 == 1560182919595L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182919595L + "'", long2 == 1560182919595L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182919595L + "'", long11 == 1560182919595L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182919595L + "'", long13 == 1560182919595L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(date15);
//    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        timeSeries5.setNotify(true);
        timeSeries5.setKey((java.lang.Comparable) 1.0f);
        boolean boolean16 = day3.equals((java.lang.Object) timeSeries5);
        int int18 = day3.compareTo((java.lang.Object) 1560182865780L);
        java.util.Calendar calendar19 = null;
        try {
            long long20 = day3.getMiddleMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        timeSeries1.setMaximumItemCount(0);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (byte) -1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, (double) (-1.0f));
        timeSeries14.add(timeSeriesDataItem17);
        timeSeries14.setNotify(true);
        timeSeries14.setNotify(true);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        timeSeries14.update((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries14.getNextTimePeriod();
        java.lang.String str28 = timeSeries14.getDomainDescription();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        java.util.Date date30 = year29.getEnd();
        boolean boolean32 = year29.equals((java.lang.Object) 100);
        java.util.Date date33 = year29.getEnd();
        java.lang.Number number34 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year29, number34);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) 1560182868197L, true);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.previous();
        java.util.Date date41 = regularTimePeriod40.getStart();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date41);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year42, (java.lang.Number) 12);
        timeSeries1.setDescription("");
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Time" + "'", str28.equals("Time"));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1560182854921L);
//        boolean boolean6 = timeSeriesDataItem5.isSelected();
//        timeSeriesDataItem5.setValue((java.lang.Number) 1L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182920194L + "'", long2 == 1560182920194L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        timeSeries1.setMaximumItemCount(0);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (byte) -1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) month10);
        timeSeries12.fireSeriesChanged();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(timeSeries12);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 100);
        int int14 = year10.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        boolean boolean6 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (double) (-1.0f));
        timeSeries8.add(timeSeriesDataItem11);
        timeSeries8.setNotify(true);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getEnd();
        boolean boolean20 = year17.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) year15, (org.jfree.data.time.RegularTimePeriod) year17);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year15);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeSeries21);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = seriesChangeEvent1.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo3);
        org.junit.Assert.assertNull(seriesChangeInfo2);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (double) 1560182842702L);
        java.lang.Object obj18 = timeSeriesDataItem17.clone();
        timeSeriesDataItem17.setSelected(false);
        timeSeriesDataItem17.setValue((java.lang.Number) (short) 100);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        boolean boolean6 = timeSeries1.getNotify();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries1);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, (double) (-1.0f));
        timeSeries13.add(timeSeriesDataItem16);
        timeSeries13.setNotify(true);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.util.Date date23 = year22.getEnd();
        boolean boolean25 = year22.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year20.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, (double) 1.0f);
        int int31 = year20.compareTo((java.lang.Object) 0.0f);
        java.lang.Class<?> wildcardClass32 = year20.getClass();
        java.lang.Number number33 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (-1.0d) + "'", number33.equals((-1.0d)));
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
//        timeSeries3.add(timeSeriesDataItem6);
//        timeSeries3.setNotify(true);
//        timeSeries3.setNotify(true);
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries12.addChangeListener(seriesChangeListener13);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        java.util.Date date16 = year15.getEnd();
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (-1.0f));
//        timeSeries20.add(timeSeriesDataItem23);
//        timeSeries20.setNotify(true);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        java.util.Date date28 = year27.getEnd();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        java.util.Date date30 = year29.getEnd();
//        boolean boolean32 = year29.equals((java.lang.Object) 100);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) year27, (org.jfree.data.time.RegularTimePeriod) year29);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        java.beans.PropertyChangeListener propertyChangeListener36 = null;
//        timeSeries35.removePropertyChangeListener(propertyChangeListener36);
//        java.util.Collection collection38 = timeSeries33.getTimePeriodsUniqueToOtherSeries(timeSeries35);
//        boolean boolean39 = timeSeries33.isEmpty();
//        java.util.Collection collection40 = timeSeries33.getTimePeriods();
//        java.lang.String str41 = timeSeries33.getDomainDescription();
//        int int42 = day18.compareTo((java.lang.Object) timeSeries33);
//        org.jfree.data.time.SerialDate serialDate43 = day18.getSerialDate();
//        int int45 = day18.compareTo((java.lang.Object) 100.0f);
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
//        java.util.Date date47 = year46.getEnd();
//        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date47);
//        boolean boolean49 = day18.equals((java.lang.Object) date47);
//        int int50 = day18.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day18.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar53 = null;
//        long long54 = fixedMillisecond52.getFirstMillisecond(calendar53);
//        java.util.Date date55 = fixedMillisecond52.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (java.lang.Number) 1560182847497L);
//        java.util.Date date58 = fixedMillisecond52.getTime();
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) day18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
//        java.beans.PropertyChangeListener propertyChangeListener60 = null;
//        timeSeries12.removePropertyChangeListener(propertyChangeListener60);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertNotNull(collection38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(collection40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Time" + "'", str41.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2019 + "'", int50 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560182921969L + "'", long54 == 1560182921969L);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeSeries59);
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        boolean boolean3 = year0.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "2019", "Value");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) (-1.0f));
        timeSeries6.add(timeSeriesDataItem9, false);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        boolean boolean15 = year12.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) 1560182842702L);
        java.lang.Object obj20 = timeSeriesDataItem19.clone();
        timeSeries1.add(timeSeriesDataItem19, false);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries24.setDomainDescription("hi!");
        timeSeries24.setMaximumItemCount(0);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year((int) (byte) -1);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        java.util.Date date32 = year31.getEnd();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month33.previous();
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) year30, (org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year30, (java.lang.Number) 1560182873327L, false);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year41, (double) (-1.0f));
        timeSeries40.add(timeSeriesDataItem43);
        timeSeries40.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year49, (double) (-1.0f));
        timeSeries48.add(timeSeriesDataItem51);
        timeSeries48.setNotify(true);
        timeSeries48.setNotify(true);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year57.previous();
        timeSeries48.update((org.jfree.data.time.RegularTimePeriod) year57, (java.lang.Number) 100);
        java.lang.Number number62 = null;
        timeSeries48.update((int) (short) 0, number62);
        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries40.addAndOrUpdate(timeSeries48);
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year67, (double) (-1.0f));
        timeSeries66.add(timeSeriesDataItem69);
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year();
        java.util.Date date72 = year71.getEnd();
        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month(date72);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = month73.previous();
        int int75 = timeSeriesDataItem69.compareTo((java.lang.Object) month73);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = month73.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries48.getDataItem((org.jfree.data.time.RegularTimePeriod) month73);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = timeSeries1.addOrUpdate(timeSeriesDataItem77);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(timeSeries64);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(timeSeriesDataItem77);
        org.junit.Assert.assertNotNull(timeSeriesDataItem78);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        boolean boolean17 = year14.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1.0f);
        java.util.Date date22 = year12.getStart();
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean20 = timeSeries14.isEmpty();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(9);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 1560182844627L);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year22, "", "Mon Jun 10 09:07:29 PDT 2019");
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        java.util.Date date6 = fixedMillisecond1.getStart();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        timeSeriesDataItem2.setValue((java.lang.Number) 0);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560182876066L);
        java.lang.Number number7 = timeSeriesDataItem2.getValue();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1560182876066L + "'", number7.equals(1560182876066L));
    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        long long5 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getLastMillisecond(calendar6);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182925158L + "'", long1 == 1560182925158L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182925158L + "'", long2 == 1560182925158L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560182925158L + "'", long5 == 1560182925158L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560182925158L + "'", long7 == 1560182925158L);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
        int int8 = month6.getMonth();
        long long9 = month6.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (-1.0f));
        boolean boolean12 = timeSeriesDataItem11.isSelected();
        timeSeries1.add(timeSeriesDataItem11);
        java.lang.Number number14 = timeSeriesDataItem11.getValue();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1576526399999L + "'", long9 == 1576526399999L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (-1.0f) + "'", number14.equals((-1.0f)));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date3 = fixedMillisecond0.getStart();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
//        int int6 = month5.getYearValue();
//        java.util.Calendar calendar7 = null;
//        try {
//            month5.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182925219L + "'", long1 == 1560182925219L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182925219L + "'", long2 == 1560182925219L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        int int2 = year0.getYear();
        long long3 = year0.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        int int4 = month2.getMonth();
        int int5 = month2.getMonth();
        long long6 = month2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1575187200000L + "'", long6 == 1575187200000L);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        java.lang.String str10 = timeSeries1.getDescription();
        timeSeries1.setRangeDescription("December 2019");
        org.junit.Assert.assertNull(str10);
    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date3 = fixedMillisecond0.getStart();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
//        java.util.Date date6 = month5.getStart();
//        int int7 = month5.getYearValue();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182925291L + "'", long1 == 1560182925291L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182925291L + "'", long2 == 1560182925291L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        java.lang.String str9 = month8.toString();
        java.lang.String str10 = month8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month8.next();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (double) 1560182907959L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "December 2019" + "'", str9.equals("December 2019"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "December 2019" + "'", str10.equals("December 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        boolean boolean17 = year14.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener21);
        java.util.Collection collection23 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        boolean boolean24 = timeSeries18.isEmpty();
        java.util.Collection collection25 = timeSeries18.getTimePeriods();
        java.lang.String str26 = timeSeries18.getDomainDescription();
        int int27 = day3.compareTo((java.lang.Object) timeSeries18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date30 = fixedMillisecond29.getTime();
        boolean boolean31 = day3.equals((java.lang.Object) date30);
        int int32 = day3.getMonth();
        long long33 = day3.getSerialIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 12 + "'", int32 == 12);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43830L + "'", long33 == 43830L);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) -1);
        long long2 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62198899200000L) + "'", long2 == (-62198899200000L));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        boolean boolean3 = year0.equals((java.lang.Object) 100);
        java.util.Date date4 = year0.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        long long7 = day6.getSerialIndex();
        java.lang.String str8 = day6.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43830L + "'", long7 == 43830L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 100);
        java.lang.Number number15 = null;
        timeSeries1.update((int) (short) 0, number15);
        timeSeries1.setNotify(false);
        java.lang.Class class19 = timeSeries1.getTimePeriodClass();
        java.util.Collection collection20 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(collection20);
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) 1.0d);
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182925606L + "'", long1 == 1560182925606L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(date4);
//    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) (byte) -1);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getLastMillisecond(calendar4);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getMiddleMillisecond(calendar6);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182925639L + "'", long1 == 1560182925639L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560182925639L + "'", long5 == 1560182925639L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560182925639L + "'", long7 == 1560182925639L);
//    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        int int3 = fixedMillisecond0.compareTo((java.lang.Object) 1560182842664L);
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (double) (-1.0f));
//        timeSeries7.add(timeSeriesDataItem10);
//        timeSeries7.setNotify(true);
//        timeSeries7.setNotify(true);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
//        timeSeries7.update((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries7.getNextTimePeriod();
//        timeSeries7.setDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
//        timeSeries24.add(timeSeriesDataItem27);
//        timeSeries24.setNotify(true);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        java.util.Date date32 = year31.getEnd();
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        java.util.Date date34 = year33.getEnd();
//        boolean boolean36 = year33.equals((java.lang.Object) 100);
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) year31, (org.jfree.data.time.RegularTimePeriod) year33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year31.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (double) 1560182842702L);
//        java.lang.Object obj41 = timeSeriesDataItem40.clone();
//        timeSeriesDataItem40.setSelected(false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries7.addOrUpdate(timeSeriesDataItem40);
//        int int45 = fixedMillisecond0.compareTo((java.lang.Object) timeSeriesDataItem44);
//        java.util.Calendar calendar46 = null;
//        long long47 = fixedMillisecond0.getMiddleMillisecond(calendar46);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182925676L + "'", long1 == 1560182925676L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(obj41);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560182925676L + "'", long47 == 1560182925676L);
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        java.lang.Object obj15 = timeSeries1.clone();
        timeSeries1.setDescription("hi!");
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.util.Date date6 = regularTimePeriod5.getStart();
        timeSeries1.delete(regularTimePeriod5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date9);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod15, (java.lang.Number) 9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod15, (java.lang.Number) 10.0f);
        boolean boolean20 = fixedMillisecond11.equals((java.lang.Object) timeSeriesDataItem19);
        timeSeries1.add(timeSeriesDataItem19);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.util.Date date23 = year22.getEnd();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year28, (double) (-1.0f));
        timeSeries27.add(timeSeriesDataItem30);
        timeSeries27.setNotify(true);
        timeSeries27.setNotify(true);
        timeSeries27.setKey((java.lang.Comparable) 1.0f);
        boolean boolean38 = day25.equals((java.lang.Object) timeSeries27);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries40.setDomainDescription("hi!");
        timeSeries40.setMaximumItemCount(0);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year((int) (byte) -1);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        java.util.Date date48 = year47.getEnd();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month49.previous();
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries40.createCopy((org.jfree.data.time.RegularTimePeriod) year46, (org.jfree.data.time.RegularTimePeriod) month49);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener52 = null;
        timeSeries40.removeChangeListener(seriesChangeListener52);
        boolean boolean54 = day25.equals((java.lang.Object) timeSeries40);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day25);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem55);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (-1.0f));
        timeSeries9.add(timeSeriesDataItem12);
        timeSeries9.setNotify(true);
        timeSeries9.setNotify(true);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        timeSeries9.update((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 100);
        java.lang.Number number23 = null;
        timeSeries9.update((int) (short) 0, number23);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries1.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year28, (double) (-1.0f));
        timeSeries27.add(timeSeriesDataItem30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.util.Date date33 = year32.getEnd();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month34.previous();
        int int36 = timeSeriesDataItem30.compareTo((java.lang.Object) month34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month34.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month34);
        java.util.Calendar calendar39 = null;
        try {
            long long40 = month34.getLastMillisecond(calendar39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(timeSeriesDataItem38);
    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test456");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1560182854921L);
//        boolean boolean6 = timeSeriesDataItem5.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (double) (-1.0f));
//        timeSeries8.add(timeSeriesDataItem11);
//        timeSeries8.setNotify(true);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        java.util.Date date16 = year15.getEnd();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        java.util.Date date18 = year17.getEnd();
//        boolean boolean20 = year17.equals((java.lang.Object) 100);
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) year15, (org.jfree.data.time.RegularTimePeriod) year17);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        java.beans.PropertyChangeListener propertyChangeListener24 = null;
//        timeSeries23.removePropertyChangeListener(propertyChangeListener24);
//        java.util.Collection collection26 = timeSeries21.getTimePeriodsUniqueToOtherSeries(timeSeries23);
//        boolean boolean27 = timeSeries21.isEmpty();
//        timeSeries21.clear();
//        int int29 = timeSeriesDataItem5.compareTo((java.lang.Object) timeSeries21);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182928284L + "'", long2 == 1560182928284L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        long long3 = fixedMillisecond2.getMiddleMillisecond();
//        long long4 = fixedMillisecond2.getSerialIndex();
//        long long5 = fixedMillisecond2.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setRangeDescription("Mon Jun 10 09:08:36 PDT 2019");
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560182928555L + "'", long3 == 1560182928555L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560182928555L + "'", long4 == 1560182928555L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560182928555L + "'", long5 == 1560182928555L);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        timeSeries12.removeAgedItems(1560182842984L, false);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year20, (double) (-1.0f));
        timeSeries19.add(timeSeriesDataItem22);
        timeSeries19.setNotify(true);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        java.util.Date date27 = year26.getEnd();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.util.Date date29 = year28.getEnd();
        boolean boolean31 = year28.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) year26, (org.jfree.data.time.RegularTimePeriod) year28);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        java.util.Date date34 = year33.getEnd();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month35.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries19.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) month35, (java.lang.Number) 10.0d, true);
        int int41 = month35.getYearValue();
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year8.next();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) (-1.0f));
        timeSeries18.add(timeSeriesDataItem21);
        timeSeries18.setNotify(true);
        timeSeries18.setNotify(true);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        timeSeries18.update((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) 100);
        java.lang.Number number32 = null;
        timeSeries18.update((int) (short) 0, number32);
        timeSeries18.setNotify(false);
        java.lang.String str36 = timeSeries18.getRangeDescription();
        boolean boolean37 = year8.equals((java.lang.Object) timeSeries18);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Value" + "'", str36.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        int int7 = month6.getYearValue();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) month6);
        long long9 = month6.getSerialIndex();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 24240L + "'", long9 == 24240L);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent1.getClass();
        java.lang.String str5 = seriesChangeEvent1.toString();
        java.lang.Object obj6 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str5.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + (byte) 100 + "'", obj6.equals((byte) 100));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        boolean boolean15 = year12.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) 1560182842702L);
        java.lang.Object obj20 = timeSeriesDataItem19.clone();
        timeSeries1.add(timeSeriesDataItem19, false);
        double double23 = timeSeries1.getMaxY();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getEnd();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year30, (double) (-1.0f));
        timeSeries29.add(timeSeriesDataItem32);
        timeSeries29.setNotify(true);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        java.util.Date date37 = year36.getEnd();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        java.util.Date date39 = year38.getEnd();
        boolean boolean41 = year38.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) year36, (org.jfree.data.time.RegularTimePeriod) year38);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener45 = null;
        timeSeries44.removePropertyChangeListener(propertyChangeListener45);
        java.util.Collection collection47 = timeSeries42.getTimePeriodsUniqueToOtherSeries(timeSeries44);
        boolean boolean48 = timeSeries42.isEmpty();
        java.util.Collection collection49 = timeSeries42.getTimePeriods();
        java.lang.String str50 = timeSeries42.getDomainDescription();
        int int51 = day27.compareTo((java.lang.Object) timeSeries42);
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year54, (double) (-1.0f));
        timeSeries53.add(timeSeriesDataItem56);
        timeSeries53.setNotify(true);
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        java.util.Date date61 = year60.getEnd();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        java.util.Date date63 = year62.getEnd();
        boolean boolean65 = year62.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries53.createCopy((org.jfree.data.time.RegularTimePeriod) year60, (org.jfree.data.time.RegularTimePeriod) year62);
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year();
        java.util.Date date68 = year67.getEnd();
        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month(date68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = month69.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = timeSeries53.getDataItem((org.jfree.data.time.RegularTimePeriod) month69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = timeSeriesDataItem71.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day27, regularTimePeriod72);
        java.beans.PropertyChangeListener propertyChangeListener74 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener74);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.560182842702E12d + "'", double23 == 1.560182842702E12d);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertNotNull(collection47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(collection49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Time" + "'", str50.equals("Time"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(timeSeries66);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(timeSeriesDataItem71);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(timeSeries73);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (-1.0f));
        timeSeries9.add(timeSeriesDataItem12);
        timeSeries9.setNotify(true);
        timeSeries9.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries18.removeChangeListener(seriesChangeListener19);
        timeSeries18.removeAgedItems(1560182842984L, false);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries5.addAndOrUpdate(timeSeries18);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(timeSeries24);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        boolean boolean17 = year14.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener21);
        java.util.Collection collection23 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        boolean boolean24 = timeSeries18.isEmpty();
        java.util.Collection collection25 = timeSeries18.getTimePeriods();
        java.lang.String str26 = timeSeries18.getDomainDescription();
        int int27 = day3.compareTo((java.lang.Object) timeSeries18);
        org.jfree.data.time.SerialDate serialDate28 = day3.getSerialDate();
        java.util.Date date29 = day3.getStart();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(date29);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-1969" + "'", str5.equals("31-December-1969"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = seriesChangeEvent1.getSummary();
        java.lang.String str3 = seriesChangeEvent1.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = seriesChangeEvent1.getSummary();
        java.lang.Object obj5 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertNull(seriesChangeInfo2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertNull(seriesChangeInfo4);
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + (byte) 100 + "'", obj5.equals((byte) 100));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        boolean boolean3 = year0.equals((java.lang.Object) 100);
        java.util.Date date4 = year0.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        long long6 = year5.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 100);
        java.lang.Number number15 = null;
        timeSeries1.update((int) (short) 0, number15);
        timeSeries1.setNotify(false);
        java.lang.String str19 = timeSeries1.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "org.jfree.data.general.SeriesException: hi!", "2019");
        long long24 = timeSeries23.getMaximumItemAge();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        long long26 = month25.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month25.next();
        java.lang.Number number28 = timeSeries23.getValue(regularTimePeriod27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        java.util.Date date30 = year29.getEnd();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month31.previous();
        int int33 = month31.getMonth();
        long long34 = month31.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month31.previous();
        timeSeries23.setKey((java.lang.Comparable) regularTimePeriod37);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries1.addOrUpdate(regularTimePeriod37, (java.lang.Number) 1560182885467L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1561964399999L + "'", long26 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 12 + "'", int33 == 12);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1576526399999L + "'", long34 == 1576526399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "org.jfree.data.general.SeriesException: hi!", "2019");
        long long4 = timeSeries3.getMaximumItemAge();
        java.lang.Object obj5 = timeSeries3.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        long long8 = fixedMillisecond7.getMiddleMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 1560182893814L);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond7.getFirstMillisecond(calendar11);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
//        timeSeries3.add(timeSeriesDataItem6);
//        timeSeries3.setNotify(true);
//        timeSeries3.setNotify(true);
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries12.addChangeListener(seriesChangeListener13);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        java.util.Date date16 = year15.getEnd();
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (-1.0f));
//        timeSeries20.add(timeSeriesDataItem23);
//        timeSeries20.setNotify(true);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        java.util.Date date28 = year27.getEnd();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        java.util.Date date30 = year29.getEnd();
//        boolean boolean32 = year29.equals((java.lang.Object) 100);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) year27, (org.jfree.data.time.RegularTimePeriod) year29);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        java.beans.PropertyChangeListener propertyChangeListener36 = null;
//        timeSeries35.removePropertyChangeListener(propertyChangeListener36);
//        java.util.Collection collection38 = timeSeries33.getTimePeriodsUniqueToOtherSeries(timeSeries35);
//        boolean boolean39 = timeSeries33.isEmpty();
//        java.util.Collection collection40 = timeSeries33.getTimePeriods();
//        java.lang.String str41 = timeSeries33.getDomainDescription();
//        int int42 = day18.compareTo((java.lang.Object) timeSeries33);
//        org.jfree.data.time.SerialDate serialDate43 = day18.getSerialDate();
//        int int45 = day18.compareTo((java.lang.Object) 100.0f);
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
//        java.util.Date date47 = year46.getEnd();
//        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date47);
//        boolean boolean49 = day18.equals((java.lang.Object) date47);
//        int int50 = day18.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day18.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar53 = null;
//        long long54 = fixedMillisecond52.getFirstMillisecond(calendar53);
//        java.util.Date date55 = fixedMillisecond52.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (java.lang.Number) 1560182847497L);
//        java.util.Date date58 = fixedMillisecond52.getTime();
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) day18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener60 = null;
//        timeSeries12.addChangeListener(seriesChangeListener60);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertNotNull(collection38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(collection40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Time" + "'", str41.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2019 + "'", int50 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560182932391L + "'", long54 == 1560182932391L);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeSeries59);
//    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        int int3 = fixedMillisecond0.compareTo((java.lang.Object) 1560182842664L);
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (double) (-1.0f));
//        timeSeries7.add(timeSeriesDataItem10);
//        timeSeries7.setNotify(true);
//        timeSeries7.setNotify(true);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
//        timeSeries7.update((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries7.getNextTimePeriod();
//        timeSeries7.setDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
//        timeSeries24.add(timeSeriesDataItem27);
//        timeSeries24.setNotify(true);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        java.util.Date date32 = year31.getEnd();
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        java.util.Date date34 = year33.getEnd();
//        boolean boolean36 = year33.equals((java.lang.Object) 100);
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) year31, (org.jfree.data.time.RegularTimePeriod) year33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year31.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (double) 1560182842702L);
//        java.lang.Object obj41 = timeSeriesDataItem40.clone();
//        timeSeriesDataItem40.setSelected(false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries7.addOrUpdate(timeSeriesDataItem40);
//        int int45 = fixedMillisecond0.compareTo((java.lang.Object) timeSeriesDataItem44);
//        java.util.Calendar calendar46 = null;
//        fixedMillisecond0.peg(calendar46);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
//        timeSeries49.setDomainDescription("hi!");
//        timeSeries49.setMaximumItemCount(0);
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year((int) (byte) -1);
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
//        java.util.Date date57 = year56.getEnd();
//        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month(date57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = month58.previous();
//        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries49.createCopy((org.jfree.data.time.RegularTimePeriod) year55, (org.jfree.data.time.RegularTimePeriod) month58);
//        long long61 = month58.getFirstMillisecond();
//        int int62 = month58.getMonth();
//        boolean boolean63 = fixedMillisecond0.equals((java.lang.Object) month58);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182932985L + "'", long1 == 1560182932985L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(obj41);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(timeSeries60);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1575187200000L + "'", long61 == 1575187200000L);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 12 + "'", int62 == 12);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        boolean boolean17 = year14.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1.0f);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener22);
        java.lang.String str24 = timeSeries1.getRangeDescription();
        timeSeries1.setNotify(true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Value" + "'", str24.equals("Value"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries21.removePropertyChangeListener(propertyChangeListener22);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (double) (-1.0f));
        timeSeries25.add(timeSeriesDataItem28);
        timeSeries25.setNotify(true);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.util.Date date33 = year32.getEnd();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        java.util.Date date35 = year34.getEnd();
        boolean boolean37 = year34.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) year34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year32.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year32, (double) 1.0f);
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) 10.0d);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year44, (double) (-1.0f));
        timeSeriesDataItem46.setValue((java.lang.Number) 0);
        timeSeries16.setKey((java.lang.Comparable) timeSeriesDataItem46);
        java.lang.String str50 = timeSeries16.getDomainDescription();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Time" + "'", str50.equals("Time"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent1.getClass();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo5);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.util.Date date6 = regularTimePeriod5.getStart();
        timeSeries1.delete(regularTimePeriod5);
        double double8 = timeSeries1.getMaxY();
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, (double) (-1.0f));
        timeSeries13.add(timeSeriesDataItem16);
        timeSeries13.setNotify(true);
        timeSeries13.setNotify(true);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.previous();
        timeSeries13.update((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeries13.getNextTimePeriod();
        timeSeries13.setDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timeSeries13.removeAgedItems((long) '4', true);
        boolean boolean32 = timeSeries1.equals((java.lang.Object) true);
        double double33 = timeSeries1.getMinY();
        try {
            timeSeries1.delete((int) (byte) 0, 7, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.Year year20 = month17.getYear();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (double) (-1.0f));
        timeSeries22.add(timeSeriesDataItem25);
        timeSeries22.setNotify(true);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        java.util.Date date30 = year29.getEnd();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        java.util.Date date32 = year31.getEnd();
        boolean boolean34 = year31.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) year29, (org.jfree.data.time.RegularTimePeriod) year31);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries37.removePropertyChangeListener(propertyChangeListener38);
        java.util.Collection collection40 = timeSeries35.getTimePeriodsUniqueToOtherSeries(timeSeries37);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timeSeries42.removePropertyChangeListener(propertyChangeListener43);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year47, (double) (-1.0f));
        timeSeries46.add(timeSeriesDataItem49);
        timeSeries46.setNotify(true);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        java.util.Date date54 = year53.getEnd();
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        java.util.Date date56 = year55.getEnd();
        boolean boolean58 = year55.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries46.createCopy((org.jfree.data.time.RegularTimePeriod) year53, (org.jfree.data.time.RegularTimePeriod) year55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = year53.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year53, (double) 1.0f);
        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) 10.0d);
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries66.setMaximumItemAge((long) 'a');
        boolean boolean69 = year53.equals((java.lang.Object) 'a');
        int int70 = month17.compareTo((java.lang.Object) boolean69);
        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        long long73 = fixedMillisecond72.getMiddleMillisecond();
        int int74 = month17.compareTo((java.lang.Object) long73);
        java.lang.String str75 = month17.toString();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertNotNull(collection40);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNull(timeSeriesDataItem62);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 100L + "'", long73 == 100L);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "December 2019" + "'", str75.equals("December 2019"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        timeSeries5.add(timeSeriesDataItem8);
        timeSeries5.setNotify(true);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        boolean boolean17 = year14.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener21);
        java.util.Collection collection23 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        boolean boolean24 = timeSeries18.isEmpty();
        java.util.Collection collection25 = timeSeries18.getTimePeriods();
        java.lang.String str26 = timeSeries18.getDomainDescription();
        int int27 = day3.compareTo((java.lang.Object) timeSeries18);
        org.jfree.data.time.SerialDate serialDate28 = day3.getSerialDate();
        int int30 = day3.compareTo((java.lang.Object) 100.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day3.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        timeSeries1.setMaximumItemCount(0);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (byte) -1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(9);
        java.lang.Number number15 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener16);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNull(number15);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (-1.0f));
        timeSeries9.add(timeSeriesDataItem12);
        timeSeries9.setNotify(true);
        timeSeries9.setNotify(true);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        timeSeries9.update((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 100);
        java.lang.Number number23 = null;
        timeSeries9.update((int) (short) 0, number23);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries1.addAndOrUpdate(timeSeries9);
        double double26 = timeSeries25.getMinY();
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-1.0d) + "'", double26 == (-1.0d));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        boolean boolean3 = year0.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "2019", "Value");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) (-1.0f));
        timeSeries6.setKey((java.lang.Comparable) (-1.0f));
        java.util.List list11 = timeSeries6.getItems();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries6.addChangeListener(seriesChangeListener12);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
        java.util.List list13 = timeSeries12.getItems();
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "", "31-December-2019");
        timeSeries3.setMaximumItemCount(7);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries3.createCopy((int) (short) 0, 8);
        org.junit.Assert.assertNotNull(timeSeries8);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.addChangeListener(seriesChangeListener13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries12.createCopy(0, 0);
        timeSeries17.clear();
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(timeSeries17);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        boolean boolean3 = year0.equals((java.lang.Object) 100);
        java.util.Date date4 = year0.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5, "June 2019", "hi!");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year((int) (byte) -1);
        java.lang.Number number15 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year14);
        java.lang.String str16 = timeSeries1.getDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries1.getTimePeriod((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean20 = timeSeries14.isEmpty();
        java.util.Collection collection21 = timeSeries14.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries23.setDomainDescription("hi!");
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.previous();
        java.util.Date date28 = regularTimePeriod27.getStart();
        timeSeries23.delete(regularTimePeriod27);
        double double30 = timeSeries23.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (-1.0f));
        timeSeries32.add(timeSeriesDataItem35);
        timeSeries32.setNotify(true);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        java.util.Date date40 = year39.getEnd();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        java.util.Date date42 = year41.getEnd();
        boolean boolean44 = year41.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) year39, (org.jfree.data.time.RegularTimePeriod) year41);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        java.util.Date date47 = year46.getEnd();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month48.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) month48);
        org.jfree.data.time.Year year51 = month48.getYear();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) year51, (java.lang.Number) 1560182842664L);
        java.util.Collection collection54 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        timeSeries14.setDomainDescription("Mon Jun 10 09:08:36 PDT 2019");
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(timeSeriesDataItem50);
        org.junit.Assert.assertNotNull(year51);
        org.junit.Assert.assertNotNull(collection54);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        timeSeries1.setMaximumItemCount(0);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (byte) -1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) month10);
        long long13 = month10.getFirstMillisecond();
        long long14 = month10.getSerialIndex();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1575187200000L + "'", long13 == 1575187200000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24240L + "'", long14 == 24240L);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.setNotify(true);
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries3);
        java.lang.String str13 = timeSeries12.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries12.removePropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getEnd();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
        java.lang.String str19 = month18.toString();
        java.lang.String str20 = month18.toString();
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 1560182842984L);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeries12.getTimePeriod(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "December 2019" + "'", str19.equals("December 2019"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "December 2019" + "'", str20.equals("December 2019"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        boolean boolean6 = timeSeries1.getNotify();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries1);
        java.lang.Object obj8 = seriesChangeEvent7.getSource();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(obj8);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date3 = fixedMillisecond0.getStart();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
//        java.lang.String str6 = month5.toString();
//        int int7 = month5.getYearValue();
//        java.util.Calendar calendar8 = null;
//        try {
//            month5.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182937814L + "'", long1 == 1560182937814L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182937814L + "'", long2 == 1560182937814L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(11);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(5, year2);
        boolean boolean5 = month3.equals((java.lang.Object) 1560182849845L);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month3.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date3 = fixedMillisecond0.getStart();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
//        java.lang.String str6 = month5.toString();
//        java.lang.Class<?> wildcardClass7 = month5.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        long long10 = fixedMillisecond8.getSerialIndex();
//        java.util.Calendar calendar11 = null;
//        fixedMillisecond8.peg(calendar11);
//        boolean boolean14 = fixedMillisecond8.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, 0.0d);
//        java.lang.Class<?> wildcardClass17 = fixedMillisecond8.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize(class18);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
//        java.util.Date date22 = regularTimePeriod21.getStart();
//        java.util.TimeZone timeZone23 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date22, timeZone23);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date22, timeZone25);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182937861L + "'", long1 == 1560182937861L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182937861L + "'", long2 == 1560182937861L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182937864L + "'", long9 == 1560182937864L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560182937864L + "'", long10 == 1560182937864L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        timeSeries1.add(timeSeriesDataItem4);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) collection19);
        java.lang.Object obj21 = seriesChangeEvent20.getSource();
        java.lang.Object obj22 = seriesChangeEvent20.getSource();
        java.lang.Object obj23 = seriesChangeEvent20.getSource();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.util.Date date6 = regularTimePeriod5.getStart();
        timeSeries1.delete(regularTimePeriod5);
        double double8 = timeSeries1.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (double) (-1.0f));
        timeSeries10.add(timeSeriesDataItem13);
        timeSeries10.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) (-1.0f));
        timeSeries18.add(timeSeriesDataItem21);
        timeSeries18.setNotify(true);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        java.util.Date date26 = year25.getEnd();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.util.Date date28 = year27.getEnd();
        boolean boolean30 = year27.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) year25, (org.jfree.data.time.RegularTimePeriod) year27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year25.next();
        org.jfree.data.general.SeriesException seriesException34 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray35 = seriesException34.getSuppressed();
        int int36 = year25.compareTo((java.lang.Object) throwableArray35);
        long long37 = year25.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year25, (double) 1560182842984L);
        timeSeries1.add(timeSeriesDataItem39, false);
        timeSeriesDataItem39.setSelected(false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 2019L + "'", long37 == 2019L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.util.Date date6 = regularTimePeriod5.getStart();
        timeSeries1.delete(regularTimePeriod5);
        double double8 = timeSeries1.getMaxY();
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182842943L);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, (double) (-1.0f));
        timeSeries13.add(timeSeriesDataItem16);
        timeSeries13.setNotify(true);
        timeSeries13.setNotify(true);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.previous();
        timeSeries13.update((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeries13.getNextTimePeriod();
        timeSeries13.setDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timeSeries13.removeAgedItems((long) '4', true);
        boolean boolean32 = timeSeries1.equals((java.lang.Object) true);
        double double33 = timeSeries1.getMinY();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        java.util.Date date35 = year34.getEnd();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month36.previous();
        int int38 = month36.getMonth();
        long long39 = month36.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month36, (java.lang.Number) (-1.0f));
        boolean boolean42 = timeSeries1.equals((java.lang.Object) timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1576526399999L + "'", long39 == 1576526399999L);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }
}

