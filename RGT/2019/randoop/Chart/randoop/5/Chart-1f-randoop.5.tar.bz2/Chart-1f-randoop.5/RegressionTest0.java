import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.Color color1 = java.awt.Color.getColor("hi!");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        try {
            double double7 = barRenderer0.getItemMiddle((java.lang.Comparable) (-1.0f), (java.lang.Comparable) 0.0f, categoryDataset3, categoryAxis4, rectangle2D5, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.category.BarPainter barPainter1 = null;
        try {
            barRenderer0.setBarPainter(barPainter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.event.RendererChangeListener rendererChangeListener1 = null;
        try {
            barRenderer0.removeChangeListener(rendererChangeListener1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.util.List list10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        try {
            double double13 = categoryAxis0.getCategoryMiddle((java.lang.Comparable) (-1L), list10, rectangle2D11, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'categories' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = null;
        try {
            org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = null;
        org.jfree.chart.text.TextAnchor textAnchor1 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor2, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'itemLabelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        java.awt.Shape shape4 = null;
        try {
            barRenderer0.setBaseShape(shape4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Shape shape6 = null;
        try {
            barRenderer0.setBaseShape(shape6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer5.setLegendShape(100, shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Stroke stroke13 = null;
        java.awt.Shape shape15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke16 = null;
        java.awt.Paint paint17 = null;
        try {
            org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", true, shape7, false, (java.awt.Paint) color10, false, (java.awt.Paint) color12, stroke13, false, shape15, stroke16, paint17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = categoryAxis11.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D17, rectangleEdge18);
        java.lang.String str20 = categoryAxis11.getLabel();
        categoryAxis11.setLabelURL("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState28 = null;
        try {
            boolean boolean29 = barRenderer0.hitTest(100.0d, (double) 255, graphics2D8, rectangle2D9, categoryPlot10, categoryAxis11, valueAxis23, categoryDataset24, (int) (byte) 100, (int) (byte) -1, false, categoryItemRendererState28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int3 = java.awt.Color.HSBtoRGB((float) (-1L), (float) (-1), (float) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-2097346) + "'", int3 == (-2097346));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        try {
            lineAndShapeRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D3, categoryPlot4, categoryAxis5, valueAxis6, categoryDataset7, (int) ' ', 0, true, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = null;
        try {
            barRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer0.setBaseItemLabelFont(font1, false);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            barRenderer0.drawBackground(graphics2D4, categoryPlot5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.event.RendererChangeListener rendererChangeListener1 = null;
        try {
            lineAndShapeRenderer0.addChangeListener(rendererChangeListener1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        try {
            lineAndShapeRenderer0.setSeriesLinesVisible((-1), (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer0.setBaseItemLabelFont(font1, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = categoryAxis4.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D10, rectangleEdge11);
        java.lang.String str13 = categoryAxis4.getLabel();
        categoryAxis4.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = categoryAxis16.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D22, rectangleEdge23);
        java.awt.Font font25 = categoryAxis16.getTickLabelFont();
        categoryAxis4.setLabelFont(font25);
        barRenderer0.setBaseLegendTextFont(font25);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis30.setLowerMargin(0.0d);
        java.lang.String str33 = categoryAxis30.getLabel();
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        try {
            barRenderer0.drawDomainMarker(graphics2D28, categoryPlot29, categoryAxis30, categoryMarker34, rectangle2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNull(str33);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis0.setTickLabelInsets(rectangleInsets10);
        double double13 = rectangleInsets10.trimWidth((double) '#');
        double double14 = rectangleInsets10.getBottom();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets10.createAdjustedRectangle(rectangle2D15, lengthAdjustmentType16, lengthAdjustmentType17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 19.0d + "'", double13 == 19.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getSeriesNegativeItemLabelPosition(0);
        java.awt.Color color12 = java.awt.Color.YELLOW;
        barRenderer0.setBaseLegendTextPaint((java.awt.Paint) color12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer14.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer14.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color20 = java.awt.Color.RED;
        barRenderer14.setShadowPaint((java.awt.Paint) color20);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator22 = barRenderer14.getLegendItemLabelGenerator();
        barRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator22);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = null;
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState29 = barRenderer0.initialise(graphics2D24, rectangle2D25, categoryPlot26, categoryDataset27, plotRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator22);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendItem1.setLinePaint((java.awt.Paint) color2);
        java.text.AttributedString attributedString4 = legendItem1.getAttributedLabel();
        org.jfree.data.general.Dataset dataset5 = legendItem1.getDataset();
        java.awt.Paint paint6 = legendItem1.getLabelPaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(attributedString4);
        org.junit.Assert.assertNull(dataset5);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendItem1.setLinePaint((java.awt.Paint) color2);
        java.lang.String str4 = legendItem1.getToolTipText();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color7 = java.awt.Color.getColor("hi!", color6);
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        int int10 = color9.getGreen();
        try {
            org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "", "hi!", shape4, (java.awt.Paint) color6, stroke8, (java.awt.Paint) color9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer1.setLegendShape(100, shape3);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = barRenderer1.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint9 = barRenderer1.getBaseItemLabelPaint();
        boolean boolean10 = barRenderer1.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = barRenderer1.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor13 = itemLabelPosition12.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor14 = itemLabelPosition12.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor15 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor14, textAnchor15, (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryURLGenerator8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(itemLabelAnchor13);
        org.junit.Assert.assertNotNull(textAnchor14);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        barRenderer0.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer6.setLegendShape(100, shape8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer6.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint14 = barRenderer6.getBaseItemLabelPaint();
        boolean boolean15 = barRenderer6.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer6.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = itemLabelPosition17.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor19 = itemLabelPosition17.getRotationAnchor();
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition17, false);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color28 = java.awt.Color.getColor("hi!", color27);
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        try {
            barRenderer0.drawDomainLine(graphics2D22, categoryPlot23, rectangle2D24, 0.0d, (java.awt.Paint) color27, stroke29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        barRenderer0.clearSeriesPaints(false);
        java.awt.Paint paint9 = barRenderer0.getSeriesItemLabelPaint(1);
        barRenderer0.removeAnnotations();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setLowerMargin(0.0d);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D24 = barRenderer0.createHotSpotBounds(graphics2D11, rectangle2D12, categoryPlot13, categoryAxis14, valueAxis17, categoryDataset18, 10, (int) (byte) 1, true, categoryItemRendererState22, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity6 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "", "hi!", categoryDataset3, (java.lang.Comparable) (-1.0f), (java.lang.Comparable) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = abstractCategoryDataset0.getGroup();
        boolean boolean3 = datasetGroup1.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis4.setLowerMargin(0.0d);
        categoryAxis4.setLowerMargin((double) 1L);
        boolean boolean9 = datasetGroup1.equals((java.lang.Object) categoryAxis4);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset10 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup11 = abstractCategoryDataset10.getGroup();
        java.util.EventListener eventListener12 = null;
        boolean boolean13 = abstractCategoryDataset10.hasListener(eventListener12);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo14 = null;
        try {
            org.jfree.data.event.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) categoryAxis4, (org.jfree.data.general.Dataset) abstractCategoryDataset10, datasetChangeInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(datasetGroup11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        barRenderer0.setShadowXOffset((double) 'a');
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.setLowerMargin(0.0d);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            barRenderer0.drawAnnotations(graphics2D6, rectangle2D7, categoryAxis8, valueAxis11, layer12, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8, false);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.data.Range range13 = barRenderer0.findRangeBounds(categoryDataset11, false);
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        try {
            barRenderer0.setSeriesItemLabelFont((int) (short) -1, font15, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.plot.Plot plot4 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity7 = new org.jfree.chart.entity.PlotEntity(shape2, plot4, "", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState1 = abstractCategoryDataset0.getSelectionState();
        org.junit.Assert.assertNull(categoryDatasetSelectionState1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer0.setSeriesStroke(0, stroke5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer7.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer7.setSeriesStroke(0, stroke12);
        barRenderer0.setBaseOutlineStroke(stroke12, true);
        barRenderer0.clearSeriesStrokes(true);
        barRenderer0.setAutoPopulateSeriesPaint(false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke2 = renderAttributes0.getSeriesStroke((int) (byte) -1);
        java.awt.Paint paint3 = null;
        try {
            renderAttributes0.setDefaultFillPaint(paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = abstractCategoryDataset0.getGroup();
        boolean boolean3 = datasetGroup1.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis4.setLowerMargin(0.0d);
        categoryAxis4.setLowerMargin((double) 1L);
        boolean boolean9 = datasetGroup1.equals((java.lang.Object) categoryAxis4);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis4.getCategoryEnd((int) (byte) 100, (int) (byte) 10, rectangle2D12, rectangleEdge13);
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        barRenderer0.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer6.setLegendShape(100, shape8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer6.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint14 = barRenderer6.getBaseItemLabelPaint();
        boolean boolean15 = barRenderer6.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer6.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = itemLabelPosition17.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor19 = itemLabelPosition17.getRotationAnchor();
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition17, false);
        boolean boolean22 = barRenderer0.getBaseCreateEntities();
        java.awt.Shape shape24 = barRenderer0.getSeriesShape(100);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(shape24);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 100, (int) (byte) 100, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = abstractCategoryDataset0.getGroup();
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset2 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup3 = abstractCategoryDataset2.getGroup();
        abstractCategoryDataset0.setGroup(datasetGroup3);
        java.lang.String str5 = datasetGroup3.getID();
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(datasetGroup3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "NOID" + "'", str5.equals("NOID"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int1 = color0.getTransparency();
        java.awt.Color color2 = color0.brighter();
        java.awt.color.ColorSpace colorSpace3 = null;
        float[] floatArray4 = null;
        try {
            float[] floatArray5 = color2.getColorComponents(colorSpace3, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj1 = standardCategorySeriesLabelGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer0.setBaseItemLabelFont(font1, false);
        boolean boolean5 = barRenderer0.isSeriesVisible((int) (short) 1);
        barRenderer0.setShadowXOffset((double) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (byte) 1, categoryToolTipGenerator9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int16 = color15.getTransparency();
        java.awt.Color color17 = color15.brighter();
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        try {
            barRenderer0.drawDomainLine(graphics2D11, categoryPlot12, rectangle2D13, (double) 2, (java.awt.Paint) color17, stroke18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape2 = renderAttributes0.getSeriesShape((int) (byte) 100);
        java.awt.Stroke stroke3 = null;
        try {
            renderAttributes0.setDefaultOutlineStroke(stroke3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(shape2);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((-2097346));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.awt.Color color1 = null;
        java.awt.Color color2 = java.awt.Color.getColor("", color1);
        org.junit.Assert.assertNull(color2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis0.setTickLabelInsets(rectangleInsets10);
        double double13 = rectangleInsets10.trimWidth((double) '#');
        double double14 = rectangleInsets10.getRight();
        double double16 = rectangleInsets10.trimWidth((double) (byte) 0);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 19.0d + "'", double13 == 19.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 8.0d + "'", double14 == 8.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-16.0d) + "'", double16 == (-16.0d));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation11, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        barRenderer0.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer6.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer6.setSeriesStroke(0, stroke11);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer13.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer13.setSeriesStroke(0, stroke18);
        barRenderer6.setBaseOutlineStroke(stroke18, true);
        barRenderer0.setBaseStroke(stroke18);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation23 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        int int2 = color1.getGreen();
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color1);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset4 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup5 = abstractCategoryDataset4.getGroup();
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState6 = null;
        abstractCategoryDataset4.setSelectionState(categoryDatasetSelectionState6);
        abstractCategoryDataset4.validateObject();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo9 = null;
        try {
            org.jfree.data.event.DatasetChangeEvent datasetChangeEvent10 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) color1, (org.jfree.data.general.Dataset) abstractCategoryDataset4, datasetChangeInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertNotNull(datasetGroup5);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        double double8 = barRenderer0.getItemMargin();
        double double9 = barRenderer0.getItemLabelAnchorOffset();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendItem1.setLinePaint((java.awt.Paint) color2);
        int int4 = color2.getGreen();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 255 + "'", int4 == 255);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0);
        java.awt.Stroke stroke12 = barRenderer0.getSeriesOutlineStroke(1);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = categoryAxis16.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D22, rectangleEdge23);
        java.awt.Font font25 = categoryAxis16.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis16.setTickLabelInsets(rectangleInsets26);
        categoryAxis16.setVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        double double38 = categoryAxis30.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D36, rectangleEdge37);
        java.awt.Font font39 = categoryAxis30.getTickLabelFont();
        java.awt.Font font40 = categoryAxis30.getTickLabelFont();
        categoryAxis16.setLabelFont(font40);
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D49 = barRenderer0.createHotSpotBounds(graphics2D13, rectangle2D14, categoryPlot15, categoryAxis16, valueAxis42, categoryDataset43, (int) '4', 1, false, categoryItemRendererState47, rectangle2D48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(font40);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.clearSeriesStrokes(true);
        boolean boolean6 = barRenderer0.isItemLabelVisible((int) (byte) 0, (int) (byte) -1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator8, true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesShapesFilled((int) (byte) 100);
        boolean boolean5 = lineAndShapeRenderer0.getBaseLinesVisible();
        lineAndShapeRenderer0.setSeriesShapesFilled(0, (java.lang.Boolean) false);
        java.lang.Boolean boolean10 = lineAndShapeRenderer0.getSeriesShapesVisible(2);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(boolean10);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getSeriesNegativeItemLabelPosition(0);
        java.awt.Color color12 = java.awt.Color.YELLOW;
        barRenderer0.setBaseLegendTextPaint((java.awt.Paint) color12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer14.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer14.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color20 = java.awt.Color.RED;
        barRenderer14.setShadowPaint((java.awt.Paint) color20);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator22 = barRenderer14.getLegendItemLabelGenerator();
        barRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator22);
        boolean boolean24 = barRenderer0.getIncludeBaseInRange();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier29 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset30 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup31 = abstractCategoryDataset30.getGroup();
        boolean boolean33 = datasetGroup31.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis34.setLowerMargin(0.0d);
        categoryAxis34.setLowerMargin((double) 1L);
        boolean boolean39 = datasetGroup31.equals((java.lang.Object) categoryAxis34);
        boolean boolean40 = defaultDrawingSupplier29.equals((java.lang.Object) categoryAxis34);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        try {
            barRenderer0.drawItem(graphics2D25, categoryItemRendererState26, rectangle2D27, categoryPlot28, categoryAxis34, valueAxis41, categoryDataset42, 100, 0, false, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(datasetGroup31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = abstractCategoryDataset0.getGroup();
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset2 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup3 = abstractCategoryDataset2.getGroup();
        abstractCategoryDataset0.setGroup(datasetGroup3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer13.setLegendShape(100, shape15);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint18 = null;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape15, stroke17, paint18);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color22 = java.awt.Color.getColor("hi!", color21);
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape15, (java.awt.Paint) color21);
        boolean boolean24 = datasetGroup3.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(datasetGroup3);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis0.setTickLabelInsets(rectangleInsets10);
        categoryAxis0.setMinorTickMarkOutsideLength((-1.0f));
        double double14 = categoryAxis0.getCategoryMargin();
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color15);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        int int2 = color1.getGreen();
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color1);
        barRenderer0.setMaximumBarWidth((double) (byte) 10);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        barRenderer0.setShadowXOffset((double) 'a');
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendItem7.setLinePaint((java.awt.Paint) color8);
        java.text.AttributedString attributedString10 = legendItem7.getAttributedLabel();
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer11.setLegendShape(100, shape13);
        legendItem7.setShape(shape13);
        barRenderer0.setBaseShape(shape13);
        java.awt.Paint paint17 = barRenderer0.getBasePaint();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(attributedString10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.lang.String str9 = categoryAxis0.getLabel();
        categoryAxis0.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis12.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D18, rectangleEdge19);
        java.awt.Font font21 = categoryAxis12.getTickLabelFont();
        categoryAxis0.setLabelFont(font21);
        categoryAxis0.setTickMarkInsideLength((float) (-1));
        float float25 = categoryAxis0.getTickMarkInsideLength();
        float float26 = categoryAxis0.getTickMarkInsideLength();
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + (-1.0f) + "'", float25 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + (-1.0f) + "'", float26 == (-1.0f));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        categoryAxis0.setLabel("hi!");
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.Plot plot13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace17 = categoryAxis0.reserveSpace(graphics2D12, plot13, rectangle2D14, rectangleEdge15, axisSpace16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.awt.Shape shape0 = null;
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity3 = new org.jfree.chart.entity.PlotEntity(shape0, plot1, "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        double double8 = barRenderer0.getItemMargin();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = barRenderer0.getURLGenerator((int) (short) 100, (-1), false);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        try {
            barRenderer0.setPlot(categoryPlot13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertNull(categoryURLGenerator12);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        barRenderer0.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer6.setLegendShape(100, shape8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer6.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint14 = barRenderer6.getBaseItemLabelPaint();
        boolean boolean15 = barRenderer6.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer6.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = itemLabelPosition17.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor19 = itemLabelPosition17.getRotationAnchor();
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition17, false);
        boolean boolean22 = barRenderer0.getBaseCreateEntities();
        boolean boolean23 = barRenderer0.getAutoPopulateSeriesOutlineStroke();
        barRenderer0.setDefaultEntityRadius(3);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.awt.Color color0 = java.awt.Color.WHITE;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10L, jFreeChart1, chartChangeEventType2);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer0.setBaseItemLabelFont(font1, false);
        boolean boolean5 = barRenderer0.isSeriesVisible((int) (short) 1);
        barRenderer0.setShadowXOffset((double) 10);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = categoryAxis11.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D17, rectangleEdge18);
        java.awt.Font font20 = categoryAxis11.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis11.setTickLabelInsets(rectangleInsets21);
        categoryAxis11.setVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = categoryAxis25.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D31, rectangleEdge32);
        java.awt.Font font34 = categoryAxis25.getTickLabelFont();
        java.awt.Font font35 = categoryAxis25.getTickLabelFont();
        categoryAxis11.setLabelFont(font35);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D44 = barRenderer0.createHotSpotBounds(graphics2D8, rectangle2D9, categoryPlot10, categoryAxis11, valueAxis37, categoryDataset38, 8, (int) (short) 0, true, categoryItemRendererState42, rectangle2D43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(font35);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis0.setTickLabelInsets(rectangleInsets10);
        categoryAxis0.setVisible(true);
        java.awt.Paint paint14 = categoryAxis0.getAxisLinePaint();
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getSeriesNegativeItemLabelPosition(0);
        java.awt.Color color12 = java.awt.Color.YELLOW;
        barRenderer0.setBaseLegendTextPaint((java.awt.Paint) color12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer14.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer14.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color20 = java.awt.Color.RED;
        barRenderer14.setShadowPaint((java.awt.Paint) color20);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator22 = barRenderer14.getLegendItemLabelGenerator();
        barRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator22);
        boolean boolean24 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.renderer.category.BarPainter barPainter25 = null;
        try {
            barRenderer0.setBarPainter(barPainter25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.clearSeriesStrokes(true);
        boolean boolean6 = barRenderer0.isItemLabelVisible((int) (byte) 0, (int) (byte) -1, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 100, (int) (byte) 0, false);
        java.awt.Paint paint14 = barRenderer0.getItemPaint((int) (short) 0, 0, true);
        java.awt.Color color15 = java.awt.Color.lightGray;
        barRenderer0.setBaseLegendTextPaint((java.awt.Paint) color15);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        try {
            barRenderer0.setSeriesStroke((-2097346), stroke18, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-1.0f), (double) (short) 100, (double) (-1.0f), (double) (short) 100);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets5.createOutsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis0.setTickLabelInsets(rectangleInsets10);
        categoryAxis0.setMinorTickMarkOutsideLength((-1.0f));
        java.awt.Font font14 = categoryAxis0.getTickLabelFont();
        java.awt.Font font16 = categoryAxis0.getTickLabelFont((java.lang.Comparable) (byte) 100);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        try {
            org.jfree.chart.axis.AxisState axisState23 = categoryAxis0.draw(graphics2D17, (double) 100L, rectangle2D19, rectangle2D20, rectangleEdge21, plotRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis0.setTickLabelInsets(rectangleInsets10);
        double double13 = rectangleInsets10.trimWidth((double) '#');
        double double14 = rectangleInsets10.getRight();
        double double16 = rectangleInsets10.calculateLeftInset((double) (-1.0f));
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 19.0d + "'", double13 == 19.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 8.0d + "'", double14 == 8.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 8.0d + "'", double16 == 8.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesShapesFilled((int) (byte) 100);
        boolean boolean5 = lineAndShapeRenderer0.getBaseLinesVisible();
        lineAndShapeRenderer0.setSeriesShapesVisible((int) (short) 1, true);
        boolean boolean9 = lineAndShapeRenderer0.getBaseCreateEntities();
        boolean boolean12 = lineAndShapeRenderer0.getItemShapeVisible((int) ' ', (int) (short) -1);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = null;
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset18 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup19 = abstractCategoryDataset18.getGroup();
        boolean boolean21 = datasetGroup19.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis22.setLowerMargin(0.0d);
        categoryAxis22.setLowerMargin((double) 1L);
        boolean boolean27 = datasetGroup19.equals((java.lang.Object) categoryAxis22);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState33 = null;
        try {
            boolean boolean34 = lineAndShapeRenderer0.hitTest((double) 1, 0.0d, graphics2D15, rectangle2D16, categoryPlot17, categoryAxis22, valueAxis28, categoryDataset29, 0, 100, false, categoryItemRendererState33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(datasetGroup19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer0.setSeriesStroke(0, stroke5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer7.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer7.setSeriesStroke(0, stroke12);
        barRenderer0.setBaseOutlineStroke(stroke12, true);
        barRenderer0.clearSeriesStrokes(true);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.Color color22 = java.awt.Color.RED;
        java.awt.Stroke stroke23 = null;
        try {
            barRenderer0.drawDomainLine(graphics2D18, categoryPlot19, rectangle2D20, Double.NaN, (java.awt.Paint) color22, stroke23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesShapesFilled((int) (byte) 100);
        boolean boolean5 = lineAndShapeRenderer0.getBaseLinesVisible();
        lineAndShapeRenderer0.setSeriesShapesVisible((int) (short) 1, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int10 = color9.getTransparency();
        java.awt.Color color11 = color9.brighter();
        lineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color9);
        lineAndShapeRenderer0.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset20 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup21 = abstractCategoryDataset20.getGroup();
        boolean boolean23 = datasetGroup21.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis24.setLowerMargin(0.0d);
        categoryAxis24.setLowerMargin((double) 1L);
        boolean boolean29 = datasetGroup21.equals((java.lang.Object) categoryAxis24);
        boolean boolean30 = defaultDrawingSupplier19.equals((java.lang.Object) categoryAxis24);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        try {
            lineAndShapeRenderer0.drawItem(graphics2D15, categoryItemRendererState16, rectangle2D17, categoryPlot18, categoryAxis24, valueAxis31, categoryDataset32, 1, (int) 'a', true, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(datasetGroup21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        int int7 = color6.getGreen();
        barRenderer5.setBaseOutlinePaint((java.awt.Paint) color6);
        java.awt.Shape shape12 = barRenderer5.getItemShape((int) '4', (int) (byte) 100, true);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Paint paint16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis17.setLowerMargin(0.0d);
        categoryAxis17.setLowerMargin((double) 1L);
        boolean boolean22 = categoryAxis17.isAxisLineVisible();
        categoryAxis17.setLowerMargin(4.0d);
        float float25 = categoryAxis17.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer26.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer26.setSeriesStroke(0, stroke31);
        org.jfree.chart.renderer.category.BarRenderer barRenderer33 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer33.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer33.setSeriesStroke(0, stroke38);
        barRenderer26.setBaseOutlineStroke(stroke38, true);
        categoryAxis17.setTickMarkStroke(stroke38);
        org.jfree.chart.renderer.category.BarRenderer barRenderer52 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape54 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer52.setLegendShape(100, shape54);
        java.awt.Stroke stroke56 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint57 = null;
        org.jfree.chart.LegendItem legendItem58 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape54, stroke56, paint57);
        java.awt.Color color60 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color61 = java.awt.Color.getColor("hi!", color60);
        org.jfree.chart.LegendItem legendItem62 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape54, (java.awt.Paint) color60);
        org.jfree.chart.entity.ChartEntity chartEntity63 = new org.jfree.chart.entity.ChartEntity(shape54);
        java.awt.Stroke stroke64 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color65 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        try {
            org.jfree.chart.LegendItem legendItem66 = new org.jfree.chart.LegendItem("rect", "{0}", "rect", "AxisLocation.BOTTOM_OR_LEFT", true, shape12, true, (java.awt.Paint) color14, false, paint16, stroke38, true, shape54, stroke64, (java.awt.Paint) color65);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'outlinePaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 255 + "'", int7 == 255);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(color65);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.util.PaintList paintList1 = new org.jfree.chart.util.PaintList();
        boolean boolean2 = shapeList0.equals((java.lang.Object) paintList1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        java.awt.Font font10 = categoryAxis0.getTickLabelFont();
        java.lang.String str11 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) (byte) 10);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        barRenderer0.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer6.setLegendShape(100, shape8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer6.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint14 = barRenderer6.getBaseItemLabelPaint();
        boolean boolean15 = barRenderer6.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer6.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = itemLabelPosition17.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor19 = itemLabelPosition17.getRotationAnchor();
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition17, false);
        boolean boolean22 = barRenderer0.getBaseCreateEntities();
        boolean boolean23 = barRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        barRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color25);
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer27.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer27.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color33 = java.awt.Color.RED;
        barRenderer27.setShadowPaint((java.awt.Paint) color33);
        java.awt.Color color35 = java.awt.Color.ORANGE;
        float[] floatArray40 = new float[] { ' ', (byte) 10, (byte) 1, 100 };
        float[] floatArray41 = color35.getRGBComponents(floatArray40);
        float[] floatArray42 = color33.getColorComponents(floatArray40);
        float[] floatArray43 = color25.getRGBColorComponents(floatArray42);
        java.awt.color.ColorSpace colorSpace44 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer45 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer45.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer45.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color51 = java.awt.Color.RED;
        barRenderer45.setShadowPaint((java.awt.Paint) color51);
        java.awt.Color color53 = java.awt.Color.ORANGE;
        float[] floatArray58 = new float[] { ' ', (byte) 10, (byte) 1, 100 };
        float[] floatArray59 = color53.getRGBComponents(floatArray58);
        float[] floatArray60 = color51.getColorComponents(floatArray58);
        try {
            float[] floatArray61 = color25.getComponents(colorSpace44, floatArray58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertNotNull(floatArray60);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Font font6 = null;
        barRenderer0.setBaseLegendTextFont(font6);
        barRenderer0.setBaseItemLabelsVisible(true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.util.SortOrder sortOrder12 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis13.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D19, rectangleEdge20);
        java.lang.String str22 = categoryAxis13.getLabel();
        categoryAxis13.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = categoryAxis25.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D31, rectangleEdge32);
        java.awt.Font font34 = categoryAxis25.getTickLabelFont();
        categoryAxis13.setLabelFont(font34);
        categoryAxis13.setAxisLineVisible(true);
        java.awt.Paint paint38 = categoryAxis13.getLabelPaint();
        boolean boolean39 = sortOrder12.equals((java.lang.Object) categoryAxis13);
        org.jfree.chart.plot.CategoryMarker categoryMarker40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        try {
            barRenderer0.drawDomainMarker(graphics2D10, categoryPlot11, categoryAxis13, categoryMarker40, rectangle2D41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sortOrder12);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.lang.String str2 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GradientPaintTransformType.VERTICAL" + "'", str2.equals("GradientPaintTransformType.VERTICAL"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer4.setLegendShape(100, shape6);
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint9 = null;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape6, stroke8, paint9);
        java.lang.String str11 = legendItem10.getURLText();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = legendItem10.getFillPaintTransformer();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis13.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D19, rectangleEdge20);
        java.awt.Font font22 = categoryAxis13.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis13.setTickLabelInsets(rectangleInsets23);
        categoryAxis13.setMinorTickMarkOutsideLength((-1.0f));
        java.awt.Font font27 = categoryAxis13.getTickLabelFont();
        java.awt.Font font29 = categoryAxis13.getTickLabelFont((java.lang.Comparable) (byte) 100);
        legendItem10.setLabelFont(font29);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer31 = legendItem10.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(gradientPaintTransformer12);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(gradientPaintTransformer31);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer4.setLegendShape(100, shape6);
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint9 = null;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape6, stroke8, paint9);
        java.lang.String str11 = legendItem10.getURLText();
        java.lang.Object obj12 = legendItem10.clone();
        boolean boolean13 = legendItem10.isShapeFilled();
        legendItem10.setToolTipText("NOID");
        legendItem10.setDescription("hi!");
        java.lang.Comparable comparable18 = legendItem10.getSeriesKey();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(comparable18);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color6 = java.awt.Color.RED;
        barRenderer0.setShadowPaint((java.awt.Paint) color6);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = barRenderer0.getLegendItemLabelGenerator();
        barRenderer0.setShadowYOffset(100.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer11.setLegendShape(100, shape13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = barRenderer11.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint19 = barRenderer11.getBaseItemLabelPaint();
        boolean boolean20 = barRenderer11.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = barRenderer11.getSeriesNegativeItemLabelPosition(0);
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition22);
        java.awt.Font font25 = null;
        barRenderer0.setLegendTextFont((int) '4', font25);
        java.awt.Paint paint28 = barRenderer0.getSeriesPaint((int) '4');
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier31 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset32 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup33 = abstractCategoryDataset32.getGroup();
        boolean boolean35 = datasetGroup33.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis36.setLowerMargin(0.0d);
        categoryAxis36.setLowerMargin((double) 1L);
        boolean boolean41 = datasetGroup33.equals((java.lang.Object) categoryAxis36);
        boolean boolean42 = defaultDrawingSupplier31.equals((java.lang.Object) categoryAxis36);
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.util.Layer layer44 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        try {
            barRenderer0.drawAnnotations(graphics2D29, rectangle2D30, categoryAxis36, valueAxis43, layer44, plotRenderingInfo45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNotNull(datasetGroup33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        barRenderer0.clearSeriesPaints(false);
        java.awt.Paint paint9 = barRenderer0.getSeriesItemLabelPaint(1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = barRenderer0.getSeriesItemLabelGenerator((int) '#');
        barRenderer0.setIncludeBaseInRange(true);
        java.awt.Color color14 = java.awt.Color.cyan;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color14, false);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        int int2 = color1.getGreen();
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color1);
        java.awt.Stroke stroke5 = null;
        barRenderer0.setSeriesOutlineStroke(0, stroke5);
        java.awt.Paint paint8 = barRenderer0.getSeriesOutlinePaint((int) (byte) 100);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        float[] floatArray5 = new float[] { 100L, (byte) 0 };
        try {
            float[] floatArray6 = java.awt.Color.RGBtoHSB(100, (int) (byte) -1, 0, floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis0.setTickLabelInsets(rectangleInsets10);
        categoryAxis0.setVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis14.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D20, rectangleEdge21);
        java.awt.Font font23 = categoryAxis14.getTickLabelFont();
        java.awt.Font font24 = categoryAxis14.getTickLabelFont();
        categoryAxis0.setLabelFont(font24);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        try {
            double double32 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) 0.2d, (java.lang.Comparable) (byte) 0, categoryDataset28, 100.0d, rectangle2D30, rectangleEdge31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(font24);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.lang.String str9 = categoryAxis0.getLabel();
        categoryAxis0.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis12.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D18, rectangleEdge19);
        java.awt.Font font21 = categoryAxis12.getTickLabelFont();
        categoryAxis0.setLabelFont(font21);
        categoryAxis0.setAxisLineVisible(true);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor25 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor25, (int) (byte) 0, (int) '4', rectangle2D28, rectangleEdge29);
        org.jfree.chart.event.AxisChangeListener axisChangeListener31 = null;
        categoryAxis0.removeChangeListener(axisChangeListener31);
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.axis.AxisState axisState34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        try {
            java.util.List list37 = categoryAxis0.refreshTicks(graphics2D33, axisState34, rectangle2D35, rectangleEdge36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(categoryAnchor25);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int1 = color0.getTransparency();
        java.awt.Color color2 = color0.brighter();
        int int3 = color2.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer8.setLegendShape(100, shape10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint13 = null;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape10, stroke12, paint13);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color16);
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape10, (java.awt.Paint) color16);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape10);
        java.lang.String str20 = chartEntity19.getShapeCoords();
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-4,-4,4,4" + "'", str20.equals("-4,-4,4,4"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer8.setLegendShape(100, shape10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint13 = null;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape10, stroke12, paint13);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color16);
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape10, (java.awt.Paint) color16);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape10);
        chartEntity19.setToolTipText("NOID");
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8, false);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.data.Range range13 = barRenderer0.findRangeBounds(categoryDataset11, false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color16);
        barRenderer0.setSeriesPaint((int) (short) 100, (java.awt.Paint) color17, false);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState32 = null;
        try {
            boolean boolean33 = barRenderer0.hitTest((double) 10.0f, (double) 100, graphics2D22, rectangle2D23, categoryPlot24, categoryAxis26, valueAxis27, categoryDataset28, (int) (short) 10, 3, false, categoryItemRendererState32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        double double8 = barRenderer0.getItemMargin();
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean11 = barRenderer0.isSeriesVisibleInLegend((int) (short) 1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("AxisLocation.BOTTOM_OR_LEFT", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color6 = java.awt.Color.RED;
        barRenderer0.setShadowPaint((java.awt.Paint) color6);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = barRenderer0.getLegendItemLabelGenerator();
        barRenderer0.setShadowYOffset(100.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer11.setLegendShape(100, shape13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = barRenderer11.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint19 = barRenderer11.getBaseItemLabelPaint();
        boolean boolean20 = barRenderer11.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = barRenderer11.getSeriesNegativeItemLabelPosition(0);
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition22);
        java.awt.Font font25 = null;
        barRenderer0.setLegendTextFont((int) '4', font25);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = barRenderer0.getNegativeItemLabelPositionFallback();
        barRenderer0.setDefaultEntityRadius((int) (short) 0);
        java.awt.Stroke stroke31 = barRenderer0.getSeriesOutlineStroke((int) '4');
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNull(stroke31);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesShapesFilled((int) (byte) 100);
        boolean boolean5 = lineAndShapeRenderer0.getBaseLinesVisible();
        lineAndShapeRenderer0.setSeriesShapesVisible((int) (short) 1, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int10 = color9.getTransparency();
        java.awt.Color color11 = color9.brighter();
        lineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color9);
        lineAndShapeRenderer0.setBaseShapesVisible(true);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-1.0f), (double) (short) 100, (double) (-1.0f), (double) (short) 100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer6.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer6.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Font font12 = null;
        barRenderer6.setBaseLegendTextFont(font12);
        barRenderer6.removeAnnotations();
        boolean boolean15 = unitType0.equals((java.lang.Object) barRenderer6);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseOutlinePaint(false);
        boolean boolean3 = lineAndShapeRenderer0.getUseSeriesOffset();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        barRenderer0.clearSeriesPaints(false);
        java.awt.Paint paint9 = barRenderer0.getSeriesItemLabelPaint(1);
        barRenderer0.setItemLabelAnchorOffset((double) (byte) 10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        try {
            barRenderer0.drawDomainLine(graphics2D12, categoryPlot13, rectangle2D14, (double) 2.0f, (java.awt.Paint) color16, stroke17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE9" + "'", str1.equals("ItemLabelAnchor.OUTSIDE9"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        int int2 = color1.getGreen();
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color1);
        java.awt.Font font4 = barRenderer0.getBaseItemLabelFont();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        barRenderer0.setBaseLegendTextPaint((java.awt.Paint) color5);
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendItem8.setLinePaint((java.awt.Paint) color9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer19.setLegendShape(100, shape21);
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint24 = null;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape21, stroke23, paint24);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color28 = java.awt.Color.getColor("hi!", color27);
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape21, (java.awt.Paint) color27);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape21);
        legendItem8.setLine(shape21);
        java.awt.Paint paint32 = legendItem8.getFillPaint();
        barRenderer0.setBaseOutlinePaint(paint32, true);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8, false);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.data.Range range13 = barRenderer0.findRangeBounds(categoryDataset11, false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color16);
        barRenderer0.setSeriesPaint((int) (short) 100, (java.awt.Paint) color17, false);
        boolean boolean21 = barRenderer0.isSeriesVisible(0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D7, rectangleEdge8);
        java.lang.String str10 = categoryAxis1.getLabel();
        categoryAxis1.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis13.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D19, rectangleEdge20);
        java.awt.Font font22 = categoryAxis13.getTickLabelFont();
        categoryAxis1.setLabelFont(font22);
        categoryAxis1.setAxisLineVisible(true);
        java.awt.Paint paint26 = categoryAxis1.getLabelPaint();
        boolean boolean27 = sortOrder0.equals((java.lang.Object) categoryAxis1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer28.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer28.setAutoPopulateSeriesOutlinePaint(true);
        barRenderer28.clearSeriesPaints(false);
        java.awt.Paint paint37 = barRenderer28.getSeriesItemLabelPaint(1);
        barRenderer28.removeAnnotations();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator40 = barRenderer28.getSeriesToolTipGenerator((int) (short) 0);
        boolean boolean41 = sortOrder0.equals((java.lang.Object) (short) 0);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(paint37);
        org.junit.Assert.assertNull(categoryToolTipGenerator40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color6 = java.awt.Color.RED;
        barRenderer0.setShadowPaint((java.awt.Paint) color6);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = barRenderer0.getLegendItemLabelGenerator();
        java.awt.Paint paint10 = barRenderer0.lookupSeriesPaint((int) '4');
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis0.setTickLabelInsets(rectangleInsets10);
        double double13 = rectangleInsets10.trimWidth((double) '#');
        double double15 = rectangleInsets10.trimWidth((double) 100L);
        double double16 = rectangleInsets10.getLeft();
        double double18 = rectangleInsets10.calculateRightOutset((double) (-1L));
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            rectangleInsets10.trim(rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 19.0d + "'", double13 == 19.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 84.0d + "'", double15 == 84.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 8.0d + "'", double16 == 8.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.0d + "'", double18 == 8.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        boolean boolean2 = axisLocation0.equals((java.lang.Object) color1);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendItem1.setLinePaint((java.awt.Paint) color2);
        java.text.AttributedString attributedString4 = legendItem1.getAttributedLabel();
        boolean boolean5 = legendItem1.isShapeVisible();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(attributedString4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer1.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer1.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color7 = java.awt.Color.RED;
        barRenderer1.setShadowPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = barRenderer1.getLegendItemLabelGenerator();
        lineAndShapeRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator9);
        java.util.EventListener eventListener11 = null;
        boolean boolean12 = lineAndShapeRenderer0.hasListener(eventListener11);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color6 = java.awt.Color.RED;
        barRenderer0.setShadowPaint((java.awt.Paint) color6);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = barRenderer0.getLegendItemLabelGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator10, true);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Paint paint2 = paintList0.getPaint((int) (byte) 0);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        paintList0.setPaint((int) (byte) 0, (java.awt.Paint) color4);
        java.awt.Paint paint7 = paintList0.getPaint((-1));
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        barRenderer0.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer6.setLegendShape(100, shape8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer6.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint14 = barRenderer6.getBaseItemLabelPaint();
        boolean boolean15 = barRenderer6.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer6.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = itemLabelPosition17.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor19 = itemLabelPosition17.getRotationAnchor();
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition17, false);
        boolean boolean22 = barRenderer0.getBaseCreateEntities();
        boolean boolean23 = barRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType24 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer25 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType24);
        barRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer25);
        java.lang.Object obj27 = standardGradientPaintTransformer25.clone();
        java.awt.GradientPaint gradientPaint28 = null;
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        try {
            java.awt.GradientPaint gradientPaint30 = standardGradientPaintTransformer25.transform(gradientPaint28, shape29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformType24);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer8.setLegendShape(100, shape10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint13 = null;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape10, stroke12, paint13);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color16);
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape10, (java.awt.Paint) color16);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape10);
        java.lang.String str20 = chartEntity19.getShapeType();
        java.lang.String str21 = chartEntity19.getToolTipText();
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "rect" + "'", str20.equals("rect"));
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color6 = java.awt.Color.RED;
        barRenderer0.setShadowPaint((java.awt.Paint) color6);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = barRenderer0.getLegendItemLabelGenerator();
        barRenderer0.setShadowYOffset(100.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer11.setLegendShape(100, shape13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = barRenderer11.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint19 = barRenderer11.getBaseItemLabelPaint();
        boolean boolean20 = barRenderer11.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = barRenderer11.getSeriesNegativeItemLabelPosition(0);
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition22);
        org.jfree.chart.LegendItem legendItem26 = barRenderer0.getLegendItem(2, (int) '4');
        barRenderer0.setBase(3.0d);
        java.awt.Paint paint30 = barRenderer0.lookupSeriesFillPaint(100);
        java.awt.Stroke stroke32 = barRenderer0.getSeriesStroke(3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNull(legendItem26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(stroke32);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer4.setLegendShape(100, shape6);
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint9 = null;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape6, stroke8, paint9);
        java.lang.String str11 = legendItem10.getURLText();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer12.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer12.setSeriesStroke(0, stroke17);
        java.awt.Paint paint20 = barRenderer12.lookupSeriesPaint((-1));
        legendItem10.setLabelPaint(paint20);
        java.awt.Shape shape22 = legendItem10.getLine();
        org.jfree.chart.plot.Plot plot23 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity26 = new org.jfree.chart.entity.PlotEntity(shape22, plot23, "AxisLocation.BOTTOM_OR_RIGHT", "GradientPaintTransformType.VERTICAL");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis0.setTickLabelInsets(rectangleInsets10);
        double double13 = rectangleInsets10.trimWidth((double) '#');
        double double15 = rectangleInsets10.trimWidth((double) 100L);
        double double17 = rectangleInsets10.calculateLeftInset((double) 1);
        double double19 = rectangleInsets10.calculateRightOutset((double) '4');
        java.lang.String str20 = rectangleInsets10.toString();
        double double22 = rectangleInsets10.extendWidth((double) (byte) 100);
        double double24 = rectangleInsets10.calculateLeftInset((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets10.createInsetRectangle(rectangle2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 19.0d + "'", double13 == 19.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 84.0d + "'", double15 == 84.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str20.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 116.0d + "'", double22 == 116.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 8.0d + "'", double24 == 8.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        barRenderer0.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer7.setLegendShape(100, shape9);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = barRenderer7.getURLGenerator(10, (int) (byte) 1, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = null;
        barRenderer7.setBaseToolTipGenerator(categoryToolTipGenerator15, false);
        boolean boolean18 = barRenderer7.getAutoPopulateSeriesPaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor19 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor19, textAnchor20, textAnchor21, Double.NaN);
        barRenderer7.setBasePositiveItemLabelPosition(itemLabelPosition23, true);
        try {
            barRenderer0.setSeriesPositiveItemLabelPosition((int) (short) -1, itemLabelPosition23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(categoryURLGenerator14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(itemLabelAnchor19);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(textAnchor21);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor12 = itemLabelPosition11.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor13 = itemLabelPosition11.getRotationAnchor();
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        boolean boolean15 = textAnchor13.equals((java.lang.Object) axisLocation14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer16.setLegendShape(100, shape18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator23 = barRenderer16.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint24 = barRenderer16.getBaseItemLabelPaint();
        boolean boolean25 = barRenderer16.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer16);
        boolean boolean27 = axisLocation14.equals((java.lang.Object) chartChangeEvent26);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer28.setUseOutlinePaint(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator34 = lineAndShapeRenderer28.getURLGenerator(10, (int) 'a', false);
        boolean boolean35 = lineAndShapeRenderer28.getBaseSeriesVisible();
        lineAndShapeRenderer28.setSeriesShapesFilled(10, true);
        boolean boolean39 = axisLocation14.equals((java.lang.Object) lineAndShapeRenderer28);
        try {
            lineAndShapeRenderer28.setSeriesCreateEntities((-2097346), (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(itemLabelAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(categoryURLGenerator23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(categoryURLGenerator34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer0.setSeriesStroke(0, stroke5);
        java.awt.Paint paint8 = barRenderer0.lookupSeriesPaint((-1));
        org.jfree.chart.LegendItem legendItem11 = barRenderer0.getLegendItem((-2097346), 1);
        boolean boolean15 = barRenderer0.getItemCreateEntity((-2097346), (int) (short) 10, false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        try {
            double double16 = barRenderer0.getItemMiddle((java.lang.Comparable) (short) 0, (java.lang.Comparable) 2, categoryDataset12, categoryAxis13, rectangle2D14, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(itemLabelPosition9);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.awt.Paint paint0 = null;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] { paint0 };
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray3 = new java.awt.Paint[] {};
        java.awt.Stroke stroke4 = null;
        java.awt.Stroke[] strokeArray5 = new java.awt.Stroke[] { stroke4 };
        java.awt.Stroke[] strokeArray6 = null;
        java.awt.Shape shape7 = null;
        java.awt.Shape[] shapeArray8 = new java.awt.Shape[] { shape7 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray2, paintArray3, strokeArray5, strokeArray6, shapeArray8);
        java.awt.Stroke stroke10 = defaultDrawingSupplier9.getNextStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = categoryAxis11.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D17, rectangleEdge18);
        java.lang.String str20 = categoryAxis11.getLabel();
        categoryAxis11.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        double double31 = categoryAxis23.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D29, rectangleEdge30);
        java.awt.Font font32 = categoryAxis23.getTickLabelFont();
        categoryAxis11.setLabelFont(font32);
        categoryAxis11.setAxisLineVisible(true);
        java.awt.Paint paint36 = categoryAxis11.getLabelPaint();
        boolean boolean37 = defaultDrawingSupplier9.equals((java.lang.Object) paint36);
        try {
            java.awt.Stroke stroke38 = defaultDrawingSupplier9.getNextOutlineStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(shapeArray8);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesShapesFilled((int) (byte) 100);
        boolean boolean5 = lineAndShapeRenderer0.getBaseLinesVisible();
        lineAndShapeRenderer0.setSeriesShapesVisible((int) (short) 1, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int10 = color9.getTransparency();
        java.awt.Color color11 = color9.brighter();
        lineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color9);
        java.lang.Object obj13 = lineAndShapeRenderer0.clone();
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.clearSeriesStrokes(true);
        boolean boolean6 = barRenderer0.isItemLabelVisible((int) (byte) 0, (int) (byte) -1, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 100, (int) (byte) 0, false);
        java.awt.Paint paint14 = barRenderer0.getItemPaint((int) (short) 0, 0, true);
        barRenderer0.setShadowVisible(false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        barRenderer0.drawRangeMarker(graphics2D4, categoryPlot5, valueAxis6, marker7, rectangle2D8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState15 = barRenderer0.initialise(graphics2D10, rectangle2D11, categoryPlot12, categoryDataset13, plotRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer0.setSeriesStroke(0, stroke5);
        java.awt.Paint paint8 = barRenderer0.lookupSeriesPaint((-1));
        barRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        boolean boolean12 = barRenderer0.removeAnnotation(categoryAnnotation11);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.lang.String str9 = categoryAxis0.getLabel();
        categoryAxis0.setLabelURL("hi!");
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis0.getCategoryEnd(100, 0, rectangle2D14, rectangleEdge15);
        categoryAxis0.setCategoryLabelPositionOffset((int) (byte) 100);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.AxisState axisState20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        try {
            java.util.List list23 = categoryAxis0.refreshTicks(graphics2D19, axisState20, rectangle2D21, rectangleEdge22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getDrawOutlines();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = lineAndShapeRenderer0.hasListener(eventListener2);
        java.awt.Font font5 = lineAndShapeRenderer0.getLegendTextFont((int) (short) -1);
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendItem8.setLinePaint((java.awt.Paint) color9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer19.setLegendShape(100, shape21);
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint24 = null;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape21, stroke23, paint24);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color28 = java.awt.Color.getColor("hi!", color27);
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape21, (java.awt.Paint) color27);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape21);
        legendItem8.setLine(shape21);
        java.awt.Paint paint32 = legendItem8.getFillPaint();
        try {
            lineAndShapeRenderer0.setSeriesOutlinePaint((-2097346), paint32, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Font font6 = null;
        barRenderer0.setBaseLegendTextFont(font6);
        barRenderer0.setBaseItemLabelsVisible(true);
        java.lang.Boolean boolean11 = barRenderer0.getSeriesVisible((int) (byte) -1);
        org.junit.Assert.assertNull(boolean11);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        barRenderer0.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer6.setLegendShape(100, shape8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer6.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint14 = barRenderer6.getBaseItemLabelPaint();
        boolean boolean15 = barRenderer6.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer6.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = itemLabelPosition17.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor19 = itemLabelPosition17.getRotationAnchor();
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition17, false);
        barRenderer0.setIncludeBaseInRange(false);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        try {
            barRenderer0.drawOutline(graphics2D24, categoryPlot25, rectangle2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer8.setLegendShape(100, shape10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint13 = null;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape10, stroke12, paint13);
        java.awt.Color color15 = java.awt.Color.orange;
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer16.setLegendShape(100, shape18);
        barRenderer16.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer22.setLegendShape(100, shape24);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator29 = barRenderer22.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint30 = barRenderer22.getBaseItemLabelPaint();
        boolean boolean31 = barRenderer22.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = barRenderer22.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor34 = itemLabelPosition33.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor35 = itemLabelPosition33.getRotationAnchor();
        barRenderer16.setBasePositiveItemLabelPosition(itemLabelPosition33, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer42 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape44 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer42.setLegendShape(100, shape44);
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint47 = null;
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape44, stroke46, paint47);
        java.lang.String str49 = legendItem48.getURLText();
        java.lang.Object obj50 = legendItem48.clone();
        boolean boolean51 = itemLabelPosition33.equals((java.lang.Object) legendItem48);
        legendItem48.setShapeVisible(true);
        legendItem48.setSeriesKey((java.lang.Comparable) 10.0d);
        java.lang.String str56 = legendItem48.getLabel();
        java.awt.Stroke stroke57 = legendItem48.getOutlineStroke();
        org.jfree.chart.LegendItem legendItem59 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Color color60 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendItem59.setLinePaint((java.awt.Paint) color60);
        try {
            org.jfree.chart.LegendItem legendItem62 = new org.jfree.chart.LegendItem(attributedString0, "GradientPaintTransformType.VERTICAL", "", "AxisLocation.BOTTOM_OR_LEFT", shape10, (java.awt.Paint) color15, stroke57, (java.awt.Paint) color60);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(categoryURLGenerator29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertNotNull(itemLabelAnchor34);
        org.junit.Assert.assertNotNull(textAnchor35);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "hi!" + "'", str49.equals("hi!"));
        org.junit.Assert.assertNotNull(obj50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "hi!" + "'", str56.equals("hi!"));
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(color60);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesShapesFilled((int) (byte) 100);
        boolean boolean5 = lineAndShapeRenderer0.getBaseLinesVisible();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            lineAndShapeRenderer0.drawOutline(graphics2D6, categoryPlot7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (byte) 100, categoryToolTipGenerator10, false);
        boolean boolean16 = barRenderer0.isItemLabelVisible(0, (int) (byte) 1, false);
        org.jfree.chart.event.RendererChangeListener rendererChangeListener17 = null;
        try {
            barRenderer0.removeChangeListener(rendererChangeListener17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor12 = itemLabelPosition11.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor13 = itemLabelPosition11.getRotationAnchor();
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        boolean boolean15 = textAnchor13.equals((java.lang.Object) axisLocation14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer16.setLegendShape(100, shape18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator23 = barRenderer16.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint24 = barRenderer16.getBaseItemLabelPaint();
        boolean boolean25 = barRenderer16.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer16);
        boolean boolean27 = axisLocation14.equals((java.lang.Object) chartChangeEvent26);
        java.lang.String str28 = chartChangeEvent26.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(itemLabelAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(categoryURLGenerator23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.lang.String str9 = categoryAxis0.getLabel();
        categoryAxis0.setLabelURL("hi!");
        org.jfree.chart.plot.Plot plot12 = null;
        categoryAxis0.setPlot(plot12);
        boolean boolean14 = categoryAxis0.isVisible();
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin(0.0d);
        categoryAxis0.setLowerMargin((double) 1L);
        boolean boolean5 = categoryAxis0.isAxisLineVisible();
        boolean boolean6 = categoryAxis0.isTickLabelsVisible();
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke9 = renderAttributes7.getSeriesStroke((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer11.setLegendShape(100, shape13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = barRenderer11.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint19 = barRenderer11.getBaseItemLabelPaint();
        renderAttributes7.setSeriesPaint((int) 'a', paint19);
        java.awt.Color color21 = java.awt.Color.gray;
        renderAttributes7.setDefaultFillPaint((java.awt.Paint) color21);
        categoryAxis0.setTickMarkPaint((java.awt.Paint) color21);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = categoryAxis24.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D30, rectangleEdge31);
        java.lang.String str33 = categoryAxis24.getLabel();
        categoryAxis24.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = null;
        double double44 = categoryAxis36.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D42, rectangleEdge43);
        java.awt.Font font45 = categoryAxis36.getTickLabelFont();
        categoryAxis24.setLabelFont(font45);
        categoryAxis24.setAxisLineVisible(true);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor49 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        double double54 = categoryAxis24.getCategoryJava2DCoordinate(categoryAnchor49, (int) (byte) 0, (int) '4', rectangle2D52, rectangleEdge53);
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        org.jfree.chart.axis.AxisLocation axisLocation58 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str59 = axisLocation58.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation60 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation58, plotOrientation60);
        try {
            double double62 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor49, (int) '4', (int) (short) 100, rectangle2D57, rectangleEdge61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(categoryAnchor49);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str59.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertNotNull(plotOrientation60);
        org.junit.Assert.assertNotNull(rectangleEdge61);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin(0.0d);
        categoryAxis0.setLowerMargin((double) 1L);
        boolean boolean5 = categoryAxis0.isAxisLineVisible();
        categoryAxis0.setLowerMargin(4.0d);
        float float8 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer9.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer9.setSeriesStroke(0, stroke14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer16.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer16.setSeriesStroke(0, stroke21);
        barRenderer9.setBaseOutlineStroke(stroke21, true);
        categoryAxis0.setTickMarkStroke(stroke21);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.plot.Plot plot27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str30 = axisLocation29.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation31 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation29, plotOrientation31);
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace34 = categoryAxis0.reserveSpace(graphics2D26, plot27, rectangle2D28, rectangleEdge32, axisSpace33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str30.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertNotNull(plotOrientation31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        try {
            java.awt.Color color1 = java.awt.Color.decode("AxisLocation.BOTTOM_OR_RIGHT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"AxisLocation.BOTTOM_OR_RIGHT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis0.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.plot.Plot plot12 = categoryAxis0.getPlot();
        categoryAxis0.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis14.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D20, rectangleEdge21);
        java.awt.Font font23 = categoryAxis14.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis14.setTickLabelInsets(rectangleInsets24);
        double double27 = rectangleInsets24.trimWidth((double) '#');
        double double29 = rectangleInsets24.trimWidth((double) 100L);
        double double31 = rectangleInsets24.calculateLeftInset((double) 1);
        double double33 = rectangleInsets24.calculateRightOutset((double) '4');
        java.lang.String str34 = rectangleInsets24.toString();
        double double35 = rectangleInsets24.getBottom();
        categoryAxis0.setLabelInsets(rectangleInsets24, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer38 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape40 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer38.setLegendShape(100, shape40);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator45 = barRenderer38.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint46 = barRenderer38.getBaseItemLabelPaint();
        boolean boolean47 = barRenderer38.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition49 = barRenderer38.getSeriesNegativeItemLabelPosition(0);
        java.awt.Color color50 = java.awt.Color.YELLOW;
        barRenderer38.setBaseLegendTextPaint((java.awt.Paint) color50);
        float[] floatArray52 = null;
        float[] floatArray53 = color50.getRGBComponents(floatArray52);
        categoryAxis0.setTickMarkPaint((java.awt.Paint) color50);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 19.0d + "'", double27 == 19.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 84.0d + "'", double29 == 84.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 8.0d + "'", double31 == 8.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 8.0d + "'", double33 == 8.0d);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str34.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 4.0d + "'", double35 == 4.0d);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNull(categoryURLGenerator45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(floatArray53);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8, false);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = categoryAxis16.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D22, rectangleEdge23);
        java.lang.String str25 = categoryAxis16.getLabel();
        categoryAxis16.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        double double36 = categoryAxis28.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D34, rectangleEdge35);
        java.awt.Font font37 = categoryAxis28.getTickLabelFont();
        categoryAxis16.setLabelFont(font37);
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState44 = null;
        try {
            boolean boolean45 = barRenderer0.hitTest((double) 1, (double) (-1.0f), graphics2D13, rectangle2D14, categoryPlot15, categoryAxis16, valueAxis39, categoryDataset40, 3, (int) ' ', true, categoryItemRendererState44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font37);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer1.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer1.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color7 = java.awt.Color.RED;
        barRenderer1.setShadowPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = barRenderer1.getLegendItemLabelGenerator();
        lineAndShapeRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator9);
        boolean boolean14 = lineAndShapeRenderer0.isItemLabelVisible(255, 0, true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Paint paint6 = barRenderer0.getBaseOutlinePaint();
        double double7 = barRenderer0.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        try {
            barRenderer0.setSeriesStroke((-2097346), stroke9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0);
        java.lang.Object obj11 = chartChangeEvent10.getSource();
        java.lang.Object obj12 = chartChangeEvent10.getSource();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        chartChangeEvent10.setType(chartChangeEventType13);
        java.lang.Object obj15 = chartChangeEvent10.getSource();
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        chartChangeEvent10.setChart(jFreeChart16);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(chartChangeEventType13);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int2 = color1.getTransparency();
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator6 = new org.jfree.chart.util.DefaultShadowGenerator((int) '4', color1, 10.0f, (int) (short) 100, (double) (byte) 1);
        int int7 = defaultShadowGenerator6.calculateOffsetX();
        int int8 = defaultShadowGenerator6.calculateOffsetY();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-136) + "'", int8 == (-136));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D7, rectangleEdge8);
        java.lang.String str10 = categoryAxis1.getLabel();
        categoryAxis1.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis13.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D19, rectangleEdge20);
        java.awt.Font font22 = categoryAxis13.getTickLabelFont();
        categoryAxis1.setLabelFont(font22);
        categoryAxis1.setAxisLineVisible(true);
        java.awt.Paint paint26 = categoryAxis1.getLabelPaint();
        boolean boolean27 = sortOrder0.equals((java.lang.Object) categoryAxis1);
        categoryAxis1.setMinorTickMarkInsideLength((float) 10L);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8, false);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.data.Range range13 = barRenderer0.findRangeBounds(categoryDataset11, false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color16);
        barRenderer0.setSeriesPaint((int) (short) 100, (java.awt.Paint) color17, false);
        barRenderer0.setBaseCreateEntities(false, false);
        barRenderer0.setBaseItemLabelsVisible(true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color6 = java.awt.Color.RED;
        barRenderer0.setShadowPaint((java.awt.Paint) color6);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = barRenderer0.getLegendItemLabelGenerator();
        barRenderer0.setShadowYOffset(100.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer11.setLegendShape(100, shape13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = barRenderer11.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint19 = barRenderer11.getBaseItemLabelPaint();
        boolean boolean20 = barRenderer11.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = barRenderer11.getSeriesNegativeItemLabelPosition(0);
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition22);
        org.jfree.chart.LegendItem legendItem26 = barRenderer0.getLegendItem(2, (int) '4');
        java.awt.Paint paint27 = barRenderer0.getBasePaint();
        double double28 = barRenderer0.getMinimumBarLength();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNull(legendItem26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.lang.String str9 = categoryAxis0.getLabel();
        categoryAxis0.setUpperMargin((double) (byte) 10);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 10, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke15 = barRenderer0.getBaseOutlineStroke();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        java.awt.Font font10 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor11, (int) ' ', (int) (byte) 100, rectangle2D14, rectangleEdge15);
        categoryAxis0.setAxisLineVisible(true);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str23 = axisLocation22.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation22, plotOrientation24);
        try {
            double double26 = categoryAxis0.getCategoryStart((-1), (int) (short) 100, rectangle2D21, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(categoryAnchor11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str23.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-1.0f), (double) (short) 100, (double) (-1.0f), (double) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) 1, 4.0d, (double) (-1L), 19.0d);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D14 = rectangleInsets10.createInsetRectangle(rectangle2D11, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape2 = renderAttributes0.getSeriesShape((int) (byte) 100);
        java.awt.Paint paint4 = null;
        renderAttributes0.setSeriesOutlinePaint((int) '4', paint4);
        java.awt.Paint paint6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        renderAttributes0.setDefaultFillPaint(paint6);
        try {
            java.lang.Boolean boolean9 = renderAttributes0.getSeriesCreateEntity(100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendItem3.setLinePaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer14.setLegendShape(100, shape16);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint19 = null;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape16, stroke18, paint19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color23 = java.awt.Color.getColor("hi!", color22);
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape16, (java.awt.Paint) color22);
        org.jfree.chart.entity.ChartEntity chartEntity25 = new org.jfree.chart.entity.ChartEntity(shape16);
        legendItem3.setLine(shape16);
        legendItemCollection1.add(legendItem3);
        legendItemCollection0.add(legendItem3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(0, (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer4.setLegendShape(100, shape6);
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint9 = null;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape6, stroke8, paint9);
        java.lang.String str11 = legendItem10.getURLText();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = legendItem10.getFillPaintTransformer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer13.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer13.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color19 = java.awt.Color.RED;
        barRenderer13.setShadowPaint((java.awt.Paint) color19);
        int int21 = color19.getTransparency();
        legendItem10.setOutlinePaint((java.awt.Paint) color19);
        java.text.AttributedString attributedString23 = legendItem10.getAttributedLabel();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(gradientPaintTransformer12);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(attributedString23);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color6 = java.awt.Color.RED;
        barRenderer0.setShadowPaint((java.awt.Paint) color6);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = barRenderer0.getLegendItemLabelGenerator();
        barRenderer0.setShadowYOffset(100.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer11.setLegendShape(100, shape13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = barRenderer11.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint19 = barRenderer11.getBaseItemLabelPaint();
        boolean boolean20 = barRenderer11.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = barRenderer11.getSeriesNegativeItemLabelPosition(0);
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition22);
        org.jfree.chart.LegendItem legendItem26 = barRenderer0.getLegendItem(2, (int) '4');
        java.awt.Paint paint27 = barRenderer0.getBasePaint();
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis33.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D39, rectangleEdge40);
        java.awt.Font font42 = categoryAxis33.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis33.setTickLabelInsets(rectangleInsets43);
        categoryAxis33.setVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState52 = null;
        try {
            boolean boolean53 = barRenderer0.hitTest((double) 0, (double) (short) 0, graphics2D30, rectangle2D31, categoryPlot32, categoryAxis33, valueAxis47, categoryDataset48, (int) '4', 2, true, categoryItemRendererState52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNull(legendItem26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertEquals((double) double41, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(rectangleInsets43);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer8.setLegendShape(100, shape10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint13 = null;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape10, stroke12, paint13);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color16);
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape10, (java.awt.Paint) color16);
        org.jfree.chart.plot.Plot plot19 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity22 = new org.jfree.chart.entity.PlotEntity(shape10, plot19, "AxisLocation.BOTTOM_OR_LEFT", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        barRenderer0.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer6.setLegendShape(100, shape8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer6.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint14 = barRenderer6.getBaseItemLabelPaint();
        boolean boolean15 = barRenderer6.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer6.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = itemLabelPosition17.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor19 = itemLabelPosition17.getRotationAnchor();
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition17, false);
        boolean boolean22 = barRenderer0.getBaseCreateEntities();
        boolean boolean23 = barRenderer0.getAutoPopulateSeriesStroke();
        barRenderer0.setSeriesItemLabelsVisible(1, (java.lang.Boolean) true, true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((-1), (int) '4', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer0.setBaseItemLabelFont(font1, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        int int6 = color5.getGreen();
        barRenderer4.setBaseOutlinePaint((java.awt.Paint) color5);
        java.awt.Font font8 = barRenderer4.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font8, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        boolean boolean12 = barRenderer0.removeAnnotation(categoryAnnotation11);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        boolean boolean9 = categoryAxis0.isMinorTickMarksVisible();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str14 = axisLocation13.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation13, plotOrientation15);
        try {
            double double17 = categoryAxis0.getCategoryMiddle((int) (byte) 10, (int) (byte) 0, rectangle2D12, rectangleEdge16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str14.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        barRenderer0.setShadowXOffset((double) 'a');
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendItem7.setLinePaint((java.awt.Paint) color8);
        java.text.AttributedString attributedString10 = legendItem7.getAttributedLabel();
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer11.setLegendShape(100, shape13);
        legendItem7.setShape(shape13);
        barRenderer0.setBaseShape(shape13);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            barRenderer0.drawOutline(graphics2D17, categoryPlot18, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(attributedString10);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = abstractCategoryDataset0.getGroup();
        boolean boolean3 = datasetGroup1.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis4.setLowerMargin(0.0d);
        categoryAxis4.setLowerMargin((double) 1L);
        boolean boolean9 = datasetGroup1.equals((java.lang.Object) categoryAxis4);
        java.lang.Object obj10 = datasetGroup1.clone();
        java.lang.String str11 = datasetGroup1.getID();
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "NOID" + "'", str11.equals("NOID"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke2 = renderAttributes0.getSeriesStroke((int) (byte) -1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape(8, 10);
        boolean boolean6 = renderAttributes0.getAllowNull();
        org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendItem9.setLinePaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer16.setLegendShape(100, shape18);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint21 = null;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape18, stroke20, paint21);
        legendItem9.setShape(shape18);
        try {
            renderAttributes0.setSeriesShape((int) (byte) -1, shape18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color6 = java.awt.Color.RED;
        barRenderer0.setShadowPaint((java.awt.Paint) color6);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = barRenderer0.getLegendItemLabelGenerator();
        barRenderer0.setShadowYOffset(100.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer11.setLegendShape(100, shape13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = barRenderer11.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint19 = barRenderer11.getBaseItemLabelPaint();
        boolean boolean20 = barRenderer11.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = barRenderer11.getSeriesNegativeItemLabelPosition(0);
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition22);
        org.jfree.chart.LegendItem legendItem26 = barRenderer0.getLegendItem(2, (int) '4');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = barRenderer0.getSeriesPositiveItemLabelPosition((int) (short) 100);
        barRenderer0.setItemLabelAnchorOffset((double) (-1L));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNull(legendItem26);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        barRenderer0.setShadowXOffset((double) 'a');
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendItem7.setLinePaint((java.awt.Paint) color8);
        java.text.AttributedString attributedString10 = legendItem7.getAttributedLabel();
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer11.setLegendShape(100, shape13);
        legendItem7.setShape(shape13);
        barRenderer0.setBaseShape(shape13);
        barRenderer0.setMinimumBarLength(84.0d);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis22.setLowerMargin(0.0d);
        categoryAxis22.setLowerMargin((double) 1L);
        boolean boolean27 = categoryAxis22.isAxisLineVisible();
        categoryAxis22.setLowerMargin(4.0d);
        float float30 = categoryAxis22.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.renderer.category.BarRenderer barRenderer31 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer31.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer31.setSeriesStroke(0, stroke36);
        org.jfree.chart.renderer.category.BarRenderer barRenderer38 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer38.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer38.setSeriesStroke(0, stroke43);
        barRenderer31.setBaseOutlineStroke(stroke43, true);
        categoryAxis22.setTickMarkStroke(stroke43);
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D55 = barRenderer0.createHotSpotBounds(graphics2D19, rectangle2D20, categoryPlot21, categoryAxis22, valueAxis48, categoryDataset49, 2, 3, true, categoryItemRendererState53, rectangle2D54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(attributedString10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.0f + "'", float30 == 0.0f);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        barRenderer0.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer6.setLegendShape(100, shape8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer6.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint14 = barRenderer6.getBaseItemLabelPaint();
        boolean boolean15 = barRenderer6.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer6.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = itemLabelPosition17.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor19 = itemLabelPosition17.getRotationAnchor();
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition17, false);
        boolean boolean22 = barRenderer0.getBaseCreateEntities();
        int int23 = barRenderer0.getPassCount();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis0.setTickLabelInsets(rectangleInsets10);
        categoryAxis0.setVisible(true);
        categoryAxis0.setLowerMargin((-16.0d));
        int int16 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setLabelURL("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.lang.String str9 = categoryAxis0.getLabel();
        categoryAxis0.setLabelURL("hi!");
        org.jfree.chart.plot.Plot plot12 = null;
        categoryAxis0.setPlot(plot12);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        try {
            double double18 = categoryAxis0.getCategoryMiddle((int) '#', (-1), rectangle2D16, rectangleEdge17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 35");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        barRenderer0.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer6.setLegendShape(100, shape8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer6.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint14 = barRenderer6.getBaseItemLabelPaint();
        boolean boolean15 = barRenderer6.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer6.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = itemLabelPosition17.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor19 = itemLabelPosition17.getRotationAnchor();
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition17, false);
        boolean boolean22 = barRenderer0.getBaseCreateEntities();
        boolean boolean23 = barRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType24 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer25 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType24);
        barRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer25);
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformType24);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = barRenderer0.getItemLabelGenerator((int) (byte) 100, 0, true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator15);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "{0}", "AxisLocation.BOTTOM_OR_RIGHT");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator4 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator5 = null;
        try {
            java.lang.String str6 = chartEntity3.getImageMapAreaTag(toolTipTagFragmentGenerator4, uRLTagFragmentGenerator5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-1.0f), (double) (short) 100, (double) (-1.0f), (double) (short) 100);
        double double7 = rectangleInsets5.calculateBottomOutset((double) 255);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets5.createOutsetRectangle(rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke2 = renderAttributes0.getSeriesStroke((int) (byte) -1);
        java.awt.Shape shape3 = renderAttributes0.getDefaultShape();
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNull(shape3);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint3 = defaultDrawingSupplier2.getNextFillPaint();
        java.awt.Paint paint4 = defaultDrawingSupplier2.getNextPaint();
        boolean boolean5 = gradientPaintTransformType0.equals((java.lang.Object) paint4);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("AxisLocation.BOTTOM_OR_RIGHT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseSeriesOffset(true);
        lineAndShapeRenderer0.setUseSeriesOffset(false);
        lineAndShapeRenderer0.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer8.setLegendShape(100, shape10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint13 = null;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape10, stroke12, paint13);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color16);
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape10, (java.awt.Paint) color16);
        legendItem18.setURLText("NOID");
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8, false);
        boolean boolean11 = barRenderer0.getAutoPopulateSeriesPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer12.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer12.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color18 = java.awt.Color.RED;
        barRenderer12.setShadowPaint((java.awt.Paint) color18);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator20 = barRenderer12.getLegendItemLabelGenerator();
        barRenderer12.setShadowYOffset(100.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer23.setLegendShape(100, shape25);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator30 = barRenderer23.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint31 = barRenderer23.getBaseItemLabelPaint();
        boolean boolean32 = barRenderer23.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = barRenderer23.getSeriesNegativeItemLabelPosition(0);
        barRenderer12.setNegativeItemLabelPositionFallback(itemLabelPosition34);
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition34);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator40 = barRenderer0.getItemLabelGenerator((int) (short) 1, (int) (byte) 10, true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator20);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNull(categoryURLGenerator30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition34);
        org.junit.Assert.assertNull(categoryItemLabelGenerator40);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Font font6 = null;
        barRenderer0.setBaseLegendTextFont(font6);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        java.lang.Object obj10 = standardCategorySeriesLabelGenerator8.clone();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        try {
            java.lang.String str13 = standardCategorySeriesLabelGenerator8.generateLabel(categoryDataset11, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer0.setBaseItemLabelFont(font1, false);
        boolean boolean5 = barRenderer0.isSeriesVisible((int) (short) 1);
        barRenderer0.setShadowXOffset((double) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (byte) 1, categoryToolTipGenerator9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer0.setSeriesItemLabelGenerator(3, categoryItemLabelGenerator13, false);
        java.awt.Stroke stroke19 = barRenderer0.getItemOutlineStroke(4, 3, true);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int1 = color0.getTransparency();
        java.awt.Color color2 = color0.brighter();
        java.awt.Color color3 = color2.brighter();
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color3.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintContext9);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        java.awt.Font font10 = categoryAxis0.getTickLabelFont();
        java.lang.String str11 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer12.setBaseShapesFilled(true);
        java.lang.Boolean boolean16 = lineAndShapeRenderer12.getSeriesShapesFilled((int) (byte) 100);
        boolean boolean17 = lineAndShapeRenderer12.getBaseLinesVisible();
        boolean boolean18 = categoryAxis0.equals((java.lang.Object) boolean17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str23 = axisLocation22.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation22, plotOrientation24);
        org.jfree.chart.axis.AxisState axisState26 = null;
        categoryAxis0.drawTickMarks(graphics2D19, (double) (-2097346), rectangle2D21, rectangleEdge25, axisState26);
        categoryAxis0.setMaximumCategoryLabelLines((int) ' ');
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str23.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.plot.Plot plot4 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity7 = new org.jfree.chart.entity.PlotEntity(shape2, plot4, "ChartEntity: tooltip = null", "PlotOrientation.VERTICAL");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.LegendItem legendItem5 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendItem5.setLinePaint((java.awt.Paint) color6);
        java.text.AttributedString attributedString8 = legendItem5.getAttributedLabel();
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer9.setLegendShape(100, shape11);
        legendItem5.setShape(shape11);
        java.awt.Color color14 = java.awt.Color.YELLOW;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = categoryAxis15.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D21, rectangleEdge22);
        java.awt.Font font24 = categoryAxis15.getTickLabelFont();
        categoryAxis15.setLabel("hi!");
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer27.setLegendShape(100, shape29);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator34 = barRenderer27.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint35 = barRenderer27.getBaseItemLabelPaint();
        boolean boolean36 = barRenderer27.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = barRenderer27.getSeriesNegativeItemLabelPosition(0);
        java.awt.Color color39 = java.awt.Color.YELLOW;
        barRenderer27.setBaseLegendTextPaint((java.awt.Paint) color39);
        categoryAxis15.setTickLabelPaint((java.awt.Paint) color39);
        categoryAxis15.setMaximumCategoryLabelLines((int) (short) 100);
        double double44 = categoryAxis15.getLowerMargin();
        java.awt.Stroke stroke45 = categoryAxis15.getAxisLineStroke();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier46 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint47 = defaultDrawingSupplier46.getNextFillPaint();
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "{0}", "{0}", shape11, (java.awt.Paint) color14, stroke45, paint47);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(attributedString8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNull(categoryURLGenerator34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.05d + "'", double44 == 0.05d);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin(0.0d);
        categoryAxis0.setLowerMargin((double) 1L);
        boolean boolean5 = categoryAxis0.isAxisLineVisible();
        categoryAxis0.setLowerMargin(4.0d);
        float float8 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer9.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer9.setSeriesStroke(0, stroke14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer16.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer16.setSeriesStroke(0, stroke21);
        barRenderer9.setBaseOutlineStroke(stroke21, true);
        categoryAxis0.setTickMarkStroke(stroke21);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = categoryAxis26.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D32, rectangleEdge33);
        java.awt.Font font35 = categoryAxis26.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis26.setTickLabelInsets(rectangleInsets36);
        double double39 = rectangleInsets36.trimWidth((double) '#');
        double double41 = rectangleInsets36.trimWidth((double) 100L);
        double double42 = rectangleInsets36.getLeft();
        categoryAxis0.setLabelInsets(rectangleInsets36, true);
        double double46 = rectangleInsets36.calculateRightInset((double) 1L);
        double double48 = rectangleInsets36.calculateTopOutset((-2097346.0d));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 19.0d + "'", double39 == 19.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 84.0d + "'", double41 == 84.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 8.0d + "'", double42 == 8.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 8.0d + "'", double46 == 8.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 4.0d + "'", double48 == 4.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        boolean boolean5 = lineAndShapeRenderer0.getItemShapeVisible(1, (int) (short) 0);
        java.awt.Paint paint7 = lineAndShapeRenderer0.getSeriesPaint(255);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-2097346), 0.0d, 0.05d, (double) 1);
        double double6 = rectangleInsets5.getTop();
        double double8 = rectangleInsets5.calculateBottomInset((double) 2.0f);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-2097346.0d) + "'", double6 == (-2097346.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.awt.Color color1 = java.awt.Color.getColor("AxisLocation.BOTTOM_OR_RIGHT");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState1 = null;
        abstractCategoryDataset0.setSelectionState(categoryDatasetSelectionState1);
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState3 = abstractCategoryDataset0.getSelectionState();
        org.jfree.data.general.DatasetGroup datasetGroup4 = abstractCategoryDataset0.getGroup();
        org.junit.Assert.assertNull(categoryDatasetSelectionState3);
        org.junit.Assert.assertNotNull(datasetGroup4);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str1 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str1.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        barRenderer0.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer6.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer6.setSeriesStroke(0, stroke11);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer13.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer13.setSeriesStroke(0, stroke18);
        barRenderer6.setBaseOutlineStroke(stroke18, true);
        barRenderer0.setBaseStroke(stroke18);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int24 = color23.getTransparency();
        barRenderer0.setShadowPaint((java.awt.Paint) color23);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator29 = barRenderer0.getToolTipGenerator((int) (byte) -1, 10, true);
        java.awt.Paint paint30 = barRenderer0.getShadowPaint();
        int int31 = barRenderer0.getPassCount();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNull(categoryToolTipGenerator29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getSeriesNegativeItemLabelPosition(0);
        java.awt.Color color12 = java.awt.Color.YELLOW;
        barRenderer0.setBaseLegendTextPaint((java.awt.Paint) color12);
        org.jfree.chart.event.RendererChangeListener rendererChangeListener14 = null;
        try {
            barRenderer0.addChangeListener(rendererChangeListener14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator11, false);
        barRenderer0.setSeriesCreateEntities((int) '#', (java.lang.Boolean) true, false);
        int int18 = barRenderer0.getPassCount();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer8.setLegendShape(100, shape10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint13 = null;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape10, stroke12, paint13);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color16);
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape10, (java.awt.Paint) color16);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape10);
        java.lang.String str20 = chartEntity19.getShapeType();
        java.lang.String str21 = chartEntity19.getShapeCoords();
        boolean boolean23 = chartEntity19.equals((java.lang.Object) (-1L));
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "rect" + "'", str20.equals("rect"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "-4,-4,4,4" + "'", str21.equals("-4,-4,4,4"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color6 = java.awt.Color.RED;
        barRenderer0.setShadowPaint((java.awt.Paint) color6);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = barRenderer0.getLegendItemLabelGenerator();
        barRenderer0.setShadowYOffset(100.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer11.setLegendShape(100, shape13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = barRenderer11.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint19 = barRenderer11.getBaseItemLabelPaint();
        boolean boolean20 = barRenderer11.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = barRenderer11.getSeriesNegativeItemLabelPosition(0);
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition22);
        org.jfree.chart.LegendItem legendItem26 = barRenderer0.getLegendItem(2, (int) '4');
        barRenderer0.setAutoPopulateSeriesFillPaint(false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNull(legendItem26);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke2 = renderAttributes0.getSeriesStroke((int) (byte) -1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape(8, 10);
        java.awt.Paint paint7 = renderAttributes0.getSeriesFillPaint((int) (short) 0);
        java.awt.Stroke stroke8 = renderAttributes0.getDefaultOutlineStroke();
        java.awt.Shape shape10 = null;
        renderAttributes0.setSeriesShape(0, shape10);
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNull(stroke8);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color6 = java.awt.Color.RED;
        barRenderer0.setShadowPaint((java.awt.Paint) color6);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = barRenderer0.getLegendItemLabelGenerator();
        barRenderer0.setShadowYOffset(100.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer11.setLegendShape(100, shape13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = barRenderer11.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint19 = barRenderer11.getBaseItemLabelPaint();
        boolean boolean20 = barRenderer11.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = barRenderer11.getSeriesNegativeItemLabelPosition(0);
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition22);
        org.jfree.chart.LegendItem legendItem26 = barRenderer0.getLegendItem(2, (int) '4');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = barRenderer0.getSeriesPositiveItemLabelPosition((int) (short) 100);
        org.jfree.chart.text.TextAnchor textAnchor29 = itemLabelPosition28.getTextAnchor();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNull(legendItem26);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertNotNull(textAnchor29);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.lang.String str9 = categoryAxis0.getLabel();
        categoryAxis0.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis12.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D18, rectangleEdge19);
        java.awt.Font font21 = categoryAxis12.getTickLabelFont();
        categoryAxis0.setLabelFont(font21);
        categoryAxis0.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer25.clearSeriesStrokes(true);
        boolean boolean31 = barRenderer25.isItemLabelVisible((int) (byte) 0, (int) (byte) -1, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = barRenderer25.getNegativeItemLabelPosition((int) (byte) 100, (int) (byte) 0, false);
        java.awt.Paint paint39 = barRenderer25.getItemPaint((int) (short) 0, 0, true);
        java.awt.Color color40 = java.awt.Color.lightGray;
        barRenderer25.setBaseLegendTextPaint((java.awt.Paint) color40);
        boolean boolean42 = categoryAxis0.equals((java.lang.Object) barRenderer25);
        java.awt.Paint paint44 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        try {
            barRenderer25.setSeriesFillPaint((int) (byte) -1, paint44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        barRenderer0.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer6.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer6.setSeriesStroke(0, stroke11);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer13.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer13.setSeriesStroke(0, stroke18);
        barRenderer6.setBaseOutlineStroke(stroke18, true);
        barRenderer0.setBaseStroke(stroke18);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int24 = color23.getTransparency();
        barRenderer0.setShadowPaint((java.awt.Paint) color23);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        double double38 = categoryAxis30.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D36, rectangleEdge37);
        java.lang.String str39 = categoryAxis30.getLabel();
        categoryAxis30.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = null;
        double double50 = categoryAxis42.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D48, rectangleEdge49);
        java.awt.Font font51 = categoryAxis42.getTickLabelFont();
        categoryAxis30.setLabelFont(font51);
        categoryAxis30.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer55 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer55.clearSeriesStrokes(true);
        boolean boolean61 = barRenderer55.isItemLabelVisible((int) (byte) 0, (int) (byte) -1, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition65 = barRenderer55.getNegativeItemLabelPosition((int) (byte) 100, (int) (byte) 0, false);
        java.awt.Paint paint69 = barRenderer55.getItemPaint((int) (short) 0, 0, true);
        java.awt.Color color70 = java.awt.Color.lightGray;
        barRenderer55.setBaseLegendTextPaint((java.awt.Paint) color70);
        boolean boolean72 = categoryAxis30.equals((java.lang.Object) barRenderer55);
        org.jfree.chart.axis.ValueAxis valueAxis73 = null;
        org.jfree.data.category.CategoryDataset categoryDataset74 = null;
        try {
            barRenderer0.drawItem(graphics2D26, categoryItemRendererState27, rectangle2D28, categoryPlot29, categoryAxis30, valueAxis73, categoryDataset74, (-1), (int) (byte) -1, false, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertEquals((double) double50, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition65);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        barRenderer0.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer6.setLegendShape(100, shape8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer6.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint14 = barRenderer6.getBaseItemLabelPaint();
        boolean boolean15 = barRenderer6.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer6.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = itemLabelPosition17.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor19 = itemLabelPosition17.getRotationAnchor();
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition17, false);
        boolean boolean22 = barRenderer0.getBaseCreateEntities();
        boolean boolean23 = barRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Stroke stroke25 = barRenderer0.getSeriesOutlineStroke((int) 'a');
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(stroke25);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Font font6 = null;
        barRenderer0.setBaseLegendTextFont(font6);
        barRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = barRenderer0.getItemLabelGenerator(0, 255, true);
        barRenderer0.setBaseItemLabelsVisible(false, false);
        boolean boolean17 = barRenderer0.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer8.setLegendShape(100, shape10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint13 = null;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape10, stroke12, paint13);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color16);
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape10, (java.awt.Paint) color16);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape10);
        java.lang.String str20 = chartEntity19.getShapeType();
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer21.setLegendShape(100, shape23);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator28 = barRenderer21.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint29 = barRenderer21.getBaseItemLabelPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator31 = null;
        barRenderer21.setSeriesToolTipGenerator((int) (byte) 100, categoryToolTipGenerator31, false);
        boolean boolean37 = barRenderer21.isItemLabelVisible(0, (int) (byte) 1, false);
        boolean boolean38 = chartEntity19.equals((java.lang.Object) boolean37);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "rect" + "'", str20.equals("rect"));
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNull(categoryURLGenerator28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin(0.0d);
        categoryAxis0.setLowerMargin((double) 1L);
        boolean boolean5 = categoryAxis0.isAxisLineVisible();
        boolean boolean6 = categoryAxis0.isTickLabelsVisible();
        categoryAxis0.setAxisLineVisible(true);
        java.awt.Paint paint10 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer3.clearSeriesStrokes(true);
        boolean boolean9 = barRenderer3.isItemLabelVisible((int) (byte) 0, (int) (byte) -1, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer3.getNegativeItemLabelPosition((int) (byte) 100, (int) (byte) 0, false);
        java.awt.Paint paint17 = barRenderer3.getItemPaint((int) (short) 0, 0, true);
        try {
            objectList1.set((-1), (java.lang.Object) barRenderer3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        barRenderer0.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer6.setLegendShape(100, shape8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer6.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint14 = barRenderer6.getBaseItemLabelPaint();
        boolean boolean15 = barRenderer6.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer6.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = itemLabelPosition17.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor19 = itemLabelPosition17.getRotationAnchor();
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition17, false);
        boolean boolean22 = barRenderer0.getBaseCreateEntities();
        boolean boolean23 = barRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType24 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer25 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType24);
        barRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer25);
        java.lang.Object obj27 = standardGradientPaintTransformer25.clone();
        java.awt.GradientPaint gradientPaint28 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer29 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer29.setLegendShape(100, shape31);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator36 = barRenderer29.getURLGenerator(10, (int) (byte) 1, false);
        double double37 = barRenderer29.getItemMargin();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = barRenderer29.getURLGenerator((int) (short) 100, (-1), false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer43 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer43.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer43.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color49 = java.awt.Color.RED;
        barRenderer43.setShadowPaint((java.awt.Paint) color49);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator51 = barRenderer43.getLegendItemLabelGenerator();
        barRenderer43.setShadowYOffset(100.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer54 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape56 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer54.setLegendShape(100, shape56);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator61 = barRenderer54.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint62 = barRenderer54.getBaseItemLabelPaint();
        boolean boolean63 = barRenderer54.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition65 = barRenderer54.getSeriesNegativeItemLabelPosition(0);
        barRenderer43.setNegativeItemLabelPositionFallback(itemLabelPosition65);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator67 = null;
        barRenderer43.setBaseURLGenerator(categoryURLGenerator67, false);
        java.awt.Shape shape70 = barRenderer43.getBaseShape();
        barRenderer29.setSeriesShape(2, shape70, true);
        try {
            java.awt.GradientPaint gradientPaint73 = standardGradientPaintTransformer25.transform(gradientPaint28, shape70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformType24);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(categoryURLGenerator36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.2d + "'", double37 == 0.2d);
        org.junit.Assert.assertNull(categoryURLGenerator41);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator51);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNull(categoryURLGenerator61);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition65);
        org.junit.Assert.assertNotNull(shape70);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin(0.0d);
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        categoryAxis0.removeChangeListener(axisChangeListener3);
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) "-4,-4,4,4", "ChartEntity: tooltip = null");
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.lang.String str9 = categoryAxis0.getLabel();
        categoryAxis0.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis12.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D18, rectangleEdge19);
        java.awt.Font font21 = categoryAxis12.getTickLabelFont();
        categoryAxis0.setLabelFont(font21);
        categoryAxis0.setTickMarkInsideLength((float) (-1));
        float float25 = categoryAxis0.getTickMarkInsideLength();
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        try {
            double double32 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) 0.05d, (java.lang.Comparable) "AxisLocation.BOTTOM_OR_LEFT", categoryDataset28, (double) 0.0f, rectangle2D30, rectangleEdge31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + (-1.0f) + "'", float25 == (-1.0f));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis0.setTickLabelInsets(rectangleInsets10);
        categoryAxis0.setVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis14.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D20, rectangleEdge21);
        java.awt.Font font23 = categoryAxis14.getTickLabelFont();
        java.awt.Font font24 = categoryAxis14.getTickLabelFont();
        categoryAxis0.setLabelFont(font24);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions26 = categoryAxis0.getCategoryLabelPositions();
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = categoryAxis32.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D38, rectangleEdge39);
        java.awt.Font font41 = categoryAxis32.getTickLabelFont();
        java.awt.Font font42 = categoryAxis32.getTickLabelFont();
        java.lang.String str43 = categoryAxis32.getLabelToolTip();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer44 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer44.setBaseShapesFilled(true);
        java.lang.Boolean boolean48 = lineAndShapeRenderer44.getSeriesShapesFilled((int) (byte) 100);
        boolean boolean49 = lineAndShapeRenderer44.getBaseLinesVisible();
        boolean boolean50 = categoryAxis32.equals((java.lang.Object) boolean49);
        java.awt.Graphics2D graphics2D51 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.axis.AxisLocation axisLocation54 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str55 = axisLocation54.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation54, plotOrientation56);
        org.jfree.chart.axis.AxisState axisState58 = null;
        categoryAxis32.drawTickMarks(graphics2D51, (double) (-2097346), rectangle2D53, rectangleEdge57, axisState58);
        try {
            double double60 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) 1.0f, (java.lang.Comparable) 1.0d, categoryDataset29, (double) 8, rectangle2D31, rectangleEdge57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(categoryLabelPositions26);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNull(boolean48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str55.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNotNull(rectangleEdge57);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis0.setTickLabelInsets(rectangleInsets10);
        categoryAxis0.setVisible(true);
        int int14 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = categoryAxis0.getCategoryLabelPositions();
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions15);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        java.awt.Font font10 = categoryAxis0.getTickLabelFont();
        java.lang.String str11 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer12.setBaseShapesFilled(true);
        java.lang.Boolean boolean16 = lineAndShapeRenderer12.getSeriesShapesFilled((int) (byte) 100);
        boolean boolean17 = lineAndShapeRenderer12.getBaseLinesVisible();
        boolean boolean18 = categoryAxis0.equals((java.lang.Object) boolean17);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = categoryAxis19.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D25, rectangleEdge26);
        java.awt.Font font28 = categoryAxis19.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis19.setTickLabelInsets(rectangleInsets29);
        double double32 = rectangleInsets29.trimWidth((double) '#');
        double double34 = rectangleInsets29.trimWidth((double) 100L);
        double double36 = rectangleInsets29.calculateLeftInset((double) 1);
        double double38 = rectangleInsets29.calculateRightOutset((double) '4');
        java.lang.String str39 = rectangleInsets29.toString();
        double double41 = rectangleInsets29.extendWidth((double) (byte) 100);
        categoryAxis0.setLabelInsets(rectangleInsets29);
        double double44 = rectangleInsets29.calculateBottomOutset(3.0d);
        double double46 = rectangleInsets29.trimHeight(0.0d);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 19.0d + "'", double32 == 19.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 84.0d + "'", double34 == 84.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 8.0d + "'", double36 == 8.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 8.0d + "'", double38 == 8.0d);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str39.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 116.0d + "'", double41 == 116.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 4.0d + "'", double44 == 4.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + (-8.0d) + "'", double46 == (-8.0d));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        barRenderer0.clearSeriesPaints(false);
        java.awt.Paint paint9 = barRenderer0.getSeriesItemLabelPaint(1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = barRenderer0.getSeriesItemLabelGenerator((int) '#');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator12);
        java.awt.Shape shape15 = barRenderer0.getLegendShape(5);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
        org.junit.Assert.assertNull(shape15);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("GradientPaintTransformType.VERTICAL", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color6 = java.awt.Color.RED;
        barRenderer0.setShadowPaint((java.awt.Paint) color6);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = barRenderer0.getLegendItemLabelGenerator();
        barRenderer0.setShadowYOffset(100.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer11.setLegendShape(100, shape13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = barRenderer11.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint19 = barRenderer11.getBaseItemLabelPaint();
        boolean boolean20 = barRenderer11.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = barRenderer11.getSeriesNegativeItemLabelPosition(0);
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition22);
        org.jfree.chart.LegendItem legendItem26 = barRenderer0.getLegendItem(2, (int) '4');
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator27 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator27);
        org.jfree.chart.LegendItemCollection legendItemCollection29 = barRenderer0.getLegendItems();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNull(legendItem26);
        org.junit.Assert.assertNotNull(legendItemCollection29);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis0.setTickLabelInsets(rectangleInsets10);
        categoryAxis0.setVisible(true);
        categoryAxis0.setLowerMargin((-16.0d));
        categoryAxis0.setUpperMargin((double) 8);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendItem1.setLinePaint((java.awt.Paint) color2);
        java.text.AttributedString attributedString4 = legendItem1.getAttributedLabel();
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer5.setLegendShape(100, shape7);
        legendItem1.setShape(shape7);
        boolean boolean10 = legendItem1.isShapeOutlineVisible();
        boolean boolean11 = legendItem1.isShapeFilled();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(attributedString4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 2.0f, (double) (-1L), (double) 'a', (double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        categoryAxis0.setLabel("hi!");
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer12.setLegendShape(100, shape14);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = barRenderer12.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint20 = barRenderer12.getBaseItemLabelPaint();
        boolean boolean21 = barRenderer12.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = barRenderer12.getSeriesNegativeItemLabelPosition(0);
        java.awt.Color color24 = java.awt.Color.YELLOW;
        barRenderer12.setBaseLegendTextPaint((java.awt.Paint) color24);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color24);
        double double27 = categoryAxis0.getCategoryMargin();
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNull(categoryURLGenerator19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.2d + "'", double27 == 0.2d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        booleanList0.setBoolean((int) (short) 100, (java.lang.Boolean) true);
        java.lang.Boolean boolean5 = booleanList0.getBoolean(4);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendItem1.setLinePaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer12.setLegendShape(100, shape14);
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint17 = null;
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape14, stroke16, paint17);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color21 = java.awt.Color.getColor("hi!", color20);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape14, (java.awt.Paint) color20);
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity(shape14);
        legendItem1.setLine(shape14);
        java.awt.Paint paint25 = legendItem1.getFillPaint();
        java.lang.String str26 = legendItem1.getURLText();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(str26);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        booleanList0.setBoolean((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean5 = booleanList0.equals((java.lang.Object) (-2097346));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer4.setLegendShape(100, shape6);
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint9 = null;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape6, stroke8, paint9);
        java.lang.String str11 = legendItem10.getURLText();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = legendItem10.getFillPaintTransformer();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis13.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D19, rectangleEdge20);
        java.awt.Font font22 = categoryAxis13.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis13.setTickLabelInsets(rectangleInsets23);
        categoryAxis13.setMinorTickMarkOutsideLength((-1.0f));
        java.awt.Font font27 = categoryAxis13.getTickLabelFont();
        java.awt.Font font29 = categoryAxis13.getTickLabelFont((java.lang.Comparable) (byte) 100);
        legendItem10.setLabelFont(font29);
        java.awt.Paint paint31 = legendItem10.getFillPaint();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(gradientPaintTransformer12);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getDrawOutlines();
        boolean boolean2 = lineAndShapeRenderer0.getBaseLinesVisible();
        lineAndShapeRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        boolean boolean5 = lineAndShapeRenderer0.getUseOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer0.getBasePositiveItemLabelPosition();
        java.lang.Boolean boolean8 = lineAndShapeRenderer0.getSeriesVisible(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNull(boolean8);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        int int2 = color1.getGreen();
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color1);
        java.awt.Stroke stroke5 = null;
        barRenderer0.setSeriesOutlineStroke(0, stroke5);
        java.awt.Paint paint7 = barRenderer0.getBasePaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseOutlinePaint(false);
        java.awt.Stroke stroke6 = lineAndShapeRenderer0.getItemStroke(0, 0, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        try {
            lineAndShapeRenderer0.addAnnotation(categoryAnnotation7, layer8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.lang.String str9 = categoryAxis0.getLabel();
        categoryAxis0.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis12.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D18, rectangleEdge19);
        java.awt.Font font21 = categoryAxis12.getTickLabelFont();
        categoryAxis0.setLabelFont(font21);
        categoryAxis0.setAxisLineVisible(true);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor25 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor25, (int) (byte) 0, (int) '4', rectangle2D28, rectangleEdge29);
        org.jfree.chart.event.AxisChangeListener axisChangeListener31 = null;
        categoryAxis0.removeChangeListener(axisChangeListener31);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color35 = java.awt.Color.getColor("hi!", color34);
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color34);
        org.jfree.chart.renderer.category.BarRenderer barRenderer37 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape39 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer37.setLegendShape(100, shape39);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator44 = barRenderer37.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint45 = barRenderer37.getBaseItemLabelPaint();
        boolean boolean46 = barRenderer37.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition48 = barRenderer37.getSeriesNegativeItemLabelPosition(0);
        java.awt.Color color49 = java.awt.Color.YELLOW;
        barRenderer37.setBaseLegendTextPaint((java.awt.Paint) color49);
        org.jfree.chart.renderer.category.BarRenderer barRenderer51 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer51.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer51.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color57 = java.awt.Color.RED;
        barRenderer51.setShadowPaint((java.awt.Paint) color57);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator59 = barRenderer51.getLegendItemLabelGenerator();
        barRenderer37.setLegendItemLabelGenerator(categorySeriesLabelGenerator59);
        java.awt.Font font61 = barRenderer37.getBaseItemLabelFont();
        categoryAxis0.setLabelFont(font61);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(categoryAnchor25);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNull(categoryURLGenerator44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator59);
        org.junit.Assert.assertNotNull(font61);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        int int2 = color1.getGreen();
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color1);
        java.awt.Font font4 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer0.getToolTipGenerator(8, (int) ' ', true);
        boolean boolean9 = barRenderer0.getShadowsVisible();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        legendItem1.setToolTipText("AxisLocation.BOTTOM_OR_RIGHT");
        org.jfree.chart.renderer.RenderAttributes renderAttributes4 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape6 = renderAttributes4.getSeriesShape((int) (byte) 100);
        java.awt.Paint paint8 = null;
        renderAttributes4.setSeriesOutlinePaint((int) '4', paint8);
        java.awt.Paint paint10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        renderAttributes4.setDefaultFillPaint(paint10);
        boolean boolean12 = legendItem1.equals((java.lang.Object) paint10);
        org.junit.Assert.assertNull(shape6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        java.awt.Font font10 = categoryAxis0.getTickLabelFont();
        java.lang.String str11 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer12.setBaseShapesFilled(true);
        java.lang.Boolean boolean16 = lineAndShapeRenderer12.getSeriesShapesFilled((int) (byte) 100);
        boolean boolean17 = lineAndShapeRenderer12.getBaseLinesVisible();
        boolean boolean18 = categoryAxis0.equals((java.lang.Object) boolean17);
        org.jfree.chart.renderer.RenderAttributes renderAttributes19 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape21 = renderAttributes19.getSeriesShape((int) (byte) 100);
        java.awt.Paint paint23 = null;
        renderAttributes19.setSeriesOutlinePaint((int) '4', paint23);
        java.awt.Color color26 = java.awt.Color.WHITE;
        renderAttributes19.setSeriesPaint((int) (short) 1, (java.awt.Paint) color26);
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer28.setBaseItemLabelFont(font29, false);
        renderAttributes19.setDefaultLabelFont(font29);
        categoryAxis0.setTickLabelFont(font29);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(shape21);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor12 = itemLabelPosition11.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor13 = itemLabelPosition11.getRotationAnchor();
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        boolean boolean15 = textAnchor13.equals((java.lang.Object) axisLocation14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer16.setLegendShape(100, shape18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator23 = barRenderer16.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint24 = barRenderer16.getBaseItemLabelPaint();
        boolean boolean25 = barRenderer16.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer16);
        boolean boolean27 = axisLocation14.equals((java.lang.Object) chartChangeEvent26);
        org.jfree.chart.axis.AxisLocation axisLocation28 = axisLocation14.getOpposite();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(itemLabelAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(categoryURLGenerator23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(axisLocation28);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.lang.String str9 = categoryAxis0.getLabel();
        categoryAxis0.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis12.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D18, rectangleEdge19);
        java.awt.Font font21 = categoryAxis12.getTickLabelFont();
        categoryAxis0.setLabelFont(font21);
        categoryAxis0.setAxisLineVisible(true);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor25 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor25, (int) (byte) 0, (int) '4', rectangle2D28, rectangleEdge29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = categoryAxis35.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D41, rectangleEdge42);
        java.awt.Font font44 = categoryAxis35.getTickLabelFont();
        java.awt.Font font45 = categoryAxis35.getTickLabelFont();
        java.lang.String str46 = categoryAxis35.getLabelToolTip();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer47 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer47.setBaseShapesFilled(true);
        java.lang.Boolean boolean51 = lineAndShapeRenderer47.getSeriesShapesFilled((int) (byte) 100);
        boolean boolean52 = lineAndShapeRenderer47.getBaseLinesVisible();
        boolean boolean53 = categoryAxis35.equals((java.lang.Object) boolean52);
        java.awt.Graphics2D graphics2D54 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.axis.AxisLocation axisLocation57 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str58 = axisLocation57.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation59 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation57, plotOrientation59);
        org.jfree.chart.axis.AxisState axisState61 = null;
        categoryAxis35.drawTickMarks(graphics2D54, (double) (-2097346), rectangle2D56, rectangleEdge60, axisState61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = null;
        try {
            org.jfree.chart.axis.AxisState axisState64 = categoryAxis0.draw(graphics2D31, 0.0d, rectangle2D33, rectangle2D34, rectangleEdge60, plotRenderingInfo63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(categoryAnchor25);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNull(boolean51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(axisLocation57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str58.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertNotNull(plotOrientation59);
        org.junit.Assert.assertNotNull(rectangleEdge60);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesShapesFilled((int) (byte) 100);
        boolean boolean5 = lineAndShapeRenderer0.getBaseLinesVisible();
        lineAndShapeRenderer0.setSeriesShapesVisible((int) (short) 1, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int10 = color9.getTransparency();
        java.awt.Color color11 = color9.brighter();
        lineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color9);
        try {
            lineAndShapeRenderer0.setSeriesShapesFilled((int) (byte) -1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke2 = renderAttributes0.getSeriesStroke((int) (byte) -1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape(8, 10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer6.setLegendShape(100, shape8);
        barRenderer6.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer12.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer12.setSeriesStroke(0, stroke17);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer19.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer19.setSeriesStroke(0, stroke24);
        barRenderer12.setBaseOutlineStroke(stroke24, true);
        barRenderer6.setBaseStroke(stroke24);
        renderAttributes0.setDefaultOutlineStroke(stroke24);
        java.awt.Paint paint30 = renderAttributes0.getDefaultPaint();
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(paint30);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0);
        java.awt.Stroke stroke12 = barRenderer0.getSeriesOutlineStroke(1);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.SortOrder sortOrder17 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = categoryAxis18.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D24, rectangleEdge25);
        java.lang.String str27 = categoryAxis18.getLabel();
        categoryAxis18.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        double double38 = categoryAxis30.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D36, rectangleEdge37);
        java.awt.Font font39 = categoryAxis30.getTickLabelFont();
        categoryAxis18.setLabelFont(font39);
        categoryAxis18.setAxisLineVisible(true);
        java.awt.Paint paint43 = categoryAxis18.getLabelPaint();
        boolean boolean44 = sortOrder17.equals((java.lang.Object) categoryAxis18);
        java.awt.Color color45 = java.awt.Color.green;
        boolean boolean46 = sortOrder17.equals((java.lang.Object) color45);
        java.awt.Stroke stroke47 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        try {
            barRenderer0.drawDomainLine(graphics2D13, categoryPlot14, rectangle2D15, (double) (byte) 10, (java.awt.Paint) color45, stroke47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color6 = java.awt.Color.RED;
        barRenderer0.setShadowPaint((java.awt.Paint) color6);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = barRenderer0.getLegendItemLabelGenerator();
        barRenderer0.setShadowYOffset(100.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer11.setLegendShape(100, shape13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = barRenderer11.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint19 = barRenderer11.getBaseItemLabelPaint();
        boolean boolean20 = barRenderer11.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = barRenderer11.getSeriesNegativeItemLabelPosition(0);
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition22);
        org.jfree.chart.LegendItem legendItem26 = barRenderer0.getLegendItem(2, (int) '4');
        barRenderer0.setBase(3.0d);
        java.awt.Shape shape30 = barRenderer0.lookupSeriesShape((int) (short) -1);
        barRenderer0.setAutoPopulateSeriesStroke(true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNull(legendItem26);
        org.junit.Assert.assertNotNull(shape30);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D7, rectangleEdge8);
        java.lang.String str10 = categoryAxis1.getLabel();
        categoryAxis1.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis13.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D19, rectangleEdge20);
        java.awt.Font font22 = categoryAxis13.getTickLabelFont();
        categoryAxis1.setLabelFont(font22);
        categoryAxis1.setAxisLineVisible(true);
        java.awt.Paint paint26 = categoryAxis1.getLabelPaint();
        boolean boolean27 = sortOrder0.equals((java.lang.Object) categoryAxis1);
        java.awt.Stroke stroke28 = null;
        try {
            categoryAxis1.setAxisLineStroke(stroke28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor12 = itemLabelPosition11.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor13 = itemLabelPosition11.getRotationAnchor();
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        boolean boolean15 = textAnchor13.equals((java.lang.Object) axisLocation14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer16.setLegendShape(100, shape18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator23 = barRenderer16.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint24 = barRenderer16.getBaseItemLabelPaint();
        boolean boolean25 = barRenderer16.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer16);
        boolean boolean27 = axisLocation14.equals((java.lang.Object) chartChangeEvent26);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer28.setUseOutlinePaint(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator34 = lineAndShapeRenderer28.getURLGenerator(10, (int) 'a', false);
        boolean boolean35 = lineAndShapeRenderer28.getBaseSeriesVisible();
        lineAndShapeRenderer28.setSeriesShapesFilled(10, true);
        boolean boolean39 = axisLocation14.equals((java.lang.Object) lineAndShapeRenderer28);
        org.jfree.chart.axis.AxisLocation axisLocation40 = axisLocation14.getOpposite();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(itemLabelAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(categoryURLGenerator23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(categoryURLGenerator34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(axisLocation40);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke2 = renderAttributes0.getSeriesStroke((int) (byte) -1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape(8, 10);
        java.awt.Paint paint7 = renderAttributes0.getSeriesFillPaint((int) (short) 0);
        java.awt.Shape shape10 = renderAttributes0.getItemShape(10, (-2097346));
        java.awt.Paint paint12 = renderAttributes0.getSeriesOutlinePaint((int) (short) 0);
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer4.setLegendShape(100, shape6);
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint9 = null;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape6, stroke8, paint9);
        java.lang.String str11 = legendItem10.getURLText();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer12.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer12.setSeriesStroke(0, stroke17);
        java.awt.Paint paint20 = barRenderer12.lookupSeriesPaint((-1));
        legendItem10.setLabelPaint(paint20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = categoryAxis22.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D28, rectangleEdge29);
        java.awt.Font font31 = categoryAxis22.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis22.setTickLabelInsets(rectangleInsets32);
        categoryAxis22.setVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = null;
        double double44 = categoryAxis36.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D42, rectangleEdge43);
        java.awt.Font font45 = categoryAxis36.getTickLabelFont();
        java.awt.Font font46 = categoryAxis36.getTickLabelFont();
        categoryAxis22.setLabelFont(font46);
        legendItem10.setLabelFont(font46);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(font46);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color6 = java.awt.Color.RED;
        barRenderer0.setShadowPaint((java.awt.Paint) color6);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = barRenderer0.getLegendItemLabelGenerator();
        barRenderer0.setShadowYOffset(100.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer11.setLegendShape(100, shape13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = barRenderer11.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint19 = barRenderer11.getBaseItemLabelPaint();
        boolean boolean20 = barRenderer11.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = barRenderer11.getSeriesNegativeItemLabelPosition(0);
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition22);
        org.jfree.chart.LegendItem legendItem26 = barRenderer0.getLegendItem(2, (int) '4');
        barRenderer0.setBase(3.0d);
        java.awt.Shape shape30 = barRenderer0.lookupSeriesShape((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity36 = new org.jfree.chart.entity.CategoryItemEntity(shape30, "ChartEntity: tooltip = null", "-4,-4,4,4", categoryDataset33, (java.lang.Comparable) "-4,-4,4,4", (java.lang.Comparable) 0.05d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNull(legendItem26);
        org.junit.Assert.assertNotNull(shape30);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        int int2 = color1.getGreen();
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color1);
        java.awt.Font font4 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer0.getToolTipGenerator(8, (int) ' ', true);
        int int9 = barRenderer0.getRowCount();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis0.setTickLabelInsets(rectangleInsets10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType13 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType14 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets10.createAdjustedRectangle(rectangle2D12, lengthAdjustmentType13, lengthAdjustmentType14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8, false);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.data.Range range13 = barRenderer0.findRangeBounds(categoryDataset11, false);
        boolean boolean14 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer16.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer16.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color22 = java.awt.Color.RED;
        barRenderer16.setShadowPaint((java.awt.Paint) color22);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator24 = barRenderer16.getLegendItemLabelGenerator();
        lineAndShapeRenderer15.setLegendItemLabelGenerator(categorySeriesLabelGenerator24);
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator24);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer27 = barRenderer0.getGradientPaintTransformer();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (short) 1, categoryToolTipGenerator30);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator24);
        org.junit.Assert.assertNotNull(gradientPaintTransformer27);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.awt.GradientPaint gradientPaint2 = null;
        org.jfree.chart.util.ShapeList shapeList3 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.util.ShapeList shapeList5 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        shapeList5.setShape((int) (byte) 1, shape7);
        shapeList3.setShape((int) (short) 0, shape7);
        try {
            java.awt.GradientPaint gradientPaint10 = standardGradientPaintTransformer1.transform(gradientPaint2, shape7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int3 = color2.getTransparency();
        java.awt.Color color4 = color2.brighter();
        lineAndShapeRenderer0.setSeriesOutlinePaint(0, (java.awt.Paint) color4, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        boolean boolean11 = lineAndShapeRenderer0.getItemLineVisible((int) (byte) 10, (int) (short) -1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis0.setTickLabelInsets(rectangleInsets10);
        categoryAxis0.setVisible(true);
        categoryAxis0.setLowerMargin((-16.0d));
        int int16 = categoryAxis0.getMaximumCategoryLabelLines();
        java.awt.Font font17 = categoryAxis0.getTickLabelFont();
        java.awt.Font font18 = null;
        try {
            categoryAxis0.setTickLabelFont(font18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.text.AttributedString attributedString2 = legendItem1.getAttributedLabel();
        java.text.AttributedString attributedString3 = legendItem1.getAttributedLabel();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = categoryAxis5.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D11, rectangleEdge12);
        java.lang.String str14 = categoryAxis5.getLabel();
        categoryAxis5.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = categoryAxis17.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D23, rectangleEdge24);
        java.awt.Font font26 = categoryAxis17.getTickLabelFont();
        categoryAxis5.setLabelFont(font26);
        categoryAxis5.setAxisLineVisible(true);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor30 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = null;
        double double35 = categoryAxis5.getCategoryJava2DCoordinate(categoryAnchor30, (int) (byte) 0, (int) '4', rectangle2D33, rectangleEdge34);
        org.jfree.chart.event.AxisChangeListener axisChangeListener36 = null;
        categoryAxis5.removeChangeListener(axisChangeListener36);
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color40 = java.awt.Color.getColor("hi!", color39);
        categoryAxis5.setAxisLinePaint((java.awt.Paint) color39);
        boolean boolean42 = chartChangeEventType4.equals((java.lang.Object) color39);
        legendItem1.setFillPaint((java.awt.Paint) color39);
        org.junit.Assert.assertNull(attributedString2);
        org.junit.Assert.assertNull(attributedString3);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(categoryAnchor30);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer9.setLegendShape(100, shape11);
        barRenderer9.setShadowXOffset((double) 'a');
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendItem16.setLinePaint((java.awt.Paint) color17);
        java.text.AttributedString attributedString19 = legendItem16.getAttributedLabel();
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer20.setLegendShape(100, shape22);
        legendItem16.setShape(shape22);
        barRenderer9.setBaseShape(shape22);
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int28 = color27.getTransparency();
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator32 = new org.jfree.chart.util.DefaultShadowGenerator((int) '4', color27, 10.0f, (int) (short) 100, (double) (byte) 1);
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "hi!", "{0}", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", shape22, (java.awt.Paint) color27);
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer35.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer35.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color41 = java.awt.Color.RED;
        barRenderer35.setShadowPaint((java.awt.Paint) color41);
        java.awt.Color color43 = java.awt.Color.ORANGE;
        float[] floatArray48 = new float[] { ' ', (byte) 10, (byte) 1, 100 };
        float[] floatArray49 = color43.getRGBComponents(floatArray48);
        float[] floatArray50 = color41.getColorComponents(floatArray48);
        org.jfree.chart.renderer.RenderAttributes renderAttributes52 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke54 = renderAttributes52.getSeriesStroke((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer56 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape58 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer56.setLegendShape(100, shape58);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator63 = barRenderer56.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint64 = barRenderer56.getBaseItemLabelPaint();
        renderAttributes52.setSeriesPaint((int) 'a', paint64);
        java.awt.Stroke stroke66 = null;
        org.jfree.chart.LegendItem legendItem69 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Color color70 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendItem69.setLinePaint((java.awt.Paint) color70);
        java.text.AttributedString attributedString72 = legendItem69.getAttributedLabel();
        org.jfree.chart.renderer.category.BarRenderer barRenderer73 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape75 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer73.setLegendShape(100, shape75);
        legendItem69.setShape(shape75);
        java.awt.Stroke stroke78 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis79 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D85 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = null;
        double double87 = categoryAxis79.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D85, rectangleEdge86);
        java.awt.Font font88 = categoryAxis79.getTickLabelFont();
        java.awt.Font font89 = categoryAxis79.getTickLabelFont();
        org.jfree.chart.plot.Plot plot90 = null;
        categoryAxis79.setPlot(plot90);
        categoryAxis79.setLabel("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        java.awt.Color color94 = java.awt.Color.GRAY;
        categoryAxis79.setTickMarkPaint((java.awt.Paint) color94);
        try {
            org.jfree.chart.LegendItem legendItem96 = new org.jfree.chart.LegendItem("AxisLocation.BOTTOM_OR_RIGHT", "PlotOrientation.VERTICAL", "AxisLocation.BOTTOM_OR_RIGHT", "NOID", true, shape22, false, (java.awt.Paint) color41, false, paint64, stroke66, false, shape75, stroke78, (java.awt.Paint) color94);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(attributedString19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertNull(stroke54);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertNull(categoryURLGenerator63);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNull(attributedString72);
        org.junit.Assert.assertNotNull(shape75);
        org.junit.Assert.assertEquals((double) double87, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font88);
        org.junit.Assert.assertNotNull(font89);
        org.junit.Assert.assertNotNull(color94);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getSeriesNegativeItemLabelPosition(0);
        java.awt.Stroke stroke13 = barRenderer0.getSeriesOutlineStroke((int) (short) 0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        barRenderer0.notifyListeners(rendererChangeEvent14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer16.setBaseItemLabelFont(font17, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis20.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D26, rectangleEdge27);
        java.lang.String str29 = categoryAxis20.getLabel();
        categoryAxis20.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = categoryAxis32.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D38, rectangleEdge39);
        java.awt.Font font41 = categoryAxis32.getTickLabelFont();
        categoryAxis20.setLabelFont(font41);
        barRenderer16.setBaseLegendTextFont(font41);
        barRenderer0.setBaseLegendTextFont(font41);
        barRenderer0.setBase(84.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font41);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color6 = java.awt.Color.RED;
        barRenderer0.setShadowPaint((java.awt.Paint) color6);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = barRenderer0.getLegendItemLabelGenerator();
        barRenderer0.setShadowYOffset(100.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer11.setLegendShape(100, shape13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = barRenderer11.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint19 = barRenderer11.getBaseItemLabelPaint();
        boolean boolean20 = barRenderer11.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = barRenderer11.getSeriesNegativeItemLabelPosition(0);
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition22);
        barRenderer0.setSeriesCreateEntities((int) (short) 10, (java.lang.Boolean) false, true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer2.setLegendShape(100, shape4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = barRenderer2.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint10 = barRenderer2.getBaseItemLabelPaint();
        boolean boolean11 = barRenderer2.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer2);
        java.awt.Color color13 = java.awt.Color.RED;
        barRenderer2.setBaseOutlinePaint((java.awt.Paint) color13);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = null;
        barRenderer2.setSeriesItemLabelGenerator((int) (byte) 0, categoryItemLabelGenerator16, false);
        java.util.EventListener eventListener19 = null;
        boolean boolean20 = barRenderer2.hasListener(eventListener19);
        try {
            objectList0.set((int) (short) -1, (java.lang.Object) boolean20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer4.setLegendShape(100, shape6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = barRenderer4.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint12 = barRenderer4.getBaseItemLabelPaint();
        boolean boolean13 = barRenderer4.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer4.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor16 = itemLabelPosition15.getItemLabelAnchor();
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition15, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer27.setLegendShape(100, shape29);
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint32 = null;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape29, stroke31, paint32);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color36 = java.awt.Color.getColor("hi!", color35);
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape29, (java.awt.Paint) color35);
        org.jfree.chart.entity.ChartEntity chartEntity38 = new org.jfree.chart.entity.ChartEntity(shape29);
        barRenderer0.setBaseShape(shape29);
        org.jfree.chart.plot.Plot plot40 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity42 = new org.jfree.chart.entity.PlotEntity(shape29, plot40, "AxisLocation.BOTTOM_OR_RIGHT");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(categoryURLGenerator11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(itemLabelAnchor16);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer0.setBaseItemLabelFont(font1, false);
        boolean boolean5 = barRenderer0.isSeriesVisible((int) (short) 1);
        barRenderer0.setShadowXOffset((double) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (byte) 1, categoryToolTipGenerator9);
        java.awt.Paint paint14 = barRenderer0.getItemFillPaint((int) (byte) 100, 0, false);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8, false);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.data.Range range13 = barRenderer0.findRangeBounds(categoryDataset11, false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color16);
        barRenderer0.setSeriesPaint((int) (short) 100, (java.awt.Paint) color17, false);
        barRenderer0.clearSeriesStrokes(false);
        boolean boolean23 = barRenderer0.isSeriesVisibleInLegend((int) (byte) 1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-1.0f), (double) (short) 100, (double) (-1.0f), (double) (short) 100);
        double double7 = rectangleInsets5.calculateBottomOutset((double) 255);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets5.createOutsetRectangle(rectangle2D8, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8, false);
        boolean boolean11 = barRenderer0.getAutoPopulateSeriesPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer12.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer12.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color18 = java.awt.Color.RED;
        barRenderer12.setShadowPaint((java.awt.Paint) color18);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator20 = barRenderer12.getLegendItemLabelGenerator();
        barRenderer12.setShadowYOffset(100.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer23.setLegendShape(100, shape25);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator30 = barRenderer23.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint31 = barRenderer23.getBaseItemLabelPaint();
        boolean boolean32 = barRenderer23.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = barRenderer23.getSeriesNegativeItemLabelPosition(0);
        barRenderer12.setNegativeItemLabelPositionFallback(itemLabelPosition34);
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition34);
        java.awt.Stroke stroke38 = barRenderer0.lookupSeriesStroke((int) (short) 100);
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = null;
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset44 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup45 = abstractCategoryDataset44.getGroup();
        boolean boolean47 = datasetGroup45.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis48.setLowerMargin(0.0d);
        categoryAxis48.setLowerMargin((double) 1L);
        boolean boolean53 = datasetGroup45.equals((java.lang.Object) categoryAxis48);
        org.jfree.chart.renderer.category.BarRenderer barRenderer55 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape57 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer55.setLegendShape(100, shape57);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator62 = barRenderer55.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint63 = barRenderer55.getBaseItemLabelPaint();
        boolean boolean64 = barRenderer55.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent65 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer55);
        java.awt.Color color66 = java.awt.Color.RED;
        barRenderer55.setBaseOutlinePaint((java.awt.Paint) color66);
        categoryAxis48.setTickLabelPaint((java.lang.Comparable) 116.0d, (java.awt.Paint) color66);
        org.jfree.chart.axis.ValueAxis valueAxis69 = null;
        org.jfree.data.category.CategoryDataset categoryDataset70 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState74 = null;
        try {
            boolean boolean75 = barRenderer0.hitTest((double) (-1), (double) (-1), graphics2D41, rectangle2D42, categoryPlot43, categoryAxis48, valueAxis69, categoryDataset70, 0, 0, false, categoryItemRendererState74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator20);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNull(categoryURLGenerator30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition34);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(datasetGroup45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNull(categoryURLGenerator62);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(color66);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer0.setBaseItemLabelFont(font1, false);
        boolean boolean5 = barRenderer0.isSeriesVisible((int) (short) 1);
        barRenderer0.setShadowXOffset((double) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (byte) 1, categoryToolTipGenerator9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getBasePositiveItemLabelPosition();
        java.lang.Boolean boolean13 = barRenderer0.getSeriesVisibleInLegend(0);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNull(boolean13);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        boolean boolean5 = lineAndShapeRenderer0.getItemShapeVisible(1, (int) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer0.getBaseNegativeItemLabelPosition();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape2 = renderAttributes0.getSeriesShape((int) (byte) 100);
        java.awt.Paint paint4 = null;
        renderAttributes0.setSeriesOutlinePaint((int) '4', paint4);
        java.awt.Paint paint7 = renderAttributes0.getSeriesOutlinePaint((int) ' ');
        java.awt.Paint paint9 = renderAttributes0.getSeriesFillPaint((int) (byte) 0);
        try {
            java.awt.Stroke stroke12 = renderAttributes0.getItemOutlineStroke((int) '#', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin(0.0d);
        categoryAxis0.setLowerMargin((double) 1L);
        boolean boolean5 = categoryAxis0.isAxisLineVisible();
        categoryAxis0.setLowerMargin(4.0d);
        float float8 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        double double9 = categoryAxis0.getFixedDimension();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin(0.0d);
        categoryAxis0.setMinorTickMarksVisible(true);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = org.jfree.chart.axis.CategoryAnchor.END;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str10 = axisLocation9.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation9, plotOrientation11);
        try {
            double double13 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor5, (int) (byte) -1, (int) ' ', rectangle2D8, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str10.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8, false);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.data.Range range13 = barRenderer0.findRangeBounds(categoryDataset11, false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color16);
        barRenderer0.setSeriesPaint((int) (short) 100, (java.awt.Paint) color17, false);
        barRenderer0.setBaseCreateEntities(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset23 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup24 = abstractCategoryDataset23.getGroup();
        boolean boolean26 = datasetGroup24.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis27.setLowerMargin(0.0d);
        categoryAxis27.setLowerMargin((double) 1L);
        boolean boolean32 = datasetGroup24.equals((java.lang.Object) categoryAxis27);
        org.jfree.chart.renderer.category.BarRenderer barRenderer34 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer34.setLegendShape(100, shape36);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = barRenderer34.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint42 = barRenderer34.getBaseItemLabelPaint();
        boolean boolean43 = barRenderer34.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent44 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer34);
        java.awt.Color color45 = java.awt.Color.RED;
        barRenderer34.setBaseOutlinePaint((java.awt.Paint) color45);
        categoryAxis27.setTickLabelPaint((java.lang.Comparable) 116.0d, (java.awt.Paint) color45);
        barRenderer0.setBasePaint((java.awt.Paint) color45, false);
        java.awt.Paint paint51 = barRenderer0.lookupSeriesPaint((int) 'a');
        barRenderer0.setSeriesVisible(255, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(datasetGroup24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(categoryURLGenerator41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke2 = renderAttributes0.getSeriesStroke((int) (byte) -1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape(8, 10);
        java.awt.Paint paint7 = renderAttributes0.getSeriesFillPaint((int) (short) 0);
        java.awt.Stroke stroke8 = renderAttributes0.getDefaultOutlineStroke();
        java.awt.Paint paint9 = renderAttributes0.getDefaultPaint();
        java.awt.Font font10 = renderAttributes0.getDefaultLabelFont();
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNull(font10);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Shape shape1 = lineAndShapeRenderer0.getBaseShape();
        java.lang.Boolean boolean3 = lineAndShapeRenderer0.getSeriesVisible(8);
        java.awt.Paint paint7 = lineAndShapeRenderer0.getItemOutlinePaint((int) (byte) 1, (int) (byte) 0, false);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("ChartEntity: tooltip = null");
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.clearSeriesStrokes(true);
        boolean boolean6 = barRenderer0.isItemLabelVisible((int) (byte) 0, (int) (byte) -1, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 100, (int) (byte) 0, false);
        java.lang.Object obj11 = barRenderer0.clone();
        org.jfree.chart.util.ShapeList shapeList12 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Shape shape15 = lineAndShapeRenderer14.getBaseShape();
        shapeList12.setShape((int) (byte) 10, shape15);
        barRenderer0.setBaseShape(shape15);
        java.awt.Shape shape19 = barRenderer0.getSeriesShape((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(shape19);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin(0.0d);
        categoryAxis0.setLowerMargin((double) 1L);
        boolean boolean5 = categoryAxis0.isAxisLineVisible();
        categoryAxis0.setLowerMargin(4.0d);
        float float8 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer9.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer9.setSeriesStroke(0, stroke14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer16.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer16.setSeriesStroke(0, stroke21);
        barRenderer9.setBaseOutlineStroke(stroke21, true);
        categoryAxis0.setTickMarkStroke(stroke21);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = categoryAxis29.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D35, rectangleEdge36);
        java.awt.Font font38 = categoryAxis29.getTickLabelFont();
        java.awt.Font font39 = categoryAxis29.getTickLabelFont();
        java.lang.String str40 = categoryAxis29.getLabelToolTip();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer41.setBaseShapesFilled(true);
        java.lang.Boolean boolean45 = lineAndShapeRenderer41.getSeriesShapesFilled((int) (byte) 100);
        boolean boolean46 = lineAndShapeRenderer41.getBaseLinesVisible();
        boolean boolean47 = categoryAxis29.equals((java.lang.Object) boolean46);
        java.awt.Graphics2D graphics2D48 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.axis.AxisLocation axisLocation51 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str52 = axisLocation51.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation53 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation51, plotOrientation53);
        org.jfree.chart.axis.AxisState axisState55 = null;
        categoryAxis29.drawTickMarks(graphics2D48, (double) (-2097346), rectangle2D50, rectangleEdge54, axisState55);
        try {
            double double57 = categoryAxis0.getCategoryEnd((int) (byte) 1, (int) 'a', rectangle2D28, rectangleEdge54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNull(boolean45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str52.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertNotNull(plotOrientation53);
        org.junit.Assert.assertNotNull(rectangleEdge54);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis0.setTickLabelInsets(rectangleInsets10);
        categoryAxis0.setVisible(true);
        categoryAxis0.setLowerMargin((-16.0d));
        int int16 = categoryAxis0.getMaximumCategoryLabelLines();
        java.awt.Paint paint17 = categoryAxis0.getAxisLinePaint();
        java.awt.Paint paint18 = categoryAxis0.getTickMarkPaint();
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        boolean boolean9 = categoryAxis0.isMinorTickMarksVisible();
        categoryAxis0.setCategoryLabelPositionOffset(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis12.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D18, rectangleEdge19);
        java.awt.Font font21 = categoryAxis12.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis12.setTickLabelInsets(rectangleInsets22);
        double double25 = rectangleInsets22.trimWidth((double) '#');
        double double26 = rectangleInsets22.getRight();
        org.jfree.chart.util.UnitType unitType27 = rectangleInsets22.getUnitType();
        categoryAxis0.setLabelInsets(rectangleInsets22);
        double double29 = rectangleInsets22.getRight();
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 19.0d + "'", double25 == 19.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 8.0d + "'", double26 == 8.0d);
        org.junit.Assert.assertNotNull(unitType27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 8.0d + "'", double29 == 8.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        legendItem1.setToolTipText("AxisLocation.BOTTOM_OR_RIGHT");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset5 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup6 = abstractCategoryDataset5.getGroup();
        boolean boolean8 = datasetGroup6.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setLowerMargin(0.0d);
        categoryAxis9.setLowerMargin((double) 1L);
        boolean boolean14 = datasetGroup6.equals((java.lang.Object) categoryAxis9);
        boolean boolean15 = defaultDrawingSupplier4.equals((java.lang.Object) categoryAxis9);
        java.awt.Shape shape16 = defaultDrawingSupplier4.getNextShape();
        legendItem1.setShape(shape16);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = legendItem1.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(datasetGroup6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(gradientPaintTransformer18);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape2 = renderAttributes0.getSeriesShape((int) (byte) 100);
        java.awt.Paint paint4 = null;
        renderAttributes0.setSeriesOutlinePaint((int) '4', paint4);
        java.awt.Color color7 = java.awt.Color.WHITE;
        renderAttributes0.setSeriesPaint((int) (short) 1, (java.awt.Paint) color7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer9.setBaseItemLabelFont(font10, false);
        renderAttributes0.setDefaultLabelFont(font10);
        try {
            java.lang.Boolean boolean15 = renderAttributes0.getSeriesLabelVisible((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.clearSeriesStrokes(true);
        barRenderer0.setBaseItemLabelsVisible(false, true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin(0.0d);
        categoryAxis0.setLowerMargin((double) 1L);
        boolean boolean5 = categoryAxis0.isAxisLineVisible();
        categoryAxis0.setLowerMargin(4.0d);
        float float8 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer9.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer9.setSeriesStroke(0, stroke14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer16.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer16.setSeriesStroke(0, stroke21);
        barRenderer9.setBaseOutlineStroke(stroke21, true);
        categoryAxis0.setTickMarkStroke(stroke21);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = categoryAxis26.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D32, rectangleEdge33);
        java.awt.Font font35 = categoryAxis26.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis26.setTickLabelInsets(rectangleInsets36);
        double double39 = rectangleInsets36.trimWidth((double) '#');
        double double41 = rectangleInsets36.trimWidth((double) 100L);
        double double42 = rectangleInsets36.getLeft();
        categoryAxis0.setLabelInsets(rectangleInsets36, true);
        double double46 = rectangleInsets36.calculateRightInset((double) 1L);
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets36.createInsetRectangle(rectangle2D47, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 19.0d + "'", double39 == 19.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 84.0d + "'", double41 == 84.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 8.0d + "'", double42 == 8.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 8.0d + "'", double46 == 8.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) 100, (float) 100, (float) 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1494) + "'", int3 == (-1494));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis0.setTickLabelInsets(rectangleInsets10);
        double double13 = rectangleInsets10.trimWidth((double) '#');
        double double14 = rectangleInsets10.getRight();
        org.jfree.chart.util.UnitType unitType15 = rectangleInsets10.getUnitType();
        double double17 = rectangleInsets10.calculateRightOutset((double) (-1));
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 19.0d + "'", double13 == 19.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 8.0d + "'", double14 == 8.0d);
        org.junit.Assert.assertNotNull(unitType15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.clearSeriesStrokes(true);
        boolean boolean6 = barRenderer0.isItemLabelVisible((int) (byte) 0, (int) (byte) -1, true);
        barRenderer0.removeAnnotations();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer8.setLegendShape(100, shape10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = barRenderer8.getURLGenerator(10, (int) (byte) 1, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = null;
        barRenderer8.setBaseToolTipGenerator(categoryToolTipGenerator16, false);
        boolean boolean19 = barRenderer8.getAutoPopulateSeriesPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer20.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer20.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color26 = java.awt.Color.RED;
        barRenderer20.setShadowPaint((java.awt.Paint) color26);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator28 = barRenderer20.getLegendItemLabelGenerator();
        barRenderer20.setShadowYOffset(100.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer31 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer31.setLegendShape(100, shape33);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator38 = barRenderer31.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint39 = barRenderer31.getBaseItemLabelPaint();
        boolean boolean40 = barRenderer31.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition42 = barRenderer31.getSeriesNegativeItemLabelPosition(0);
        barRenderer20.setNegativeItemLabelPositionFallback(itemLabelPosition42);
        barRenderer8.setBasePositiveItemLabelPosition(itemLabelPosition42);
        java.awt.Stroke stroke46 = barRenderer8.lookupSeriesStroke((int) (short) 100);
        barRenderer0.setBaseOutlineStroke(stroke46, false);
        java.awt.Font font49 = barRenderer0.getBaseLegendTextFont();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(categoryURLGenerator15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator28);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNull(categoryURLGenerator38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition42);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNull(font49);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateTopOutset(Double.NaN);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer4.setLegendShape(100, shape6);
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint9 = null;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape6, stroke8, paint9);
        java.lang.String str11 = legendItem10.getURLText();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = legendItem10.getFillPaintTransformer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer13.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer13.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color19 = java.awt.Color.RED;
        barRenderer13.setShadowPaint((java.awt.Paint) color19);
        int int21 = color19.getTransparency();
        legendItem10.setOutlinePaint((java.awt.Paint) color19);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        legendItem10.setLabelPaint((java.awt.Paint) color23);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(gradientPaintTransformer12);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer8.setLegendShape(100, shape10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint13 = null;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape10, stroke12, paint13);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color16);
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape10, (java.awt.Paint) color16);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape10);
        boolean boolean21 = chartEntity19.equals((java.lang.Object) "hi!");
        java.lang.String str22 = chartEntity19.toString();
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        chartEntity19.setArea(shape23);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ChartEntity: tooltip = null" + "'", str22.equals("ChartEntity: tooltip = null"));
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset1 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup2 = abstractCategoryDataset1.getGroup();
        boolean boolean4 = datasetGroup2.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.setLowerMargin(0.0d);
        categoryAxis5.setLowerMargin((double) 1L);
        boolean boolean10 = datasetGroup2.equals((java.lang.Object) categoryAxis5);
        boolean boolean11 = defaultDrawingSupplier0.equals((java.lang.Object) categoryAxis5);
        java.awt.Shape shape12 = defaultDrawingSupplier0.getNextShape();
        java.awt.Shape shape13 = defaultDrawingSupplier0.getNextShape();
        org.junit.Assert.assertNotNull(datasetGroup2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer1.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer1.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color7 = java.awt.Color.RED;
        barRenderer1.setShadowPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = barRenderer1.getLegendItemLabelGenerator();
        lineAndShapeRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator9);
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        org.jfree.chart.util.UnitType unitType13 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets(unitType13, (double) (-1.0f), (double) (short) 100, (double) (-1.0f), (double) (short) 100);
        boolean boolean19 = lineAndShapeRenderer0.equals((java.lang.Object) (short) 100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer21.setBaseItemLabelFont(font22, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = categoryAxis25.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D31, rectangleEdge32);
        java.lang.String str34 = categoryAxis25.getLabel();
        categoryAxis25.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = categoryAxis37.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D43, rectangleEdge44);
        java.awt.Font font46 = categoryAxis37.getTickLabelFont();
        categoryAxis25.setLabelFont(font46);
        barRenderer21.setBaseLegendTextFont(font46);
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer50.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer50.setSeriesStroke(0, stroke55);
        barRenderer21.setSeriesStroke(100, stroke55, false);
        try {
            lineAndShapeRenderer0.setSeriesStroke((-1494), stroke55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertNotNull(unitType13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(stroke55);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis0.setTickLabelInsets(rectangleInsets10);
        double double13 = rectangleInsets10.calculateBottomInset((double) 4);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer0.setBaseItemLabelFont(font1, false);
        boolean boolean5 = barRenderer0.isSeriesVisible((int) (short) 1);
        barRenderer0.setShadowXOffset((double) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (byte) 1, categoryToolTipGenerator9);
        java.awt.Color color11 = java.awt.Color.lightGray;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color11, false);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        barRenderer0.clearSeriesPaints(false);
        java.awt.Paint paint9 = barRenderer0.getSeriesItemLabelPaint(1);
        barRenderer0.removeAnnotations();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = barRenderer0.getSeriesToolTipGenerator((int) (short) 0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = barRenderer0.getToolTipGenerator((int) (short) -1, 5, true);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNull(categoryToolTipGenerator16);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        boolean boolean5 = lineAndShapeRenderer0.getItemShapeVisible(1, (int) (short) 0);
        double double6 = lineAndShapeRenderer0.getItemMargin();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        barRenderer0.clearSeriesPaints(false);
        java.awt.Paint paint9 = barRenderer0.getSeriesItemLabelPaint(1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = barRenderer0.getSeriesItemLabelGenerator((int) '#');
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (byte) 10, categoryItemLabelGenerator13);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        boolean boolean2 = datasetRenderingOrder0.equals((java.lang.Object) (byte) -1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer1.setUseOutlinePaint(false);
        java.awt.Stroke stroke7 = lineAndShapeRenderer1.getItemStroke(0, 0, false);
        categoryPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            boolean boolean11 = categoryPlot0.removeRangeMarker(marker9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = barRenderer0.getSeriesToolTipGenerator((int) (short) 100);
        boolean boolean6 = barRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer0.getBasePositiveItemLabelPosition();
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 100, (java.lang.Boolean) false, false);
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        java.lang.Class<?> wildcardClass1 = textAnchor0.getClass();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.lang.String str9 = categoryAxis0.getLabel();
        categoryAxis0.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis12.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D18, rectangleEdge19);
        java.awt.Font font21 = categoryAxis12.getTickLabelFont();
        categoryAxis0.setLabelFont(font21);
        categoryAxis0.setTickMarkInsideLength((float) (-1));
        float float25 = categoryAxis0.getMinorTickMarkOutsideLength();
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 2.0f + "'", float25 == 2.0f);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        barRenderer0.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer6.setLegendShape(100, shape8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer6.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint14 = barRenderer6.getBaseItemLabelPaint();
        boolean boolean15 = barRenderer6.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer6.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = itemLabelPosition17.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor19 = itemLabelPosition17.getRotationAnchor();
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition17, false);
        barRenderer0.setIncludeBaseInRange(false);
        java.awt.Shape shape25 = barRenderer0.getSeriesShape((int) (byte) 1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertNull(shape25);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = barRenderer0.getSeriesToolTipGenerator((int) (short) 100);
        barRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer17.setLegendShape(100, shape19);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint22 = null;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape19, stroke21, paint22);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("hi!", color25);
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape19, (java.awt.Paint) color25);
        org.jfree.chart.entity.ChartEntity chartEntity28 = new org.jfree.chart.entity.ChartEntity(shape19);
        barRenderer0.setSeriesShape((int) 'a', shape19);
        int int30 = barRenderer0.getDefaultEntityRadius();
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) ' ', categoryItemLabelGenerator5, true);
        double double8 = barRenderer0.getItemLabelAnchorOffset();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor12 = itemLabelPosition11.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor13 = itemLabelPosition11.getRotationAnchor();
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        boolean boolean15 = textAnchor13.equals((java.lang.Object) axisLocation14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer16.setLegendShape(100, shape18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator23 = barRenderer16.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint24 = barRenderer16.getBaseItemLabelPaint();
        boolean boolean25 = barRenderer16.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer16);
        boolean boolean27 = axisLocation14.equals((java.lang.Object) chartChangeEvent26);
        java.lang.Object obj28 = chartChangeEvent26.getSource();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(itemLabelAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(categoryURLGenerator23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(obj28);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer1.setUseOutlinePaint(false);
        java.awt.Stroke stroke7 = lineAndShapeRenderer1.getItemStroke(0, 0, false);
        categoryPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            boolean boolean11 = categoryPlot0.removeAnnotation(categoryAnnotation9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke3 = renderAttributes1.getSeriesStroke((int) (byte) -1);
        java.awt.Shape shape6 = renderAttributes1.getItemShape(8, 10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer7.setLegendShape(100, shape9);
        barRenderer7.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer13.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer13.setSeriesStroke(0, stroke18);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer20.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer20.setSeriesStroke(0, stroke25);
        barRenderer13.setBaseOutlineStroke(stroke25, true);
        barRenderer7.setBaseStroke(stroke25);
        renderAttributes1.setDefaultOutlineStroke(stroke25);
        int int31 = objectList0.indexOf((java.lang.Object) renderAttributes1);
        java.awt.Paint paint33 = renderAttributes1.getSeriesFillPaint((int) (byte) 1);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNull(paint33);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        categoryAxis0.setLabel("hi!");
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer12.setLegendShape(100, shape14);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = barRenderer12.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint20 = barRenderer12.getBaseItemLabelPaint();
        boolean boolean21 = barRenderer12.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = barRenderer12.getSeriesNegativeItemLabelPosition(0);
        java.awt.Color color24 = java.awt.Color.YELLOW;
        barRenderer12.setBaseLegendTextPaint((java.awt.Paint) color24);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color24);
        org.jfree.chart.event.AxisChangeListener axisChangeListener27 = null;
        categoryAxis0.addChangeListener(axisChangeListener27);
        categoryAxis0.setCategoryMargin((double) 1);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNull(categoryURLGenerator19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Font font6 = null;
        barRenderer0.setBaseLegendTextFont(font6);
        java.awt.Paint paint9 = barRenderer0.lookupSeriesPaint((int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = barRenderer0.getPlot();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder14 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = categoryAxis15.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D21, rectangleEdge22);
        java.lang.String str24 = categoryAxis15.getLabel();
        categoryAxis15.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = null;
        double double35 = categoryAxis27.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D33, rectangleEdge34);
        java.awt.Font font36 = categoryAxis27.getTickLabelFont();
        categoryAxis15.setLabelFont(font36);
        categoryAxis15.setAxisLineVisible(true);
        java.awt.Paint paint40 = categoryAxis15.getLabelPaint();
        boolean boolean41 = sortOrder14.equals((java.lang.Object) categoryAxis15);
        java.util.List list42 = categoryPlot13.getCategoriesForAxis(categoryAxis15);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = null;
        double double51 = categoryAxis43.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D49, rectangleEdge50);
        java.awt.Font font52 = categoryAxis43.getTickLabelFont();
        categoryAxis43.setLabel("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions55 = categoryAxis43.getCategoryLabelPositions();
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        org.jfree.data.category.CategoryDataset categoryDataset57 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState61 = null;
        java.awt.geom.Rectangle2D rectangle2D62 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D63 = barRenderer0.createHotSpotBounds(graphics2D11, rectangle2D12, categoryPlot13, categoryAxis43, valueAxis56, categoryDataset57, (int) (short) 1, (int) (short) 1, true, categoryItemRendererState61, rectangle2D62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryPlot10);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(categoryLabelPositions55);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.awt.Color color2 = java.awt.Color.getColor("", 0);
        java.awt.Color color3 = color2.brighter();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getSeriesNegativeItemLabelPosition(0);
        barRenderer0.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false, true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color6 = java.awt.Color.RED;
        barRenderer0.setShadowPaint((java.awt.Paint) color6);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = barRenderer0.getLegendItemLabelGenerator();
        barRenderer0.setShadowYOffset(100.0d);
        boolean boolean11 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = categoryAxis11.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D17, rectangleEdge18);
        java.lang.String str20 = categoryAxis11.getLabel();
        categoryAxis11.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        double double31 = categoryAxis23.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D29, rectangleEdge30);
        java.awt.Font font32 = categoryAxis23.getTickLabelFont();
        categoryAxis11.setLabelFont(font32);
        categoryAxis11.setAxisLineVisible(true);
        java.awt.Paint paint36 = categoryAxis11.getLabelPaint();
        double double37 = categoryAxis11.getUpperMargin();
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D45 = barRenderer0.createHotSpotBounds(graphics2D8, rectangle2D9, categoryPlot10, categoryAxis11, valueAxis38, categoryDataset39, 1, (int) (short) 10, true, categoryItemRendererState43, rectangle2D44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.05d + "'", double37 == 0.05d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        barRenderer0.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer6.setLegendShape(100, shape8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer6.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint14 = barRenderer6.getBaseItemLabelPaint();
        boolean boolean15 = barRenderer6.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer6.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = itemLabelPosition17.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor19 = itemLabelPosition17.getRotationAnchor();
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition17, false);
        boolean boolean22 = barRenderer0.getBaseCreateEntities();
        boolean boolean23 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder27 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        double double36 = categoryAxis28.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D34, rectangleEdge35);
        java.lang.String str37 = categoryAxis28.getLabel();
        categoryAxis28.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = categoryAxis40.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D46, rectangleEdge47);
        java.awt.Font font49 = categoryAxis40.getTickLabelFont();
        categoryAxis28.setLabelFont(font49);
        categoryAxis28.setAxisLineVisible(true);
        java.awt.Paint paint53 = categoryAxis28.getLabelPaint();
        boolean boolean54 = sortOrder27.equals((java.lang.Object) categoryAxis28);
        java.util.List list55 = categoryPlot26.getCategoriesForAxis(categoryAxis28);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor56 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot26.setDomainGridlinePosition(categoryAnchor56);
        java.awt.geom.GeneralPath generalPath58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.RenderingSource renderingSource60 = null;
        categoryPlot26.select(generalPath58, rectangle2D59, renderingSource60);
        org.jfree.chart.plot.Marker marker62 = null;
        boolean boolean63 = categoryPlot26.removeDomainMarker(marker62);
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = null;
        double double72 = categoryAxis64.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D70, rectangleEdge71);
        boolean boolean73 = categoryAxis64.isMinorTickMarksVisible();
        categoryAxis64.setCategoryLabelPositionOffset(0);
        org.jfree.chart.axis.ValueAxis valueAxis76 = null;
        org.jfree.data.category.CategoryDataset categoryDataset77 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState81 = null;
        try {
            java.awt.Shape shape82 = barRenderer0.createHotSpotShape(graphics2D24, rectangle2D25, categoryPlot26, categoryAxis64, valueAxis76, categoryDataset77, (int) (short) -1, 4, true, categoryItemRendererState81);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(sortOrder27);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertEquals((double) double48, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(list55);
        org.junit.Assert.assertNotNull(categoryAnchor56);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertEquals((double) double72, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        barRenderer0.setMaximumBarWidth((double) '4');
        java.lang.Object obj6 = barRenderer0.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D8, rectangleEdge9);
        java.lang.String str11 = categoryAxis2.getLabel();
        categoryAxis2.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis14.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D20, rectangleEdge21);
        java.awt.Font font23 = categoryAxis14.getTickLabelFont();
        categoryAxis2.setLabelFont(font23);
        categoryAxis2.setAxisLineVisible(true);
        java.awt.Paint paint27 = categoryAxis2.getLabelPaint();
        boolean boolean28 = sortOrder1.equals((java.lang.Object) categoryAxis2);
        java.util.List list29 = categoryPlot0.getCategoriesForAxis(categoryAxis2);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor30 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor30);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder34 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = categoryAxis35.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D41, rectangleEdge42);
        java.lang.String str44 = categoryAxis35.getLabel();
        categoryAxis35.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        double double55 = categoryAxis47.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D53, rectangleEdge54);
        java.awt.Font font56 = categoryAxis47.getTickLabelFont();
        categoryAxis35.setLabelFont(font56);
        categoryAxis35.setAxisLineVisible(true);
        java.awt.Paint paint60 = categoryAxis35.getLabelPaint();
        boolean boolean61 = sortOrder34.equals((java.lang.Object) categoryAxis35);
        java.util.List list62 = categoryPlot33.getCategoriesForAxis(categoryAxis35);
        try {
            categoryPlot0.mapDatasetToRangeAxes((-2097346), list62);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(categoryAnchor30);
        org.junit.Assert.assertNotNull(sortOrder34);
        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(list62);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
        java.lang.Object obj2 = null;
        int int3 = objectList1.indexOf(obj2);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType5 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer6 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType5);
        boolean boolean7 = legendItemCollection4.equals((java.lang.Object) gradientPaintTransformType5);
        int int8 = objectList1.indexOf((java.lang.Object) gradientPaintTransformType5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(gradientPaintTransformType5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker1 = null;
        org.jfree.chart.util.Layer layer2 = null;
        try {
            boolean boolean3 = categoryPlot0.removeRangeMarker(marker1, layer2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8, false);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.data.Range range13 = barRenderer0.findRangeBounds(categoryDataset11, false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color16);
        barRenderer0.setSeriesPaint((int) (short) 100, (java.awt.Paint) color17, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator20 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator20, false);
        java.awt.Paint paint23 = barRenderer0.getShadowPaint();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8, false);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.data.Range range13 = barRenderer0.findRangeBounds(categoryDataset11, false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color16);
        barRenderer0.setSeriesPaint((int) (short) 100, (java.awt.Paint) color17, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator20 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator20, false);
        boolean boolean26 = barRenderer0.getItemCreateEntity(0, (int) (short) 10, false);
        barRenderer0.setDrawBarOutline(false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis0.setTickLabelInsets(rectangleInsets10);
        double double13 = rectangleInsets10.trimWidth((double) '#');
        double double14 = rectangleInsets10.getBottom();
        org.jfree.chart.util.UnitType unitType15 = rectangleInsets10.getUnitType();
        double double17 = rectangleInsets10.calculateTopInset((-16.0d));
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 19.0d + "'", double13 == 19.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(unitType15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        shapeList0.setShape((int) (byte) 1, shape2);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape2, "NOID", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        chartEntity6.setURLText("NOID");
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.lang.String str9 = categoryAxis0.getLabel();
        categoryAxis0.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis12.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D18, rectangleEdge19);
        java.awt.Font font21 = categoryAxis12.getTickLabelFont();
        categoryAxis0.setLabelFont(font21);
        categoryAxis0.setTickMarkInsideLength((float) (-1));
        float float25 = categoryAxis0.getTickMarkInsideLength();
        double double26 = categoryAxis0.getFixedDimension();
        categoryAxis0.clearCategoryLabelToolTips();
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + (-1.0f) + "'", float25 == (-1.0f));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        barRenderer0.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer6.setLegendShape(100, shape8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer6.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint14 = barRenderer6.getBaseItemLabelPaint();
        boolean boolean15 = barRenderer6.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer6.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = itemLabelPosition17.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor19 = itemLabelPosition17.getRotationAnchor();
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition17, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator22);
        java.lang.Boolean boolean25 = barRenderer0.getSeriesItemLabelsVisible(3);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator29 = barRenderer0.getToolTipGenerator(255, (int) (short) 0, true);
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder33 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        double double42 = categoryAxis34.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D40, rectangleEdge41);
        java.lang.String str43 = categoryAxis34.getLabel();
        categoryAxis34.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        double double54 = categoryAxis46.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D52, rectangleEdge53);
        java.awt.Font font55 = categoryAxis46.getTickLabelFont();
        categoryAxis34.setLabelFont(font55);
        categoryAxis34.setAxisLineVisible(true);
        java.awt.Paint paint59 = categoryAxis34.getLabelPaint();
        boolean boolean60 = sortOrder33.equals((java.lang.Object) categoryAxis34);
        java.util.List list61 = categoryPlot32.getCategoriesForAxis(categoryAxis34);
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = null;
        double double70 = categoryAxis62.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D68, rectangleEdge69);
        java.awt.Font font71 = categoryAxis62.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis62.setTickLabelInsets(rectangleInsets72);
        categoryAxis62.setMinorTickMarkOutsideLength((-1.0f));
        double double76 = categoryAxis62.getCategoryMargin();
        org.jfree.chart.axis.ValueAxis valueAxis77 = null;
        org.jfree.data.category.CategoryDataset categoryDataset78 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState82 = null;
        try {
            java.awt.Shape shape83 = barRenderer0.createHotSpotShape(graphics2D30, rectangle2D31, categoryPlot32, categoryAxis62, valueAxis77, categoryDataset78, (int) ' ', 4, false, categoryItemRendererState82);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNull(categoryToolTipGenerator29);
        org.junit.Assert.assertNotNull(sortOrder33);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertEquals((double) double54, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertEquals((double) double70, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font71);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.2d + "'", double76 == 0.2d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color6 = java.awt.Color.RED;
        barRenderer0.setShadowPaint((java.awt.Paint) color6);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = barRenderer0.getLegendItemLabelGenerator();
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint(0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int2 = color1.getTransparency();
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator6 = new org.jfree.chart.util.DefaultShadowGenerator((int) '4', color1, 10.0f, (int) (short) 100, (double) (byte) 1);
        int int7 = defaultShadowGenerator6.calculateOffsetX();
        float float8 = defaultShadowGenerator6.getShadowOpacity();
        int int9 = defaultShadowGenerator6.getShadowSize();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 10.0f + "'", float8 == 10.0f);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8, false);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.data.Range range13 = barRenderer0.findRangeBounds(categoryDataset11, false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color16);
        barRenderer0.setSeriesPaint((int) (short) 100, (java.awt.Paint) color17, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        boolean boolean21 = barRenderer0.removeAnnotation(categoryAnnotation20);
        java.awt.Color color22 = java.awt.Color.PINK;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color22, false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendItem1.setLinePaint((java.awt.Paint) color2);
        java.text.AttributedString attributedString4 = legendItem1.getAttributedLabel();
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer5.setLegendShape(100, shape7);
        legendItem1.setShape(shape7);
        boolean boolean10 = legendItem1.isShapeOutlineVisible();
        legendItem1.setURLText("AxisLocation.BOTTOM_OR_LEFT");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(attributedString4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color6 = java.awt.Color.RED;
        barRenderer0.setShadowPaint((java.awt.Paint) color6);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = barRenderer0.getLegendItemLabelGenerator();
        barRenderer0.setShadowYOffset(100.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer11.setLegendShape(100, shape13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = barRenderer11.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint19 = barRenderer11.getBaseItemLabelPaint();
        boolean boolean20 = barRenderer11.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = barRenderer11.getSeriesNegativeItemLabelPosition(0);
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition22);
        org.jfree.chart.LegendItem legendItem26 = barRenderer0.getLegendItem(2, (int) '4');
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator27 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator27);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation29 = null;
        org.jfree.chart.util.Layer layer30 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation29, layer30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNull(legendItem26);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int3 = color2.getTransparency();
        java.awt.Color color4 = color2.brighter();
        lineAndShapeRenderer0.setSeriesOutlinePaint(0, (java.awt.Paint) color4, true);
        java.lang.Object obj7 = lineAndShapeRenderer0.clone();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer1.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer1.setAutoPopulateSeriesOutlinePaint(true);
        barRenderer1.clearSeriesPaints(false);
        java.awt.Paint paint10 = barRenderer1.getSeriesItemLabelPaint(1);
        barRenderer1.removeAnnotations();
        org.jfree.chart.util.StrokeList strokeList12 = new org.jfree.chart.util.StrokeList();
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        strokeList12.setStroke((int) '#', stroke14);
        barRenderer1.setBaseStroke(stroke14);
        java.awt.Paint paint20 = barRenderer1.getItemPaint((int) (short) 0, (int) (byte) 10, true);
        int int21 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer1);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder24 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = categoryAxis25.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D31, rectangleEdge32);
        java.lang.String str34 = categoryAxis25.getLabel();
        categoryAxis25.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = categoryAxis37.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D43, rectangleEdge44);
        java.awt.Font font46 = categoryAxis37.getTickLabelFont();
        categoryAxis25.setLabelFont(font46);
        categoryAxis25.setAxisLineVisible(true);
        java.awt.Paint paint50 = categoryAxis25.getLabelPaint();
        boolean boolean51 = sortOrder24.equals((java.lang.Object) categoryAxis25);
        java.util.List list52 = categoryPlot23.getCategoriesForAxis(categoryAxis25);
        try {
            categoryPlot0.mapDatasetToDomainAxes(0, list52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(list52);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer8.setLegendShape(100, shape10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint13 = null;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape10, stroke12, paint13);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color16);
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape10, (java.awt.Paint) color16);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape10);
        boolean boolean21 = chartEntity19.equals((java.lang.Object) "hi!");
        java.lang.String str22 = chartEntity19.getToolTipText();
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer0.setBaseItemLabelFont(font1, false);
        java.awt.Paint paint5 = barRenderer0.lookupSeriesOutlinePaint((int) (byte) 100);
        boolean boolean6 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        boolean boolean8 = barRenderer0.removeAnnotation(categoryAnnotation7);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8, false);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.data.Range range13 = barRenderer0.findRangeBounds(categoryDataset11, false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color16);
        barRenderer0.setSeriesPaint((int) (short) 100, (java.awt.Paint) color17, false);
        java.awt.color.ColorSpace colorSpace20 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer21.setLegendShape(100, shape23);
        barRenderer21.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer27.setLegendShape(100, shape29);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator34 = barRenderer27.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint35 = barRenderer27.getBaseItemLabelPaint();
        boolean boolean36 = barRenderer27.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = barRenderer27.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor39 = itemLabelPosition38.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor40 = itemLabelPosition38.getRotationAnchor();
        barRenderer21.setBasePositiveItemLabelPosition(itemLabelPosition38, false);
        boolean boolean43 = barRenderer21.getBaseCreateEntities();
        boolean boolean44 = barRenderer21.getAutoPopulateSeriesOutlineStroke();
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        barRenderer21.setSeriesFillPaint((int) '#', (java.awt.Paint) color46);
        org.jfree.chart.renderer.category.BarRenderer barRenderer48 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer48.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer48.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color54 = java.awt.Color.RED;
        barRenderer48.setShadowPaint((java.awt.Paint) color54);
        java.awt.Color color56 = java.awt.Color.ORANGE;
        float[] floatArray61 = new float[] { ' ', (byte) 10, (byte) 1, 100 };
        float[] floatArray62 = color56.getRGBComponents(floatArray61);
        float[] floatArray63 = color54.getColorComponents(floatArray61);
        float[] floatArray64 = color46.getRGBColorComponents(floatArray63);
        try {
            float[] floatArray65 = color17.getComponents(colorSpace20, floatArray63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNull(categoryURLGenerator34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition38);
        org.junit.Assert.assertNotNull(itemLabelAnchor39);
        org.junit.Assert.assertNotNull(textAnchor40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(floatArray61);
        org.junit.Assert.assertNotNull(floatArray62);
        org.junit.Assert.assertNotNull(floatArray63);
        org.junit.Assert.assertNotNull(floatArray64);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8, false);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.data.Range range13 = barRenderer0.findRangeBounds(categoryDataset11, false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color16);
        barRenderer0.setSeriesPaint((int) (short) 100, (java.awt.Paint) color17, false);
        barRenderer0.setBaseCreateEntities(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset23 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup24 = abstractCategoryDataset23.getGroup();
        boolean boolean26 = datasetGroup24.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis27.setLowerMargin(0.0d);
        categoryAxis27.setLowerMargin((double) 1L);
        boolean boolean32 = datasetGroup24.equals((java.lang.Object) categoryAxis27);
        org.jfree.chart.renderer.category.BarRenderer barRenderer34 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer34.setLegendShape(100, shape36);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = barRenderer34.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint42 = barRenderer34.getBaseItemLabelPaint();
        boolean boolean43 = barRenderer34.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent44 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer34);
        java.awt.Color color45 = java.awt.Color.RED;
        barRenderer34.setBaseOutlinePaint((java.awt.Paint) color45);
        categoryAxis27.setTickLabelPaint((java.lang.Comparable) 116.0d, (java.awt.Paint) color45);
        barRenderer0.setBasePaint((java.awt.Paint) color45, false);
        org.jfree.chart.renderer.RenderAttributes renderAttributes50 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke52 = renderAttributes50.getSeriesStroke((int) (byte) -1);
        java.awt.Shape shape55 = renderAttributes50.getItemShape(8, 10);
        boolean boolean56 = renderAttributes50.getAllowNull();
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = null;
        double double65 = categoryAxis57.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D63, rectangleEdge64);
        java.awt.Font font66 = categoryAxis57.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis57.setTickLabelInsets(rectangleInsets67);
        categoryAxis57.setVisible(true);
        categoryAxis57.setLowerMargin((-16.0d));
        int int73 = categoryAxis57.getMaximumCategoryLabelLines();
        java.awt.Font font74 = categoryAxis57.getTickLabelFont();
        renderAttributes50.setDefaultLabelFont(font74);
        barRenderer0.setBaseLegendTextFont(font74);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(datasetGroup24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(categoryURLGenerator41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNull(stroke52);
        org.junit.Assert.assertNull(shape55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertEquals((double) double65, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertNotNull(font74);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis13.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D19, rectangleEdge20);
        java.awt.Font font22 = categoryAxis13.getTickLabelFont();
        java.awt.Font font23 = categoryAxis13.getTickLabelFont();
        java.lang.String str24 = categoryAxis13.getLabelToolTip();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer25.setBaseShapesFilled(true);
        java.lang.Boolean boolean29 = lineAndShapeRenderer25.getSeriesShapesFilled((int) (byte) 100);
        boolean boolean30 = lineAndShapeRenderer25.getBaseLinesVisible();
        boolean boolean31 = categoryAxis13.equals((java.lang.Object) boolean30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str36 = axisLocation35.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation35, plotOrientation37);
        org.jfree.chart.axis.AxisState axisState39 = null;
        categoryAxis13.drawTickMarks(graphics2D32, (double) (-2097346), rectangle2D34, rectangleEdge38, axisState39);
        try {
            double double41 = categoryAxis0.getCategoryEnd((int) (short) 1, (int) (byte) 10, rectangle2D12, rectangleEdge38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNull(boolean29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str36.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke2 = renderAttributes0.getSeriesStroke((int) (byte) -1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape(8, 10);
        java.awt.Paint paint7 = renderAttributes0.getSeriesFillPaint((int) (short) 0);
        java.awt.Shape shape10 = renderAttributes0.getItemShape(10, (-2097346));
        java.awt.Font font11 = renderAttributes0.getDefaultLabelFont();
        java.awt.Stroke stroke12 = null;
        try {
            renderAttributes0.setDefaultOutlineStroke(stroke12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNull(font11);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = abstractCategoryDataset0.getGroup();
        boolean boolean3 = datasetGroup1.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = categoryAxis4.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D10, rectangleEdge11);
        java.awt.Font font13 = categoryAxis4.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis4.setTickLabelInsets(rectangleInsets14);
        double double17 = rectangleInsets14.trimWidth((double) '#');
        double double19 = rectangleInsets14.trimWidth((double) 100L);
        double double21 = rectangleInsets14.calculateLeftInset((double) 1);
        double double23 = rectangleInsets14.calculateRightOutset((double) '4');
        java.lang.String str24 = rectangleInsets14.toString();
        double double26 = rectangleInsets14.extendWidth((double) (byte) 100);
        double double28 = rectangleInsets14.calculateLeftInset((double) 10.0f);
        boolean boolean29 = datasetGroup1.equals((java.lang.Object) double28);
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 19.0d + "'", double17 == 19.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 84.0d + "'", double19 == 84.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 8.0d + "'", double21 == 8.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 8.0d + "'", double23 == 8.0d);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str24.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 116.0d + "'", double26 == 116.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 8.0d + "'", double28 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke2 = renderAttributes0.getSeriesStroke((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer4.setLegendShape(100, shape6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = barRenderer4.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint12 = barRenderer4.getBaseItemLabelPaint();
        renderAttributes0.setSeriesPaint((int) 'a', paint12);
        java.awt.Font font14 = renderAttributes0.getDefaultLabelFont();
        java.lang.Boolean boolean15 = renderAttributes0.getDefaultCreateEntity();
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(categoryURLGenerator11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertNull(boolean15);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendItem1.setLinePaint((java.awt.Paint) color2);
        legendItem1.setLineVisible(true);
        org.jfree.data.general.Dataset dataset6 = legendItem1.getDataset();
        java.awt.Paint paint7 = legendItem1.getOutlinePaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(dataset6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getDrawOutlines();
        boolean boolean2 = lineAndShapeRenderer0.getBaseLinesVisible();
        lineAndShapeRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        boolean boolean5 = lineAndShapeRenderer0.getUseOutlinePaint();
        boolean boolean6 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer12.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer12.setAutoPopulateSeriesOutlinePaint(true);
        barRenderer12.clearSeriesPaints(false);
        java.awt.Paint paint21 = barRenderer12.getSeriesItemLabelPaint(1);
        barRenderer12.removeAnnotations();
        org.jfree.chart.util.StrokeList strokeList23 = new org.jfree.chart.util.StrokeList();
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        strokeList23.setStroke((int) '#', stroke25);
        barRenderer12.setBaseStroke(stroke25);
        java.awt.Paint paint31 = barRenderer12.getItemPaint((int) (short) 0, (int) (byte) 10, true);
        int int32 = categoryPlot11.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation34 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str35 = axisLocation34.toString();
        java.lang.String str36 = axisLocation34.toString();
        categoryPlot11.setDomainAxisLocation(1, axisLocation34);
        categoryPlot11.setDomainCrosshairRowKey((java.lang.Comparable) 3.0d);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = categoryAxis40.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D46, rectangleEdge47);
        java.awt.Font font49 = categoryAxis40.getTickLabelFont();
        java.awt.Font font50 = categoryAxis40.getTickLabelFont();
        java.lang.String str51 = categoryAxis40.getLabelToolTip();
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.data.category.CategoryDataset categoryDataset53 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState57 = null;
        try {
            boolean boolean58 = lineAndShapeRenderer0.hitTest((-1.0d), (double) 255, graphics2D9, rectangle2D10, categoryPlot11, categoryAxis40, valueAxis52, categoryDataset53, 255, (int) (short) 100, false, categoryItemRendererState57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str35.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str36.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertEquals((double) double48, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNull(str51);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer4.setLegendShape(100, shape6);
        barRenderer4.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer10.setLegendShape(100, shape12);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator17 = barRenderer10.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint18 = barRenderer10.getBaseItemLabelPaint();
        boolean boolean19 = barRenderer10.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = barRenderer10.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = itemLabelPosition21.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor23 = itemLabelPosition21.getRotationAnchor();
        barRenderer4.setBasePositiveItemLabelPosition(itemLabelPosition21, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape32 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer30.setLegendShape(100, shape32);
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint35 = null;
        org.jfree.chart.LegendItem legendItem36 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape32, stroke34, paint35);
        java.lang.String str37 = legendItem36.getURLText();
        java.lang.Object obj38 = legendItem36.clone();
        boolean boolean39 = itemLabelPosition21.equals((java.lang.Object) legendItem36);
        legendItem36.setShapeVisible(true);
        legendItem36.setSeriesKey((java.lang.Comparable) 10.0d);
        legendItem36.setLineVisible(false);
        org.jfree.chart.util.ShapeList shapeList46 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape48 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        shapeList46.setShape((int) (byte) 1, shape48);
        legendItem36.setLine(shape48);
        org.jfree.chart.renderer.category.BarRenderer barRenderer55 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape57 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer55.setLegendShape(100, shape57);
        java.awt.Stroke stroke59 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint60 = null;
        org.jfree.chart.LegendItem legendItem61 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape57, stroke59, paint60);
        java.lang.String str62 = legendItem61.getURLText();
        org.jfree.chart.renderer.category.BarRenderer barRenderer63 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer63.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke68 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer63.setSeriesStroke(0, stroke68);
        java.awt.Paint paint71 = barRenderer63.lookupSeriesPaint((-1));
        legendItem61.setLabelPaint(paint71);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier73 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset74 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup75 = abstractCategoryDataset74.getGroup();
        boolean boolean77 = datasetGroup75.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.axis.CategoryAxis categoryAxis78 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis78.setLowerMargin(0.0d);
        categoryAxis78.setLowerMargin((double) 1L);
        boolean boolean83 = datasetGroup75.equals((java.lang.Object) categoryAxis78);
        boolean boolean84 = defaultDrawingSupplier73.equals((java.lang.Object) categoryAxis78);
        java.awt.Shape shape85 = defaultDrawingSupplier73.getNextShape();
        java.awt.Stroke stroke86 = defaultDrawingSupplier73.getNextStroke();
        java.awt.Color color87 = java.awt.Color.CYAN;
        org.jfree.chart.LegendItem legendItem88 = new org.jfree.chart.LegendItem("", "rect", "ChartEntity: tooltip = null", "AxisLocation.BOTTOM_OR_RIGHT", shape48, paint71, stroke86, (java.awt.Paint) color87);
        java.awt.Color color89 = java.awt.Color.ORANGE;
        float[] floatArray94 = new float[] { ' ', (byte) 10, (byte) 1, 100 };
        float[] floatArray95 = color89.getRGBComponents(floatArray94);
        float[] floatArray96 = color87.getRGBColorComponents(floatArray94);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(categoryURLGenerator17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "hi!" + "'", str62.equals("hi!"));
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNotNull(datasetGroup75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(shape85);
        org.junit.Assert.assertNotNull(stroke86);
        org.junit.Assert.assertNotNull(color87);
        org.junit.Assert.assertNotNull(color89);
        org.junit.Assert.assertNotNull(floatArray94);
        org.junit.Assert.assertNotNull(floatArray95);
        org.junit.Assert.assertNotNull(floatArray96);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseOutlinePaint(false);
        boolean boolean3 = lineAndShapeRenderer0.getBaseLinesVisible();
        lineAndShapeRenderer0.setSeriesLinesVisible(255, (java.lang.Boolean) false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer7.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer7.setSeriesStroke(0, stroke12);
        lineAndShapeRenderer0.setBaseStroke(stroke12);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke2 = renderAttributes0.getSeriesStroke((int) (byte) -1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape(8, 10);
        boolean boolean6 = renderAttributes0.getAllowNull();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = categoryAxis7.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D13, rectangleEdge14);
        java.awt.Font font16 = categoryAxis7.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis7.setTickLabelInsets(rectangleInsets17);
        categoryAxis7.setVisible(true);
        categoryAxis7.setLowerMargin((-16.0d));
        int int23 = categoryAxis7.getMaximumCategoryLabelLines();
        java.awt.Font font24 = categoryAxis7.getTickLabelFont();
        renderAttributes0.setDefaultLabelFont(font24);
        java.awt.Shape shape26 = renderAttributes0.getDefaultShape();
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNull(shape26);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.net.URL uRL0 = null;
        java.net.URLClassLoader uRLClassLoader1 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL0, uRLClassLoader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis0.setTickLabelInsets(rectangleInsets10);
        categoryAxis0.setMinorTickMarkOutsideLength((-1.0f));
        categoryAxis0.setLabelToolTip("");
        double double16 = categoryAxis0.getFixedDimension();
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0);
        java.lang.Object obj11 = chartChangeEvent10.getSource();
        java.lang.Object obj12 = chartChangeEvent10.getSource();
        org.jfree.chart.JFreeChart jFreeChart13 = chartChangeEvent10.getChart();
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        chartChangeEvent10.setChart(jFreeChart14);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(jFreeChart13);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.awt.Color color0 = java.awt.Color.orange;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=255,g=200,b=0]" + "'", str1.equals("java.awt.Color[r=255,g=200,b=0]"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer4.setLegendShape(100, shape6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = barRenderer4.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint12 = barRenderer4.getBaseItemLabelPaint();
        boolean boolean13 = barRenderer4.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer4.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor16 = itemLabelPosition15.getItemLabelAnchor();
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition15, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer27.setLegendShape(100, shape29);
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint32 = null;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape29, stroke31, paint32);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color36 = java.awt.Color.getColor("hi!", color35);
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape29, (java.awt.Paint) color35);
        org.jfree.chart.entity.ChartEntity chartEntity38 = new org.jfree.chart.entity.ChartEntity(shape29);
        barRenderer0.setBaseShape(shape29);
        java.awt.Shape shape40 = barRenderer0.getBaseLegendShape();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(categoryURLGenerator11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(itemLabelAnchor16);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(shape40);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin(0.0d);
        java.lang.String str3 = categoryAxis0.getLabel();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis0.setLabelInsets(rectangleInsets4);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer8.setLegendShape(100, shape10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint13 = null;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape10, stroke12, paint13);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color16);
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape10, (java.awt.Paint) color16);
        java.awt.Stroke stroke19 = legendItem18.getOutlineStroke();
        legendItem18.setSeriesIndex((int) '#');
        boolean boolean22 = legendItem18.isLineVisible();
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        boolean boolean2 = categoryAxis1.isMinorTickMarksVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendItem1.setLinePaint((java.awt.Paint) color2);
        java.text.AttributedString attributedString4 = legendItem1.getAttributedLabel();
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer5.setLegendShape(100, shape7);
        legendItem1.setShape(shape7);
        boolean boolean10 = legendItem1.isShapeOutlineVisible();
        legendItem1.setSeriesIndex((int) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = legendItem1.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(attributedString4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer0.setSeriesStroke(0, stroke5);
        java.awt.Paint paint8 = barRenderer0.lookupSeriesPaint((-1));
        org.jfree.chart.LegendItem legendItem11 = barRenderer0.getLegendItem((-2097346), 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setLowerMargin(0.0d);
        categoryAxis12.setLowerMargin((double) 1L);
        boolean boolean17 = categoryAxis12.isAxisLineVisible();
        boolean boolean18 = categoryAxis12.isTickLabelsVisible();
        org.jfree.chart.renderer.RenderAttributes renderAttributes19 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke21 = renderAttributes19.getSeriesStroke((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer23.setLegendShape(100, shape25);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator30 = barRenderer23.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint31 = barRenderer23.getBaseItemLabelPaint();
        renderAttributes19.setSeriesPaint((int) 'a', paint31);
        java.awt.Color color33 = java.awt.Color.gray;
        renderAttributes19.setDefaultFillPaint((java.awt.Paint) color33);
        categoryAxis12.setTickMarkPaint((java.awt.Paint) color33);
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color33);
        java.awt.Paint paint38 = barRenderer0.getLegendTextPaint(0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNull(categoryURLGenerator30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNull(paint38);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D8, rectangleEdge9);
        java.lang.String str11 = categoryAxis2.getLabel();
        categoryAxis2.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis14.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D20, rectangleEdge21);
        java.awt.Font font23 = categoryAxis14.getTickLabelFont();
        categoryAxis2.setLabelFont(font23);
        categoryAxis2.setAxisLineVisible(true);
        java.awt.Paint paint27 = categoryAxis2.getLabelPaint();
        boolean boolean28 = sortOrder1.equals((java.lang.Object) categoryAxis2);
        java.util.List list29 = categoryPlot0.getCategoriesForAxis(categoryAxis2);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor30 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor30);
        org.jfree.chart.plot.Marker marker32 = null;
        boolean boolean33 = categoryPlot0.removeDomainMarker(marker32);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace34);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation36 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation36, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(categoryAnchor30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.event.DatasetChangeListener datasetChangeListener1 = null;
        abstractCategoryDataset0.removeChangeListener(datasetChangeListener1);
        abstractCategoryDataset0.validateObject();
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        barRenderer0.clearSeriesPaints(false);
        java.awt.Paint paint9 = barRenderer0.getSeriesItemLabelPaint(1);
        boolean boolean10 = barRenderer0.getAutoPopulateSeriesPaint();
        java.awt.Paint paint12 = barRenderer0.getSeriesFillPaint((int) '#');
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0);
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color11);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (byte) 0, categoryItemLabelGenerator14, false);
        java.util.EventListener eventListener17 = null;
        boolean boolean18 = barRenderer0.hasListener(eventListener17);
        java.awt.Paint paint19 = barRenderer0.getBaseItemLabelPaint();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 10);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        boolean boolean5 = lineAndShapeRenderer0.getItemShapeVisible(1, (int) (short) 0);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer9.setUseOutlinePaint(false);
        java.awt.Stroke stroke15 = lineAndShapeRenderer9.getItemStroke(0, 0, false);
        categoryPlot8.setRangeGridlineStroke(stroke15);
        categoryPlot8.setRangeCrosshairLockedOnData(true);
        java.awt.Stroke stroke19 = categoryPlot8.getRangeCrosshairStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis20.setLowerMargin(0.0d);
        categoryAxis20.setLowerMargin((double) 1L);
        boolean boolean25 = categoryAxis20.isAxisLineVisible();
        categoryAxis20.setLowerMargin(4.0d);
        float float28 = categoryAxis20.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.renderer.category.BarRenderer barRenderer29 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer29.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer29.setSeriesStroke(0, stroke34);
        org.jfree.chart.renderer.category.BarRenderer barRenderer36 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer36.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer36.setSeriesStroke(0, stroke41);
        barRenderer29.setBaseOutlineStroke(stroke41, true);
        categoryAxis20.setTickMarkStroke(stroke41);
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState51 = null;
        try {
            java.awt.Shape shape52 = lineAndShapeRenderer0.createHotSpotShape(graphics2D6, rectangle2D7, categoryPlot8, categoryAxis20, valueAxis46, categoryDataset47, (int) (byte) 0, 4, false, categoryItemRendererState51);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.0f + "'", float28 == 0.0f);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer0.setSeriesStroke(0, stroke5);
        java.awt.Paint paint8 = barRenderer0.lookupSeriesPaint((-1));
        barRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        barRenderer0.setSeriesFillPaint(52, (java.awt.Paint) color12, false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        double double8 = barRenderer0.getItemMargin();
        java.awt.Paint paint10 = barRenderer0.lookupSeriesFillPaint((int) (short) 1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color6 = java.awt.Color.RED;
        barRenderer0.setShadowPaint((java.awt.Paint) color6);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("ChartEntity: tooltip = null");
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis14.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D20, rectangleEdge21);
        java.awt.Font font23 = categoryAxis14.getTickLabelFont();
        java.awt.Font font24 = categoryAxis14.getTickLabelFont();
        java.lang.String str25 = categoryAxis14.getLabelToolTip();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer26.setBaseShapesFilled(true);
        java.lang.Boolean boolean30 = lineAndShapeRenderer26.getSeriesShapesFilled((int) (byte) 100);
        boolean boolean31 = lineAndShapeRenderer26.getBaseLinesVisible();
        boolean boolean32 = categoryAxis14.equals((java.lang.Object) boolean31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str37 = axisLocation36.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation38 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation36, plotOrientation38);
        org.jfree.chart.axis.AxisState axisState40 = null;
        categoryAxis14.drawTickMarks(graphics2D33, (double) (-2097346), rectangle2D35, rectangleEdge39, axisState40);
        try {
            double double42 = barRenderer0.getItemMiddle((java.lang.Comparable) (byte) 0, (java.lang.Comparable) 0.0d, categoryDataset10, categoryAxis12, rectangle2D13, rectangleEdge39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNull(boolean30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str37.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertNotNull(plotOrientation38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer1.setUseOutlinePaint(false);
        java.awt.Stroke stroke7 = lineAndShapeRenderer1.getItemStroke(0, 0, false);
        categoryPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot0.getDomainAxisForDataset((int) (byte) 10);
        org.jfree.chart.util.SortOrder sortOrder13 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setColumnRenderingOrder(sortOrder13);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(categoryAxis12);
        org.junit.Assert.assertNotNull(sortOrder13);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesShapesFilled((int) (byte) 100);
        boolean boolean5 = lineAndShapeRenderer0.getBaseLinesVisible();
        int int6 = lineAndShapeRenderer0.getPassCount();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = lineAndShapeRenderer0.getBaseItemLabelGenerator();
        boolean boolean10 = lineAndShapeRenderer0.getItemShapeVisible(0, 4);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Font font6 = null;
        barRenderer0.setBaseLegendTextFont(font6);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        java.lang.Object obj10 = standardCategorySeriesLabelGenerator8.clone();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        try {
            java.lang.String str13 = standardCategorySeriesLabelGenerator8.generateLabel(categoryDataset11, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor12 = itemLabelPosition11.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor13 = itemLabelPosition11.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor14 = itemLabelPosition11.getTextAnchor();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(itemLabelAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(textAnchor14);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer4.setLegendShape(100, shape6);
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint9 = null;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape6, stroke8, paint9);
        java.lang.String str11 = legendItem10.getURLText();
        java.lang.Object obj12 = legendItem10.clone();
        boolean boolean13 = legendItem10.isShapeFilled();
        legendItem10.setURLText("NOID");
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer16.setLegendShape(100, shape18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator23 = barRenderer16.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint24 = barRenderer16.getBaseItemLabelPaint();
        boolean boolean25 = barRenderer16.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer16);
        java.awt.Color color27 = java.awt.Color.RED;
        barRenderer16.setBaseOutlinePaint((java.awt.Paint) color27);
        boolean boolean29 = legendItem10.equals((java.lang.Object) color27);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(categoryURLGenerator23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer1.setUseOutlinePaint(false);
        java.awt.Stroke stroke7 = lineAndShapeRenderer1.getItemStroke(0, 0, false);
        categoryPlot0.setRangeGridlineStroke(stroke7);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot0.getDomainMarkers(255, layer12);
        categoryPlot0.setCrosshairDatasetIndex(10, false);
        categoryPlot0.clearRangeMarkers((int) (byte) 0);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot0.getRendererForDataset(categoryDataset19);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNull(categoryItemRenderer20);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getSeriesNegativeItemLabelPosition(0);
        java.awt.Color color12 = java.awt.Color.YELLOW;
        barRenderer0.setBaseLegendTextPaint((java.awt.Paint) color12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer14.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer14.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color20 = java.awt.Color.RED;
        barRenderer14.setShadowPaint((java.awt.Paint) color20);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator22 = barRenderer14.getLegendItemLabelGenerator();
        barRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator22);
        double double24 = barRenderer0.getItemLabelAnchorOffset();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer1.setLegendShape(100, shape3);
        barRenderer1.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer7.setLegendShape(100, shape9);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = barRenderer7.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint15 = barRenderer7.getBaseItemLabelPaint();
        boolean boolean16 = barRenderer7.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer7.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor19 = itemLabelPosition18.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor20 = itemLabelPosition18.getRotationAnchor();
        barRenderer1.setBasePositiveItemLabelPosition(itemLabelPosition18, false);
        boolean boolean23 = barRenderer1.getBaseCreateEntities();
        boolean boolean24 = barRenderer1.getAutoPopulateSeriesOutlineStroke();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        barRenderer1.setSeriesFillPaint((int) '#', (java.awt.Paint) color26);
        java.awt.Color color28 = java.awt.Color.getColor("", color26);
        int int29 = color26.getRGB();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(categoryURLGenerator14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(itemLabelAnchor19);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-8355840) + "'", int29 == (-8355840));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendItem1.setLinePaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer12.setLegendShape(100, shape14);
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint17 = null;
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape14, stroke16, paint17);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color21 = java.awt.Color.getColor("hi!", color20);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape14, (java.awt.Paint) color20);
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity(shape14);
        legendItem1.setLine(shape14);
        java.lang.String str25 = legendItem1.getDescription();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0);
        java.lang.Object obj11 = chartChangeEvent10.getSource();
        java.lang.Object obj12 = chartChangeEvent10.getSource();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        chartChangeEvent10.setType(chartChangeEventType13);
        java.lang.Object obj15 = chartChangeEvent10.getSource();
        org.jfree.chart.JFreeChart jFreeChart16 = chartChangeEvent10.getChart();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(chartChangeEventType13);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNull(jFreeChart16);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesShapesFilled((int) (byte) 100);
        boolean boolean5 = lineAndShapeRenderer0.getBaseLinesVisible();
        lineAndShapeRenderer0.setSeriesShapesVisible((int) (short) 1, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int10 = color9.getTransparency();
        java.awt.Color color11 = color9.brighter();
        lineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color9);
        lineAndShapeRenderer0.setUseOutlinePaint(true);
        java.lang.Object obj15 = lineAndShapeRenderer0.clone();
        lineAndShapeRenderer0.setDefaultEntityRadius(1);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.awt.Paint paint0 = null;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] { paint0 };
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray3 = new java.awt.Paint[] {};
        java.awt.Stroke stroke4 = null;
        java.awt.Stroke[] strokeArray5 = new java.awt.Stroke[] { stroke4 };
        java.awt.Stroke[] strokeArray6 = null;
        java.awt.Shape shape7 = null;
        java.awt.Shape[] shapeArray8 = new java.awt.Shape[] { shape7 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray2, paintArray3, strokeArray5, strokeArray6, shapeArray8);
        java.awt.Shape shape10 = defaultDrawingSupplier9.getNextShape();
        java.lang.Object obj11 = defaultDrawingSupplier9.clone();
        try {
            java.awt.Stroke stroke12 = defaultDrawingSupplier9.getNextOutlineStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(shapeArray8);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer1.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer1.setAutoPopulateSeriesOutlinePaint(true);
        barRenderer1.clearSeriesPaints(false);
        java.awt.Paint paint10 = barRenderer1.getSeriesItemLabelPaint(1);
        barRenderer1.removeAnnotations();
        org.jfree.chart.util.StrokeList strokeList12 = new org.jfree.chart.util.StrokeList();
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        strokeList12.setStroke((int) '#', stroke14);
        barRenderer1.setBaseStroke(stroke14);
        java.awt.Paint paint20 = barRenderer1.getItemPaint((int) (short) 0, (int) (byte) 10, true);
        int int21 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer1);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = categoryAxis22.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D28, rectangleEdge29);
        java.awt.Font font31 = categoryAxis22.getTickLabelFont();
        java.awt.Font font32 = categoryAxis22.getTickLabelFont();
        java.lang.String str33 = categoryAxis22.getLabelToolTip();
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        double double42 = categoryAxis34.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D40, rectangleEdge41);
        java.lang.String str43 = categoryAxis34.getLabel();
        float float44 = categoryAxis34.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = null;
        double double53 = categoryAxis45.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D51, rectangleEdge52);
        java.awt.Font font54 = categoryAxis45.getTickLabelFont();
        java.awt.Font font55 = categoryAxis45.getTickLabelFont();
        org.jfree.chart.plot.Plot plot56 = null;
        categoryAxis45.setPlot(plot56);
        categoryAxis45.setUpperMargin((double) 10.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray62 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis22, categoryAxis34, categoryAxis45, categoryAxis61 };
        categoryPlot0.setDomainAxes(categoryAxisArray62);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = null;
        try {
            categoryPlot0.handleClick((-1), (int) (byte) -1, plotRenderingInfo66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.0f + "'", float44 == 0.0f);
        org.junit.Assert.assertEquals((double) double53, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNotNull(categoryAxisArray62);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Shape shape1 = lineAndShapeRenderer0.getBaseShape();
        lineAndShapeRenderer0.setDefaultEntityRadius((-2097346));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = lineAndShapeRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer1.setLegendShape(100, shape3);
        barRenderer1.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer7.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer7.setSeriesStroke(0, stroke12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer14.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer14.setSeriesStroke(0, stroke19);
        barRenderer7.setBaseOutlineStroke(stroke19, true);
        barRenderer1.setBaseStroke(stroke19);
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int25 = color24.getTransparency();
        barRenderer1.setShadowPaint((java.awt.Paint) color24);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = barRenderer1.getToolTipGenerator((int) (byte) -1, 10, true);
        java.awt.Paint paint31 = barRenderer1.getShadowPaint();
        boolean boolean32 = itemLabelAnchor0.equals((java.lang.Object) barRenderer1);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNull(categoryToolTipGenerator30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
        java.lang.Object obj2 = null;
        int int3 = objectList1.indexOf(obj2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = categoryAxis4.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D10, rectangleEdge11);
        java.awt.Font font13 = categoryAxis4.getTickLabelFont();
        java.awt.Font font14 = categoryAxis4.getTickLabelFont();
        java.lang.String str15 = categoryAxis4.getLabelToolTip();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer16.setBaseShapesFilled(true);
        java.lang.Boolean boolean20 = lineAndShapeRenderer16.getSeriesShapesFilled((int) (byte) 100);
        boolean boolean21 = lineAndShapeRenderer16.getBaseLinesVisible();
        boolean boolean22 = categoryAxis4.equals((java.lang.Object) boolean21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str27 = axisLocation26.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation28 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation26, plotOrientation28);
        org.jfree.chart.axis.AxisState axisState30 = null;
        categoryAxis4.drawTickMarks(graphics2D23, (double) (-2097346), rectangle2D25, rectangleEdge29, axisState30);
        int int32 = objectList1.indexOf((java.lang.Object) graphics2D23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNull(boolean20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str27.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertNotNull(plotOrientation28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke2 = renderAttributes0.getSeriesStroke((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer4.setLegendShape(100, shape6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = barRenderer4.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint12 = barRenderer4.getBaseItemLabelPaint();
        renderAttributes0.setSeriesPaint((int) 'a', paint12);
        java.awt.Paint paint14 = renderAttributes0.getDefaultPaint();
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(categoryURLGenerator11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(paint14);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesShapesFilled((int) (byte) 100);
        boolean boolean5 = lineAndShapeRenderer0.getBaseLinesVisible();
        lineAndShapeRenderer0.removeAnnotations();
        boolean boolean8 = lineAndShapeRenderer0.isSeriesVisible((int) (short) 100);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        java.awt.Font font10 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.Plot plot11 = null;
        categoryAxis0.setPlot(plot11);
        float float13 = categoryAxis0.getTickMarkInsideLength();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis14.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D20, rectangleEdge21);
        java.lang.String str23 = categoryAxis14.getLabel();
        categoryAxis14.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = categoryAxis26.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D32, rectangleEdge33);
        java.awt.Font font35 = categoryAxis26.getTickLabelFont();
        categoryAxis14.setLabelFont(font35);
        categoryAxis14.setAxisLineVisible(true);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor39 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = null;
        double double44 = categoryAxis14.getCategoryJava2DCoordinate(categoryAnchor39, (int) (byte) 0, (int) '4', rectangle2D42, rectangleEdge43);
        org.jfree.chart.event.AxisChangeListener axisChangeListener45 = null;
        categoryAxis14.removeChangeListener(axisChangeListener45);
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color49 = java.awt.Color.getColor("hi!", color48);
        categoryAxis14.setAxisLinePaint((java.awt.Paint) color48);
        categoryAxis0.setTickMarkPaint((java.awt.Paint) color48);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(categoryAnchor39);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(color49);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.END" + "'", str1.equals("CategoryAnchor.END"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape2 = renderAttributes0.getSeriesShape((int) (byte) 100);
        java.awt.Paint paint4 = null;
        renderAttributes0.setSeriesOutlinePaint((int) '4', paint4);
        java.awt.Color color7 = java.awt.Color.WHITE;
        renderAttributes0.setSeriesPaint((int) (short) 1, (java.awt.Paint) color7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer9.setBaseItemLabelFont(font10, false);
        renderAttributes0.setDefaultLabelFont(font10);
        try {
            java.awt.Stroke stroke15 = renderAttributes0.getSeriesOutlineStroke((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        java.awt.Font font10 = categoryAxis0.getTickLabelFont();
        java.lang.String str11 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer12.setBaseShapesFilled(true);
        java.lang.Boolean boolean16 = lineAndShapeRenderer12.getSeriesShapesFilled((int) (byte) 100);
        boolean boolean17 = lineAndShapeRenderer12.getBaseLinesVisible();
        boolean boolean18 = categoryAxis0.equals((java.lang.Object) boolean17);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = categoryAxis19.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D25, rectangleEdge26);
        java.awt.Font font28 = categoryAxis19.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis19.setTickLabelInsets(rectangleInsets29);
        double double32 = rectangleInsets29.trimWidth((double) '#');
        double double34 = rectangleInsets29.trimWidth((double) 100L);
        double double36 = rectangleInsets29.calculateLeftInset((double) 1);
        double double38 = rectangleInsets29.calculateRightOutset((double) '4');
        java.lang.String str39 = rectangleInsets29.toString();
        double double41 = rectangleInsets29.extendWidth((double) (byte) 100);
        categoryAxis0.setLabelInsets(rectangleInsets29);
        double double43 = rectangleInsets29.getTop();
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        try {
            rectangleInsets29.trim(rectangle2D44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 19.0d + "'", double32 == 19.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 84.0d + "'", double34 == 84.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 8.0d + "'", double36 == 8.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 8.0d + "'", double38 == 8.0d);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str39.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 116.0d + "'", double41 == 116.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 4.0d + "'", double43 == 4.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.extendHeight((double) 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.awt.Color color1 = java.awt.Color.getColor("{0}");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke2 = renderAttributes0.getSeriesStroke((int) (byte) -1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape(8, 10);
        boolean boolean6 = renderAttributes0.getAllowNull();
        java.awt.Paint paint8 = null;
        renderAttributes0.setSeriesPaint((int) '#', paint8);
        java.awt.Stroke stroke10 = renderAttributes0.getDefaultStroke();
        java.lang.Boolean boolean11 = renderAttributes0.getDefaultCreateEntity();
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNull(boolean11);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        shapeList0.setShape((int) (byte) 1, shape2);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape2, "NOID", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator7 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator8 = null;
        try {
            java.lang.String str9 = chartEntity6.getImageMapAreaTag(toolTipTagFragmentGenerator7, uRLTagFragmentGenerator8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer4.setLegendShape(100, shape6);
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint9 = null;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape6, stroke8, paint9);
        java.lang.String str11 = legendItem10.getURLText();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = legendItem10.getFillPaintTransformer();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis13.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D19, rectangleEdge20);
        java.awt.Font font22 = categoryAxis13.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis13.setTickLabelInsets(rectangleInsets23);
        categoryAxis13.setMinorTickMarkOutsideLength((-1.0f));
        java.awt.Font font27 = categoryAxis13.getTickLabelFont();
        java.awt.Font font29 = categoryAxis13.getTickLabelFont((java.lang.Comparable) (byte) 100);
        legendItem10.setLabelFont(font29);
        java.awt.Shape shape31 = legendItem10.getLine();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(gradientPaintTransformer12);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(shape31);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer0.setBaseItemLabelFont(font1, false);
        boolean boolean5 = barRenderer0.isSeriesVisible((int) (short) 1);
        barRenderer0.setShadowXOffset((double) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (byte) 1, categoryToolTipGenerator9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer0.setSeriesItemLabelGenerator(3, categoryItemLabelGenerator13, false);
        java.awt.Paint paint17 = barRenderer0.getSeriesOutlinePaint((-1494));
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNull(paint17);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        barRenderer0.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer6.setLegendShape(100, shape8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer6.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint14 = barRenderer6.getBaseItemLabelPaint();
        boolean boolean15 = barRenderer6.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer6.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = itemLabelPosition17.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor19 = itemLabelPosition17.getRotationAnchor();
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition17, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer26.setLegendShape(100, shape28);
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint31 = null;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape28, stroke30, paint31);
        java.lang.String str33 = legendItem32.getURLText();
        java.lang.Object obj34 = legendItem32.clone();
        boolean boolean35 = itemLabelPosition17.equals((java.lang.Object) legendItem32);
        legendItem32.setShapeVisible(true);
        legendItem32.setSeriesKey((java.lang.Comparable) 10.0d);
        java.lang.String str40 = legendItem32.getLabel();
        java.lang.Object obj41 = legendItem32.clone();
        java.awt.Paint paint42 = legendItem32.getOutlinePaint();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getDrawOutlines();
        boolean boolean2 = lineAndShapeRenderer0.getBaseLinesVisible();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(8);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = categoryAxis5.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D11, rectangleEdge12);
        java.lang.String str14 = categoryAxis5.getLabel();
        categoryAxis5.setLabelURL("hi!");
        org.jfree.chart.plot.Plot plot17 = null;
        categoryAxis5.setPlot(plot17);
        int int19 = categoryAxis5.getCategoryLabelPositionOffset();
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        int int22 = color21.getGreen();
        barRenderer20.setBaseOutlinePaint((java.awt.Paint) color21);
        java.awt.Stroke stroke25 = null;
        barRenderer20.setSeriesOutlineStroke(0, stroke25);
        java.awt.Paint paint27 = barRenderer20.getBasePaint();
        categoryAxis5.setAxisLinePaint(paint27);
        boolean boolean29 = lineAndShapeRenderer0.equals((java.lang.Object) categoryAxis5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 255 + "'", int22 == 255);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer0.setBaseItemLabelFont(font1, false);
        boolean boolean5 = barRenderer0.isSeriesVisible((int) (short) 1);
        barRenderer0.setShadowXOffset((double) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (byte) 1, categoryToolTipGenerator9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation12 = null;
        boolean boolean13 = barRenderer0.removeAnnotation(categoryAnnotation12);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer1.setUseOutlinePaint(false);
        java.awt.Stroke stroke7 = lineAndShapeRenderer1.getItemStroke(0, 0, false);
        categoryPlot0.setRangeGridlineStroke(stroke7);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot0.getDomainMarkers(255, layer12);
        categoryPlot0.setCrosshairDatasetIndex(10, false);
        categoryPlot0.clearRangeMarkers((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str21 = axisLocation20.toString();
        java.lang.String str22 = axisLocation20.toString();
        categoryPlot0.setDomainAxisLocation(10, axisLocation20);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str21.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str22.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesShapesFilled((int) (byte) 100);
        boolean boolean5 = lineAndShapeRenderer0.getBaseLinesVisible();
        int int6 = lineAndShapeRenderer0.getPassCount();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) ' ', (java.lang.Boolean) true);
        java.awt.Paint paint10 = null;
        lineAndShapeRenderer0.setBasePaint(paint10, false);
        lineAndShapeRenderer0.setUseSeriesOffset(false);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getDrawOutlines();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = lineAndShapeRenderer0.hasListener(eventListener2);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesOutlinePaint((int) (byte) 10);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer10.setUseOutlinePaint(false);
        java.awt.Stroke stroke16 = lineAndShapeRenderer10.getItemStroke(0, 0, false);
        categoryPlot9.setRangeGridlineStroke(stroke16);
        categoryPlot9.setRangeCrosshairLockedOnData(true);
        java.awt.Stroke stroke20 = categoryPlot9.getRangeCrosshairStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = categoryAxis21.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D27, rectangleEdge28);
        java.awt.Font font30 = categoryAxis21.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis21.setTickLabelInsets(rectangleInsets31);
        categoryAxis21.setVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        try {
            lineAndShapeRenderer0.drawItem(graphics2D6, categoryItemRendererState7, rectangle2D8, categoryPlot9, categoryAxis21, valueAxis35, categoryDataset36, 3, (int) (byte) 10, false, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0);
        java.awt.Color color11 = java.awt.Color.RED;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color11);
        int int13 = color11.getTransparency();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        barRenderer0.clearSeriesPaints(false);
        java.awt.Shape shape11 = barRenderer0.getItemShape(0, (int) (short) 1, false);
        barRenderer0.setMinimumBarLength(84.0d);
        boolean boolean15 = barRenderer0.isSeriesItemLabelsVisible((-1));
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.awt.Paint paint0 = null;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] { paint0 };
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray3 = new java.awt.Paint[] {};
        java.awt.Stroke stroke4 = null;
        java.awt.Stroke[] strokeArray5 = new java.awt.Stroke[] { stroke4 };
        java.awt.Stroke[] strokeArray6 = null;
        java.awt.Shape shape7 = null;
        java.awt.Shape[] shapeArray8 = new java.awt.Shape[] { shape7 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray2, paintArray3, strokeArray5, strokeArray6, shapeArray8);
        java.awt.Shape shape10 = defaultDrawingSupplier9.getNextShape();
        java.awt.Stroke stroke11 = defaultDrawingSupplier9.getNextStroke();
        java.awt.Paint paint12 = defaultDrawingSupplier9.getNextPaint();
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(shapeArray8);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("java.awt.Color[r=255,g=200,b=0]");
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin(0.0d);
        categoryAxis0.setLowerMargin((double) 1L);
        boolean boolean5 = categoryAxis0.isAxisLineVisible();
        categoryAxis0.setLowerMargin(4.0d);
        float float8 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D15, rectangleEdge16);
        java.awt.Font font18 = categoryAxis9.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis9.setTickLabelInsets(rectangleInsets19);
        double double22 = rectangleInsets19.trimWidth((double) '#');
        double double24 = rectangleInsets19.trimWidth((double) 100L);
        double double26 = rectangleInsets19.calculateLeftInset((double) 1);
        double double28 = rectangleInsets19.calculateRightOutset((double) '4');
        java.lang.String str29 = rectangleInsets19.toString();
        categoryAxis0.setTickLabelInsets(rectangleInsets19);
        org.jfree.chart.util.UnitType unitType31 = rectangleInsets19.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        try {
            rectangleInsets19.trim(rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 19.0d + "'", double22 == 19.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 84.0d + "'", double24 == 84.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 8.0d + "'", double26 == 8.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 8.0d + "'", double28 == 8.0d);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str29.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertNotNull(unitType31);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer1.setUseOutlinePaint(false);
        java.awt.Stroke stroke7 = lineAndShapeRenderer1.getItemStroke(0, 0, false);
        categoryPlot0.setRangeGridlineStroke(stroke7);
        java.awt.Paint paint9 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke2 = renderAttributes0.getSeriesStroke((int) (byte) -1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape(8, 10);
        java.awt.Shape shape8 = renderAttributes0.getItemShape((int) (byte) 0, (-136));
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNull(shape8);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesShapesFilled((int) (byte) 100);
        boolean boolean5 = lineAndShapeRenderer0.getBaseLinesVisible();
        lineAndShapeRenderer0.setSeriesShapesVisible((int) (short) 1, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int10 = color9.getTransparency();
        java.awt.Color color11 = color9.brighter();
        lineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color9);
        lineAndShapeRenderer0.setUseOutlinePaint(true);
        java.lang.Object obj15 = lineAndShapeRenderer0.clone();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = null;
        lineAndShapeRenderer0.setSeriesToolTipGenerator((int) ' ', categoryToolTipGenerator17);
        boolean boolean19 = lineAndShapeRenderer0.getBaseShapesVisible();
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer1.setUseOutlinePaint(false);
        java.awt.Stroke stroke7 = lineAndShapeRenderer1.getItemStroke(0, 0, false);
        categoryPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.util.ShapeList shapeList13 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.util.ShapeList shapeList15 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        shapeList15.setShape((int) (byte) 1, shape17);
        shapeList13.setShape((int) (byte) 100, shape17);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer20.setLegendShape(100, shape22);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.plot.Marker marker27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        barRenderer20.drawRangeMarker(graphics2D24, categoryPlot25, valueAxis26, marker27, rectangle2D28);
        boolean boolean30 = shapeList13.equals((java.lang.Object) valueAxis26);
        java.lang.Object obj31 = shapeList13.clone();
        boolean boolean32 = datasetRenderingOrder11.equals(obj31);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendItem1.setLinePaint((java.awt.Paint) color2);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset4 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState5 = null;
        abstractCategoryDataset4.setSelectionState(categoryDatasetSelectionState5);
        legendItem1.setDataset((org.jfree.data.general.Dataset) abstractCategoryDataset4);
        legendItem1.setDescription("ItemLabelAnchor.OUTSIDE9");
        java.text.AttributedString attributedString10 = legendItem1.getAttributedLabel();
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer11.setLegendShape(100, shape13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = barRenderer11.getURLGenerator(10, (int) (byte) 1, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = null;
        barRenderer11.setBaseToolTipGenerator(categoryToolTipGenerator19, false);
        boolean boolean22 = barRenderer11.getAutoPopulateSeriesPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer23.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer23.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color29 = java.awt.Color.RED;
        barRenderer23.setShadowPaint((java.awt.Paint) color29);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator31 = barRenderer23.getLegendItemLabelGenerator();
        barRenderer23.setShadowYOffset(100.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer34 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer34.setLegendShape(100, shape36);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = barRenderer34.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint42 = barRenderer34.getBaseItemLabelPaint();
        boolean boolean43 = barRenderer34.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = barRenderer34.getSeriesNegativeItemLabelPosition(0);
        barRenderer23.setNegativeItemLabelPositionFallback(itemLabelPosition45);
        barRenderer11.setBasePositiveItemLabelPosition(itemLabelPosition45);
        java.awt.Stroke stroke49 = barRenderer11.lookupSeriesStroke((int) (short) 100);
        legendItem1.setOutlineStroke(stroke49);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(attributedString10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator31);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(categoryURLGenerator41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition45);
        org.junit.Assert.assertNotNull(stroke49);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont();
        java.awt.Font font10 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor11, (int) ' ', (int) (byte) 100, rectangle2D14, rectangleEdge15);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str21 = axisLocation20.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation20, plotOrientation22);
        try {
            double double24 = categoryAxis0.getCategoryStart((int) (short) 10, (int) '4', rectangle2D19, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(categoryAnchor11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str21.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertNotNull(plotOrientation22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer0.setSeriesStroke(0, stroke5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer7.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer7.setSeriesStroke(0, stroke12);
        barRenderer0.setBaseOutlineStroke(stroke12, true);
        barRenderer0.clearSeriesStrokes(true);
        int int18 = barRenderer0.getPassCount();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator9 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator9);
        int int11 = barRenderer0.getRowCount();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer4.setLegendShape(100, shape6);
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint9 = null;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape6, stroke8, paint9);
        java.lang.String str11 = legendItem10.getURLText();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = legendItem10.getFillPaintTransformer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer13.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer13.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color19 = java.awt.Color.RED;
        barRenderer13.setShadowPaint((java.awt.Paint) color19);
        int int21 = color19.getTransparency();
        legendItem10.setOutlinePaint((java.awt.Paint) color19);
        int int23 = legendItem10.getDatasetIndex();
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset24 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup25 = abstractCategoryDataset24.getGroup();
        java.util.EventListener eventListener26 = null;
        boolean boolean27 = abstractCategoryDataset24.hasListener(eventListener26);
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState28 = abstractCategoryDataset24.getSelectionState();
        legendItem10.setDataset((org.jfree.data.general.Dataset) abstractCategoryDataset24);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(gradientPaintTransformer12);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(datasetGroup25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(categoryDatasetSelectionState28);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer1.setUseOutlinePaint(false);
        java.awt.Stroke stroke7 = lineAndShapeRenderer1.getItemStroke(0, 0, false);
        categoryPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace9);
        categoryPlot0.setBackgroundAlpha((-1.0f));
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer22.setLegendShape(100, shape24);
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint27 = null;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape24, stroke26, paint27);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color31 = java.awt.Color.getColor("hi!", color30);
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape24, (java.awt.Paint) color30);
        java.awt.Stroke stroke33 = legendItem32.getOutlineStroke();
        boolean boolean34 = plotOrientation13.equals((java.lang.Object) legendItem32);
        java.lang.String str35 = plotOrientation13.toString();
        org.jfree.chart.renderer.category.BarRenderer barRenderer36 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer36.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer36.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Paint paint42 = barRenderer36.getBaseOutlinePaint();
        barRenderer36.setItemLabelAnchorOffset((double) (byte) 100);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset45 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState46 = null;
        abstractCategoryDataset45.setSelectionState(categoryDatasetSelectionState46);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener48 = null;
        abstractCategoryDataset45.addChangeListener(datasetChangeListener48);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo50 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent51 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) barRenderer36, (org.jfree.data.general.Dataset) abstractCategoryDataset45, datasetChangeInfo50);
        boolean boolean52 = plotOrientation13.equals((java.lang.Object) barRenderer36);
        java.lang.String str53 = plotOrientation13.toString();
        categoryPlot0.setOrientation(plotOrientation13);
        org.jfree.chart.util.Layer layer56 = null;
        java.util.Collection collection57 = categoryPlot0.getDomainMarkers((-1494), layer56);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "PlotOrientation.VERTICAL" + "'", str35.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "PlotOrientation.VERTICAL" + "'", str53.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNull(collection57);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        shapeList0.setShape((int) (byte) 1, shape2);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape2, "NOID", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        java.lang.String str7 = chartEntity6.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ChartEntity: tooltip = NOID" + "'", str7.equals("ChartEntity: tooltip = NOID"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesShapesFilled((int) (byte) 100);
        boolean boolean5 = lineAndShapeRenderer0.getBaseLinesVisible();
        lineAndShapeRenderer0.setAutoPopulateSeriesPaint(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8, false);
        lineAndShapeRenderer0.setSeriesShapesFilled((int) (short) 1, false);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.clearSeriesStrokes(true);
        boolean boolean6 = barRenderer0.isItemLabelVisible((int) (byte) 0, (int) (byte) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) '4', categoryItemLabelGenerator8);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D8, rectangleEdge9);
        java.lang.String str11 = categoryAxis2.getLabel();
        categoryAxis2.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis14.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D20, rectangleEdge21);
        java.awt.Font font23 = categoryAxis14.getTickLabelFont();
        categoryAxis2.setLabelFont(font23);
        categoryAxis2.setAxisLineVisible(true);
        java.awt.Paint paint27 = categoryAxis2.getLabelPaint();
        boolean boolean28 = sortOrder1.equals((java.lang.Object) categoryAxis2);
        java.util.List list29 = categoryPlot0.getCategoriesForAxis(categoryAxis2);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor30 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor30);
        org.jfree.chart.plot.Marker marker32 = null;
        boolean boolean33 = categoryPlot0.removeDomainMarker(marker32);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        try {
            int int35 = categoryPlot0.getRangeAxisIndex(valueAxis34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(categoryAnchor30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer1.setUseOutlinePaint(false);
        java.awt.Stroke stroke7 = lineAndShapeRenderer1.getItemStroke(0, 0, false);
        categoryPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            categoryPlot0.addRangeMarker(3, marker12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        barRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false);
        boolean boolean13 = barRenderer0.isSeriesVisibleInLegend(0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer8.setLegendShape(100, shape10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint13 = null;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape10, stroke12, paint13);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color16);
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape10, (java.awt.Paint) color16);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape10);
        boolean boolean21 = chartEntity19.equals((java.lang.Object) "hi!");
        java.lang.String str22 = chartEntity19.getURLText();
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        chartEntity19.setArea(shape23);
        java.lang.String str25 = chartEntity19.getToolTipText();
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer1.setUseOutlinePaint(false);
        java.awt.Stroke stroke7 = lineAndShapeRenderer1.getItemStroke(0, 0, false);
        categoryPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.panRangeAxes(0.0d, plotRenderingInfo11, point2D12);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) ' ', (int) '#', (int) (short) 10);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint8 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getSeriesNegativeItemLabelPosition(0);
        java.awt.Color color12 = java.awt.Color.YELLOW;
        barRenderer0.setBaseLegendTextPaint((java.awt.Paint) color12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer0.getBasePositiveItemLabelPosition();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlignment(0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer4.setLegendShape(100, shape6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = barRenderer4.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint12 = barRenderer4.getBaseItemLabelPaint();
        boolean boolean13 = barRenderer4.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer4.getSeriesNegativeItemLabelPosition(0);
        java.awt.Stroke stroke17 = barRenderer4.getSeriesOutlineStroke((int) (short) 0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        barRenderer4.notifyListeners(rendererChangeEvent18);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer20.setBaseItemLabelFont(font21, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = categoryAxis24.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D30, rectangleEdge31);
        java.lang.String str33 = categoryAxis24.getLabel();
        categoryAxis24.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = null;
        double double44 = categoryAxis36.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D42, rectangleEdge43);
        java.awt.Font font45 = categoryAxis36.getTickLabelFont();
        categoryAxis24.setLabelFont(font45);
        barRenderer20.setBaseLegendTextFont(font45);
        barRenderer4.setBaseLegendTextFont(font45);
        java.awt.Shape shape50 = barRenderer4.getLegendShape((int) (short) 100);
        categoryPlot0.setRenderer(255, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(categoryURLGenerator11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(shape50);
    }
}

