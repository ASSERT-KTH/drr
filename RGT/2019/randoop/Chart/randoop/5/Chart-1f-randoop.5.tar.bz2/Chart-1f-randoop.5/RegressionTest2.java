import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int3 = color2.getTransparency();
        java.awt.Color color4 = color2.brighter();
        lineAndShapeRenderer0.setSeriesOutlinePaint(0, (java.awt.Paint) color4, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        java.awt.Stroke stroke10 = lineAndShapeRenderer0.lookupSeriesOutlineStroke((int) '#');
        boolean boolean11 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin(0.0d);
        categoryAxis0.setLowerMargin((double) 1L);
        boolean boolean5 = categoryAxis0.isAxisLineVisible();
        categoryAxis0.setLowerMargin(4.0d);
        float float8 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer9.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer9.setSeriesStroke(0, stroke14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer16.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer16.setSeriesStroke(0, stroke21);
        barRenderer9.setBaseOutlineStroke(stroke21, true);
        categoryAxis0.setTickMarkStroke(stroke21);
        categoryAxis0.setMaximumCategoryLabelWidthRatio((-1.0f));
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer28.setLegendShape(100, shape30);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator35 = barRenderer28.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint36 = barRenderer28.getBaseItemLabelPaint();
        boolean boolean37 = barRenderer28.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = barRenderer28.getSeriesNegativeItemLabelPosition(0);
        java.awt.Color color40 = java.awt.Color.YELLOW;
        barRenderer28.setBaseLegendTextPaint((java.awt.Paint) color40);
        categoryAxis0.setTickMarkPaint((java.awt.Paint) color40);
        categoryAxis0.setLabelToolTip("AxisLocation.BOTTOM_OR_RIGHT");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNull(categoryURLGenerator35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(color40);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = barRenderer0.getSeriesToolTipGenerator((int) (short) 100);
        boolean boolean6 = barRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Paint paint7 = barRenderer0.getBaseItemLabelPaint();
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer1.setUseOutlinePaint(false);
        java.awt.Stroke stroke7 = lineAndShapeRenderer1.getItemStroke(0, 0, false);
        categoryPlot0.setRangeGridlineStroke(stroke7);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        java.awt.Stroke stroke11 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer12.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer12.setAutoPopulateSeriesOutlinePaint(true);
        barRenderer12.clearSeriesPaints(false);
        java.awt.Paint paint21 = barRenderer12.getSeriesItemLabelPaint(1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = barRenderer12.getSeriesItemLabelGenerator((int) '#');
        java.awt.Stroke stroke25 = barRenderer12.lookupSeriesOutlineStroke(0);
        categoryPlot0.setDomainGridlineStroke(stroke25);
        org.jfree.chart.renderer.category.BarRenderer barRenderer31 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer31.setLegendShape(100, shape33);
        java.awt.Stroke stroke35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint36 = null;
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape33, stroke35, paint36);
        java.lang.String str38 = legendItem37.getURLText();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer39 = legendItem37.getFillPaintTransformer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer40 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer40.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer40.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Color color46 = java.awt.Color.RED;
        barRenderer40.setShadowPaint((java.awt.Paint) color46);
        int int48 = color46.getTransparency();
        legendItem37.setOutlinePaint((java.awt.Paint) color46);
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color46);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer51 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer51.setUseOutlinePaint(false);
        java.awt.Stroke stroke57 = lineAndShapeRenderer51.getItemStroke(0, 0, false);
        categoryPlot0.setRangeCrosshairStroke(stroke57);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertNotNull(gradientPaintTransformer39);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(stroke57);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D6, rectangleEdge7);
        java.lang.String str9 = categoryAxis0.getLabel();
        categoryAxis0.setLabelURL("hi!");
        org.jfree.chart.plot.Plot plot12 = null;
        categoryAxis0.setPlot(plot12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder15 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = categoryAxis16.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D22, rectangleEdge23);
        java.lang.String str25 = categoryAxis16.getLabel();
        categoryAxis16.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        double double36 = categoryAxis28.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D34, rectangleEdge35);
        java.awt.Font font37 = categoryAxis28.getTickLabelFont();
        categoryAxis16.setLabelFont(font37);
        categoryAxis16.setAxisLineVisible(true);
        java.awt.Paint paint41 = categoryAxis16.getLabelPaint();
        boolean boolean42 = sortOrder15.equals((java.lang.Object) categoryAxis16);
        java.util.List list43 = categoryPlot14.getCategoriesForAxis(categoryAxis16);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor44 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot14.setDomainGridlinePosition(categoryAnchor44);
        org.jfree.chart.plot.Marker marker46 = null;
        boolean boolean47 = categoryPlot14.removeDomainMarker(marker46);
        org.jfree.chart.axis.AxisLocation axisLocation48 = categoryPlot14.getDomainAxisLocation();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot14);
        org.jfree.chart.axis.AxisLocation axisLocation51 = categoryPlot14.getDomainAxisLocation((int) (short) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder54 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = null;
        double double63 = categoryAxis55.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D61, rectangleEdge62);
        java.lang.String str64 = categoryAxis55.getLabel();
        categoryAxis55.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis67 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D73 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = null;
        double double75 = categoryAxis67.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D73, rectangleEdge74);
        java.awt.Font font76 = categoryAxis67.getTickLabelFont();
        categoryAxis55.setLabelFont(font76);
        categoryAxis55.setAxisLineVisible(true);
        java.awt.Paint paint80 = categoryAxis55.getLabelPaint();
        boolean boolean81 = sortOrder54.equals((java.lang.Object) categoryAxis55);
        java.util.List list82 = categoryPlot53.getCategoriesForAxis(categoryAxis55);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor83 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot53.setDomainGridlinePosition(categoryAnchor83);
        categoryPlot53.setOutlineVisible(false);
        categoryPlot53.setNotify(true);
        org.jfree.chart.axis.AxisLocation axisLocation90 = categoryPlot53.getRangeAxisLocation((int) (short) 100);
        categoryPlot14.setDomainAxisLocation(128, axisLocation90, false);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNotNull(categoryAnchor44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertNotNull(sortOrder54);
        org.junit.Assert.assertEquals((double) double63, Double.NaN, 0);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertEquals((double) double75, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font76);
        org.junit.Assert.assertNotNull(paint80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(list82);
        org.junit.Assert.assertNotNull(categoryAnchor83);
        org.junit.Assert.assertNotNull(axisLocation90);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer10.setLegendShape(100, shape12);
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint15 = null;
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape12, stroke14, paint15);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color19 = java.awt.Color.getColor("hi!", color18);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape12, (java.awt.Paint) color18);
        java.awt.Stroke stroke21 = legendItem20.getOutlineStroke();
        boolean boolean22 = plotOrientation1.equals((java.lang.Object) legendItem20);
        java.lang.String str23 = plotOrientation1.toString();
        org.jfree.chart.renderer.category.BarRenderer barRenderer24 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer24.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer24.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Paint paint30 = barRenderer24.getBaseOutlinePaint();
        barRenderer24.setItemLabelAnchorOffset((double) (byte) 100);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset33 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState34 = null;
        abstractCategoryDataset33.setSelectionState(categoryDatasetSelectionState34);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener36 = null;
        abstractCategoryDataset33.addChangeListener(datasetChangeListener36);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo38 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent39 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) barRenderer24, (org.jfree.data.general.Dataset) abstractCategoryDataset33, datasetChangeInfo38);
        boolean boolean40 = plotOrientation1.equals((java.lang.Object) barRenderer24);
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PlotOrientation.VERTICAL" + "'", str23.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.addValue((java.lang.Number) 3.0d, (java.lang.Comparable) 8.0d, (java.lang.Comparable) 1.0d);
        java.util.List list5 = defaultCategoryDataset0.getRowKeys();
        try {
            boolean boolean8 = defaultCategoryDataset0.isSelected((int) 'a', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer1.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer1.setAutoPopulateSeriesOutlinePaint(true);
        barRenderer1.clearSeriesPaints(false);
        java.awt.Paint paint10 = barRenderer1.getSeriesItemLabelPaint(1);
        barRenderer1.removeAnnotations();
        org.jfree.chart.util.StrokeList strokeList12 = new org.jfree.chart.util.StrokeList();
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        strokeList12.setStroke((int) '#', stroke14);
        barRenderer1.setBaseStroke(stroke14);
        java.awt.Paint paint20 = barRenderer1.getItemPaint((int) (short) 0, (int) (byte) 10, true);
        int int21 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer1);
        categoryPlot0.setRangeCrosshairVisible(true);
        float float24 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = categoryPlot0.getRangeMarkers(layer25);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
        org.junit.Assert.assertNull(collection26);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setLegendShape(100, shape2);
        barRenderer0.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer6.setLegendShape(100, shape8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer6.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint14 = barRenderer6.getBaseItemLabelPaint();
        boolean boolean15 = barRenderer6.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer6.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = itemLabelPosition17.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor19 = itemLabelPosition17.getRotationAnchor();
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition17, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer26.setLegendShape(100, shape28);
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint31 = null;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", shape28, stroke30, paint31);
        java.lang.String str33 = legendItem32.getURLText();
        java.lang.Object obj34 = legendItem32.clone();
        boolean boolean35 = itemLabelPosition17.equals((java.lang.Object) legendItem32);
        legendItem32.setShapeVisible(true);
        legendItem32.setSeriesKey((java.lang.Comparable) 10.0d);
        java.lang.String str40 = legendItem32.getLabel();
        java.awt.Stroke stroke41 = legendItem32.getOutlineStroke();
        java.awt.Paint paint42 = legendItem32.getOutlinePaint();
        java.awt.Color color43 = java.awt.Color.WHITE;
        java.awt.Color color44 = color43.darker();
        legendItem32.setLinePaint((java.awt.Paint) color44);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset46 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.renderer.category.BarRenderer barRenderer47 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer47.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        barRenderer47.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Paint paint53 = barRenderer47.getBaseOutlinePaint();
        barRenderer47.setItemLabelAnchorOffset((double) (byte) 100);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset56 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState57 = null;
        abstractCategoryDataset56.setSelectionState(categoryDatasetSelectionState57);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener59 = null;
        abstractCategoryDataset56.addChangeListener(datasetChangeListener59);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo61 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent62 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) barRenderer47, (org.jfree.data.general.Dataset) abstractCategoryDataset56, datasetChangeInfo61);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo63 = datasetChangeEvent62.getInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent64 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) color44, (org.jfree.data.general.Dataset) defaultCategoryDataset46, datasetChangeInfo63);
        float[] floatArray65 = null;
        float[] floatArray66 = color44.getRGBColorComponents(floatArray65);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(datasetChangeInfo63);
        org.junit.Assert.assertNotNull(floatArray66);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D7, rectangleEdge8);
        java.awt.Font font10 = categoryAxis1.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis1.setTickLabelInsets(rectangleInsets11);
        categoryAxis1.setVisible(true);
        categoryAxis1.setLowerMargin((-16.0d));
        int int17 = categoryAxis1.getMaximumCategoryLabelLines();
        java.awt.Font font18 = categoryAxis1.getTickLabelFont();
        boolean boolean19 = shapeList0.equals((java.lang.Object) categoryAxis1);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesShapesFilled((int) (byte) 100);
        boolean boolean5 = lineAndShapeRenderer0.getBaseLinesVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer6.setLegendShape(100, shape8);
        barRenderer6.setShadowXOffset((double) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer12.setLegendShape(100, shape14);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = barRenderer12.getURLGenerator(10, (int) (byte) 1, false);
        java.awt.Paint paint20 = barRenderer12.getBaseItemLabelPaint();
        boolean boolean21 = barRenderer12.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = barRenderer12.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor24 = itemLabelPosition23.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor25 = itemLabelPosition23.getRotationAnchor();
        barRenderer6.setBasePositiveItemLabelPosition(itemLabelPosition23, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor28 = itemLabelPosition23.getItemLabelAnchor();
        lineAndShapeRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition23);
        lineAndShapeRenderer0.setSeriesShapesVisible(5, true);
        boolean boolean33 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNull(categoryURLGenerator19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(itemLabelAnchor24);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNotNull(itemLabelAnchor28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("NOID");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder6 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = categoryAxis7.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D13, rectangleEdge14);
        java.lang.String str16 = categoryAxis7.getLabel();
        categoryAxis7.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = categoryAxis19.getCategorySeriesMiddle(1, 0, (int) (byte) 100, 0, (double) 0L, rectangle2D25, rectangleEdge26);
        java.awt.Font font28 = categoryAxis19.getTickLabelFont();
        categoryAxis7.setLabelFont(font28);
        categoryAxis7.setAxisLineVisible(true);
        java.awt.Paint paint32 = categoryAxis7.getLabelPaint();
        boolean boolean33 = sortOrder6.equals((java.lang.Object) categoryAxis7);
        java.util.List list34 = categoryPlot5.getCategoriesForAxis(categoryAxis7);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor35 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot5.setDomainGridlinePosition(categoryAnchor35);
        org.jfree.chart.plot.Marker marker37 = null;
        boolean boolean38 = categoryPlot5.removeDomainMarker(marker37);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot5.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation40 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str41 = axisLocation40.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation42 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation40, plotOrientation42);
        categoryPlot5.setDomainAxisLocation(axisLocation40, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation46 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation40, plotOrientation46);
        org.jfree.chart.axis.AxisState axisState48 = null;
        categoryAxis1.drawTickMarks(graphics2D2, (double) (-2), rectangle2D4, rectangleEdge47, axisState48);
        categoryAxis1.setLabel("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(categoryAnchor35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str41.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertNotNull(plotOrientation42);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(plotOrientation46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
    }
}

