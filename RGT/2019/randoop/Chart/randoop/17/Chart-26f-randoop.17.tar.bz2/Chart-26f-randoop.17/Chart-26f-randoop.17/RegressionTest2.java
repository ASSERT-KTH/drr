import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 9, (double) (short) 100);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D5.setBase((double) 1.0f);
        java.lang.Boolean boolean9 = stackedBarRenderer3D5.getSeriesCreateEntities((int) (short) 1);
        double double10 = stackedBarRenderer3D5.getUpperClip();
        boolean boolean11 = verticalAlignment1.equals((java.lang.Object) stackedBarRenderer3D5);
        java.lang.String str12 = verticalAlignment1.toString();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str12.equals("VerticalAlignment.BOTTOM"));
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator1 = null;
        levelRenderer0.setBaseURLGenerator(categoryURLGenerator1, true);
        double double4 = levelRenderer0.getMaximumItemWidth();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = minMaxCategoryRenderer0.getItemLabelGenerator((int) (short) 100, (int) 'a');
        java.awt.Paint paint6 = minMaxCategoryRenderer0.getItemPaint((-1), (int) (short) 100);
        java.awt.Paint paint7 = minMaxCategoryRenderer0.getGroupPaint();
        javax.swing.Icon icon8 = minMaxCategoryRenderer0.getObjectIcon();
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(icon8);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.String str1 = standardCategoryToolTipGenerator0.getLabelFormat();
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation4 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 100.0f, (double) (byte) 10);
        java.lang.Number number5 = meanAndStandardDeviation4.getMean();
        boolean boolean6 = standardCategoryToolTipGenerator0.equals((java.lang.Object) number5);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "({0}, {1}) = {2}" + "'", str1.equals("({0}, {1}) = {2}"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100.0d + "'", number5.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("hi!");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection4, true);
        taskSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) taskSeriesCollection4);
        taskSeries1.removeAll();
        org.jfree.data.gantt.Task task10 = taskSeries1.get("AxisLocation.BOTTOM_OR_LEFT");
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(task10);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        boolean boolean6 = stackedBarRenderer3D0.getAutoPopulateSeriesPaint();
        boolean boolean9 = stackedBarRenderer3D0.isItemLabelVisible((-1), (int) (byte) 100);
        java.awt.Paint paint10 = stackedBarRenderer3D0.getWallPaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.lang.Boolean boolean2 = statisticalLineAndShapeRenderer0.getSeriesShapesFilled(7);
        java.lang.Boolean boolean4 = statisticalLineAndShapeRenderer0.getSeriesLinesVisible(11);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        double double2 = layeredBarRenderer0.getSeriesBarWidth(11);
        java.awt.Paint paint4 = layeredBarRenderer0.getSeriesOutlinePaint((int) (byte) 1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator6);
        java.awt.Paint paint9 = null;
        stackedBarRenderer3D0.setSeriesPaint(4, paint9);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator13 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.text.NumberFormat numberFormat14 = standardCategoryToolTipGenerator13.getNumberFormat();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator15 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("({0}, {1}) = {3} - {4}", numberFormat14);
        java.text.DateFormat dateFormat16 = standardCategoryToolTipGenerator15.getDateFormat();
        stackedBarRenderer3D0.setSeriesToolTipGenerator(8, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator15);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator20 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.text.NumberFormat numberFormat21 = standardCategoryToolTipGenerator20.getNumberFormat();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator22 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("RangeType.NEGATIVE", numberFormat21);
        try {
            stackedBarRenderer3D0.setSeriesToolTipGenerator((-1), (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator22, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(numberFormat14);
        org.junit.Assert.assertNull(dateFormat16);
        org.junit.Assert.assertNotNull(numberFormat21);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        java.lang.Object obj1 = tickUnits0.clone();
        int int2 = tickUnits0.size();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        piePlot0.markerChanged(markerChangeEvent3);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.configure();
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker((double) 2, (double) (byte) 100);
        java.awt.Stroke stroke5 = intervalMarker4.getStroke();
        intervalMarker4.setLabel("Range[0.0,0.0]");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer8 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        intervalMarker4.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer8);
        boolean boolean10 = categoryAxis3D0.equals((java.lang.Object) standardGradientPaintTransformer8);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight(9);
        categoryPlot0.clearRangeMarkers(9);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D5.setBase((double) 1.0f);
        java.awt.Paint paint8 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D5.setBaseItemLabelPaint(paint8, true);
        java.awt.Shape shape13 = stackedBarRenderer3D5.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity14 = new org.jfree.chart.entity.LegendItemEntity(shape13);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset17 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range19 = defaultBoxAndWhiskerCategoryDataset17.getRangeBounds(false);
        java.lang.Comparable comparable20 = null;
        java.lang.Number number22 = defaultBoxAndWhiskerCategoryDataset17.getMaxOutlier(comparable20, (java.lang.Comparable) (short) 0);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity25 = new org.jfree.chart.entity.CategoryItemEntity(shape13, "DateTickMarkPosition.END", "TextBlockAnchor.CENTER_RIGHT", (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset17, (java.lang.Comparable) (short) 1, (java.lang.Comparable) "RangeType.NEGATIVE");
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke27 = piePlot26.getLabelOutlineStroke();
        piePlot26.setLabelLinkMargin((double) '#');
        boolean boolean30 = defaultBoxAndWhiskerCategoryDataset17.hasListener((java.util.EventListener) piePlot26);
        java.awt.Paint paint31 = piePlot26.getShadowPaint();
        java.awt.Stroke stroke32 = piePlot26.getOutlineStroke();
        categoryPlot0.setRangeGridlineStroke(stroke32);
        org.jfree.chart.LegendItemCollection legendItemCollection34 = categoryPlot0.getFixedLegendItems();
        categoryPlot0.clearDomainMarkers((int) (byte) 1);
        int int37 = categoryPlot0.getWeight();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(legendItemCollection34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 9 + "'", int37 == 9);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("orange");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot6.setBaseSectionPaint(paint7);
        java.awt.Font font9 = piePlot6.getLabelFont();
        boolean boolean10 = piePlot6.isSubplot();
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot6);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean13 = numberAxis5.equals((java.lang.Object) color12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer14);
        boolean boolean16 = xYPlot15.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.Layer layer18 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str19 = layer18.toString();
        java.util.Collection collection20 = xYPlot15.getDomainMarkers((-49088), layer18);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(layer18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Layer.FOREGROUND" + "'", str19.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection20);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot1.setBaseSectionPaint(paint2);
        minMaxCategoryRenderer0.setBaseFillPaint(paint2);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D5.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        stackedBarRenderer3D5.setBaseToolTipGenerator(categoryToolTipGenerator8);
        stackedBarRenderer3D5.setItemMargin((-1.0d));
        boolean boolean12 = stackedBarRenderer3D5.getAutoPopulateSeriesOutlinePaint();
        java.lang.Boolean boolean14 = stackedBarRenderer3D5.getSeriesItemLabelsVisible(500);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D16.setBase((double) 1.0f);
        java.lang.Boolean boolean20 = stackedBarRenderer3D16.getSeriesCreateEntities((int) (short) 1);
        double double21 = stackedBarRenderer3D16.getUpperClip();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = stackedBarRenderer3D16.getSeriesItemLabelGenerator((int) (byte) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = stackedBarRenderer3D16.getNegativeItemLabelPosition((-14336), 11);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline27 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline31 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long32 = segmentedTimeline31.getSegmentsExcludedSize();
        java.util.Date date34 = segmentedTimeline31.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline38 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long39 = segmentedTimeline38.getSegmentsExcludedSize();
        java.util.Date date41 = segmentedTimeline38.getDate((long) 7);
        boolean boolean42 = segmentedTimeline27.containsDomainRange(date34, date41);
        boolean boolean43 = itemLabelPosition26.equals((java.lang.Object) boolean42);
        stackedBarRenderer3D5.setSeriesPositiveItemLabelPosition((int) (byte) 0, itemLabelPosition26, false);
        minMaxCategoryRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition26, true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor48 = itemLabelPosition26.getItemLabelAnchor();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNull(boolean20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator23);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertNotNull(segmentedTimeline27);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-4L) + "'", long32 == (-4L));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-4L) + "'", long39 == (-4L));
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor48);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.util.List list1 = defaultKeyedValues0.getKeys();
        try {
            java.lang.Number number3 = defaultKeyedValues0.getValue((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 9, (double) (short) 100);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range7 = defaultBoxAndWhiskerCategoryDataset5.getRangeBounds(false);
        java.lang.Comparable comparable8 = null;
        java.lang.Number number10 = defaultBoxAndWhiskerCategoryDataset5.getMaxOutlier(comparable8, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str14 = spreadsheetDate13.getDescription();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset5, (java.lang.Comparable) str14);
        legendItemBlockContainer15.setHeight((double) 500);
        org.jfree.data.general.Dataset dataset18 = legendItemBlockContainer15.getDataset();
        legendItemBlockContainer15.setURLText("Range[0.0,0.0]");
        org.jfree.chart.block.Arrangement arrangement21 = legendItemBlockContainer15.getArrangement();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(dataset18);
        org.junit.Assert.assertNotNull(arrangement21);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 9, (double) (short) 100);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range7 = defaultBoxAndWhiskerCategoryDataset5.getRangeBounds(false);
        java.lang.Comparable comparable8 = null;
        java.lang.Number number10 = defaultBoxAndWhiskerCategoryDataset5.getMaxOutlier(comparable8, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str14 = spreadsheetDate13.getDescription();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset5, (java.lang.Comparable) str14);
        boolean boolean16 = legendItemBlockContainer15.isEmpty();
        java.util.List list17 = legendItemBlockContainer15.getBlocks();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getColumnKeys();
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = dateAxis3.getStandardTickUnits();
        double double6 = dateAxis3.getUpperBound();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset7 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range9 = defaultBoxAndWhiskerCategoryDataset7.getRangeBounds(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline11 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline15 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long16 = segmentedTimeline15.getSegmentsExcludedSize();
        java.util.Date date18 = segmentedTimeline15.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline22 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long23 = segmentedTimeline22.getSegmentsExcludedSize();
        java.util.Date date25 = segmentedTimeline22.getDate((long) 7);
        boolean boolean26 = segmentedTimeline11.containsDomainRange(date18, date25);
        java.lang.Number number27 = defaultBoxAndWhiskerCategoryDataset7.getMaxRegularValue((java.lang.Comparable) ' ', (java.lang.Comparable) date18);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date18);
        dateAxis3.setMinimumDate(date18);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date18);
        java.lang.Comparable comparable31 = null;
        keyedObjects2D0.addObject((java.lang.Object) paint2, (java.lang.Comparable) serialDate30, comparable31);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(segmentedTimeline11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-4L) + "'", long16 == (-4L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-4L) + "'", long23 == (-4L));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertNotNull(serialDate30);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        java.lang.String str2 = dateAxis0.getLabel();
        dateAxis0.setNegativeArrowVisible(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = null;
        try {
            java.util.Date date6 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Font font3 = stackedBarRenderer3D0.getBaseItemLabelFont();
        stackedBarRenderer3D0.setBaseSeriesVisible(true);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.lang.String str4 = taskSeries1.getDescription();
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.lang.Boolean boolean5 = stackedBarRenderer3D1.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font8 = stackedBarRenderer3D1.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.setAutoTickUnitSelection(false);
        boolean boolean13 = dateAxis10.isNegativeArrowVisible();
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot14.setBaseSectionPaint(paint15);
        dateAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot14);
        org.jfree.chart.event.AxisChangeListener axisChangeListener18 = null;
        dateAxis10.removeChangeListener(axisChangeListener18);
        java.awt.Font font20 = dateAxis10.getTickLabelFont();
        java.awt.Color color21 = java.awt.Color.darkGray;
        org.jfree.chart.text.TextMeasurer textMeasurer23 = null;
        org.jfree.chart.text.TextBlock textBlock24 = org.jfree.chart.text.TextUtilities.createTextBlock("", font20, (java.awt.Paint) color21, (float) (byte) 0, textMeasurer23);
        org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("June 2019", font8, (java.awt.Paint) color21);
        java.awt.Graphics2D graphics2D26 = null;
        try {
            org.jfree.chart.util.Size2D size2D27 = textBlock25.calculateDimensions(graphics2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(textBlock24);
        org.junit.Assert.assertNotNull(textBlock25);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long4 = segmentedTimeline3.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long10 = segmentedTimeline9.getSegmentsExcludedSize();
        java.util.Date date12 = segmentedTimeline9.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long17 = segmentedTimeline16.getSegmentsExcludedSize();
        java.util.Date date19 = segmentedTimeline16.getDate((long) 7);
        boolean boolean20 = segmentedTimeline5.containsDomainRange(date12, date19);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline3.getSegment(date19);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment24 = segment21.intersect((long) 'a', (long) 12);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline28 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long29 = segmentedTimeline28.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline30 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline34 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long35 = segmentedTimeline34.getSegmentsExcludedSize();
        java.util.Date date37 = segmentedTimeline34.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline41 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long42 = segmentedTimeline41.getSegmentsExcludedSize();
        java.util.Date date44 = segmentedTimeline41.getDate((long) 7);
        boolean boolean45 = segmentedTimeline30.containsDomainRange(date37, date44);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment46 = segmentedTimeline28.getSegment(date44);
        segment46.dec();
        boolean boolean48 = segment21.before(segment46);
        boolean boolean49 = segment21.inExcludeSegments();
        segment21.inc((long) '4');
        long long52 = segment21.getSegmentNumber();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-4L) + "'", long4 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-4L) + "'", long10 == (-4L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-4L) + "'", long17 == (-4L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(segment21);
        org.junit.Assert.assertNull(segment24);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-4L) + "'", long29 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline30);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-4L) + "'", long35 == (-4L));
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-4L) + "'", long42 == (-4L));
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(segment46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 53L + "'", long52 == 53L);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateX();
        blockParams0.setTranslateY((double) 12);
        boolean boolean4 = blockParams0.getGenerateEntities();
        boolean boolean5 = blockParams0.getGenerateEntities();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font4, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Paint paint11 = jFreeChart10.getBorderPaint();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart10.addProgressListener(chartProgressListener13);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart10.getLegend((int) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart10.getTitle();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection18 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str21 = spreadsheetDate20.getDescription();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions22 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean23 = spreadsheetDate20.equals((java.lang.Object) categoryLabelPositions22);
        int int24 = taskSeriesCollection18.getColumnIndex((java.lang.Comparable) spreadsheetDate20);
        org.jfree.data.KeyedObjects2D keyedObjects2D25 = new org.jfree.data.KeyedObjects2D();
        java.util.List list26 = keyedObjects2D25.getColumnKeys();
        org.jfree.chart.JFreeChart jFreeChart28 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType29 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10.0f, jFreeChart28, chartChangeEventType29);
        java.lang.Object obj31 = chartChangeEvent30.getSource();
        java.lang.Object obj32 = chartChangeEvent30.getSource();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset35 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range37 = defaultBoxAndWhiskerCategoryDataset35.getRangeBounds(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline39 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline43 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long44 = segmentedTimeline43.getSegmentsExcludedSize();
        java.util.Date date46 = segmentedTimeline43.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline50 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long51 = segmentedTimeline50.getSegmentsExcludedSize();
        java.util.Date date53 = segmentedTimeline50.getDate((long) 7);
        boolean boolean54 = segmentedTimeline39.containsDomainRange(date46, date53);
        java.lang.Number number55 = defaultBoxAndWhiskerCategoryDataset35.getMaxRegularValue((java.lang.Comparable) ' ', (java.lang.Comparable) date46);
        java.lang.Class class56 = null;
        java.util.Date date57 = null;
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone59 = dateAxis58.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class56, date57, timeZone59);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone59;
        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month(date46, timeZone59);
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance(date46);
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate63);
        keyedObjects2D25.setObject((java.lang.Object) chartChangeEvent30, (java.lang.Comparable) 8.0d, (java.lang.Comparable) serialDate63);
        boolean boolean66 = spreadsheetDate20.isOnOrAfter(serialDate63);
        boolean boolean67 = textTitle17.equals((java.lang.Object) boolean66);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(legendTitle16);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(categoryLabelPositions22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertTrue("'" + obj31 + "' != '" + 10.0f + "'", obj31.equals(10.0f));
        org.junit.Assert.assertTrue("'" + obj32 + "' != '" + 10.0f + "'", obj32.equals(10.0f));
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(segmentedTimeline39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-4L) + "'", long44 == (-4L));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-4L) + "'", long51 == (-4L));
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(number55);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot2.setBaseSectionPaint(paint3);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) 3, 0.0f, (float) 1L);
        piePlot2.setLegendItemShape(shape6);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = piePlot2.getLabelGenerator();
        piePlot2.setIgnoreNullValues(true);
        int int15 = piePlot2.getPieIndex();
        piePlot2.setShadowXOffset((double) 6);
        java.awt.Paint paint18 = piePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("LegendItemEntity: seriesKey=null, dataset=null", font1, (org.jfree.chart.plot.Plot) piePlot2, true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (-1), 0.0d);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        intervalMarker2.setOutlineStroke(stroke3);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = rendererState1.getInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = rendererState1.getInfo();
        org.junit.Assert.assertNull(plotRenderingInfo2);
        org.junit.Assert.assertNull(plotRenderingInfo3);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        shapeList0.clear();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 9, (double) (short) 100);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset8 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range10 = defaultBoxAndWhiskerCategoryDataset8.getRangeBounds(false);
        java.lang.Comparable comparable11 = null;
        java.lang.Number number13 = defaultBoxAndWhiskerCategoryDataset8.getMaxOutlier(comparable11, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str17 = spreadsheetDate16.getDescription();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer18 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset8, (java.lang.Comparable) str17);
        legendItemBlockContainer18.setURLText("orange");
        legendItemBlockContainer18.setToolTipText("LegendItemEntity: seriesKey=null, dataset=null");
        legendItemBlockContainer18.setHeight((double) 500);
        java.lang.String str25 = legendItemBlockContainer18.getToolTipText();
        boolean boolean26 = shapeList0.equals((java.lang.Object) str25);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str25.equals("LegendItemEntity: seriesKey=null, dataset=null"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("orange");
        float float4 = dateAxis3.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot7.setBaseSectionPaint(paint8);
        java.awt.Font font10 = piePlot7.getLabelFont();
        boolean boolean11 = piePlot7.isSubplot();
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot7);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean14 = numberAxis6.equals((java.lang.Object) color13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis6, xYItemRenderer15);
        java.awt.Paint paint17 = xYPlot16.getDomainGridlinePaint();
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str20 = layer19.toString();
        java.util.Collection collection21 = xYPlot16.getRangeMarkers(3, layer19);
        java.util.Collection collection22 = categoryPlot0.getDomainMarkers(layer19);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot0.getRangeAxisForDataset(100);
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        categoryPlot0.setDomainAxisLocation((int) '#', axisLocation26, false);
        categoryPlot0.setWeight((int) 'a');
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Layer.FOREGROUND" + "'", str20.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNull(valueAxis24);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("orange");
        float float4 = dateAxis3.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot7.setBaseSectionPaint(paint8);
        java.awt.Font font10 = piePlot7.getLabelFont();
        boolean boolean11 = piePlot7.isSubplot();
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot7);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean14 = numberAxis6.equals((java.lang.Object) color13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis6, xYItemRenderer15);
        java.awt.Paint paint17 = xYPlot16.getDomainGridlinePaint();
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str20 = layer19.toString();
        java.util.Collection collection21 = xYPlot16.getRangeMarkers(3, layer19);
        java.util.Collection collection22 = categoryPlot0.getDomainMarkers(layer19);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot0.getRangeAxisForDataset(100);
        boolean boolean26 = categoryPlot0.equals((java.lang.Object) (-2208960000000L));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Layer.FOREGROUND" + "'", str20.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setStartPercent((double) (-253));
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D3.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedBarRenderer3D3.setBaseToolTipGenerator(categoryToolTipGenerator6);
        stackedBarRenderer3D3.setItemMargin((-1.0d));
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = stackedBarRenderer3D3.getToolTipGenerator((int) (byte) 0, 0);
        java.awt.Shape shape13 = stackedBarRenderer3D3.getBaseShape();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        stackedBarRenderer3D3.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator15);
        java.awt.Paint paint17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        stackedBarRenderer3D3.setBaseFillPaint(paint17);
        ganttRenderer0.setIncompletePaint(paint17);
        java.awt.Paint paint20 = ganttRenderer0.getBasePaint();
        double double21 = ganttRenderer0.getEndPercent();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.65d + "'", double21 == 0.65d);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Comparable comparable2 = null;
        java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getMedianValue((java.lang.Comparable) (-1.0f), comparable2);
        org.jfree.data.Range range5 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        java.lang.Number number8 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier((java.lang.Comparable) 108.0d, (java.lang.Comparable) 7);
        try {
            java.lang.Number number11 = defaultBoxAndWhiskerCategoryDataset0.getValue(0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot3.setBaseSectionPaint(paint4);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape7, (double) 3, 0.0f, (float) 1L);
        piePlot3.setLegendItemShape(shape7);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D14.setBase((double) 1.0f);
        java.lang.Boolean boolean18 = stackedBarRenderer3D14.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font21 = stackedBarRenderer3D14.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font21);
        piePlot3.setLabelFont(font21);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("LegendItemEntity: seriesKey=null, dataset=null", font21);
        piePlot3D1.setLabelFont(font21);
        java.lang.String str26 = piePlot3D1.getNoDataMessage();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(boolean18);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNull(str26);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        double double3 = dateAxis0.getUpperBound();
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("", font5);
        dateAxis0.setLabelFont(font5);
        dateAxis0.setVisible(false);
        java.lang.String str10 = dateAxis0.getLabelURL();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("orange");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot6.setBaseSectionPaint(paint7);
        java.awt.Font font9 = piePlot6.getLabelFont();
        boolean boolean10 = piePlot6.isSubplot();
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot6);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean13 = numberAxis5.equals((java.lang.Object) color12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer14);
        boolean boolean16 = xYPlot15.isRangeCrosshairLockedOnData();
        xYPlot15.setRangeGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("orange");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot6.setBaseSectionPaint(paint7);
        java.awt.Font font9 = piePlot6.getLabelFont();
        boolean boolean10 = piePlot6.isSubplot();
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot6);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean13 = numberAxis5.equals((java.lang.Object) color12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer14);
        java.awt.Paint paint16 = xYPlot15.getDomainGridlinePaint();
        org.jfree.chart.util.Layer layer18 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str19 = layer18.toString();
        java.util.Collection collection20 = xYPlot15.getRangeMarkers(3, layer18);
        xYPlot15.setRangeCrosshairValue(100.0d, true);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        try {
            xYPlot15.setRangeAxisLocation((-14336), axisLocation25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(layer18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Layer.FOREGROUND" + "'", str19.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight(9);
        categoryPlot0.clearRangeMarkers(9);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D5.setBase((double) 1.0f);
        java.awt.Paint paint8 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D5.setBaseItemLabelPaint(paint8, true);
        java.awt.Shape shape13 = stackedBarRenderer3D5.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity14 = new org.jfree.chart.entity.LegendItemEntity(shape13);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset17 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range19 = defaultBoxAndWhiskerCategoryDataset17.getRangeBounds(false);
        java.lang.Comparable comparable20 = null;
        java.lang.Number number22 = defaultBoxAndWhiskerCategoryDataset17.getMaxOutlier(comparable20, (java.lang.Comparable) (short) 0);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity25 = new org.jfree.chart.entity.CategoryItemEntity(shape13, "DateTickMarkPosition.END", "TextBlockAnchor.CENTER_RIGHT", (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset17, (java.lang.Comparable) (short) 1, (java.lang.Comparable) "RangeType.NEGATIVE");
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke27 = piePlot26.getLabelOutlineStroke();
        piePlot26.setLabelLinkMargin((double) '#');
        boolean boolean30 = defaultBoxAndWhiskerCategoryDataset17.hasListener((java.util.EventListener) piePlot26);
        java.awt.Paint paint31 = piePlot26.getShadowPaint();
        java.awt.Stroke stroke32 = piePlot26.getOutlineStroke();
        categoryPlot0.setRangeGridlineStroke(stroke32);
        categoryPlot0.setAnchorValue(0.25d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long6 = segmentedTimeline5.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline11 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long12 = segmentedTimeline11.getSegmentsExcludedSize();
        java.util.Date date14 = segmentedTimeline11.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline18 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long19 = segmentedTimeline18.getSegmentsExcludedSize();
        java.util.Date date21 = segmentedTimeline18.getDate((long) 7);
        boolean boolean22 = segmentedTimeline7.containsDomainRange(date14, date21);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment23 = segmentedTimeline5.getSegment(date21);
        segment23.dec();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) segment23, (java.lang.Comparable) 108.0d);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-4L) + "'", long6 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-4L) + "'", long12 == (-4L));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-4L) + "'", long19 == (-4L));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(segment23);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        dateAxis1.setInverted(false);
        dateAxis1.resizeRange((double) (byte) 10, (double) (byte) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection0.add((org.jfree.chart.axis.Axis) dateAxis1, rectangleEdge8);
        double double10 = dateAxis1.getFixedDimension();
        java.awt.Paint paint11 = dateAxis1.getTickLabelPaint();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list13 = defaultStatisticalCategoryDataset12.getColumnKeys();
        defaultStatisticalCategoryDataset12.add((java.lang.Number) (-1L), (java.lang.Number) 100.0d, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset19 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range21 = defaultBoxAndWhiskerCategoryDataset19.getRangeBounds(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline23 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline27 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long28 = segmentedTimeline27.getSegmentsExcludedSize();
        java.util.Date date30 = segmentedTimeline27.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline34 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long35 = segmentedTimeline34.getSegmentsExcludedSize();
        java.util.Date date37 = segmentedTimeline34.getDate((long) 7);
        boolean boolean38 = segmentedTimeline23.containsDomainRange(date30, date37);
        java.lang.Number number39 = defaultBoxAndWhiskerCategoryDataset19.getMaxRegularValue((java.lang.Comparable) ' ', (java.lang.Comparable) date30);
        java.lang.Class class40 = null;
        java.util.Date date41 = null;
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone43 = dateAxis42.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date41, timeZone43);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone43;
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(date30, timeZone43);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline50 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long51 = segmentedTimeline50.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline52 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline56 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long57 = segmentedTimeline56.getSegmentsExcludedSize();
        java.util.Date date59 = segmentedTimeline56.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline63 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long64 = segmentedTimeline63.getSegmentsExcludedSize();
        java.util.Date date66 = segmentedTimeline63.getDate((long) 7);
        boolean boolean67 = segmentedTimeline52.containsDomainRange(date59, date66);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment68 = segmentedTimeline50.getSegment(date66);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment71 = segment68.intersect((long) 'a', (long) 12);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline75 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long76 = segmentedTimeline75.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline77 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline81 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long82 = segmentedTimeline81.getSegmentsExcludedSize();
        java.util.Date date84 = segmentedTimeline81.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline88 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long89 = segmentedTimeline88.getSegmentsExcludedSize();
        java.util.Date date91 = segmentedTimeline88.getDate((long) 7);
        boolean boolean92 = segmentedTimeline77.containsDomainRange(date84, date91);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment93 = segmentedTimeline75.getSegment(date91);
        segment93.dec();
        boolean boolean95 = segment68.before(segment93);
        boolean boolean96 = segment68.inExcludeSegments();
        java.lang.Number number97 = defaultStatisticalCategoryDataset12.getValue((java.lang.Comparable) date30, (java.lang.Comparable) boolean96);
        dateAxis1.setMaximumDate(date30);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(segmentedTimeline23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-4L) + "'", long28 == (-4L));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-4L) + "'", long35 == (-4L));
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(number39);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-4L) + "'", long51 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline52);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-4L) + "'", long57 == (-4L));
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-4L) + "'", long64 == (-4L));
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(segment68);
        org.junit.Assert.assertNull(segment71);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-4L) + "'", long76 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline77);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-4L) + "'", long82 == (-4L));
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + (-4L) + "'", long89 == (-4L));
        org.junit.Assert.assertNotNull(date91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNotNull(segment93);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + true + "'", boolean96 == true);
        org.junit.Assert.assertNull(number97);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        boolean boolean2 = groupedStackedBarRenderer0.equals((java.lang.Object) (short) 0);
        java.awt.Paint paint4 = groupedStackedBarRenderer0.getSeriesOutlinePaint(0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        groupedStackedBarRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator6);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D8.setBase((double) 1.0f);
        java.awt.Paint paint11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D8.setBaseItemLabelPaint(paint11, true);
        java.awt.Shape shape16 = stackedBarRenderer3D8.getItemShape(1, (int) (short) 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = null;
        stackedBarRenderer3D8.setBaseItemLabelGenerator(categoryItemLabelGenerator17);
        boolean boolean19 = stackedBarRenderer3D8.getRenderAsPercentages();
        java.awt.Font font20 = stackedBarRenderer3D8.getBaseItemLabelFont();
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape27, (double) 100L, (float) 0, (float) 10L);
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape33, (double) 100L, (float) 0, (float) 10L);
        boolean boolean38 = org.jfree.chart.util.ShapeUtilities.equal(shape31, shape37);
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        int int41 = color40.getAlpha();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer43 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint44 = waterfallBarRenderer43.getLastBarPaint();
        org.jfree.chart.plot.PiePlot piePlot45 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint46 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot45.setBaseSectionPaint(paint46);
        java.awt.Font font48 = piePlot45.getLabelFont();
        java.awt.Stroke stroke49 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot45.setBaseSectionOutlineStroke(stroke49);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D52 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D52.setBase((double) 1.0f);
        java.awt.Paint paint55 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D52.setBaseItemLabelPaint(paint55, true);
        java.awt.Shape shape60 = stackedBarRenderer3D52.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity61 = new org.jfree.chart.entity.LegendItemEntity(shape60);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset64 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range66 = defaultBoxAndWhiskerCategoryDataset64.getRangeBounds(false);
        java.lang.Comparable comparable67 = null;
        java.lang.Number number69 = defaultBoxAndWhiskerCategoryDataset64.getMaxOutlier(comparable67, (java.lang.Comparable) (short) 0);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity72 = new org.jfree.chart.entity.CategoryItemEntity(shape60, "DateTickMarkPosition.END", "TextBlockAnchor.CENTER_RIGHT", (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset64, (java.lang.Comparable) (short) 1, (java.lang.Comparable) "RangeType.NEGATIVE");
        java.awt.Stroke stroke73 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer74 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.plot.PiePlot piePlot75 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke76 = piePlot75.getLabelOutlineStroke();
        waterfallBarRenderer74.setBaseOutlineStroke(stroke76);
        java.awt.Paint paint78 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        waterfallBarRenderer74.setLastBarPaint(paint78);
        org.jfree.chart.LegendItem legendItem80 = new org.jfree.chart.LegendItem("Default Group", "1.0.6", "1.0.6", "GradientPaintTransformType.VERTICAL", false, shape31, true, (java.awt.Paint) color40, true, paint44, stroke49, false, shape60, stroke73, paint78);
        boolean boolean81 = stackedBarRenderer3D8.equals((java.lang.Object) paint44);
        groupedStackedBarRenderer0.setBaseOutlinePaint(paint44);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 255 + "'", int41 == 255);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(range66);
        org.junit.Assert.assertNull(number69);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }
}

