import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        double double3 = rectangleInsets1.calculateLeftInset((double) 1561964399999L);
        double double5 = rectangleInsets1.calculateTopOutset((double) (-49088));
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets1.createInsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long4 = segmentedTimeline3.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long10 = segmentedTimeline9.getSegmentsExcludedSize();
        java.util.Date date12 = segmentedTimeline9.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long17 = segmentedTimeline16.getSegmentsExcludedSize();
        java.util.Date date19 = segmentedTimeline16.getDate((long) 7);
        boolean boolean20 = segmentedTimeline5.containsDomainRange(date12, date19);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline3.getSegment(date19);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date19);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-4L) + "'", long4 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-4L) + "'", long10 == (-4L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-4L) + "'", long17 == (-4L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(segment21);
        org.junit.Assert.assertNotNull(serialDate22);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 3, 0.0f, (float) 1L);
        piePlot0.setLegendItemShape(shape4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot0.getLabelGenerator();
        piePlot0.setIgnoreNullValues(true);
        int int13 = piePlot0.getPieIndex();
        piePlot0.setShadowXOffset((double) 6);
        java.awt.Color color16 = java.awt.Color.yellow;
        piePlot0.setLabelShadowPaint((java.awt.Paint) color16);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit18 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        piePlot0.setExplodePercent((java.lang.Comparable) numberTickUnit18, 0.0d);
        java.awt.Paint paint21 = piePlot0.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(numberTickUnit18);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("Layer.FOREGROUND", "1.0.6");
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 3, 0.0f, (float) 1L);
        piePlot0.setLegendItemShape(shape4);
        piePlot0.setShadowYOffset((double) 9);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot12.setBaseSectionPaint(paint13);
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape16, (double) 3, 0.0f, (float) 1L);
        piePlot12.setLegendItemShape(shape16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator22 = piePlot12.getLabelGenerator();
        piePlot0.setLegendLabelGenerator(pieSectionLabelGenerator22);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        piePlot0.drawBackgroundImage(graphics2D24, rectangle2D25);
        java.lang.Object obj27 = piePlot0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator22);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((-1), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) '4', (double) 10);
        stackedBarRenderer3D2.setDrawBarOutline(false);
        java.lang.Boolean boolean6 = stackedBarRenderer3D2.getSeriesItemLabelsVisible(0);
        org.junit.Assert.assertNull(boolean6);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.centerRange((double) 8);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("1.0.6");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.awt.Shape shape5 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke8 = piePlot7.getLabelOutlineStroke();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer10 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        minMaxCategoryRenderer10.setBaseFillPaint(paint11);
        piePlot7.setSectionOutlinePaint((java.lang.Comparable) 0.2d, paint11);
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        piePlot7.setShadowPaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D17.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = null;
        stackedBarRenderer3D17.setBaseToolTipGenerator(categoryToolTipGenerator20);
        stackedBarRenderer3D17.setItemMargin((-1.0d));
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        stackedBarRenderer3D17.setBaseOutlinePaint((java.awt.Paint) color24, false);
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot27.setBaseSectionPaint(paint28);
        java.awt.Font font30 = piePlot27.getLabelFont();
        boolean boolean31 = piePlot27.isSubplot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D32.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator35 = null;
        stackedBarRenderer3D32.setBaseToolTipGenerator(categoryToolTipGenerator35);
        stackedBarRenderer3D32.setItemMargin((-1.0d));
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D32.setSeriesOutlineStroke(3, stroke40, true);
        piePlot27.setOutlineStroke(stroke40);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("orange");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D47 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D47.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator50 = null;
        stackedBarRenderer3D47.setBaseToolTipGenerator(categoryToolTipGenerator50);
        stackedBarRenderer3D47.setItemMargin((-1.0d));
        boolean boolean54 = stackedBarRenderer3D47.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape56 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape60 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape56, (double) 100L, (float) 0, (float) 10L);
        stackedBarRenderer3D47.setBaseShape(shape60, true);
        dateAxis46.setDownArrow(shape60);
        org.jfree.chart.plot.PiePlot piePlot64 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke65 = piePlot64.getLabelOutlineStroke();
        java.awt.Color color66 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem67 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", true, shape5, true, (java.awt.Paint) color14, false, (java.awt.Paint) color24, stroke40, true, shape60, stroke65, (java.awt.Paint) color66);
        java.lang.String str68 = legendItem67.getDescription();
        int int69 = legendItem67.getDatasetIndex();
        java.awt.Shape shape70 = legendItem67.getLine();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str68.equals("({0}, {1}) = {3} - {4}"));
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(shape70);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        org.jfree.data.Range range3 = dateAxis0.getDefaultAutoRange();
        dateAxis0.setNegativeArrowVisible(true);
        java.awt.Stroke stroke6 = null;
        try {
            dateAxis0.setAxisLineStroke(stroke6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        int int3 = taskSeriesCollection0.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries5 = new org.jfree.data.gantt.TaskSeries("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        taskSeries5.removePropertyChangeListener(propertyChangeListener6);
        taskSeriesCollection0.remove(taskSeries5);
        try {
            java.lang.Number number11 = taskSeriesCollection0.getStartValue((int) (short) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color2);
        java.awt.Paint paint5 = categoryAxis3D0.getTickLabelPaint((java.lang.Comparable) 11);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset6 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range8 = defaultBoxAndWhiskerCategoryDataset6.getRangeBounds(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline10 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline14 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long15 = segmentedTimeline14.getSegmentsExcludedSize();
        java.util.Date date17 = segmentedTimeline14.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline21 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long22 = segmentedTimeline21.getSegmentsExcludedSize();
        java.util.Date date24 = segmentedTimeline21.getDate((long) 7);
        boolean boolean25 = segmentedTimeline10.containsDomainRange(date17, date24);
        java.lang.Number number26 = defaultBoxAndWhiskerCategoryDataset6.getMaxRegularValue((java.lang.Comparable) ' ', (java.lang.Comparable) date17);
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone30 = dateAxis29.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone30);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone30;
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date17, timeZone30);
        categoryAxis3D0.addCategoryLabelToolTip((java.lang.Comparable) month33, "");
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            double double40 = categoryAxis3D0.getCategoryStart((int) ' ', 255, rectangle2D38, rectangleEdge39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(segmentedTimeline10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-4L) + "'", long15 == (-4L));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-4L) + "'", long22 == (-4L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(number26);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        stackedBarRenderer3D4.setBaseToolTipGenerator(categoryToolTipGenerator7);
        stackedBarRenderer3D4.setItemMargin((-1.0d));
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D4.setSeriesOutlineStroke(3, stroke12, true);
        stackedBarRenderer3D1.setBaseOutlineStroke(stroke12, true);
        int int17 = month0.compareTo((java.lang.Object) stackedBarRenderer3D1);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D19.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D22.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator25 = null;
        stackedBarRenderer3D22.setBaseToolTipGenerator(categoryToolTipGenerator25);
        stackedBarRenderer3D22.setItemMargin((-1.0d));
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D22.setSeriesOutlineStroke(3, stroke30, true);
        stackedBarRenderer3D19.setBaseOutlineStroke(stroke30, true);
        int int35 = month18.compareTo((java.lang.Object) stackedBarRenderer3D19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month18.next();
        boolean boolean37 = month0.equals((java.lang.Object) month18);
        java.lang.String str38 = month0.toString();
        long long39 = month0.getSerialIndex();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June 2019" + "'", str38.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 24234L + "'", long39 == 24234L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color2);
        java.awt.Paint paint5 = categoryAxis3D0.getTickLabelPaint((java.lang.Comparable) 11);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double10 = categoryAxis3D0.getCategoryMiddle((int) (byte) -1, (int) (byte) 100, rectangle2D8, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        java.awt.Shape shape8 = stackedBarRenderer3D0.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset12 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range14 = defaultBoxAndWhiskerCategoryDataset12.getRangeBounds(false);
        java.lang.Comparable comparable15 = null;
        java.lang.Number number17 = defaultBoxAndWhiskerCategoryDataset12.getMaxOutlier(comparable15, (java.lang.Comparable) (short) 0);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity20 = new org.jfree.chart.entity.CategoryItemEntity(shape8, "DateTickMarkPosition.END", "TextBlockAnchor.CENTER_RIGHT", (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset12, (java.lang.Comparable) (short) 1, (java.lang.Comparable) "RangeType.NEGATIVE");
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke22 = piePlot21.getLabelOutlineStroke();
        piePlot21.setLabelLinkMargin((double) '#');
        boolean boolean25 = defaultBoxAndWhiskerCategoryDataset12.hasListener((java.util.EventListener) piePlot21);
        try {
            java.lang.Number number28 = defaultBoxAndWhiskerCategoryDataset12.getMedianValue(1, (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("hi!");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection4, true);
        taskSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) taskSeriesCollection4);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection8 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = null;
        taskSeriesCollection8.seriesChanged(seriesChangeEvent9);
        taskSeries1.removeChangeListener((org.jfree.data.general.SeriesChangeListener) taskSeriesCollection8);
        java.lang.Comparable comparable12 = null;
        try {
            java.lang.Number number14 = taskSeriesCollection8.getEndValue(comparable12, (java.lang.Comparable) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.lang.Boolean boolean5 = stackedBarRenderer3D1.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font8 = stackedBarRenderer3D1.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font8);
        org.jfree.chart.text.TextFragment textFragment10 = textLine9.getLastTextFragment();
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("LegendItemEntity: seriesKey=null, dataset=null");
        boolean boolean14 = textFragment12.equals((java.lang.Object) "hi!");
        textLine9.addFragment(textFragment12);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(textFragment10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        stackedBarRenderer3D4.setBaseToolTipGenerator(categoryToolTipGenerator7);
        stackedBarRenderer3D4.setItemMargin((-1.0d));
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D4.setSeriesOutlineStroke(3, stroke12, true);
        stackedBarRenderer3D1.setBaseOutlineStroke(stroke12, true);
        int int17 = month0.compareTo((java.lang.Object) stackedBarRenderer3D1);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D19.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D22.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator25 = null;
        stackedBarRenderer3D22.setBaseToolTipGenerator(categoryToolTipGenerator25);
        stackedBarRenderer3D22.setItemMargin((-1.0d));
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D22.setSeriesOutlineStroke(3, stroke30, true);
        stackedBarRenderer3D19.setBaseOutlineStroke(stroke30, true);
        int int35 = month18.compareTo((java.lang.Object) stackedBarRenderer3D19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month18.next();
        boolean boolean37 = month0.equals((java.lang.Object) month18);
        long long38 = month0.getLastMillisecond();
        long long39 = month0.getSerialIndex();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1561964399999L + "'", long38 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 24234L + "'", long39 == 24234L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("RangeType.NEGATIVE");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("LegendItemEntity: seriesKey=null, dataset=null");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset2 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range4 = defaultBoxAndWhiskerCategoryDataset2.getRangeBounds(false);
        java.lang.Comparable comparable5 = null;
        java.lang.Number number7 = defaultBoxAndWhiskerCategoryDataset2.getMaxOutlier(comparable5, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset2);
        double double9 = range8.getLowerBound();
        double double10 = range8.getLength();
        numberAxis1.setDefaultAutoRange(range8);
        boolean boolean13 = range8.contains((double) (-460));
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot1.setBaseSectionPaint(paint2);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape5, (double) 3, 0.0f, (float) 1L);
        piePlot1.setLegendItemShape(shape5);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D12.setBase((double) 1.0f);
        java.lang.Boolean boolean16 = stackedBarRenderer3D12.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font19 = stackedBarRenderer3D12.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font19);
        piePlot1.setLabelFont(font19);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot22.setBaseSectionPaint(paint23);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape26, (double) 3, 0.0f, (float) 1L);
        piePlot22.setLegendItemShape(shape26);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D33.setBase((double) 1.0f);
        java.lang.Boolean boolean37 = stackedBarRenderer3D33.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font40 = stackedBarRenderer3D33.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine41 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font40);
        piePlot22.setLabelFont(font40);
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_RED;
        piePlot22.setNoDataMessagePaint((java.awt.Paint) color43);
        org.jfree.chart.block.LabelBlock labelBlock45 = new org.jfree.chart.block.LabelBlock("orange", font19, (java.awt.Paint) color43);
        java.awt.Graphics2D graphics2D46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        java.lang.Object obj48 = null;
        try {
            java.lang.Object obj49 = labelBlock45.draw(graphics2D46, rectangle2D47, obj48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNull(boolean37);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(color43);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 100.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(paint0);
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D3.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedBarRenderer3D3.setBaseToolTipGenerator(categoryToolTipGenerator6);
        stackedBarRenderer3D3.setItemMargin((-1.0d));
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D3.setSeriesOutlineStroke(3, stroke11, true);
        stackedBarRenderer3D0.setBaseOutlineStroke(stroke11, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = stackedBarRenderer3D0.getLegendItemURLGenerator();
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator16);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = stackedBarRenderer3D0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            java.lang.Comparable comparable2 = defaultKeyedValues0.getKey((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        java.lang.Object obj4 = segmentedTimeline3.clone();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, 0.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setBaseShapesFilled(false);
        java.lang.Boolean boolean4 = statisticalLineAndShapeRenderer0.getSeriesLinesVisible((int) (byte) 1);
        statisticalLineAndShapeRenderer0.setBaseSeriesVisible(false);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        double double1 = levelRenderer0.getMaximumItemWidth();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        levelRenderer0.setBaseURLGenerator(categoryURLGenerator2, false);
        int int5 = levelRenderer0.getRowCount();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("({0}, {1}) = {2}", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot2.setBaseSectionPaint(paint3);
        java.awt.Font font5 = piePlot2.getLabelFont();
        boolean boolean6 = piePlot2.isSubplot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot2);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean9 = numberAxis1.equals((java.lang.Object) color8);
        double double10 = numberAxis1.getUpperMargin();
        boolean boolean11 = numberAxis1.isAutoTickUnitSelection();
        boolean boolean12 = numberAxis1.isInverted();
        boolean boolean13 = numberAxis1.isTickMarksVisible();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        stackedBarRenderer3D0.setItemMargin((-1.0d));
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D0.setSeriesOutlineStroke(3, stroke8, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = null;
        stackedBarRenderer3D0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator11);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = null;
        stackedBarRenderer3D0.setGradientPaintTransformer(gradientPaintTransformer13);
        java.awt.Stroke stroke17 = stackedBarRenderer3D0.getItemStroke((-457), (int) (byte) 100);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range3 = defaultBoxAndWhiskerCategoryDataset1.getRangeBounds(false);
        java.lang.Comparable comparable4 = null;
        java.lang.Number number6 = defaultBoxAndWhiskerCategoryDataset1.getMaxOutlier(comparable4, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset1);
        boolean boolean8 = blockBorder0.equals((java.lang.Object) defaultBoxAndWhiskerCategoryDataset1);
        int int10 = defaultBoxAndWhiskerCategoryDataset1.getRowIndex((java.lang.Comparable) 4);
        try {
            java.lang.Number number13 = defaultBoxAndWhiskerCategoryDataset1.getMaxRegularValue(9, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.lang.Boolean boolean4 = stackedBarRenderer3D0.getSeriesCreateEntities((int) (short) 1);
        stackedBarRenderer3D0.setSeriesItemLabelsVisible((int) '4', false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = stackedBarRenderer3D0.getURLGenerator(0, (int) ' ');
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        try {
            stackedBarRenderer3D0.setPlot(categoryPlot11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(categoryURLGenerator10);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        boolean boolean1 = outlierListCollection0.isLowFarOut();
        org.jfree.chart.renderer.Outlier outlier2 = null;
        boolean boolean3 = outlierListCollection0.add(outlier2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color2);
        java.lang.String str5 = categoryAxis3D0.getCategoryLabelToolTip((java.lang.Comparable) 4.0d);
        categoryAxis3D0.configure();
        java.awt.Paint paint8 = categoryAxis3D0.getTickLabelPaint((java.lang.Comparable) 0.25d);
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot11.setBaseSectionPaint(paint12);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape15, (double) 3, 0.0f, (float) 1L);
        piePlot11.setLegendItemShape(shape15);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D22.setBase((double) 1.0f);
        java.lang.Boolean boolean26 = stackedBarRenderer3D22.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font29 = stackedBarRenderer3D22.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine30 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font29);
        piePlot11.setLabelFont(font29);
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("LegendItemEntity: seriesKey=null, dataset=null", font29);
        org.jfree.chart.plot.IntervalMarker intervalMarker35 = new org.jfree.chart.plot.IntervalMarker((double) 2, (double) (byte) 100);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D36 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D36.setBase((double) 1.0f);
        java.awt.Paint paint39 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D36.setBaseItemLabelPaint(paint39, true);
        java.awt.Shape shape44 = stackedBarRenderer3D36.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity45 = new org.jfree.chart.entity.LegendItemEntity(shape44);
        java.awt.Shape shape46 = legendItemEntity45.getArea();
        java.lang.Comparable comparable47 = legendItemEntity45.getSeriesKey();
        boolean boolean48 = intervalMarker35.equals((java.lang.Object) comparable47);
        intervalMarker35.setStartValue(0.4d);
        java.awt.Font font51 = intervalMarker35.getLabelFont();
        textTitle32.setFont(font51);
        categoryAxis3D0.setTickLabelFont((java.lang.Comparable) 2.0d, font51);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNull(comparable47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(font51);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 3, 0.0f, (float) 1L);
        piePlot0.setLegendItemShape(shape4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot0.getLabelGenerator();
        piePlot0.setIgnoreNullValues(true);
        piePlot0.setShadowXOffset((double) 0L);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.LEVEL;
        org.junit.Assert.assertNotNull(areaRendererEndType0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        minMaxCategoryRenderer0.setGroupPaint((java.awt.Paint) color1);
        javax.swing.Icon icon3 = minMaxCategoryRenderer0.getMaxIcon();
        minMaxCategoryRenderer0.setSeriesItemLabelsVisible(2958465, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(icon3);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font4, (org.jfree.chart.plot.Plot) piePlot5, false);
        boolean boolean11 = jFreeChart10.isNotify();
        float float12 = jFreeChart10.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.lang.Boolean boolean5 = stackedBarRenderer3D1.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font8 = stackedBarRenderer3D1.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font8);
        org.jfree.chart.text.TextFragment textFragment10 = textLine9.getLastTextFragment();
        java.awt.Paint paint11 = textFragment10.getPaint();
        java.awt.Font font12 = textFragment10.getFont();
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(textFragment10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        double double3 = dateAxis0.getLowerBound();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis0);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 3, 0.0f, (float) 1L);
        piePlot0.setLegendItemShape(shape4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot0.getLabelGenerator();
        piePlot0.setIgnoreNullValues(true);
        int int13 = piePlot0.getPieIndex();
        piePlot0.setShadowXOffset((double) 6);
        piePlot0.setPieIndex((int) (short) -1);
        int int18 = piePlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.configure();
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        double double3 = dateAxis0.getUpperBound();
        boolean boolean4 = dateAxis0.isTickLabelsVisible();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        dateAxis0.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline8);
        try {
            boolean boolean12 = segmentedTimeline8.containsDomainRange((long) (-14336), (long) (-49088));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: domainValueEnd (-49088) < domainValueStart (-14336)");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot1.setBaseSectionPaint(paint2);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape5, (double) 3, 0.0f, (float) 1L);
        piePlot1.setLegendItemShape(shape5);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D12.setBase((double) 1.0f);
        java.lang.Boolean boolean16 = stackedBarRenderer3D12.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font19 = stackedBarRenderer3D12.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font19);
        piePlot1.setLabelFont(font19);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot22.setBaseSectionPaint(paint23);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape26, (double) 3, 0.0f, (float) 1L);
        piePlot22.setLegendItemShape(shape26);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D33.setBase((double) 1.0f);
        java.lang.Boolean boolean37 = stackedBarRenderer3D33.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font40 = stackedBarRenderer3D33.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine41 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font40);
        piePlot22.setLabelFont(font40);
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_RED;
        piePlot22.setNoDataMessagePaint((java.awt.Paint) color43);
        org.jfree.chart.block.LabelBlock labelBlock45 = new org.jfree.chart.block.LabelBlock("orange", font19, (java.awt.Paint) color43);
        labelBlock45.setURLText("");
        java.awt.Graphics2D graphics2D48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        try {
            labelBlock45.draw(graphics2D48, rectangle2D49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNull(boolean37);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(color43);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        java.awt.Shape shape8 = stackedBarRenderer3D0.getItemShape(1, (int) (short) 0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) 7);
        stackedBarRenderer3D0.notifyListeners(rendererChangeEvent10);
        stackedBarRenderer3D0.setSeriesItemLabelsVisible(255, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setMaximumItemWidth((double) 1900);
        boolean boolean5 = levelRenderer0.getItemVisible((int) ' ', 6);
        java.awt.Stroke stroke6 = levelRenderer0.getBaseStroke();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color2);
        java.lang.String str5 = categoryAxis3D0.getCategoryLabelToolTip((java.lang.Comparable) 4.0d);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long10 = segmentedTimeline9.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline11 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline15 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long16 = segmentedTimeline15.getSegmentsExcludedSize();
        java.util.Date date18 = segmentedTimeline15.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline22 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long23 = segmentedTimeline22.getSegmentsExcludedSize();
        java.util.Date date25 = segmentedTimeline22.getDate((long) 7);
        boolean boolean26 = segmentedTimeline11.containsDomainRange(date18, date25);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment27 = segmentedTimeline9.getSegment(date25);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment30 = segment27.intersect((long) 'a', (long) 12);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline34 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long35 = segmentedTimeline34.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline36 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline40 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long41 = segmentedTimeline40.getSegmentsExcludedSize();
        java.util.Date date43 = segmentedTimeline40.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline47 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long48 = segmentedTimeline47.getSegmentsExcludedSize();
        java.util.Date date50 = segmentedTimeline47.getDate((long) 7);
        boolean boolean51 = segmentedTimeline36.containsDomainRange(date43, date50);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment52 = segmentedTimeline34.getSegment(date50);
        segment52.dec();
        boolean boolean54 = segment27.before(segment52);
        org.jfree.chart.plot.PiePlot piePlot56 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint57 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot56.setBaseSectionPaint(paint57);
        java.awt.Shape shape60 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape64 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape60, (double) 3, 0.0f, (float) 1L);
        piePlot56.setLegendItemShape(shape60);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D67 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D67.setBase((double) 1.0f);
        java.lang.Boolean boolean71 = stackedBarRenderer3D67.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font74 = stackedBarRenderer3D67.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine75 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font74);
        piePlot56.setLabelFont(font74);
        org.jfree.chart.title.TextTitle textTitle77 = new org.jfree.chart.title.TextTitle("LegendItemEntity: seriesKey=null, dataset=null", font74);
        org.jfree.chart.plot.IntervalMarker intervalMarker80 = new org.jfree.chart.plot.IntervalMarker((double) 2, (double) (byte) 100);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D81 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D81.setBase((double) 1.0f);
        java.awt.Paint paint84 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D81.setBaseItemLabelPaint(paint84, true);
        java.awt.Shape shape89 = stackedBarRenderer3D81.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity90 = new org.jfree.chart.entity.LegendItemEntity(shape89);
        java.awt.Shape shape91 = legendItemEntity90.getArea();
        java.lang.Comparable comparable92 = legendItemEntity90.getSeriesKey();
        boolean boolean93 = intervalMarker80.equals((java.lang.Object) comparable92);
        intervalMarker80.setStartValue(0.4d);
        java.awt.Font font96 = intervalMarker80.getLabelFont();
        textTitle77.setFont(font96);
        categoryAxis3D0.setTickLabelFont((java.lang.Comparable) segment27, font96);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-4L) + "'", long10 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-4L) + "'", long16 == (-4L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-4L) + "'", long23 == (-4L));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(segment27);
        org.junit.Assert.assertNull(segment30);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-4L) + "'", long35 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline36);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-4L) + "'", long41 == (-4L));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-4L) + "'", long48 == (-4L));
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(segment52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNull(boolean71);
        org.junit.Assert.assertNotNull(font74);
        org.junit.Assert.assertNotNull(paint84);
        org.junit.Assert.assertNotNull(shape89);
        org.junit.Assert.assertNotNull(shape91);
        org.junit.Assert.assertNull(comparable92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(font96);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font4, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Paint paint11 = jFreeChart10.getBorderPaint();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        org.jfree.chart.event.ChartChangeListener chartChangeListener13 = null;
        try {
            jFreeChart10.removeChangeListener(chartChangeListener13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertEquals((double) number2, Double.NaN, 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot1.setBaseSectionPaint(paint2);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape5, (double) 3, 0.0f, (float) 1L);
        piePlot1.setLegendItemShape(shape5);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D12.setBase((double) 1.0f);
        java.lang.Boolean boolean16 = stackedBarRenderer3D12.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font19 = stackedBarRenderer3D12.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font19);
        piePlot1.setLabelFont(font19);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("LegendItemEntity: seriesKey=null, dataset=null", font19);
        textTitle22.setExpandToFitSpace(false);
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        try {
            textTitle22.setBounds(rectangle2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TRUNCATE;
        org.junit.Assert.assertNotNull(areaRendererEndType0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot2.setBaseSectionPaint(paint3);
        java.awt.Font font5 = piePlot2.getLabelFont();
        boolean boolean6 = piePlot2.isSubplot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot2);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean9 = numberAxis1.equals((java.lang.Object) color8);
        org.jfree.data.RangeType rangeType10 = org.jfree.data.RangeType.POSITIVE;
        numberAxis1.setRangeType(rangeType10);
        numberAxis1.setAutoRangeMinimumSize(Double.NaN, false);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator16 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.text.NumberFormat numberFormat17 = standardCategoryToolTipGenerator16.getNumberFormat();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit18 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat17);
        numberAxis1.setNumberFormatOverride(numberFormat17);
        boolean boolean20 = numberAxis1.getAutoRangeStickyZero();
        numberAxis1.setAutoTickUnitSelection(false, false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rangeType10);
        org.junit.Assert.assertNotNull(numberFormat17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("", font1);
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("LegendItemEntity: seriesKey=null, dataset=null");
        textLine2.removeFragment(textFragment4);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (-1), 0.0d);
        java.awt.Paint paint3 = intervalMarker2.getOutlinePaint();
        java.io.ObjectOutputStream objectOutputStream4 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint3, objectOutputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Font font3 = piePlot0.getLabelFont();
        boolean boolean4 = piePlot0.isSubplot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D5.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        stackedBarRenderer3D5.setBaseToolTipGenerator(categoryToolTipGenerator8);
        stackedBarRenderer3D5.setItemMargin((-1.0d));
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D5.setSeriesOutlineStroke(3, stroke13, true);
        piePlot0.setOutlineStroke(stroke13);
        boolean boolean17 = piePlot0.getSectionOutlinesVisible();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot0.getLegendLabelGenerator();
        piePlot0.setPieIndex(1900);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator21 = null;
        piePlot0.setURLGenerator(pieURLGenerator21);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.KeyToGroupMap keyToGroupMap0 = new org.jfree.data.KeyToGroupMap();
        java.lang.Comparable comparable2 = keyToGroupMap0.getGroup((java.lang.Comparable) (byte) 10);
        int int4 = keyToGroupMap0.getGroupIndex((java.lang.Comparable) Double.NaN);
        java.lang.Object obj5 = keyToGroupMap0.clone();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + "Default Group" + "'", comparable2.equals("Default Group"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        boolean boolean2 = textTitle1.getNotify();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        piePlot0.setShadowXOffset((double) (-49088));
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 3, 0.0f, (float) 1L);
        piePlot0.setLegendItemShape(shape4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D11.setBase((double) 1.0f);
        java.lang.Boolean boolean15 = stackedBarRenderer3D11.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font18 = stackedBarRenderer3D11.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine19 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font18);
        piePlot0.setLabelFont(font18);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_RED;
        piePlot0.setNoDataMessagePaint((java.awt.Paint) color21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color24 = java.awt.Color.yellow;
        float[] floatArray28 = new float[] { (byte) -1, 100.0f, 7 };
        float[] floatArray29 = color24.getColorComponents(floatArray28);
        float[] floatArray30 = color23.getRGBColorComponents(floatArray28);
        float[] floatArray31 = color21.getColorComponents(floatArray30);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setBackgroundImageAlignment(15);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long9 = segmentedTimeline8.getSegmentsExcludedSize();
        java.util.Date date11 = segmentedTimeline8.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline15 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long16 = segmentedTimeline15.getSegmentsExcludedSize();
        java.util.Date date18 = segmentedTimeline15.getDate((long) 7);
        boolean boolean19 = segmentedTimeline4.containsDomainRange(date11, date18);
        java.lang.Number number20 = defaultBoxAndWhiskerCategoryDataset0.getMaxRegularValue((java.lang.Comparable) ' ', (java.lang.Comparable) date11);
        java.lang.Class class21 = null;
        java.util.Date date22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone24 = dateAxis23.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone24);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone24;
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date11, timeZone24);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date11);
        java.lang.Class class29 = null;
        java.util.Date date30 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone32 = dateAxis31.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone32);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone32;
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date11, timeZone32);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date11);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-4L) + "'", long9 == (-4L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-4L) + "'", long16 == (-4L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        stackedBarRenderer3D0.setItemMargin((-1.0d));
        boolean boolean7 = stackedBarRenderer3D0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape9, (double) 100L, (float) 0, (float) 10L);
        stackedBarRenderer3D0.setBaseShape(shape13, true);
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape13);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        java.lang.Comparable comparable20 = null;
        java.lang.Comparable comparable21 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity22 = new org.jfree.chart.entity.CategoryItemEntity(shape13, "org.jfree.data.time.TimePeriodFormatException: orange", "LegendItemEntity: seriesKey=null, dataset=null", categoryDataset19, comparable20, comparable21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font4, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Paint paint11 = jFreeChart10.getBorderPaint();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart10.addProgressListener(chartProgressListener13);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D15.setBase((double) 1.0f);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer18 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = minMaxCategoryRenderer18.getItemLabelGenerator((int) (short) 100, (int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor23 = itemLabelPosition22.getTextAnchor();
        double double24 = itemLabelPosition22.getAngle();
        minMaxCategoryRenderer18.setBaseNegativeItemLabelPosition(itemLabelPosition22);
        stackedBarRenderer3D15.setPositiveItemLabelPositionFallback(itemLabelPosition22);
        boolean boolean27 = jFreeChart10.equals((java.lang.Object) itemLabelPosition22);
        jFreeChart10.setBackgroundImageAlpha((float) 9);
        org.jfree.chart.title.TextTitle textTitle30 = jFreeChart10.getTitle();
        java.awt.Image image31 = jFreeChart10.getBackgroundImage();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(textTitle30);
        org.junit.Assert.assertNull(image31);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D2.setBase((double) 1.0f);
        java.awt.Paint paint5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D2.setBaseItemLabelPaint(paint5, true);
        java.awt.Shape shape10 = stackedBarRenderer3D2.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity11 = new org.jfree.chart.entity.LegendItemEntity(shape10);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset14 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range16 = defaultBoxAndWhiskerCategoryDataset14.getRangeBounds(false);
        java.lang.Comparable comparable17 = null;
        java.lang.Number number19 = defaultBoxAndWhiskerCategoryDataset14.getMaxOutlier(comparable17, (java.lang.Comparable) (short) 0);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity22 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "DateTickMarkPosition.END", "TextBlockAnchor.CENTER_RIGHT", (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset14, (java.lang.Comparable) (short) 1, (java.lang.Comparable) "RangeType.NEGATIVE");
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke24 = piePlot23.getLabelOutlineStroke();
        piePlot23.setLabelLinkMargin((double) '#');
        boolean boolean27 = defaultBoxAndWhiskerCategoryDataset14.hasListener((java.util.EventListener) piePlot23);
        piePlot23.setIgnoreZeroValues(false);
        boolean boolean30 = stackedAreaRenderer1.equals((java.lang.Object) false);
        java.awt.Paint paint32 = stackedAreaRenderer1.lookupSeriesOutlinePaint(0);
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType33 = stackedAreaRenderer1.getEndType();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(number19);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(areaRendererEndType33);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Font font3 = piePlot0.getLabelFont();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot0.setBaseSectionOutlineStroke(stroke4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor7 = itemLabelPosition6.getTextAnchor();
        double double8 = itemLabelPosition6.getAngle();
        boolean boolean9 = piePlot0.equals((java.lang.Object) double8);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D10.setBase((double) 1.0f);
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D10.setBaseItemLabelPaint(paint13, true);
        java.awt.Shape shape18 = stackedBarRenderer3D10.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity19 = new org.jfree.chart.entity.LegendItemEntity(shape18);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset22 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range24 = defaultBoxAndWhiskerCategoryDataset22.getRangeBounds(false);
        java.lang.Comparable comparable25 = null;
        java.lang.Number number27 = defaultBoxAndWhiskerCategoryDataset22.getMaxOutlier(comparable25, (java.lang.Comparable) (short) 0);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity30 = new org.jfree.chart.entity.CategoryItemEntity(shape18, "DateTickMarkPosition.END", "TextBlockAnchor.CENTER_RIGHT", (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset22, (java.lang.Comparable) (short) 1, (java.lang.Comparable) "RangeType.NEGATIVE");
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke32 = piePlot31.getLabelOutlineStroke();
        piePlot31.setLabelLinkMargin((double) '#');
        boolean boolean35 = defaultBoxAndWhiskerCategoryDataset22.hasListener((java.util.EventListener) piePlot31);
        java.awt.Paint paint36 = piePlot31.getShadowPaint();
        piePlot0.setBackgroundPaint(paint36);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.lang.Boolean boolean5 = stackedBarRenderer3D1.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font8 = stackedBarRenderer3D1.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font8);
        org.jfree.chart.text.TextFragment textFragment10 = textLine9.getLastTextFragment();
        java.awt.Paint paint11 = textFragment10.getPaint();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor16 = itemLabelPosition15.getTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor17 = itemLabelPosition15.getTextAnchor();
        try {
            textFragment10.draw(graphics2D12, (float) 60000L, (float) 12, textAnchor17, (float) (-4L), (float) 15, 2.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(textFragment10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(textAnchor17);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceText("");
        java.util.List list3 = projectInfo0.getContributors();
        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
        projectInfo4.setLicenceText("");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo4);
        projectInfo4.setName("");
        projectInfo4.setInfo("ItemLabelAnchor.INSIDE7");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(projectInfo4);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        double double1 = intervalBarRenderer0.getMaximumBarWidth();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone8 = dateAxis7.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = dateAxis7.getStandardTickUnits();
        double double10 = dateAxis7.getUpperBound();
        boolean boolean11 = dateAxis7.isTickLabelsVisible();
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis7.setTickUnit(dateTickUnit12, true, false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D16.setBase((double) 1.0f);
        java.awt.Paint paint19 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D16.setBaseItemLabelPaint(paint19, true);
        java.awt.Shape shape24 = stackedBarRenderer3D16.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity25 = new org.jfree.chart.entity.LegendItemEntity(shape24);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset28 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range30 = defaultBoxAndWhiskerCategoryDataset28.getRangeBounds(false);
        java.lang.Comparable comparable31 = null;
        java.lang.Number number33 = defaultBoxAndWhiskerCategoryDataset28.getMaxOutlier(comparable31, (java.lang.Comparable) (short) 0);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity36 = new org.jfree.chart.entity.CategoryItemEntity(shape24, "DateTickMarkPosition.END", "TextBlockAnchor.CENTER_RIGHT", (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset28, (java.lang.Comparable) (short) 1, (java.lang.Comparable) "RangeType.NEGATIVE");
        try {
            intervalBarRenderer0.drawItem(graphics2D2, categoryItemRendererState3, rectangle2D4, categoryPlot5, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset28, 9, (int) (short) 0, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNull(number33);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 11);
        boolean boolean2 = categoryMarker1.getDrawAsLine();
        java.awt.Font font3 = categoryMarker1.getLabelFont();
        org.jfree.chart.event.MarkerChangeListener markerChangeListener4 = null;
        categoryMarker1.addChangeListener(markerChangeListener4);
        categoryMarker1.setDrawAsLine(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        double double1 = levelRenderer0.getMaximumItemWidth();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot6.setBaseSectionPaint(paint7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape10, (double) 3, 0.0f, (float) 1L);
        piePlot6.setLegendItemShape(shape10);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D17.setBase((double) 1.0f);
        java.lang.Boolean boolean21 = stackedBarRenderer3D17.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font24 = stackedBarRenderer3D17.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine25 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font24);
        piePlot6.setLabelFont(font24);
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("LegendItemEntity: seriesKey=null, dataset=null", font24);
        piePlot3D4.setLabelFont(font24);
        levelRenderer0.setSeriesItemLabelFont((int) 'a', font24);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator34 = null;
        stackedBarRenderer3D31.setBaseToolTipGenerator(categoryToolTipGenerator34);
        stackedBarRenderer3D31.setItemMargin((-1.0d));
        java.awt.Stroke stroke39 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D31.setSeriesOutlineStroke(3, stroke39, true);
        levelRenderer0.setSeriesOutlineStroke(192, stroke39, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getColumnKeys();
        java.lang.Object obj2 = keyedObjects2D0.clone();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getLabelOutlineStroke();
        piePlot0.setLabelLinkMargin((double) '#');
        java.lang.Object obj4 = piePlot0.clone();
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot0.setLabelLinkStroke(stroke5);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        java.awt.Shape shape8 = stackedBarRenderer3D0.getItemShape(1, (int) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = stackedBarRenderer3D0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(itemLabelPosition9);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItem legendItem1 = null;
        legendItemCollection0.add(legendItem1);
        java.util.Iterator iterator3 = legendItemCollection0.iterator();
        java.util.Iterator iterator4 = legendItemCollection0.iterator();
        org.junit.Assert.assertNotNull(iterator3);
        org.junit.Assert.assertNotNull(iterator4);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library library1 = null;
        try {
            projectInfo0.addOptionalLibrary(library1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Library must be given.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        java.awt.Shape shape8 = stackedBarRenderer3D0.getItemShape(1, (int) (short) 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = null;
        stackedBarRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator9);
        boolean boolean11 = stackedBarRenderer3D0.getRenderAsPercentages();
        java.awt.Font font12 = stackedBarRenderer3D0.getBaseItemLabelFont();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape19, (double) 100L, (float) 0, (float) 10L);
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape25, (double) 100L, (float) 0, (float) 10L);
        boolean boolean30 = org.jfree.chart.util.ShapeUtilities.equal(shape23, shape29);
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        int int33 = color32.getAlpha();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer35 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint36 = waterfallBarRenderer35.getLastBarPaint();
        org.jfree.chart.plot.PiePlot piePlot37 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint38 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot37.setBaseSectionPaint(paint38);
        java.awt.Font font40 = piePlot37.getLabelFont();
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot37.setBaseSectionOutlineStroke(stroke41);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D44 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D44.setBase((double) 1.0f);
        java.awt.Paint paint47 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D44.setBaseItemLabelPaint(paint47, true);
        java.awt.Shape shape52 = stackedBarRenderer3D44.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity53 = new org.jfree.chart.entity.LegendItemEntity(shape52);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset56 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range58 = defaultBoxAndWhiskerCategoryDataset56.getRangeBounds(false);
        java.lang.Comparable comparable59 = null;
        java.lang.Number number61 = defaultBoxAndWhiskerCategoryDataset56.getMaxOutlier(comparable59, (java.lang.Comparable) (short) 0);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity64 = new org.jfree.chart.entity.CategoryItemEntity(shape52, "DateTickMarkPosition.END", "TextBlockAnchor.CENTER_RIGHT", (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset56, (java.lang.Comparable) (short) 1, (java.lang.Comparable) "RangeType.NEGATIVE");
        java.awt.Stroke stroke65 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer66 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.plot.PiePlot piePlot67 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke68 = piePlot67.getLabelOutlineStroke();
        waterfallBarRenderer66.setBaseOutlineStroke(stroke68);
        java.awt.Paint paint70 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        waterfallBarRenderer66.setLastBarPaint(paint70);
        org.jfree.chart.LegendItem legendItem72 = new org.jfree.chart.LegendItem("Default Group", "1.0.6", "1.0.6", "GradientPaintTransformType.VERTICAL", false, shape23, true, (java.awt.Paint) color32, true, paint36, stroke41, false, shape52, stroke65, paint70);
        boolean boolean73 = stackedBarRenderer3D0.equals((java.lang.Object) paint36);
        double double74 = stackedBarRenderer3D0.getItemMargin();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 255 + "'", int33 == 255);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNull(number61);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.2d + "'", double74 == 0.2d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot2.setBaseSectionPaint(paint3);
        java.awt.Font font5 = piePlot2.getLabelFont();
        boolean boolean6 = piePlot2.isSubplot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot2);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean9 = numberAxis1.equals((java.lang.Object) color8);
        org.jfree.data.RangeType rangeType10 = org.jfree.data.RangeType.POSITIVE;
        numberAxis1.setRangeType(rangeType10);
        boolean boolean12 = numberAxis1.isAutoTickUnitSelection();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rangeType10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.awt.Shape shape5 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke8 = piePlot7.getLabelOutlineStroke();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer10 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        minMaxCategoryRenderer10.setBaseFillPaint(paint11);
        piePlot7.setSectionOutlinePaint((java.lang.Comparable) 0.2d, paint11);
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        piePlot7.setShadowPaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D17.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = null;
        stackedBarRenderer3D17.setBaseToolTipGenerator(categoryToolTipGenerator20);
        stackedBarRenderer3D17.setItemMargin((-1.0d));
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        stackedBarRenderer3D17.setBaseOutlinePaint((java.awt.Paint) color24, false);
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot27.setBaseSectionPaint(paint28);
        java.awt.Font font30 = piePlot27.getLabelFont();
        boolean boolean31 = piePlot27.isSubplot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D32.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator35 = null;
        stackedBarRenderer3D32.setBaseToolTipGenerator(categoryToolTipGenerator35);
        stackedBarRenderer3D32.setItemMargin((-1.0d));
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D32.setSeriesOutlineStroke(3, stroke40, true);
        piePlot27.setOutlineStroke(stroke40);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("orange");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D47 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D47.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator50 = null;
        stackedBarRenderer3D47.setBaseToolTipGenerator(categoryToolTipGenerator50);
        stackedBarRenderer3D47.setItemMargin((-1.0d));
        boolean boolean54 = stackedBarRenderer3D47.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape56 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape60 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape56, (double) 100L, (float) 0, (float) 10L);
        stackedBarRenderer3D47.setBaseShape(shape60, true);
        dateAxis46.setDownArrow(shape60);
        org.jfree.chart.plot.PiePlot piePlot64 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke65 = piePlot64.getLabelOutlineStroke();
        java.awt.Color color66 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem67 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", true, shape5, true, (java.awt.Paint) color14, false, (java.awt.Paint) color24, stroke40, true, shape60, stroke65, (java.awt.Paint) color66);
        legendItem67.setSeriesKey((java.lang.Comparable) "JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\n");
        boolean boolean70 = legendItem67.isShapeVisible();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(false);
        boolean boolean3 = dateAxis0.isNegativeArrowVisible();
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot4.setBaseSectionPaint(paint5);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot4);
        org.jfree.chart.event.AxisChangeListener axisChangeListener8 = null;
        dateAxis0.removeChangeListener(axisChangeListener8);
        java.awt.Font font10 = dateAxis0.getTickLabelFont();
        java.awt.Shape shape11 = dateAxis0.getDownArrow();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) 100L, (float) 0, (float) 10L);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape12, (double) 100L, (float) 0, (float) 10L);
        boolean boolean17 = org.jfree.chart.util.ShapeUtilities.equal(shape10, shape16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        int int20 = color19.getAlpha();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer22 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint23 = waterfallBarRenderer22.getLastBarPaint();
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot24.setBaseSectionPaint(paint25);
        java.awt.Font font27 = piePlot24.getLabelFont();
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot24.setBaseSectionOutlineStroke(stroke28);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setBase((double) 1.0f);
        java.awt.Paint paint34 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D31.setBaseItemLabelPaint(paint34, true);
        java.awt.Shape shape39 = stackedBarRenderer3D31.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity40 = new org.jfree.chart.entity.LegendItemEntity(shape39);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset43 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range45 = defaultBoxAndWhiskerCategoryDataset43.getRangeBounds(false);
        java.lang.Comparable comparable46 = null;
        java.lang.Number number48 = defaultBoxAndWhiskerCategoryDataset43.getMaxOutlier(comparable46, (java.lang.Comparable) (short) 0);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity51 = new org.jfree.chart.entity.CategoryItemEntity(shape39, "DateTickMarkPosition.END", "TextBlockAnchor.CENTER_RIGHT", (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset43, (java.lang.Comparable) (short) 1, (java.lang.Comparable) "RangeType.NEGATIVE");
        java.awt.Stroke stroke52 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer53 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.plot.PiePlot piePlot54 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke55 = piePlot54.getLabelOutlineStroke();
        waterfallBarRenderer53.setBaseOutlineStroke(stroke55);
        java.awt.Paint paint57 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        waterfallBarRenderer53.setLastBarPaint(paint57);
        org.jfree.chart.LegendItem legendItem59 = new org.jfree.chart.LegendItem("Default Group", "1.0.6", "1.0.6", "GradientPaintTransformType.VERTICAL", false, shape10, true, (java.awt.Paint) color19, true, paint23, stroke28, false, shape39, stroke52, paint57);
        java.lang.String str60 = legendItem59.getURLText();
        org.jfree.data.general.Dataset dataset61 = legendItem59.getDataset();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 255 + "'", int20 == 255);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "GradientPaintTransformType.VERTICAL" + "'", str60.equals("GradientPaintTransformType.VERTICAL"));
        org.junit.Assert.assertNull(dataset61);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItem legendItem1 = null;
        legendItemCollection0.add(legendItem1);
        java.util.Iterator iterator3 = legendItemCollection0.iterator();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) '4', (double) 10);
        stackedBarRenderer3D6.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = stackedBarRenderer3D6.getLegendItems();
        legendItemCollection0.addAll(legendItemCollection10);
        try {
            org.jfree.chart.LegendItem legendItem13 = legendItemCollection10.get((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iterator3);
        org.junit.Assert.assertNotNull(legendItemCollection10);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        java.lang.String str2 = dateAxis0.getLabel();
        org.jfree.data.Range range3 = null;
        try {
            dateAxis0.setRange(range3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("orange", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}", "");
        basicProjectInfo5.setName("");
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone3 = dateAxis2.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone3);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone3;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone3;
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot3.setBaseSectionPaint(paint4);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape7, (double) 3, 0.0f, (float) 1L);
        piePlot3.setLegendItemShape(shape7);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D14.setBase((double) 1.0f);
        java.lang.Boolean boolean18 = stackedBarRenderer3D14.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font21 = stackedBarRenderer3D14.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font21);
        piePlot3.setLabelFont(font21);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("LegendItemEntity: seriesKey=null, dataset=null", font21);
        piePlot3D1.setLabelFont(font21);
        double double26 = piePlot3D1.getMinimumArcAngleToDraw();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(boolean18);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-5d + "'", double26 == 1.0E-5d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range3 = defaultBoxAndWhiskerCategoryDataset1.getRangeBounds(false);
        java.lang.Comparable comparable4 = null;
        java.lang.Number number6 = defaultBoxAndWhiskerCategoryDataset1.getMaxOutlier(comparable4, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset1);
        boolean boolean8 = blockBorder0.equals((java.lang.Object) defaultBoxAndWhiskerCategoryDataset1);
        int int10 = defaultBoxAndWhiskerCategoryDataset1.getRowIndex((java.lang.Comparable) 4);
        double double12 = defaultBoxAndWhiskerCategoryDataset1.getRangeUpperBound(false);
        defaultBoxAndWhiskerCategoryDataset1.validateObject();
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10.0f, jFreeChart1, chartChangeEventType2);
        java.lang.Object obj4 = chartChangeEvent3.getSource();
        java.lang.Object obj5 = chartChangeEvent3.getSource();
        java.lang.Object obj6 = chartChangeEvent3.getSource();
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + 10.0f + "'", obj4.equals(10.0f));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + 10.0f + "'", obj5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + 10.0f + "'", obj6.equals(10.0f));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot0.getLabelGenerator();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        centerArrangement0.clear();
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke2 = piePlot1.getLabelOutlineStroke();
        waterfallBarRenderer0.setBaseOutlineStroke(stroke2);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setBase((double) 1.0f);
        java.lang.Boolean boolean8 = stackedBarRenderer3D4.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font11 = stackedBarRenderer3D4.getItemLabelFont((int) ' ', (int) (short) -1);
        boolean boolean12 = waterfallBarRenderer0.equals((java.lang.Object) (short) -1);
        java.awt.Paint paint13 = waterfallBarRenderer0.getNegativeBarPaint();
        java.awt.Paint paint14 = waterfallBarRenderer0.getLastBarPaint();
        java.awt.Color color15 = java.awt.Color.blue;
        waterfallBarRenderer0.setNegativeBarPaint((java.awt.Paint) color15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.lang.Boolean boolean4 = stackedBarRenderer3D0.getSeriesCreateEntities((int) (short) 1);
        stackedBarRenderer3D0.setSeriesItemLabelsVisible((int) '4', false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = stackedBarRenderer3D0.getDrawingSupplier();
        stackedBarRenderer3D0.setBaseSeriesVisibleInLegend(true);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(drawingSupplier8);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.lang.Class class1 = null;
        java.util.Date date2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date2, timeZone4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\n", timeZone4);
        boolean boolean7 = dateAxis6.isInverted();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getLabelOutlineStroke();
        piePlot0.setLabelLinkMargin((double) '#');
        piePlot0.setExplodePercent((java.lang.Comparable) "({0}, {1}) = {2}", (double) (short) -1);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        boolean boolean2 = groupedStackedBarRenderer0.equals((java.lang.Object) (short) 0);
        java.awt.Paint paint4 = groupedStackedBarRenderer0.getSeriesOutlinePaint(0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        groupedStackedBarRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setWeight(9);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D14.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color16);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone19 = dateAxis18.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = dateAxis18.getStandardTickUnits();
        double double21 = dateAxis18.getUpperBound();
        boolean boolean22 = dateAxis18.isTickLabelsVisible();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline26 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        dateAxis18.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline26);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset28 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list29 = defaultStatisticalCategoryDataset28.getColumnKeys();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str32 = spreadsheetDate31.getDescription();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions33 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean34 = spreadsheetDate31.equals((java.lang.Object) categoryLabelPositions33);
        int int35 = spreadsheetDate31.getMonth();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset36 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range38 = defaultBoxAndWhiskerCategoryDataset36.getRangeBounds(false);
        java.lang.Comparable comparable39 = null;
        java.lang.Number number41 = defaultBoxAndWhiskerCategoryDataset36.getMaxOutlier(comparable39, (java.lang.Comparable) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str44 = spreadsheetDate43.getDescription();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions45 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean46 = spreadsheetDate43.equals((java.lang.Object) categoryLabelPositions45);
        int int47 = spreadsheetDate43.getMonth();
        java.lang.Number number49 = defaultBoxAndWhiskerCategoryDataset36.getMinRegularValue((java.lang.Comparable) spreadsheetDate43, (java.lang.Comparable) (-4L));
        java.lang.Number number50 = defaultStatisticalCategoryDataset28.getValue((java.lang.Comparable) int35, (java.lang.Comparable) spreadsheetDate43);
        try {
            groupedStackedBarRenderer0.drawItem(graphics2D8, categoryItemRendererState9, rectangle2D10, categoryPlot11, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D14, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset28, 2, 9, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(tickUnitSource20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(categoryLabelPositions33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2 + "'", int35 == 2);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNull(number41);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(categoryLabelPositions45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2 + "'", int47 == 2);
        org.junit.Assert.assertNull(number49);
        org.junit.Assert.assertNull(number50);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font4, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Paint paint11 = jFreeChart10.getBorderPaint();
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot13.setBaseSectionPaint(paint14);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape17, (double) 3, 0.0f, (float) 1L);
        piePlot13.setLegendItemShape(shape17);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D24.setBase((double) 1.0f);
        java.lang.Boolean boolean28 = stackedBarRenderer3D24.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font31 = stackedBarRenderer3D24.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine32 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font31);
        piePlot13.setLabelFont(font31);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("LegendItemEntity: seriesKey=null, dataset=null", font31);
        textTitle34.setExpandToFitSpace(false);
        jFreeChart10.addSubtitle((org.jfree.chart.title.Title) textTitle34);
        int int38 = jFreeChart10.getSubtitleCount();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(boolean28);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setMaximumItemWidth((double) 1900);
        double double3 = levelRenderer0.getMaximumItemWidth();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1900.0d + "'", double3 == 1900.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("TextBlockAnchor.CENTER_RIGHT", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str1 = categoryAnchor0.toString();
        java.lang.String str2 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.END" + "'", str1.equals("CategoryAnchor.END"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CategoryAnchor.END" + "'", str2.equals("CategoryAnchor.END"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(0.0d, (double) (byte) 1, (double) 0.0f, (double) 4L);
        java.awt.Paint paint5 = blockBorder4.getPaint();
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        dateAxis1.setInverted(false);
        dateAxis1.resizeRange((double) (byte) 10, (double) (byte) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection0.add((org.jfree.chart.axis.Axis) dateAxis1, rectangleEdge8);
        java.util.List list10 = axisCollection0.getAxesAtTop();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getLicenceText();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(false);
        boolean boolean3 = dateAxis0.isNegativeArrowVisible();
        boolean boolean4 = dateAxis0.isInverted();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D5.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        stackedBarRenderer3D5.setBaseToolTipGenerator(categoryToolTipGenerator8);
        stackedBarRenderer3D5.setItemMargin((-1.0d));
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = stackedBarRenderer3D5.getToolTipGenerator((int) (byte) 0, 0);
        stackedBarRenderer3D5.setAutoPopulateSeriesOutlineStroke(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor19 = itemLabelPosition18.getTextAnchor();
        stackedBarRenderer3D5.setSeriesPositiveItemLabelPosition(100, itemLabelPosition18);
        java.awt.Stroke stroke21 = stackedBarRenderer3D5.getBaseOutlineStroke();
        dateAxis0.setTickMarkStroke(stroke21);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator14);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        int int0 = org.jfree.chart.axis.DateTickUnit.MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setSeriesShapesVisible((int) '4', (java.lang.Boolean) false);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setWeight(9);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D10.setLabelURL("");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment15, verticalAlignment16, (double) 9, (double) (short) 100);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset20 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range22 = defaultBoxAndWhiskerCategoryDataset20.getRangeBounds(false);
        java.lang.Comparable comparable23 = null;
        java.lang.Number number25 = defaultBoxAndWhiskerCategoryDataset20.getMaxOutlier(comparable23, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str29 = spreadsheetDate28.getDescription();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer30 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement19, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset20, (java.lang.Comparable) str29);
        org.jfree.data.general.PieDataset pieDataset32 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset20, (java.lang.Comparable) 60000L);
        try {
            statisticalLineAndShapeRenderer0.drawItem(graphics2D4, categoryItemRendererState5, rectangle2D6, categoryPlot7, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D10, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset20, (int) (byte) 10, 3, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(pieDataset32);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor1 = categoryLabelPosition0.getRotationAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = categoryLabelPosition0.getLabelAnchor();
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D7.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        stackedBarRenderer3D7.setBaseToolTipGenerator(categoryToolTipGenerator10);
        stackedBarRenderer3D7.setItemMargin((-1.0d));
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D7.setSeriesOutlineStroke(3, stroke15, true);
        stackedBarRenderer3D4.setBaseOutlineStroke(stroke15, true);
        int int20 = month3.compareTo((java.lang.Object) stackedBarRenderer3D4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month3.next();
        org.jfree.data.gantt.TaskSeries taskSeries22 = taskSeriesCollection0.getSeries((java.lang.Comparable) regularTimePeriod21);
        long long23 = regularTimePeriod21.getMiddleMillisecond();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNull(taskSeries22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1563303599999L + "'", long23 == 1563303599999L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.VERTICAL" + "'", str1.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        java.lang.Comparable comparable3 = null;
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier(comparable3, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        java.lang.Object obj1 = tickUnits0.clone();
        java.lang.Class class3 = null;
        java.util.Date date4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone6 = dateAxis5.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date4, timeZone6);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\n", timeZone6);
        boolean boolean9 = tickUnits0.equals((java.lang.Object) dateAxis8);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer10 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer10.setStartPercent((double) (-253));
        java.awt.Color color13 = java.awt.Color.ORANGE;
        ganttRenderer10.setCompletePaint((java.awt.Paint) color13);
        boolean boolean15 = tickUnits0.equals((java.lang.Object) color13);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight(9);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge((int) '#');
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        defaultStatisticalCategoryDataset0.add((java.lang.Number) (-1L), (java.lang.Number) 100.0d, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset7 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range9 = defaultBoxAndWhiskerCategoryDataset7.getRangeBounds(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline11 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline15 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long16 = segmentedTimeline15.getSegmentsExcludedSize();
        java.util.Date date18 = segmentedTimeline15.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline22 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long23 = segmentedTimeline22.getSegmentsExcludedSize();
        java.util.Date date25 = segmentedTimeline22.getDate((long) 7);
        boolean boolean26 = segmentedTimeline11.containsDomainRange(date18, date25);
        java.lang.Number number27 = defaultBoxAndWhiskerCategoryDataset7.getMaxRegularValue((java.lang.Comparable) ' ', (java.lang.Comparable) date18);
        java.lang.Class class28 = null;
        java.util.Date date29 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone31 = dateAxis30.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone31);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone31;
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date18, timeZone31);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline38 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long39 = segmentedTimeline38.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline40 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline44 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long45 = segmentedTimeline44.getSegmentsExcludedSize();
        java.util.Date date47 = segmentedTimeline44.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline51 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long52 = segmentedTimeline51.getSegmentsExcludedSize();
        java.util.Date date54 = segmentedTimeline51.getDate((long) 7);
        boolean boolean55 = segmentedTimeline40.containsDomainRange(date47, date54);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment56 = segmentedTimeline38.getSegment(date54);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment59 = segment56.intersect((long) 'a', (long) 12);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline63 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long64 = segmentedTimeline63.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline65 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline69 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long70 = segmentedTimeline69.getSegmentsExcludedSize();
        java.util.Date date72 = segmentedTimeline69.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline76 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long77 = segmentedTimeline76.getSegmentsExcludedSize();
        java.util.Date date79 = segmentedTimeline76.getDate((long) 7);
        boolean boolean80 = segmentedTimeline65.containsDomainRange(date72, date79);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment81 = segmentedTimeline63.getSegment(date79);
        segment81.dec();
        boolean boolean83 = segment56.before(segment81);
        boolean boolean84 = segment56.inExcludeSegments();
        java.lang.Number number85 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) date18, (java.lang.Comparable) boolean84);
        double double87 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(segmentedTimeline11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-4L) + "'", long16 == (-4L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-4L) + "'", long23 == (-4L));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-4L) + "'", long39 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline40);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-4L) + "'", long45 == (-4L));
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-4L) + "'", long52 == (-4L));
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(segment56);
        org.junit.Assert.assertNull(segment59);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-4L) + "'", long64 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline65);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-4L) + "'", long70 == (-4L));
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + (-4L) + "'", long77 == (-4L));
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(segment81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNull(number85);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + (-1.0d) + "'", double87 == (-1.0d));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 3, 0.0f, (float) 1L);
        piePlot0.setLegendItemShape(shape4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot0.getLabelGenerator();
        piePlot0.setIgnoreNullValues(true);
        int int13 = piePlot0.getPieIndex();
        piePlot0.setShadowXOffset((double) 6);
        java.lang.Object obj16 = piePlot0.clone();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        piePlot0.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color18);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = piePlot0.getDrawingSupplier();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(drawingSupplier20);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.configure();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D3.setBase((double) 1.0f);
        java.awt.Paint paint6 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D3.setBaseItemLabelPaint(paint6, true);
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) 2.0d, paint6);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range3 = defaultBoxAndWhiskerCategoryDataset1.getRangeBounds(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long10 = segmentedTimeline9.getSegmentsExcludedSize();
        java.util.Date date12 = segmentedTimeline9.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long17 = segmentedTimeline16.getSegmentsExcludedSize();
        java.util.Date date19 = segmentedTimeline16.getDate((long) 7);
        boolean boolean20 = segmentedTimeline5.containsDomainRange(date12, date19);
        java.lang.Number number21 = defaultBoxAndWhiskerCategoryDataset1.getMaxRegularValue((java.lang.Comparable) ' ', (java.lang.Comparable) date12);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date12);
        int int23 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) date12);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-4L) + "'", long10 == (-4L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-4L) + "'", long17 == (-4L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(number21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        double double3 = dateAxis0.getUpperBound();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset4 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range6 = defaultBoxAndWhiskerCategoryDataset4.getRangeBounds(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long13 = segmentedTimeline12.getSegmentsExcludedSize();
        java.util.Date date15 = segmentedTimeline12.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline19 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long20 = segmentedTimeline19.getSegmentsExcludedSize();
        java.util.Date date22 = segmentedTimeline19.getDate((long) 7);
        boolean boolean23 = segmentedTimeline8.containsDomainRange(date15, date22);
        java.lang.Number number24 = defaultBoxAndWhiskerCategoryDataset4.getMaxRegularValue((java.lang.Comparable) ' ', (java.lang.Comparable) date15);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date15);
        dateAxis0.setMinimumDate(date15);
        java.awt.Shape shape27 = dateAxis0.getRightArrow();
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity30 = new org.jfree.chart.entity.TickLabelEntity(shape27, "({0}, {1}) = {2}", "orange");
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-4L) + "'", long13 == (-4L));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-4L) + "'", long20 == (-4L));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(number24);
        org.junit.Assert.assertNotNull(shape27);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NO_CHANGE" + "'", str1.equals("NO_CHANGE"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot1.setBaseSectionPaint(paint2);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape5, (double) 3, 0.0f, (float) 1L);
        piePlot1.setLegendItemShape(shape5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot1.getLabelGenerator();
        piePlot1.setIgnoreNullValues(true);
        int int14 = piePlot1.getPieIndex();
        piePlot1.setShadowXOffset((double) 6);
        java.awt.Color color17 = java.awt.Color.yellow;
        piePlot1.setLabelShadowPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        piePlot1.setExplodePercent((java.lang.Comparable) numberTickUnit19, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement22 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.general.Dataset dataset23 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer25 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement22, dataset23, (java.lang.Comparable) 6);
        int int26 = numberTickUnit19.compareTo((java.lang.Object) flowArrangement22);
        boolean boolean27 = shapeList0.equals((java.lang.Object) flowArrangement22);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(numberTickUnit19);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("LegendItemEntity: seriesKey=null, dataset=null");
        boolean boolean2 = numberAxis1.isAutoRange();
        numberAxis1.setAutoTickUnitSelection(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.lang.Boolean boolean2 = statisticalLineAndShapeRenderer0.getSeriesShapesFilled(7);
        statisticalLineAndShapeRenderer0.setSeriesLinesVisible((int) '4', (java.lang.Boolean) true);
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range3 = defaultBoxAndWhiskerCategoryDataset1.getRangeBounds(false);
        java.lang.Comparable comparable4 = null;
        java.lang.Number number6 = defaultBoxAndWhiskerCategoryDataset1.getMaxOutlier(comparable4, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset1);
        boolean boolean8 = blockBorder0.equals((java.lang.Object) defaultBoxAndWhiskerCategoryDataset1);
        int int10 = defaultBoxAndWhiskerCategoryDataset1.getRowIndex((java.lang.Comparable) 4);
        java.util.List list11 = defaultBoxAndWhiskerCategoryDataset1.getColumnKeys();
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.block.BlockBorder blockBorder1 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        java.awt.Color color3 = java.awt.Color.orange;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(rectangleInsets2, (java.awt.Paint) color3);
        boolean boolean5 = textAnchor0.equals((java.lang.Object) rectangleInsets2);
        java.lang.Object obj6 = null;
        boolean boolean7 = rectangleInsets2.equals(obj6);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(blockBorder1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.lang.String str1 = categoryLabelWidthType0.toString();
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str1.equals("CategoryLabelWidthType.CATEGORY"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        double double3 = dateAxis0.getUpperBound();
        boolean boolean4 = dateAxis0.isTickLabelsVisible();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        dateAxis0.setTickMarkPaint((java.awt.Paint) color5);
        org.jfree.data.Range range7 = dateAxis0.getDefaultAutoRange();
        java.awt.Stroke stroke8 = dateAxis0.getTickMarkStroke();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape10, (double) 100L, (float) 0, (float) 10L);
        dateAxis0.setLeftArrow(shape10);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        defaultStatisticalCategoryDataset0.add((java.lang.Number) (-1L), (java.lang.Number) 100.0d, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 0.0f);
        org.jfree.data.Range range8 = defaultStatisticalCategoryDataset0.getRangeBounds(false);
        double double9 = range8.getUpperBound();
        boolean boolean12 = range8.intersects((double) 4L, (double) 10);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long4 = segmentedTimeline3.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long10 = segmentedTimeline9.getSegmentsExcludedSize();
        java.util.Date date12 = segmentedTimeline9.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long17 = segmentedTimeline16.getSegmentsExcludedSize();
        java.util.Date date19 = segmentedTimeline16.getDate((long) 7);
        boolean boolean20 = segmentedTimeline5.containsDomainRange(date12, date19);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline3.getSegment(date19);
        segment21.dec((long) 12);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-4L) + "'", long4 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-4L) + "'", long10 == (-4L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-4L) + "'", long17 == (-4L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(segment21);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        int int3 = taskSeriesCollection0.getColumnCount();
        java.util.List list4 = taskSeriesCollection0.getColumnKeys();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) -1, 10, 192);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItem legendItem1 = null;
        legendItemCollection0.add(legendItem1);
        java.util.Iterator iterator3 = legendItemCollection0.iterator();
        java.awt.Shape shape9 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke12 = piePlot11.getLabelOutlineStroke();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer14 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        minMaxCategoryRenderer14.setBaseFillPaint(paint15);
        piePlot11.setSectionOutlinePaint((java.lang.Comparable) 0.2d, paint15);
        java.awt.Color color18 = java.awt.Color.LIGHT_GRAY;
        piePlot11.setShadowPaint((java.awt.Paint) color18);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D21.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = null;
        stackedBarRenderer3D21.setBaseToolTipGenerator(categoryToolTipGenerator24);
        stackedBarRenderer3D21.setItemMargin((-1.0d));
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        stackedBarRenderer3D21.setBaseOutlinePaint((java.awt.Paint) color28, false);
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot31.setBaseSectionPaint(paint32);
        java.awt.Font font34 = piePlot31.getLabelFont();
        boolean boolean35 = piePlot31.isSubplot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D36 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D36.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator39 = null;
        stackedBarRenderer3D36.setBaseToolTipGenerator(categoryToolTipGenerator39);
        stackedBarRenderer3D36.setItemMargin((-1.0d));
        java.awt.Stroke stroke44 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D36.setSeriesOutlineStroke(3, stroke44, true);
        piePlot31.setOutlineStroke(stroke44);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("orange");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D51 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D51.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator54 = null;
        stackedBarRenderer3D51.setBaseToolTipGenerator(categoryToolTipGenerator54);
        stackedBarRenderer3D51.setItemMargin((-1.0d));
        boolean boolean58 = stackedBarRenderer3D51.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape60 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape64 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape60, (double) 100L, (float) 0, (float) 10L);
        stackedBarRenderer3D51.setBaseShape(shape64, true);
        dateAxis50.setDownArrow(shape64);
        org.jfree.chart.plot.PiePlot piePlot68 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke69 = piePlot68.getLabelOutlineStroke();
        java.awt.Color color70 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem71 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", true, shape9, true, (java.awt.Paint) color18, false, (java.awt.Paint) color28, stroke44, true, shape64, stroke69, (java.awt.Paint) color70);
        legendItem71.setSeriesKey((java.lang.Comparable) "JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\n");
        java.lang.String str74 = legendItem71.getLabel();
        legendItemCollection0.add(legendItem71);
        java.lang.Comparable comparable76 = null;
        legendItem71.setSeriesKey(comparable76);
        org.junit.Assert.assertNotNull(iterator3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "" + "'", str74.equals(""));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D5.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color7);
        java.lang.String str10 = categoryAxis3D5.getCategoryLabelToolTip((java.lang.Comparable) 4.0d);
        categoryAxis3D5.configure();
        java.awt.Paint paint13 = categoryAxis3D5.getTickLabelPaint((java.lang.Comparable) 0.25d);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset16 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list17 = defaultStatisticalCategoryDataset16.getColumnKeys();
        defaultStatisticalCategoryDataset16.add((java.lang.Number) (-1L), (java.lang.Number) 100.0d, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 0.0f);
        try {
            statisticalLineAndShapeRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D3, categoryPlot4, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D5, (org.jfree.chart.axis.ValueAxis) numberAxis15, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset16, 7, 12, (-457));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range3 = defaultBoxAndWhiskerCategoryDataset1.getRangeBounds(false);
        java.lang.Comparable comparable4 = null;
        java.lang.Number number6 = defaultBoxAndWhiskerCategoryDataset1.getMaxOutlier(comparable4, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset1);
        double double8 = range7.getLowerBound();
        java.lang.Comparable comparable10 = null;
        keyedObjects2D0.addObject((java.lang.Object) range7, (java.lang.Comparable) 1.0E-5d, comparable10);
        int int12 = keyedObjects2D0.getRowCount();
        try {
            keyedObjects2D0.removeColumn((java.lang.Comparable) 7L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.awt.Shape shape5 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke8 = piePlot7.getLabelOutlineStroke();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer10 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        minMaxCategoryRenderer10.setBaseFillPaint(paint11);
        piePlot7.setSectionOutlinePaint((java.lang.Comparable) 0.2d, paint11);
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        piePlot7.setShadowPaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D17.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = null;
        stackedBarRenderer3D17.setBaseToolTipGenerator(categoryToolTipGenerator20);
        stackedBarRenderer3D17.setItemMargin((-1.0d));
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        stackedBarRenderer3D17.setBaseOutlinePaint((java.awt.Paint) color24, false);
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot27.setBaseSectionPaint(paint28);
        java.awt.Font font30 = piePlot27.getLabelFont();
        boolean boolean31 = piePlot27.isSubplot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D32.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator35 = null;
        stackedBarRenderer3D32.setBaseToolTipGenerator(categoryToolTipGenerator35);
        stackedBarRenderer3D32.setItemMargin((-1.0d));
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D32.setSeriesOutlineStroke(3, stroke40, true);
        piePlot27.setOutlineStroke(stroke40);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("orange");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D47 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D47.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator50 = null;
        stackedBarRenderer3D47.setBaseToolTipGenerator(categoryToolTipGenerator50);
        stackedBarRenderer3D47.setItemMargin((-1.0d));
        boolean boolean54 = stackedBarRenderer3D47.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape56 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape60 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape56, (double) 100L, (float) 0, (float) 10L);
        stackedBarRenderer3D47.setBaseShape(shape60, true);
        dateAxis46.setDownArrow(shape60);
        org.jfree.chart.plot.PiePlot piePlot64 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke65 = piePlot64.getLabelOutlineStroke();
        java.awt.Color color66 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem67 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", true, shape5, true, (java.awt.Paint) color14, false, (java.awt.Paint) color24, stroke40, true, shape60, stroke65, (java.awt.Paint) color66);
        java.lang.String str68 = legendItem67.getDescription();
        int int69 = legendItem67.getDatasetIndex();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer70 = legendItem67.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str68.equals("({0}, {1}) = {3} - {4}"));
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(gradientPaintTransformer70);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 3, 0.0f, (float) 1L);
        piePlot0.setLegendItemShape(shape4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot0.getLabelGenerator();
        piePlot0.setIgnoreNullValues(true);
        int int13 = piePlot0.getPieIndex();
        piePlot0.setShadowXOffset((double) 6);
        java.awt.Paint paint16 = piePlot0.getNoDataMessagePaint();
        java.awt.Paint paint17 = piePlot0.getShadowPaint();
        boolean boolean18 = piePlot0.isSubplot();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("hi!");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection4, true);
        taskSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) taskSeriesCollection4);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection8 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = null;
        taskSeriesCollection8.seriesChanged(seriesChangeEvent9);
        taskSeries1.removeChangeListener((org.jfree.data.general.SeriesChangeListener) taskSeriesCollection8);
        org.jfree.data.gantt.TaskSeries taskSeries12 = null;
        try {
            taskSeriesCollection8.remove(taskSeries12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Font font3 = piePlot0.getLabelFont();
        double double4 = piePlot0.getShadowYOffset();
        piePlot0.setLabelLinksVisible(true);
        int int7 = piePlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 3, 0.0f, (float) 1L);
        piePlot0.setLegendItemShape(shape4);
        java.awt.Color color10 = java.awt.Color.yellow;
        piePlot0.setOutlinePaint((java.awt.Paint) color10);
        java.awt.Font font12 = piePlot0.getLabelFont();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot2.setBaseSectionPaint(paint3);
        java.awt.Font font5 = piePlot2.getLabelFont();
        boolean boolean6 = piePlot2.isSubplot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot2);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean9 = numberAxis1.equals((java.lang.Object) color8);
        double double10 = numberAxis1.getUpperMargin();
        double double11 = numberAxis1.getFixedDimension();
        numberAxis1.setAutoRangeIncludesZero(true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 3, 0.0f, (float) 1L);
        piePlot0.setLegendItemShape(shape4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot0.getLabelGenerator();
        piePlot0.setIgnoreNullValues(true);
        int int13 = piePlot0.getPieIndex();
        java.awt.Color color14 = java.awt.Color.darkGray;
        piePlot0.setOutlinePaint((java.awt.Paint) color14);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator1 = null;
        levelRenderer0.setBaseURLGenerator(categoryURLGenerator1, true);
        java.awt.Font font5 = null;
        levelRenderer0.setSeriesItemLabelFont(12, font5);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font4, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Paint paint11 = jFreeChart10.getBorderPaint();
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot12 = jFreeChart10.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.awt.Paint paint0 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = waterfallBarRenderer0.getLastBarPaint();
        double double2 = waterfallBarRenderer0.getBase();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (-1), 0.0d);
        java.awt.Paint paint3 = intervalMarker2.getOutlinePaint();
        double double4 = intervalMarker2.getStartValue();
        intervalMarker2.setStartValue(35.0d);
        double double7 = intervalMarker2.getEndValue();
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer8 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        levelRenderer8.setBaseURLGenerator(categoryURLGenerator9, true);
        boolean boolean12 = intervalMarker2.equals((java.lang.Object) categoryURLGenerator9);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.height = (-49088);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("LegendItemEntity: seriesKey=null, dataset=null");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset2 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range4 = defaultBoxAndWhiskerCategoryDataset2.getRangeBounds(false);
        java.lang.Comparable comparable5 = null;
        java.lang.Number number7 = defaultBoxAndWhiskerCategoryDataset2.getMaxOutlier(comparable5, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset2);
        double double9 = range8.getLowerBound();
        double double10 = range8.getLength();
        numberAxis1.setDefaultAutoRange(range8);
        numberAxis1.setTickMarkInsideLength((float) 1563303599999L);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Point2D point2D4 = null;
        org.jfree.chart.plot.PlotState plotState5 = new org.jfree.chart.plot.PlotState();
        java.util.Map map6 = plotState5.getSharedAxisStates();
        java.util.Map map7 = plotState5.getSharedAxisStates();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            waferMapPlot1.draw(graphics2D2, rectangle2D3, point2D4, plotState5, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(map6);
        org.junit.Assert.assertNotNull(map7);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font4, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Paint paint11 = jFreeChart10.getBorderPaint();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart10.addProgressListener(chartProgressListener13);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D15.setBase((double) 1.0f);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer18 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = minMaxCategoryRenderer18.getItemLabelGenerator((int) (short) 100, (int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor23 = itemLabelPosition22.getTextAnchor();
        double double24 = itemLabelPosition22.getAngle();
        minMaxCategoryRenderer18.setBaseNegativeItemLabelPosition(itemLabelPosition22);
        stackedBarRenderer3D15.setPositiveItemLabelPositionFallback(itemLabelPosition22);
        boolean boolean27 = jFreeChart10.equals((java.lang.Object) itemLabelPosition22);
        jFreeChart10.setBackgroundImageAlpha((float) 9);
        org.jfree.chart.title.TextTitle textTitle30 = jFreeChart10.getTitle();
        java.awt.Paint paint31 = jFreeChart10.getBorderPaint();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(textTitle30);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection1 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str4 = spreadsheetDate3.getDescription();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean6 = spreadsheetDate3.equals((java.lang.Object) categoryLabelPositions5);
        int int7 = taskSeriesCollection1.getColumnIndex((java.lang.Comparable) spreadsheetDate3);
        java.lang.Class<?> wildcardClass8 = taskSeriesCollection1.getClass();
        java.lang.Object obj9 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("AxisLocation.BOTTOM_OR_LEFT", (java.lang.Class) wildcardClass8);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(obj9);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setUseOutlinePaint(true);
        boolean boolean3 = statisticalLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color2 = java.awt.Color.yellow;
        float[] floatArray6 = new float[] { (byte) -1, 100.0f, 7 };
        float[] floatArray7 = color2.getColorComponents(floatArray6);
        float[] floatArray8 = color1.getRGBColorComponents(floatArray6);
        float[] floatArray9 = color0.getColorComponents(floatArray8);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        defaultStatisticalCategoryDataset0.add((java.lang.Number) (-1L), (java.lang.Number) 100.0d, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 0.0f);
        org.jfree.data.Range range8 = defaultStatisticalCategoryDataset0.getRangeBounds(false);
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range10 = null;
        org.jfree.data.Range range11 = org.jfree.data.Range.combine(range9, range10);
        double double12 = range9.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint(range8, range9);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke2 = piePlot1.getLabelOutlineStroke();
        waterfallBarRenderer0.setBaseOutlineStroke(stroke2);
        double double4 = waterfallBarRenderer0.getUpperClip();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = waterfallBarRenderer0.getPositiveItemLabelPosition((-5280), 2958465);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 9, (double) (short) 100);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range7 = defaultBoxAndWhiskerCategoryDataset5.getRangeBounds(false);
        java.lang.Comparable comparable8 = null;
        java.lang.Number number10 = defaultBoxAndWhiskerCategoryDataset5.getMaxOutlier(comparable8, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str14 = spreadsheetDate13.getDescription();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset5, (java.lang.Comparable) str14);
        legendItemBlockContainer15.setToolTipText("LegendItemEntity: seriesKey=null, dataset=null");
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator3 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.String str4 = standardCategoryToolTipGenerator3.getLabelFormat();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) standardCategoryToolTipGenerator3);
        taskSeriesCollection0.seriesChanged(seriesChangeEvent5);
        try {
            java.lang.Number number9 = taskSeriesCollection0.getStartValue(0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "({0}, {1}) = {2}" + "'", str4.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D3.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedBarRenderer3D3.setBaseToolTipGenerator(categoryToolTipGenerator6);
        stackedBarRenderer3D3.setItemMargin((-1.0d));
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D3.setSeriesOutlineStroke(3, stroke11, true);
        stackedBarRenderer3D0.setBaseOutlineStroke(stroke11, true);
        java.lang.Boolean boolean17 = stackedBarRenderer3D0.getSeriesCreateEntities((-253));
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(boolean17);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        boolean boolean2 = rectangleAnchor0.equals((java.lang.Object) "RangeType.FULL");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor3);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        double double3 = dateAxis0.getUpperBound();
        boolean boolean4 = dateAxis0.isTickLabelsVisible();
        java.util.Date date5 = dateAxis0.getMinimumDate();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = stackedBarRenderer3D0.getLegendItems();
        org.junit.Assert.assertNotNull(legendItemCollection3);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        minMaxCategoryRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.awt.Shape shape5 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke8 = piePlot7.getLabelOutlineStroke();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer10 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        minMaxCategoryRenderer10.setBaseFillPaint(paint11);
        piePlot7.setSectionOutlinePaint((java.lang.Comparable) 0.2d, paint11);
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        piePlot7.setShadowPaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D17.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = null;
        stackedBarRenderer3D17.setBaseToolTipGenerator(categoryToolTipGenerator20);
        stackedBarRenderer3D17.setItemMargin((-1.0d));
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        stackedBarRenderer3D17.setBaseOutlinePaint((java.awt.Paint) color24, false);
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot27.setBaseSectionPaint(paint28);
        java.awt.Font font30 = piePlot27.getLabelFont();
        boolean boolean31 = piePlot27.isSubplot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D32.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator35 = null;
        stackedBarRenderer3D32.setBaseToolTipGenerator(categoryToolTipGenerator35);
        stackedBarRenderer3D32.setItemMargin((-1.0d));
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D32.setSeriesOutlineStroke(3, stroke40, true);
        piePlot27.setOutlineStroke(stroke40);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("orange");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D47 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D47.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator50 = null;
        stackedBarRenderer3D47.setBaseToolTipGenerator(categoryToolTipGenerator50);
        stackedBarRenderer3D47.setItemMargin((-1.0d));
        boolean boolean54 = stackedBarRenderer3D47.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape56 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape60 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape56, (double) 100L, (float) 0, (float) 10L);
        stackedBarRenderer3D47.setBaseShape(shape60, true);
        dateAxis46.setDownArrow(shape60);
        org.jfree.chart.plot.PiePlot piePlot64 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke65 = piePlot64.getLabelOutlineStroke();
        java.awt.Color color66 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem67 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", true, shape5, true, (java.awt.Paint) color14, false, (java.awt.Paint) color24, stroke40, true, shape60, stroke65, (java.awt.Paint) color66);
        legendItem67.setSeriesKey((java.lang.Comparable) "JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\n");
        java.lang.String str70 = legendItem67.getLabel();
        java.awt.Stroke stroke71 = legendItem67.getLineStroke();
        java.text.AttributedString attributedString72 = legendItem67.getAttributedLabel();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "" + "'", str70.equals(""));
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNull(attributedString72);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        double double1 = levelRenderer0.getMaximumItemWidth();
        java.awt.Paint paint4 = levelRenderer0.getItemPaint((int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot1.setBaseSectionPaint(paint2);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape5, (double) 3, 0.0f, (float) 1L);
        piePlot1.setLegendItemShape(shape5);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D12.setBase((double) 1.0f);
        java.lang.Boolean boolean16 = stackedBarRenderer3D12.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font19 = stackedBarRenderer3D12.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font19);
        piePlot1.setLabelFont(font19);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("LegendItemEntity: seriesKey=null, dataset=null", font19);
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker((double) 2, (double) (byte) 100);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D26.setBase((double) 1.0f);
        java.awt.Paint paint29 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D26.setBaseItemLabelPaint(paint29, true);
        java.awt.Shape shape34 = stackedBarRenderer3D26.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity35 = new org.jfree.chart.entity.LegendItemEntity(shape34);
        java.awt.Shape shape36 = legendItemEntity35.getArea();
        java.lang.Comparable comparable37 = legendItemEntity35.getSeriesKey();
        boolean boolean38 = intervalMarker25.equals((java.lang.Object) comparable37);
        intervalMarker25.setStartValue(0.4d);
        java.awt.Font font41 = intervalMarker25.getLabelFont();
        textTitle22.setFont(font41);
        java.awt.Paint paint43 = null;
        textTitle22.setBackgroundPaint(paint43);
        boolean boolean45 = textTitle22.getNotify();
        java.awt.Paint paint46 = textTitle22.getPaint();
        org.jfree.chart.event.TitleChangeListener titleChangeListener47 = null;
        textTitle22.addChangeListener(titleChangeListener47);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(comparable37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        boolean boolean2 = groupedStackedBarRenderer0.equals((java.lang.Object) (short) 0);
        java.awt.Paint paint4 = groupedStackedBarRenderer0.getSeriesOutlinePaint(0);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D9.setLabelURL("");
        categoryAxis3D9.setLowerMargin((double) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone15 = dateAxis14.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis14.getStandardTickUnits();
        double double17 = dateAxis14.getUpperBound();
        boolean boolean18 = dateAxis14.isTickLabelsVisible();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset19 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list20 = defaultStatisticalCategoryDataset19.getColumnKeys();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str23 = spreadsheetDate22.getDescription();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions24 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean25 = spreadsheetDate22.equals((java.lang.Object) categoryLabelPositions24);
        int int26 = spreadsheetDate22.getMonth();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset27 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range29 = defaultBoxAndWhiskerCategoryDataset27.getRangeBounds(false);
        java.lang.Comparable comparable30 = null;
        java.lang.Number number32 = defaultBoxAndWhiskerCategoryDataset27.getMaxOutlier(comparable30, (java.lang.Comparable) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str35 = spreadsheetDate34.getDescription();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions36 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean37 = spreadsheetDate34.equals((java.lang.Object) categoryLabelPositions36);
        int int38 = spreadsheetDate34.getMonth();
        java.lang.Number number40 = defaultBoxAndWhiskerCategoryDataset27.getMinRegularValue((java.lang.Comparable) spreadsheetDate34, (java.lang.Comparable) (-4L));
        java.lang.Number number41 = defaultStatisticalCategoryDataset19.getValue((java.lang.Comparable) int26, (java.lang.Comparable) spreadsheetDate34);
        try {
            groupedStackedBarRenderer0.drawItem(graphics2D5, categoryItemRendererState6, rectangle2D7, categoryPlot8, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D9, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset19, 1900, (-49088), 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1900, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(categoryLabelPositions24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNull(number32);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(categoryLabelPositions36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
        org.junit.Assert.assertNull(number40);
        org.junit.Assert.assertNull(number41);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 2, (float) 1563303599999L);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        java.awt.Shape shape8 = stackedBarRenderer3D0.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset12 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range14 = defaultBoxAndWhiskerCategoryDataset12.getRangeBounds(false);
        java.lang.Comparable comparable15 = null;
        java.lang.Number number17 = defaultBoxAndWhiskerCategoryDataset12.getMaxOutlier(comparable15, (java.lang.Comparable) (short) 0);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity20 = new org.jfree.chart.entity.CategoryItemEntity(shape8, "DateTickMarkPosition.END", "TextBlockAnchor.CENTER_RIGHT", (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset12, (java.lang.Comparable) (short) 1, (java.lang.Comparable) "RangeType.NEGATIVE");
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke22 = piePlot21.getLabelOutlineStroke();
        piePlot21.setLabelLinkMargin((double) '#');
        boolean boolean25 = defaultBoxAndWhiskerCategoryDataset12.hasListener((java.util.EventListener) piePlot21);
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset12);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range26);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setUseOutlinePaint(true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D3.setBase((double) 1.0f);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator6 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        stackedBarRenderer3D3.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator6);
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER;
        boolean boolean9 = standardCategorySeriesLabelGenerator6.equals((java.lang.Object) textAnchor8);
        statisticalLineAndShapeRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator6);
        java.awt.Paint paint11 = statisticalLineAndShapeRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = statisticalLineAndShapeRenderer0.getBaseToolTipGenerator();
        java.awt.Stroke stroke15 = statisticalLineAndShapeRenderer0.getItemStroke((int) (byte) 1, (int) '#');
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.lang.Boolean boolean4 = stackedBarRenderer3D0.getSeriesCreateEntities((int) (short) 1);
        stackedBarRenderer3D0.setItemMargin(0.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D7.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        stackedBarRenderer3D7.setBaseToolTipGenerator(categoryToolTipGenerator10);
        stackedBarRenderer3D7.setItemMargin((-1.0d));
        boolean boolean14 = stackedBarRenderer3D7.getAutoPopulateSeriesOutlinePaint();
        java.lang.Boolean boolean16 = stackedBarRenderer3D7.getSeriesItemLabelsVisible(500);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D18.setBase((double) 1.0f);
        java.lang.Boolean boolean22 = stackedBarRenderer3D18.getSeriesCreateEntities((int) (short) 1);
        double double23 = stackedBarRenderer3D18.getUpperClip();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator25 = stackedBarRenderer3D18.getSeriesItemLabelGenerator((int) (byte) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = stackedBarRenderer3D18.getNegativeItemLabelPosition((-14336), 11);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline29 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline33 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long34 = segmentedTimeline33.getSegmentsExcludedSize();
        java.util.Date date36 = segmentedTimeline33.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline40 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long41 = segmentedTimeline40.getSegmentsExcludedSize();
        java.util.Date date43 = segmentedTimeline40.getDate((long) 7);
        boolean boolean44 = segmentedTimeline29.containsDomainRange(date36, date43);
        boolean boolean45 = itemLabelPosition28.equals((java.lang.Object) boolean44);
        stackedBarRenderer3D7.setSeriesPositiveItemLabelPosition((int) (byte) 0, itemLabelPosition28, false);
        stackedBarRenderer3D0.setBaseNegativeItemLabelPosition(itemLabelPosition28);
        java.awt.Paint paint49 = stackedBarRenderer3D0.getWallPaint();
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNull(boolean22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator25);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertNotNull(segmentedTimeline29);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-4L) + "'", long34 == (-4L));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-4L) + "'", long41 == (-4L));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(paint49);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getLabelOutlineStroke();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer3 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        minMaxCategoryRenderer3.setBaseFillPaint(paint4);
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) 0.2d, paint4);
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        piePlot0.setShadowPaint((java.awt.Paint) color7);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator9 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator9);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 192, (double) 'a');
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        stackedBarRenderer3D1.setBaseToolTipGenerator(categoryToolTipGenerator4);
        stackedBarRenderer3D1.setItemMargin((-1.0d));
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        stackedBarRenderer3D1.setBaseOutlinePaint((java.awt.Paint) color8, false);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(0.25d, (java.awt.Paint) color8, stroke11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.TOP;
        boolean boolean15 = rectangleAnchor13.equals((java.lang.Object) "RangeType.FULL");
        valueMarker12.setLabelAnchor(rectangleAnchor13);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = textTitle18.getTextAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = textTitle18.getTextAlignment();
        boolean boolean21 = textTitle18.getNotify();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D23.setBase((double) 1.0f);
        java.awt.Font font26 = stackedBarRenderer3D23.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot27.setBaseSectionPaint(paint28);
        java.awt.Font font30 = piePlot27.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font26, (org.jfree.chart.plot.Plot) piePlot27, false);
        java.awt.Paint paint33 = jFreeChart32.getBorderPaint();
        boolean boolean34 = jFreeChart32.isBorderVisible();
        textTitle18.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart32);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent36 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) valueMarker12, jFreeChart32);
        org.jfree.chart.text.TextAnchor textAnchor37 = valueMarker12.getLabelTextAnchor();
        double double38 = valueMarker12.getValue();
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(textAnchor37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.25d + "'", double38 == 0.25d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 100, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot2.setBaseSectionPaint(paint3);
        java.awt.Font font5 = piePlot2.getLabelFont();
        boolean boolean6 = piePlot2.isSubplot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot2);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean9 = numberAxis1.equals((java.lang.Object) color8);
        double double10 = numberAxis1.getUpperMargin();
        double double11 = numberAxis1.getFixedDimension();
        boolean boolean12 = numberAxis1.getAutoRangeStickyZero();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        boolean boolean6 = stackedBarRenderer3D0.getAutoPopulateSeriesPaint();
        boolean boolean8 = stackedBarRenderer3D0.isSeriesItemLabelsVisible((int) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = stackedBarRenderer3D0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(itemLabelPosition9);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateTopInset(35.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("orange");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot6.setBaseSectionPaint(paint7);
        java.awt.Font font9 = piePlot6.getLabelFont();
        boolean boolean10 = piePlot6.isSubplot();
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot6);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean13 = numberAxis5.equals((java.lang.Object) color12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer14);
        java.awt.Paint paint16 = xYPlot15.getDomainGridlinePaint();
        java.awt.geom.Point2D point2D17 = null;
        try {
            xYPlot15.setQuadrantOrigin(point2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        stackedBarRenderer3D0.setItemMargin((-1.0d));
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D0.setSeriesOutlineStroke(3, stroke8, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = null;
        stackedBarRenderer3D0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator11);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = null;
        stackedBarRenderer3D0.setGradientPaintTransformer(gradientPaintTransformer13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        stackedBarRenderer3D0.setBaseURLGenerator(categoryURLGenerator15, true);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        boolean boolean19 = stackedBarRenderer3D0.equals((java.lang.Object) color18);
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendTitle20.getLegendItemGraphicAnchor();
        java.awt.Paint paint22 = legendTitle20.getItemPaint();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.lang.Boolean boolean5 = stackedBarRenderer3D1.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font8 = stackedBarRenderer3D1.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.setAutoTickUnitSelection(false);
        boolean boolean13 = dateAxis10.isNegativeArrowVisible();
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot14.setBaseSectionPaint(paint15);
        dateAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot14);
        org.jfree.chart.event.AxisChangeListener axisChangeListener18 = null;
        dateAxis10.removeChangeListener(axisChangeListener18);
        java.awt.Font font20 = dateAxis10.getTickLabelFont();
        java.awt.Color color21 = java.awt.Color.darkGray;
        org.jfree.chart.text.TextMeasurer textMeasurer23 = null;
        org.jfree.chart.text.TextBlock textBlock24 = org.jfree.chart.text.TextUtilities.createTextBlock("", font20, (java.awt.Paint) color21, (float) (byte) 0, textMeasurer23);
        org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("June 2019", font8, (java.awt.Paint) color21);
        org.jfree.chart.text.TextLine textLine26 = textBlock25.getLastLine();
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(textBlock24);
        org.junit.Assert.assertNotNull(textBlock25);
        org.junit.Assert.assertNotNull(textLine26);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.combine(range0, range1);
        java.lang.String str3 = range0.toString();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[0.0,1.0]" + "'", str3.equals("Range[0.0,1.0]"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.width;
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) 10, range1, lengthConstraintType2, (double) (byte) 1, range4, lengthConstraintType5);
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range8 = null;
        org.jfree.data.Range range9 = org.jfree.data.Range.combine(range7, range8);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint6.toRangeHeight(range9);
        double double11 = range9.getCentralValue();
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.5d + "'", double11 == 0.5d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font4, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Paint paint11 = jFreeChart10.getBorderPaint();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart10.addProgressListener(chartProgressListener13);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D15.setBase((double) 1.0f);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer18 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = minMaxCategoryRenderer18.getItemLabelGenerator((int) (short) 100, (int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor23 = itemLabelPosition22.getTextAnchor();
        double double24 = itemLabelPosition22.getAngle();
        minMaxCategoryRenderer18.setBaseNegativeItemLabelPosition(itemLabelPosition22);
        stackedBarRenderer3D15.setPositiveItemLabelPositionFallback(itemLabelPosition22);
        boolean boolean27 = jFreeChart10.equals((java.lang.Object) itemLabelPosition22);
        jFreeChart10.setBackgroundImageAlpha((float) 9);
        org.jfree.chart.title.TextTitle textTitle30 = jFreeChart10.getTitle();
        jFreeChart10.setBackgroundImageAlignment(2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(textTitle30);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str1 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str1.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        java.awt.Stroke stroke7 = stackedBarRenderer3D0.lookupSeriesOutlineStroke((int) (short) 1);
        int int8 = stackedBarRenderer3D0.getPassCount();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        java.awt.Shape shape8 = stackedBarRenderer3D0.getItemShape(1, (int) (short) 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = null;
        stackedBarRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator9);
        boolean boolean11 = stackedBarRenderer3D0.getRenderAsPercentages();
        stackedBarRenderer3D0.setBaseSeriesVisibleInLegend(true);
        java.awt.Paint paint14 = stackedBarRenderer3D0.getBaseFillPaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range3 = defaultBoxAndWhiskerCategoryDataset1.getRangeBounds(false);
        java.lang.Comparable comparable4 = null;
        java.lang.Number number6 = defaultBoxAndWhiskerCategoryDataset1.getMaxOutlier(comparable4, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset1);
        boolean boolean8 = blockBorder0.equals((java.lang.Object) defaultBoxAndWhiskerCategoryDataset1);
        double double10 = defaultBoxAndWhiskerCategoryDataset1.getRangeLowerBound(true);
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape1, (double) 100L, (float) 0, (float) 10L);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.clone(shape5);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape1, (double) 100L, (float) 0, (float) 10L);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape7, (double) 100L, (float) 0, (float) 10L);
        boolean boolean12 = org.jfree.chart.util.ShapeUtilities.equal(shape5, shape11);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity15 = new org.jfree.chart.entity.TickLabelEntity(shape11, "1.0.6", "");
        java.awt.Shape shape16 = tickLabelEntity15.getArea();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D2.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D5.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        stackedBarRenderer3D5.setBaseToolTipGenerator(categoryToolTipGenerator8);
        stackedBarRenderer3D5.setItemMargin((-1.0d));
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D5.setSeriesOutlineStroke(3, stroke13, true);
        stackedBarRenderer3D2.setBaseOutlineStroke(stroke13, true);
        int int18 = month1.compareTo((java.lang.Object) stackedBarRenderer3D2);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D20 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D20.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D23.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator26 = null;
        stackedBarRenderer3D23.setBaseToolTipGenerator(categoryToolTipGenerator26);
        stackedBarRenderer3D23.setItemMargin((-1.0d));
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D23.setSeriesOutlineStroke(3, stroke31, true);
        stackedBarRenderer3D20.setBaseOutlineStroke(stroke31, true);
        int int36 = month19.compareTo((java.lang.Object) stackedBarRenderer3D20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month19.next();
        boolean boolean38 = month1.equals((java.lang.Object) month19);
        boolean boolean39 = multiplePiePlot0.equals((java.lang.Object) month1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = month1.previous();
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str3 = spreadsheetDate2.getDescription();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean5 = spreadsheetDate2.equals((java.lang.Object) categoryLabelPositions4);
        int int6 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) spreadsheetDate2);
        java.lang.Class<?> wildcardClass7 = taskSeriesCollection0.getClass();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.util.Date date9 = month8.getStart();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.setAutoTickUnitSelection(false);
        boolean boolean13 = dateAxis10.isNegativeArrowVisible();
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot14.setBaseSectionPaint(paint15);
        dateAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot14);
        org.jfree.chart.event.AxisChangeListener axisChangeListener18 = null;
        dateAxis10.removeChangeListener(axisChangeListener18);
        java.lang.Class class20 = null;
        java.util.Date date21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone23 = dateAxis22.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone23);
        dateAxis10.setTimeZone(timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date9, timeZone23);
        java.lang.ClassLoader classLoader27 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass7);
        java.util.ResourceBundle.clearCache(classLoader27);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(classLoader27);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 11);
        boolean boolean2 = categoryMarker1.getDrawAsLine();
        java.awt.Font font3 = categoryMarker1.getLabelFont();
        java.awt.Shape shape9 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke12 = piePlot11.getLabelOutlineStroke();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer14 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        minMaxCategoryRenderer14.setBaseFillPaint(paint15);
        piePlot11.setSectionOutlinePaint((java.lang.Comparable) 0.2d, paint15);
        java.awt.Color color18 = java.awt.Color.LIGHT_GRAY;
        piePlot11.setShadowPaint((java.awt.Paint) color18);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D21.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = null;
        stackedBarRenderer3D21.setBaseToolTipGenerator(categoryToolTipGenerator24);
        stackedBarRenderer3D21.setItemMargin((-1.0d));
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        stackedBarRenderer3D21.setBaseOutlinePaint((java.awt.Paint) color28, false);
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot31.setBaseSectionPaint(paint32);
        java.awt.Font font34 = piePlot31.getLabelFont();
        boolean boolean35 = piePlot31.isSubplot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D36 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D36.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator39 = null;
        stackedBarRenderer3D36.setBaseToolTipGenerator(categoryToolTipGenerator39);
        stackedBarRenderer3D36.setItemMargin((-1.0d));
        java.awt.Stroke stroke44 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D36.setSeriesOutlineStroke(3, stroke44, true);
        piePlot31.setOutlineStroke(stroke44);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("orange");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D51 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D51.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator54 = null;
        stackedBarRenderer3D51.setBaseToolTipGenerator(categoryToolTipGenerator54);
        stackedBarRenderer3D51.setItemMargin((-1.0d));
        boolean boolean58 = stackedBarRenderer3D51.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape60 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape64 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape60, (double) 100L, (float) 0, (float) 10L);
        stackedBarRenderer3D51.setBaseShape(shape64, true);
        dateAxis50.setDownArrow(shape64);
        org.jfree.chart.plot.PiePlot piePlot68 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke69 = piePlot68.getLabelOutlineStroke();
        java.awt.Color color70 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem71 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", true, shape9, true, (java.awt.Paint) color18, false, (java.awt.Paint) color28, stroke44, true, shape64, stroke69, (java.awt.Paint) color70);
        categoryMarker1.setOutlineStroke(stroke44);
        org.jfree.chart.util.RectangleInsets rectangleInsets73 = categoryMarker1.getLabelOffset();
        double double75 = rectangleInsets73.calculateBottomInset(0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNotNull(rectangleInsets73);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 3.0d + "'", double75 == 3.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Comparable comparable2 = null;
        java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getMedianValue((java.lang.Comparable) (-1.0f), comparable2);
        org.jfree.data.Range range5 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        double double6 = range5.getUpperBound();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, (float) 1561964399999L, 0.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setStartPercent((double) (-253));
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D3.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedBarRenderer3D3.setBaseToolTipGenerator(categoryToolTipGenerator6);
        stackedBarRenderer3D3.setItemMargin((-1.0d));
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = stackedBarRenderer3D3.getToolTipGenerator((int) (byte) 0, 0);
        java.awt.Shape shape13 = stackedBarRenderer3D3.getBaseShape();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        stackedBarRenderer3D3.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator15);
        java.awt.Paint paint17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        stackedBarRenderer3D3.setBaseFillPaint(paint17);
        ganttRenderer0.setIncompletePaint(paint17);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer23 = new org.jfree.chart.renderer.category.LevelRenderer();
        double double24 = levelRenderer23.getMaximumItemWidth();
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D(pieDataset26);
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot29.setBaseSectionPaint(paint30);
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape33, (double) 3, 0.0f, (float) 1L);
        piePlot29.setLegendItemShape(shape33);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D40 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D40.setBase((double) 1.0f);
        java.lang.Boolean boolean44 = stackedBarRenderer3D40.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font47 = stackedBarRenderer3D40.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine48 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font47);
        piePlot29.setLabelFont(font47);
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle("LegendItemEntity: seriesKey=null, dataset=null", font47);
        piePlot3D27.setLabelFont(font47);
        levelRenderer23.setSeriesItemLabelFont((int) 'a', font47);
        java.awt.Graphics2D graphics2D53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean55 = categoryPlot54.isDomainGridlinesVisible();
        java.awt.Paint paint56 = categoryPlot54.getRangeGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone58 = dateAxis57.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource59 = dateAxis57.getStandardTickUnits();
        double double60 = dateAxis57.getUpperBound();
        boolean boolean61 = dateAxis57.isTickLabelsVisible();
        org.jfree.chart.plot.Marker marker62 = null;
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        levelRenderer23.drawRangeMarker(graphics2D53, categoryPlot54, (org.jfree.chart.axis.ValueAxis) dateAxis57, marker62, rectangle2D63);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D65 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color67 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D65.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color67);
        java.lang.String str70 = categoryAxis3D65.getCategoryLabelToolTip((java.lang.Comparable) 4.0d);
        categoryAxis3D65.configure();
        java.awt.Paint paint73 = categoryAxis3D65.getTickLabelPaint((java.lang.Comparable) 0.25d);
        java.lang.String str75 = categoryAxis3D65.getCategoryLabelToolTip((java.lang.Comparable) 86400000L);
        org.jfree.chart.axis.ValueAxis valueAxis76 = null;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection77 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range79 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection77, true);
        int int80 = taskSeriesCollection77.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries82 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection77.remove(taskSeries82);
        java.util.List list84 = taskSeriesCollection77.getColumnKeys();
        try {
            ganttRenderer0.drawItem(graphics2D20, categoryItemRendererState21, rectangle2D22, categoryPlot54, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D65, valueAxis76, (org.jfree.data.category.CategoryDataset) taskSeriesCollection77, 0, 6, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNull(boolean44);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNotNull(tickUnitSource59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNull(str75);
        org.junit.Assert.assertNull(range79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertNotNull(list84);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItem legendItem1 = null;
        legendItemCollection0.add(legendItem1);
        java.util.Iterator iterator3 = legendItemCollection0.iterator();
        java.awt.Shape shape9 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke12 = piePlot11.getLabelOutlineStroke();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer14 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        minMaxCategoryRenderer14.setBaseFillPaint(paint15);
        piePlot11.setSectionOutlinePaint((java.lang.Comparable) 0.2d, paint15);
        java.awt.Color color18 = java.awt.Color.LIGHT_GRAY;
        piePlot11.setShadowPaint((java.awt.Paint) color18);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D21.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = null;
        stackedBarRenderer3D21.setBaseToolTipGenerator(categoryToolTipGenerator24);
        stackedBarRenderer3D21.setItemMargin((-1.0d));
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        stackedBarRenderer3D21.setBaseOutlinePaint((java.awt.Paint) color28, false);
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot31.setBaseSectionPaint(paint32);
        java.awt.Font font34 = piePlot31.getLabelFont();
        boolean boolean35 = piePlot31.isSubplot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D36 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D36.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator39 = null;
        stackedBarRenderer3D36.setBaseToolTipGenerator(categoryToolTipGenerator39);
        stackedBarRenderer3D36.setItemMargin((-1.0d));
        java.awt.Stroke stroke44 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D36.setSeriesOutlineStroke(3, stroke44, true);
        piePlot31.setOutlineStroke(stroke44);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("orange");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D51 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D51.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator54 = null;
        stackedBarRenderer3D51.setBaseToolTipGenerator(categoryToolTipGenerator54);
        stackedBarRenderer3D51.setItemMargin((-1.0d));
        boolean boolean58 = stackedBarRenderer3D51.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape60 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape64 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape60, (double) 100L, (float) 0, (float) 10L);
        stackedBarRenderer3D51.setBaseShape(shape64, true);
        dateAxis50.setDownArrow(shape64);
        org.jfree.chart.plot.PiePlot piePlot68 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke69 = piePlot68.getLabelOutlineStroke();
        java.awt.Color color70 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem71 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", true, shape9, true, (java.awt.Paint) color18, false, (java.awt.Paint) color28, stroke44, true, shape64, stroke69, (java.awt.Paint) color70);
        legendItem71.setSeriesKey((java.lang.Comparable) "JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\n");
        java.lang.String str74 = legendItem71.getLabel();
        legendItemCollection0.add(legendItem71);
        java.awt.Shape shape76 = legendItem71.getShape();
        org.jfree.data.general.Dataset dataset77 = null;
        legendItem71.setDataset(dataset77);
        org.junit.Assert.assertNotNull(iterator3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "" + "'", str74.equals(""));
        org.junit.Assert.assertNull(shape76);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.awt.Color color0 = java.awt.Color.gray;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=128,g=128,b=128]" + "'", str1.equals("java.awt.Color[r=128,g=128,b=128]"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D2.setBase((double) 1.0f);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        stackedBarRenderer3D2.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.CENTER;
        boolean boolean8 = standardCategorySeriesLabelGenerator5.equals((java.lang.Object) textAnchor7);
        boolean boolean9 = chartRenderingInfo1.equals((java.lang.Object) boolean8);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke2 = piePlot1.getLabelOutlineStroke();
        waterfallBarRenderer0.setBaseOutlineStroke(stroke2);
        double double4 = waterfallBarRenderer0.getUpperClip();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer5 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot6.setBaseSectionPaint(paint7);
        minMaxCategoryRenderer5.setBaseFillPaint(paint7);
        waterfallBarRenderer0.setBasePaint(paint7);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("hi!");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection4, true);
        taskSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) taskSeriesCollection4);
        int int8 = taskSeriesCollection4.getSeriesCount();
        try {
            java.lang.Number number12 = taskSeriesCollection4.getEndValue(0, (int) (byte) 100, (-14336));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("hi!");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection4, true);
        taskSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) taskSeriesCollection4);
        taskSeries1.removeAll();
        org.jfree.data.gantt.Task task10 = taskSeries1.get("TextAnchor.BOTTOM_CENTER");
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(task10);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long4 = segmentedTimeline3.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long10 = segmentedTimeline9.getSegmentsExcludedSize();
        java.util.Date date12 = segmentedTimeline9.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long17 = segmentedTimeline16.getSegmentsExcludedSize();
        java.util.Date date19 = segmentedTimeline16.getDate((long) 7);
        boolean boolean20 = segmentedTimeline5.containsDomainRange(date12, date19);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline3.getSegment(date19);
        long long22 = segment21.getMillisecond();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-4L) + "'", long4 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-4L) + "'", long10 == (-4L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-4L) + "'", long17 == (-4L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(segment21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 7L + "'", long22 == 7L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        categoryPlot0.setRangeCrosshairValue(Double.NaN, true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D6.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color8);
        java.lang.String str11 = categoryAxis3D6.getCategoryLabelToolTip((java.lang.Comparable) 4.0d);
        categoryAxis3D6.configure();
        java.awt.Paint paint14 = categoryAxis3D6.getTickLabelPaint((java.lang.Comparable) 0.25d);
        java.lang.String str16 = categoryAxis3D6.getCategoryLabelToolTip((java.lang.Comparable) 86400000L);
        try {
            categoryPlot0.setDomainAxis((-460), (org.jfree.chart.axis.CategoryAxis) categoryAxis3D6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getRowKeys();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        dateAxis1.setInverted(false);
        dateAxis1.resizeRange((double) (byte) 10, (double) (byte) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection0.add((org.jfree.chart.axis.Axis) dateAxis1, rectangleEdge8);
        dateAxis1.setAutoRangeMinimumSize(0.05d);
        java.text.DateFormat dateFormat12 = null;
        dateAxis1.setDateFormatOverride(dateFormat12);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot1.setBaseSectionPaint(paint2);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape5, (double) 3, 0.0f, (float) 1L);
        piePlot1.setLegendItemShape(shape5);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D12.setBase((double) 1.0f);
        java.lang.Boolean boolean16 = stackedBarRenderer3D12.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font19 = stackedBarRenderer3D12.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font19);
        piePlot1.setLabelFont(font19);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot22.setBaseSectionPaint(paint23);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape26, (double) 3, 0.0f, (float) 1L);
        piePlot22.setLegendItemShape(shape26);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D33.setBase((double) 1.0f);
        java.lang.Boolean boolean37 = stackedBarRenderer3D33.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font40 = stackedBarRenderer3D33.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine41 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font40);
        piePlot22.setLabelFont(font40);
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_RED;
        piePlot22.setNoDataMessagePaint((java.awt.Paint) color43);
        org.jfree.chart.block.LabelBlock labelBlock45 = new org.jfree.chart.block.LabelBlock("orange", font19, (java.awt.Paint) color43);
        labelBlock45.setURLText("");
        labelBlock45.setToolTipText("Category Plot");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer50 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint51 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        minMaxCategoryRenderer50.setBaseFillPaint(paint51);
        labelBlock45.setPaint(paint51);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNull(boolean37);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("({0}, {1}) = {2}", graphics2D1, 0.0f, (float) (-253), textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItem legendItem1 = null;
        legendItemCollection0.add(legendItem1);
        java.util.Iterator iterator3 = legendItemCollection0.iterator();
        java.awt.Shape shape9 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke12 = piePlot11.getLabelOutlineStroke();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer14 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        minMaxCategoryRenderer14.setBaseFillPaint(paint15);
        piePlot11.setSectionOutlinePaint((java.lang.Comparable) 0.2d, paint15);
        java.awt.Color color18 = java.awt.Color.LIGHT_GRAY;
        piePlot11.setShadowPaint((java.awt.Paint) color18);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D21.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = null;
        stackedBarRenderer3D21.setBaseToolTipGenerator(categoryToolTipGenerator24);
        stackedBarRenderer3D21.setItemMargin((-1.0d));
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        stackedBarRenderer3D21.setBaseOutlinePaint((java.awt.Paint) color28, false);
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot31.setBaseSectionPaint(paint32);
        java.awt.Font font34 = piePlot31.getLabelFont();
        boolean boolean35 = piePlot31.isSubplot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D36 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D36.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator39 = null;
        stackedBarRenderer3D36.setBaseToolTipGenerator(categoryToolTipGenerator39);
        stackedBarRenderer3D36.setItemMargin((-1.0d));
        java.awt.Stroke stroke44 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D36.setSeriesOutlineStroke(3, stroke44, true);
        piePlot31.setOutlineStroke(stroke44);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("orange");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D51 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D51.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator54 = null;
        stackedBarRenderer3D51.setBaseToolTipGenerator(categoryToolTipGenerator54);
        stackedBarRenderer3D51.setItemMargin((-1.0d));
        boolean boolean58 = stackedBarRenderer3D51.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape60 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape64 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape60, (double) 100L, (float) 0, (float) 10L);
        stackedBarRenderer3D51.setBaseShape(shape64, true);
        dateAxis50.setDownArrow(shape64);
        org.jfree.chart.plot.PiePlot piePlot68 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke69 = piePlot68.getLabelOutlineStroke();
        java.awt.Color color70 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem71 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", true, shape9, true, (java.awt.Paint) color18, false, (java.awt.Paint) color28, stroke44, true, shape64, stroke69, (java.awt.Paint) color70);
        legendItem71.setSeriesKey((java.lang.Comparable) "JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\n");
        java.lang.String str74 = legendItem71.getLabel();
        legendItemCollection0.add(legendItem71);
        org.jfree.data.general.Dataset dataset76 = legendItem71.getDataset();
        boolean boolean77 = legendItem71.isShapeVisible();
        org.junit.Assert.assertNotNull(iterator3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "" + "'", str74.equals(""));
        org.junit.Assert.assertNull(dataset76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        stackedBarRenderer3D4.setBaseToolTipGenerator(categoryToolTipGenerator7);
        stackedBarRenderer3D4.setItemMargin((-1.0d));
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D4.setSeriesOutlineStroke(3, stroke12, true);
        stackedBarRenderer3D1.setBaseOutlineStroke(stroke12, true);
        int int17 = month0.compareTo((java.lang.Object) stackedBarRenderer3D1);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D19.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D22.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator25 = null;
        stackedBarRenderer3D22.setBaseToolTipGenerator(categoryToolTipGenerator25);
        stackedBarRenderer3D22.setItemMargin((-1.0d));
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D22.setSeriesOutlineStroke(3, stroke30, true);
        stackedBarRenderer3D19.setBaseOutlineStroke(stroke30, true);
        int int35 = month18.compareTo((java.lang.Object) stackedBarRenderer3D19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month18.next();
        boolean boolean37 = month0.equals((java.lang.Object) month18);
        long long38 = month0.getLastMillisecond();
        org.jfree.data.time.Year year39 = month0.getYear();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D40 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D40.setBase((double) 1.0f);
        stackedBarRenderer3D40.setBaseSeriesVisible(false);
        int int45 = year39.compareTo((java.lang.Object) stackedBarRenderer3D40);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1561964399999L + "'", long38 == 1561964399999L);
        org.junit.Assert.assertNotNull(year39);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long4 = segmentedTimeline3.getSegmentsExcludedSize();
        java.util.Date date6 = segmentedTimeline3.getDate((long) 7);
        long long7 = segmentedTimeline3.getSegmentsIncludedSize();
        boolean boolean8 = segmentedTimeline3.getAdjustForDaylightSaving();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-4L) + "'", long4 == (-4L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-4L) + "'", long7 == (-4L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        int int1 = groupedStackedBarRenderer0.getPassCount();
        java.awt.Stroke stroke3 = groupedStackedBarRenderer0.getSeriesOutlineStroke((int) (byte) 10);
        boolean boolean4 = groupedStackedBarRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = minMaxCategoryRenderer0.getItemLabelGenerator((int) (short) 100, (int) 'a');
        java.awt.Paint paint6 = minMaxCategoryRenderer0.getItemPaint((-1), (int) (short) 100);
        java.awt.Paint paint7 = minMaxCategoryRenderer0.getGroupPaint();
        java.awt.Font font9 = minMaxCategoryRenderer0.getSeriesItemLabelFont(7);
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(font9);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        try {
            piePlot3D1.setBackgroundImageAlpha((float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test250");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo0.setLicenceText("");
//        java.lang.String str3 = projectInfo0.getVersion();
//        java.lang.String str4 = projectInfo0.getCopyright();
//        projectInfo0.setName("java.awt.Color[r=128,g=128,b=128]");
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DateTickMarkPosition.END" + "'", str3.equals("DateTickMarkPosition.END"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str4.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str4 = spreadsheetDate3.getDescription();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean6 = spreadsheetDate3.equals((java.lang.Object) categoryLabelPositions5);
        int int7 = spreadsheetDate3.getMonth();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset8 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range10 = defaultBoxAndWhiskerCategoryDataset8.getRangeBounds(false);
        java.lang.Comparable comparable11 = null;
        java.lang.Number number13 = defaultBoxAndWhiskerCategoryDataset8.getMaxOutlier(comparable11, (java.lang.Comparable) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str16 = spreadsheetDate15.getDescription();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions17 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean18 = spreadsheetDate15.equals((java.lang.Object) categoryLabelPositions17);
        int int19 = spreadsheetDate15.getMonth();
        java.lang.Number number21 = defaultBoxAndWhiskerCategoryDataset8.getMinRegularValue((java.lang.Comparable) spreadsheetDate15, (java.lang.Comparable) (-4L));
        java.lang.Number number22 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) int7, (java.lang.Comparable) spreadsheetDate15);
        try {
            java.lang.Number number25 = defaultStatisticalCategoryDataset0.getMeanValue(2958465, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2958465, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(categoryLabelPositions17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNull(number21);
        org.junit.Assert.assertNull(number22);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("TextAnchor.BOTTOM_CENTER", graphics2D1, (float) 7, 100.0f, (double) 100L, 10.0f, (float) 192);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 100.0f, (double) (byte) 10);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset3 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range5 = defaultBoxAndWhiskerCategoryDataset3.getRangeBounds(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline11 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long12 = segmentedTimeline11.getSegmentsExcludedSize();
        java.util.Date date14 = segmentedTimeline11.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline18 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long19 = segmentedTimeline18.getSegmentsExcludedSize();
        java.util.Date date21 = segmentedTimeline18.getDate((long) 7);
        boolean boolean22 = segmentedTimeline7.containsDomainRange(date14, date21);
        java.lang.Number number23 = defaultBoxAndWhiskerCategoryDataset3.getMaxRegularValue((java.lang.Comparable) ' ', (java.lang.Comparable) date14);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date14);
        boolean boolean25 = meanAndStandardDeviation2.equals((java.lang.Object) year24);
        java.lang.Number number26 = meanAndStandardDeviation2.getStandardDeviation();
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(segmentedTimeline7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-4L) + "'", long12 == (-4L));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-4L) + "'", long19 == (-4L));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 10.0d + "'", number26.equals(10.0d));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.0d, (double) '#');
        double double3 = size2D2.height;
        double double4 = size2D2.getHeight();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 35.0d + "'", double4 == 35.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        stackedBarRenderer3D0.setItemMargin((double) 4L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot2.setBaseSectionPaint(paint3);
        java.awt.Font font5 = piePlot2.getLabelFont();
        boolean boolean6 = piePlot2.isSubplot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot2);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean9 = numberAxis1.equals((java.lang.Object) color8);
        double double10 = numberAxis1.getUpperMargin();
        java.awt.Shape shape11 = null;
        try {
            numberAxis1.setUpArrow(shape11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 3, 0.0f, (float) 1L);
        piePlot0.setLegendItemShape(shape4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot0.getLabelGenerator();
        piePlot0.setIgnoreNullValues(true);
        int int13 = piePlot0.getPieIndex();
        piePlot0.setShadowXOffset((double) 6);
        java.awt.Paint paint16 = piePlot0.getNoDataMessagePaint();
        java.awt.Paint paint17 = piePlot0.getShadowPaint();
        piePlot0.setBackgroundImageAlignment(2958465);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        java.lang.Comparable comparable3 = null;
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier(comparable3, (java.lang.Comparable) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str8 = spreadsheetDate7.getDescription();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean10 = spreadsheetDate7.equals((java.lang.Object) categoryLabelPositions9);
        int int11 = spreadsheetDate7.getMonth();
        java.lang.Number number13 = defaultBoxAndWhiskerCategoryDataset0.getMinRegularValue((java.lang.Comparable) spreadsheetDate7, (java.lang.Comparable) (-4L));
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str16 = spreadsheetDate15.getDescription();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions17 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean18 = spreadsheetDate15.equals((java.lang.Object) categoryLabelPositions17);
        int int19 = spreadsheetDate15.getMonth();
        boolean boolean20 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        try {
            org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate7.getFollowingDayOfWeek((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(categoryLabelPositions17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        double double3 = dateAxis0.getUpperBound();
        boolean boolean4 = dateAxis0.isTickLabelsVisible();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        dateAxis0.setTickMarkPaint((java.awt.Paint) color5);
        dateAxis0.resizeRange((double) (-1.0f));
        dateAxis0.setTickMarkInsideLength((float) 'a');
        dateAxis0.setVisible(true);
        dateAxis0.setAutoRangeMinimumSize((double) '#', false);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) 100L, (float) 0, (float) 10L);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape12, (double) 100L, (float) 0, (float) 10L);
        boolean boolean17 = org.jfree.chart.util.ShapeUtilities.equal(shape10, shape16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        int int20 = color19.getAlpha();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer22 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint23 = waterfallBarRenderer22.getLastBarPaint();
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot24.setBaseSectionPaint(paint25);
        java.awt.Font font27 = piePlot24.getLabelFont();
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot24.setBaseSectionOutlineStroke(stroke28);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setBase((double) 1.0f);
        java.awt.Paint paint34 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D31.setBaseItemLabelPaint(paint34, true);
        java.awt.Shape shape39 = stackedBarRenderer3D31.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity40 = new org.jfree.chart.entity.LegendItemEntity(shape39);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset43 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range45 = defaultBoxAndWhiskerCategoryDataset43.getRangeBounds(false);
        java.lang.Comparable comparable46 = null;
        java.lang.Number number48 = defaultBoxAndWhiskerCategoryDataset43.getMaxOutlier(comparable46, (java.lang.Comparable) (short) 0);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity51 = new org.jfree.chart.entity.CategoryItemEntity(shape39, "DateTickMarkPosition.END", "TextBlockAnchor.CENTER_RIGHT", (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset43, (java.lang.Comparable) (short) 1, (java.lang.Comparable) "RangeType.NEGATIVE");
        java.awt.Stroke stroke52 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer53 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.plot.PiePlot piePlot54 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke55 = piePlot54.getLabelOutlineStroke();
        waterfallBarRenderer53.setBaseOutlineStroke(stroke55);
        java.awt.Paint paint57 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        waterfallBarRenderer53.setLastBarPaint(paint57);
        org.jfree.chart.LegendItem legendItem59 = new org.jfree.chart.LegendItem("Default Group", "1.0.6", "1.0.6", "GradientPaintTransformType.VERTICAL", false, shape10, true, (java.awt.Paint) color19, true, paint23, stroke28, false, shape39, stroke52, paint57);
        java.lang.String str60 = legendItem59.getURLText();
        java.lang.String str61 = legendItem59.getDescription();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 255 + "'", int20 == 255);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "GradientPaintTransformType.VERTICAL" + "'", str60.equals("GradientPaintTransformType.VERTICAL"));
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "1.0.6" + "'", str61.equals("1.0.6"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\n");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener2);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range3 = defaultBoxAndWhiskerCategoryDataset1.getRangeBounds(false);
        java.lang.Comparable comparable4 = null;
        java.lang.Number number6 = defaultBoxAndWhiskerCategoryDataset1.getMaxOutlier(comparable4, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset1);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset1, (double) 10L);
        try {
            java.lang.String str11 = standardCategoryToolTipGenerator0.generateRowLabel((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D0.setSeriesOutlineStroke((int) ' ', stroke6);
        stackedBarRenderer3D0.setAutoPopulateSeriesShape(true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean12 = categoryPlot11.isDomainGridlinesVisible();
        java.awt.Paint paint13 = categoryPlot11.getRangeGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot11.setRenderer(categoryItemRenderer14);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot11.getDomainAxis();
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot17.setBaseSectionPaint(paint18);
        java.awt.Font font20 = piePlot17.getLabelFont();
        boolean boolean21 = piePlot17.isSubplot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D22.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator25 = null;
        stackedBarRenderer3D22.setBaseToolTipGenerator(categoryToolTipGenerator25);
        stackedBarRenderer3D22.setItemMargin((-1.0d));
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D22.setSeriesOutlineStroke(3, stroke30, true);
        piePlot17.setOutlineStroke(stroke30);
        categoryPlot11.setRangeGridlineStroke(stroke30);
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        try {
            stackedBarRenderer3D0.drawBackground(graphics2D10, categoryPlot11, rectangle2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer1 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer1.setStartPercent((double) (-253));
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        stackedBarRenderer3D4.setBaseToolTipGenerator(categoryToolTipGenerator7);
        stackedBarRenderer3D4.setItemMargin((-1.0d));
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = stackedBarRenderer3D4.getToolTipGenerator((int) (byte) 0, 0);
        java.awt.Shape shape14 = stackedBarRenderer3D4.getBaseShape();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = null;
        stackedBarRenderer3D4.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator16);
        java.awt.Paint paint18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        stackedBarRenderer3D4.setBaseFillPaint(paint18);
        ganttRenderer1.setIncompletePaint(paint18);
        boolean boolean21 = chartChangeEventType0.equals((java.lang.Object) paint18);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color2);
        java.lang.String str5 = categoryAxis3D0.getCategoryLabelToolTip((java.lang.Comparable) 4.0d);
        categoryAxis3D0.configure();
        categoryAxis3D0.configure();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (-1), (double) (byte) 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 3, 0.0f, (float) 1L);
        piePlot0.setLegendItemShape(shape4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot0.getLabelGenerator();
        piePlot0.setIgnoreNullValues(true);
        int int13 = piePlot0.getPieIndex();
        piePlot0.setShadowXOffset((double) 6);
        piePlot0.setPieIndex((int) (short) -1);
        java.awt.Paint paint18 = piePlot0.getOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor19 = piePlot0.getLabelDistributor();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor19);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setBaseShapesFilled(false);
        statisticalLineAndShapeRenderer0.setSeriesShapesFilled((int) 'a', true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) '4', (double) 10);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = stackedBarRenderer3D2.getURLGenerator((int) (byte) 1, (int) ' ');
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer10 = new org.jfree.chart.renderer.category.LevelRenderer();
        double double11 = levelRenderer10.getMaximumItemWidth();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D(pieDataset13);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot16.setBaseSectionPaint(paint17);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape20, (double) 3, 0.0f, (float) 1L);
        piePlot16.setLegendItemShape(shape20);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D27 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D27.setBase((double) 1.0f);
        java.lang.Boolean boolean31 = stackedBarRenderer3D27.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font34 = stackedBarRenderer3D27.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine35 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font34);
        piePlot16.setLabelFont(font34);
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("LegendItemEntity: seriesKey=null, dataset=null", font34);
        piePlot3D14.setLabelFont(font34);
        levelRenderer10.setSeriesItemLabelFont((int) 'a', font34);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean42 = categoryPlot41.isDomainGridlinesVisible();
        java.awt.Paint paint43 = categoryPlot41.getRangeGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone45 = dateAxis44.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource46 = dateAxis44.getStandardTickUnits();
        double double47 = dateAxis44.getUpperBound();
        boolean boolean48 = dateAxis44.isTickLabelsVisible();
        org.jfree.chart.plot.Marker marker49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        levelRenderer10.drawRangeMarker(graphics2D40, categoryPlot41, (org.jfree.chart.axis.ValueAxis) dateAxis44, marker49, rectangle2D50);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset52 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Comparable comparable54 = null;
        java.lang.Number number55 = defaultBoxAndWhiskerCategoryDataset52.getMedianValue((java.lang.Comparable) (-1.0f), comparable54);
        org.jfree.data.Range range57 = defaultBoxAndWhiskerCategoryDataset52.getRangeBounds(false);
        categoryPlot41.setDataset((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset52);
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        try {
            stackedBarRenderer3D2.drawBackground(graphics2D9, categoryPlot41, rectangle2D59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(boolean31);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNotNull(tickUnitSource46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNull(number55);
        org.junit.Assert.assertNotNull(range57);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) 100L, (float) 0, (float) 10L);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape12, (double) 100L, (float) 0, (float) 10L);
        boolean boolean17 = org.jfree.chart.util.ShapeUtilities.equal(shape10, shape16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        int int20 = color19.getAlpha();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer22 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint23 = waterfallBarRenderer22.getLastBarPaint();
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot24.setBaseSectionPaint(paint25);
        java.awt.Font font27 = piePlot24.getLabelFont();
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot24.setBaseSectionOutlineStroke(stroke28);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setBase((double) 1.0f);
        java.awt.Paint paint34 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D31.setBaseItemLabelPaint(paint34, true);
        java.awt.Shape shape39 = stackedBarRenderer3D31.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity40 = new org.jfree.chart.entity.LegendItemEntity(shape39);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset43 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range45 = defaultBoxAndWhiskerCategoryDataset43.getRangeBounds(false);
        java.lang.Comparable comparable46 = null;
        java.lang.Number number48 = defaultBoxAndWhiskerCategoryDataset43.getMaxOutlier(comparable46, (java.lang.Comparable) (short) 0);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity51 = new org.jfree.chart.entity.CategoryItemEntity(shape39, "DateTickMarkPosition.END", "TextBlockAnchor.CENTER_RIGHT", (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset43, (java.lang.Comparable) (short) 1, (java.lang.Comparable) "RangeType.NEGATIVE");
        java.awt.Stroke stroke52 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer53 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.plot.PiePlot piePlot54 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke55 = piePlot54.getLabelOutlineStroke();
        waterfallBarRenderer53.setBaseOutlineStroke(stroke55);
        java.awt.Paint paint57 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        waterfallBarRenderer53.setLastBarPaint(paint57);
        org.jfree.chart.LegendItem legendItem59 = new org.jfree.chart.LegendItem("Default Group", "1.0.6", "1.0.6", "GradientPaintTransformType.VERTICAL", false, shape10, true, (java.awt.Paint) color19, true, paint23, stroke28, false, shape39, stroke52, paint57);
        int int60 = legendItem59.getSeriesIndex();
        java.lang.Object obj61 = null;
        boolean boolean62 = legendItem59.equals(obj61);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 255 + "'", int20 == 255);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("Other", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, (double) 3, 0.0f, (float) 1L);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 10L, shape2, "GradientPaintTransformType.VERTICAL", "UnitType.RELATIVE");
        java.lang.String str10 = categoryLabelEntity9.getToolTipText();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GradientPaintTransformType.VERTICAL" + "'", str10.equals("GradientPaintTransformType.VERTICAL"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        double double3 = dateAxis0.getUpperBound();
        boolean boolean4 = dateAxis0.isTickLabelsVisible();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        dateAxis0.setTickMarkPaint((java.awt.Paint) color5);
        org.jfree.data.Range range7 = dateAxis0.getDefaultAutoRange();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape9, (double) 100L, (float) 0, (float) 10L);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity16 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis0, shape9, "RangeType.NEGATIVE", "RangeType.NEGATIVE");
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = dateAxis0.getTickLabelInsets();
        double double18 = dateAxis0.getLowerBound();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight(9);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D3.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedBarRenderer3D3.setBaseToolTipGenerator(categoryToolTipGenerator6);
        stackedBarRenderer3D3.setItemMargin((-1.0d));
        boolean boolean10 = stackedBarRenderer3D3.getAutoPopulateSeriesOutlinePaint();
        java.lang.Boolean boolean12 = stackedBarRenderer3D3.getSeriesItemLabelsVisible(500);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D14.setBase((double) 1.0f);
        java.lang.Boolean boolean18 = stackedBarRenderer3D14.getSeriesCreateEntities((int) (short) 1);
        double double19 = stackedBarRenderer3D14.getUpperClip();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedBarRenderer3D14.getSeriesItemLabelGenerator((int) (byte) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = stackedBarRenderer3D14.getNegativeItemLabelPosition((-14336), 11);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline25 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline29 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long30 = segmentedTimeline29.getSegmentsExcludedSize();
        java.util.Date date32 = segmentedTimeline29.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline36 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long37 = segmentedTimeline36.getSegmentsExcludedSize();
        java.util.Date date39 = segmentedTimeline36.getDate((long) 7);
        boolean boolean40 = segmentedTimeline25.containsDomainRange(date32, date39);
        boolean boolean41 = itemLabelPosition24.equals((java.lang.Object) boolean40);
        stackedBarRenderer3D3.setSeriesPositiveItemLabelPosition((int) (byte) 0, itemLabelPosition24, false);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D3, true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNull(boolean18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(segmentedTimeline25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-4L) + "'", long30 == (-4L));
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-4L) + "'", long37 == (-4L));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        stackedBarRenderer3D0.setItemMargin((-1.0d));
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D0.getToolTipGenerator((int) (byte) 0, 0);
        stackedBarRenderer3D0.setAutoPopulateSeriesOutlineStroke(false);
        stackedBarRenderer3D0.setDrawBarOutline(true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset14 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Comparable comparable16 = null;
        java.lang.Number number17 = defaultBoxAndWhiskerCategoryDataset14.getMedianValue((java.lang.Comparable) (-1.0f), comparable16);
        org.jfree.data.Range range19 = defaultBoxAndWhiskerCategoryDataset14.getRangeBounds(false);
        org.jfree.data.Range range20 = stackedBarRenderer3D0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset14);
        stackedBarRenderer3D0.setSeriesItemLabelsVisible(7, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(range20);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot1.setBaseSectionPaint(paint2);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape5, (double) 3, 0.0f, (float) 1L);
        piePlot1.setLegendItemShape(shape5);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D12.setBase((double) 1.0f);
        java.lang.Boolean boolean16 = stackedBarRenderer3D12.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font19 = stackedBarRenderer3D12.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font19);
        piePlot1.setLabelFont(font19);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("LegendItemEntity: seriesKey=null, dataset=null", font19);
        textTitle22.setExpandToFitSpace(false);
        textTitle22.setID("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font1 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot2.setBaseSectionPaint(paint3);
        java.awt.Font font5 = piePlot2.getLabelFont();
        boolean boolean6 = piePlot2.isSubplot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D7.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        stackedBarRenderer3D7.setBaseToolTipGenerator(categoryToolTipGenerator10);
        stackedBarRenderer3D7.setItemMargin((-1.0d));
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D7.setSeriesOutlineStroke(3, stroke15, true);
        piePlot2.setOutlineStroke(stroke15);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot2.setNoDataMessagePaint((java.awt.Paint) color19);
        boolean boolean21 = barRenderer0.equals((java.lang.Object) piePlot2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = new org.jfree.chart.labels.ItemLabelPosition();
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition22);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        dateAxis1.setInverted(false);
        dateAxis1.resizeRange((double) (byte) 10, (double) (byte) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection0.add((org.jfree.chart.axis.Axis) dateAxis1, rectangleEdge8);
        double double10 = dateAxis1.getFixedDimension();
        dateAxis1.resizeRange((double) 10);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot1.setBaseSectionPaint(paint2);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape5, (double) 3, 0.0f, (float) 1L);
        piePlot1.setLegendItemShape(shape5);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D12.setBase((double) 1.0f);
        java.lang.Boolean boolean16 = stackedBarRenderer3D12.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font19 = stackedBarRenderer3D12.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font19);
        piePlot1.setLabelFont(font19);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("LegendItemEntity: seriesKey=null, dataset=null", font19);
        java.lang.String str23 = textTitle22.getURLText();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        taskSeries1.removeChangeListener(seriesChangeListener2);
        taskSeries1.setNotify(true);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        defaultStatisticalCategoryDataset0.add((java.lang.Number) (-1L), (java.lang.Number) 100.0d, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 0.0f);
        org.jfree.data.Range range8 = defaultStatisticalCategoryDataset0.getRangeBounds(false);
        double double10 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 2, (double) (byte) 100);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D14.setBase((double) 1.0f);
        java.awt.Paint paint17 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D14.setBaseItemLabelPaint(paint17, true);
        java.awt.Shape shape22 = stackedBarRenderer3D14.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity23 = new org.jfree.chart.entity.LegendItemEntity(shape22);
        java.awt.Shape shape24 = legendItemEntity23.getArea();
        java.lang.Comparable comparable25 = legendItemEntity23.getSeriesKey();
        boolean boolean26 = intervalMarker13.equals((java.lang.Object) comparable25);
        intervalMarker13.setStartValue(0.4d);
        java.lang.Object obj29 = intervalMarker13.clone();
        boolean boolean30 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) intervalMarker13);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(comparable25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("orange");
        float float4 = dateAxis3.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot7.setBaseSectionPaint(paint8);
        java.awt.Font font10 = piePlot7.getLabelFont();
        boolean boolean11 = piePlot7.isSubplot();
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot7);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean14 = numberAxis6.equals((java.lang.Object) color13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis6, xYItemRenderer15);
        java.awt.Paint paint17 = xYPlot16.getDomainGridlinePaint();
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str20 = layer19.toString();
        java.util.Collection collection21 = xYPlot16.getRangeMarkers(3, layer19);
        java.util.Collection collection22 = categoryPlot0.getDomainMarkers(layer19);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        boolean boolean27 = categoryPlot0.render(graphics2D23, rectangle2D24, (-460), plotRenderingInfo26);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        boolean boolean32 = categoryPlot0.render(graphics2D28, rectangle2D29, 8, plotRenderingInfo31);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Layer.FOREGROUND" + "'", str20.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        dateAxis1.setInverted(false);
        dateAxis1.resizeRange((double) (byte) 10, (double) (byte) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection0.add((org.jfree.chart.axis.Axis) dateAxis1, rectangleEdge8);
        double double10 = dateAxis1.getFixedDimension();
        java.awt.Paint paint11 = dateAxis1.getTickLabelPaint();
        java.awt.Stroke stroke12 = dateAxis1.getAxisLineStroke();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long4 = segmentedTimeline3.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long10 = segmentedTimeline9.getSegmentsExcludedSize();
        java.util.Date date12 = segmentedTimeline9.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long17 = segmentedTimeline16.getSegmentsExcludedSize();
        java.util.Date date19 = segmentedTimeline16.getDate((long) 7);
        boolean boolean20 = segmentedTimeline5.containsDomainRange(date12, date19);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline3.getSegment(date19);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment24 = segment21.intersect((long) 'a', (long) 12);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline28 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long29 = segmentedTimeline28.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline30 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline34 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long35 = segmentedTimeline34.getSegmentsExcludedSize();
        java.util.Date date37 = segmentedTimeline34.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline41 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long42 = segmentedTimeline41.getSegmentsExcludedSize();
        java.util.Date date44 = segmentedTimeline41.getDate((long) 7);
        boolean boolean45 = segmentedTimeline30.containsDomainRange(date37, date44);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment46 = segmentedTimeline28.getSegment(date44);
        segment46.dec();
        boolean boolean48 = segment21.before(segment46);
        boolean boolean49 = segment21.inExcludeSegments();
        segment21.inc((long) '4');
        segment21.dec();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-4L) + "'", long4 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-4L) + "'", long10 == (-4L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-4L) + "'", long17 == (-4L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(segment21);
        org.junit.Assert.assertNull(segment24);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-4L) + "'", long29 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline30);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-4L) + "'", long35 == (-4L));
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-4L) + "'", long42 == (-4L));
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(segment46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("TextAnchor.BOTTOM_CENTER");
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("orange");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot6.setBaseSectionPaint(paint7);
        java.awt.Font font9 = piePlot6.getLabelFont();
        boolean boolean10 = piePlot6.isSubplot();
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot6);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean13 = numberAxis5.equals((java.lang.Object) color12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer14);
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str17 = layer16.toString();
        java.util.Collection collection18 = xYPlot15.getDomainMarkers(layer16);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke20 = defaultDrawingSupplier19.getNextOutlineStroke();
        java.awt.Shape shape21 = defaultDrawingSupplier19.getNextShape();
        java.lang.Object obj22 = defaultDrawingSupplier19.clone();
        java.awt.Stroke stroke23 = defaultDrawingSupplier19.getNextOutlineStroke();
        xYPlot15.setDomainCrosshairStroke(stroke23);
        org.jfree.chart.axis.AxisCollection axisCollection26 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone28 = dateAxis27.getTimeZone();
        dateAxis27.setInverted(false);
        dateAxis27.resizeRange((double) (byte) 10, (double) (byte) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection26.add((org.jfree.chart.axis.Axis) dateAxis27, rectangleEdge34);
        double double36 = dateAxis27.getFixedDimension();
        xYPlot15.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis27);
        java.awt.Paint paint39 = null;
        try {
            xYPlot15.setQuadrantPaint((-49088), paint39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Layer.FOREGROUND" + "'", str17.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1, (double) 60000L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("orange");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot6.setBaseSectionPaint(paint7);
        java.awt.Font font9 = piePlot6.getLabelFont();
        boolean boolean10 = piePlot6.isSubplot();
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot6);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean13 = numberAxis5.equals((java.lang.Object) color12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer14);
        xYPlot15.setRangeCrosshairVisible(false);
        java.awt.Paint paint18 = null;
        try {
            xYPlot15.setNoDataMessagePaint(paint18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        outlierListCollection0.setHighFarOut(true);
        outlierListCollection0.setLowFarOut(true);
        boolean boolean5 = outlierListCollection0.isLowFarOut();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis1);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            double double6 = dateAxis1.valueToJava2D((double) (-253), rectangle2D4, rectangleEdge5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint1 = ganttRenderer0.getIncompletePaint();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = ganttRenderer0.getGradientPaintTransformer();
        ganttRenderer0.setMaximumBarWidth((double) 15);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long6 = segmentedTimeline5.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline11 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long12 = segmentedTimeline11.getSegmentsExcludedSize();
        java.util.Date date14 = segmentedTimeline11.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline18 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long19 = segmentedTimeline18.getSegmentsExcludedSize();
        java.util.Date date21 = segmentedTimeline18.getDate((long) 7);
        boolean boolean22 = segmentedTimeline7.containsDomainRange(date14, date21);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment23 = segmentedTimeline5.getSegment(date21);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment26 = segment23.intersect((long) 'a', (long) 12);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline30 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long31 = segmentedTimeline30.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline32 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline36 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long37 = segmentedTimeline36.getSegmentsExcludedSize();
        java.util.Date date39 = segmentedTimeline36.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline43 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long44 = segmentedTimeline43.getSegmentsExcludedSize();
        java.util.Date date46 = segmentedTimeline43.getDate((long) 7);
        boolean boolean47 = segmentedTimeline32.containsDomainRange(date39, date46);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment48 = segmentedTimeline30.getSegment(date46);
        segment48.dec();
        boolean boolean50 = segment23.before(segment48);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment51 = segment23.copy();
        defaultCategoryDataset0.removeColumn((java.lang.Comparable) segment23);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-4L) + "'", long6 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-4L) + "'", long12 == (-4L));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-4L) + "'", long19 == (-4L));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(segment23);
        org.junit.Assert.assertNull(segment26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-4L) + "'", long31 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-4L) + "'", long37 == (-4L));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-4L) + "'", long44 == (-4L));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(segment48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(segment51);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor2 = itemLabelPosition1.getTextAnchor();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor4 = categoryLabelPosition3.getRotationAnchor();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor2, textAnchor4, (double) 1563303599999L);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setBaseShapesFilled(false);
        statisticalLineAndShapeRenderer0.setBaseShapesFilled(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalLineAndShapeRenderer0.setBaseURLGenerator(categoryURLGenerator5);
        statisticalLineAndShapeRenderer0.setBaseShapesFilled(true);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 3, 0.0f, (float) 1L);
        piePlot0.setLegendItemShape(shape4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot0.getLabelGenerator();
        piePlot0.setIgnoreNullValues(true);
        int int13 = piePlot0.getPieIndex();
        piePlot0.setShadowXOffset((double) 6);
        java.awt.Paint paint16 = piePlot0.getNoDataMessagePaint();
        java.awt.Paint paint17 = piePlot0.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = piePlot0.getInsets();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets18.createOutsetRectangle(rectangle2D19, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = levelRenderer0.getNegativeItemLabelPosition(12, (-49088));
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        java.lang.String str8 = dateAxis6.getLabel();
        dateAxis6.setNegativeArrowVisible(false);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        levelRenderer0.drawRangeGridline(graphics2D4, categoryPlot5, (org.jfree.chart.axis.ValueAxis) dateAxis6, rectangle2D11, (double) 4L);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = piePlot3D1.getLegendLabelGenerator();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("orange");
        float float2 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.resizeRange((double) 8, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color2 = java.awt.Color.getColor("hi!", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) 10, range1, lengthConstraintType2, (double) (byte) 1, range4, lengthConstraintType5);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint6.toUnconstrainedHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint6.toFixedWidth((double) 255);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint9.toFixedHeight(1.0E-5d);
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = waterfallBarRenderer0.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        double double2 = layeredBarRenderer0.getSeriesBarWidth((-1));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("orange");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot6.setBaseSectionPaint(paint7);
        java.awt.Font font9 = piePlot6.getLabelFont();
        boolean boolean10 = piePlot6.isSubplot();
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot6);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean13 = numberAxis5.equals((java.lang.Object) color12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer14);
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str17 = layer16.toString();
        java.util.Collection collection18 = xYPlot15.getDomainMarkers(layer16);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke20 = defaultDrawingSupplier19.getNextOutlineStroke();
        java.awt.Shape shape21 = defaultDrawingSupplier19.getNextShape();
        java.lang.Object obj22 = defaultDrawingSupplier19.clone();
        java.awt.Stroke stroke23 = defaultDrawingSupplier19.getNextOutlineStroke();
        xYPlot15.setDomainCrosshairStroke(stroke23);
        org.jfree.chart.axis.AxisCollection axisCollection26 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone28 = dateAxis27.getTimeZone();
        dateAxis27.setInverted(false);
        dateAxis27.resizeRange((double) (byte) 10, (double) (byte) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection26.add((org.jfree.chart.axis.Axis) dateAxis27, rectangleEdge34);
        double double36 = dateAxis27.getFixedDimension();
        xYPlot15.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis27);
        org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot15.getDomainAxis(255);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Layer.FOREGROUND" + "'", str17.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNull(valueAxis39);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color2);
        java.lang.String str5 = categoryAxis3D0.getCategoryLabelToolTip((java.lang.Comparable) 4.0d);
        categoryAxis3D0.configure();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            double double12 = categoryAxis3D0.getCategoryJava2DCoordinate(categoryAnchor7, (int) (byte) 100, 1900, rectangle2D10, rectangleEdge11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(categoryAnchor7);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = dateAxis1.getStandardTickUnits();
        double double4 = dateAxis1.getUpperBound();
        boolean boolean5 = dateAxis1.isTickLabelsVisible();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        dateAxis1.setTickMarkPaint((java.awt.Paint) color6);
        piePlot3D0.setLabelLinkPaint((java.awt.Paint) color6);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot3D0.getLabelGenerator();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        double double3 = dateAxis0.getUpperBound();
        boolean boolean4 = dateAxis0.isTickLabelsVisible();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        dateAxis0.setTickMarkPaint((java.awt.Paint) color5);
        dateAxis0.setPositiveArrowVisible(false);
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range10 = null;
        org.jfree.data.Range range11 = org.jfree.data.Range.combine(range9, range10);
        double double12 = range9.getLowerBound();
        dateAxis0.setRangeWithMargins(range9);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        stackedBarRenderer3D1.setBaseToolTipGenerator(categoryToolTipGenerator4);
        stackedBarRenderer3D1.setItemMargin((-1.0d));
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        stackedBarRenderer3D1.setBaseOutlinePaint((java.awt.Paint) color8, false);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(0.25d, (java.awt.Paint) color8, stroke11);
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot14.setBaseSectionPaint(paint15);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape18, (double) 3, 0.0f, (float) 1L);
        piePlot14.setLegendItemShape(shape18);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D25.setBase((double) 1.0f);
        java.lang.Boolean boolean29 = stackedBarRenderer3D25.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font32 = stackedBarRenderer3D25.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine33 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font32);
        piePlot14.setLabelFont(font32);
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot35.setBaseSectionPaint(paint36);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape39, (double) 3, 0.0f, (float) 1L);
        piePlot35.setLegendItemShape(shape39);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D46 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D46.setBase((double) 1.0f);
        java.lang.Boolean boolean50 = stackedBarRenderer3D46.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font53 = stackedBarRenderer3D46.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine54 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font53);
        piePlot35.setLabelFont(font53);
        java.awt.Color color56 = org.jfree.chart.ChartColor.LIGHT_RED;
        piePlot35.setNoDataMessagePaint((java.awt.Paint) color56);
        org.jfree.chart.block.LabelBlock labelBlock58 = new org.jfree.chart.block.LabelBlock("orange", font32, (java.awt.Paint) color56);
        java.awt.Paint paint59 = labelBlock58.getPaint();
        valueMarker12.setLabelPaint(paint59);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(boolean29);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNull(boolean50);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(paint59);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight(9);
        categoryPlot0.clearRangeMarkers(9);
        double double5 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        int int1 = groupedStackedBarRenderer0.getPassCount();
        java.awt.Stroke stroke3 = groupedStackedBarRenderer0.getSeriesOutlineStroke((int) (byte) 10);
        double double4 = groupedStackedBarRenderer0.getItemMargin();
        groupedStackedBarRenderer0.setBaseSeriesVisibleInLegend(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 3, 0.0f, (float) 1L);
        piePlot0.setLegendItemShape(shape4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D11.setBase((double) 1.0f);
        java.lang.Boolean boolean15 = stackedBarRenderer3D11.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font18 = stackedBarRenderer3D11.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine19 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font18);
        piePlot0.setLabelFont(font18);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_RED;
        piePlot0.setNoDataMessagePaint((java.awt.Paint) color21);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = textTitle24.getTextAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = textTitle24.getTextAlignment();
        boolean boolean27 = textTitle24.getNotify();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D29 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D29.setBase((double) 1.0f);
        java.awt.Font font32 = stackedBarRenderer3D29.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot33 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot33.setBaseSectionPaint(paint34);
        java.awt.Font font36 = piePlot33.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font32, (org.jfree.chart.plot.Plot) piePlot33, false);
        java.awt.Paint paint39 = jFreeChart38.getBorderPaint();
        boolean boolean40 = jFreeChart38.isBorderVisible();
        textTitle24.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart38);
        piePlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart38);
        double double43 = piePlot0.getMaximumLabelWidth();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertNotNull(horizontalAlignment26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.2d + "'", double43 == 0.2d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItem legendItem1 = null;
        legendItemCollection0.add(legendItem1);
        java.util.Iterator iterator3 = legendItemCollection0.iterator();
        java.awt.Shape shape9 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke12 = piePlot11.getLabelOutlineStroke();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer14 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        minMaxCategoryRenderer14.setBaseFillPaint(paint15);
        piePlot11.setSectionOutlinePaint((java.lang.Comparable) 0.2d, paint15);
        java.awt.Color color18 = java.awt.Color.LIGHT_GRAY;
        piePlot11.setShadowPaint((java.awt.Paint) color18);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D21.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = null;
        stackedBarRenderer3D21.setBaseToolTipGenerator(categoryToolTipGenerator24);
        stackedBarRenderer3D21.setItemMargin((-1.0d));
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        stackedBarRenderer3D21.setBaseOutlinePaint((java.awt.Paint) color28, false);
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot31.setBaseSectionPaint(paint32);
        java.awt.Font font34 = piePlot31.getLabelFont();
        boolean boolean35 = piePlot31.isSubplot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D36 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D36.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator39 = null;
        stackedBarRenderer3D36.setBaseToolTipGenerator(categoryToolTipGenerator39);
        stackedBarRenderer3D36.setItemMargin((-1.0d));
        java.awt.Stroke stroke44 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D36.setSeriesOutlineStroke(3, stroke44, true);
        piePlot31.setOutlineStroke(stroke44);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("orange");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D51 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D51.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator54 = null;
        stackedBarRenderer3D51.setBaseToolTipGenerator(categoryToolTipGenerator54);
        stackedBarRenderer3D51.setItemMargin((-1.0d));
        boolean boolean58 = stackedBarRenderer3D51.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape60 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape64 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape60, (double) 100L, (float) 0, (float) 10L);
        stackedBarRenderer3D51.setBaseShape(shape64, true);
        dateAxis50.setDownArrow(shape64);
        org.jfree.chart.plot.PiePlot piePlot68 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke69 = piePlot68.getLabelOutlineStroke();
        java.awt.Color color70 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem71 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", true, shape9, true, (java.awt.Paint) color18, false, (java.awt.Paint) color28, stroke44, true, shape64, stroke69, (java.awt.Paint) color70);
        legendItem71.setSeriesKey((java.lang.Comparable) "JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\n");
        java.lang.String str74 = legendItem71.getLabel();
        legendItemCollection0.add(legendItem71);
        java.awt.Stroke stroke76 = legendItem71.getOutlineStroke();
        int int77 = legendItem71.getDatasetIndex();
        org.junit.Assert.assertNotNull(iterator3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "" + "'", str74.equals(""));
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.String str1 = multiplePiePlot0.getPlotType();
        multiplePiePlot0.setLimit((double) 1561964399999L);
        java.lang.Comparable comparable4 = multiplePiePlot0.getAggregatedItemsKey();
        try {
            multiplePiePlot0.setBackgroundImageAlpha((float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Multiple Pie Plot" + "'", str1.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "Other" + "'", comparable4.equals("Other"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        stackedBarRenderer3D0.setItemMargin((-1.0d));
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D0.setSeriesOutlineStroke(3, stroke8, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = null;
        stackedBarRenderer3D0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator11);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = null;
        stackedBarRenderer3D0.setGradientPaintTransformer(gradientPaintTransformer13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        stackedBarRenderer3D0.setBaseURLGenerator(categoryURLGenerator15, true);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        boolean boolean19 = stackedBarRenderer3D0.equals((java.lang.Object) color18);
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D0);
        boolean boolean21 = legendTitle20.getNotify();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        double double3 = rectangleInsets1.calculateLeftInset((double) 1561964399999L);
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets1.getUnitType();
        java.lang.String str5 = rectangleInsets1.toString();
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str5.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long9 = segmentedTimeline8.getSegmentsExcludedSize();
        java.util.Date date11 = segmentedTimeline8.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline15 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long16 = segmentedTimeline15.getSegmentsExcludedSize();
        java.util.Date date18 = segmentedTimeline15.getDate((long) 7);
        boolean boolean19 = segmentedTimeline4.containsDomainRange(date11, date18);
        java.lang.Number number20 = defaultBoxAndWhiskerCategoryDataset0.getMaxRegularValue((java.lang.Comparable) ' ', (java.lang.Comparable) date11);
        java.lang.Number number23 = defaultBoxAndWhiskerCategoryDataset0.getQ3Value((java.lang.Comparable) 8.0d, (java.lang.Comparable) 6);
        double double25 = defaultBoxAndWhiskerCategoryDataset0.getRangeUpperBound(false);
        try {
            java.lang.Number number28 = defaultBoxAndWhiskerCategoryDataset0.getValue(0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-4L) + "'", long9 == (-4L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-4L) + "'", long16 == (-4L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 9, (double) (short) 100);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range7 = defaultBoxAndWhiskerCategoryDataset5.getRangeBounds(false);
        java.lang.Comparable comparable8 = null;
        java.lang.Number number10 = defaultBoxAndWhiskerCategoryDataset5.getMaxOutlier(comparable8, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str14 = spreadsheetDate13.getDescription();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset5, (java.lang.Comparable) str14);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset16 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list17 = defaultStatisticalCategoryDataset16.getColumnKeys();
        defaultStatisticalCategoryDataset16.add((java.lang.Number) (-1L), (java.lang.Number) 100.0d, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 0.0f);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset16);
        java.lang.Comparable comparable24 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer25 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset16, comparable24);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font4, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Paint paint11 = jFreeChart10.getBorderPaint();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart10.addProgressListener(chartProgressListener13);
        jFreeChart10.fireChartChanged();
        try {
            org.jfree.chart.title.Title title17 = jFreeChart10.getSubtitle(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        categoryPlot0.setRangeCrosshairValue(Double.NaN, true);
        categoryPlot0.setAnchorValue(0.0d);
        categoryPlot0.clearDomainMarkers((-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean10 = categoryPlot9.isDomainGridlinesVisible();
        java.awt.Paint paint11 = categoryPlot9.getRangeGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot9.setRenderer(categoryItemRenderer12);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot9.getDomainAxis();
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot15.setBaseSectionPaint(paint16);
        java.awt.Font font18 = piePlot15.getLabelFont();
        boolean boolean19 = piePlot15.isSubplot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D20 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D20.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = null;
        stackedBarRenderer3D20.setBaseToolTipGenerator(categoryToolTipGenerator23);
        stackedBarRenderer3D20.setItemMargin((-1.0d));
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D20.setSeriesOutlineStroke(3, stroke28, true);
        piePlot15.setOutlineStroke(stroke28);
        categoryPlot9.setRangeGridlineStroke(stroke28);
        categoryPlot0.setRangeCrosshairStroke(stroke28);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryAxis14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint1 = ganttRenderer0.getIncompletePaint();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = ganttRenderer0.getGradientPaintTransformer();
        java.lang.Class<?> wildcardClass3 = gradientPaintTransformer2.getClass();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, dataset1, (java.lang.Comparable) 6);
        flowArrangement0.clear();
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getRowKeys();
        keyedObjects2D0.removeColumn((java.lang.Comparable) 0.05d);
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("orange");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot6.setBaseSectionPaint(paint7);
        java.awt.Font font9 = piePlot6.getLabelFont();
        boolean boolean10 = piePlot6.isSubplot();
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot6);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean13 = numberAxis5.equals((java.lang.Object) color12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer14);
        java.awt.Shape shape21 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke24 = piePlot23.getLabelOutlineStroke();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer26 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint27 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        minMaxCategoryRenderer26.setBaseFillPaint(paint27);
        piePlot23.setSectionOutlinePaint((java.lang.Comparable) 0.2d, paint27);
        java.awt.Color color30 = java.awt.Color.LIGHT_GRAY;
        piePlot23.setShadowPaint((java.awt.Paint) color30);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D33.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator36 = null;
        stackedBarRenderer3D33.setBaseToolTipGenerator(categoryToolTipGenerator36);
        stackedBarRenderer3D33.setItemMargin((-1.0d));
        java.awt.Color color40 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        stackedBarRenderer3D33.setBaseOutlinePaint((java.awt.Paint) color40, false);
        org.jfree.chart.plot.PiePlot piePlot43 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint44 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot43.setBaseSectionPaint(paint44);
        java.awt.Font font46 = piePlot43.getLabelFont();
        boolean boolean47 = piePlot43.isSubplot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D48 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D48.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator51 = null;
        stackedBarRenderer3D48.setBaseToolTipGenerator(categoryToolTipGenerator51);
        stackedBarRenderer3D48.setItemMargin((-1.0d));
        java.awt.Stroke stroke56 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D48.setSeriesOutlineStroke(3, stroke56, true);
        piePlot43.setOutlineStroke(stroke56);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("orange");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D63 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D63.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator66 = null;
        stackedBarRenderer3D63.setBaseToolTipGenerator(categoryToolTipGenerator66);
        stackedBarRenderer3D63.setItemMargin((-1.0d));
        boolean boolean70 = stackedBarRenderer3D63.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape72 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape76 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape72, (double) 100L, (float) 0, (float) 10L);
        stackedBarRenderer3D63.setBaseShape(shape76, true);
        dateAxis62.setDownArrow(shape76);
        org.jfree.chart.plot.PiePlot piePlot80 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke81 = piePlot80.getLabelOutlineStroke();
        java.awt.Color color82 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem83 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", true, shape21, true, (java.awt.Paint) color30, false, (java.awt.Paint) color40, stroke56, true, shape76, stroke81, (java.awt.Paint) color82);
        xYPlot15.setRangeZeroBaselineStroke(stroke56);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(shape72);
        org.junit.Assert.assertNotNull(shape76);
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertNotNull(color82);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setSeriesShapesVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean4 = statisticalLineAndShapeRenderer0.getUseFillPaint();
        boolean boolean5 = statisticalLineAndShapeRenderer0.getUseOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getLabelOutlineStroke();
        double double2 = piePlot0.getShadowYOffset();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke2 = piePlot1.getLabelOutlineStroke();
        waterfallBarRenderer0.setBaseOutlineStroke(stroke2);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setBase((double) 1.0f);
        java.lang.Boolean boolean8 = stackedBarRenderer3D4.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font11 = stackedBarRenderer3D4.getItemLabelFont((int) ' ', (int) (short) -1);
        boolean boolean12 = waterfallBarRenderer0.equals((java.lang.Object) (short) -1);
        java.awt.Paint paint13 = waterfallBarRenderer0.getNegativeBarPaint();
        java.awt.Paint paint14 = waterfallBarRenderer0.getLastBarPaint();
        boolean boolean15 = waterfallBarRenderer0.getAutoPopulateSeriesPaint();
        java.awt.Paint paint16 = waterfallBarRenderer0.getLastBarPaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("orange");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot6.setBaseSectionPaint(paint7);
        java.awt.Font font9 = piePlot6.getLabelFont();
        boolean boolean10 = piePlot6.isSubplot();
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot6);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean13 = numberAxis5.equals((java.lang.Object) color12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer14);
        boolean boolean16 = xYPlot15.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.Marker marker17 = null;
        try {
            xYPlot15.addDomainMarker(marker17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        java.awt.Shape shape8 = stackedBarRenderer3D0.getItemShape(1, (int) (short) 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = null;
        stackedBarRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator9);
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke12 = piePlot11.getLabelOutlineStroke();
        stackedBarRenderer3D0.setBaseStroke(stroke12, true);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean18 = categoryPlot17.isDomainGridlinesVisible();
        java.awt.Paint paint19 = categoryPlot17.getRangeGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        categoryPlot17.setRenderer(categoryItemRenderer20);
        categoryPlot17.setRangeCrosshairValue((double) 9, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot17.getDomainAxisEdge((-253));
        categoryPlot17.clearRangeMarkers((-14336));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState31 = stackedBarRenderer3D0.initialise(graphics2D15, rectangle2D16, categoryPlot17, (int) (short) 10, plotRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("hi!");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection4, true);
        taskSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) taskSeriesCollection4);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection8 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = null;
        taskSeriesCollection8.seriesChanged(seriesChangeEvent9);
        taskSeries1.removeChangeListener((org.jfree.data.general.SeriesChangeListener) taskSeriesCollection8);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection12 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str15 = spreadsheetDate14.getDescription();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean17 = spreadsheetDate14.equals((java.lang.Object) categoryLabelPositions16);
        int int18 = taskSeriesCollection12.getColumnIndex((java.lang.Comparable) spreadsheetDate14);
        try {
            java.lang.Number number20 = taskSeriesCollection8.getPercentComplete((java.lang.Comparable) spreadsheetDate14, (java.lang.Comparable) "java.awt.Color[r=128,g=128,b=128]");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font4, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Paint paint11 = jFreeChart10.getBorderPaint();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart10.addProgressListener(chartProgressListener13);
        float float15 = jFreeChart10.getBackgroundImageAlpha();
        jFreeChart10.setBackgroundImageAlpha((float) (byte) 10);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getLabelOutlineStroke();
        float float2 = piePlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5f + "'", float2 == 0.5f);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot1.setBaseSectionPaint(paint2);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape5, (double) 3, 0.0f, (float) 1L);
        piePlot1.setLegendItemShape(shape5);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D12.setBase((double) 1.0f);
        java.lang.Boolean boolean16 = stackedBarRenderer3D12.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font19 = stackedBarRenderer3D12.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font19);
        piePlot1.setLabelFont(font19);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("LegendItemEntity: seriesKey=null, dataset=null", font19);
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker((double) 2, (double) (byte) 100);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D26.setBase((double) 1.0f);
        java.awt.Paint paint29 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D26.setBaseItemLabelPaint(paint29, true);
        java.awt.Shape shape34 = stackedBarRenderer3D26.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity35 = new org.jfree.chart.entity.LegendItemEntity(shape34);
        java.awt.Shape shape36 = legendItemEntity35.getArea();
        java.lang.Comparable comparable37 = legendItemEntity35.getSeriesKey();
        boolean boolean38 = intervalMarker25.equals((java.lang.Object) comparable37);
        intervalMarker25.setStartValue(0.4d);
        java.awt.Font font41 = intervalMarker25.getLabelFont();
        textTitle22.setFont(font41);
        java.awt.Paint paint43 = null;
        textTitle22.setBackgroundPaint(paint43);
        boolean boolean45 = textTitle22.getNotify();
        java.awt.Paint paint46 = textTitle22.getPaint();
        org.jfree.chart.util.VerticalAlignment verticalAlignment47 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        textTitle22.setVerticalAlignment(verticalAlignment47);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(comparable37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(verticalAlignment47);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight(9);
        categoryPlot0.clearRangeMarkers(9);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            categoryPlot0.drawBackground(graphics2D5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D4.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color6);
        java.awt.Paint paint9 = categoryAxis3D4.getTickLabelPaint((java.lang.Comparable) 11);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset10 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range12 = defaultBoxAndWhiskerCategoryDataset10.getRangeBounds(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline14 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline18 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long19 = segmentedTimeline18.getSegmentsExcludedSize();
        java.util.Date date21 = segmentedTimeline18.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline25 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long26 = segmentedTimeline25.getSegmentsExcludedSize();
        java.util.Date date28 = segmentedTimeline25.getDate((long) 7);
        boolean boolean29 = segmentedTimeline14.containsDomainRange(date21, date28);
        java.lang.Number number30 = defaultBoxAndWhiskerCategoryDataset10.getMaxRegularValue((java.lang.Comparable) ' ', (java.lang.Comparable) date21);
        java.lang.Class class31 = null;
        java.util.Date date32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone34 = dateAxis33.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date32, timeZone34);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone34;
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date21, timeZone34);
        categoryAxis3D4.addCategoryLabelToolTip((java.lang.Comparable) month37, "");
        java.util.Date date40 = month37.getStart();
        try {
            java.lang.Number number42 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) ' ', (java.lang.Comparable) date40, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(segmentedTimeline14);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-4L) + "'", long19 == (-4L));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-4L) + "'", long26 == (-4L));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date40);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        double double3 = dateAxis0.getUpperBound();
        boolean boolean4 = dateAxis0.isTickLabelsVisible();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        dateAxis0.setTickMarkPaint((java.awt.Paint) color5);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        dateAxis0.setStandardTickUnits(tickUnitSource7);
        java.awt.Shape shape9 = dateAxis0.getLeftArrow();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        double double3 = rectangleInsets1.calculateLeftInset((double) 1561964399999L);
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets1.getUnitType();
        double double6 = rectangleInsets1.calculateLeftInset((double) 100.0f);
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection2 = waferMapPlot1.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("LegendItemEntity: seriesKey=null, dataset=null");
        boolean boolean3 = textFragment1.equals((java.lang.Object) "hi!");
        float float4 = textFragment1.getBaselineOffset();
        java.lang.String str5 = textFragment1.getText();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str5.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (-5280));
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 9, (double) (short) 100);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range7 = defaultBoxAndWhiskerCategoryDataset5.getRangeBounds(false);
        java.lang.Comparable comparable8 = null;
        java.lang.Number number10 = defaultBoxAndWhiskerCategoryDataset5.getMaxOutlier(comparable8, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str14 = spreadsheetDate13.getDescription();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset5, (java.lang.Comparable) str14);
        java.lang.Object obj16 = legendItemBlockContainer15.clone();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        java.awt.Shape shape8 = stackedBarRenderer3D0.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        java.awt.Shape shape10 = legendItemEntity9.getArea();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity11 = new org.jfree.chart.entity.LegendItemEntity(shape10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.util.Date date13 = month12.getStart();
        boolean boolean14 = legendItemEntity11.equals((java.lang.Object) date13);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment15, verticalAlignment16, (double) 9, (double) (short) 100);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset20 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range22 = defaultBoxAndWhiskerCategoryDataset20.getRangeBounds(false);
        java.lang.Comparable comparable23 = null;
        java.lang.Number number25 = defaultBoxAndWhiskerCategoryDataset20.getMaxOutlier(comparable23, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str29 = spreadsheetDate28.getDescription();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer30 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement19, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset20, (java.lang.Comparable) str29);
        legendItemBlockContainer30.setHeight((double) 500);
        org.jfree.data.general.Dataset dataset33 = legendItemBlockContainer30.getDataset();
        java.lang.String str34 = legendItemBlockContainer30.getToolTipText();
        boolean boolean35 = legendItemEntity11.equals((java.lang.Object) str34);
        java.lang.String str36 = legendItemEntity11.toString();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(dataset33);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str36.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setMaximumItemWidth((double) 1900);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean7 = categoryPlot6.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D8.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color10);
        java.awt.Paint paint13 = categoryAxis3D8.getTickLabelPaint((java.lang.Comparable) 11);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset14 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range16 = defaultBoxAndWhiskerCategoryDataset14.getRangeBounds(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline18 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline22 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long23 = segmentedTimeline22.getSegmentsExcludedSize();
        java.util.Date date25 = segmentedTimeline22.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline29 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long30 = segmentedTimeline29.getSegmentsExcludedSize();
        java.util.Date date32 = segmentedTimeline29.getDate((long) 7);
        boolean boolean33 = segmentedTimeline18.containsDomainRange(date25, date32);
        java.lang.Number number34 = defaultBoxAndWhiskerCategoryDataset14.getMaxRegularValue((java.lang.Comparable) ' ', (java.lang.Comparable) date25);
        java.lang.Class class35 = null;
        java.util.Date date36 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone38 = dateAxis37.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date36, timeZone38);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone38;
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date25, timeZone38);
        categoryAxis3D8.addCategoryLabelToolTip((java.lang.Comparable) month41, "");
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("orange");
        float float47 = dateAxis46.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot50 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint51 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot50.setBaseSectionPaint(paint51);
        java.awt.Font font53 = piePlot50.getLabelFont();
        boolean boolean54 = piePlot50.isSubplot();
        numberAxis49.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot50);
        java.awt.Color color56 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean57 = numberAxis49.equals((java.lang.Object) color56);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer58 = null;
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot(xYDataset44, (org.jfree.chart.axis.ValueAxis) dateAxis46, (org.jfree.chart.axis.ValueAxis) numberAxis49, xYItemRenderer58);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset60 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            levelRenderer0.drawItem(graphics2D3, categoryItemRendererState4, rectangle2D5, categoryPlot6, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D8, (org.jfree.chart.axis.ValueAxis) numberAxis49, (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset60, 500, (int) ' ', (-14336));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(segmentedTimeline18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-4L) + "'", long23 == (-4L));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-4L) + "'", long30 == (-4L));
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 2.0f + "'", float47 == 2.0f);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        boolean boolean3 = dateAxis0.isAxisLineVisible();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        java.awt.Color color0 = java.awt.Color.BLACK;
        int int1 = color0.getTransparency();
        java.awt.Color color2 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        java.awt.Shape shape8 = stackedBarRenderer3D0.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset12 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range14 = defaultBoxAndWhiskerCategoryDataset12.getRangeBounds(false);
        java.lang.Comparable comparable15 = null;
        java.lang.Number number17 = defaultBoxAndWhiskerCategoryDataset12.getMaxOutlier(comparable15, (java.lang.Comparable) (short) 0);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity20 = new org.jfree.chart.entity.CategoryItemEntity(shape8, "DateTickMarkPosition.END", "TextBlockAnchor.CENTER_RIGHT", (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset12, (java.lang.Comparable) (short) 1, (java.lang.Comparable) "RangeType.NEGATIVE");
        java.lang.Comparable comparable21 = categoryItemEntity20.getRowKey();
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryItemEntity20.getDataset();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset23 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list24 = defaultStatisticalCategoryDataset23.getColumnKeys();
        categoryItemEntity20.setDataset((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset23);
        java.lang.Number number26 = null;
        java.lang.Comparable comparable28 = null;
        defaultStatisticalCategoryDataset23.add(number26, (java.lang.Number) 1.0f, comparable28, (java.lang.Comparable) 1561964399999L);
        double double32 = defaultStatisticalCategoryDataset23.getRangeUpperBound(false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + (short) 1 + "'", comparable21.equals((short) 1));
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test356");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo0.setLicenceText("");
//        java.lang.String str3 = projectInfo0.getVersion();
//        org.jfree.chart.ui.Library[] libraryArray4 = projectInfo0.getOptionalLibraries();
//        java.lang.String str5 = projectInfo0.getVersion();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DateTickMarkPosition.END" + "'", str3.equals("DateTickMarkPosition.END"));
//        org.junit.Assert.assertNotNull(libraryArray4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTickMarkPosition.END" + "'", str5.equals("DateTickMarkPosition.END"));
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        double double3 = rectangleInsets1.extendWidth(0.0d);
        double double5 = rectangleInsets1.calculateBottomOutset((double) 192);
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long5 = segmentedTimeline4.getSegmentsExcludedSize();
        java.util.Date date7 = segmentedTimeline4.getDate((long) 7);
        boolean boolean8 = segmentedTimeline0.containsDomainValue(date7);
        org.jfree.data.KeyedObjects2D keyedObjects2D9 = new org.jfree.data.KeyedObjects2D();
        java.util.List list10 = keyedObjects2D9.getRowKeys();
        segmentedTimeline0.addExceptions(list10);
        long long12 = segmentedTimeline0.getSegmentSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-4L) + "'", long5 == (-4L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 900000L + "'", long12 == 900000L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), (double) (byte) 1, true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 2, (double) (byte) 100);
        double double3 = intervalMarker2.getEndValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("June 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        double double3 = dateAxis0.getUpperBound();
        boolean boolean4 = dateAxis0.isTickLabelsVisible();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = null;
        dateAxis0.setTickUnit(dateTickUnit5, true, false);
        java.lang.Object obj9 = dateAxis0.clone();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setBaseShapesFilled(false);
        try {
            statisticalLineAndShapeRenderer0.setSeriesLinesVisible((-253), (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D7.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        stackedBarRenderer3D7.setBaseToolTipGenerator(categoryToolTipGenerator10);
        stackedBarRenderer3D7.setItemMargin((-1.0d));
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D7.setSeriesOutlineStroke(3, stroke15, true);
        stackedBarRenderer3D4.setBaseOutlineStroke(stroke15, true);
        int int20 = month3.compareTo((java.lang.Object) stackedBarRenderer3D4);
        java.awt.Paint paint23 = stackedBarRenderer3D4.getItemPaint(4, 7);
        org.jfree.chart.text.TextFragment textFragment25 = new org.jfree.chart.text.TextFragment("1.0.6", font2, paint23, (float) (short) -1);
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot26.setBaseSectionPaint(paint27);
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape34 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape30, (double) 3, 0.0f, (float) 1L);
        piePlot26.setLegendItemShape(shape30);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator36 = piePlot26.getLabelGenerator();
        piePlot26.setIgnoreNullValues(true);
        int int39 = piePlot26.getPieIndex();
        piePlot26.setShadowXOffset((double) 6);
        java.lang.Object obj42 = piePlot26.clone();
        java.awt.Color color44 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        piePlot26.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color44);
        org.jfree.chart.axis.AxisCollection axisCollection46 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone48 = dateAxis47.getTimeZone();
        dateAxis47.setInverted(false);
        dateAxis47.resizeRange((double) (byte) 10, (double) (byte) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection46.add((org.jfree.chart.axis.Axis) dateAxis47, rectangleEdge54);
        org.jfree.chart.title.TextTitle textTitle57 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment58 = textTitle57.getTextAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment59 = textTitle57.getTextAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment60 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment61 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement64 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment60, verticalAlignment61, (double) 9, (double) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle66 = new org.jfree.chart.title.TextTitle("CategoryLabelWidthType.CATEGORY", font2, (java.awt.Paint) color44, rectangleEdge54, horizontalAlignment59, verticalAlignment61, rectangleInsets65);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'spacer' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNotNull(horizontalAlignment58);
        org.junit.Assert.assertNotNull(horizontalAlignment59);
        org.junit.Assert.assertNotNull(verticalAlignment61);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        int int3 = taskSeriesCollection0.getSeriesCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("orange");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot6.setBaseSectionPaint(paint7);
        java.awt.Font font9 = piePlot6.getLabelFont();
        boolean boolean10 = piePlot6.isSubplot();
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot6);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean13 = numberAxis5.equals((java.lang.Object) color12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer14);
        boolean boolean16 = xYPlot15.isRangeCrosshairLockedOnData();
        xYPlot15.mapDatasetToRangeAxis(6, (int) (short) 10);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        xYPlot15.setDataset(7, xYDataset21);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        double double1 = levelRenderer0.getMaximumItemWidth();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot6.setBaseSectionPaint(paint7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape10, (double) 3, 0.0f, (float) 1L);
        piePlot6.setLegendItemShape(shape10);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D17.setBase((double) 1.0f);
        java.lang.Boolean boolean21 = stackedBarRenderer3D17.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font24 = stackedBarRenderer3D17.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine25 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font24);
        piePlot6.setLabelFont(font24);
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("LegendItemEntity: seriesKey=null, dataset=null", font24);
        piePlot3D4.setLabelFont(font24);
        levelRenderer0.setSeriesItemLabelFont((int) 'a', font24);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean32 = categoryPlot31.isDomainGridlinesVisible();
        java.awt.Paint paint33 = categoryPlot31.getRangeGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone35 = dateAxis34.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource36 = dateAxis34.getStandardTickUnits();
        double double37 = dateAxis34.getUpperBound();
        boolean boolean38 = dateAxis34.isTickLabelsVisible();
        org.jfree.chart.plot.Marker marker39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        levelRenderer0.drawRangeMarker(graphics2D30, categoryPlot31, (org.jfree.chart.axis.ValueAxis) dateAxis34, marker39, rectangle2D40);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        try {
            categoryPlot31.handleClick(15, (-253), plotRenderingInfo44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(tickUnitSource36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        stackedBarRenderer3D4.setBaseToolTipGenerator(categoryToolTipGenerator7);
        stackedBarRenderer3D4.setItemMargin((-1.0d));
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D4.setSeriesOutlineStroke(3, stroke12, true);
        stackedBarRenderer3D1.setBaseOutlineStroke(stroke12, true);
        int int17 = month0.compareTo((java.lang.Object) stackedBarRenderer3D1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month0.next();
        long long19 = regularTimePeriod18.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1563303599999L + "'", long19 == 1563303599999L);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color2);
        java.lang.String str5 = categoryAxis3D0.getCategoryLabelToolTip((java.lang.Comparable) 4.0d);
        categoryAxis3D0.configure();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str9 = spreadsheetDate8.getDescription();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean11 = spreadsheetDate8.equals((java.lang.Object) categoryLabelPositions10);
        java.lang.String str12 = categoryAxis3D0.getCategoryLabelToolTip((java.lang.Comparable) boolean11);
        java.awt.Paint paint13 = categoryAxis3D0.getLabelPaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        java.awt.Shape shape8 = stackedBarRenderer3D0.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        java.awt.Shape shape10 = legendItemEntity9.getArea();
        java.lang.Comparable comparable11 = legendItemEntity9.getSeriesKey();
        java.lang.Object obj12 = legendItemEntity9.clone();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(comparable11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        java.lang.String str2 = categoryPlot0.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(192);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Category Plot" + "'", str2.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("orange");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot6.setBaseSectionPaint(paint7);
        java.awt.Font font9 = piePlot6.getLabelFont();
        boolean boolean10 = piePlot6.isSubplot();
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot6);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean13 = numberAxis5.equals((java.lang.Object) color12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer14);
        xYPlot15.setRangeCrosshairVisible(false);
        xYPlot15.setDomainCrosshairValue((double) 6);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        minMaxCategoryRenderer0.setBaseFillPaint(paint1);
        boolean boolean4 = minMaxCategoryRenderer0.isSeriesVisibleInLegend((int) (byte) 100);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D5.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        stackedBarRenderer3D5.setBaseToolTipGenerator(categoryToolTipGenerator8);
        stackedBarRenderer3D5.setItemMargin((-1.0d));
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = stackedBarRenderer3D5.getToolTipGenerator((int) (byte) 0, 0);
        java.awt.Shape shape15 = stackedBarRenderer3D5.getBaseShape();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = null;
        stackedBarRenderer3D5.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator17);
        java.awt.Paint paint19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        stackedBarRenderer3D5.setBaseFillPaint(paint19);
        minMaxCategoryRenderer0.setBaseItemLabelPaint(paint19);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean24 = categoryPlot23.isDomainGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        minMaxCategoryRenderer0.drawRangeGridline(graphics2D22, categoryPlot23, (org.jfree.chart.axis.ValueAxis) numberAxis26, rectangle2D27, (double) 7L);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("orange");
        float float4 = dateAxis3.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot7.setBaseSectionPaint(paint8);
        java.awt.Font font10 = piePlot7.getLabelFont();
        boolean boolean11 = piePlot7.isSubplot();
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot7);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean14 = numberAxis6.equals((java.lang.Object) color13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis6, xYItemRenderer15);
        java.awt.Paint paint17 = xYPlot16.getDomainGridlinePaint();
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str20 = layer19.toString();
        java.util.Collection collection21 = xYPlot16.getRangeMarkers(3, layer19);
        java.util.Collection collection22 = categoryPlot0.getDomainMarkers(layer19);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        boolean boolean27 = categoryPlot0.render(graphics2D23, rectangle2D24, (-460), plotRenderingInfo26);
        org.jfree.chart.block.BlockBorder blockBorder28 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = blockBorder28.getInsets();
        double double31 = rectangleInsets29.extendWidth(0.0d);
        categoryPlot0.setAxisOffset(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Layer.FOREGROUND" + "'", str20.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(blockBorder28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range3 = defaultBoxAndWhiskerCategoryDataset1.getRangeBounds(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long10 = segmentedTimeline9.getSegmentsExcludedSize();
        java.util.Date date12 = segmentedTimeline9.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long17 = segmentedTimeline16.getSegmentsExcludedSize();
        java.util.Date date19 = segmentedTimeline16.getDate((long) 7);
        boolean boolean20 = segmentedTimeline5.containsDomainRange(date12, date19);
        java.lang.Number number21 = defaultBoxAndWhiskerCategoryDataset1.getMaxRegularValue((java.lang.Comparable) ' ', (java.lang.Comparable) date12);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(3, year22);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-4L) + "'", long10 == (-4L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-4L) + "'", long17 == (-4L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(number21);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, false);
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str1 = rectangleEdge0.toString();
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleEdge.LEFT" + "'", str1.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getTextAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle1.getTextAlignment();
        boolean boolean4 = textTitle1.getNotify();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D6.setBase((double) 1.0f);
        java.awt.Font font9 = stackedBarRenderer3D6.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot10.setBaseSectionPaint(paint11);
        java.awt.Font font13 = piePlot10.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font9, (org.jfree.chart.plot.Plot) piePlot10, false);
        java.awt.Paint paint16 = jFreeChart15.getBorderPaint();
        boolean boolean17 = jFreeChart15.isBorderVisible();
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart15);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = textTitle1.getTextAlignment();
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        double double3 = dateAxis0.getUpperBound();
        boolean boolean4 = dateAxis0.isTickLabelsVisible();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        dateAxis0.setTickMarkPaint((java.awt.Paint) color5);
        dateAxis0.setPositiveArrowVisible(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = null;
        try {
            java.util.Date date10 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        boolean boolean2 = stackedAreaRenderer1.getRenderAsPercentages();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getTextAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle1.getTextAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment4, verticalAlignment5, (double) (byte) 100, (double) 10.0f);
        textTitle1.setVerticalAlignment(verticalAlignment5);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(verticalAlignment5);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        org.jfree.data.gantt.Task task2 = null;
        taskSeries1.remove(task2);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.String str1 = multiplePiePlot0.getPlotType();
        multiplePiePlot0.setLimit((double) 1561964399999L);
        java.lang.Comparable comparable4 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation7 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 100.0f, (double) (byte) 10);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset8 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range10 = defaultBoxAndWhiskerCategoryDataset8.getRangeBounds(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long17 = segmentedTimeline16.getSegmentsExcludedSize();
        java.util.Date date19 = segmentedTimeline16.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline23 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long24 = segmentedTimeline23.getSegmentsExcludedSize();
        java.util.Date date26 = segmentedTimeline23.getDate((long) 7);
        boolean boolean27 = segmentedTimeline12.containsDomainRange(date19, date26);
        java.lang.Number number28 = defaultBoxAndWhiskerCategoryDataset8.getMaxRegularValue((java.lang.Comparable) ' ', (java.lang.Comparable) date19);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date19);
        boolean boolean30 = meanAndStandardDeviation7.equals((java.lang.Object) year29);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) year29);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Multiple Pie Plot" + "'", str1.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "Other" + "'", comparable4.equals("Other"));
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-4L) + "'", long17 == (-4L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-4L) + "'", long24 == (-4L));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long4 = segmentedTimeline3.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long9 = segmentedTimeline8.getSegmentsExcludedSize();
        java.util.Date date11 = segmentedTimeline8.getDate((long) 7);
        long long12 = segmentedTimeline3.getTime(date11);
        long long13 = segmentedTimeline3.getSegmentsExcludedSize();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-4L) + "'", long4 == (-4L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-4L) + "'", long9 == (-4L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 7L + "'", long12 == 7L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-4L) + "'", long13 == (-4L));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (-1), 0.0d);
        java.awt.Paint paint3 = intervalMarker2.getOutlinePaint();
        double double4 = intervalMarker2.getStartValue();
        try {
            intervalMarker2.setAlpha(10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        stackedBarRenderer3D4.setBaseToolTipGenerator(categoryToolTipGenerator7);
        stackedBarRenderer3D4.setItemMargin((-1.0d));
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D4.setSeriesOutlineStroke(3, stroke12, true);
        stackedBarRenderer3D1.setBaseOutlineStroke(stroke12, true);
        int int17 = month0.compareTo((java.lang.Object) stackedBarRenderer3D1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month0.next();
        long long19 = month0.getLastMillisecond();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 9, (double) (short) 100);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range7 = defaultBoxAndWhiskerCategoryDataset5.getRangeBounds(false);
        java.lang.Comparable comparable8 = null;
        java.lang.Number number10 = defaultBoxAndWhiskerCategoryDataset5.getMaxOutlier(comparable8, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str14 = spreadsheetDate13.getDescription();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset5, (java.lang.Comparable) str14);
        legendItemBlockContainer15.setHeight((double) 500);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D19.setBase((double) 1.0f);
        java.awt.Font font22 = stackedBarRenderer3D19.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot23.setBaseSectionPaint(paint24);
        java.awt.Font font26 = piePlot23.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font22, (org.jfree.chart.plot.Plot) piePlot23, false);
        java.awt.Paint paint29 = jFreeChart28.getBorderPaint();
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot31.setBaseSectionPaint(paint32);
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape35, (double) 3, 0.0f, (float) 1L);
        piePlot31.setLegendItemShape(shape35);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D42 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D42.setBase((double) 1.0f);
        java.lang.Boolean boolean46 = stackedBarRenderer3D42.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font49 = stackedBarRenderer3D42.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine50 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font49);
        piePlot31.setLabelFont(font49);
        org.jfree.chart.title.TextTitle textTitle52 = new org.jfree.chart.title.TextTitle("LegendItemEntity: seriesKey=null, dataset=null", font49);
        textTitle52.setExpandToFitSpace(false);
        jFreeChart28.addSubtitle((org.jfree.chart.title.Title) textTitle52);
        legendItemBlockContainer15.add((org.jfree.chart.block.Block) textTitle52);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNull(boolean46);
        org.junit.Assert.assertNotNull(font49);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor2 = categoryLabelPosition1.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
        double double4 = categoryLabelPosition1.getAngle();
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font4, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_RED;
        int int12 = color11.getAlpha();
        piePlot5.setBackgroundPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D14.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color16);
        java.awt.color.ColorSpace colorSpace18 = color16.getColorSpace();
        java.awt.Color color19 = java.awt.Color.yellow;
        float[] floatArray23 = new float[] { (byte) -1, 100.0f, 7 };
        float[] floatArray24 = color19.getColorComponents(floatArray23);
        float[] floatArray25 = color11.getColorComponents(colorSpace18, floatArray23);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        stackedBarRenderer3D4.setBaseToolTipGenerator(categoryToolTipGenerator7);
        stackedBarRenderer3D4.setItemMargin((-1.0d));
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D4.setSeriesOutlineStroke(3, stroke12, true);
        stackedBarRenderer3D1.setBaseOutlineStroke(stroke12, true);
        int int17 = month0.compareTo((java.lang.Object) stackedBarRenderer3D1);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = month0.getLastMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.text.NumberFormat numberFormat3 = standardCategoryToolTipGenerator2.getNumberFormat();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat3);
        tickUnits0.add((org.jfree.chart.axis.TickUnit) numberTickUnit4);
        org.jfree.chart.axis.TickUnit tickUnit7 = tickUnits0.getCeilingTickUnit((double) 2.0f);
        double double8 = tickUnit7.getSize();
        org.junit.Assert.assertNotNull(numberFormat3);
        org.junit.Assert.assertNotNull(tickUnit7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Comparable comparable1 = null;
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset2 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range4 = defaultBoxAndWhiskerCategoryDataset2.getRangeBounds(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline10 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long11 = segmentedTimeline10.getSegmentsExcludedSize();
        java.util.Date date13 = segmentedTimeline10.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long18 = segmentedTimeline17.getSegmentsExcludedSize();
        java.util.Date date20 = segmentedTimeline17.getDate((long) 7);
        boolean boolean21 = segmentedTimeline6.containsDomainRange(date13, date20);
        java.lang.Number number22 = defaultBoxAndWhiskerCategoryDataset2.getMaxRegularValue((java.lang.Comparable) ' ', (java.lang.Comparable) date13);
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone26 = dateAxis25.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone26);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone26;
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date13, timeZone26);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date13);
        try {
            defaultCategoryDataset0.removeValue(comparable1, (java.lang.Comparable) serialDate30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-4L) + "'", long11 == (-4L));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-4L) + "'", long18 == (-4L));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(serialDate30);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor2 = categoryLabelPosition1.getRotationAnchor();
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 24234L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str3 = spreadsheetDate2.getDescription();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean5 = spreadsheetDate2.equals((java.lang.Object) categoryLabelPositions4);
        int int6 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) spreadsheetDate2);
        java.lang.Class<?> wildcardClass7 = taskSeriesCollection0.getClass();
        int int8 = taskSeriesCollection0.getRowCount();
        try {
            java.lang.Number number11 = taskSeriesCollection0.getStartValue((int) (short) 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        java.awt.Font font0 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 3, 0.0f, (float) 1L);
        piePlot0.setLegendItemShape(shape4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D11.setBase((double) 1.0f);
        java.lang.Boolean boolean15 = stackedBarRenderer3D11.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font18 = stackedBarRenderer3D11.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine19 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font18);
        piePlot0.setLabelFont(font18);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_RED;
        piePlot0.setNoDataMessagePaint((java.awt.Paint) color21);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = textTitle24.getTextAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = textTitle24.getTextAlignment();
        boolean boolean27 = textTitle24.getNotify();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D29 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D29.setBase((double) 1.0f);
        java.awt.Font font32 = stackedBarRenderer3D29.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot33 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot33.setBaseSectionPaint(paint34);
        java.awt.Font font36 = piePlot33.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font32, (org.jfree.chart.plot.Plot) piePlot33, false);
        java.awt.Paint paint39 = jFreeChart38.getBorderPaint();
        boolean boolean40 = jFreeChart38.isBorderVisible();
        textTitle24.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart38);
        piePlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart38);
        java.awt.Stroke stroke43 = piePlot0.getLabelLinkStroke();
        boolean boolean44 = piePlot0.getIgnoreZeroValues();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertNotNull(horizontalAlignment26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("hi!");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection4, true);
        taskSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) taskSeriesCollection4);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection8 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = null;
        taskSeriesCollection8.seriesChanged(seriesChangeEvent9);
        taskSeries1.removeChangeListener((org.jfree.data.general.SeriesChangeListener) taskSeriesCollection8);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D13.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D16.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = null;
        stackedBarRenderer3D16.setBaseToolTipGenerator(categoryToolTipGenerator19);
        stackedBarRenderer3D16.setItemMargin((-1.0d));
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D16.setSeriesOutlineStroke(3, stroke24, true);
        stackedBarRenderer3D13.setBaseOutlineStroke(stroke24, true);
        int int29 = month12.compareTo((java.lang.Object) stackedBarRenderer3D13);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D34.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator37 = null;
        stackedBarRenderer3D34.setBaseToolTipGenerator(categoryToolTipGenerator37);
        stackedBarRenderer3D34.setItemMargin((-1.0d));
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D34.setSeriesOutlineStroke(3, stroke42, true);
        stackedBarRenderer3D31.setBaseOutlineStroke(stroke42, true);
        int int47 = month30.compareTo((java.lang.Object) stackedBarRenderer3D31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month30.next();
        boolean boolean49 = month12.equals((java.lang.Object) month30);
        int int50 = taskSeriesCollection8.getRowIndex((java.lang.Comparable) boolean49);
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection51 = new org.jfree.chart.renderer.OutlierListCollection();
        outlierListCollection51.setHighFarOut(true);
        outlierListCollection51.setLowFarOut(true);
        boolean boolean56 = taskSeriesCollection8.equals((java.lang.Object) outlierListCollection51);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setUseOutlinePaint(true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D3.setBase((double) 1.0f);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator6 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        stackedBarRenderer3D3.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator6);
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER;
        boolean boolean9 = standardCategorySeriesLabelGenerator6.equals((java.lang.Object) textAnchor8);
        statisticalLineAndShapeRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator6);
        java.lang.Boolean boolean12 = statisticalLineAndShapeRenderer0.getSeriesLinesVisible((int) (short) 1);
        statisticalLineAndShapeRenderer0.setSeriesShapesVisible(1, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(boolean12);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        stackedBarRenderer3D0.setItemMargin((-1.0d));
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D0.setSeriesOutlineStroke(3, stroke8, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = null;
        stackedBarRenderer3D0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator11);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = null;
        stackedBarRenderer3D0.setGradientPaintTransformer(gradientPaintTransformer13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        stackedBarRenderer3D0.setBaseURLGenerator(categoryURLGenerator15, true);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        boolean boolean19 = stackedBarRenderer3D0.equals((java.lang.Object) color18);
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D0);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        legendTitle20.setItemLabelPadding(rectangleInsets21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = legendTitle20.getLegendItemGraphicAnchor();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        categoryPlot0.setRangeCrosshairValue(Double.NaN, true);
        java.awt.Stroke stroke5 = categoryPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(false);
        boolean boolean3 = dateAxis0.isNegativeArrowVisible();
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot4.setBaseSectionPaint(paint5);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot4);
        org.jfree.chart.event.AxisChangeListener axisChangeListener8 = null;
        dateAxis0.removeChangeListener(axisChangeListener8);
        java.awt.Font font10 = dateAxis0.getTickLabelFont();
        double double11 = dateAxis0.getFixedAutoRange();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        categoryPlot0.setRangeCrosshairValue(Double.NaN, true);
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font4, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Paint paint11 = jFreeChart10.getBorderPaint();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart10.addProgressListener(chartProgressListener13);
        jFreeChart10.fireChartChanged();
        org.jfree.chart.title.LegendTitle legendTitle17 = jFreeChart10.getLegend((int) (short) 1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(legendTitle17);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        java.awt.Paint paint0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D0.setSeriesOutlineStroke((int) ' ', stroke6);
        boolean boolean8 = stackedBarRenderer3D0.getAutoPopulateSeriesShape();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getTextAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle1.getTextAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1900, (-1.0d));
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(verticalAlignment4);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.junit.Assert.assertNotNull(dateRange0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font4, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Paint paint11 = jFreeChart10.getBorderPaint();
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot13.setBaseSectionPaint(paint14);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape17, (double) 3, 0.0f, (float) 1L);
        piePlot13.setLegendItemShape(shape17);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D24.setBase((double) 1.0f);
        java.lang.Boolean boolean28 = stackedBarRenderer3D24.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font31 = stackedBarRenderer3D24.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine32 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font31);
        piePlot13.setLabelFont(font31);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("LegendItemEntity: seriesKey=null, dataset=null", font31);
        textTitle34.setExpandToFitSpace(false);
        jFreeChart10.addSubtitle((org.jfree.chart.title.Title) textTitle34);
        textTitle34.setToolTipText("");
        java.lang.Object obj40 = textTitle34.clone();
        java.awt.Paint paint41 = textTitle34.getPaint();
        textTitle34.setText("RectangleEdge.LEFT");
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(boolean28);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        java.awt.Shape shape8 = stackedBarRenderer3D0.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset12 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range14 = defaultBoxAndWhiskerCategoryDataset12.getRangeBounds(false);
        java.lang.Comparable comparable15 = null;
        java.lang.Number number17 = defaultBoxAndWhiskerCategoryDataset12.getMaxOutlier(comparable15, (java.lang.Comparable) (short) 0);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity20 = new org.jfree.chart.entity.CategoryItemEntity(shape8, "DateTickMarkPosition.END", "TextBlockAnchor.CENTER_RIGHT", (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset12, (java.lang.Comparable) (short) 1, (java.lang.Comparable) "RangeType.NEGATIVE");
        java.lang.Comparable comparable21 = categoryItemEntity20.getRowKey();
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryItemEntity20.getDataset();
        org.jfree.data.category.CategoryDataset categoryDataset23 = categoryItemEntity20.getDataset();
        categoryItemEntity20.setURLText("Range[0.0,1.0]");
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + (short) 1 + "'", comparable21.equals((short) 1));
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertNotNull(categoryDataset23);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D2.setBase((double) 1.0f);
        java.awt.Paint paint5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D2.setBaseItemLabelPaint(paint5, true);
        java.awt.Shape shape10 = stackedBarRenderer3D2.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity11 = new org.jfree.chart.entity.LegendItemEntity(shape10);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset14 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range16 = defaultBoxAndWhiskerCategoryDataset14.getRangeBounds(false);
        java.lang.Comparable comparable17 = null;
        java.lang.Number number19 = defaultBoxAndWhiskerCategoryDataset14.getMaxOutlier(comparable17, (java.lang.Comparable) (short) 0);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity22 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "DateTickMarkPosition.END", "TextBlockAnchor.CENTER_RIGHT", (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset14, (java.lang.Comparable) (short) 1, (java.lang.Comparable) "RangeType.NEGATIVE");
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke24 = piePlot23.getLabelOutlineStroke();
        piePlot23.setLabelLinkMargin((double) '#');
        boolean boolean27 = defaultBoxAndWhiskerCategoryDataset14.hasListener((java.util.EventListener) piePlot23);
        piePlot23.setIgnoreZeroValues(false);
        boolean boolean30 = stackedAreaRenderer1.equals((java.lang.Object) false);
        java.awt.Color color31 = java.awt.Color.GRAY;
        stackedAreaRenderer1.setBaseOutlinePaint((java.awt.Paint) color31, true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(number19);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        stackedBarRenderer3D4.setBaseToolTipGenerator(categoryToolTipGenerator7);
        stackedBarRenderer3D4.setItemMargin((-1.0d));
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D4.setSeriesOutlineStroke(3, stroke12, true);
        stackedBarRenderer3D1.setBaseOutlineStroke(stroke12, true);
        int int17 = month0.compareTo((java.lang.Object) stackedBarRenderer3D1);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D19.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D22.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator25 = null;
        stackedBarRenderer3D22.setBaseToolTipGenerator(categoryToolTipGenerator25);
        stackedBarRenderer3D22.setItemMargin((-1.0d));
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D22.setSeriesOutlineStroke(3, stroke30, true);
        stackedBarRenderer3D19.setBaseOutlineStroke(stroke30, true);
        int int35 = month18.compareTo((java.lang.Object) stackedBarRenderer3D19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month18.next();
        boolean boolean37 = month0.equals((java.lang.Object) month18);
        org.jfree.chart.block.BlockBorder blockBorder38 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = blockBorder38.getInsets();
        double double41 = rectangleInsets39.calculateLeftInset((double) 1561964399999L);
        double double42 = rectangleInsets39.getTop();
        int int43 = month18.compareTo((java.lang.Object) rectangleInsets39);
        double double44 = rectangleInsets39.getLeft();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(blockBorder38);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        paintList0.setPaint(15, paint2);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long9 = segmentedTimeline8.getSegmentsExcludedSize();
        java.util.Date date11 = segmentedTimeline8.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline15 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long16 = segmentedTimeline15.getSegmentsExcludedSize();
        java.util.Date date18 = segmentedTimeline15.getDate((long) 7);
        boolean boolean19 = segmentedTimeline4.containsDomainRange(date11, date18);
        long long21 = segmentedTimeline4.getTimeFromLong(10L);
        boolean boolean22 = paintList0.equals((java.lang.Object) long21);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-4L) + "'", long9 == (-4L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-4L) + "'", long16 == (-4L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("orange");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot6.setBaseSectionPaint(paint7);
        java.awt.Font font9 = piePlot6.getLabelFont();
        boolean boolean10 = piePlot6.isSubplot();
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot6);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean13 = numberAxis5.equals((java.lang.Object) color12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer14);
        boolean boolean16 = xYPlot15.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        xYPlot15.setOrientation(plotOrientation17);
        xYPlot15.mapDatasetToRangeAxis(12, 100);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D22.setBase((double) 1.0f);
        java.awt.Paint paint25 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D22.setBaseItemLabelPaint(paint25, true);
        java.awt.Shape shape30 = stackedBarRenderer3D22.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity31 = new org.jfree.chart.entity.LegendItemEntity(shape30);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset34 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range36 = defaultBoxAndWhiskerCategoryDataset34.getRangeBounds(false);
        java.lang.Comparable comparable37 = null;
        java.lang.Number number39 = defaultBoxAndWhiskerCategoryDataset34.getMaxOutlier(comparable37, (java.lang.Comparable) (short) 0);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity42 = new org.jfree.chart.entity.CategoryItemEntity(shape30, "DateTickMarkPosition.END", "TextBlockAnchor.CENTER_RIGHT", (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset34, (java.lang.Comparable) (short) 1, (java.lang.Comparable) "RangeType.NEGATIVE");
        org.jfree.chart.plot.PiePlot piePlot43 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke44 = piePlot43.getLabelOutlineStroke();
        piePlot43.setLabelLinkMargin((double) '#');
        boolean boolean47 = defaultBoxAndWhiskerCategoryDataset34.hasListener((java.util.EventListener) piePlot43);
        java.awt.Paint paint48 = piePlot43.getShadowPaint();
        java.awt.Stroke stroke49 = piePlot43.getOutlineStroke();
        xYPlot15.setDomainZeroBaselineStroke(stroke49);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNull(number39);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(stroke49);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        waferMapPlot1.setDataset(waferMapDataset2);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.setHeight(35.0d);
        size2D0.setWidth(0.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getLabelOutlineStroke();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer3 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        minMaxCategoryRenderer3.setBaseFillPaint(paint4);
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) 0.2d, paint4);
        org.jfree.chart.util.Rotation rotation7 = piePlot0.getDirection();
        double double8 = piePlot0.getInteriorGap();
        java.awt.Paint paint9 = piePlot0.getOutlinePaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator10);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.25d + "'", double8 == 0.25d);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font4, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Paint paint11 = jFreeChart10.getBorderPaint();
        jFreeChart10.setAntiAlias(false);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer14 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = levelRenderer14.getNegativeItemLabelPosition(12, (-49088));
        java.awt.Stroke stroke19 = levelRenderer14.lookupSeriesStroke(0);
        java.awt.Color color20 = java.awt.Color.RED;
        levelRenderer14.setBaseOutlinePaint((java.awt.Paint) color20, true);
        jFreeChart10.setBackgroundPaint((java.awt.Paint) color20);
        org.jfree.chart.title.LegendTitle legendTitle24 = jFreeChart10.getLegend();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(legendTitle24);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        stackedBarRenderer3D4.setBaseToolTipGenerator(categoryToolTipGenerator7);
        stackedBarRenderer3D4.setItemMargin((-1.0d));
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D4.setSeriesOutlineStroke(3, stroke12, true);
        stackedBarRenderer3D1.setBaseOutlineStroke(stroke12, true);
        int int17 = month0.compareTo((java.lang.Object) stackedBarRenderer3D1);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D19.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D22.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator25 = null;
        stackedBarRenderer3D22.setBaseToolTipGenerator(categoryToolTipGenerator25);
        stackedBarRenderer3D22.setItemMargin((-1.0d));
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D22.setSeriesOutlineStroke(3, stroke30, true);
        stackedBarRenderer3D19.setBaseOutlineStroke(stroke30, true);
        int int35 = month18.compareTo((java.lang.Object) stackedBarRenderer3D19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month18.next();
        boolean boolean37 = month0.equals((java.lang.Object) month18);
        long long38 = month0.getLastMillisecond();
        org.jfree.data.time.Year year39 = month0.getYear();
        java.util.Calendar calendar40 = null;
        try {
            long long41 = month0.getMiddleMillisecond(calendar40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1561964399999L + "'", long38 == 1561964399999L);
        org.junit.Assert.assertNotNull(year39);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) '4', (double) 10);
        stackedBarRenderer3D3.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedBarRenderer3D3.getURLGenerator((int) (byte) 1, (int) ' ');
        boolean boolean10 = dateTickMarkPosition0.equals((java.lang.Object) categoryURLGenerator9);
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot1.setBaseSectionPaint(paint2);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape5, (double) 3, 0.0f, (float) 1L);
        piePlot1.setLegendItemShape(shape5);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D12.setBase((double) 1.0f);
        java.lang.Boolean boolean16 = stackedBarRenderer3D12.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font19 = stackedBarRenderer3D12.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font19);
        piePlot1.setLabelFont(font19);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot22.setBaseSectionPaint(paint23);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape26, (double) 3, 0.0f, (float) 1L);
        piePlot22.setLegendItemShape(shape26);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D33.setBase((double) 1.0f);
        java.lang.Boolean boolean37 = stackedBarRenderer3D33.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font40 = stackedBarRenderer3D33.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine41 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font40);
        piePlot22.setLabelFont(font40);
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_RED;
        piePlot22.setNoDataMessagePaint((java.awt.Paint) color43);
        org.jfree.chart.block.LabelBlock labelBlock45 = new org.jfree.chart.block.LabelBlock("orange", font19, (java.awt.Paint) color43);
        double double46 = labelBlock45.getContentXOffset();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNull(boolean37);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 9, (double) (short) 100);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range7 = defaultBoxAndWhiskerCategoryDataset5.getRangeBounds(false);
        java.lang.Comparable comparable8 = null;
        java.lang.Number number10 = defaultBoxAndWhiskerCategoryDataset5.getMaxOutlier(comparable8, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str14 = spreadsheetDate13.getDescription();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset5, (java.lang.Comparable) str14);
        legendItemBlockContainer15.setURLText("orange");
        legendItemBlockContainer15.setToolTipText("LegendItemEntity: seriesKey=null, dataset=null");
        legendItemBlockContainer15.setPadding((double) (short) 100, (-1.0d), 0.5d, (double) (byte) 100);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDatasetCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("orange");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot6.setBaseSectionPaint(paint7);
        java.awt.Font font9 = piePlot6.getLabelFont();
        boolean boolean10 = piePlot6.isSubplot();
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot6);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean13 = numberAxis5.equals((java.lang.Object) color12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer14);
        boolean boolean16 = xYPlot15.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        xYPlot15.setOrientation(plotOrientation17);
        xYPlot15.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke21 = xYPlot15.getDomainZeroBaselineStroke();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 1563303599999L, (float) (-4L), (float) (-5280));
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.lang.Boolean boolean4 = stackedBarRenderer3D0.getSeriesCreateEntities((int) (short) 1);
        stackedBarRenderer3D0.setItemMargin(0.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D7.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        stackedBarRenderer3D7.setBaseToolTipGenerator(categoryToolTipGenerator10);
        stackedBarRenderer3D7.setItemMargin((-1.0d));
        boolean boolean14 = stackedBarRenderer3D7.getAutoPopulateSeriesOutlinePaint();
        java.lang.Boolean boolean16 = stackedBarRenderer3D7.getSeriesItemLabelsVisible(500);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D18.setBase((double) 1.0f);
        java.lang.Boolean boolean22 = stackedBarRenderer3D18.getSeriesCreateEntities((int) (short) 1);
        double double23 = stackedBarRenderer3D18.getUpperClip();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator25 = stackedBarRenderer3D18.getSeriesItemLabelGenerator((int) (byte) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = stackedBarRenderer3D18.getNegativeItemLabelPosition((-14336), 11);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline29 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline33 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long34 = segmentedTimeline33.getSegmentsExcludedSize();
        java.util.Date date36 = segmentedTimeline33.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline40 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long41 = segmentedTimeline40.getSegmentsExcludedSize();
        java.util.Date date43 = segmentedTimeline40.getDate((long) 7);
        boolean boolean44 = segmentedTimeline29.containsDomainRange(date36, date43);
        boolean boolean45 = itemLabelPosition28.equals((java.lang.Object) boolean44);
        stackedBarRenderer3D7.setSeriesPositiveItemLabelPosition((int) (byte) 0, itemLabelPosition28, false);
        stackedBarRenderer3D0.setBaseNegativeItemLabelPosition(itemLabelPosition28);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection49 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range51 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection49, true);
        int int52 = taskSeriesCollection49.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries54 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection49.remove(taskSeries54);
        java.util.List list56 = taskSeriesCollection49.getColumnKeys();
        org.jfree.data.Range range57 = stackedBarRenderer3D0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection49);
        java.awt.Color color58 = java.awt.Color.RED;
        stackedBarRenderer3D0.setBaseItemLabelPaint((java.awt.Paint) color58);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNull(boolean22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator25);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertNotNull(segmentedTimeline29);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-4L) + "'", long34 == (-4L));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-4L) + "'", long41 == (-4L));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(range51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(list56);
        org.junit.Assert.assertNull(range57);
        org.junit.Assert.assertNotNull(color58);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        java.lang.Comparable comparable3 = null;
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier(comparable3, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (double) 10L);
        try {
            java.util.List list11 = defaultBoxAndWhiskerCategoryDataset0.getOutliers((-5280), 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) "RangeType.FULL");
        java.lang.Object obj3 = defaultCategoryDataset0.clone();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        java.util.Date date10 = segmentedTimeline8.getDate(0L);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline14 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long15 = segmentedTimeline14.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline20 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long21 = segmentedTimeline20.getSegmentsExcludedSize();
        java.util.Date date23 = segmentedTimeline20.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline27 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long28 = segmentedTimeline27.getSegmentsExcludedSize();
        java.util.Date date30 = segmentedTimeline27.getDate((long) 7);
        boolean boolean31 = segmentedTimeline16.containsDomainRange(date23, date30);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment32 = segmentedTimeline14.getSegment(date30);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment35 = segment32.intersect((long) 'a', (long) 12);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline39 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long40 = segmentedTimeline39.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline41 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline45 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long46 = segmentedTimeline45.getSegmentsExcludedSize();
        java.util.Date date48 = segmentedTimeline45.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline52 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long53 = segmentedTimeline52.getSegmentsExcludedSize();
        java.util.Date date55 = segmentedTimeline52.getDate((long) 7);
        boolean boolean56 = segmentedTimeline41.containsDomainRange(date48, date55);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment57 = segmentedTimeline39.getSegment(date55);
        segment57.dec();
        boolean boolean59 = segment32.before(segment57);
        boolean boolean60 = segment32.inExcludeSegments();
        long long61 = segment32.getSegmentCount();
        defaultCategoryDataset0.addValue((java.lang.Number) 10.0f, (java.lang.Comparable) date10, (java.lang.Comparable) segment32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-4L) + "'", long15 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-4L) + "'", long21 == (-4L));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-4L) + "'", long28 == (-4L));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(segment32);
        org.junit.Assert.assertNull(segment35);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-4L) + "'", long40 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline41);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-4L) + "'", long46 == (-4L));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-4L) + "'", long53 == (-4L));
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(segment57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1L + "'", long61 == 1L);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setSeriesShapesVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone5 = dateAxis4.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = dateAxis4.getStandardTickUnits();
        double double7 = dateAxis4.getUpperBound();
        java.awt.Font font9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("", font9);
        dateAxis4.setLabelFont(font9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) dateAxis4);
        statisticalLineAndShapeRenderer0.notifyListeners(rendererChangeEvent12);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("hi!");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection4, true);
        taskSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) taskSeriesCollection4);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection8 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = null;
        taskSeriesCollection8.seriesChanged(seriesChangeEvent9);
        taskSeries1.removeChangeListener((org.jfree.data.general.SeriesChangeListener) taskSeriesCollection8);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D13.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D16.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = null;
        stackedBarRenderer3D16.setBaseToolTipGenerator(categoryToolTipGenerator19);
        stackedBarRenderer3D16.setItemMargin((-1.0d));
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D16.setSeriesOutlineStroke(3, stroke24, true);
        stackedBarRenderer3D13.setBaseOutlineStroke(stroke24, true);
        int int29 = month12.compareTo((java.lang.Object) stackedBarRenderer3D13);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D34.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator37 = null;
        stackedBarRenderer3D34.setBaseToolTipGenerator(categoryToolTipGenerator37);
        stackedBarRenderer3D34.setItemMargin((-1.0d));
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D34.setSeriesOutlineStroke(3, stroke42, true);
        stackedBarRenderer3D31.setBaseOutlineStroke(stroke42, true);
        int int47 = month30.compareTo((java.lang.Object) stackedBarRenderer3D31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month30.next();
        boolean boolean49 = month12.equals((java.lang.Object) month30);
        int int50 = taskSeriesCollection8.getRowIndex((java.lang.Comparable) boolean49);
        taskSeriesCollection8.removeAll();
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str2 = textTitle1.getURLText();
        boolean boolean3 = textTitle1.getNotify();
        textTitle1.setNotify(true);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        piePlot0.setPieIndex(12);
        boolean boolean5 = piePlot0.getIgnoreNullValues();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        java.awt.Shape shape8 = stackedBarRenderer3D0.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset12 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range14 = defaultBoxAndWhiskerCategoryDataset12.getRangeBounds(false);
        java.lang.Comparable comparable15 = null;
        java.lang.Number number17 = defaultBoxAndWhiskerCategoryDataset12.getMaxOutlier(comparable15, (java.lang.Comparable) (short) 0);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity20 = new org.jfree.chart.entity.CategoryItemEntity(shape8, "DateTickMarkPosition.END", "TextBlockAnchor.CENTER_RIGHT", (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset12, (java.lang.Comparable) (short) 1, (java.lang.Comparable) "RangeType.NEGATIVE");
        java.lang.Comparable comparable21 = categoryItemEntity20.getRowKey();
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryItemEntity20.getDataset();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset23 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list24 = defaultStatisticalCategoryDataset23.getColumnKeys();
        categoryItemEntity20.setDataset((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset23);
        java.lang.Number number26 = null;
        java.lang.Comparable comparable28 = null;
        defaultStatisticalCategoryDataset23.add(number26, (java.lang.Number) 1.0f, comparable28, (java.lang.Comparable) 1561964399999L);
        double double32 = defaultStatisticalCategoryDataset23.getRangeLowerBound(false);
        java.util.List list33 = defaultStatisticalCategoryDataset23.getColumnKeys();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + (short) 1 + "'", comparable21.equals((short) 1));
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(list33);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        defaultKeyedValues0.sortByValues(sortOrder1);
        org.junit.Assert.assertNotNull(sortOrder1);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean4 = spreadsheetDate1.equals((java.lang.Object) categoryLabelPositions3);
        java.lang.Class<?> wildcardClass5 = categoryLabelPositions3.getClass();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        double double3 = dateAxis0.getUpperBound();
        boolean boolean4 = dateAxis0.isTickLabelsVisible();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        dateAxis0.setTickMarkPaint((java.awt.Paint) color5);
        org.jfree.data.Range range7 = dateAxis0.getDefaultAutoRange();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape9, (double) 100L, (float) 0, (float) 10L);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity16 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis0, shape9, "RangeType.NEGATIVE", "RangeType.NEGATIVE");
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = dateAxis0.getTickLabelInsets();
        double double19 = rectangleInsets17.extendHeight(3.0d);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 7.0d + "'", double19 == 7.0d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        java.awt.Shape shape8 = stackedBarRenderer3D0.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset12 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range14 = defaultBoxAndWhiskerCategoryDataset12.getRangeBounds(false);
        java.lang.Comparable comparable15 = null;
        java.lang.Number number17 = defaultBoxAndWhiskerCategoryDataset12.getMaxOutlier(comparable15, (java.lang.Comparable) (short) 0);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity20 = new org.jfree.chart.entity.CategoryItemEntity(shape8, "DateTickMarkPosition.END", "TextBlockAnchor.CENTER_RIGHT", (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset12, (java.lang.Comparable) (short) 1, (java.lang.Comparable) "RangeType.NEGATIVE");
        java.lang.Comparable comparable21 = categoryItemEntity20.getRowKey();
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryItemEntity20.getDataset();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset23 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list24 = defaultStatisticalCategoryDataset23.getColumnKeys();
        categoryItemEntity20.setDataset((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset23);
        defaultStatisticalCategoryDataset23.add(35.0d, (double) (byte) 10, (java.lang.Comparable) 0.2d, (java.lang.Comparable) 900000L);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + (short) 1 + "'", comparable21.equals((short) 1));
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertNotNull(list24);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.util.List list1 = defaultKeyedValues0.getKeys();
        int int3 = defaultKeyedValues0.getIndex((java.lang.Comparable) (-460));
        try {
            java.lang.Number number5 = defaultKeyedValues0.getValue((java.lang.Comparable) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 1");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        java.awt.Shape shape8 = stackedBarRenderer3D0.getItemShape(1, (int) (short) 0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) 7);
        stackedBarRenderer3D0.notifyListeners(rendererChangeEvent10);
        boolean boolean12 = stackedBarRenderer3D0.getRenderAsPercentages();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setBase((double) 1.0f);
        java.awt.Paint paint7 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D4.setBaseItemLabelPaint(paint7, true);
        java.awt.Shape shape12 = stackedBarRenderer3D4.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity13 = new org.jfree.chart.entity.LegendItemEntity(shape12);
        java.awt.Shape shape14 = legendItemEntity13.getArea();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity15 = new org.jfree.chart.entity.LegendItemEntity(shape14);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D17.setBase((double) 1.0f);
        java.lang.Boolean boolean21 = stackedBarRenderer3D17.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font24 = stackedBarRenderer3D17.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        dateAxis26.setAutoTickUnitSelection(false);
        boolean boolean29 = dateAxis26.isNegativeArrowVisible();
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot30.setBaseSectionPaint(paint31);
        dateAxis26.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot30);
        org.jfree.chart.event.AxisChangeListener axisChangeListener34 = null;
        dateAxis26.removeChangeListener(axisChangeListener34);
        java.awt.Font font36 = dateAxis26.getTickLabelFont();
        java.awt.Color color37 = java.awt.Color.darkGray;
        org.jfree.chart.text.TextMeasurer textMeasurer39 = null;
        org.jfree.chart.text.TextBlock textBlock40 = org.jfree.chart.text.TextUtilities.createTextBlock("", font36, (java.awt.Paint) color37, (float) (byte) 0, textMeasurer39);
        org.jfree.chart.text.TextBlock textBlock41 = org.jfree.chart.text.TextUtilities.createTextBlock("June 2019", font24, (java.awt.Paint) color37);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer42 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator45 = minMaxCategoryRenderer42.getItemLabelGenerator((int) (short) 100, (int) 'a');
        java.awt.Paint paint48 = minMaxCategoryRenderer42.getItemPaint((-1), (int) (short) 100);
        java.awt.Paint paint49 = minMaxCategoryRenderer42.getGroupPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator50 = minMaxCategoryRenderer42.getLegendItemURLGenerator();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D51 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color53 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D51.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color53);
        java.lang.String str56 = categoryAxis3D51.getCategoryLabelToolTip((java.lang.Comparable) 4.0d);
        categoryAxis3D51.configure();
        java.awt.Paint paint59 = categoryAxis3D51.getTickLabelPaint((java.lang.Comparable) 0.25d);
        minMaxCategoryRenderer42.setGroupPaint(paint59);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer61 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.plot.PiePlot piePlot62 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke63 = piePlot62.getLabelOutlineStroke();
        waterfallBarRenderer61.setBaseOutlineStroke(stroke63);
        minMaxCategoryRenderer42.setGroupStroke(stroke63);
        java.awt.Paint paint66 = null;
        try {
            org.jfree.chart.LegendItem legendItem67 = new org.jfree.chart.LegendItem("Default Group", "", "Default Group", "TextAnchor.BOTTOM_CENTER", shape14, (java.awt.Paint) color37, stroke63, paint66);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'outlinePaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(textBlock40);
        org.junit.Assert.assertNotNull(textBlock41);
        org.junit.Assert.assertNull(categoryItemLabelGenerator45);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator50);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(stroke63);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setUseOutlinePaint(true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D3.setBase((double) 1.0f);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator6 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        stackedBarRenderer3D3.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator6);
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER;
        boolean boolean9 = standardCategorySeriesLabelGenerator6.equals((java.lang.Object) textAnchor8);
        statisticalLineAndShapeRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator6);
        java.lang.Boolean boolean12 = statisticalLineAndShapeRenderer0.getSeriesLinesVisible((int) (short) 1);
        java.awt.Paint paint13 = statisticalLineAndShapeRenderer0.getBasePaint();
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.configure();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.25d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setBase((double) 1.0f);
        java.awt.Paint paint7 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D4.setBaseItemLabelPaint(paint7, true);
        java.awt.Shape shape12 = stackedBarRenderer3D4.getItemShape(1, (int) (short) 0);
        stackedBarRenderer3D4.setAutoPopulateSeriesOutlinePaint(false);
        boolean boolean15 = categoryLabelPositions3.equals((java.lang.Object) stackedBarRenderer3D4);
        categoryAxis3D0.setCategoryLabelPositions(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("DateTickMarkPosition.END");
        boolean boolean2 = numberAxis3D1.isVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = numberAxis3D1.getLabelInsets();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("ItemLabelAnchor.OUTSIDE12", "1.0.6", "GradientPaintTransformType.VERTICAL", "RangeType.FULL", "");
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 3, 0.0f, (float) 1L);
        piePlot0.setLegendItemShape(shape4);
        java.awt.Color color10 = java.awt.Color.yellow;
        piePlot0.setOutlinePaint((java.awt.Paint) color10);
        piePlot0.setSectionOutlinesVisible(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint2 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        categoryPlot0.setRenderer(categoryItemRenderer3);
        categoryPlot0.setRangeCrosshairValue((double) 9, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getDomainAxisEdge((-253));
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str11 = piePlot10.getNoDataMessage();
        java.awt.Image image12 = null;
        piePlot10.setBackgroundImage(image12);
        boolean boolean14 = categoryPlot0.equals((java.lang.Object) image12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 3, 0.0f, (float) 1L);
        piePlot0.setLegendItemShape(shape4);
        java.awt.Paint paint10 = piePlot0.getLabelPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Object obj1 = defaultKeyedValues0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("orange");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot6.setBaseSectionPaint(paint7);
        java.awt.Font font9 = piePlot6.getLabelFont();
        boolean boolean10 = piePlot6.isSubplot();
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot6);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean13 = numberAxis5.equals((java.lang.Object) color12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer14);
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str17 = layer16.toString();
        java.util.Collection collection18 = xYPlot15.getDomainMarkers(layer16);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke20 = defaultDrawingSupplier19.getNextOutlineStroke();
        java.awt.Shape shape21 = defaultDrawingSupplier19.getNextShape();
        java.lang.Object obj22 = defaultDrawingSupplier19.clone();
        java.awt.Stroke stroke23 = defaultDrawingSupplier19.getNextOutlineStroke();
        xYPlot15.setDomainCrosshairStroke(stroke23);
        java.awt.Paint paint25 = xYPlot15.getDomainZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Layer.FOREGROUND" + "'", str17.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 11);
        boolean boolean2 = categoryMarker1.getDrawAsLine();
        java.awt.Font font3 = categoryMarker1.getLabelFont();
        org.jfree.chart.event.MarkerChangeListener markerChangeListener4 = null;
        categoryMarker1.addChangeListener(markerChangeListener4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryMarker1.getLabelOffset();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.String str1 = multiplePiePlot0.getPlotType();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D3.setBase((double) 1.0f);
        java.awt.Font font6 = stackedBarRenderer3D3.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot7.setBaseSectionPaint(paint8);
        java.awt.Font font10 = piePlot7.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font6, (org.jfree.chart.plot.Plot) piePlot7, false);
        java.awt.Paint paint13 = jFreeChart12.getBorderPaint();
        boolean boolean14 = jFreeChart12.isBorderVisible();
        org.jfree.chart.event.ChartProgressListener chartProgressListener15 = null;
        jFreeChart12.addProgressListener(chartProgressListener15);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D17.setBase((double) 1.0f);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer20 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = minMaxCategoryRenderer20.getItemLabelGenerator((int) (short) 100, (int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor25 = itemLabelPosition24.getTextAnchor();
        double double26 = itemLabelPosition24.getAngle();
        minMaxCategoryRenderer20.setBaseNegativeItemLabelPosition(itemLabelPosition24);
        stackedBarRenderer3D17.setPositiveItemLabelPositionFallback(itemLabelPosition24);
        boolean boolean29 = jFreeChart12.equals((java.lang.Object) itemLabelPosition24);
        jFreeChart12.setBackgroundImageAlpha((float) 9);
        org.jfree.chart.title.TextTitle textTitle32 = jFreeChart12.getTitle();
        multiplePiePlot0.setPieChart(jFreeChart12);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions34 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions35 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition36 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor37 = categoryLabelPosition36.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions38 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions35, categoryLabelPosition36);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions39 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions34, categoryLabelPosition36);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions40 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.AxisCollection axisCollection41 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone43 = dateAxis42.getTimeZone();
        dateAxis42.setInverted(false);
        dateAxis42.resizeRange((double) (byte) 10, (double) (byte) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection41.add((org.jfree.chart.axis.Axis) dateAxis42, rectangleEdge49);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition51 = categoryLabelPositions40.getLabelPosition(rectangleEdge49);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition52 = categoryLabelPositions39.getLabelPosition(rectangleEdge49);
        boolean boolean53 = multiplePiePlot0.equals((java.lang.Object) categoryLabelPosition52);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Multiple Pie Plot" + "'", str1.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator23);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(textTitle32);
        org.junit.Assert.assertNotNull(categoryLabelPositions34);
        org.junit.Assert.assertNotNull(categoryLabelPositions35);
        org.junit.Assert.assertNotNull(textAnchor37);
        org.junit.Assert.assertNotNull(categoryLabelPositions38);
        org.junit.Assert.assertNotNull(categoryLabelPositions39);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertNotNull(categoryLabelPosition51);
        org.junit.Assert.assertNotNull(categoryLabelPosition52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color2);
        java.lang.String str5 = categoryAxis3D0.getCategoryLabelToolTip((java.lang.Comparable) 4.0d);
        categoryAxis3D0.configure();
        java.awt.Paint paint8 = categoryAxis3D0.getTickLabelPaint((java.lang.Comparable) 0.25d);
        categoryAxis3D0.setMaximumCategoryLabelLines(2958465);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        double double1 = levelRenderer0.getMaximumItemWidth();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot6.setBaseSectionPaint(paint7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape10, (double) 3, 0.0f, (float) 1L);
        piePlot6.setLegendItemShape(shape10);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D17.setBase((double) 1.0f);
        java.lang.Boolean boolean21 = stackedBarRenderer3D17.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font24 = stackedBarRenderer3D17.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine25 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font24);
        piePlot6.setLabelFont(font24);
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("LegendItemEntity: seriesKey=null, dataset=null", font24);
        piePlot3D4.setLabelFont(font24);
        levelRenderer0.setSeriesItemLabelFont((int) 'a', font24);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean32 = categoryPlot31.isDomainGridlinesVisible();
        java.awt.Paint paint33 = categoryPlot31.getRangeGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone35 = dateAxis34.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource36 = dateAxis34.getStandardTickUnits();
        double double37 = dateAxis34.getUpperBound();
        boolean boolean38 = dateAxis34.isTickLabelsVisible();
        org.jfree.chart.plot.Marker marker39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        levelRenderer0.drawRangeMarker(graphics2D30, categoryPlot31, (org.jfree.chart.axis.ValueAxis) dateAxis34, marker39, rectangle2D40);
        dateAxis34.setPositiveArrowVisible(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(tickUnitSource36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("hi!");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection4, true);
        taskSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) taskSeriesCollection4);
        org.jfree.data.gantt.Task task8 = null;
        taskSeries1.remove(task8);
        taskSeries1.setDescription("GradientPaintTransformType.VERTICAL");
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        minMaxCategoryRenderer0.setBaseFillPaint(paint1);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) minMaxCategoryRenderer0, jFreeChart3);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot6.setBaseSectionPaint(paint7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape10, (double) 3, 0.0f, (float) 1L);
        piePlot6.setLegendItemShape(shape10);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D17.setBase((double) 1.0f);
        java.lang.Boolean boolean21 = stackedBarRenderer3D17.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font24 = stackedBarRenderer3D17.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine25 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font24);
        piePlot6.setLabelFont(font24);
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_RED;
        piePlot6.setNoDataMessagePaint((java.awt.Paint) color27);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment31 = textTitle30.getTextAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment32 = textTitle30.getTextAlignment();
        boolean boolean33 = textTitle30.getNotify();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D35.setBase((double) 1.0f);
        java.awt.Font font38 = stackedBarRenderer3D35.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot39 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint40 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot39.setBaseSectionPaint(paint40);
        java.awt.Font font42 = piePlot39.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font38, (org.jfree.chart.plot.Plot) piePlot39, false);
        java.awt.Paint paint45 = jFreeChart44.getBorderPaint();
        boolean boolean46 = jFreeChart44.isBorderVisible();
        textTitle30.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart44);
        piePlot6.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart44);
        java.awt.Stroke stroke49 = piePlot6.getLabelLinkStroke();
        minMaxCategoryRenderer0.setSeriesStroke(10, stroke49);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(horizontalAlignment31);
        org.junit.Assert.assertNotNull(horizontalAlignment32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(stroke49);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font4, (org.jfree.chart.plot.Plot) piePlot5, false);
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart10.getTitle();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(textTitle11);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        double double3 = rectangleInsets1.calculateLeftInset((double) 1561964399999L);
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets1.getUnitType();
        double double6 = rectangleInsets1.calculateLeftOutset((double) (-4L));
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight(9);
        categoryPlot0.clearRangeMarkers(9);
        categoryPlot0.setAnchorValue((double) 8);
        categoryPlot0.setDomainGridlinesVisible(true);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset2 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range4 = defaultBoxAndWhiskerCategoryDataset2.getRangeBounds(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline10 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long11 = segmentedTimeline10.getSegmentsExcludedSize();
        java.util.Date date13 = segmentedTimeline10.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long18 = segmentedTimeline17.getSegmentsExcludedSize();
        java.util.Date date20 = segmentedTimeline17.getDate((long) 7);
        boolean boolean21 = segmentedTimeline6.containsDomainRange(date13, date20);
        java.lang.Number number22 = defaultBoxAndWhiskerCategoryDataset2.getMaxRegularValue((java.lang.Comparable) ' ', (java.lang.Comparable) date13);
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone26 = dateAxis25.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone26);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone26;
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date13, timeZone26);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date13);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate30);
        try {
            org.jfree.data.general.PieDataset pieDataset33 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) serialDate31, (double) (-253));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-4L) + "'", long11 == (-4L));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-4L) + "'", long18 == (-4L));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        java.awt.Shape shape8 = stackedBarRenderer3D0.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset12 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range14 = defaultBoxAndWhiskerCategoryDataset12.getRangeBounds(false);
        java.lang.Comparable comparable15 = null;
        java.lang.Number number17 = defaultBoxAndWhiskerCategoryDataset12.getMaxOutlier(comparable15, (java.lang.Comparable) (short) 0);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity20 = new org.jfree.chart.entity.CategoryItemEntity(shape8, "DateTickMarkPosition.END", "TextBlockAnchor.CENTER_RIGHT", (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset12, (java.lang.Comparable) (short) 1, (java.lang.Comparable) "RangeType.NEGATIVE");
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke22 = piePlot21.getLabelOutlineStroke();
        piePlot21.setLabelLinkMargin((double) '#');
        boolean boolean25 = defaultBoxAndWhiskerCategoryDataset12.hasListener((java.util.EventListener) piePlot21);
        piePlot21.setLabelLinksVisible(true);
        piePlot21.setMinimumArcAngleToDraw((double) 'a');
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setBaseShapesFilled(false);
        java.lang.Boolean boolean4 = statisticalLineAndShapeRenderer0.getSeriesLinesVisible(5);
        statisticalLineAndShapeRenderer0.setBaseShapesVisible(false);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean11 = categoryPlot10.isDomainGridlinesVisible();
        java.lang.String str12 = categoryPlot10.getPlotType();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D13.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color15);
        java.lang.String str18 = categoryAxis3D13.getCategoryLabelToolTip((java.lang.Comparable) 4.0d);
        categoryAxis3D13.configure();
        java.awt.Paint paint21 = categoryAxis3D13.getTickLabelPaint((java.lang.Comparable) 0.25d);
        java.lang.String str23 = categoryAxis3D13.getCategoryLabelToolTip((java.lang.Comparable) 86400000L);
        int int24 = categoryPlot10.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D13);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean26 = categoryPlot25.isDomainGridlinesVisible();
        categoryPlot25.setRangeCrosshairValue(Double.NaN, true);
        categoryPlot25.setAnchorValue(0.0d);
        categoryPlot25.clearDomainMarkers((-1));
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color37 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D35.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color37);
        categoryPlot25.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone41 = dateAxis40.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource42 = dateAxis40.getStandardTickUnits();
        double double43 = dateAxis40.getUpperBound();
        java.awt.Font font45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine46 = new org.jfree.chart.text.TextLine("", font45);
        dateAxis40.setLabelFont(font45);
        dateAxis40.setVisible(false);
        dateAxis40.setLabel("JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\n");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline55 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long56 = segmentedTimeline55.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline57 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline61 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long62 = segmentedTimeline61.getSegmentsExcludedSize();
        java.util.Date date64 = segmentedTimeline61.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline68 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long69 = segmentedTimeline68.getSegmentsExcludedSize();
        java.util.Date date71 = segmentedTimeline68.getDate((long) 7);
        boolean boolean72 = segmentedTimeline57.containsDomainRange(date64, date71);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment73 = segmentedTimeline55.getSegment(date71);
        dateAxis40.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline55);
        org.jfree.data.category.CategoryDataset categoryDataset75 = null;
        try {
            statisticalLineAndShapeRenderer0.drawItem(graphics2D7, categoryItemRendererState8, rectangle2D9, categoryPlot10, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D35, (org.jfree.chart.axis.ValueAxis) dateAxis40, categoryDataset75, (int) (short) 100, 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNotNull(tickUnitSource42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-4L) + "'", long56 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline57);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-4L) + "'", long62 == (-4L));
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-4L) + "'", long69 == (-4L));
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(segment73);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint2 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("orange");
        float float8 = dateAxis7.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot11.setBaseSectionPaint(paint12);
        java.awt.Font font14 = piePlot11.getLabelFont();
        boolean boolean15 = piePlot11.isSubplot();
        numberAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot11);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean18 = numberAxis10.equals((java.lang.Object) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer19);
        java.awt.Paint paint21 = xYPlot20.getDomainGridlinePaint();
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str24 = layer23.toString();
        java.util.Collection collection25 = xYPlot20.getRangeMarkers(3, layer23);
        java.util.Collection collection26 = categoryPlot4.getDomainMarkers(layer23);
        java.util.Collection collection27 = categoryPlot0.getDomainMarkers((int) (byte) 100, layer23);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertNull(collection27);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("hi!");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection4, true);
        taskSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) taskSeriesCollection4);
        taskSeries1.removeAll();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D9.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        stackedBarRenderer3D9.setBaseToolTipGenerator(categoryToolTipGenerator12);
        stackedBarRenderer3D9.setItemMargin((-1.0d));
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D9.setSeriesOutlineStroke(3, stroke17, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator20 = null;
        stackedBarRenderer3D9.setLegendItemToolTipGenerator(categorySeriesLabelGenerator20);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer22 = null;
        stackedBarRenderer3D9.setGradientPaintTransformer(gradientPaintTransformer22);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = null;
        stackedBarRenderer3D9.setBaseURLGenerator(categoryURLGenerator24, true);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        boolean boolean28 = stackedBarRenderer3D9.equals((java.lang.Object) color27);
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D9);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        legendTitle29.setItemLabelPadding(rectangleInsets30);
        org.jfree.data.general.PieDataset pieDataset32 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D33 = new org.jfree.chart.plot.PiePlot3D(pieDataset32);
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot35.setBaseSectionPaint(paint36);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape39, (double) 3, 0.0f, (float) 1L);
        piePlot35.setLegendItemShape(shape39);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D46 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D46.setBase((double) 1.0f);
        java.lang.Boolean boolean50 = stackedBarRenderer3D46.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font53 = stackedBarRenderer3D46.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine54 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font53);
        piePlot35.setLabelFont(font53);
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("LegendItemEntity: seriesKey=null, dataset=null", font53);
        piePlot3D33.setLabelFont(font53);
        legendTitle29.setItemFont(font53);
        boolean boolean59 = taskSeries1.equals((java.lang.Object) legendTitle29);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNull(boolean50);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.0d, (double) '#');
        double double3 = size2D2.getHeight();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        double double3 = dateAxis0.getUpperBound();
        boolean boolean4 = dateAxis0.isTickLabelsVisible();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        dateAxis0.setTickMarkPaint((java.awt.Paint) color5);
        dateAxis0.setAxisLineVisible(true);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean12 = categoryPlot11.isDomainGridlinesVisible();
        java.awt.Paint paint13 = categoryPlot11.getRangeGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot11.setRenderer(categoryItemRenderer14);
        categoryPlot11.setRangeCrosshairValue((double) 9, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot11.getDomainAxisEdge((-253));
        try {
            double double21 = dateAxis0.java2DToValue((double) 5, rectangle2D10, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isDomainGridlinesVisible();
        categoryPlot2.setRangeCrosshairValue(Double.NaN, true);
        categoryPlot2.setAnchorValue(0.0d);
        categoryPlot2.clearDomainMarkers((-1));
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.setAutoTickUnitSelection(false);
        boolean boolean14 = dateAxis11.isNegativeArrowVisible();
        boolean boolean15 = dateAxis11.isInverted();
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 11);
        boolean boolean18 = categoryMarker17.getDrawAsLine();
        java.awt.Font font19 = categoryMarker17.getLabelFont();
        java.awt.Shape shape25 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke28 = piePlot27.getLabelOutlineStroke();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer30 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint31 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        minMaxCategoryRenderer30.setBaseFillPaint(paint31);
        piePlot27.setSectionOutlinePaint((java.lang.Comparable) 0.2d, paint31);
        java.awt.Color color34 = java.awt.Color.LIGHT_GRAY;
        piePlot27.setShadowPaint((java.awt.Paint) color34);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D37 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D37.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator40 = null;
        stackedBarRenderer3D37.setBaseToolTipGenerator(categoryToolTipGenerator40);
        stackedBarRenderer3D37.setItemMargin((-1.0d));
        java.awt.Color color44 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        stackedBarRenderer3D37.setBaseOutlinePaint((java.awt.Paint) color44, false);
        org.jfree.chart.plot.PiePlot piePlot47 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint48 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot47.setBaseSectionPaint(paint48);
        java.awt.Font font50 = piePlot47.getLabelFont();
        boolean boolean51 = piePlot47.isSubplot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D52 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D52.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator55 = null;
        stackedBarRenderer3D52.setBaseToolTipGenerator(categoryToolTipGenerator55);
        stackedBarRenderer3D52.setItemMargin((-1.0d));
        java.awt.Stroke stroke60 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D52.setSeriesOutlineStroke(3, stroke60, true);
        piePlot47.setOutlineStroke(stroke60);
        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis("orange");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D67 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D67.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator70 = null;
        stackedBarRenderer3D67.setBaseToolTipGenerator(categoryToolTipGenerator70);
        stackedBarRenderer3D67.setItemMargin((-1.0d));
        boolean boolean74 = stackedBarRenderer3D67.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape76 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape80 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape76, (double) 100L, (float) 0, (float) 10L);
        stackedBarRenderer3D67.setBaseShape(shape80, true);
        dateAxis66.setDownArrow(shape80);
        org.jfree.chart.plot.PiePlot piePlot84 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke85 = piePlot84.getLabelOutlineStroke();
        java.awt.Color color86 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem87 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", true, shape25, true, (java.awt.Paint) color34, false, (java.awt.Paint) color44, stroke60, true, shape80, stroke85, (java.awt.Paint) color86);
        categoryMarker17.setOutlineStroke(stroke60);
        java.awt.geom.Rectangle2D rectangle2D89 = null;
        stackedBarRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.plot.Marker) categoryMarker17, rectangle2D89);
        java.awt.Paint paint91 = categoryPlot2.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(shape76);
        org.junit.Assert.assertNotNull(shape80);
        org.junit.Assert.assertNotNull(stroke85);
        org.junit.Assert.assertNotNull(color86);
        org.junit.Assert.assertNotNull(paint91);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        double double2 = stackedBarRenderer3D1.getXOffset();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 12.0d + "'", double2 == 12.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) 10);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot6.setBaseSectionPaint(paint7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape10, (double) 3, 0.0f, (float) 1L);
        piePlot6.setLegendItemShape(shape10);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator16 = piePlot6.getLabelGenerator();
        piePlot6.setIgnoreNullValues(true);
        int int19 = piePlot6.getPieIndex();
        piePlot6.setShadowXOffset((double) 6);
        java.awt.Color color22 = java.awt.Color.yellow;
        piePlot6.setLabelShadowPaint((java.awt.Paint) color22);
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot24.setBaseSectionPaint(paint25);
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape28, (double) 3, 0.0f, (float) 1L);
        piePlot24.setLegendItemShape(shape28);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator34 = piePlot24.getLabelGenerator();
        piePlot24.setIgnoreNullValues(true);
        int int37 = piePlot24.getPieIndex();
        piePlot24.setShadowXOffset((double) 6);
        java.awt.Color color40 = java.awt.Color.yellow;
        piePlot24.setLabelShadowPaint((java.awt.Paint) color40);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D43 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D43.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator46 = null;
        stackedBarRenderer3D43.setBaseToolTipGenerator(categoryToolTipGenerator46);
        java.awt.Stroke stroke49 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D43.setSeriesOutlineStroke((int) ' ', stroke49);
        piePlot24.setSectionOutlineStroke((java.lang.Comparable) (byte) 100, stroke49);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D52 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D52.setBase((double) 1.0f);
        java.lang.Boolean boolean56 = stackedBarRenderer3D52.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font59 = stackedBarRenderer3D52.getItemLabelFont((int) ' ', (int) (short) -1);
        stackedBarRenderer3D52.setItemMargin((double) (short) -1);
        java.awt.Paint paint62 = stackedBarRenderer3D52.getBaseItemLabelPaint();
        try {
            org.jfree.chart.LegendItem legendItem63 = new org.jfree.chart.LegendItem(attributedString0, "Other", "ClassContext", "java.awt.Color[r=128,g=128,b=128]", shape5, (java.awt.Paint) color22, stroke49, paint62);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNull(boolean56);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(paint62);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreZeroValues();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset2 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Comparable comparable4 = null;
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset2.getMedianValue((java.lang.Comparable) (-1.0f), comparable4);
        java.lang.Comparable comparable6 = null;
        java.lang.Comparable comparable7 = null;
        java.lang.Number number8 = defaultBoxAndWhiskerCategoryDataset2.getMaxRegularValue(comparable6, comparable7);
        boolean boolean9 = textTitle1.equals((java.lang.Object) number8);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        boolean boolean6 = stackedBarRenderer3D0.getAutoPopulateSeriesPaint();
        stackedBarRenderer3D0.setAutoPopulateSeriesStroke(false);
        java.awt.Paint paint11 = stackedBarRenderer3D0.getItemLabelPaint(500, (int) ' ');
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setUseOutlinePaint(true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D3.setBase((double) 1.0f);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator6 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        stackedBarRenderer3D3.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator6);
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER;
        boolean boolean9 = standardCategorySeriesLabelGenerator6.equals((java.lang.Object) textAnchor8);
        statisticalLineAndShapeRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator6);
        java.lang.Boolean boolean12 = statisticalLineAndShapeRenderer0.getSeriesLinesVisible((int) (short) 1);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.setAutoTickUnitSelection(false);
        boolean boolean16 = dateAxis13.isNegativeArrowVisible();
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot17.setBaseSectionPaint(paint18);
        dateAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot17);
        boolean boolean21 = statisticalLineAndShapeRenderer0.equals((java.lang.Object) dateAxis13);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset22 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range24 = defaultBoxAndWhiskerCategoryDataset22.getRangeBounds(false);
        java.lang.Comparable comparable25 = null;
        java.lang.Number number27 = defaultBoxAndWhiskerCategoryDataset22.getMaxOutlier(comparable25, (java.lang.Comparable) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str30 = spreadsheetDate29.getDescription();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions31 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean32 = spreadsheetDate29.equals((java.lang.Object) categoryLabelPositions31);
        int int33 = spreadsheetDate29.getMonth();
        java.lang.Number number35 = defaultBoxAndWhiskerCategoryDataset22.getMinRegularValue((java.lang.Comparable) spreadsheetDate29, (java.lang.Comparable) (-4L));
        boolean boolean36 = statisticalLineAndShapeRenderer0.equals((java.lang.Object) (-4L));
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(categoryLabelPositions31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertNull(number35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        dateAxis0.setInverted(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setBase((double) 1.0f);
        java.lang.Boolean boolean8 = stackedBarRenderer3D4.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font11 = stackedBarRenderer3D4.getItemLabelFont((int) ' ', (int) (short) -1);
        stackedBarRenderer3D4.setItemMargin((double) (short) -1);
        java.awt.Paint paint14 = stackedBarRenderer3D4.getBaseItemLabelPaint();
        dateAxis0.setLabelPaint(paint14);
        try {
            dateAxis0.setRangeWithMargins((double) (short) 1, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("LegendItemEntity: seriesKey=null, dataset=null");
        boolean boolean3 = textFragment1.equals((java.lang.Object) "hi!");
        java.awt.Graphics2D graphics2D4 = null;
        try {
            org.jfree.chart.util.Size2D size2D5 = textFragment1.calculateDimensions(graphics2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint2 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        categoryPlot0.setRenderer(categoryItemRenderer3);
        categoryPlot0.setRangeCrosshairValue((double) 9, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getDomainAxisEdge((-253));
        categoryPlot0.clearRangeMarkers((-14336));
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot0.setDataset(categoryDataset12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        defaultStatisticalCategoryDataset0.add((java.lang.Number) (-1L), (java.lang.Number) 100.0d, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset7 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range9 = defaultBoxAndWhiskerCategoryDataset7.getRangeBounds(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline11 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline15 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long16 = segmentedTimeline15.getSegmentsExcludedSize();
        java.util.Date date18 = segmentedTimeline15.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline22 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long23 = segmentedTimeline22.getSegmentsExcludedSize();
        java.util.Date date25 = segmentedTimeline22.getDate((long) 7);
        boolean boolean26 = segmentedTimeline11.containsDomainRange(date18, date25);
        java.lang.Number number27 = defaultBoxAndWhiskerCategoryDataset7.getMaxRegularValue((java.lang.Comparable) ' ', (java.lang.Comparable) date18);
        java.lang.Class class28 = null;
        java.util.Date date29 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone31 = dateAxis30.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone31);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone31;
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date18, timeZone31);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline38 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long39 = segmentedTimeline38.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline40 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline44 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long45 = segmentedTimeline44.getSegmentsExcludedSize();
        java.util.Date date47 = segmentedTimeline44.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline51 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long52 = segmentedTimeline51.getSegmentsExcludedSize();
        java.util.Date date54 = segmentedTimeline51.getDate((long) 7);
        boolean boolean55 = segmentedTimeline40.containsDomainRange(date47, date54);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment56 = segmentedTimeline38.getSegment(date54);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment59 = segment56.intersect((long) 'a', (long) 12);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline63 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long64 = segmentedTimeline63.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline65 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline69 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long70 = segmentedTimeline69.getSegmentsExcludedSize();
        java.util.Date date72 = segmentedTimeline69.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline76 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long77 = segmentedTimeline76.getSegmentsExcludedSize();
        java.util.Date date79 = segmentedTimeline76.getDate((long) 7);
        boolean boolean80 = segmentedTimeline65.containsDomainRange(date72, date79);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment81 = segmentedTimeline63.getSegment(date79);
        segment81.dec();
        boolean boolean83 = segment56.before(segment81);
        boolean boolean84 = segment56.inExcludeSegments();
        java.lang.Number number85 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) date18, (java.lang.Comparable) boolean84);
        double double87 = defaultStatisticalCategoryDataset0.getRangeLowerBound(false);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(segmentedTimeline11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-4L) + "'", long16 == (-4L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-4L) + "'", long23 == (-4L));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-4L) + "'", long39 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline40);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-4L) + "'", long45 == (-4L));
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-4L) + "'", long52 == (-4L));
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(segment56);
        org.junit.Assert.assertNull(segment59);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-4L) + "'", long64 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline65);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-4L) + "'", long70 == (-4L));
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + (-4L) + "'", long77 == (-4L));
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(segment81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNull(number85);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + (-1.0d) + "'", double87 == (-1.0d));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) 10, range1, lengthConstraintType2, (double) (byte) 1, range4, lengthConstraintType5);
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range8 = null;
        org.jfree.data.Range range9 = org.jfree.data.Range.combine(range7, range8);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint6.toRangeHeight(range9);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType11 = rectangleConstraint10.getWidthConstraintType();
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot12.setBaseSectionPaint(paint13);
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape16, (double) 3, 0.0f, (float) 1L);
        piePlot12.setLegendItemShape(shape16);
        piePlot12.setShadowYOffset((double) 9);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("orange");
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent26 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis25);
        piePlot12.axisChanged(axisChangeEvent26);
        boolean boolean28 = lengthConstraintType11.equals((java.lang.Object) axisChangeEvent26);
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNotNull(lengthConstraintType11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color2);
        java.lang.String str5 = categoryAxis3D0.getCategoryLabelToolTip((java.lang.Comparable) 4.0d);
        categoryAxis3D0.configure();
        java.awt.Paint paint8 = categoryAxis3D0.getTickLabelPaint((java.lang.Comparable) 0.25d);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor15 = categoryLabelPosition14.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions13, categoryLabelPosition14);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions17 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition19 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor20 = categoryLabelPosition19.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions21 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions18, categoryLabelPosition19);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions22 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions17, categoryLabelPosition19);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions23 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.AxisCollection axisCollection24 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone26 = dateAxis25.getTimeZone();
        dateAxis25.setInverted(false);
        dateAxis25.resizeRange((double) (byte) 10, (double) (byte) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection24.add((org.jfree.chart.axis.Axis) dateAxis25, rectangleEdge32);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition34 = categoryLabelPositions23.getLabelPosition(rectangleEdge32);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition35 = categoryLabelPositions22.getLabelPosition(rectangleEdge32);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition36 = categoryLabelPositions13.getLabelPosition(rectangleEdge32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        try {
            org.jfree.chart.axis.AxisState axisState38 = categoryAxis3D0.draw(graphics2D9, (double) (byte) 0, rectangle2D11, rectangle2D12, rectangleEdge32, plotRenderingInfo37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertNotNull(categoryLabelPositions17);
        org.junit.Assert.assertNotNull(categoryLabelPositions18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(categoryLabelPositions21);
        org.junit.Assert.assertNotNull(categoryLabelPositions22);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(categoryLabelPosition34);
        org.junit.Assert.assertNotNull(categoryLabelPosition35);
        org.junit.Assert.assertNotNull(categoryLabelPosition36);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D0.setSeriesOutlineStroke((int) ' ', stroke6);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape10, (double) 3, 0.0f, (float) 1L);
        stackedBarRenderer3D0.setSeriesShape(0, shape14);
        stackedBarRenderer3D0.setSeriesCreateEntities(0, (java.lang.Boolean) true, false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, 5);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        boolean boolean6 = stackedBarRenderer3D0.getAutoPopulateSeriesPaint();
        boolean boolean8 = stackedBarRenderer3D0.isSeriesItemLabelsVisible((int) (short) 100);
        java.lang.Class<?> wildcardClass9 = stackedBarRenderer3D0.getClass();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 9, (double) (short) 100);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range7 = defaultBoxAndWhiskerCategoryDataset5.getRangeBounds(false);
        java.lang.Comparable comparable8 = null;
        java.lang.Number number10 = defaultBoxAndWhiskerCategoryDataset5.getMaxOutlier(comparable8, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str14 = spreadsheetDate13.getDescription();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset5, (java.lang.Comparable) str14);
        legendItemBlockContainer15.setHeight((double) 500);
        org.jfree.data.general.Dataset dataset18 = legendItemBlockContainer15.getDataset();
        legendItemBlockContainer15.setHeight((double) '4');
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D21.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = null;
        stackedBarRenderer3D21.setBaseToolTipGenerator(categoryToolTipGenerator24);
        stackedBarRenderer3D21.setItemMargin((-1.0d));
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D21.setSeriesOutlineStroke(3, stroke29, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator32 = null;
        stackedBarRenderer3D21.setLegendItemToolTipGenerator(categorySeriesLabelGenerator32);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer34 = null;
        stackedBarRenderer3D21.setGradientPaintTransformer(gradientPaintTransformer34);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator36 = null;
        stackedBarRenderer3D21.setBaseURLGenerator(categoryURLGenerator36, true);
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        boolean boolean40 = stackedBarRenderer3D21.equals((java.lang.Object) color39);
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D21);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        legendTitle41.setItemLabelPadding(rectangleInsets42);
        org.jfree.data.general.PieDataset pieDataset44 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D45 = new org.jfree.chart.plot.PiePlot3D(pieDataset44);
        org.jfree.chart.plot.PiePlot piePlot47 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint48 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot47.setBaseSectionPaint(paint48);
        java.awt.Shape shape51 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape55 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape51, (double) 3, 0.0f, (float) 1L);
        piePlot47.setLegendItemShape(shape51);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D58 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D58.setBase((double) 1.0f);
        java.lang.Boolean boolean62 = stackedBarRenderer3D58.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font65 = stackedBarRenderer3D58.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine66 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font65);
        piePlot47.setLabelFont(font65);
        org.jfree.chart.title.TextTitle textTitle68 = new org.jfree.chart.title.TextTitle("LegendItemEntity: seriesKey=null, dataset=null", font65);
        piePlot3D45.setLabelFont(font65);
        legendTitle41.setItemFont(font65);
        legendItemBlockContainer15.add((org.jfree.chart.block.Block) legendTitle41);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(dataset18);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNull(boolean62);
        org.junit.Assert.assertNotNull(font65);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("orange");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot6.setBaseSectionPaint(paint7);
        java.awt.Font font9 = piePlot6.getLabelFont();
        boolean boolean10 = piePlot6.isSubplot();
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot6);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean13 = numberAxis5.equals((java.lang.Object) color12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer14);
        boolean boolean16 = xYPlot15.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace17 = xYPlot15.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(axisSpace17);
    }
}

