import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-1), serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.lang.Comparable[] comparableArray2 = new java.lang.Comparable[] { (-1.0d), 1.0f };
        java.lang.Comparable[] comparableArray9 = new java.lang.Comparable[] { '4', (byte) -1, 'a', 1.0d, 10.0f, '#' };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (short) 100, 10.0f, 0L, 1, 100L, 10 };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (short) 100, 10.0f, 0L, 1, 100L, 10 };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (short) 100, 10.0f, 0L, 1, 100L, 10 };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { (short) 100, 10.0f, 0L, 1, 100L, 10 };
        java.lang.Number[][] numberArray38 = new java.lang.Number[][] { numberArray16, numberArray23, numberArray30, numberArray37 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (short) 0 };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { (short) 0 };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { (short) 0 };
        java.lang.Number[][] numberArray45 = new java.lang.Number[][] { numberArray40, numberArray42, numberArray44 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset46 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray2, comparableArray9, numberArray38, numberArray45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray2);
        org.junit.Assert.assertNotNull(comparableArray9);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray45);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.chart.axis.DateTickUnit.HOUR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.io.ObjectOutputStream objectOutputStream2 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape1, objectOutputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            stackedBarRenderer3D0.drawOutline(graphics2D6, categoryPlot7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) '#', (float) '#', (double) 1, (-1.0f), 0.0f);
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.util.Date date0 = null;
        java.util.Date date1 = null;
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(date0, date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10.0f, 0.0d, false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.text.TextAnchor textAnchor2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 10, "hi!", textAnchor2, textAnchor3, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) '4', (double) 10);
        stackedBarRenderer3D2.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.event.RendererChangeListener rendererChangeListener5 = null;
        try {
            stackedBarRenderer3D2.addChangeListener(rendererChangeListener5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Paint paint8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D10.setBase((double) 1.0f);
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D10.setBaseItemLabelPaint(paint13, true);
        java.awt.Stroke stroke16 = null;
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Stroke stroke20 = null;
        java.awt.Paint paint21 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", true, shape6, false, paint8, false, paint13, stroke16, false, shape19, stroke20, paint21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        minMaxCategoryRenderer0.setBaseFillPaint(paint1);
        minMaxCategoryRenderer0.setItemLabelAnchorOffset((double) 100L);
        javax.swing.Icon icon5 = null;
        try {
            minMaxCategoryRenderer0.setMinIcon(icon5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'icon' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.Comparable[] comparableArray2 = new java.lang.Comparable[] { (short) 10, (byte) 1 };
        java.lang.Comparable[] comparableArray5 = new java.lang.Comparable[] { 100, (byte) 10 };
        double[][] doubleArray6 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray2, comparableArray5, doubleArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray2);
        org.junit.Assert.assertNotNull(comparableArray5);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'right' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) '4', (double) 10);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            stackedBarRenderer3D2.drawRangeGridline(graphics2D3, categoryPlot4, valueAxis5, rectangle2D6, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) '4', (double) 10);
        stackedBarRenderer3D2.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.event.RendererChangeListener rendererChangeListener5 = null;
        try {
            stackedBarRenderer3D2.removeChangeListener(rendererChangeListener5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double[] doubleArray5 = new double[] { 1, 0, 60000L, (short) 10, (short) 100 };
        double[] doubleArray11 = new double[] { 1, 0, 60000L, (short) 10, (short) 100 };
        double[][] doubleArray12 = new double[][] { doubleArray5, doubleArray11 };
        double[] doubleArray13 = new double[] {};
        double[] doubleArray14 = new double[] {};
        double[] doubleArray15 = new double[] {};
        double[] doubleArray16 = new double[] {};
        double[][] doubleArray17 = new double[][] { doubleArray13, doubleArray14, doubleArray15, doubleArray16 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset18 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray12, doubleArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        boolean boolean6 = stackedBarRenderer3D0.getAutoPopulateSeriesPaint();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            stackedBarRenderer3D0.drawDomainGridline(graphics2D7, categoryPlot8, rectangle2D9, (double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) '4', 0.4d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.25d + "'", double0 == 0.25d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, (double) (-1L), false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) '4', (double) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection1 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.String str3 = standardCategoryToolTipGenerator0.generateRowLabel((org.jfree.data.category.CategoryDataset) taskSeriesCollection1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.util.Date date1 = null;
        java.util.Date date2 = null;
        try {
            org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("", date1, date2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date1 = null;
        try {
            org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment(date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        stackedBarRenderer3D0.setItemMargin((-1.0d));
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D0.getToolTipGenerator((int) (byte) 0, 0);
        stackedBarRenderer3D0.setRenderAsPercentages(false);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            stackedBarRenderer3D0.drawDomainGridline(graphics2D12, categoryPlot13, rectangle2D14, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) 10L, (float) 3, (float) 6);
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        stackedBarRenderer3D0.setItemMargin((-1.0d));
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D0.setSeriesOutlineStroke(3, stroke8, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = null;
        stackedBarRenderer3D0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator11);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = null;
        stackedBarRenderer3D0.setGradientPaintTransformer(gradientPaintTransformer13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        stackedBarRenderer3D0.setBaseURLGenerator(categoryURLGenerator15, true);
        java.lang.Object obj18 = stackedBarRenderer3D0.clone();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        stackedBarRenderer3D0.setItemMargin((-1.0d));
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D0.setSeriesOutlineStroke(3, stroke8, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = null;
        stackedBarRenderer3D0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator11);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = null;
        stackedBarRenderer3D0.setGradientPaintTransformer(gradientPaintTransformer13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        stackedBarRenderer3D0.setBaseURLGenerator(categoryURLGenerator15, true);
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) true, jFreeChart18);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test067");
//        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (double) 0L, (float) (byte) 10, (float) '#');
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        boolean boolean2 = unitType0.equals((java.lang.Object) paintArray1);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("orange", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = null;
        double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.orange;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("orange", font1, (java.awt.Paint) color2, 0.0f, 1, textMeasurer5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange(range0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D0.setSeriesOutlineStroke((int) ' ', stroke6);
        stackedBarRenderer3D0.setAutoPopulateSeriesShape(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = stackedBarRenderer3D0.getSeriesURLGenerator(0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(categoryURLGenerator11);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        try {
            java.lang.Number number5 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) (-1.0d), (java.lang.Comparable) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.lang.String str0 = org.jfree.chart.labels.IntervalCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str0.equals("({0}, {1}) = {3} - {4}"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.awt.Color color0 = java.awt.Color.red;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray2 = null;
        try {
            float[] floatArray3 = color0.getComponents(colorSpace1, floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        try {
            java.lang.Comparable comparable4 = taskSeriesCollection0.getSeriesKey(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        try {
            java.lang.Number number6 = taskSeriesCollection0.getStartValue((java.lang.Comparable) 8.0d, (java.lang.Comparable) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("({0}, {1}) = {3} - {4}", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) (-1), (float) (short) 100, (double) 1.0f, 0.0f, (float) '4');
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.block.Arrangement arrangement1 = null;
        org.jfree.chart.block.Arrangement arrangement2 = null;
        try {
            org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) groupedStackedBarRenderer0, arrangement1, arrangement2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        stackedBarRenderer3D4.setBaseToolTipGenerator(categoryToolTipGenerator7);
        stackedBarRenderer3D4.setItemMargin((-1.0d));
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = stackedBarRenderer3D4.getToolTipGenerator((int) (byte) 0, 0);
        java.awt.Shape shape14 = stackedBarRenderer3D4.getBaseShape();
        java.awt.Paint paint15 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D16.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = null;
        stackedBarRenderer3D16.setBaseToolTipGenerator(categoryToolTipGenerator19);
        stackedBarRenderer3D16.setItemMargin((-1.0d));
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D16.setSeriesOutlineStroke(3, stroke24, true);
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        try {
            org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem(attributedString0, "({0}, {1}) = {3} - {4}", "({0}, {1}) = {3} - {4}", "orange", shape14, paint15, stroke24, (java.awt.Paint) color27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = minMaxCategoryRenderer0.getItemLabelGenerator((int) (short) 100, (int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor5 = itemLabelPosition4.getTextAnchor();
        double double6 = itemLabelPosition4.getAngle();
        minMaxCategoryRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition4);
        javax.swing.Icon icon8 = null;
        try {
            minMaxCategoryRenderer0.setMinIcon(icon8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'icon' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        taskSeries1.setKey((java.lang.Comparable) 0.4d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        stackedBarRenderer3D0.setItemMargin((-1.0d));
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        stackedBarRenderer3D0.setBaseOutlinePaint((java.awt.Paint) color7, false);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            stackedBarRenderer3D0.drawDomainGridline(graphics2D10, categoryPlot11, rectangle2D12, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.text.NumberFormat numberFormat1 = standardCategoryToolTipGenerator0.getNumberFormat();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection2, true);
        try {
            java.lang.String str6 = standardCategoryToolTipGenerator0.generateColumnLabel((org.jfree.data.category.CategoryDataset) taskSeriesCollection2, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Number number3 = taskSeriesCollection0.getValue((int) (byte) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("({0}, {1}) = {3} - {4}");
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("orange", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        try {
            dateAxis0.setRangeWithMargins(0.0d, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("", "", "orange", "");
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        try {
            java.lang.Number number5 = taskSeriesCollection0.getEndValue(0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        try {
            java.lang.Number number6 = taskSeriesCollection0.getValue((java.lang.Comparable) '#', (java.lang.Comparable) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor5 = itemLabelPosition4.getTextAnchor();
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = org.jfree.chart.text.TextUtilities.drawAlignedString("", graphics2D1, (float) 255, 0.0f, textAnchor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date1 = null;
        try {
            long long2 = segmentedTimeline0.toTimelineValue(date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        try {
            java.lang.Comparable comparable4 = taskSeriesCollection0.getColumnKey(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) -1, (float) (short) -1, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-253) + "'", int3 == (-253));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        java.lang.String str1 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.NEGATIVE" + "'", str1.equals("RangeType.NEGATIVE"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = barRenderer0.initialise(graphics2D1, rectangle2D2, categoryPlot3, 4, plotRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Paint paint4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D1.setBaseItemLabelPaint(paint4, true);
        java.awt.Shape shape9 = stackedBarRenderer3D1.getItemShape(1, (int) (short) 0);
        boolean boolean10 = sortOrder0.equals((java.lang.Object) 1);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, 8.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.lang.Boolean boolean4 = stackedBarRenderer3D0.getSeriesCreateEntities((int) (short) 1);
        double double5 = stackedBarRenderer3D0.getUpperClip();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = stackedBarRenderer3D0.getSeriesItemLabelGenerator((int) (byte) 100);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = stackedBarRenderer3D0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator8);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        java.util.Date date2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        try {
            double double5 = dateAxis0.dateToJava2D(date2, rectangle2D3, rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean4 = spreadsheetDate1.equals((java.lang.Object) categoryLabelPositions3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = categoryLabelPositions3.getLabelPosition(rectangleEdge5);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(categoryLabelPosition6);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(100);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("({0}, {1}) = {3} - {4}");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name ({0}, {1}) = {3} - {4}, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 9, (double) (short) 100);
        org.jfree.chart.block.BlockContainer blockContainer5 = null;
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range11 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType12 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) 10, range8, lengthConstraintType9, (double) (byte) 1, range11, lengthConstraintType12);
        try {
            org.jfree.chart.util.Size2D size2D14 = flowArrangement4.arrange(blockContainer5, graphics2D6, rectangleConstraint13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertNotNull(lengthConstraintType12);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) true);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = null;
        try {
            org.jfree.chart.block.LineBorder lineBorder3 = new org.jfree.chart.block.LineBorder(paint0, stroke1, rectangleInsets2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.lang.Boolean boolean4 = stackedBarRenderer3D0.getSeriesCreateEntities((int) (short) 1);
        double double5 = stackedBarRenderer3D0.getUpperClip();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        try {
            stackedBarRenderer3D0.setPlot(categoryPlot6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        try {
            java.lang.Number number5 = taskSeriesCollection0.getEndValue(4, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = minMaxCategoryRenderer0.getItemLabelGenerator((int) (short) 100, (int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor5 = itemLabelPosition4.getTextAnchor();
        double double6 = itemLabelPosition4.getAngle();
        minMaxCategoryRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition4);
        boolean boolean8 = minMaxCategoryRenderer0.isDrawLines();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection15 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection15, true);
        try {
            minMaxCategoryRenderer0.drawItem(graphics2D9, categoryItemRendererState10, rectangle2D11, categoryPlot12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.data.category.CategoryDataset) taskSeriesCollection15, (int) ' ', (int) ' ', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = barRenderer0.getSeriesNegativeItemLabelPosition(11);
        double double3 = itemLabelPosition2.getAngle();
        org.junit.Assert.assertNotNull(itemLabelPosition2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeColumn((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.awt.Color color0 = java.awt.Color.orange;
        java.lang.String str1 = org.jfree.chart.util.PaintUtilities.colorToString(color0);
        java.awt.color.ColorSpace colorSpace2 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "orange" + "'", str1.equals("orange"));
        org.junit.Assert.assertNotNull(colorSpace2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot4.setBaseSectionPaint(paint5);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace10 = dateAxis0.reserveSpace(graphics2D3, (org.jfree.chart.plot.Plot) piePlot4, rectangle2D7, rectangleEdge8, axisSpace9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 100.0f, (double) (byte) 10);
        java.lang.Number number3 = meanAndStandardDeviation2.getMean();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        boolean boolean5 = meanAndStandardDeviation2.equals((java.lang.Object) textBlockAnchor4);
        java.lang.Number number6 = meanAndStandardDeviation2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.0d + "'", number6.equals(10.0d));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        double double1 = levelRenderer0.getMaximumItemWidth();
        java.awt.Paint paint4 = levelRenderer0.getItemFillPaint(0, (int) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) 1, (float) 60000L, (float) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-5280) + "'", int3 == (-5280));
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test143");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo0.setLicenceText("");
//        java.lang.String str3 = projectInfo0.toString();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\n" + "'", str3.equals("JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\n"));
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = minMaxCategoryRenderer0.getItemLabelGenerator((int) (short) 100, (int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor5 = itemLabelPosition4.getTextAnchor();
        double double6 = itemLabelPosition4.getAngle();
        minMaxCategoryRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition4);
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition4.getRotationAnchor();
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        double double3 = dateAxis0.getUpperBound();
        boolean boolean4 = dateAxis0.isTickLabelsVisible();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        dateAxis0.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline8);
        java.util.Date date10 = null;
        try {
            segmentedTimeline8.addBaseTimelineException(date10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceText("");
        projectInfo0.setLicenceText("orange");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.setAxisLineVisible(false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("({0}, {1}) = {3} - {4}");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (short) 1, (double) ' ', rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.String str1 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE" + "'", str1.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("RangeType.NEGATIVE", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        java.lang.String str1 = dateTickMarkPosition0.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickMarkPosition.END" + "'", str1.equals("DateTickMarkPosition.END"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            java.lang.Comparable comparable2 = defaultBoxAndWhiskerCategoryDataset0.getRowKey(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        try {
            axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis2, rectangleEdge3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'edge' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = minMaxCategoryRenderer0.getItemLabelGenerator((int) (short) 100, (int) 'a');
        javax.swing.Icon icon4 = null;
        try {
            minMaxCategoryRenderer0.setMinIcon(icon4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'icon' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.CENTER_RIGHT" + "'", str1.equals("TextBlockAnchor.CENTER_RIGHT"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            java.lang.Comparable comparable2 = keyedObjects2D0.getRowKey((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.awt.Stroke stroke0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        stackedBarRenderer3D4.setBaseToolTipGenerator(categoryToolTipGenerator7);
        stackedBarRenderer3D4.setItemMargin((-1.0d));
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D4.setSeriesOutlineStroke(3, stroke12, true);
        stackedBarRenderer3D1.setBaseOutlineStroke(stroke12, true);
        int int17 = month0.compareTo((java.lang.Object) stackedBarRenderer3D1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = stackedBarRenderer3D1.getSeriesURLGenerator(10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(categoryURLGenerator19);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        java.awt.Shape shape8 = stackedBarRenderer3D0.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        java.awt.Shape shape10 = legendItemEntity9.getArea();
        java.lang.String str11 = legendItemEntity9.toString();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str11.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'defaultGroup' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(2958465, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        stackedBarRenderer3D0.setItemMargin((-1.0d));
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D0.getToolTipGenerator((int) (byte) 0, 0);
        stackedBarRenderer3D0.setAutoPopulateSeriesOutlineStroke(false);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            stackedBarRenderer3D0.drawDomainGridline(graphics2D12, categoryPlot13, rectangle2D14, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Font font3 = piePlot0.getLabelFont();
        float float4 = piePlot0.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo6 = new org.jfree.chart.ui.BasicProjectInfo("orange", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}", "");
        boolean boolean7 = lengthConstraintType0.equals((java.lang.Object) "({0}, {1}) = {3} - {4}");
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot2.setBaseSectionPaint(paint3);
        java.awt.Font font5 = piePlot2.getLabelFont();
        boolean boolean6 = piePlot2.isSubplot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot2);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean9 = numberAxis1.equals((java.lang.Object) color8);
        try {
            numberAxis1.setRangeWithMargins(0.0d, (double) (-14336));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-14336.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean4 = spreadsheetDate1.equals((java.lang.Object) categoryLabelPositions3);
        org.jfree.data.time.SerialDate serialDate5 = null;
        try {
            boolean boolean6 = spreadsheetDate1.isBefore(serialDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        java.lang.Comparable comparable3 = null;
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier(comparable3, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (double) 10L);
        org.jfree.chart.axis.AxisCollection axisCollection9 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list10 = axisCollection9.getAxesAtBottom();
        try {
            defaultBoxAndWhiskerCategoryDataset0.add(list10, (java.lang.Comparable) (short) 100, (java.lang.Comparable) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (Infinity) <= upper (-Infinity).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 9, (double) (short) 100);
        flowArrangement4.clear();
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D2.setBase((double) 1.0f);
        java.lang.Boolean boolean6 = stackedBarRenderer3D2.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font9 = stackedBarRenderer3D2.getItemLabelFont((int) ' ', (int) (short) -1);
        boolean boolean10 = rectangleAnchor1.equals((java.lang.Object) ' ');
        try {
            java.awt.geom.Point2D point2D11 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer3 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = minMaxCategoryRenderer3.getItemLabelGenerator((int) (short) 100, (int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getTextAnchor();
        double double9 = itemLabelPosition7.getAngle();
        minMaxCategoryRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition7);
        stackedBarRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition7);
        stackedBarRenderer3D0.setRenderAsPercentages(true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("TextBlockAnchor.CENTER_RIGHT", "DateTickMarkPosition.END", "JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\n", "UnitType.RELATIVE", "DateTickMarkPosition.END");
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 11);
        boolean boolean2 = categoryMarker1.getDrawAsLine();
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            categoryMarker1.setLabelTextAnchor(textAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {2}" + "'", str0.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (short) 0, (int) (short) 100);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long8 = segmentedTimeline7.getSegmentsExcludedSize();
        segmentedTimeline7.setAdjustForDaylightSaving(true);
        try {
            segmentedTimeline3.setBaseTimeline(segmentedTimeline7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-4L) + "'", long8 == (-4L));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.lang.Boolean boolean5 = stackedBarRenderer3D1.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font8 = stackedBarRenderer3D1.getItemLabelFont((int) ' ', (int) (short) -1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        int int10 = color9.getAlpha();
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("LegendItemEntity: seriesKey=null, dataset=null", font8, (java.awt.Paint) color9, (float) 2958465, 255, textMeasurer13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.getCeilingTickUnit((double) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 3, 0.0f, (float) 1L);
        piePlot0.setLegendItemShape(shape4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot0.getLabelGenerator();
        piePlot0.setIgnoreNullValues(true);
        int int13 = piePlot0.getPieIndex();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            piePlot0.drawOutline(graphics2D14, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        java.lang.Comparable comparable3 = null;
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier(comparable3, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        try {
            java.lang.Number number9 = defaultBoxAndWhiskerCategoryDataset0.getMinOutlier(9, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("hi!");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection4, true);
        taskSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) taskSeriesCollection4);
        try {
            java.lang.Number number11 = taskSeriesCollection4.getEndValue((java.lang.Comparable) 0.05d, (java.lang.Comparable) (-1.0f), 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.lang.Boolean boolean5 = stackedBarRenderer3D1.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font8 = stackedBarRenderer3D1.getItemLabelFont((int) ' ', (int) (short) -1);
        boolean boolean9 = rectangleAnchor0.equals((java.lang.Object) ' ');
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType11 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor10, categoryLabelWidthType11, (float) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.function.Function2D function2D0 = null;
        java.lang.Comparable comparable4 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 0.2d, (double) 7, (int) 'a', comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 11);
        boolean boolean2 = categoryMarker1.getDrawAsLine();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = null;
        try {
            categoryMarker1.setLabelOffsetType(lengthAdjustmentType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, 8.0d, (float) 0, 1.0f);
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.removePropertyChangeListener(propertyChangeListener2);
        boolean boolean4 = taskSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double[] doubleArray5 = new double[] { 2, (-1), 4, 0, (-1) };
        double[] doubleArray11 = new double[] { 2, (-1), 4, 0, (-1) };
        double[] doubleArray17 = new double[] { 2, (-1), 4, 0, (-1) };
        double[] doubleArray23 = new double[] { 2, (-1), 4, 0, (-1) };
        double[] doubleArray29 = new double[] { 2, (-1), 4, 0, (-1) };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        double[] doubleArray33 = new double[] { 2, 4 };
        double[] doubleArray36 = new double[] { 2, 4 };
        double[] doubleArray39 = new double[] { 2, 4 };
        double[][] doubleArray40 = new double[][] { doubleArray33, doubleArray36, doubleArray39 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset41 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray30, doubleArray40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 9, (double) (short) 100);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range7 = defaultBoxAndWhiskerCategoryDataset5.getRangeBounds(false);
        java.lang.Comparable comparable8 = null;
        java.lang.Number number10 = defaultBoxAndWhiskerCategoryDataset5.getMaxOutlier(comparable8, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str14 = spreadsheetDate13.getDescription();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset5, (java.lang.Comparable) str14);
        try {
            java.lang.Comparable comparable17 = defaultBoxAndWhiskerCategoryDataset5.getColumnKey((-14336));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        taskSeriesCollection0.addChangeListener(datasetChangeListener3);
        try {
            java.lang.Number number8 = taskSeriesCollection0.getEndValue((-14336), 1900, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(3, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(false);
        boolean boolean3 = dateAxis0.isNegativeArrowVisible();
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot4.setBaseSectionPaint(paint5);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot4);
        piePlot4.setPieIndex((int) '4');
        piePlot4.zoom(100.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) '4', (double) 10);
        stackedBarRenderer3D2.setAutoPopulateSeriesFillPaint(true);
        stackedBarRenderer3D2.setMinimumBarLength((double) 10L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long4 = segmentedTimeline3.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long10 = segmentedTimeline9.getSegmentsExcludedSize();
        java.util.Date date12 = segmentedTimeline9.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long17 = segmentedTimeline16.getSegmentsExcludedSize();
        java.util.Date date19 = segmentedTimeline16.getDate((long) 7);
        boolean boolean20 = segmentedTimeline5.containsDomainRange(date12, date19);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline3.getSegment(date19);
        boolean boolean22 = segmentedTimeline3.getAdjustForDaylightSaving();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-4L) + "'", long4 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-4L) + "'", long10 == (-4L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-4L) + "'", long17 == (-4L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(segment21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(0, (-14336), (-14336));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        int int5 = month0.compareTo((java.lang.Object) font4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range3 = defaultBoxAndWhiskerCategoryDataset1.getRangeBounds(false);
        java.lang.Comparable comparable4 = null;
        java.lang.Number number6 = defaultBoxAndWhiskerCategoryDataset1.getMaxOutlier(comparable4, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset1);
        boolean boolean8 = blockBorder0.equals((java.lang.Object) defaultBoxAndWhiskerCategoryDataset1);
        int int10 = defaultBoxAndWhiskerCategoryDataset1.getRowIndex((java.lang.Comparable) 4);
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem11 = null;
        java.lang.Comparable comparable12 = null;
        try {
            defaultBoxAndWhiskerCategoryDataset1.add(boxAndWhiskerItem11, comparable12, (java.lang.Comparable) "TextBlockAnchor.CENTER_RIGHT");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        stackedBarRenderer3D4.setBaseToolTipGenerator(categoryToolTipGenerator7);
        stackedBarRenderer3D4.setItemMargin((-1.0d));
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D4.setSeriesOutlineStroke(3, stroke12, true);
        stackedBarRenderer3D1.setBaseOutlineStroke(stroke12, true);
        int int17 = month0.compareTo((java.lang.Object) stackedBarRenderer3D1);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D19.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D22.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator25 = null;
        stackedBarRenderer3D22.setBaseToolTipGenerator(categoryToolTipGenerator25);
        stackedBarRenderer3D22.setItemMargin((-1.0d));
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D22.setSeriesOutlineStroke(3, stroke30, true);
        stackedBarRenderer3D19.setBaseOutlineStroke(stroke30, true);
        int int35 = month18.compareTo((java.lang.Object) stackedBarRenderer3D19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month18.next();
        boolean boolean37 = month0.equals((java.lang.Object) month18);
        long long38 = month0.getLastMillisecond();
        java.util.Calendar calendar39 = null;
        try {
            long long40 = month0.getFirstMillisecond(calendar39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1561964399999L + "'", long38 == 1561964399999L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("", font1);
        java.awt.Graphics2D graphics2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textLine2.calculateDimensions(graphics2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        stackedBarRenderer3D4.setBaseToolTipGenerator(categoryToolTipGenerator7);
        stackedBarRenderer3D4.setItemMargin((-1.0d));
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D4.setSeriesOutlineStroke(3, stroke12, true);
        stackedBarRenderer3D1.setBaseOutlineStroke(stroke12, true);
        int int17 = month0.compareTo((java.lang.Object) stackedBarRenderer3D1);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone24 = dateAxis23.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource25 = dateAxis23.getStandardTickUnits();
        double double26 = dateAxis23.getUpperBound();
        boolean boolean27 = dateAxis23.isTickLabelsVisible();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        dateAxis23.setTickMarkPaint((java.awt.Paint) color28);
        dateAxis23.setAxisLineVisible(true);
        dateAxis23.setNegativeArrowVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        try {
            stackedBarRenderer3D1.drawItem(graphics2D18, categoryItemRendererState19, rectangle2D20, categoryPlot21, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D22, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryDataset34, 10, 9, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(tickUnitSource25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        stackedBarRenderer3D0.setItemMargin((-1.0d));
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D0.getToolTipGenerator((int) (byte) 0, 0);
        java.awt.Shape shape10 = stackedBarRenderer3D0.getBaseShape();
        int int11 = stackedBarRenderer3D0.getRowCount();
        java.awt.Paint paint13 = stackedBarRenderer3D0.getSeriesFillPaint(1);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.VERTICAL" + "'", str1.equals("GradientPaintTransformType.VERTICAL"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 11);
        boolean boolean2 = categoryMarker1.getDrawAsLine();
        java.awt.Font font3 = categoryMarker1.getLabelFont();
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            categoryMarker1.setLabelTextAnchor(textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        int int0 = org.jfree.chart.axis.DateTickUnit.SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long9 = segmentedTimeline8.getSegmentsExcludedSize();
        java.util.Date date11 = segmentedTimeline8.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline15 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long16 = segmentedTimeline15.getSegmentsExcludedSize();
        java.util.Date date18 = segmentedTimeline15.getDate((long) 7);
        boolean boolean19 = segmentedTimeline4.containsDomainRange(date11, date18);
        java.lang.Number number20 = defaultBoxAndWhiskerCategoryDataset0.getMaxRegularValue((java.lang.Comparable) ' ', (java.lang.Comparable) date11);
        java.lang.Number number23 = defaultBoxAndWhiskerCategoryDataset0.getQ3Value((java.lang.Comparable) 8.0d, (java.lang.Comparable) 6);
        try {
            java.util.List list26 = defaultBoxAndWhiskerCategoryDataset0.getOutliers((int) ' ', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-4L) + "'", long9 == (-4L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-4L) + "'", long16 == (-4L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertNull(number23);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator6);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = null;
        stackedBarRenderer3D0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator8);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator1 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.text.NumberFormat numberFormat2 = standardCategoryToolTipGenerator1.getNumberFormat();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator3 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("({0}, {1}) = {3} - {4}", numberFormat2);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset4 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range6 = defaultBoxAndWhiskerCategoryDataset4.getRangeBounds(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long13 = segmentedTimeline12.getSegmentsExcludedSize();
        java.util.Date date15 = segmentedTimeline12.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline19 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long20 = segmentedTimeline19.getSegmentsExcludedSize();
        java.util.Date date22 = segmentedTimeline19.getDate((long) 7);
        boolean boolean23 = segmentedTimeline8.containsDomainRange(date15, date22);
        java.lang.Number number24 = defaultBoxAndWhiskerCategoryDataset4.getMaxRegularValue((java.lang.Comparable) ' ', (java.lang.Comparable) date15);
        try {
            java.lang.String str26 = standardCategoryToolTipGenerator3.generateRowLabel((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset4, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-4L) + "'", long13 == (-4L));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-4L) + "'", long20 == (-4L));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(number24);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long4 = segmentedTimeline3.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long10 = segmentedTimeline9.getSegmentsExcludedSize();
        java.util.Date date12 = segmentedTimeline9.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long17 = segmentedTimeline16.getSegmentsExcludedSize();
        java.util.Date date19 = segmentedTimeline16.getDate((long) 7);
        boolean boolean20 = segmentedTimeline5.containsDomainRange(date12, date19);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline3.getSegment(date19);
        try {
            int int23 = segment21.compareTo((java.lang.Object) "LegendItemEntity: seriesKey=null, dataset=null");
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to org.jfree.chart.axis.SegmentedTimeline$Segment");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-4L) + "'", long4 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-4L) + "'", long10 == (-4L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-4L) + "'", long17 == (-4L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(segment21);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) '4', (double) 10);
        stackedBarRenderer3D2.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint7 = stackedBarRenderer3D2.getItemLabelPaint(0, 12);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10.0f, jFreeChart1, chartChangeEventType2);
        java.lang.Object obj4 = chartChangeEvent3.getSource();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        chartChangeEvent3.setChart(jFreeChart5);
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + 10.0f + "'", obj4.equals(10.0f));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        stackedBarRenderer3D1.setBaseToolTipGenerator(categoryToolTipGenerator4);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D1.setSeriesOutlineStroke((int) ' ', stroke7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape11, (double) 3, 0.0f, (float) 1L);
        stackedBarRenderer3D1.setSeriesShape(0, shape15);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape15, 100.0d, (float) 0L, (float) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 60000L, (double) 7, false);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState9 = stackedBarRenderer3D3.initialise(graphics2D4, rectangle2D5, categoryPlot6, 0, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) '4', (double) 10);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = stackedBarRenderer3D2.getLegendItems();
        stackedBarRenderer3D2.setSeriesItemLabelsVisible(7, false);
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        java.lang.Comparable comparable3 = null;
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier(comparable3, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        java.lang.String str7 = range6.toString();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Range[0.0,0.0]" + "'", str7.equals("Range[0.0,0.0]"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) '4', (double) 10);
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        stackedBarRenderer3D2.setSeriesItemLabelPaint(9, paint4, true);
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D(0.0d, (double) '#');
        double double10 = size2D9.height;
        boolean boolean11 = stackedBarRenderer3D2.equals((java.lang.Object) size2D9);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 35.0d + "'", double10 == 35.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("({0}, {1}) = {2}", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        boolean boolean2 = gradientPaintTransformType0.equals((java.lang.Object) textBlockAnchor1);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 10.0f, 0.0f, (double) 10, (float) (byte) 1, (float) (-4L));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        org.junit.Assert.assertNotNull(layer0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        java.lang.Comparable comparable3 = null;
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier(comparable3, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (double) 10L);
        try {
            java.lang.Number number11 = defaultBoxAndWhiskerCategoryDataset0.getMedianValue((int) '#', 192);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.0d, (double) '#');
        double double3 = size2D2.height;
        size2D2.height = (short) 0;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 5);
        java.lang.Class class2 = null;
        try {
            java.util.EventListener[] eventListenerArray3 = valueMarker1.getListeners(class2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        double double3 = dateAxis0.getUpperBound();
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("", font5);
        dateAxis0.setLabelFont(font5);
        dateAxis0.setAutoRangeMinimumSize((double) 2);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TAPER;
        org.junit.Assert.assertNotNull(areaRendererEndType0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\n", "", numberArray2);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str1 = piePlot0.getNoDataMessage();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = piePlot0.getLegendLabelToolTipGenerator();
        java.awt.Paint paint3 = null;
        piePlot0.setLabelBackgroundPaint(paint3);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            blockBorder0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        minMaxCategoryRenderer0.setBaseFillPaint(paint1);
        minMaxCategoryRenderer0.setItemLabelAnchorOffset((double) 100L);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator6 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        try {
            minMaxCategoryRenderer0.setSeriesToolTipGenerator((-5280), (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator6, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            java.lang.Comparable comparable2 = defaultBoxAndWhiskerCategoryDataset0.getColumnKey((-253));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) '4', (double) 10);
        stackedBarRenderer3D2.setAutoPopulateSeriesFillPaint(true);
        boolean boolean7 = stackedBarRenderer3D2.getItemVisible((int) '#', (int) '4');
        double double8 = stackedBarRenderer3D2.getUpperClip();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getLabelOutlineStroke();
        piePlot0.setLabelLinkMargin((double) '#');
        int int4 = piePlot0.getPieIndex();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(7, 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 2, (double) (byte) 100);
        java.awt.Color color3 = java.awt.Color.white;
        intervalMarker2.setOutlinePaint((java.awt.Paint) color3);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        minMaxCategoryRenderer0.setBaseFillPaint(paint1);
        minMaxCategoryRenderer0.setItemLabelAnchorOffset((double) 100L);
        boolean boolean5 = minMaxCategoryRenderer0.isDrawLines();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot2.setBaseSectionPaint(paint3);
        java.awt.Font font5 = piePlot2.getLabelFont();
        boolean boolean6 = piePlot2.isSubplot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot2);
        boolean boolean8 = piePlot2.getSectionOutlinesVisible();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.awt.Paint paint0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str1 = piePlot0.getNoDataMessage();
        java.awt.Image image2 = null;
        piePlot0.setBackgroundImage(image2);
        double double4 = piePlot0.getMaximumLabelWidth();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.text.NumberFormat numberFormat3 = standardCategoryToolTipGenerator2.getNumberFormat();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat3);
        tickUnits0.add((org.jfree.chart.axis.TickUnit) numberTickUnit4);
        try {
            org.jfree.chart.axis.TickUnit tickUnit7 = tickUnits0.get(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat3);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Font font3 = piePlot0.getLabelFont();
        boolean boolean4 = piePlot0.isSubplot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D5.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        stackedBarRenderer3D5.setBaseToolTipGenerator(categoryToolTipGenerator8);
        stackedBarRenderer3D5.setItemMargin((-1.0d));
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D5.setSeriesOutlineStroke(3, stroke13, true);
        piePlot0.setOutlineStroke(stroke13);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot0.setNoDataMessagePaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D19.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator22 = null;
        stackedBarRenderer3D19.setBaseToolTipGenerator(categoryToolTipGenerator22);
        stackedBarRenderer3D19.setItemMargin((-1.0d));
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = stackedBarRenderer3D19.getToolTipGenerator((int) (byte) 0, 0);
        java.awt.Shape shape29 = stackedBarRenderer3D19.getBaseShape();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator31 = null;
        stackedBarRenderer3D19.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator31);
        java.awt.Paint paint33 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        stackedBarRenderer3D19.setBaseFillPaint(paint33);
        java.awt.Paint paint35 = null;
        java.awt.Color color39 = java.awt.Color.getHSBColor((float) (-1L), 0.0f, (float) 1L);
        try {
            org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer40 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color17, paint33, paint35, (java.awt.Paint) color39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'negativeBarPaint' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(color39);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 3);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("hi!");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection4, true);
        taskSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) taskSeriesCollection4);
        taskSeriesCollection4.removeAll();
        try {
            java.lang.Comparable comparable10 = taskSeriesCollection4.getRowKey(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str3 = spreadsheetDate2.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(10, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 9, (double) (short) 100);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range7 = defaultBoxAndWhiskerCategoryDataset5.getRangeBounds(false);
        java.lang.Comparable comparable8 = null;
        java.lang.Number number10 = defaultBoxAndWhiskerCategoryDataset5.getMaxOutlier(comparable8, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str14 = spreadsheetDate13.getDescription();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset5, (java.lang.Comparable) str14);
        try {
            java.lang.Number number18 = defaultBoxAndWhiskerCategoryDataset5.getMinOutlier(0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font4, (org.jfree.chart.plot.Plot) piePlot5, false);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor11 = null;
        try {
            piePlot5.setLabelDistributor(abstractPieLabelDistributor11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color2);
        java.awt.color.ColorSpace colorSpace4 = color2.getColorSpace();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("orange");
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis6);
        boolean boolean8 = color2.equals((java.lang.Object) dateAxis6);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.axis.AxisCollection axisCollection5 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        dateAxis6.setInverted(false);
        dateAxis6.resizeRange((double) (byte) 10, (double) (byte) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection5.add((org.jfree.chart.axis.Axis) dateAxis6, rectangleEdge13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        try {
            org.jfree.chart.axis.AxisState axisState16 = categoryAxis3D0.draw(graphics2D1, (double) 1.0f, rectangle2D3, rectangle2D4, rectangleEdge13, plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.0d, (double) '#');
        double double3 = size2D2.getWidth();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        java.lang.Comparable comparable3 = null;
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier(comparable3, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (double) 10L);
        try {
            java.lang.Number number11 = defaultBoxAndWhiskerCategoryDataset0.getMedianValue(6, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("hi!");
        org.jfree.data.gantt.Task task2 = null;
        taskSeries1.remove(task2);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        double double3 = dateAxis0.getUpperBound();
        boolean boolean4 = dateAxis0.isTickLabelsVisible();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        dateAxis0.setTickMarkPaint((java.awt.Paint) color5);
        dateAxis0.resizeRange((double) (-1.0f));
        dateAxis0.setTickMarkInsideLength((float) 'a');
        org.jfree.data.Range range11 = null;
        try {
            dateAxis0.setRangeWithMargins(range11, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = minMaxCategoryRenderer0.getItemLabelGenerator((int) (short) 100, (int) 'a');
        java.awt.Paint paint6 = minMaxCategoryRenderer0.getItemPaint((-1), (int) (short) 100);
        javax.swing.Icon icon7 = null;
        try {
            minMaxCategoryRenderer0.setMinIcon(icon7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'icon' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D0.setSeriesOutlineStroke((int) ' ', stroke6);
        stackedBarRenderer3D0.setAutoPopulateSeriesShape(true);
        try {
            stackedBarRenderer3D0.setSeriesItemLabelsVisible((-253), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) (byte) 100, (double) 10.0f);
        boolean boolean6 = textBlockAnchor0.equals((java.lang.Object) columnArrangement5);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font4, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Paint paint11 = jFreeChart10.getBorderPaint();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart10.addProgressListener(chartProgressListener13);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent15 = null;
        try {
            jFreeChart10.titleChanged(titleChangeEvent15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(11);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = levelRenderer0.initialise(graphics2D1, rectangle2D2, categoryPlot3, 500, plotRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor1 = categoryLabelPosition0.getRotationAnchor();
        java.lang.Object obj2 = null;
        boolean boolean3 = textAnchor1.equals(obj2);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.lang.Boolean boolean2 = stackedBarRenderer3D0.getSeriesCreateEntities((int) (short) -1);
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.awt.Paint paint0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.awt.Color color0 = null;
        try {
            java.lang.String str1 = org.jfree.chart.util.PaintUtilities.colorToString(color0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot4.setBaseSectionPaint(paint5);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape8, (double) 3, 0.0f, (float) 1L);
        piePlot4.setLegendItemShape(shape8);
        java.awt.Color color14 = java.awt.Color.darkGray;
        int int15 = color14.getAlpha();
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot16.setBaseSectionPaint(paint17);
        java.awt.Font font19 = piePlot16.getLabelFont();
        boolean boolean20 = piePlot16.isSubplot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D21.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = null;
        stackedBarRenderer3D21.setBaseToolTipGenerator(categoryToolTipGenerator24);
        stackedBarRenderer3D21.setItemMargin((-1.0d));
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D21.setSeriesOutlineStroke(3, stroke29, true);
        piePlot16.setOutlineStroke(stroke29);
        java.awt.Paint paint33 = null;
        try {
            org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem(attributedString0, "({0}, {1}) = {3} - {4}", "Layer.FOREGROUND", "DateTickMarkPosition.END", shape8, (java.awt.Paint) color14, stroke29, paint33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 255 + "'", int15 == 255);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        java.lang.Comparable comparable3 = null;
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier(comparable3, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (double) 10L);
        try {
            java.lang.Number number11 = defaultBoxAndWhiskerCategoryDataset0.getMeanValue(6, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font4, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Paint paint11 = jFreeChart10.getBorderPaint();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart10.addProgressListener(chartProgressListener13);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        try {
            jFreeChart10.plotChanged(plotChangeEvent15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("TextBlockAnchor.CENTER_RIGHT", graphics2D1, (float) 9, (float) (byte) 10, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("Range[0.0,0.0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name Range[0.0,0.0], locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color2);
        java.lang.String str5 = categoryAxis3D0.getCategoryLabelToolTip((java.lang.Comparable) 4.0d);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.axis.AxisCollection axisCollection10 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone12 = dateAxis11.getTimeZone();
        dateAxis11.setInverted(false);
        dateAxis11.resizeRange((double) (byte) 10, (double) (byte) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection10.add((org.jfree.chart.axis.Axis) dateAxis11, rectangleEdge18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        try {
            org.jfree.chart.axis.AxisState axisState21 = categoryAxis3D0.draw(graphics2D6, (double) 8, rectangle2D8, rectangle2D9, rectangleEdge18, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.lang.Boolean boolean4 = stackedBarRenderer3D0.getSeriesCreateEntities((int) (short) 1);
        stackedBarRenderer3D0.setSeriesItemLabelsVisible((int) '4', false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = stackedBarRenderer3D0.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = stackedBarRenderer3D0.getPlot();
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(drawingSupplier8);
        org.junit.Assert.assertNull(categoryPlot9);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long4 = segmentedTimeline3.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long9 = segmentedTimeline8.getSegmentsExcludedSize();
        java.util.Date date11 = segmentedTimeline8.getDate((long) 7);
        long long12 = segmentedTimeline3.getTime(date11);
        long long14 = segmentedTimeline3.getTimeFromLong((long) 4);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-4L) + "'", long4 == (-4L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-4L) + "'", long9 == (-4L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 7L + "'", long12 == 7L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 4L + "'", long14 == 4L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str3 = spreadsheetDate2.getDescription();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean5 = spreadsheetDate2.equals((java.lang.Object) categoryLabelPositions4);
        int int6 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) spreadsheetDate2);
        try {
            java.lang.Number number9 = taskSeriesCollection0.getValue((java.lang.Comparable) (byte) -1, (java.lang.Comparable) (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setDepthFactor((double) (short) -1);
        org.jfree.data.general.DatasetGroup datasetGroup3 = piePlot3D0.getDatasetGroup();
        boolean boolean4 = piePlot3D0.isOutlineVisible();
        org.junit.Assert.assertNull(datasetGroup3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) 10, range1, lengthConstraintType2, (double) (byte) 1, range4, lengthConstraintType5);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint6.toUnconstrainedHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint6.toFixedWidth((double) 255);
        org.jfree.data.Range range10 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range12 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType13 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range15 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType16 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint((double) 10, range12, lengthConstraintType13, (double) (byte) 1, range15, lengthConstraintType16);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint17.toUnconstrainedHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint17.toFixedWidth((double) 255);
        boolean boolean21 = range10.equals((java.lang.Object) 255);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = rectangleConstraint6.toRangeWidth(range10);
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(lengthConstraintType13);
        org.junit.Assert.assertNotNull(lengthConstraintType16);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
        org.junit.Assert.assertNotNull(rectangleConstraint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot1.setBaseSectionPaint(paint2);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape5, (double) 3, 0.0f, (float) 1L);
        piePlot1.setLegendItemShape(shape5);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D12.setBase((double) 1.0f);
        java.lang.Boolean boolean16 = stackedBarRenderer3D12.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font19 = stackedBarRenderer3D12.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font19);
        piePlot1.setLabelFont(font19);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot22.setBaseSectionPaint(paint23);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape26, (double) 3, 0.0f, (float) 1L);
        piePlot22.setLegendItemShape(shape26);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D33.setBase((double) 1.0f);
        java.lang.Boolean boolean37 = stackedBarRenderer3D33.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font40 = stackedBarRenderer3D33.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine41 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font40);
        piePlot22.setLabelFont(font40);
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_RED;
        piePlot22.setNoDataMessagePaint((java.awt.Paint) color43);
        org.jfree.chart.block.LabelBlock labelBlock45 = new org.jfree.chart.block.LabelBlock("orange", font19, (java.awt.Paint) color43);
        int int46 = color43.getRGB();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNull(boolean37);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-49088) + "'", int46 == (-49088));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 3, 0.0f, (float) 1L);
        piePlot0.setLegendItemShape(shape4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot0.getLabelGenerator();
        piePlot0.setIgnoreNullValues(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot0.getInsets();
        double double15 = rectangleInsets13.extendHeight((double) 100);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 108.0d + "'", double15 == 108.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("orange");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2, false, false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("hi!");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection4, true);
        taskSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) taskSeriesCollection4);
        taskSeriesCollection4.removeAll();
        try {
            taskSeriesCollection4.remove(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: TaskSeriesCollection.remove(): index outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Font font3 = piePlot0.getLabelFont();
        boolean boolean4 = piePlot0.isSubplot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D5.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        stackedBarRenderer3D5.setBaseToolTipGenerator(categoryToolTipGenerator8);
        stackedBarRenderer3D5.setItemMargin((-1.0d));
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D5.setSeriesOutlineStroke(3, stroke13, true);
        piePlot0.setOutlineStroke(stroke13);
        boolean boolean17 = piePlot0.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator18 = piePlot0.getURLGenerator();
        double double19 = piePlot0.getInteriorGap();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(pieURLGenerator18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.25d + "'", double19 == 0.25d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceText("");
        java.util.List list3 = projectInfo0.getContributors();
        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
        projectInfo4.setLicenceText("");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo4);
        java.awt.Image image8 = projectInfo4.getLogo();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(projectInfo4);
        org.junit.Assert.assertNotNull(image8);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font4, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Paint paint11 = jFreeChart10.getBorderPaint();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart10.addProgressListener(chartProgressListener13);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone17 = dateAxis16.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis16.getStandardTickUnits();
        double double19 = dateAxis16.getUpperBound();
        java.awt.Font font21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("", font21);
        dateAxis16.setLabelFont(font21);
        boolean boolean24 = categoryAnchor15.equals((java.lang.Object) dateAxis16);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor25 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        boolean boolean26 = categoryAnchor15.equals((java.lang.Object) textBlockAnchor25);
        try {
            jFreeChart10.setTextAntiAlias((java.lang.Object) boolean26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: false incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Font font3 = piePlot0.getLabelFont();
        double double4 = piePlot0.getShadowYOffset();
        java.awt.Paint paint5 = piePlot0.getNoDataMessagePaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D6.setBase((double) 1.0f);
        java.lang.Boolean boolean10 = stackedBarRenderer3D6.getSeriesCreateEntities((int) (short) 1);
        double double11 = stackedBarRenderer3D6.getUpperClip();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = stackedBarRenderer3D6.getSeriesItemLabelGenerator((int) (byte) 100);
        java.awt.Paint paint16 = stackedBarRenderer3D6.getItemPaint((int) (short) 100, (int) (short) 10);
        piePlot0.setLabelOutlinePaint(paint16);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 9, (double) (short) 100);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range7 = defaultBoxAndWhiskerCategoryDataset5.getRangeBounds(false);
        java.lang.Comparable comparable8 = null;
        java.lang.Number number10 = defaultBoxAndWhiskerCategoryDataset5.getMaxOutlier(comparable8, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str14 = spreadsheetDate13.getDescription();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset5, (java.lang.Comparable) str14);
        legendItemBlockContainer15.setURLText("orange");
        java.lang.String str18 = legendItemBlockContainer15.getToolTipText();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D5.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color7);
        java.lang.String str10 = categoryAxis3D5.getCategoryLabelToolTip((java.lang.Comparable) 4.0d);
        categoryAxis3D5.configure();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone14 = dateAxis13.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = dateAxis13.getStandardTickUnits();
        double double16 = dateAxis13.getUpperBound();
        java.awt.Font font18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine19 = new org.jfree.chart.text.TextLine("", font18);
        dateAxis13.setLabelFont(font18);
        boolean boolean21 = categoryAnchor12.equals((java.lang.Object) dateAxis13);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection22 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = null;
        taskSeriesCollection22.seriesChanged(seriesChangeEvent23);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener25 = null;
        taskSeriesCollection22.addChangeListener(datasetChangeListener25);
        try {
            layeredBarRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D3, categoryPlot4, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D5, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.data.category.CategoryDataset) taskSeriesCollection22, 9, 3, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(tickUnitSource15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        java.lang.Comparable comparable3 = null;
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier(comparable3, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (double) 10L);
        try {
            org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem11 = defaultBoxAndWhiskerCategoryDataset0.getItem((int) '#', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("TextBlockAnchor.CENTER_RIGHT", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        outlierListCollection0.setHighFarOut(true);
        outlierListCollection0.setHighFarOut(true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 9, (double) (short) 100);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range7 = defaultBoxAndWhiskerCategoryDataset5.getRangeBounds(false);
        java.lang.Comparable comparable8 = null;
        java.lang.Number number10 = defaultBoxAndWhiskerCategoryDataset5.getMaxOutlier(comparable8, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str14 = spreadsheetDate13.getDescription();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset5, (java.lang.Comparable) str14);
        try {
            java.lang.Number number18 = defaultBoxAndWhiskerCategoryDataset5.getMeanValue((int) '#', 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font4, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Paint paint11 = jFreeChart10.getBorderPaint();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent13 = null;
        try {
            jFreeChart10.titleChanged(titleChangeEvent13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        org.jfree.data.Range range3 = dateAxis0.getDefaultAutoRange();
        dateAxis0.setNegativeArrowVisible(true);
        java.awt.Shape shape6 = dateAxis0.getDownArrow();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("orange");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D7.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        stackedBarRenderer3D7.setBaseToolTipGenerator(categoryToolTipGenerator10);
        stackedBarRenderer3D7.setItemMargin((-1.0d));
        boolean boolean14 = stackedBarRenderer3D7.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape16, (double) 100L, (float) 0, (float) 10L);
        stackedBarRenderer3D7.setBaseShape(shape20, true);
        dateAxis6.setDownArrow(shape20);
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot25.setBaseSectionPaint(paint26);
        java.awt.Font font28 = piePlot25.getLabelFont();
        double double29 = piePlot25.getShadowYOffset();
        java.awt.Paint paint30 = piePlot25.getNoDataMessagePaint();
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Stroke stroke33 = null;
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("orange");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D37 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D37.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator40 = null;
        stackedBarRenderer3D37.setBaseToolTipGenerator(categoryToolTipGenerator40);
        stackedBarRenderer3D37.setItemMargin((-1.0d));
        boolean boolean44 = stackedBarRenderer3D37.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape46 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape50 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape46, (double) 100L, (float) 0, (float) 10L);
        stackedBarRenderer3D37.setBaseShape(shape50, true);
        dateAxis36.setDownArrow(shape50);
        org.jfree.chart.plot.IntervalMarker intervalMarker56 = new org.jfree.chart.plot.IntervalMarker((double) 2, (double) (byte) 100);
        java.awt.Stroke stroke57 = intervalMarker56.getStroke();
        java.awt.Paint paint58 = null;
        try {
            org.jfree.chart.LegendItem legendItem59 = new org.jfree.chart.LegendItem(attributedString0, "LegendItemEntity: seriesKey=null, dataset=null", "Layer.FOREGROUND", "RangeType.FULL", true, shape20, true, paint30, true, (java.awt.Paint) color32, stroke33, true, shape50, stroke57, paint58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 4.0d + "'", double29 == 4.0d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(stroke57);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        stackedBarRenderer3D4.setBaseToolTipGenerator(categoryToolTipGenerator7);
        stackedBarRenderer3D4.setItemMargin((-1.0d));
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D4.setSeriesOutlineStroke(3, stroke12, true);
        stackedBarRenderer3D1.setBaseOutlineStroke(stroke12, true);
        int int17 = month0.compareTo((java.lang.Object) stackedBarRenderer3D1);
        java.awt.Paint paint20 = stackedBarRenderer3D1.getItemPaint(4, 7);
        boolean boolean22 = stackedBarRenderer3D1.isSeriesItemLabelsVisible((int) (short) -1);
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot23.setBaseSectionPaint(paint24);
        java.awt.Font font26 = piePlot23.getLabelFont();
        boolean boolean27 = piePlot23.isSubplot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D28 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D28.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator31 = null;
        stackedBarRenderer3D28.setBaseToolTipGenerator(categoryToolTipGenerator31);
        stackedBarRenderer3D28.setItemMargin((-1.0d));
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D28.setSeriesOutlineStroke(3, stroke36, true);
        piePlot23.setOutlineStroke(stroke36);
        java.awt.Color color40 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot23.setNoDataMessagePaint((java.awt.Paint) color40);
        stackedBarRenderer3D1.setWallPaint((java.awt.Paint) color40);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color40);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Font font3 = piePlot0.getLabelFont();
        double double4 = piePlot0.getShadowYOffset();
        java.awt.Paint paint5 = piePlot0.getNoDataMessagePaint();
        java.awt.Paint paint6 = null;
        piePlot0.setLabelOutlinePaint(paint6);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean4 = spreadsheetDate1.equals((java.lang.Object) categoryLabelPositions3);
        try {
            org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate1.getPreviousDayOfWeek(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Font font3 = piePlot0.getLabelFont();
        double double4 = piePlot0.getShadowYOffset();
        java.awt.Paint paint5 = piePlot0.getNoDataMessagePaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = null;
        piePlot0.setToolTipGenerator(pieToolTipGenerator6);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceText("");
        java.util.List list3 = projectInfo0.getContributors();
        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
        projectInfo4.setLicenceText("");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo4);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo("orange", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}", "");
        projectInfo4.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo13);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(projectInfo4);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        stackedBarRenderer3D0.setItemMargin((-1.0d));
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D0.getToolTipGenerator((int) (byte) 0, 0);
        stackedBarRenderer3D0.setAutoPopulateSeriesOutlineStroke(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor14 = itemLabelPosition13.getTextAnchor();
        stackedBarRenderer3D0.setSeriesPositiveItemLabelPosition(100, itemLabelPosition13);
        java.awt.Stroke stroke16 = stackedBarRenderer3D0.getBaseOutlineStroke();
        boolean boolean17 = stackedBarRenderer3D0.isDrawBarOutline();
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        boolean boolean6 = stackedBarRenderer3D0.getAutoPopulateSeriesPaint();
        java.awt.Paint paint7 = stackedBarRenderer3D0.getBasePaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        int int0 = org.jfree.chart.axis.DateTickUnit.YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.lang.Boolean boolean4 = stackedBarRenderer3D0.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font7 = stackedBarRenderer3D0.getItemLabelFont((int) ' ', (int) (short) -1);
        stackedBarRenderer3D0.setItemMargin((double) (short) -1);
        java.awt.Paint paint10 = stackedBarRenderer3D0.getBaseItemLabelPaint();
        double double11 = stackedBarRenderer3D0.getXOffset();
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 12.0d + "'", double11 == 12.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        org.jfree.data.Range range3 = dateAxis0.getDefaultAutoRange();
        dateAxis0.setNegativeArrowVisible(true);
        float float6 = dateAxis0.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj1 = standardGradientPaintTransformer0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Default Group");
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        double double1 = stackedBarRenderer3D0.getYOffset();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer2 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        boolean boolean4 = groupedStackedBarRenderer2.equals((java.lang.Object) (short) 0);
        org.jfree.data.KeyToGroupMap keyToGroupMap5 = new org.jfree.data.KeyToGroupMap();
        groupedStackedBarRenderer2.setSeriesToGroupMap(keyToGroupMap5);
        boolean boolean7 = stackedBarRenderer3D0.equals((java.lang.Object) groupedStackedBarRenderer2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long4 = segmentedTimeline3.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long10 = segmentedTimeline9.getSegmentsExcludedSize();
        java.util.Date date12 = segmentedTimeline9.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long17 = segmentedTimeline16.getSegmentsExcludedSize();
        java.util.Date date19 = segmentedTimeline16.getDate((long) 7);
        boolean boolean20 = segmentedTimeline5.containsDomainRange(date12, date19);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline3.getSegment(date19);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment24 = segment21.intersect((long) 'a', (long) 12);
        try {
            segment24.inc(7L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-4L) + "'", long4 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-4L) + "'", long10 == (-4L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-4L) + "'", long17 == (-4L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(segment21);
        org.junit.Assert.assertNull(segment24);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        java.awt.Shape shape8 = stackedBarRenderer3D0.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        java.awt.Shape shape10 = legendItemEntity9.getArea();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator11 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator12 = null;
        java.lang.String str13 = legendItemEntity9.getImageMapAreaTag(toolTipTagFragmentGenerator11, uRLTagFragmentGenerator12);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        int int0 = org.jfree.chart.axis.DateTickUnit.MINUTE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        dateAxis0.setInverted(false);
        dateAxis0.setVisible(true);
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("ClassContext", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("hi!");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection2, true);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D6.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D9.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        stackedBarRenderer3D9.setBaseToolTipGenerator(categoryToolTipGenerator12);
        stackedBarRenderer3D9.setItemMargin((-1.0d));
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D9.setSeriesOutlineStroke(3, stroke17, true);
        stackedBarRenderer3D6.setBaseOutlineStroke(stroke17, true);
        int int22 = month5.compareTo((java.lang.Object) stackedBarRenderer3D6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month5.next();
        org.jfree.data.gantt.TaskSeries taskSeries24 = taskSeriesCollection2.getSeries((java.lang.Comparable) regularTimePeriod23);
        taskSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) taskSeriesCollection2);
        try {
            java.lang.Number number28 = taskSeriesCollection2.getStartValue((-49088), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNull(taskSeries24);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("GradientPaintTransformType.VERTICAL", graphics2D1, (float) 10L, 0.0f, (double) 9, (float) (byte) -1, (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.lang.Boolean boolean4 = stackedBarRenderer3D0.getSeriesCreateEntities((int) (short) 1);
        double double5 = stackedBarRenderer3D0.getUpperClip();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = stackedBarRenderer3D0.getSeriesItemLabelGenerator((int) (byte) 100);
        java.awt.Paint paint10 = stackedBarRenderer3D0.getItemPaint((int) (short) 100, (int) (short) 10);
        stackedBarRenderer3D0.setBaseCreateEntities(false);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Point2D point2D4 = null;
        org.jfree.chart.plot.PlotState plotState5 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            piePlot3D1.draw(graphics2D2, rectangle2D3, point2D4, plotState5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        int int3 = taskSeriesCollection0.getColumnCount();
        taskSeriesCollection0.validateObject();
        try {
            java.lang.Number number8 = taskSeriesCollection0.getStartValue((int) 'a', 4, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        org.jfree.data.Range range3 = dateAxis0.getDefaultAutoRange();
        org.jfree.data.Range range5 = org.jfree.data.Range.shift(range3, 0.0d);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getLabelOutlineStroke();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer3 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        minMaxCategoryRenderer3.setBaseFillPaint(paint4);
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) 0.2d, paint4);
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.Rotation rotation8 = piePlot7.getDirection();
        piePlot0.setDirection(rotation8);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot0.getDataset();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rotation8);
        org.junit.Assert.assertNull(pieDataset10);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.util.TimeZone timeZone0 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D5.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color7);
        java.lang.String str10 = categoryAxis3D5.getCategoryLabelToolTip((java.lang.Comparable) 4.0d);
        double double11 = categoryAxis3D5.getUpperMargin();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection14 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection14, true);
        int int17 = taskSeriesCollection14.getColumnCount();
        taskSeriesCollection14.validateObject();
        try {
            ganttRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D3, categoryPlot4, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D5, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.data.category.CategoryDataset) taskSeriesCollection14, (-457), (int) (short) 10, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        stackedBarRenderer3D0.setItemMargin((-1.0d));
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D0.setSeriesOutlineStroke(3, stroke8, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = stackedBarRenderer3D0.getBaseNegativeItemLabelPosition();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        minMaxCategoryRenderer0.setBaseFillPaint(paint1);
        javax.swing.Icon icon3 = null;
        try {
            minMaxCategoryRenderer0.setMinIcon(icon3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'icon' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        java.awt.Shape shape8 = stackedBarRenderer3D0.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset12 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range14 = defaultBoxAndWhiskerCategoryDataset12.getRangeBounds(false);
        java.lang.Comparable comparable15 = null;
        java.lang.Number number17 = defaultBoxAndWhiskerCategoryDataset12.getMaxOutlier(comparable15, (java.lang.Comparable) (short) 0);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity20 = new org.jfree.chart.entity.CategoryItemEntity(shape8, "DateTickMarkPosition.END", "TextBlockAnchor.CENTER_RIGHT", (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset12, (java.lang.Comparable) (short) 1, (java.lang.Comparable) "RangeType.NEGATIVE");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator21 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator22 = null;
        try {
            java.lang.String str23 = categoryItemEntity20.getImageMapAreaTag(toolTipTagFragmentGenerator21, uRLTagFragmentGenerator22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNull(number17);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.String str1 = standardCategoryToolTipGenerator0.getLabelFormat();
        java.lang.Object obj2 = null;
        boolean boolean3 = standardCategoryToolTipGenerator0.equals(obj2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "({0}, {1}) = {2}" + "'", str1.equals("({0}, {1}) = {2}"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getRowKeys();
        try {
            java.lang.Object obj4 = keyedObjects2D0.getObject(7, 500);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = new org.jfree.chart.axis.AxisState();
        double double6 = axisState5.getCursor();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            java.util.List list9 = categoryAxis3D0.refreshTicks(graphics2D4, axisState5, rectangle2D7, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.4d, (double) 100, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        dateAxis1.setInverted(false);
        dateAxis1.resizeRange((double) (byte) 10, (double) (byte) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection0.add((org.jfree.chart.axis.Axis) dateAxis1, rectangleEdge8);
        double double10 = dateAxis1.getFixedDimension();
        boolean boolean11 = dateAxis1.isAutoRange();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        stackedBarRenderer3D0.setItemMargin((-1.0d));
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D0.getToolTipGenerator((int) (byte) 0, 0);
        stackedBarRenderer3D0.setAutoPopulateSeriesOutlineStroke(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor14 = itemLabelPosition13.getTextAnchor();
        stackedBarRenderer3D0.setSeriesPositiveItemLabelPosition(100, itemLabelPosition13);
        java.awt.Paint paint16 = stackedBarRenderer3D0.getWallPaint();
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        java.awt.Shape shape8 = stackedBarRenderer3D0.getItemShape(1, (int) (short) 0);
        stackedBarRenderer3D0.setAutoPopulateSeriesOutlinePaint(false);
        java.awt.Paint paint12 = stackedBarRenderer3D0.lookupSeriesOutlinePaint((int) (byte) 100);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline0.setAdjustForDaylightSaving(false);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        boolean boolean2 = groupedStackedBarRenderer0.equals((java.lang.Object) (short) 0);
        boolean boolean3 = groupedStackedBarRenderer0.getRenderAsPercentages();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = minMaxCategoryRenderer0.getItemLabelGenerator((int) (short) 100, (int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor5 = itemLabelPosition4.getTextAnchor();
        double double6 = itemLabelPosition4.getAngle();
        minMaxCategoryRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition4);
        java.awt.Stroke stroke8 = minMaxCategoryRenderer0.getBaseOutlineStroke();
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 5);
        try {
            shapeList0.setShape((-49088), shape3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        stackedBarRenderer3D0.setItemMargin((-1.0d));
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D0.getToolTipGenerator((int) (byte) 0, 0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = stackedBarRenderer3D0.getURLGenerator((-1), 0);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNull(categoryURLGenerator12);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline0.addBaseTimelineExclusions((long) (short) 10, (long) 'a');
        org.junit.Assert.assertNotNull(segmentedTimeline0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 3, 0.0f, (float) 1L);
        piePlot0.setLegendItemShape(shape4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot0.getLabelGenerator();
        piePlot0.setIgnoreNullValues(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot0.getInsets();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets13.createAdjustedRectangle(rectangle2D14, lengthAdjustmentType15, lengthAdjustmentType16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        java.awt.Shape shape8 = stackedBarRenderer3D0.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        java.lang.Comparable comparable10 = legendItemEntity9.getSeriesKey();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(comparable10);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.data.gantt.TaskSeries taskSeries2 = new org.jfree.data.gantt.TaskSeries("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        taskSeries2.removeChangeListener(seriesChangeListener3);
        java.util.List list5 = taskSeries2.getTasks();
        segmentedTimeline0.addExceptions(list5);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        java.lang.Comparable comparable3 = null;
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier(comparable3, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (double) 10L);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Font font3 = piePlot0.getLabelFont();
        boolean boolean4 = piePlot0.isSubplot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D5.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        stackedBarRenderer3D5.setBaseToolTipGenerator(categoryToolTipGenerator8);
        stackedBarRenderer3D5.setItemMargin((-1.0d));
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D5.setSeriesOutlineStroke(3, stroke13, true);
        piePlot0.setOutlineStroke(stroke13);
        java.awt.Paint paint17 = null;
        try {
            piePlot0.setLabelPaint(paint17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font4, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Paint paint11 = jFreeChart10.getBorderPaint();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart10.addProgressListener(chartProgressListener13);
        float float15 = jFreeChart10.getBackgroundImageAlpha();
        try {
            java.awt.image.BufferedImage bufferedImage18 = jFreeChart10.createBufferedImage((-1), 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (2) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (-49088), (float) (-14336));
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 9, (double) (short) 100);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range7 = defaultBoxAndWhiskerCategoryDataset5.getRangeBounds(false);
        java.lang.Comparable comparable8 = null;
        java.lang.Number number10 = defaultBoxAndWhiskerCategoryDataset5.getMaxOutlier(comparable8, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str14 = spreadsheetDate13.getDescription();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset5, (java.lang.Comparable) str14);
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset5, (java.lang.Comparable) (-14336));
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(pieDataset17);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot2.setBaseSectionPaint(paint3);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) 3, 0.0f, (float) 1L);
        piePlot2.setLegendItemShape(shape6);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D13.setBase((double) 1.0f);
        java.lang.Boolean boolean17 = stackedBarRenderer3D13.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font20 = stackedBarRenderer3D13.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font20);
        piePlot2.setLabelFont(font20);
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("LegendItemEntity: seriesKey=null, dataset=null", font20);
        java.awt.Paint paint24 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer26 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock27 = org.jfree.chart.text.TextUtilities.createTextBlock("1.0.6", font20, paint24, (float) (-457), textMeasurer26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str3 = spreadsheetDate2.getDescription();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean5 = spreadsheetDate2.equals((java.lang.Object) categoryLabelPositions4);
        int int6 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) spreadsheetDate2);
        java.lang.Class<?> wildcardClass7 = taskSeriesCollection0.getClass();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.util.Date date9 = month8.getStart();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.setAutoTickUnitSelection(false);
        boolean boolean13 = dateAxis10.isNegativeArrowVisible();
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot14.setBaseSectionPaint(paint15);
        dateAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot14);
        org.jfree.chart.event.AxisChangeListener axisChangeListener18 = null;
        dateAxis10.removeChangeListener(axisChangeListener18);
        java.lang.Class class20 = null;
        java.util.Date date21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone23 = dateAxis22.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone23);
        dateAxis10.setTimeZone(timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date9, timeZone23);
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot27.setBaseSectionPaint(paint28);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape31, (double) 3, 0.0f, (float) 1L);
        piePlot27.setLegendItemShape(shape31);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D38 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D38.setBase((double) 1.0f);
        java.lang.Boolean boolean42 = stackedBarRenderer3D38.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font45 = stackedBarRenderer3D38.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine46 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font45);
        piePlot27.setLabelFont(font45);
        java.awt.Color color48 = org.jfree.chart.ChartColor.LIGHT_RED;
        piePlot27.setNoDataMessagePaint((java.awt.Paint) color48);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D50 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D50.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator53 = null;
        stackedBarRenderer3D50.setBaseToolTipGenerator(categoryToolTipGenerator53);
        java.awt.Stroke stroke56 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D50.setSeriesOutlineStroke((int) ' ', stroke56);
        java.awt.Color color58 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.plot.PiePlot piePlot59 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint60 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot59.setBaseSectionPaint(paint60);
        java.awt.Font font62 = piePlot59.getLabelFont();
        java.awt.Stroke stroke63 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot59.setBaseSectionOutlineStroke(stroke63);
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker66 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) regularTimePeriod26, (java.awt.Paint) color48, stroke56, (java.awt.Paint) color58, stroke63, (float) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNull(boolean42);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertNotNull(stroke63);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Comparable comparable2 = null;
        java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getMedianValue((java.lang.Comparable) (-1.0f), comparable2);
        org.jfree.data.Range range5 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        org.jfree.data.Range range8 = org.jfree.data.Range.shift(range5, (double) (-253), false);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("June 2019", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        minMaxCategoryRenderer0.setGroupPaint((java.awt.Paint) color1);
        javax.swing.Icon icon3 = minMaxCategoryRenderer0.getMaxIcon();
        javax.swing.Icon icon4 = minMaxCategoryRenderer0.getObjectIcon();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(icon3);
        org.junit.Assert.assertNotNull(icon4);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1561964399999L, (double) 'a');
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        stackedBarRenderer3D0.setItemMargin((-1.0d));
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D0.getToolTipGenerator((int) (byte) 0, 0);
        stackedBarRenderer3D0.setAutoPopulateSeriesOutlineStroke(false);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D13.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D16.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = null;
        stackedBarRenderer3D16.setBaseToolTipGenerator(categoryToolTipGenerator19);
        stackedBarRenderer3D16.setItemMargin((-1.0d));
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D16.setSeriesOutlineStroke(3, stroke24, true);
        stackedBarRenderer3D13.setBaseOutlineStroke(stroke24, true);
        int int29 = month12.compareTo((java.lang.Object) stackedBarRenderer3D13);
        java.awt.Paint paint32 = stackedBarRenderer3D13.getItemPaint(4, 7);
        stackedBarRenderer3D0.setBaseOutlinePaint(paint32, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker37 = new org.jfree.chart.plot.IntervalMarker((double) 2, (double) (byte) 100);
        java.awt.Stroke stroke38 = intervalMarker37.getStroke();
        java.awt.Paint paint39 = intervalMarker37.getLabelPaint();
        stackedBarRenderer3D0.setWallPaint(paint39);
        java.awt.Font font43 = stackedBarRenderer3D0.getItemLabelFont((int) '#', 0);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(font43);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape5, (double) 100L, (float) 0, (float) 10L);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape11, (double) 100L, (float) 0, (float) 10L);
        boolean boolean16 = org.jfree.chart.util.ShapeUtilities.equal(shape9, shape15);
        java.awt.Paint paint17 = null;
        try {
            org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem(attributedString0, "({0}, {1}) = {3} - {4}", "({0}, {1}) = {2}", "JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\n", shape9, paint17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot2.setBaseSectionPaint(paint3);
        java.awt.Font font5 = piePlot2.getLabelFont();
        boolean boolean6 = piePlot2.isSubplot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot2);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean9 = numberAxis1.equals((java.lang.Object) color8);
        numberAxis1.resizeRange((double) 'a', (double) (-4L));
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 11);
        boolean boolean2 = categoryMarker1.getDrawAsLine();
        java.awt.Font font3 = categoryMarker1.getLabelFont();
        org.jfree.chart.event.MarkerChangeListener markerChangeListener4 = null;
        categoryMarker1.addChangeListener(markerChangeListener4);
        boolean boolean6 = categoryMarker1.getDrawAsLine();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getTextAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle1.getTextAlignment();
        double double4 = textTitle1.getWidth();
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long4 = segmentedTimeline3.getSegmentsExcludedSize();
        long long6 = segmentedTimeline3.getTimeFromLong((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-4L) + "'", long4 == (-4L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.awt.Shape shape5 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke8 = piePlot7.getLabelOutlineStroke();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer10 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        minMaxCategoryRenderer10.setBaseFillPaint(paint11);
        piePlot7.setSectionOutlinePaint((java.lang.Comparable) 0.2d, paint11);
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        piePlot7.setShadowPaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D17.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = null;
        stackedBarRenderer3D17.setBaseToolTipGenerator(categoryToolTipGenerator20);
        stackedBarRenderer3D17.setItemMargin((-1.0d));
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        stackedBarRenderer3D17.setBaseOutlinePaint((java.awt.Paint) color24, false);
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot27.setBaseSectionPaint(paint28);
        java.awt.Font font30 = piePlot27.getLabelFont();
        boolean boolean31 = piePlot27.isSubplot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D32.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator35 = null;
        stackedBarRenderer3D32.setBaseToolTipGenerator(categoryToolTipGenerator35);
        stackedBarRenderer3D32.setItemMargin((-1.0d));
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D32.setSeriesOutlineStroke(3, stroke40, true);
        piePlot27.setOutlineStroke(stroke40);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("orange");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D47 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D47.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator50 = null;
        stackedBarRenderer3D47.setBaseToolTipGenerator(categoryToolTipGenerator50);
        stackedBarRenderer3D47.setItemMargin((-1.0d));
        boolean boolean54 = stackedBarRenderer3D47.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape56 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape60 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape56, (double) 100L, (float) 0, (float) 10L);
        stackedBarRenderer3D47.setBaseShape(shape60, true);
        dateAxis46.setDownArrow(shape60);
        org.jfree.chart.plot.PiePlot piePlot64 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke65 = piePlot64.getLabelOutlineStroke();
        java.awt.Color color66 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem67 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", true, shape5, true, (java.awt.Paint) color14, false, (java.awt.Paint) color24, stroke40, true, shape60, stroke65, (java.awt.Paint) color66);
        boolean boolean68 = legendItem67.isShapeFilled();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        java.lang.String str1 = rangeType0.toString();
        java.lang.String str2 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.FULL" + "'", str1.equals("RangeType.FULL"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RangeType.FULL" + "'", str2.equals("RangeType.FULL"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 3, 0.0f, (float) 1L);
        piePlot0.setLegendItemShape(shape4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot0.getLabelGenerator();
        piePlot0.setIgnoreNullValues(true);
        int int13 = piePlot0.getPieIndex();
        piePlot0.setShadowXOffset((double) 6);
        java.awt.Color color16 = java.awt.Color.yellow;
        piePlot0.setLabelShadowPaint((java.awt.Paint) color16);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit18 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        piePlot0.setExplodePercent((java.lang.Comparable) numberTickUnit18, 0.0d);
        org.jfree.chart.util.Rotation rotation21 = piePlot0.getDirection();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(numberTickUnit18);
        org.junit.Assert.assertNotNull(rotation21);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        int int3 = taskSeriesCollection0.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries5 = new org.jfree.data.gantt.TaskSeries("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        taskSeries5.removePropertyChangeListener(propertyChangeListener6);
        taskSeriesCollection0.remove(taskSeries5);
        try {
            java.lang.Comparable comparable10 = taskSeriesCollection0.getRowKey(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font4, (org.jfree.chart.plot.Plot) piePlot5, false);
        org.jfree.chart.event.ChartChangeListener chartChangeListener11 = null;
        try {
            jFreeChart10.removeChangeListener(chartChangeListener11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (-1), 0.0d);
        java.awt.Paint paint3 = intervalMarker2.getOutlinePaint();
        java.lang.Object obj4 = intervalMarker2.clone();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.lang.Boolean boolean4 = stackedBarRenderer3D0.getSeriesCreateEntities((int) (short) 1);
        double double5 = stackedBarRenderer3D0.getUpperClip();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = stackedBarRenderer3D0.getSeriesItemLabelGenerator((int) (byte) 100);
        java.awt.Paint paint10 = stackedBarRenderer3D0.getItemPaint((int) (short) 100, (int) (short) 10);
        boolean boolean13 = stackedBarRenderer3D0.isItemLabelVisible(12, (-1));
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        outlierListCollection0.setHighFarOut(true);
        org.jfree.chart.renderer.Outlier outlier3 = null;
        boolean boolean4 = outlierListCollection0.add(outlier3);
        outlierListCollection0.setHighFarOut(true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        stackedBarRenderer3D4.setBaseToolTipGenerator(categoryToolTipGenerator7);
        stackedBarRenderer3D4.setItemMargin((-1.0d));
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D4.setSeriesOutlineStroke(3, stroke12, true);
        stackedBarRenderer3D1.setBaseOutlineStroke(stroke12, true);
        int int17 = month0.compareTo((java.lang.Object) stackedBarRenderer3D1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D20 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D20.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = null;
        stackedBarRenderer3D20.setBaseToolTipGenerator(categoryToolTipGenerator23);
        stackedBarRenderer3D20.setItemMargin((-1.0d));
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        stackedBarRenderer3D20.setBaseOutlinePaint((java.awt.Paint) color27, false);
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker(0.25d, (java.awt.Paint) color27, stroke30);
        try {
            stackedBarRenderer3D1.setSeriesStroke((-1), stroke30, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke2 = piePlot1.getLabelOutlineStroke();
        waterfallBarRenderer0.setBaseOutlineStroke(stroke2);
        double double4 = waterfallBarRenderer0.getUpperClip();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D9.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color11);
        java.lang.String str14 = categoryAxis3D9.getCategoryLabelToolTip((java.lang.Comparable) 4.0d);
        categoryAxis3D9.configure();
        org.jfree.chart.axis.AxisCollection axisCollection16 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone18 = dateAxis17.getTimeZone();
        dateAxis17.setInverted(false);
        dateAxis17.resizeRange((double) (byte) 10, (double) (byte) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection16.add((org.jfree.chart.axis.Axis) dateAxis17, rectangleEdge24);
        double double26 = dateAxis17.getFixedDimension();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset27 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range29 = defaultBoxAndWhiskerCategoryDataset27.getRangeBounds(false);
        java.lang.Comparable comparable30 = null;
        java.lang.Number number32 = defaultBoxAndWhiskerCategoryDataset27.getMaxOutlier(comparable30, (java.lang.Comparable) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str35 = spreadsheetDate34.getDescription();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions36 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean37 = spreadsheetDate34.equals((java.lang.Object) categoryLabelPositions36);
        int int38 = spreadsheetDate34.getMonth();
        java.lang.Number number40 = defaultBoxAndWhiskerCategoryDataset27.getMinRegularValue((java.lang.Comparable) spreadsheetDate34, (java.lang.Comparable) (-4L));
        int int41 = defaultBoxAndWhiskerCategoryDataset27.getRowCount();
        try {
            waterfallBarRenderer0.drawItem(graphics2D5, categoryItemRendererState6, rectangle2D7, categoryPlot8, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D9, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset27, 15, (int) (byte) 1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNull(number32);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(categoryLabelPositions36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
        org.junit.Assert.assertNull(number40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long4 = segmentedTimeline3.getSegmentsExcludedSize();
        java.util.Date date6 = segmentedTimeline3.getDate((long) 7);
        long long7 = segmentedTimeline3.getSegmentSize();
        long long9 = segmentedTimeline3.getTimeFromLong((long) 1900);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-4L) + "'", long4 == (-4L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 4L + "'", long7 == 4L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1900L + "'", long9 == 1900L);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D0.setBaseItemLabelPaint(paint3, true);
        java.awt.Shape shape8 = stackedBarRenderer3D0.getItemShape(1, (int) (short) 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = null;
        stackedBarRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator9);
        boolean boolean11 = stackedBarRenderer3D0.getRenderAsPercentages();
        java.awt.Font font12 = stackedBarRenderer3D0.getBaseItemLabelFont();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape19, (double) 100L, (float) 0, (float) 10L);
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape25, (double) 100L, (float) 0, (float) 10L);
        boolean boolean30 = org.jfree.chart.util.ShapeUtilities.equal(shape23, shape29);
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        int int33 = color32.getAlpha();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer35 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint36 = waterfallBarRenderer35.getLastBarPaint();
        org.jfree.chart.plot.PiePlot piePlot37 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint38 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot37.setBaseSectionPaint(paint38);
        java.awt.Font font40 = piePlot37.getLabelFont();
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot37.setBaseSectionOutlineStroke(stroke41);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D44 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D44.setBase((double) 1.0f);
        java.awt.Paint paint47 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D44.setBaseItemLabelPaint(paint47, true);
        java.awt.Shape shape52 = stackedBarRenderer3D44.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity53 = new org.jfree.chart.entity.LegendItemEntity(shape52);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset56 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range58 = defaultBoxAndWhiskerCategoryDataset56.getRangeBounds(false);
        java.lang.Comparable comparable59 = null;
        java.lang.Number number61 = defaultBoxAndWhiskerCategoryDataset56.getMaxOutlier(comparable59, (java.lang.Comparable) (short) 0);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity64 = new org.jfree.chart.entity.CategoryItemEntity(shape52, "DateTickMarkPosition.END", "TextBlockAnchor.CENTER_RIGHT", (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset56, (java.lang.Comparable) (short) 1, (java.lang.Comparable) "RangeType.NEGATIVE");
        java.awt.Stroke stroke65 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer66 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.plot.PiePlot piePlot67 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke68 = piePlot67.getLabelOutlineStroke();
        waterfallBarRenderer66.setBaseOutlineStroke(stroke68);
        java.awt.Paint paint70 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        waterfallBarRenderer66.setLastBarPaint(paint70);
        org.jfree.chart.LegendItem legendItem72 = new org.jfree.chart.LegendItem("Default Group", "1.0.6", "1.0.6", "GradientPaintTransformType.VERTICAL", false, shape23, true, (java.awt.Paint) color32, true, paint36, stroke41, false, shape52, stroke65, paint70);
        boolean boolean73 = stackedBarRenderer3D0.equals((java.lang.Object) paint36);
        boolean boolean74 = stackedBarRenderer3D0.getBaseCreateEntities();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 255 + "'", int33 == 255);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNull(number61);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLowerMargin((double) 2);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = new org.jfree.chart.axis.AxisState();
        double double5 = axisState4.getCursor();
        axisState4.setCursor((double) (byte) 1);
        java.util.List list8 = axisState4.getTicks();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.AxisCollection axisCollection11 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone13 = dateAxis12.getTimeZone();
        dateAxis12.setInverted(false);
        dateAxis12.resizeRange((double) (byte) 10, (double) (byte) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection11.add((org.jfree.chart.axis.Axis) dateAxis12, rectangleEdge19);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = categoryLabelPositions10.getLabelPosition(rectangleEdge19);
        try {
            java.util.List list22 = dateAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D9, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(categoryLabelPosition21);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor1 = itemLabelPosition0.getTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor2 = itemLabelPosition0.getTextAnchor();
        java.lang.String str3 = textAnchor2.toString();
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BOTTOM_CENTER" + "'", str3.equals("TextAnchor.BOTTOM_CENTER"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Font font3 = piePlot0.getLabelFont();
        double double4 = piePlot0.getShadowYOffset();
        java.awt.Paint paint5 = piePlot0.getNoDataMessagePaint();
        java.awt.Paint paint6 = piePlot0.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = levelRenderer0.getNegativeItemLabelPosition(12, (-49088));
        levelRenderer0.setItemMargin((double) 12);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("orange");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: orange" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: orange"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtBottom();
        java.util.List list2 = axisCollection0.getAxesAtTop();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot2.setBaseSectionPaint(paint3);
        java.awt.Font font5 = piePlot2.getLabelFont();
        boolean boolean6 = piePlot2.isSubplot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot2);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean9 = numberAxis1.equals((java.lang.Object) color8);
        org.jfree.data.RangeType rangeType10 = org.jfree.data.RangeType.POSITIVE;
        numberAxis1.setRangeType(rangeType10);
        boolean boolean13 = rangeType10.equals((java.lang.Object) 100L);
        java.lang.Class class14 = null;
        java.util.Date date15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone17 = dateAxis16.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date15, timeZone17);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone17;
        boolean boolean20 = rangeType10.equals((java.lang.Object) timeZone17);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rangeType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceText("");
        java.util.List list3 = projectInfo0.getContributors();
        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
        projectInfo4.setLicenceText("");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo4);
        projectInfo4.setVersion("DateTickMarkPosition.END");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(projectInfo4);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.awt.Font font0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        int int2 = color1.getRed();
        minMaxCategoryRenderer0.setGroupPaint((java.awt.Paint) color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 192 + "'", int2 == 192);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        java.awt.Color color2 = java.awt.Color.darkGray;
        boolean boolean3 = stackedAreaRenderer1.equals((java.lang.Object) color2);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long9 = segmentedTimeline8.getSegmentsExcludedSize();
        java.util.Date date11 = segmentedTimeline8.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline15 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long16 = segmentedTimeline15.getSegmentsExcludedSize();
        java.util.Date date18 = segmentedTimeline15.getDate((long) 7);
        boolean boolean19 = segmentedTimeline4.containsDomainRange(date11, date18);
        java.lang.Number number20 = defaultBoxAndWhiskerCategoryDataset0.getMaxRegularValue((java.lang.Comparable) ' ', (java.lang.Comparable) date11);
        java.lang.Class class21 = null;
        java.util.Date date22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone24 = dateAxis23.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone24);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone24;
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date11, timeZone24);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date11);
        java.lang.Class class29 = null;
        java.util.Date date30 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone32 = dateAxis31.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone32);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone32;
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date11, timeZone32);
        java.util.Calendar calendar36 = null;
        try {
            long long37 = year35.getLastMillisecond(calendar36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-4L) + "'", long9 == (-4L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-4L) + "'", long16 == (-4L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getGPL();
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        java.lang.String str2 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str2.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            chartRenderingInfo1.setChartArea(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setBaseShapesFilled(false);
        statisticalLineAndShapeRenderer0.setBaseShapesFilled(false);
        double double5 = statisticalLineAndShapeRenderer0.getItemLabelAnchorOffset();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getLabelOutlineStroke();
        piePlot0.setLabelLinkMargin((double) '#');
        piePlot0.setStartAngle((double) 7L);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D0.setSeriesOutlineStroke((int) ' ', stroke6);
        stackedBarRenderer3D0.setAutoPopulateSeriesShape(true);
        java.awt.Paint paint11 = stackedBarRenderer3D0.getSeriesPaint((int) '#');
        boolean boolean12 = stackedBarRenderer3D0.getBaseCreateEntities();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        stackedBarRenderer3D0.setItemMargin((-1.0d));
        boolean boolean7 = stackedBarRenderer3D0.getAutoPopulateSeriesOutlinePaint();
        java.lang.Boolean boolean9 = stackedBarRenderer3D0.getSeriesItemLabelsVisible(500);
        java.awt.Stroke stroke11 = null;
        stackedBarRenderer3D0.setSeriesStroke(0, stroke11);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(boolean9);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font4, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Paint paint11 = jFreeChart10.getBorderPaint();
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot13.setBaseSectionPaint(paint14);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape17, (double) 3, 0.0f, (float) 1L);
        piePlot13.setLegendItemShape(shape17);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D24.setBase((double) 1.0f);
        java.lang.Boolean boolean28 = stackedBarRenderer3D24.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font31 = stackedBarRenderer3D24.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine32 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font31);
        piePlot13.setLabelFont(font31);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("LegendItemEntity: seriesKey=null, dataset=null", font31);
        textTitle34.setExpandToFitSpace(false);
        jFreeChart10.addSubtitle((org.jfree.chart.title.Title) textTitle34);
        boolean boolean39 = textTitle34.equals((java.lang.Object) 12.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(boolean28);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE12" + "'", str1.equals("ItemLabelAnchor.OUTSIDE12"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font4, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Paint paint11 = jFreeChart10.getBorderPaint();
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot13.setBaseSectionPaint(paint14);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape17, (double) 3, 0.0f, (float) 1L);
        piePlot13.setLegendItemShape(shape17);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D24.setBase((double) 1.0f);
        java.lang.Boolean boolean28 = stackedBarRenderer3D24.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font31 = stackedBarRenderer3D24.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine32 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font31);
        piePlot13.setLabelFont(font31);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("LegendItemEntity: seriesKey=null, dataset=null", font31);
        textTitle34.setExpandToFitSpace(false);
        jFreeChart10.addSubtitle((org.jfree.chart.title.Title) textTitle34);
        textTitle34.setNotify(true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(boolean28);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 3, 0.0f, (float) 1L);
        piePlot0.setLegendItemShape(shape4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot0.getLabelGenerator();
        piePlot0.setIgnoreNullValues(true);
        int int13 = piePlot0.getPieIndex();
        piePlot0.setShadowXOffset((double) 6);
        java.awt.Color color16 = java.awt.Color.yellow;
        piePlot0.setLabelShadowPaint((java.awt.Paint) color16);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset18 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range20 = defaultBoxAndWhiskerCategoryDataset18.getRangeBounds(false);
        java.lang.Comparable comparable21 = null;
        java.lang.Number number23 = defaultBoxAndWhiskerCategoryDataset18.getMaxOutlier(comparable21, (java.lang.Comparable) (short) 0);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline28 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long29 = segmentedTimeline28.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline30 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline34 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long35 = segmentedTimeline34.getSegmentsExcludedSize();
        java.util.Date date37 = segmentedTimeline34.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline41 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long42 = segmentedTimeline41.getSegmentsExcludedSize();
        java.util.Date date44 = segmentedTimeline41.getDate((long) 7);
        boolean boolean45 = segmentedTimeline30.containsDomainRange(date37, date44);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment46 = segmentedTimeline28.getSegment(date44);
        java.lang.Number number47 = defaultBoxAndWhiskerCategoryDataset18.getQ1Value((java.lang.Comparable) (-1), (java.lang.Comparable) segment46);
        java.awt.Paint paint48 = piePlot0.getSectionOutlinePaint((java.lang.Comparable) (-1));
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-4L) + "'", long29 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline30);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-4L) + "'", long35 == (-4L));
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-4L) + "'", long42 == (-4L));
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(segment46);
        org.junit.Assert.assertNull(number47);
        org.junit.Assert.assertNull(paint48);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getTextAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle1.getTextAlignment();
        boolean boolean4 = textTitle1.getNotify();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            textTitle1.setBounds(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = waterfallBarRenderer0.getLastBarPaint();
        waterfallBarRenderer0.setIncludeBaseInRange(false);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        stackedBarRenderer3D1.setBaseToolTipGenerator(categoryToolTipGenerator4);
        stackedBarRenderer3D1.setItemMargin((-1.0d));
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        stackedBarRenderer3D1.setBaseOutlinePaint((java.awt.Paint) color8, false);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(0.25d, (java.awt.Paint) color8, stroke11);
        valueMarker12.setValue((double) (-49088));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        double double1 = intervalBarRenderer0.getMaximumBarWidth();
        java.awt.Shape shape3 = intervalBarRenderer0.lookupSeriesShape(8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot1.setBaseSectionPaint(paint2);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape5, (double) 3, 0.0f, (float) 1L);
        piePlot1.setLegendItemShape(shape5);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D12.setBase((double) 1.0f);
        java.lang.Boolean boolean16 = stackedBarRenderer3D12.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font19 = stackedBarRenderer3D12.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font19);
        piePlot1.setLabelFont(font19);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot22.setBaseSectionPaint(paint23);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape26, (double) 3, 0.0f, (float) 1L);
        piePlot22.setLegendItemShape(shape26);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D33.setBase((double) 1.0f);
        java.lang.Boolean boolean37 = stackedBarRenderer3D33.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font40 = stackedBarRenderer3D33.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine41 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font40);
        piePlot22.setLabelFont(font40);
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_RED;
        piePlot22.setNoDataMessagePaint((java.awt.Paint) color43);
        org.jfree.chart.block.LabelBlock labelBlock45 = new org.jfree.chart.block.LabelBlock("orange", font19, (java.awt.Paint) color43);
        labelBlock45.setURLText("");
        java.awt.Graphics2D graphics2D48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        java.lang.Object obj50 = null;
        try {
            java.lang.Object obj51 = labelBlock45.draw(graphics2D48, rectangle2D49, obj50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNull(boolean37);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(color43);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color2);
        java.lang.String str5 = categoryAxis3D0.getCategoryLabelToolTip((java.lang.Comparable) 4.0d);
        categoryAxis3D0.configure();
        java.awt.Paint paint8 = categoryAxis3D0.getTickLabelPaint((java.lang.Comparable) 0.25d);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.AxisCollection axisCollection13 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone15 = dateAxis14.getTimeZone();
        dateAxis14.setInverted(false);
        dateAxis14.resizeRange((double) (byte) 10, (double) (byte) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection13.add((org.jfree.chart.axis.Axis) dateAxis14, rectangleEdge21);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition23 = categoryLabelPositions12.getLabelPosition(rectangleEdge21);
        try {
            double double24 = categoryAxis3D0.getCategoryStart(0, 6, rectangle2D11, rectangleEdge21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(categoryLabelPosition23);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.awt.Color color0 = java.awt.Color.orange;
        int int1 = color0.getRGB();
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.AffineTransform affineTransform5 = null;
        java.awt.RenderingHints renderingHints6 = null;
        java.awt.PaintContext paintContext7 = color0.createContext(colorModel2, rectangle3, rectangle2D4, affineTransform5, renderingHints6);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-14336) + "'", int1 == (-14336));
        org.junit.Assert.assertNotNull(paintContext7);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 9, (double) (short) 100);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range7 = defaultBoxAndWhiskerCategoryDataset5.getRangeBounds(false);
        java.lang.Comparable comparable8 = null;
        java.lang.Number number10 = defaultBoxAndWhiskerCategoryDataset5.getMaxOutlier(comparable8, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str14 = spreadsheetDate13.getDescription();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset5, (java.lang.Comparable) str14);
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        java.lang.Object obj17 = blockContainer16.clone();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        double double1 = stackedBarRenderer3D0.getYOffset();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator5 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.text.NumberFormat numberFormat6 = standardCategoryToolTipGenerator5.getNumberFormat();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator7 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("({0}, {1}) = {3} - {4}", numberFormat6);
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator8 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("DateTickMarkPosition.END", numberFormat6);
        stackedBarRenderer3D0.setSeriesToolTipGenerator((int) ' ', (org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator8, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
        org.junit.Assert.assertNotNull(numberFormat6);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 100.0f, (double) 11);
        org.jfree.data.Range range3 = rectangleConstraint2.getHeightRange();
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.lang.Boolean boolean5 = stackedBarRenderer3D1.getSeriesCreateEntities((int) (short) 1);
        java.awt.Font font8 = stackedBarRenderer3D1.getItemLabelFont((int) ' ', (int) (short) -1);
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font8);
        java.awt.Graphics2D graphics2D10 = null;
        try {
            org.jfree.chart.util.Size2D size2D11 = textLine9.calculateDimensions(graphics2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setBaseShapesFilled(false);
        java.lang.Boolean boolean4 = statisticalLineAndShapeRenderer0.getSeriesLinesVisible((int) (byte) 1);
        try {
            statisticalLineAndShapeRenderer0.setSeriesShapesFilled((-457), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "" + "'", str0.equals(""));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        double double3 = rectangleInsets1.calculateLeftInset((double) 1561964399999L);
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets1.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets1.createOutsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(unitType4);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        org.jfree.data.Range range3 = dateAxis0.getDefaultAutoRange();
        boolean boolean4 = dateAxis0.isInverted();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke2 = piePlot1.getLabelOutlineStroke();
        piePlot1.setLabelLinkMargin((double) '#');
        java.lang.Object obj5 = piePlot1.clone();
        boolean boolean6 = datasetRenderingOrder0.equals((java.lang.Object) piePlot1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getTextAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle1.getTextAlignment();
        java.lang.String str4 = textTitle1.getID();
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range3 = defaultBoxAndWhiskerCategoryDataset1.getRangeBounds(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long10 = segmentedTimeline9.getSegmentsExcludedSize();
        java.util.Date date12 = segmentedTimeline9.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long17 = segmentedTimeline16.getSegmentsExcludedSize();
        java.util.Date date19 = segmentedTimeline16.getDate((long) 7);
        boolean boolean20 = segmentedTimeline5.containsDomainRange(date12, date19);
        java.lang.Number number21 = defaultBoxAndWhiskerCategoryDataset1.getMaxRegularValue((java.lang.Comparable) ' ', (java.lang.Comparable) date12);
        java.lang.Class class22 = null;
        java.util.Date date23 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone25 = dateAxis24.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date23, timeZone25);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone25;
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date12, timeZone25);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date12);
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone33 = dateAxis32.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone33);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone33;
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date12, timeZone33);
        try {
            org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (short) -1, year36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-4L) + "'", long10 == (-4L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-4L) + "'", long17 == (-4L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(number21);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod34);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long4 = segmentedTimeline3.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long10 = segmentedTimeline9.getSegmentsExcludedSize();
        java.util.Date date12 = segmentedTimeline9.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long17 = segmentedTimeline16.getSegmentsExcludedSize();
        java.util.Date date19 = segmentedTimeline16.getDate((long) 7);
        boolean boolean20 = segmentedTimeline5.containsDomainRange(date12, date19);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline3.getSegment(date19);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment24 = segment21.intersect((long) 'a', (long) 12);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline28 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long29 = segmentedTimeline28.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline30 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline34 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long35 = segmentedTimeline34.getSegmentsExcludedSize();
        java.util.Date date37 = segmentedTimeline34.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline41 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long42 = segmentedTimeline41.getSegmentsExcludedSize();
        java.util.Date date44 = segmentedTimeline41.getDate((long) 7);
        boolean boolean45 = segmentedTimeline30.containsDomainRange(date37, date44);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment46 = segmentedTimeline28.getSegment(date44);
        segment46.dec();
        boolean boolean48 = segment21.before(segment46);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline52 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long53 = segmentedTimeline52.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline54 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline58 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long59 = segmentedTimeline58.getSegmentsExcludedSize();
        java.util.Date date61 = segmentedTimeline58.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline65 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long66 = segmentedTimeline65.getSegmentsExcludedSize();
        java.util.Date date68 = segmentedTimeline65.getDate((long) 7);
        boolean boolean69 = segmentedTimeline54.containsDomainRange(date61, date68);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment70 = segmentedTimeline52.getSegment(date68);
        boolean boolean71 = segment21.after(segment70);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-4L) + "'", long4 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-4L) + "'", long10 == (-4L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-4L) + "'", long17 == (-4L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(segment21);
        org.junit.Assert.assertNull(segment24);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-4L) + "'", long29 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline30);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-4L) + "'", long35 == (-4L));
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-4L) + "'", long42 == (-4L));
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(segment46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-4L) + "'", long53 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline54);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-4L) + "'", long59 == (-4L));
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-4L) + "'", long66 == (-4L));
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(segment70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        java.lang.Comparable comparable3 = null;
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier(comparable3, (java.lang.Comparable) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str8 = spreadsheetDate7.getDescription();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean10 = spreadsheetDate7.equals((java.lang.Object) categoryLabelPositions9);
        int int11 = spreadsheetDate7.getMonth();
        java.lang.Number number13 = defaultBoxAndWhiskerCategoryDataset0.getMinRegularValue((java.lang.Comparable) spreadsheetDate7, (java.lang.Comparable) (-4L));
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str16 = spreadsheetDate15.getDescription();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions17 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean18 = spreadsheetDate15.equals((java.lang.Object) categoryLabelPositions17);
        int int19 = spreadsheetDate15.getMonth();
        boolean boolean20 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        try {
            org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate7.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(categoryLabelPositions17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot0.setBaseSectionPaint(paint1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 3, 0.0f, (float) 1L);
        piePlot0.setLegendItemShape(shape4);
        piePlot0.setShadowYOffset((double) 9);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot12.setBaseSectionPaint(paint13);
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape16, (double) 3, 0.0f, (float) 1L);
        piePlot12.setLegendItemShape(shape16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator22 = piePlot12.getLabelGenerator();
        piePlot0.setLegendLabelGenerator(pieSectionLabelGenerator22);
        java.lang.Object obj24 = piePlot0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator22);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        defaultStatisticalCategoryDataset0.add((java.lang.Number) (-1L), (java.lang.Number) 100.0d, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 0.0f);
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.0d + "'", number7.equals(0.0d));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setBase((double) 1.0f);
        java.awt.Font font4 = stackedBarRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font4, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Paint paint11 = jFreeChart10.getBorderPaint();
        jFreeChart10.setNotify(false);
        boolean boolean14 = jFreeChart10.isNotify();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE7" + "'", str1.equals("ItemLabelAnchor.INSIDE7"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) '4', (double) 10);
        stackedBarRenderer3D2.setAutoPopulateSeriesFillPaint(true);
        boolean boolean7 = stackedBarRenderer3D2.getItemVisible((int) '#', (int) '4');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedBarRenderer3D2.getBasePositiveItemLabelPosition();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState14 = stackedBarRenderer3D2.initialise(graphics2D9, rectangle2D10, categoryPlot11, (int) '4', plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedBarRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D0.setSeriesOutlineStroke((int) ' ', stroke6);
        stackedBarRenderer3D0.setAutoPopulateSeriesShape(true);
        java.awt.Paint paint11 = stackedBarRenderer3D0.getSeriesPaint((int) '#');
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            stackedBarRenderer3D0.drawBackground(graphics2D12, categoryPlot13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("TextAnchor.BOTTOM_CENTER", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(false);
        boolean boolean3 = dateAxis0.isNegativeArrowVisible();
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot4.setBaseSectionPaint(paint5);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot4);
        piePlot4.setPieIndex((int) '4');
        double double10 = piePlot4.getLabelLinkMargin();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getTextAlignment();
        textTitle1.setExpandToFitSpace(false);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        textTitle1.setTextAlignment(horizontalAlignment5);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.awt.Shape shape5 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke8 = piePlot7.getLabelOutlineStroke();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer10 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        minMaxCategoryRenderer10.setBaseFillPaint(paint11);
        piePlot7.setSectionOutlinePaint((java.lang.Comparable) 0.2d, paint11);
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        piePlot7.setShadowPaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D17.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = null;
        stackedBarRenderer3D17.setBaseToolTipGenerator(categoryToolTipGenerator20);
        stackedBarRenderer3D17.setItemMargin((-1.0d));
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        stackedBarRenderer3D17.setBaseOutlinePaint((java.awt.Paint) color24, false);
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot27.setBaseSectionPaint(paint28);
        java.awt.Font font30 = piePlot27.getLabelFont();
        boolean boolean31 = piePlot27.isSubplot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D32.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator35 = null;
        stackedBarRenderer3D32.setBaseToolTipGenerator(categoryToolTipGenerator35);
        stackedBarRenderer3D32.setItemMargin((-1.0d));
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D32.setSeriesOutlineStroke(3, stroke40, true);
        piePlot27.setOutlineStroke(stroke40);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("orange");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D47 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D47.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator50 = null;
        stackedBarRenderer3D47.setBaseToolTipGenerator(categoryToolTipGenerator50);
        stackedBarRenderer3D47.setItemMargin((-1.0d));
        boolean boolean54 = stackedBarRenderer3D47.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape56 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape60 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape56, (double) 100L, (float) 0, (float) 10L);
        stackedBarRenderer3D47.setBaseShape(shape60, true);
        dateAxis46.setDownArrow(shape60);
        org.jfree.chart.plot.PiePlot piePlot64 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke65 = piePlot64.getLabelOutlineStroke();
        java.awt.Color color66 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem67 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", true, shape5, true, (java.awt.Paint) color14, false, (java.awt.Paint) color24, stroke40, true, shape60, stroke65, (java.awt.Paint) color66);
        legendItem67.setSeriesKey((java.lang.Comparable) "JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\n");
        boolean boolean70 = legendItem67.isLineVisible();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long4 = segmentedTimeline3.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long10 = segmentedTimeline9.getSegmentsExcludedSize();
        java.util.Date date12 = segmentedTimeline9.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long17 = segmentedTimeline16.getSegmentsExcludedSize();
        java.util.Date date19 = segmentedTimeline16.getDate((long) 7);
        boolean boolean20 = segmentedTimeline5.containsDomainRange(date12, date19);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline3.getSegment(date19);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment24 = segment21.intersect((long) 'a', (long) 12);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline28 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long29 = segmentedTimeline28.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline30 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline34 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long35 = segmentedTimeline34.getSegmentsExcludedSize();
        java.util.Date date37 = segmentedTimeline34.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline41 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long42 = segmentedTimeline41.getSegmentsExcludedSize();
        java.util.Date date44 = segmentedTimeline41.getDate((long) 7);
        boolean boolean45 = segmentedTimeline30.containsDomainRange(date37, date44);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment46 = segmentedTimeline28.getSegment(date44);
        segment46.dec();
        boolean boolean48 = segment21.before(segment46);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline52 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long53 = segmentedTimeline52.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline54 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline58 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long59 = segmentedTimeline58.getSegmentsExcludedSize();
        java.util.Date date61 = segmentedTimeline58.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline65 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long66 = segmentedTimeline65.getSegmentsExcludedSize();
        java.util.Date date68 = segmentedTimeline65.getDate((long) 7);
        boolean boolean69 = segmentedTimeline54.containsDomainRange(date61, date68);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment70 = segmentedTimeline52.getSegment(date68);
        boolean boolean71 = segment46.after(segment70);
        segment70.inc(4L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-4L) + "'", long4 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-4L) + "'", long10 == (-4L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-4L) + "'", long17 == (-4L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(segment21);
        org.junit.Assert.assertNull(segment24);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-4L) + "'", long29 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline30);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-4L) + "'", long35 == (-4L));
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-4L) + "'", long42 == (-4L));
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(segment46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-4L) + "'", long53 == (-4L));
        org.junit.Assert.assertNotNull(segmentedTimeline54);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-4L) + "'", long59 == (-4L));
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-4L) + "'", long66 == (-4L));
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(segment70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        java.awt.Shape shape5 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke8 = piePlot7.getLabelOutlineStroke();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer10 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        minMaxCategoryRenderer10.setBaseFillPaint(paint11);
        piePlot7.setSectionOutlinePaint((java.lang.Comparable) 0.2d, paint11);
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        piePlot7.setShadowPaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D17.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = null;
        stackedBarRenderer3D17.setBaseToolTipGenerator(categoryToolTipGenerator20);
        stackedBarRenderer3D17.setItemMargin((-1.0d));
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        stackedBarRenderer3D17.setBaseOutlinePaint((java.awt.Paint) color24, false);
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot27.setBaseSectionPaint(paint28);
        java.awt.Font font30 = piePlot27.getLabelFont();
        boolean boolean31 = piePlot27.isSubplot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D32.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator35 = null;
        stackedBarRenderer3D32.setBaseToolTipGenerator(categoryToolTipGenerator35);
        stackedBarRenderer3D32.setItemMargin((-1.0d));
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D32.setSeriesOutlineStroke(3, stroke40, true);
        piePlot27.setOutlineStroke(stroke40);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("orange");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D47 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D47.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator50 = null;
        stackedBarRenderer3D47.setBaseToolTipGenerator(categoryToolTipGenerator50);
        stackedBarRenderer3D47.setItemMargin((-1.0d));
        boolean boolean54 = stackedBarRenderer3D47.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape56 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape60 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape56, (double) 100L, (float) 0, (float) 10L);
        stackedBarRenderer3D47.setBaseShape(shape60, true);
        dateAxis46.setDownArrow(shape60);
        org.jfree.chart.plot.PiePlot piePlot64 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke65 = piePlot64.getLabelOutlineStroke();
        java.awt.Color color66 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem67 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", true, shape5, true, (java.awt.Paint) color14, false, (java.awt.Paint) color24, stroke40, true, shape60, stroke65, (java.awt.Paint) color66);
        legendItem67.setSeriesKey((java.lang.Comparable) "JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\n");
        java.lang.String str70 = legendItem67.getLabel();
        java.lang.String str71 = legendItem67.getURLText();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "" + "'", str70.equals(""));
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "hi!" + "'", str71.equals("hi!"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long9 = segmentedTimeline8.getSegmentsExcludedSize();
        java.util.Date date11 = segmentedTimeline8.getDate((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline15 = new org.jfree.chart.axis.SegmentedTimeline((long) 4, (-1), (int) (byte) -1);
        long long16 = segmentedTimeline15.getSegmentsExcludedSize();
        java.util.Date date18 = segmentedTimeline15.getDate((long) 7);
        boolean boolean19 = segmentedTimeline4.containsDomainRange(date11, date18);
        java.lang.Number number20 = defaultBoxAndWhiskerCategoryDataset0.getMaxRegularValue((java.lang.Comparable) ' ', (java.lang.Comparable) date11);
        java.lang.Class class21 = null;
        java.util.Date date22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone24 = dateAxis23.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone24);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone24;
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date11, timeZone24);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date11);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date11);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-4L) + "'", long9 == (-4L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-4L) + "'", long16 == (-4L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(serialDate28);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape7, (double) 100L, (float) 0, (float) 10L);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape13, (double) 100L, (float) 0, (float) 10L);
        boolean boolean18 = org.jfree.chart.util.ShapeUtilities.equal(shape11, shape17);
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        int int21 = color20.getAlpha();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer23 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint24 = waterfallBarRenderer23.getLastBarPaint();
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot25.setBaseSectionPaint(paint26);
        java.awt.Font font28 = piePlot25.getLabelFont();
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot25.setBaseSectionOutlineStroke(stroke29);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D32.setBase((double) 1.0f);
        java.awt.Paint paint35 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D32.setBaseItemLabelPaint(paint35, true);
        java.awt.Shape shape40 = stackedBarRenderer3D32.getItemShape(1, (int) (short) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity41 = new org.jfree.chart.entity.LegendItemEntity(shape40);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset44 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range46 = defaultBoxAndWhiskerCategoryDataset44.getRangeBounds(false);
        java.lang.Comparable comparable47 = null;
        java.lang.Number number49 = defaultBoxAndWhiskerCategoryDataset44.getMaxOutlier(comparable47, (java.lang.Comparable) (short) 0);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity52 = new org.jfree.chart.entity.CategoryItemEntity(shape40, "DateTickMarkPosition.END", "TextBlockAnchor.CENTER_RIGHT", (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset44, (java.lang.Comparable) (short) 1, (java.lang.Comparable) "RangeType.NEGATIVE");
        java.awt.Stroke stroke53 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer54 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.plot.PiePlot piePlot55 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke56 = piePlot55.getLabelOutlineStroke();
        waterfallBarRenderer54.setBaseOutlineStroke(stroke56);
        java.awt.Paint paint58 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        waterfallBarRenderer54.setLastBarPaint(paint58);
        org.jfree.chart.LegendItem legendItem60 = new org.jfree.chart.LegendItem("Default Group", "1.0.6", "1.0.6", "GradientPaintTransformType.VERTICAL", false, shape11, true, (java.awt.Paint) color20, true, paint24, stroke29, false, shape40, stroke53, paint58);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape11, (double) (short) -1, (float) 10, (float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 255 + "'", int21 == 255);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNull(number49);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(paint58);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        minMaxCategoryRenderer2.setBaseFillPaint(paint3);
        boolean boolean5 = objectList1.equals((java.lang.Object) paint3);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getTextAnchor();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor6, textAnchor8);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", graphics2D1, (float) 9, 0.0f, textAnchor4, (double) (-457), textAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D3.setBase((double) 1.0f);
        java.awt.Font font6 = stackedBarRenderer3D3.getBaseItemLabelFont();
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot7.setBaseSectionPaint(paint8);
        java.awt.Font font10 = piePlot7.getLabelFont();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", font6, (org.jfree.chart.plot.Plot) piePlot7, false);
        java.awt.Paint paint13 = jFreeChart12.getBorderPaint();
        boolean boolean14 = jFreeChart12.isBorderVisible();
        boolean boolean15 = axisLocation1.equals((java.lang.Object) boolean14);
        java.lang.String str16 = axisLocation1.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str16.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setAutoTickUnitSelection(false);
        boolean boolean4 = dateAxis1.isNegativeArrowVisible();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        piePlot5.setBaseSectionPaint(paint6);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot5);
        org.jfree.chart.event.AxisChangeListener axisChangeListener9 = null;
        dateAxis1.removeChangeListener(axisChangeListener9);
        java.awt.Font font11 = dateAxis1.getTickLabelFont();
        java.awt.Color color12 = java.awt.Color.darkGray;
        org.jfree.chart.text.TextMeasurer textMeasurer14 = null;
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("", font11, (java.awt.Paint) color12, (float) (byte) 0, textMeasurer14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape23 = textBlock15.calculateBounds(graphics2D16, (float) (-460), (float) 10L, textBlockAnchor19, (float) (byte) -1, (float) 12, (double) 15);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("hi!");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection2, true);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D6.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D9.setBase((double) 1.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        stackedBarRenderer3D9.setBaseToolTipGenerator(categoryToolTipGenerator12);
        stackedBarRenderer3D9.setItemMargin((-1.0d));
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D9.setSeriesOutlineStroke(3, stroke17, true);
        stackedBarRenderer3D6.setBaseOutlineStroke(stroke17, true);
        int int22 = month5.compareTo((java.lang.Object) stackedBarRenderer3D6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month5.next();
        org.jfree.data.gantt.TaskSeries taskSeries24 = taskSeriesCollection2.getSeries((java.lang.Comparable) regularTimePeriod23);
        taskSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) taskSeriesCollection2);
        java.lang.Comparable comparable26 = taskSeries1.getKey();
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNull(taskSeries24);
        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + "hi!" + "'", comparable26.equals("hi!"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = minMaxCategoryRenderer0.getItemLabelGenerator((int) (short) 100, (int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor5 = itemLabelPosition4.getTextAnchor();
        double double6 = itemLabelPosition4.getAngle();
        minMaxCategoryRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition4);
        boolean boolean8 = minMaxCategoryRenderer0.isDrawLines();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryAxis3D13.setTickLabelPaint((java.lang.Comparable) "orange", (java.awt.Paint) color15);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset18 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range20 = defaultBoxAndWhiskerCategoryDataset18.getRangeBounds(false);
        java.lang.Comparable comparable21 = null;
        java.lang.Number number23 = defaultBoxAndWhiskerCategoryDataset18.getMaxOutlier(comparable21, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset18);
        try {
            minMaxCategoryRenderer0.drawItem(graphics2D9, categoryItemRendererState10, rectangle2D11, categoryPlot12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, valueAxis17, (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset18, (int) (byte) 1, 500, (-14336));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertNotNull(range24);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor2 = categoryLabelPosition1.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset4 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range6 = defaultBoxAndWhiskerCategoryDataset4.getRangeBounds(false);
        java.lang.Comparable comparable7 = null;
        java.lang.Number number9 = defaultBoxAndWhiskerCategoryDataset4.getMaxOutlier(comparable7, (java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset11 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset4, (-457));
        boolean boolean12 = categoryLabelPosition1.equals((java.lang.Object) pieDataset11);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNotNull(pieDataset11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }
}

