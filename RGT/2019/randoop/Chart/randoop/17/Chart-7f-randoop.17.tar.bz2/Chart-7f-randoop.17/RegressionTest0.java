import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) -1, 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.util.Date date0 = null;
        java.util.Date date1 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(date0, date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (9) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        int int2 = year0.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str3 = timePeriodValues1.getRangeDescription();
        try {
            org.jfree.data.time.TimePeriod timePeriod5 = timePeriodValues1.getTimePeriod((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            year0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        int int7 = day6.getYear();
        int int8 = day6.getDayOfMonth();
        java.util.Calendar calendar9 = null;
        try {
            day6.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.TimePeriod timePeriod4 = null;
        try {
            timePeriodValues1.add(timePeriod4, (double) 1546329600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(100, 0, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue4 = timePeriodValues1.getDataItem((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue8 = timePeriodValues1.getDataItem(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        int int4 = year0.compareTo((java.lang.Object) 11);
        java.util.Calendar calendar5 = null;
        try {
            year0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        java.lang.Number number10 = null;
        try {
            timePeriodValues1.update(7, number10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 100, (int) (byte) 100, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = regularTimePeriod1.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        try {
            java.lang.Number number5 = timePeriodValues1.getValue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 10);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        long long6 = year4.getFirstMillisecond();
        java.util.Date date7 = year4.getStart();
        boolean boolean8 = year0.equals((java.lang.Object) year4);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        long long11 = year9.getFirstMillisecond();
        java.util.Date date12 = year9.getStart();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        long long15 = year13.getFirstMillisecond();
        java.util.Date date16 = year13.getStart();
        boolean boolean17 = year9.equals((java.lang.Object) year13);
        boolean boolean18 = year4.equals((java.lang.Object) boolean17);
        java.util.Calendar calendar19 = null;
        try {
            long long20 = year4.getFirstMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        boolean boolean3 = timePeriodValues1.getNotify();
        try {
            timePeriodValues1.update(11, (java.lang.Number) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2019,32.0]");
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        try {
            java.lang.Number number10 = timePeriodValues1.getValue((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day6.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 10);
        java.util.Calendar calendar3 = null;
        try {
            day0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        try {
            java.lang.Number number5 = timePeriodValues1.getValue(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.String str8 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test042");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        java.util.Calendar calendar2 = null;
//        try {
//            day0.peg(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        int int6 = timePeriodValues1.getMinMiddleIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue8 = timePeriodValues1.getDataItem((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100);
        int int2 = timePeriodValues1.getMinEndIndex();
        try {
            timePeriodValues1.update(13, (java.lang.Number) 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "TimePeriodValue[2019,32.0]", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        timePeriodValues4.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date4);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int11 = simpleTimePeriod9.compareTo((java.lang.Object) day10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getStart();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass19 = timeZone18.getClass();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date16, timeZone18);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date13, date16);
        java.util.Date date22 = simpleTimePeriod21.getStart();
        try {
            int int23 = simpleTimePeriod9.compareTo((java.lang.Object) date22);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.util.Date cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        long long4 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        java.lang.Number number6 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod5, number6);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("13-June-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) 'a', (int) (byte) 1, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(6, 3, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(11, 0, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable throwable2 = null;
        try {
            seriesException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) year4);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year4.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        int int7 = day6.getYear();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day6.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Object obj1 = null;
        boolean boolean2 = year0.equals(obj1);
        long long3 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100);
        int int2 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener3);
        try {
            timePeriodValues1.update((int) (byte) 1, (java.lang.Number) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(5, 10, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100);
        int int2 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        long long7 = year5.getFirstMillisecond();
        java.util.Date date8 = year5.getStart();
        java.lang.Class<?> wildcardClass9 = year5.getClass();
        timePeriodValues1.setKey((java.lang.Comparable) year5);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year5.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        int int3 = year0.getYear();
        long long4 = year0.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        int int7 = day6.getYear();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getFirstMillisecond();
        java.util.Date date11 = year8.getStart();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass13 = timeZone12.getClass();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date11, timeZone12);
        boolean boolean15 = day6.equals((java.lang.Object) timeZone12);
        java.util.Calendar calendar16 = null;
        try {
            long long17 = day6.getMiddleMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.util.Date date0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date2, timeZone4);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(date0, date2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        long long4 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        long long6 = year0.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        long long6 = year4.getFirstMillisecond();
        java.util.Date date7 = year4.getStart();
        boolean boolean8 = year0.equals((java.lang.Object) year4);
        long long9 = year4.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getFirstMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        boolean boolean3 = timePeriodValues1.getNotify();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        int int5 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = year6.getFirstMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) 0L);
        java.lang.String str11 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass4 = timeZone3.getClass();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date1, timeZone3);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year5.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.lang.String str3 = year0.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date4);
        java.util.Date date10 = simpleTimePeriod9.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int13 = timePeriodValues12.getMaxMiddleIndex();
        timePeriodValues12.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int16 = timePeriodValues12.getMinStartIndex();
        java.lang.Comparable comparable17 = timePeriodValues12.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = timePeriodValues12.createCopy(0, 2019);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.util.Date date22 = year21.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getStart();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass28 = timeZone27.getClass();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date25, timeZone27);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(date22, date25);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        int int32 = simpleTimePeriod30.compareTo((java.lang.Object) day31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        int int34 = year33.getYear();
        boolean boolean35 = simpleTimePeriod30.equals((java.lang.Object) year33);
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) simpleTimePeriod30, (double) 1562097599999L);
        boolean boolean38 = simpleTimePeriod9.equals((java.lang.Object) simpleTimePeriod30);
        try {
            int int40 = simpleTimePeriod30.compareTo((java.lang.Object) "");
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + (short) -1 + "'", comparable17.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        java.lang.Class<?> wildcardClass7 = date3.getClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getFirstMillisecond();
        java.util.Date date11 = year8.getStart();
        java.lang.Class class12 = null;
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date11, timeZone14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        long long19 = year17.getFirstMillisecond();
        java.util.Date date20 = year17.getStart();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass22 = timeZone21.getClass();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date20, timeZone21);
        java.lang.Class<?> wildcardClass24 = date20.getClass();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass26 = timeZone25.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date20, timeZone25);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(regularTimePeriod27);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100);
        timePeriodValues1.setNotify(false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        java.lang.String str10 = timePeriodValues1.getRangeDescription();
        int int11 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDomainDescription("hi!");
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test084");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 10);
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
//        long long6 = year4.getFirstMillisecond();
//        java.util.Date date7 = year4.getStart();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass9 = timeZone8.getClass();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone8);
//        int int11 = day10.getYear();
//        long long12 = day10.getLastMillisecond();
//        boolean boolean13 = day0.equals((java.lang.Object) day10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.previous();
//        java.util.Calendar calendar15 = null;
//        try {
//            day10.peg(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546415999999L + "'", long12 == 1546415999999L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str3 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) -1, 4);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue8 = timePeriodValues6.getDataItem(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriodValues6);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) ' ');
        timePeriodValue5.setValue((java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue5);
        int int9 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) ' ');
        java.lang.Number number13 = timePeriodValue12.getValue();
        java.lang.Object obj14 = timePeriodValue12.clone();
        timePeriodValues1.add(timePeriodValue12);
        java.lang.String str16 = timePeriodValue12.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 32.0d + "'", number13.equals(32.0d));
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TimePeriodValue[2019,32.0]" + "'", str16.equals("TimePeriodValue[2019,32.0]"));
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
        java.lang.String str2 = seriesException1.toString();
        java.lang.String str3 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: Value" + "'", str2.equals("org.jfree.data.general.SeriesException: Value"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: Value" + "'", str3.equals("org.jfree.data.general.SeriesException: Value"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        timePeriodValues1.setDomainDescription("Time");
        try {
            org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValues1.getTimePeriod((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues1.getMinMiddleIndex();
        java.lang.String str11 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        int int7 = day6.getYear();
        long long8 = day6.getFirstMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day6.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date4);
        java.util.Date date10 = simpleTimePeriod9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        long long13 = year11.getFirstMillisecond();
        java.util.Date date14 = year11.getStart();
        long long15 = year11.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year11.previous();
        int int17 = simpleTimePeriod9.compareTo((java.lang.Object) year11);
        long long18 = simpleTimePeriod9.getStartMillis();
        try {
            int int20 = simpleTimePeriod9.compareTo((java.lang.Object) "13-June-2019");
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1562097599999L + "'", long15 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        long long6 = year4.getFirstMillisecond();
        java.util.Date date7 = year4.getStart();
        boolean boolean8 = year0.equals((java.lang.Object) year4);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year0.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        long long3 = year0.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            year0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        try {
            org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValues1.getTimePeriod(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener2);
        try {
            timePeriodValues1.update((int) (short) -1, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100);
        int int4 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        long long9 = year7.getFirstMillisecond();
        java.util.Date date10 = year7.getStart();
        java.lang.Class<?> wildcardClass11 = year7.getClass();
        timePeriodValues3.setKey((java.lang.Comparable) year7);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year7, (double) 2019);
        java.util.Calendar calendar15 = null;
        try {
            year7.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) ' ');
        java.lang.Number number3 = timePeriodValue2.getValue();
        java.lang.String str4 = timePeriodValue2.toString();
        timePeriodValue2.setValue((java.lang.Number) 5);
        java.lang.Object obj7 = timePeriodValue2.clone();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 32.0d + "'", number3.equals(32.0d));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TimePeriodValue[2019,32.0]" + "'", str4.equals("TimePeriodValue[2019,32.0]"));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) year4);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        long long9 = year7.getFirstMillisecond();
        java.util.Date date10 = year7.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass12 = timeZone11.getClass();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10, timeZone11);
        int int14 = day13.getYear();
        boolean boolean15 = year4.equals((java.lang.Object) int14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year4.next();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) ' ');
        java.lang.String str3 = year0.toString();
        int int4 = year0.getYear();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues1.getMinStartIndex();
        int int11 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) ' ');
        java.lang.Number number3 = timePeriodValue2.getValue();
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue2.getPeriod();
        java.lang.String str5 = timePeriodValue2.toString();
        java.lang.Number number6 = null;
        timePeriodValue2.setValue(number6);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 32.0d + "'", number3.equals(32.0d));
        org.junit.Assert.assertNotNull(timePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TimePeriodValue[2019,32.0]" + "'", str5.equals("TimePeriodValue[2019,32.0]"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        long long4 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 0);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year0.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        java.lang.String str2 = timePeriodValues1.getDescription();
        int int3 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        long long9 = year7.getFirstMillisecond();
        java.util.Date date10 = year7.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        long long13 = year11.getFirstMillisecond();
        java.util.Date date14 = year11.getStart();
        boolean boolean15 = year7.equals((java.lang.Object) year11);
        boolean boolean16 = day6.equals((java.lang.Object) year7);
        int int17 = day6.getDayOfMonth();
        java.util.Calendar calendar18 = null;
        try {
            long long19 = day6.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date4);
        java.util.Date date10 = simpleTimePeriod9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        long long13 = year11.getFirstMillisecond();
        java.util.Date date14 = year11.getStart();
        long long15 = year11.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year11.previous();
        int int17 = simpleTimePeriod9.compareTo((java.lang.Object) year11);
        java.lang.Object obj18 = null;
        int int19 = year11.compareTo(obj18);
        java.util.Calendar calendar20 = null;
        try {
            long long21 = year11.getLastMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1562097599999L + "'", long15 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        long long6 = year4.getFirstMillisecond();
        java.util.Date date7 = year4.getStart();
        boolean boolean8 = year0.equals((java.lang.Object) year4);
        int int9 = year0.getYear();
        java.util.Date date10 = year0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 10);
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
//        long long6 = year4.getFirstMillisecond();
//        java.util.Date date7 = year4.getStart();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass9 = timeZone8.getClass();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone8);
//        int int11 = day10.getYear();
//        long long12 = day10.getLastMillisecond();
//        boolean boolean13 = day0.equals((java.lang.Object) day10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.previous();
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = day10.getFirstMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546415999999L + "'", long12 == 1546415999999L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        int int7 = day6.getYear();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getFirstMillisecond();
        java.util.Date date11 = year8.getStart();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass13 = timeZone12.getClass();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date11, timeZone12);
        boolean boolean15 = day6.equals((java.lang.Object) timeZone12);
        int int16 = day6.getDayOfMonth();
        int int17 = day6.getDayOfMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=9]");
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getMiddleMillisecond();
//        long long4 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.setNotify(false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100);
        int int2 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone6);
        timePeriodValues1.setKey((java.lang.Comparable) year8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[2019,100]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.util.Date date14 = year13.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass17 = timeZone16.getClass();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(date11, date14);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        int int21 = simpleTimePeriod19.compareTo((java.lang.Object) day20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int23 = year22.getYear();
        boolean boolean24 = simpleTimePeriod19.equals((java.lang.Object) year22);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 1562097599999L);
        timePeriodValues1.setDescription("");
        timePeriodValues1.setKey((java.lang.Comparable) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        int int10 = timePeriodValues9.getMinEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.util.Date date14 = year13.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass17 = timeZone16.getClass();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(date11, date14);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        int int21 = simpleTimePeriod19.compareTo((java.lang.Object) day20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int23 = year22.getYear();
        boolean boolean24 = simpleTimePeriod19.equals((java.lang.Object) year22);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 1562097599999L);
        long long27 = simpleTimePeriod19.getStartMillis();
        java.util.Date date28 = simpleTimePeriod19.getStart();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
        org.junit.Assert.assertNotNull(date28);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (4) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1, "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]", "");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str4.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) year4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener7);
        boolean boolean10 = timePeriodValues1.equals((java.lang.Object) (-1.0f));
        java.lang.Class<?> wildcardClass11 = timePeriodValues1.getClass();
        int int12 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        long long9 = year7.getFirstMillisecond();
        java.util.Date date10 = year7.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        long long13 = year11.getFirstMillisecond();
        java.util.Date date14 = year11.getStart();
        boolean boolean15 = year7.equals((java.lang.Object) year11);
        boolean boolean16 = day6.equals((java.lang.Object) year7);
        int int17 = day6.getDayOfMonth();
        java.lang.String str18 = day6.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1-January-2019" + "'", str18.equals("1-January-2019"));
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        int int2 = timePeriodValues1.getMaxMiddleIndex();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) ' ');
//        timePeriodValue5.setValue((java.lang.Number) 100);
//        timePeriodValues1.add(timePeriodValue5);
//        java.lang.String str9 = timePeriodValue5.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getFirstMillisecond();
//        int int12 = day10.getMonth();
//        java.util.Date date13 = day10.getStart();
//        long long14 = day10.getSerialIndex();
//        boolean boolean15 = timePeriodValue5.equals((java.lang.Object) long14);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TimePeriodValue[2019,100]" + "'", str9.equals("TimePeriodValue[2019,100]"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        timePeriodValues9.setDescription("Value");
        int int12 = timePeriodValues9.getMinStartIndex();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        long long15 = year13.getFirstMillisecond();
        java.util.Date date16 = year13.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        long long19 = year17.getFirstMillisecond();
        java.util.Date date20 = year17.getStart();
        boolean boolean21 = year13.equals((java.lang.Object) year17);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) year13, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date3);
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date3, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 10);
//        long long3 = day0.getMiddleMillisecond();
//        int int4 = day0.getMonth();
//        int int5 = day0.getYear();
//        java.util.Calendar calendar6 = null;
//        try {
//            day0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test131");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        int int2 = timePeriodValues1.getMaxMiddleIndex();
//        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) (byte) 10);
//        long long8 = day5.getMiddleMillisecond();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
//        long long11 = year9.getFirstMillisecond();
//        java.util.Date date12 = year9.getStart();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass14 = timeZone13.getClass();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12, timeZone13);
//        int int16 = day15.getYear();
//        long long17 = day15.getLastMillisecond();
//        boolean boolean18 = day5.equals((java.lang.Object) day15);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) 11);
//        int int21 = timePeriodValues1.getMaxEndIndex();
//        org.jfree.data.general.SeriesException seriesException23 = new org.jfree.data.general.SeriesException("Value");
//        java.lang.String str24 = seriesException23.toString();
//        boolean boolean25 = timePeriodValues1.equals((java.lang.Object) str24);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560452399999L + "'", long8 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546415999999L + "'", long17 == 1546415999999L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.general.SeriesException: Value" + "'", str24.equals("org.jfree.data.general.SeriesException: Value"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 10);
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
//        long long6 = year4.getFirstMillisecond();
//        java.util.Date date7 = year4.getStart();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass9 = timeZone8.getClass();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone8);
//        int int11 = day10.getYear();
//        long long12 = day10.getLastMillisecond();
//        boolean boolean13 = day0.equals((java.lang.Object) day10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day10, "1-January-2019", "1-January-2019");
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546415999999L + "'", long12 == 1546415999999L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getFirstMillisecond();
        java.util.Date date11 = year8.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        long long14 = year12.getFirstMillisecond();
        java.util.Date date15 = year12.getStart();
        boolean boolean16 = year8.equals((java.lang.Object) year12);
        int int17 = day7.compareTo((java.lang.Object) year12);
        java.util.Calendar calendar18 = null;
        try {
            year12.peg(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        timePeriodValues9.setDescription("Value");
        int int12 = timePeriodValues9.getMinStartIndex();
        timePeriodValues9.setDescription("1-January-2019");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) ' ');
        java.lang.Number number3 = timePeriodValue2.getValue();
        java.lang.Object obj4 = timePeriodValue2.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        timePeriodValues6.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        boolean boolean11 = timePeriodValues6.equals((java.lang.Object) year9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener12);
        boolean boolean15 = timePeriodValues6.equals((java.lang.Object) (-1.0f));
        boolean boolean16 = timePeriodValue2.equals((java.lang.Object) (-1.0f));
        java.lang.String str17 = timePeriodValue2.toString();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 32.0d + "'", number3.equals(32.0d));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "TimePeriodValue[2019,32.0]" + "'", str17.equals("TimePeriodValue[2019,32.0]"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 10);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (short) 10 + "'", obj2.equals((short) 10));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) ' ');
        org.jfree.data.time.TimePeriod timePeriod3 = timePeriodValue2.getPeriod();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass11 = timeZone10.getClass();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date8, timeZone10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date5, date8);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        int int15 = simpleTimePeriod13.compareTo((java.lang.Object) day14);
        boolean boolean16 = timePeriodValue2.equals((java.lang.Object) int15);
        org.junit.Assert.assertNotNull(timePeriod3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        long long4 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        int int7 = year0.getYear();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year0.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        int int4 = timePeriodValues1.getMaxStartIndex();
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        int int2 = day0.getMonth();
//        java.util.Date date3 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        int int5 = day0.getDayOfMonth();
//        long long6 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Calendar calendar2 = null;
        try {
            year0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) ' ');
        timePeriodValue2.setValue((java.lang.Number) 100);
        timePeriodValue2.setValue((java.lang.Number) (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        int int7 = day6.getYear();
        long long8 = day6.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int11 = timePeriodValues10.getMaxMiddleIndex();
        timePeriodValues10.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int14 = timePeriodValues10.getMinStartIndex();
        java.lang.Comparable comparable15 = timePeriodValues10.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = timePeriodValues10.createCopy(0, 2019);
        int int19 = timePeriodValues18.getMinEndIndex();
        int int20 = day6.compareTo((java.lang.Object) int19);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546415999999L + "'", long8 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + (short) -1 + "'", comparable15.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 6);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue3 = timePeriodValues1.getDataItem(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDomainDescription("Value");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        timePeriodValues1.setRangeDescription("TimePeriodValue[2019,32.0]");
        java.lang.Object obj6 = timePeriodValues1.clone();
        timePeriodValues1.setNotify(false);
        org.junit.Assert.assertNotNull(obj6);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        int int2 = timePeriodValues1.getMaxMiddleIndex();
//        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) (byte) 10);
//        long long8 = day5.getMiddleMillisecond();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
//        long long11 = year9.getFirstMillisecond();
//        java.util.Date date12 = year9.getStart();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass14 = timeZone13.getClass();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12, timeZone13);
//        int int16 = day15.getYear();
//        long long17 = day15.getLastMillisecond();
//        boolean boolean18 = day5.equals((java.lang.Object) day15);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) 11);
//        java.util.Calendar calendar21 = null;
//        try {
//            day15.peg(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560452399999L + "'", long8 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546415999999L + "'", long17 == 1546415999999L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.util.Date date14 = year13.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass17 = timeZone16.getClass();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(date11, date14);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        int int21 = simpleTimePeriod19.compareTo((java.lang.Object) day20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int23 = year22.getYear();
        boolean boolean24 = simpleTimePeriod19.equals((java.lang.Object) year22);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 1562097599999L);
        timePeriodValues1.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener29);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        int int5 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = year6.getFirstMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) 0L);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int13 = timePeriodValues12.getMaxMiddleIndex();
        int int14 = timePeriodValues12.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues12.createCopy(6, 2019);
        java.lang.String str18 = timePeriodValues12.getRangeDescription();
        java.lang.String str19 = timePeriodValues12.getDomainDescription();
        boolean boolean20 = year6.equals((java.lang.Object) str19);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        timePeriodValues22.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        timePeriodValues22.setRangeDescription("TimePeriodValue[2019,32.0]");
        java.lang.Object obj27 = timePeriodValues22.clone();
        int int28 = timePeriodValues22.getItemCount();
        int int29 = year6.compareTo((java.lang.Object) int28);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Value" + "'", str18.equals("Value"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str3 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) -1, 4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        int int9 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues1.getMaxStartIndex();
        try {
            java.lang.Number number12 = timePeriodValues1.getValue((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100);
        int int2 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener3);
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        long long6 = year4.getFirstMillisecond();
        java.util.Date date7 = year4.getStart();
        boolean boolean8 = year0.equals((java.lang.Object) year4);
        java.lang.String str9 = year4.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) 0);
        java.lang.Number number12 = timePeriodValue11.getValue();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.0d + "'", number12.equals(0.0d));
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate4);
//        java.util.Calendar calendar7 = null;
//        try {
//            day6.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        boolean boolean8 = timePeriodValues1.isEmpty();
        try {
            timePeriodValues1.update(13, (java.lang.Number) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        long long6 = year4.getFirstMillisecond();
        java.util.Date date7 = year4.getStart();
        boolean boolean8 = year0.equals((java.lang.Object) year4);
        java.lang.String str9 = year4.toString();
        long long10 = year4.getLastMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year4.getMiddleMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date4);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int11 = simpleTimePeriod9.compareTo((java.lang.Object) day10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        int int13 = year12.getYear();
        boolean boolean14 = simpleTimePeriod9.equals((java.lang.Object) year12);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        java.lang.String str17 = timePeriodValues16.getDescription();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year18, (double) ' ');
        timePeriodValues16.add(timePeriodValue20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (double) ' ');
        org.jfree.data.time.TimePeriod timePeriod25 = timePeriodValue24.getPeriod();
        timePeriodValues16.add(timePeriodValue24);
        try {
            int int27 = simpleTimePeriod9.compareTo((java.lang.Object) timePeriodValues16);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(timePeriod25);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getItemCount();
        try {
            org.jfree.data.time.TimePeriod timePeriod5 = timePeriodValues1.getTimePeriod(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        java.lang.String str10 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: Value");
        int int13 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        int int7 = day6.getYear();
        long long8 = day6.getFirstMillisecond();
        int int9 = day6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day6.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str3 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) -1, 4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        int int9 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,100]");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues1.getMinMiddleIndex();
        try {
            java.lang.Number number12 = timePeriodValues1.getValue((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) ' ');
        java.lang.Number number3 = timePeriodValue2.getValue();
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue2.getPeriod();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue(timePeriod4, (double) (byte) 1);
        java.lang.Number number7 = timePeriodValue6.getValue();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 32.0d + "'", number3.equals(32.0d));
        org.junit.Assert.assertNotNull(timePeriod4);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.0d + "'", number7.equals(1.0d));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        timePeriodValues1.fireSeriesChanged();
        int int11 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) ' ');
        timePeriodValue5.setValue((java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue5);
        int int9 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriod timePeriod10 = null;
        try {
            timePeriodValues1.add(timePeriod10, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Object obj11 = timePeriodValues1.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        long long6 = year4.getFirstMillisecond();
        java.util.Date date7 = year4.getStart();
        boolean boolean8 = year0.equals((java.lang.Object) year4);
        long long9 = year4.getMiddleMillisecond();
        long long10 = year4.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int13 = timePeriodValues12.getMaxMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) ' ');
        timePeriodValue16.setValue((java.lang.Number) 100);
        timePeriodValues12.add(timePeriodValue16);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int22 = timePeriodValues21.getMaxMiddleIndex();
        timePeriodValues21.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int25 = timePeriodValues21.getMinStartIndex();
        boolean boolean26 = timePeriodValue16.equals((java.lang.Object) timePeriodValues21);
        boolean boolean27 = year4.equals((java.lang.Object) boolean26);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1562097599999L + "'", long9 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        long long5 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        int int4 = year0.compareTo((java.lang.Object) 11);
        long long5 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year0.next();
        java.util.Calendar calendar9 = null;
        try {
            year0.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
//        long long2 = year0.getFirstMillisecond();
//        java.util.Date date3 = year0.getStart();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
//        java.lang.Class<?> wildcardClass7 = date3.getClass();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        long long10 = year8.getFirstMillisecond();
//        java.util.Date date11 = year8.getStart();
//        java.lang.Class class12 = null;
//        java.util.Date date13 = null;
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date11, timeZone14);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date11);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        long long19 = day18.getFirstMillisecond();
//        int int20 = day18.getMonth();
//        java.util.Date date21 = day18.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date11, date21);
//        long long23 = simpleTimePeriod22.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long23, "hi!", "TimePeriodValue[2019,100]");
//        try {
//            org.jfree.data.time.TimePeriod timePeriod28 = timePeriodValues26.getTimePeriod((int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560409200000L + "'", long19 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
//    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
//        long long2 = year0.getFirstMillisecond();
//        java.util.Date date3 = year0.getStart();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
//        java.lang.Class<?> wildcardClass7 = date3.getClass();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        long long10 = year8.getFirstMillisecond();
//        java.util.Date date11 = year8.getStart();
//        java.lang.Class class12 = null;
//        java.util.Date date13 = null;
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date11, timeZone14);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
//        long long19 = year17.getFirstMillisecond();
//        java.util.Date date20 = year17.getStart();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass22 = timeZone21.getClass();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date20, timeZone21);
//        java.lang.Class<?> wildcardClass24 = date20.getClass();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.previous();
//        long long27 = year25.getFirstMillisecond();
//        java.util.Date date28 = year25.getStart();
//        java.lang.Class class29 = null;
//        java.util.Date date30 = null;
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date28, timeZone31);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date28);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        long long36 = day35.getFirstMillisecond();
//        int int37 = day35.getMonth();
//        java.util.Date date38 = day35.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date28, date38);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(date11, date28);
//        java.lang.Object obj41 = null;
//        boolean boolean42 = simpleTimePeriod40.equals(obj41);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560409200000L + "'", long36 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        int int5 = year0.getYear();
        int int6 = year0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int9 = timePeriodValues8.getMaxMiddleIndex();
        timePeriodValues8.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int12 = timePeriodValues8.getMinStartIndex();
        timePeriodValues8.setDomainDescription("hi!");
        int int15 = year0.compareTo((java.lang.Object) timePeriodValues8);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        java.lang.String str2 = timePeriodValues1.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener3);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        int int4 = timePeriodValues2.getMinMiddleIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        long long4 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod6, (java.lang.Number) (byte) 100);
        timePeriodValue8.setValue((java.lang.Number) (byte) 100);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 100, 0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        int int4 = year0.compareTo((java.lang.Object) 11);
        long long5 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        long long7 = regularTimePeriod6.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1593676799999L + "'", long7 == 1593676799999L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) ' ');
        java.lang.Number number3 = timePeriodValue2.getValue();
        java.lang.String str4 = timePeriodValue2.toString();
        timePeriodValue2.setValue((java.lang.Number) 5);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int9 = timePeriodValues8.getMaxMiddleIndex();
        java.lang.String str10 = timePeriodValues8.getRangeDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues8.createCopy((int) (short) -1, 4);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues8.addPropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = timePeriodValue2.equals((java.lang.Object) propertyChangeListener14);
        java.lang.Object obj17 = timePeriodValue2.clone();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 32.0d + "'", number3.equals(32.0d));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TimePeriodValue[2019,32.0]" + "'", str4.equals("TimePeriodValue[2019,32.0]"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        java.lang.String str10 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) year4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener7);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date3);
        long long8 = day7.getFirstMillisecond();
        int int9 = day7.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: Value");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        long long9 = year7.getFirstMillisecond();
        java.util.Date date10 = year7.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        long long13 = year11.getFirstMillisecond();
        java.util.Date date14 = year11.getStart();
        boolean boolean15 = year7.equals((java.lang.Object) year11);
        boolean boolean16 = day6.equals((java.lang.Object) year7);
        int int17 = day6.getDayOfMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int17);
        try {
            org.jfree.data.time.TimePeriod timePeriod20 = timePeriodValues18.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        java.lang.Class<?> wildcardClass7 = date3.getClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getFirstMillisecond();
        java.util.Date date11 = year8.getStart();
        java.lang.Class class12 = null;
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date11, timeZone14);
        java.util.TimeZone timeZone17 = null;
        try {
            org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date11, timeZone17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod16);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) ' ');
        java.lang.Number number3 = timePeriodValue2.getValue();
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue2.getPeriod();
        java.lang.String str5 = timePeriodValue2.toString();
        java.lang.String str6 = timePeriodValue2.toString();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 32.0d + "'", number3.equals(32.0d));
        org.junit.Assert.assertNotNull(timePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TimePeriodValue[2019,32.0]" + "'", str5.equals("TimePeriodValue[2019,32.0]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TimePeriodValue[2019,32.0]" + "'", str6.equals("TimePeriodValue[2019,32.0]"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        java.lang.String str2 = timePeriodValues1.getDescription();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) ' ');
        timePeriodValues1.add(timePeriodValue5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) ' ');
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue9.getPeriod();
        timePeriodValues1.add(timePeriodValue9);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = timePeriodValues1.createCopy(0, (int) (byte) 0);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(timePeriod10);
        org.junit.Assert.assertNotNull(timePeriodValues14);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener4);
        try {
            timePeriodValues1.delete((int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
//        long long2 = year0.getFirstMillisecond();
//        java.util.Date date3 = year0.getStart();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
//        java.lang.Class<?> wildcardClass7 = date3.getClass();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        long long10 = year8.getFirstMillisecond();
//        java.util.Date date11 = year8.getStart();
//        java.lang.Class class12 = null;
//        java.util.Date date13 = null;
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date11, timeZone14);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
//        long long19 = year17.getFirstMillisecond();
//        java.util.Date date20 = year17.getStart();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass22 = timeZone21.getClass();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date20, timeZone21);
//        java.lang.Class<?> wildcardClass24 = date20.getClass();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.previous();
//        long long27 = year25.getFirstMillisecond();
//        java.util.Date date28 = year25.getStart();
//        java.lang.Class class29 = null;
//        java.util.Date date30 = null;
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date28, timeZone31);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date28);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        long long36 = day35.getFirstMillisecond();
//        int int37 = day35.getMonth();
//        java.util.Date date38 = day35.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date28, date38);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(date11, date28);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        java.util.Date date42 = year41.getStart();
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date42);
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass45 = timeZone44.getClass();
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date42, timeZone44);
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year47.previous();
//        long long49 = year47.getFirstMillisecond();
//        java.util.Date date50 = year47.getStart();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass52 = timeZone51.getClass();
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date50, timeZone51);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date42, timeZone51);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date11, timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day55.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560409200000L + "'", long36 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1546329600000L + "'", long49 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100);
        int int2 = timePeriodValues1.getMinEndIndex();
        java.lang.String str3 = timePeriodValues1.getDescription();
        int int4 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        long long6 = year4.getFirstMillisecond();
        java.util.Date date7 = year4.getStart();
        boolean boolean8 = year0.equals((java.lang.Object) year4);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        long long11 = year9.getFirstMillisecond();
        java.util.Date date12 = year9.getStart();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        long long15 = year13.getFirstMillisecond();
        java.util.Date date16 = year13.getStart();
        boolean boolean17 = year9.equals((java.lang.Object) year13);
        boolean boolean18 = year4.equals((java.lang.Object) boolean17);
        java.util.Calendar calendar19 = null;
        try {
            year4.peg(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues1.getMinStartIndex();
        int int11 = timePeriodValues1.getItemCount();
        boolean boolean12 = timePeriodValues1.getNotify();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "2019");
        try {
            org.jfree.data.time.TimePeriod timePeriod3 = timePeriodValues1.getTimePeriod(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        int int5 = timePeriodValues1.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener6);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue9 = timePeriodValues1.getDataItem((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getFirstMillisecond();
        java.util.Date date11 = year8.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        long long14 = year12.getFirstMillisecond();
        java.util.Date date15 = year12.getStart();
        boolean boolean16 = year8.equals((java.lang.Object) year12);
        int int17 = day7.compareTo((java.lang.Object) year12);
        int int18 = day7.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("13-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test200");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        int int5 = timePeriodValues4.getMinStartIndex();
//        try {
//            org.jfree.data.time.TimePeriodValue timePeriodValue7 = timePeriodValues4.getDataItem((int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        int int10 = timePeriodValues9.getItemCount();
        try {
            timePeriodValues9.update(100, (java.lang.Number) (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) (byte) 10);
//        long long5 = day2.getMiddleMillisecond();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        long long8 = year6.getFirstMillisecond();
//        java.util.Date date9 = year6.getStart();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass11 = timeZone10.getClass();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date9, timeZone10);
//        int int13 = day12.getYear();
//        long long14 = day12.getLastMillisecond();
//        boolean boolean15 = day2.equals((java.lang.Object) day12);
//        timePeriodValues1.setKey((java.lang.Comparable) boolean15);
//        java.lang.Class<?> wildcardClass17 = timePeriodValues1.getClass();
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560452399999L + "'", long5 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546415999999L + "'", long14 == 1546415999999L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        java.lang.Class<?> wildcardClass7 = date3.getClass();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        int int11 = day8.compareTo((java.lang.Object) (-1L));
        long long12 = day8.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        timePeriodValues1.setRangeDescription("TimePeriodValue[2019,32.0]");
        java.lang.Object obj6 = timePeriodValues1.clone();
        int int7 = timePeriodValues1.getItemCount();
        int int8 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getFirstMillisecond();
        java.util.Date date11 = year8.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        long long14 = year12.getFirstMillisecond();
        java.util.Date date15 = year12.getStart();
        boolean boolean16 = year8.equals((java.lang.Object) year12);
        int int17 = day7.compareTo((java.lang.Object) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year12.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        int int2 = timePeriodValues1.getMaxMiddleIndex();
//        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) (byte) 10);
//        long long8 = day5.getMiddleMillisecond();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
//        long long11 = year9.getFirstMillisecond();
//        java.util.Date date12 = year9.getStart();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass14 = timeZone13.getClass();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12, timeZone13);
//        int int16 = day15.getYear();
//        long long17 = day15.getLastMillisecond();
//        boolean boolean18 = day5.equals((java.lang.Object) day15);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) 11);
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        int int23 = timePeriodValues22.getMaxMiddleIndex();
//        timePeriodValues22.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
//        int int26 = timePeriodValues22.getMinStartIndex();
//        java.lang.Comparable comparable27 = timePeriodValues22.getKey();
//        org.jfree.data.time.TimePeriodValues timePeriodValues30 = timePeriodValues22.createCopy(0, 2019);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        java.util.Date date32 = year31.getStart();
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        java.util.Date date35 = year34.getStart();
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass38 = timeZone37.getClass();
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date35, timeZone37);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(date32, date35);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        int int42 = simpleTimePeriod40.compareTo((java.lang.Object) day41);
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
//        int int44 = year43.getYear();
//        boolean boolean45 = simpleTimePeriod40.equals((java.lang.Object) year43);
//        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod40, (double) 1562097599999L);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod40, (java.lang.Number) (-1L));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560452399999L + "'", long8 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546415999999L + "'", long17 == 1546415999999L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + (short) -1 + "'", comparable27.equals((short) -1));
//        org.junit.Assert.assertNotNull(timePeriodValues30);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.util.Date date14 = year13.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass17 = timeZone16.getClass();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(date11, date14);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        int int21 = simpleTimePeriod19.compareTo((java.lang.Object) day20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int23 = year22.getYear();
        boolean boolean24 = simpleTimePeriod19.equals((java.lang.Object) year22);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 1562097599999L);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener27);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener29);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("1-January-2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 1-January-2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: 1-January-2019"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date3);
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date3, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 9);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.String str3 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 9 + "'", obj2.equals(9));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        int int5 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = year6.getFirstMillisecond();
        int int10 = year6.compareTo((java.lang.Object) 11);
        long long11 = year6.getLastMillisecond();
        timePeriodValues1.setKey((java.lang.Comparable) long11);
        try {
            org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValues1.getTimePeriod((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = year11.getYear();
        long long13 = year11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year11, (-1.0d));
        int int16 = year11.getYear();
        long long17 = year11.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        boolean boolean3 = timePeriodValues1.getNotify();
        java.lang.String str4 = timePeriodValues1.getDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        long long4 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        int int7 = year0.getYear();
        long long8 = year0.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 4);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (11) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        int int2 = timePeriodValues1.getMaxMiddleIndex();
//        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) (byte) 10);
//        long long8 = day5.getMiddleMillisecond();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
//        long long11 = year9.getFirstMillisecond();
//        java.util.Date date12 = year9.getStart();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass14 = timeZone13.getClass();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12, timeZone13);
//        int int16 = day15.getYear();
//        long long17 = day15.getLastMillisecond();
//        boolean boolean18 = day5.equals((java.lang.Object) day15);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) 11);
//        java.util.Date date21 = day15.getStart();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560452399999L + "'", long8 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546415999999L + "'", long17 == 1546415999999L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int8 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        int int4 = year0.compareTo((java.lang.Object) 11);
        long long5 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year0.next();
        java.lang.String str8 = year0.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=10]");
        java.lang.String str2 = seriesException1.toString();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,100]");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException5);
        java.lang.Throwable[] throwableArray7 = seriesException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass4 = timeZone3.getClass();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date1, timeZone3);
        long long6 = year5.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year5.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 4, "TimePeriodValue[2019,32.0]", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener4);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100);
        int int2 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener3);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue6 = timePeriodValues1.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date4);
        java.util.Date date10 = simpleTimePeriod9.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int13 = timePeriodValues12.getMaxMiddleIndex();
        timePeriodValues12.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int16 = timePeriodValues12.getMinStartIndex();
        java.lang.Comparable comparable17 = timePeriodValues12.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = timePeriodValues12.createCopy(0, 2019);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.util.Date date22 = year21.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getStart();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass28 = timeZone27.getClass();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date25, timeZone27);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(date22, date25);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        int int32 = simpleTimePeriod30.compareTo((java.lang.Object) day31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        int int34 = year33.getYear();
        boolean boolean35 = simpleTimePeriod30.equals((java.lang.Object) year33);
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) simpleTimePeriod30, (double) 1562097599999L);
        boolean boolean38 = simpleTimePeriod9.equals((java.lang.Object) simpleTimePeriod30);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.previous();
        long long41 = year39.getFirstMillisecond();
        long long42 = year39.getFirstMillisecond();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue45 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day43, (java.lang.Number) (byte) 10);
        int int46 = year39.compareTo((java.lang.Object) (byte) 10);
        boolean boolean47 = simpleTimePeriod9.equals((java.lang.Object) year39);
        long long48 = year39.getSerialIndex();
        java.util.Calendar calendar49 = null;
        try {
            long long50 = year39.getLastMillisecond(calendar49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + (short) -1 + "'", comparable17.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1546329600000L + "'", long41 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1546329600000L + "'", long42 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2019L + "'", long48 == 2019L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        java.lang.Class<?> wildcardClass7 = date3.getClass();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date3);
        java.lang.Class class9 = null;
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date3, timeZone11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        java.lang.String str10 = timePeriodValues9.getDescription();
        timePeriodValues9.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str10.equals("org.jfree.data.general.SeriesChangeEvent[source=10]"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) ' ');
        java.lang.String str3 = year0.toString();
        long long4 = year0.getFirstMillisecond();
        java.lang.String str5 = year0.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        java.lang.String str2 = timePeriodValues1.getDescription();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) ' ');
        timePeriodValues1.add(timePeriodValue5);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        boolean boolean9 = timePeriodValues8.getNotify();
        boolean boolean10 = timePeriodValue5.equals((java.lang.Object) boolean9);
        java.lang.Number number11 = timePeriodValue5.getValue();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 32.0d + "'", number11.equals(32.0d));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        int int7 = day6.getYear();
        long long8 = day6.getLastMillisecond();
        int int9 = day6.getDayOfMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546415999999L + "'", long8 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.Calendar calendar4 = null;
        try {
            year0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        int int7 = day6.getYear();
        long long8 = day6.getFirstMillisecond();
        int int9 = day6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day6.previous();
        long long11 = day6.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        long long6 = year4.getFirstMillisecond();
        java.util.Date date7 = year4.getStart();
        boolean boolean8 = year0.equals((java.lang.Object) year4);
        long long9 = year0.getMiddleMillisecond();
        int int10 = year0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1562097599999L + "'", long9 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        timePeriodValues1.setRangeDescription("TimePeriodValue[2019,32.0]");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener6);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
//        long long2 = year0.getFirstMillisecond();
//        java.util.Date date3 = year0.getStart();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
//        java.lang.Class<?> wildcardClass7 = date3.getClass();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        long long10 = year8.getFirstMillisecond();
//        java.util.Date date11 = year8.getStart();
//        java.lang.Class class12 = null;
//        java.util.Date date13 = null;
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date11, timeZone14);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date11);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        long long19 = day18.getFirstMillisecond();
//        int int20 = day18.getMonth();
//        java.util.Date date21 = day18.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date11, date21);
//        long long23 = simpleTimePeriod22.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long23, "hi!", "TimePeriodValue[2019,100]");
//        boolean boolean27 = timePeriodValues26.isEmpty();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560409200000L + "'", long19 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) ' ');
        org.jfree.data.time.TimePeriod timePeriod3 = timePeriodValue2.getPeriod();
        java.lang.String str4 = timePeriodValue2.toString();
        java.lang.Object obj5 = timePeriodValue2.clone();
        org.junit.Assert.assertNotNull(timePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TimePeriodValue[2019,32.0]" + "'", str4.equals("TimePeriodValue[2019,32.0]"));
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass4 = timeZone3.getClass();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date1, timeZone3);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = year6.getFirstMillisecond();
        java.util.Date date9 = year6.getStart();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass11 = timeZone10.getClass();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date9, timeZone10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date1, timeZone10);
        long long14 = day13.getFirstMillisecond();
        long long15 = day13.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546372799999L + "'", long15 == 1546372799999L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str3 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) -1, 4);
        java.lang.String str7 = timePeriodValues6.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        try {
            timePeriodValues1.update((int) (byte) -1, (java.lang.Number) 1560409200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) year4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener10);
        int int12 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        timePeriodValues9.setDescription("Value");
        timePeriodValues9.delete((int) (byte) 10, (int) (byte) 0);
        java.lang.Comparable comparable15 = timePeriodValues9.getKey();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + (short) -1 + "'", comparable15.equals((short) -1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "TimePeriodValue[2019,32.0]", "");
        timePeriodValues4.setNotify(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        int int7 = timePeriodValues6.getMaxMiddleIndex();
//        timePeriodValues6.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
//        int int10 = timePeriodValues6.getMinStartIndex();
//        int int11 = day0.compareTo((java.lang.Object) timePeriodValues6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) '#');
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) ' ');
        timePeriodValue5.setValue((java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue5);
        timePeriodValue5.setValue((java.lang.Number) 10L);
        java.lang.String str11 = timePeriodValue5.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TimePeriodValue[2019,10]" + "'", str11.equals("TimePeriodValue[2019,10]"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) ' ');
        timePeriodValue5.setValue((java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue5);
        int int9 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) ' ');
        java.lang.Number number13 = timePeriodValue12.getValue();
        java.lang.Object obj14 = timePeriodValue12.clone();
        timePeriodValues1.add(timePeriodValue12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener16);
        timePeriodValues1.fireSeriesChanged();
        java.lang.Object obj19 = timePeriodValues1.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 32.0d + "'", number13.equals(32.0d));
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        java.lang.String str2 = timePeriodValues1.getDescription();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) ' ');
        timePeriodValues1.add(timePeriodValue5);
        boolean boolean7 = timePeriodValues1.getNotify();
        int int8 = timePeriodValues1.getMaxMiddleIndex();
        try {
            timePeriodValues1.delete(1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int5 = timePeriodValues4.getMaxMiddleIndex();
        timePeriodValues4.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int8 = timePeriodValues4.getMinStartIndex();
        int int9 = timePeriodValues4.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass10 = timePeriodValues4.getClass();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        long long13 = year11.getFirstMillisecond();
        java.util.Date date14 = year11.getStart();
        java.lang.Class<?> wildcardClass15 = year11.getClass();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        long long18 = year16.getFirstMillisecond();
        java.util.Date date19 = year16.getStart();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass21 = timeZone20.getClass();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date19, timeZone20);
        java.lang.Class<?> wildcardClass23 = date19.getClass();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date19);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        long long29 = year27.getFirstMillisecond();
        java.util.Date date30 = year27.getStart();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass32 = timeZone31.getClass();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date30, timeZone31);
        java.lang.Class<?> wildcardClass34 = date30.getClass();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date30);
        java.lang.Class class36 = null;
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date30, timeZone38);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date19, timeZone38);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        java.util.Date date43 = year42.getStart();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date43);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        java.util.Date date46 = year45.getStart();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass49 = timeZone48.getClass();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date46, timeZone48);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod(date43, date46);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
        int int53 = simpleTimePeriod51.compareTo((java.lang.Object) day52);
        boolean boolean55 = simpleTimePeriod51.equals((java.lang.Object) 1560409200000L);
        java.util.Date date56 = simpleTimePeriod51.getEnd();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year57.previous();
        long long59 = year57.getFirstMillisecond();
        java.util.Date date60 = year57.getStart();
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass62 = timeZone61.getClass();
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date60, timeZone61);
        java.lang.Class<?> wildcardClass64 = date60.getClass();
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date60);
        java.lang.Class class66 = null;
        java.util.Date date67 = null;
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date60, timeZone68);
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date56, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date19, timeZone68);
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date1, timeZone68);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1546329600000L + "'", long59 == 1546329600000L);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNull(regularTimePeriod72);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100);
        int int2 = timePeriodValues1.getMinStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        java.lang.Class<?> wildcardClass7 = date3.getClass();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        long long10 = day8.getLastMillisecond();
        long long11 = day8.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546415999999L + "'", long10 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43466L + "'", long11 == 43466L);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=9]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.util.Date date14 = year13.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass17 = timeZone16.getClass();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(date11, date14);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        int int21 = simpleTimePeriod19.compareTo((java.lang.Object) day20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int23 = year22.getYear();
        boolean boolean24 = simpleTimePeriod19.equals((java.lang.Object) year22);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 1562097599999L);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener27);
        java.lang.String str29 = timePeriodValues1.getDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str29.equals("org.jfree.data.general.SeriesChangeEvent[source=10]"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        long long6 = year4.getFirstMillisecond();
        java.util.Date date7 = year4.getStart();
        boolean boolean8 = year0.equals((java.lang.Object) year4);
        java.lang.String str9 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year4.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-1), 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.util.Date date1 = year0.getStart();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        java.util.Date date4 = year3.getStart();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone6);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date4);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = simpleTimePeriod9.compareTo((java.lang.Object) day10);
//        boolean boolean13 = simpleTimePeriod9.equals((java.lang.Object) 1560409200000L);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getFirstMillisecond();
//        int int16 = day14.getMonth();
//        java.util.Date date17 = day14.getStart();
//        java.util.Date date18 = day14.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day14.next();
//        int int22 = day14.compareTo((java.lang.Object) true);
//        try {
//            int int23 = simpleTimePeriod9.compareTo((java.lang.Object) int22);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.TimePeriod");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560409200000L + "'", long15 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date4);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int11 = simpleTimePeriod9.compareTo((java.lang.Object) day10);
        java.lang.Number number12 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod9, number12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getStart();
        boolean boolean16 = timePeriodValue13.equals((java.lang.Object) year14);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        long long4 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 0);
        java.util.Date date8 = year0.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date4);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int11 = simpleTimePeriod9.compareTo((java.lang.Object) day10);
        java.lang.Number number12 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod9, number12);
        java.util.Date date14 = simpleTimePeriod9.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getStart();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass22 = timeZone21.getClass();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date19, timeZone21);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod(date16, date19);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        int int26 = simpleTimePeriod24.compareTo((java.lang.Object) day25);
        boolean boolean28 = simpleTimePeriod24.equals((java.lang.Object) 1560409200000L);
        java.util.Date date29 = simpleTimePeriod24.getEnd();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.previous();
        long long32 = year30.getFirstMillisecond();
        java.util.Date date33 = year30.getStart();
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass35 = timeZone34.getClass();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date33, timeZone34);
        java.lang.Class<?> wildcardClass37 = date33.getClass();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date33);
        java.lang.Class class39 = null;
        java.util.Date date40 = null;
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone41);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date33, timeZone41);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date29, timeZone41);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date14, timeZone41);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getMiddleMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date4);
        java.util.Date date10 = simpleTimePeriod9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getStart();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass15 = timeZone14.getClass();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date12, timeZone14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        long long19 = year17.getFirstMillisecond();
        java.util.Date date20 = year17.getStart();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass22 = timeZone21.getClass();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date20, timeZone21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date12, timeZone21);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date12);
        try {
            int int26 = simpleTimePeriod9.compareTo((java.lang.Object) date12);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.util.Date cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, (java.lang.Number) (byte) 10);
        timePeriodValues1.add(timePeriodValue8);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        long long7 = year5.getFirstMillisecond();
        java.util.Date date8 = year5.getStart();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass10 = timeZone9.getClass();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone9);
        java.lang.Class<?> wildcardClass12 = date8.getClass();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date8);
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date8, timeZone14);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date8, timeZone16);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = year17.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(timeZone16);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) year4);
        timePeriodValues1.setNotify(false);
        try {
            timePeriodValues1.update(0, (java.lang.Number) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) ' ');
        timePeriodValue5.setValue((java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue5);
        int int9 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) ' ');
        java.lang.Number number13 = timePeriodValue12.getValue();
        java.lang.Object obj14 = timePeriodValue12.clone();
        timePeriodValues1.add(timePeriodValue12);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 32.0d + "'", number13.equals(32.0d));
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 10);
        java.lang.Number number3 = timePeriodValue2.getValue();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (byte) 10 + "'", number3.equals((byte) 10));
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        int int2 = timePeriodValues1.getMaxMiddleIndex();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) ' ');
//        timePeriodValue5.setValue((java.lang.Number) 100);
//        timePeriodValues1.add(timePeriodValue5);
//        int int9 = timePeriodValues1.getMinStartIndex();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
//        long long12 = year10.getFirstMillisecond();
//        java.util.Date date13 = year10.getStart();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass15 = timeZone14.getClass();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13, timeZone14);
//        java.lang.Class<?> wildcardClass17 = date13.getClass();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
//        long long20 = year18.getFirstMillisecond();
//        java.util.Date date21 = year18.getStart();
//        java.lang.Class class22 = null;
//        java.util.Date date23 = null;
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date23, timeZone24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone24);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
//        long long29 = year27.getFirstMillisecond();
//        java.util.Date date30 = year27.getStart();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass32 = timeZone31.getClass();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date30, timeZone31);
//        java.lang.Class<?> wildcardClass34 = date30.getClass();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year35.previous();
//        long long37 = year35.getFirstMillisecond();
//        java.util.Date date38 = year35.getStart();
//        java.lang.Class class39 = null;
//        java.util.Date date40 = null;
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone41);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date38, timeZone41);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date38);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        long long46 = day45.getFirstMillisecond();
//        int int47 = day45.getMonth();
//        java.util.Date date48 = day45.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod(date38, date48);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod(date21, date38);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod50, (double) (short) 1);
//        java.util.Date date53 = simpleTimePeriod50.getEnd();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1546329600000L + "'", long37 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560409200000L + "'", long46 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(date53);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) (byte) 10);
        int int7 = year0.compareTo((java.lang.Object) (byte) 10);
        int int8 = year0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1577865599999L, 1546329600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        long long7 = day6.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day6.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) ' ');
        java.lang.Number number3 = timePeriodValue2.getValue();
        java.lang.String str4 = timePeriodValue2.toString();
        timePeriodValue2.setValue((java.lang.Number) 5);
        java.lang.String str7 = timePeriodValue2.toString();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 32.0d + "'", number3.equals(32.0d));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TimePeriodValue[2019,32.0]" + "'", str4.equals("TimePeriodValue[2019,32.0]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TimePeriodValue[2019,5]" + "'", str7.equals("TimePeriodValue[2019,5]"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        long long5 = year3.getFirstMillisecond();
        java.util.Date date6 = year3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        long long9 = year7.getFirstMillisecond();
        java.util.Date date10 = year7.getStart();
        boolean boolean11 = year3.equals((java.lang.Object) year7);
        java.lang.String str12 = year7.toString();
        long long13 = year7.getLastMillisecond();
        int int14 = day0.compareTo((java.lang.Object) long13);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
        java.util.Calendar calendar16 = null;
        try {
            day0.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) ' ');
        timePeriodValue5.setValue((java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue5);
        int int9 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) ' ');
        java.lang.Number number13 = timePeriodValue12.getValue();
        java.lang.Object obj14 = timePeriodValue12.clone();
        timePeriodValues1.add(timePeriodValue12);
        java.lang.Object obj16 = timePeriodValues1.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 32.0d + "'", number13.equals(32.0d));
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date4);
        java.util.Date date10 = simpleTimePeriod9.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int13 = timePeriodValues12.getMaxMiddleIndex();
        timePeriodValues12.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int16 = timePeriodValues12.getMinStartIndex();
        java.lang.Comparable comparable17 = timePeriodValues12.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = timePeriodValues12.createCopy(0, 2019);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.util.Date date22 = year21.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getStart();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass28 = timeZone27.getClass();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date25, timeZone27);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(date22, date25);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        int int32 = simpleTimePeriod30.compareTo((java.lang.Object) day31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        int int34 = year33.getYear();
        boolean boolean35 = simpleTimePeriod30.equals((java.lang.Object) year33);
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) simpleTimePeriod30, (double) 1562097599999L);
        boolean boolean38 = simpleTimePeriod9.equals((java.lang.Object) simpleTimePeriod30);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.previous();
        long long41 = year39.getFirstMillisecond();
        long long42 = year39.getFirstMillisecond();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue45 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day43, (java.lang.Number) (byte) 10);
        int int46 = year39.compareTo((java.lang.Object) (byte) 10);
        boolean boolean47 = simpleTimePeriod9.equals((java.lang.Object) year39);
        long long48 = year39.getSerialIndex();
        int int49 = year39.getYear();
        java.util.Calendar calendar50 = null;
        try {
            long long51 = year39.getFirstMillisecond(calendar50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + (short) -1 + "'", comparable17.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1546329600000L + "'", long41 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1546329600000L + "'", long42 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2019L + "'", long48 == 2019L);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        int int7 = day6.getYear();
        long long8 = day6.getFirstMillisecond();
        int int9 = day6.getMonth();
        java.util.Date date10 = day6.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = year11.getYear();
        long long13 = year11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year11, (-1.0d));
        java.util.Date date16 = year11.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        long long19 = year17.getFirstMillisecond();
        java.util.Date date20 = year17.getStart();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass22 = timeZone21.getClass();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date20, timeZone21);
        java.lang.Class<?> wildcardClass24 = date20.getClass();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.previous();
        long long27 = year25.getFirstMillisecond();
        java.util.Date date28 = year25.getStart();
        java.lang.Class class29 = null;
        java.util.Date date30 = null;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date28, timeZone31);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date28);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod(date16, date28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod33);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass4 = timeZone3.getClass();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date1, timeZone3);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = year6.getFirstMillisecond();
        java.util.Date date9 = year6.getStart();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass11 = timeZone10.getClass();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date9, timeZone10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date1, timeZone10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100);
        int int2 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        long long7 = year5.getFirstMillisecond();
        java.util.Date date8 = year5.getStart();
        java.lang.Class<?> wildcardClass9 = year5.getClass();
        timePeriodValues1.setKey((java.lang.Comparable) year5);
        int int11 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass4 = timeZone3.getClass();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date1, timeZone3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100);
        int int2 = timePeriodValues1.getMinStartIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        int int4 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        int int9 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        int int4 = year0.compareTo((java.lang.Object) 11);
        long long5 = year0.getMiddleMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test289");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
//        long long4 = year2.getFirstMillisecond();
//        boolean boolean5 = day0.equals((java.lang.Object) long4);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        long long7 = year5.getFirstMillisecond();
        java.util.Date date8 = year5.getStart();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass10 = timeZone9.getClass();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone9);
        java.lang.Class<?> wildcardClass12 = date8.getClass();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date8);
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date8, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        long long18 = year16.getFirstMillisecond();
        java.util.Date date19 = year16.getStart();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass21 = timeZone20.getClass();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date19, timeZone20);
        java.lang.Class<?> wildcardClass23 = date19.getClass();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date19);
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date19, timeZone27);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date8, timeZone27);
        java.util.Calendar calendar31 = null;
        try {
            year30.peg(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        java.lang.String str2 = timePeriodValues1.getDescription();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) ' ');
        timePeriodValues1.add(timePeriodValue5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) ' ');
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue9.getPeriod();
        timePeriodValues1.add(timePeriodValue9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int14 = timePeriodValues13.getMaxMiddleIndex();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) ' ');
        timePeriodValue17.setValue((java.lang.Number) 100);
        timePeriodValues13.add(timePeriodValue17);
        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValue17.getPeriod();
        boolean boolean22 = timePeriodValue9.equals((java.lang.Object) timePeriod21);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(timePeriod10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timePeriod21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str3 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) -1, 4);
        int int7 = timePeriodValues6.getMinEndIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getFirstMillisecond();
        java.util.Date date11 = year8.getStart();
        long long12 = year8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year8.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod14, (java.lang.Number) (byte) 100);
        timePeriodValues6.add(timePeriodValue16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
//        long long4 = year2.getFirstMillisecond();
//        java.util.Date date5 = year2.getStart();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date5, timeZone6);
//        java.lang.Class<?> wildcardClass9 = date5.getClass();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date5);
//        int int11 = day0.compareTo((java.lang.Object) date5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day0.next();
//        java.lang.String str13 = day0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) ' ');
        timePeriodValue5.setValue((java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue5);
        int int9 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) ' ');
        java.lang.Number number13 = timePeriodValue12.getValue();
        java.lang.Object obj14 = timePeriodValue12.clone();
        timePeriodValues1.add(timePeriodValue12);
        java.lang.Number number16 = timePeriodValue12.getValue();
        java.lang.Number number17 = timePeriodValue12.getValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 32.0d + "'", number13.equals(32.0d));
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 32.0d + "'", number16.equals(32.0d));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 32.0d + "'", number17.equals(32.0d));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100);
        int int2 = timePeriodValues1.getMinStartIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
//        long long2 = year0.getFirstMillisecond();
//        java.util.Date date3 = year0.getStart();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
//        java.lang.Class<?> wildcardClass7 = date3.getClass();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        long long10 = year8.getFirstMillisecond();
//        java.util.Date date11 = year8.getStart();
//        java.lang.Class class12 = null;
//        java.util.Date date13 = null;
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date11, timeZone14);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date11);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        long long19 = day18.getFirstMillisecond();
//        int int20 = day18.getMonth();
//        java.util.Date date21 = day18.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date11, date21);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
//        long long25 = year23.getFirstMillisecond();
//        java.util.Date date26 = year23.getStart();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass28 = timeZone27.getClass();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date26, timeZone27);
//        java.lang.Class<?> wildcardClass30 = date26.getClass();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date26);
//        java.lang.Class class32 = null;
//        java.util.Date date33 = null;
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date33, timeZone34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date26, timeZone34);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date11, timeZone34);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560409200000L + "'", long19 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546329600000L + "'", long25 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        timePeriodValues9.setDescription("Value");
        java.lang.String str12 = timePeriodValues9.getDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        int int10 = timePeriodValues9.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues9.removeChangeListener(seriesChangeListener11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
//        long long4 = year2.getFirstMillisecond();
//        java.util.Date date5 = year2.getStart();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date5, timeZone6);
//        java.lang.Class<?> wildcardClass9 = date5.getClass();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date5);
//        int int11 = day0.compareTo((java.lang.Object) date5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day0.previous();
//        java.util.Date date13 = day0.getEnd();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date4);
        java.util.Date date10 = simpleTimePeriod9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        long long13 = year11.getFirstMillisecond();
        java.util.Date date14 = year11.getStart();
        long long15 = year11.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year11.previous();
        int int17 = simpleTimePeriod9.compareTo((java.lang.Object) year11);
        long long18 = simpleTimePeriod9.getStartMillis();
        java.util.Date date19 = simpleTimePeriod9.getEnd();
        java.util.Date date20 = simpleTimePeriod9.getStart();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1562097599999L + "'", long15 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        long long6 = year4.getFirstMillisecond();
        java.util.Date date7 = year4.getStart();
        boolean boolean8 = year0.equals((java.lang.Object) year4);
        int int9 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) year4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener7);
        boolean boolean10 = timePeriodValues1.equals((java.lang.Object) (-1.0f));
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        long long13 = year11.getFirstMillisecond();
        java.util.Date date14 = year11.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass16 = timeZone15.getClass();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date14, timeZone15);
        int int18 = day17.getYear();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        long long21 = year19.getFirstMillisecond();
        java.util.Date date22 = year19.getStart();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass24 = timeZone23.getClass();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date22, timeZone23);
        boolean boolean26 = day17.equals((java.lang.Object) timeZone23);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day17, (double) '#');
        java.util.Calendar calendar29 = null;
        try {
            long long30 = day17.getFirstMillisecond(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) year4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener7);
        boolean boolean10 = timePeriodValues1.equals((java.lang.Object) (-1.0f));
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        long long13 = year11.getFirstMillisecond();
        java.util.Date date14 = year11.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass16 = timeZone15.getClass();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date14, timeZone15);
        int int18 = day17.getYear();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        long long21 = year19.getFirstMillisecond();
        java.util.Date date22 = year19.getStart();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass24 = timeZone23.getClass();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date22, timeZone23);
        boolean boolean26 = day17.equals((java.lang.Object) timeZone23);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day17, (double) '#');
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.previous();
        long long31 = year29.getFirstMillisecond();
        int int33 = year29.compareTo((java.lang.Object) 11);
        long long34 = year29.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year29.next();
        long long36 = year29.getSerialIndex();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year29, (java.lang.Number) (byte) -1);
        long long39 = year29.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1546329600000L + "'", long31 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1546329600000L + "'", long39 == 1546329600000L);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1, "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]", "");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getFirstMillisecond();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.next();
//        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 10);
//        long long11 = day4.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43629L + "'", long11 == 43629L);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        int int5 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = year6.getFirstMillisecond();
        int int10 = year6.compareTo((java.lang.Object) 11);
        long long11 = year6.getLastMillisecond();
        timePeriodValues1.setKey((java.lang.Comparable) long11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) ' ');
        java.lang.Number number16 = timePeriodValue15.getValue();
        java.lang.Object obj17 = timePeriodValue15.clone();
        org.jfree.data.time.TimePeriod timePeriod18 = timePeriodValue15.getPeriod();
        timePeriodValues1.add(timePeriodValue15);
        int int20 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 32.0d + "'", number16.equals(32.0d));
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(timePeriod18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "TimePeriodValue[2019,32.0]", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        java.lang.Comparable comparable6 = timePeriodValues4.getKey();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(comparable6);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        int int7 = timePeriodValues6.getMaxMiddleIndex();
//        timePeriodValues6.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
//        int int10 = timePeriodValues6.getMinStartIndex();
//        int int11 = day0.compareTo((java.lang.Object) timePeriodValues6);
//        int int12 = timePeriodValues6.getMinStartIndex();
//        timePeriodValues6.setRangeDescription("Value");
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        int int6 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass7 = timePeriodValues1.getClass();
        int int8 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str3 = timePeriodValues1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener4);
        boolean boolean6 = timePeriodValues1.getNotify();
        int int7 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass4 = timeZone3.getClass();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date1, timeZone3);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = year6.getFirstMillisecond();
        java.util.Date date9 = year6.getStart();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass11 = timeZone10.getClass();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date9, timeZone10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date1, timeZone10);
        long long14 = day13.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
        int int16 = day13.getDayOfMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) ' ');
        java.lang.Number number3 = timePeriodValue2.getValue();
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue2.getPeriod();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriod4);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 32.0d + "'", number3.equals(32.0d));
        org.junit.Assert.assertNotNull(timePeriod4);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues1.getDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) ' ');
        java.lang.String str3 = year0.toString();
        long long4 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date4);
        java.util.Date date10 = simpleTimePeriod9.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int13 = timePeriodValues12.getMaxMiddleIndex();
        timePeriodValues12.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int16 = timePeriodValues12.getMinStartIndex();
        java.lang.Comparable comparable17 = timePeriodValues12.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = timePeriodValues12.createCopy(0, 2019);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.util.Date date22 = year21.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getStart();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass28 = timeZone27.getClass();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date25, timeZone27);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(date22, date25);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        int int32 = simpleTimePeriod30.compareTo((java.lang.Object) day31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        int int34 = year33.getYear();
        boolean boolean35 = simpleTimePeriod30.equals((java.lang.Object) year33);
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) simpleTimePeriod30, (double) 1562097599999L);
        boolean boolean38 = simpleTimePeriod9.equals((java.lang.Object) simpleTimePeriod30);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.previous();
        long long41 = year39.getFirstMillisecond();
        long long42 = year39.getFirstMillisecond();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue45 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day43, (java.lang.Number) (byte) 10);
        int int46 = year39.compareTo((java.lang.Object) (byte) 10);
        boolean boolean47 = simpleTimePeriod9.equals((java.lang.Object) year39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year39.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + (short) -1 + "'", comparable17.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1546329600000L + "'", long41 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1546329600000L + "'", long42 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        int int2 = timePeriodValues1.getMaxMiddleIndex();
//        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) (byte) 10);
//        long long8 = day5.getMiddleMillisecond();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
//        long long11 = year9.getFirstMillisecond();
//        java.util.Date date12 = year9.getStart();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass14 = timeZone13.getClass();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12, timeZone13);
//        int int16 = day15.getYear();
//        long long17 = day15.getLastMillisecond();
//        boolean boolean18 = day5.equals((java.lang.Object) day15);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) 11);
//        java.util.Date date21 = day15.getStart();
//        java.util.Date date22 = day15.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day15, "TimePeriodValue[2019,10]", "TimePeriodValue[2019,10]");
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560452399999L + "'", long8 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546415999999L + "'", long17 == 1546415999999L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date22);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        boolean boolean8 = timePeriodValues1.isEmpty();
        boolean boolean9 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        int int7 = timePeriodValues6.getMaxMiddleIndex();
//        timePeriodValues6.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
//        int int10 = timePeriodValues6.getMinStartIndex();
//        int int11 = day0.compareTo((java.lang.Object) timePeriodValues6);
//        long long12 = day0.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate13 = day0.getSerialDate();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = day0.getLastMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560495599999L + "'", long12 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate13);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date4);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int11 = simpleTimePeriod9.compareTo((java.lang.Object) day10);
        boolean boolean13 = simpleTimePeriod9.equals((java.lang.Object) 1560409200000L);
        java.util.Date date14 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
        long long17 = year15.getFirstMillisecond();
        java.util.Date date18 = year15.getStart();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass20 = timeZone19.getClass();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date18, timeZone19);
        java.lang.Class<?> wildcardClass22 = date18.getClass();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date18);
        java.lang.Class class24 = null;
        java.util.Date date25 = null;
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date18, timeZone26);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date14, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,5]");
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        int int4 = year0.compareTo((java.lang.Object) 11);
        long long5 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year0.next();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        int int11 = year0.compareTo((java.lang.Object) year10);
        long long12 = year0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        int int2 = timePeriodValues1.getMaxMiddleIndex();
//        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
//        int int5 = timePeriodValues1.getMinStartIndex();
//        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
//        int int10 = timePeriodValues9.getItemCount();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        long long12 = day11.getFirstMillisecond();
//        int int13 = day11.getDayOfMonth();
//        java.lang.String str14 = day11.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day11.next();
//        timePeriodValues9.setKey((java.lang.Comparable) regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
//        org.junit.Assert.assertNotNull(timePeriodValues9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 13 + "'", int13 == 13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getFirstMillisecond();
        int int5 = year1.compareTo((java.lang.Object) 11);
        long long6 = year1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year1.next();
        long long8 = year1.getSerialIndex();
        long long9 = year1.getLastMillisecond();
        long long10 = year1.getFirstMillisecond();
        java.util.Date date11 = year1.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date11, timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test326");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
//        long long2 = year0.getFirstMillisecond();
//        java.util.Date date3 = year0.getStart();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
//        java.lang.Class<?> wildcardClass7 = date3.getClass();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        long long10 = year8.getFirstMillisecond();
//        java.util.Date date11 = year8.getStart();
//        java.lang.Class class12 = null;
//        java.util.Date date13 = null;
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date11, timeZone14);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date11);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        long long19 = day18.getFirstMillisecond();
//        int int20 = day18.getMonth();
//        java.util.Date date21 = day18.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date11, date21);
//        long long23 = simpleTimePeriod22.getEndMillis();
//        java.util.Date date24 = simpleTimePeriod22.getStart();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560409200000L + "'", long19 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560409200000L + "'", long23 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date24);
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "");
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100);
        int int2 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener3);
        timePeriodValues1.setRangeDescription("hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) ' ');
        org.jfree.data.time.TimePeriod timePeriod3 = timePeriodValue2.getPeriod();
        java.lang.Number number4 = timePeriodValue2.getValue();
        org.junit.Assert.assertNotNull(timePeriod3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 32.0d + "'", number4.equals(32.0d));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[2019,100.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        java.lang.String str2 = timePeriodValues1.getDescription();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) ' ');
        timePeriodValues1.add(timePeriodValue5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) ' ');
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue9.getPeriod();
        timePeriodValues1.add(timePeriodValue9);
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues14 = timePeriodValues1.createCopy(7, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(timePeriod10);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.util.Date date14 = year13.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass17 = timeZone16.getClass();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(date11, date14);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        int int21 = simpleTimePeriod19.compareTo((java.lang.Object) day20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int23 = year22.getYear();
        boolean boolean24 = simpleTimePeriod19.equals((java.lang.Object) year22);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 1562097599999L);
        long long27 = simpleTimePeriod19.getStartMillis();
        long long28 = simpleTimePeriod19.getEndMillis();
        java.util.Date date29 = simpleTimePeriod19.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date29);
        timePeriodValues30.setDomainDescription("Time");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertNotNull(date29);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        int int7 = day6.getYear();
        int int8 = day6.getDayOfMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int8);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
//        long long4 = year2.getFirstMillisecond();
//        java.util.Date date5 = year2.getStart();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date5, timeZone6);
//        java.lang.Class<?> wildcardClass9 = date5.getClass();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date5);
//        int int11 = day0.compareTo((java.lang.Object) date5);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
//        long long14 = year12.getFirstMillisecond();
//        java.util.Date date15 = year12.getStart();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass17 = timeZone16.getClass();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date15, timeZone16);
//        java.lang.Class<?> wildcardClass19 = date15.getClass();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
//        long long22 = year20.getFirstMillisecond();
//        java.util.Date date23 = year20.getStart();
//        java.lang.Class class24 = null;
//        java.util.Date date25 = null;
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date23, timeZone26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.previous();
//        long long31 = year29.getFirstMillisecond();
//        java.util.Date date32 = year29.getStart();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass34 = timeZone33.getClass();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date32, timeZone33);
//        java.lang.Class<?> wildcardClass36 = date32.getClass();
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year37.previous();
//        long long39 = year37.getFirstMillisecond();
//        java.util.Date date40 = year37.getStart();
//        java.lang.Class class41 = null;
//        java.util.Date date42 = null;
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date42, timeZone43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date40, timeZone43);
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date40);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        long long48 = day47.getFirstMillisecond();
//        int int49 = day47.getMonth();
//        java.util.Date date50 = day47.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod(date40, date50);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod52 = new org.jfree.data.time.SimpleTimePeriod(date23, date40);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
//        java.util.Date date54 = year53.getStart();
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date54);
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass57 = timeZone56.getClass();
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date54, timeZone56);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = year59.previous();
//        long long61 = year59.getFirstMillisecond();
//        java.util.Date date62 = year59.getStart();
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass64 = timeZone63.getClass();
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date62, timeZone63);
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date54, timeZone63);
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date23, timeZone63);
//        boolean boolean68 = day0.equals((java.lang.Object) date23);
//        java.util.Calendar calendar69 = null;
//        try {
//            day0.peg(calendar69);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1546329600000L + "'", long31 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1546329600000L + "'", long39 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560409200000L + "'", long48 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNotNull(wildcardClass57);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1546329600000L + "'", long61 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str3 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) -1, 4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriodValues6);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) year4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener7);
        boolean boolean9 = timePeriodValues1.isEmpty();
        timePeriodValues1.setRangeDescription("");
        int int12 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener5);
        int int7 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        int int4 = year0.compareTo((java.lang.Object) 11);
        long long5 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        long long7 = year0.getSerialIndex();
        long long8 = year0.getLastMillisecond();
        long long9 = year0.getFirstMillisecond();
        java.util.Date date10 = year0.getEnd();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year0.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        int int7 = day6.getYear();
        long long8 = day6.getLastMillisecond();
        int int9 = day6.getYear();
        int int10 = day6.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546415999999L + "'", long8 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100);
        int int2 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener3);
        boolean boolean5 = timePeriodValues1.getNotify();
        int int6 = timePeriodValues1.getMinEndIndex();
        try {
            timePeriodValues1.delete(13, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) ' ');
        java.lang.Number number3 = timePeriodValue2.getValue();
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue2.getPeriod();
        java.lang.String str5 = timePeriodValue2.toString();
        java.lang.Number number6 = timePeriodValue2.getValue();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 32.0d + "'", number3.equals(32.0d));
        org.junit.Assert.assertNotNull(timePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TimePeriodValue[2019,32.0]" + "'", str5.equals("TimePeriodValue[2019,32.0]"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 32.0d + "'", number6.equals(32.0d));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) (byte) 10);
        int int7 = year0.compareTo((java.lang.Object) (byte) 10);
        long long8 = year0.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 10);
//        long long3 = day0.getMiddleMillisecond();
//        int int4 = day0.getMonth();
//        java.lang.String str5 = day0.toString();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        long long6 = year4.getFirstMillisecond();
        java.util.Date date7 = year4.getStart();
        boolean boolean8 = year0.equals((java.lang.Object) year4);
        java.lang.String str9 = year4.toString();
        long long10 = year4.getLastMillisecond();
        long long11 = year4.getFirstMillisecond();
        int int12 = year4.getYear();
        java.util.Calendar calendar13 = null;
        try {
            year4.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        int int2 = day0.getDayOfMonth();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        int int5 = day0.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 43466L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener8);
        java.lang.Comparable comparable10 = timePeriodValues1.getKey();
        int int11 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = timePeriodValues1.createCopy((int) 'a', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) -1 + "'", comparable10.equals((short) -1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues14);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        int int2 = day0.getMonth();
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=10]");
//        int int7 = day0.compareTo((java.lang.Object) seriesException6);
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) ' ');
//        java.lang.Number number11 = timePeriodValue10.getValue();
//        java.lang.Object obj12 = timePeriodValue10.clone();
//        org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValue10.getPeriod();
//        int int14 = day0.compareTo((java.lang.Object) timePeriodValue10);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 32.0d + "'", number11.equals(32.0d));
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertNotNull(timePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.removeChangeListener(seriesChangeListener2);
//        int int4 = timePeriodValues1.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        int int7 = timePeriodValues6.getMaxMiddleIndex();
//        timePeriodValues6.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (byte) 10);
//        long long13 = day10.getMiddleMillisecond();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
//        long long16 = year14.getFirstMillisecond();
//        java.util.Date date17 = year14.getStart();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass19 = timeZone18.getClass();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date17, timeZone18);
//        int int21 = day20.getYear();
//        long long22 = day20.getLastMillisecond();
//        boolean boolean23 = day10.equals((java.lang.Object) day20);
//        timePeriodValues6.add((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) 11);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.previous();
//        long long28 = day26.getSerialIndex();
//        boolean boolean29 = day20.equals((java.lang.Object) long28);
//        java.util.Date date30 = day20.getEnd();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) (-1.0d));
//        java.beans.PropertyChangeListener propertyChangeListener33 = null;
//        timePeriodValues1.addPropertyChangeListener(propertyChangeListener33);
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues1.addPropertyChangeListener(propertyChangeListener35);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546415999999L + "'", long22 == 1546415999999L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43629L + "'", long28 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date30);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        java.lang.String str2 = timePeriodValues1.getDescription();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) ' ');
        timePeriodValues1.add(timePeriodValue5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) ' ');
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue9.getPeriod();
        timePeriodValues1.add(timePeriodValue9);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getStart();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass19 = timeZone18.getClass();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date16, timeZone18);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date13, date16);
        java.util.Date date22 = simpleTimePeriod21.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        long long25 = year23.getFirstMillisecond();
        java.util.Date date26 = year23.getStart();
        long long27 = year23.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        int int29 = simpleTimePeriod21.compareTo((java.lang.Object) year23);
        java.lang.Object obj30 = null;
        int int31 = year23.compareTo(obj30);
        java.lang.Number number32 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year23, number32);
        java.util.Date date34 = year23.getEnd();
        long long35 = year23.getSerialIndex();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(timePeriod10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546329600000L + "'", long25 == 1546329600000L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1562097599999L + "'", long27 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2019L + "'", long35 == 2019L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.util.Date date1 = year0.getStart();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        java.util.Date date4 = year3.getStart();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone6);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date4);
//        java.util.Date date10 = simpleTimePeriod9.getStart();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
//        long long13 = year11.getFirstMillisecond();
//        java.util.Date date14 = year11.getStart();
//        long long15 = year11.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year11.previous();
//        int int17 = simpleTimePeriod9.compareTo((java.lang.Object) year11);
//        long long18 = simpleTimePeriod9.getStartMillis();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
//        long long21 = year19.getFirstMillisecond();
//        java.util.Date date22 = year19.getStart();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass24 = timeZone23.getClass();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date22, timeZone23);
//        java.lang.Class<?> wildcardClass26 = date22.getClass();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
//        long long29 = year27.getFirstMillisecond();
//        java.util.Date date30 = year27.getStart();
//        java.lang.Class class31 = null;
//        java.util.Date date32 = null;
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date32, timeZone33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date30, timeZone33);
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year36.previous();
//        long long38 = year36.getFirstMillisecond();
//        java.util.Date date39 = year36.getStart();
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass41 = timeZone40.getClass();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date39, timeZone40);
//        java.lang.Class<?> wildcardClass43 = date39.getClass();
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year44.previous();
//        long long46 = year44.getFirstMillisecond();
//        java.util.Date date47 = year44.getStart();
//        java.lang.Class class48 = null;
//        java.util.Date date49 = null;
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date49, timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date47, timeZone50);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date47);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        long long55 = day54.getFirstMillisecond();
//        int int56 = day54.getMonth();
//        java.util.Date date57 = day54.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod(date47, date57);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod59 = new org.jfree.data.time.SimpleTimePeriod(date30, date47);
//        boolean boolean60 = simpleTimePeriod9.equals((java.lang.Object) simpleTimePeriod59);
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year61.previous();
//        long long63 = year61.getFirstMillisecond();
//        java.util.Date date64 = year61.getStart();
//        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass66 = timeZone65.getClass();
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date64, timeZone65);
//        java.lang.Class<?> wildcardClass68 = date64.getClass();
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date64);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = day69.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = day69.next();
//        boolean boolean72 = simpleTimePeriod59.equals((java.lang.Object) day69);
//        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = year73.previous();
//        long long75 = year73.getFirstMillisecond();
//        java.util.Date date76 = year73.getStart();
//        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass78 = timeZone77.getClass();
//        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day(date76, timeZone77);
//        java.lang.Class<?> wildcardClass80 = date76.getClass();
//        java.lang.Class class81 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass80);
//        java.lang.Class class82 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass80);
//        boolean boolean83 = simpleTimePeriod59.equals((java.lang.Object) wildcardClass80);
//        java.lang.Class class84 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass80);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1562097599999L + "'", long15 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1546329600000L + "'", long38 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1546329600000L + "'", long46 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560409200000L + "'", long55 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 6 + "'", int56 == 6);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1546329600000L + "'", long63 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(timeZone65);
//        org.junit.Assert.assertNotNull(wildcardClass66);
//        org.junit.Assert.assertNotNull(wildcardClass68);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1546329600000L + "'", long75 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNotNull(timeZone77);
//        org.junit.Assert.assertNotNull(wildcardClass78);
//        org.junit.Assert.assertNotNull(wildcardClass80);
//        org.junit.Assert.assertNotNull(class81);
//        org.junit.Assert.assertNotNull(class82);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertNotNull(class84);
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        java.lang.Class<?> wildcardClass7 = date3.getClass();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        long long10 = day8.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day8.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546415999999L + "'", long10 == 1546415999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=10]");
        java.lang.String str2 = seriesException1.toString();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,100]");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException5);
        java.lang.String str7 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str7.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]"));
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.util.Date date1 = year0.getStart();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        java.util.Date date4 = year3.getStart();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone6);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date4);
//        java.util.Date date10 = simpleTimePeriod9.getStart();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
//        long long13 = year11.getFirstMillisecond();
//        java.util.Date date14 = year11.getStart();
//        long long15 = year11.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year11.previous();
//        int int17 = simpleTimePeriod9.compareTo((java.lang.Object) year11);
//        long long18 = simpleTimePeriod9.getStartMillis();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
//        long long21 = year19.getFirstMillisecond();
//        java.util.Date date22 = year19.getStart();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass24 = timeZone23.getClass();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date22, timeZone23);
//        java.lang.Class<?> wildcardClass26 = date22.getClass();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
//        long long29 = year27.getFirstMillisecond();
//        java.util.Date date30 = year27.getStart();
//        java.lang.Class class31 = null;
//        java.util.Date date32 = null;
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date32, timeZone33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date30, timeZone33);
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year36.previous();
//        long long38 = year36.getFirstMillisecond();
//        java.util.Date date39 = year36.getStart();
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass41 = timeZone40.getClass();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date39, timeZone40);
//        java.lang.Class<?> wildcardClass43 = date39.getClass();
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year44.previous();
//        long long46 = year44.getFirstMillisecond();
//        java.util.Date date47 = year44.getStart();
//        java.lang.Class class48 = null;
//        java.util.Date date49 = null;
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date49, timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date47, timeZone50);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date47);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        long long55 = day54.getFirstMillisecond();
//        int int56 = day54.getMonth();
//        java.util.Date date57 = day54.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod(date47, date57);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod59 = new org.jfree.data.time.SimpleTimePeriod(date30, date47);
//        boolean boolean60 = simpleTimePeriod9.equals((java.lang.Object) simpleTimePeriod59);
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year61.previous();
//        long long63 = year61.getFirstMillisecond();
//        java.util.Date date64 = year61.getStart();
//        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass66 = timeZone65.getClass();
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date64, timeZone65);
//        java.lang.Class<?> wildcardClass68 = date64.getClass();
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date64);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = day69.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = day69.next();
//        boolean boolean72 = simpleTimePeriod59.equals((java.lang.Object) day69);
//        org.jfree.data.time.TimePeriodValues timePeriodValues74 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100);
//        org.jfree.data.time.TimePeriodValues timePeriodValues76 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100);
//        int int77 = timePeriodValues76.getMinEndIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener78 = null;
//        timePeriodValues76.removeChangeListener(seriesChangeListener78);
//        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = year80.previous();
//        long long82 = year80.getFirstMillisecond();
//        java.util.Date date83 = year80.getStart();
//        java.lang.Class<?> wildcardClass84 = year80.getClass();
//        timePeriodValues76.setKey((java.lang.Comparable) year80);
//        timePeriodValues74.add((org.jfree.data.time.TimePeriod) year80, (double) 2019);
//        try {
//            int int88 = simpleTimePeriod59.compareTo((java.lang.Object) timePeriodValues74);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1562097599999L + "'", long15 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1546329600000L + "'", long38 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1546329600000L + "'", long46 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560409200000L + "'", long55 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 6 + "'", int56 == 6);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1546329600000L + "'", long63 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(timeZone65);
//        org.junit.Assert.assertNotNull(wildcardClass66);
//        org.junit.Assert.assertNotNull(wildcardClass68);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod81);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 1546329600000L + "'", long82 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertNotNull(wildcardClass84);
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) ' ');
        timePeriodValue5.setValue((java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue5);
        int int9 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) ' ');
        java.lang.Number number13 = timePeriodValue12.getValue();
        java.lang.Object obj14 = timePeriodValue12.clone();
        timePeriodValues1.add(timePeriodValue12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener16);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getStart();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.util.Date date24 = year23.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass27 = timeZone26.getClass();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date24, timeZone26);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(date21, date24);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        int int31 = simpleTimePeriod29.compareTo((java.lang.Object) day30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        int int33 = year32.getYear();
        boolean boolean34 = simpleTimePeriod29.equals((java.lang.Object) year32);
        java.util.Date date35 = simpleTimePeriod29.getStart();
        boolean boolean36 = timePeriodValues1.equals((java.lang.Object) simpleTimePeriod29);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 32.0d + "'", number13.equals(32.0d));
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 10, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getDayOfMonth();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 7, (long) 8);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        java.lang.String str2 = timePeriodValues1.getDescription();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) ' ');
        timePeriodValues1.add(timePeriodValue5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) ' ');
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue9.getPeriod();
        timePeriodValues1.add(timePeriodValue9);
        boolean boolean13 = timePeriodValues1.equals((java.lang.Object) 32.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener14);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(timePeriod10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) ' ');
        timePeriodValue5.setValue((java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue5);
        int int9 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) ' ');
        java.lang.Number number13 = timePeriodValue12.getValue();
        java.lang.Object obj14 = timePeriodValue12.clone();
        timePeriodValues1.add(timePeriodValue12);
        int int16 = timePeriodValues1.getMaxMiddleIndex();
        int int17 = timePeriodValues1.getMinEndIndex();
        timePeriodValues1.setDescription("TimePeriodValue[2019,10]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 32.0d + "'", number13.equals(32.0d));
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test364");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 10);
//        long long3 = day0.getMiddleMillisecond();
//        int int4 = day0.getMonth();
//        java.util.Date date5 = day0.getEnd();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        timePeriodValues1.fireSeriesChanged();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getStart();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass18 = timeZone17.getClass();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date15, timeZone17);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date12, date15);
        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod20);
        try {
            int int23 = simpleTimePeriod20.compareTo((java.lang.Object) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        long long4 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        long long7 = year0.getMiddleMillisecond();
        java.lang.Object obj8 = null;
        boolean boolean9 = year0.equals(obj8);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1562097599999L + "'", long7 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable4 = timePeriodValues1.getKey();
        timePeriodValues1.fireSeriesChanged();
        boolean boolean6 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) -1 + "'", comparable4.equals((short) -1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        long long7 = day6.getFirstMillisecond();
        long long8 = day6.getLastMillisecond();
        java.lang.String str9 = day6.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546415999999L + "'", long8 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1-January-2019" + "'", str9.equals("1-January-2019"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.util.Date date14 = year13.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass17 = timeZone16.getClass();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(date11, date14);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        int int21 = simpleTimePeriod19.compareTo((java.lang.Object) day20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int23 = year22.getYear();
        boolean boolean24 = simpleTimePeriod19.equals((java.lang.Object) year22);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 1562097599999L);
        long long27 = simpleTimePeriod19.getStartMillis();
        long long28 = simpleTimePeriod19.getEndMillis();
        long long29 = simpleTimePeriod19.getStartMillis();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        timePeriodValues9.setDescription("Value");
        timePeriodValues9.delete((int) (byte) 10, (int) (byte) 0);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day6);
        java.lang.String str8 = seriesChangeEvent7.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1-January-2019]" + "'", str8.equals("org.jfree.data.general.SeriesChangeEvent[source=1-January-2019]"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) year4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener7);
        boolean boolean10 = timePeriodValues1.equals((java.lang.Object) (-1.0f));
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        long long13 = year11.getFirstMillisecond();
        java.util.Date date14 = year11.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass16 = timeZone15.getClass();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date14, timeZone15);
        int int18 = day17.getYear();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        long long21 = year19.getFirstMillisecond();
        java.util.Date date22 = year19.getStart();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass24 = timeZone23.getClass();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date22, timeZone23);
        boolean boolean26 = day17.equals((java.lang.Object) timeZone23);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day17, (double) '#');
        long long29 = day17.getSerialIndex();
        long long30 = day17.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 43466L + "'", long29 == 43466L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1546415999999L + "'", long30 == 1546415999999L);
    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        int int2 = day0.getDayOfMonth();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date4);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int11 = simpleTimePeriod9.compareTo((java.lang.Object) day10);
        java.lang.Number number12 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod9, number12);
        java.lang.String str14 = timePeriodValue13.toString();
        java.lang.Object obj15 = timePeriodValue13.clone();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        timePeriodValues1.setDomainDescription("Time");
        try {
            java.lang.Number number13 = timePeriodValues1.getValue((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        int int5 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = year6.getFirstMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) 0L);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int13 = timePeriodValues12.getMaxMiddleIndex();
        int int14 = timePeriodValues12.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues12.createCopy(6, 2019);
        java.lang.String str18 = timePeriodValues12.getRangeDescription();
        java.lang.String str19 = timePeriodValues12.getDomainDescription();
        boolean boolean20 = year6.equals((java.lang.Object) str19);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year6, "13-June-2019", "org.jfree.data.general.SeriesException: ");
        long long24 = year6.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Value" + "'", str18.equals("Value"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[2019,32.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) year4);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        long long9 = year7.getFirstMillisecond();
        java.util.Date date10 = year7.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass12 = timeZone11.getClass();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10, timeZone11);
        int int14 = day13.getYear();
        boolean boolean15 = year4.equals((java.lang.Object) int14);
        java.util.Date date16 = year4.getEnd();
        long long17 = year4.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(3, 0);
        int int9 = timePeriodValues8.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) year4);
        timePeriodValues1.setDescription("");
        timePeriodValues1.setRangeDescription("TimePeriodValue[2019,32.0]");
        int int11 = timePeriodValues1.getItemCount();
        java.lang.Comparable comparable12 = timePeriodValues1.getKey();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (short) -1 + "'", comparable12.equals((short) -1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.util.Date date14 = year13.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass17 = timeZone16.getClass();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(date11, date14);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        int int21 = simpleTimePeriod19.compareTo((java.lang.Object) day20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int23 = year22.getYear();
        boolean boolean24 = simpleTimePeriod19.equals((java.lang.Object) year22);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 1562097599999L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener27);
        try {
            java.lang.Number number30 = timePeriodValues1.getValue((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) ' ');
        timePeriodValue5.setValue((java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue5);
        timePeriodValues1.setDomainDescription("1-January-2019");
        int int11 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        int int2 = day0.getMonth();
//        int int3 = day0.getMonth();
//        java.lang.String str4 = day0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) ' ', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
//        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getFirstMillisecond();
//        int int5 = day3.getMonth();
//        long long6 = day3.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day3);
//        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=10]");
//        int int10 = day3.compareTo((java.lang.Object) seriesException9);
//        seriesException1.addSuppressed((java.lang.Throwable) seriesException9);
//        org.junit.Assert.assertNotNull(throwableArray2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100);
        int int2 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener3);
        boolean boolean5 = timePeriodValues1.getNotify();
        int int6 = timePeriodValues1.getItemCount();
        java.lang.String str7 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        timePeriodValues9.setDescription("Value");
        int int12 = timePeriodValues9.getMinStartIndex();
        timePeriodValues9.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=1-January-2019]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "Time");
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Time]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=Time]"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) (byte) 10);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 10);
//        long long3 = day0.getMiddleMillisecond();
//        int int4 = day0.getMonth();
//        java.util.Calendar calendar5 = null;
//        try {
//            day0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        long long6 = year4.getFirstMillisecond();
        java.util.Date date7 = year4.getStart();
        boolean boolean8 = year0.equals((java.lang.Object) year4);
        int int9 = year0.getYear();
        java.util.Date date10 = year0.getEnd();
        long long11 = year0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
//        long long2 = year0.getFirstMillisecond();
//        java.util.Date date3 = year0.getStart();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
//        java.lang.Class<?> wildcardClass7 = date3.getClass();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        long long10 = year8.getFirstMillisecond();
//        java.util.Date date11 = year8.getStart();
//        java.lang.Class class12 = null;
//        java.util.Date date13 = null;
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date11, timeZone14);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
//        long long19 = year17.getFirstMillisecond();
//        java.util.Date date20 = year17.getStart();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass22 = timeZone21.getClass();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date20, timeZone21);
//        java.lang.Class<?> wildcardClass24 = date20.getClass();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.previous();
//        long long27 = year25.getFirstMillisecond();
//        java.util.Date date28 = year25.getStart();
//        java.lang.Class class29 = null;
//        java.util.Date date30 = null;
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date28, timeZone31);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date28);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        long long36 = day35.getFirstMillisecond();
//        int int37 = day35.getMonth();
//        java.util.Date date38 = day35.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date28, date38);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(date11, date28);
//        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        int int43 = timePeriodValues42.getMaxMiddleIndex();
//        int int44 = timePeriodValues42.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = timePeriodValues42.createCopy(6, 2019);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener48 = null;
//        timePeriodValues42.removeChangeListener(seriesChangeListener48);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.previous();
//        long long52 = year50.getFirstMillisecond();
//        java.util.Date date53 = year50.getStart();
//        long long54 = year50.getMiddleMillisecond();
//        long long55 = year50.getLastMillisecond();
//        java.util.Date date56 = year50.getEnd();
//        timePeriodValues42.setKey((java.lang.Comparable) date56);
//        org.jfree.data.time.TimePeriodValues timePeriodValues59 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        int int60 = timePeriodValues59.getMaxMiddleIndex();
//        int int61 = timePeriodValues59.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues64 = timePeriodValues59.createCopy(6, 2019);
//        java.lang.String str65 = timePeriodValues59.getRangeDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener66 = null;
//        timePeriodValues59.addChangeListener(seriesChangeListener66);
//        int int68 = timePeriodValues59.getMinStartIndex();
//        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year();
//        int int70 = year69.getYear();
//        long long71 = year69.getLastMillisecond();
//        timePeriodValues59.add((org.jfree.data.time.TimePeriod) year69, (-1.0d));
//        java.util.Date date74 = year69.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod75 = new org.jfree.data.time.SimpleTimePeriod(date56, date74);
//        try {
//            int int76 = simpleTimePeriod40.compareTo((java.lang.Object) date74);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.util.Date cannot be cast to org.jfree.data.time.TimePeriod");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560409200000L + "'", long36 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues47);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1546329600000L + "'", long52 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1562097599999L + "'", long54 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1577865599999L + "'", long55 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues64);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Value" + "'", str65.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 2019 + "'", int70 == 2019);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1577865599999L + "'", long71 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date74);
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100);
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100);
//        int int4 = timePeriodValues3.getMinEndIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
//        long long9 = year7.getFirstMillisecond();
//        java.util.Date date10 = year7.getStart();
//        java.lang.Class<?> wildcardClass11 = year7.getClass();
//        timePeriodValues3.setKey((java.lang.Comparable) year7);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year7, (double) 2019);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        int int17 = timePeriodValues16.getMaxMiddleIndex();
//        timePeriodValues16.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) (byte) 10);
//        long long23 = day20.getMiddleMillisecond();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.previous();
//        long long26 = year24.getFirstMillisecond();
//        java.util.Date date27 = year24.getStart();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass29 = timeZone28.getClass();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date27, timeZone28);
//        int int31 = day30.getYear();
//        long long32 = day30.getLastMillisecond();
//        boolean boolean33 = day20.equals((java.lang.Object) day30);
//        timePeriodValues16.add((org.jfree.data.time.TimePeriod) day30, (java.lang.Number) 11);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
//        long long38 = day36.getSerialIndex();
//        boolean boolean39 = day30.equals((java.lang.Object) long38);
//        java.util.Date date40 = day30.getEnd();
//        int int41 = day30.getMonth();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day30, (double) (short) 100);
//        boolean boolean45 = day30.equals((java.lang.Object) 1.0d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560452399999L + "'", long23 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546415999999L + "'", long32 == 1546415999999L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 43629L + "'", long38 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        long long11 = year9.getFirstMillisecond();
        java.util.Date date12 = year9.getStart();
        long long13 = year9.getMiddleMillisecond();
        long long14 = year9.getLastMillisecond();
        java.util.Date date15 = year9.getEnd();
        timePeriodValues1.setKey((java.lang.Comparable) date15);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int19 = timePeriodValues18.getMaxMiddleIndex();
        int int20 = timePeriodValues18.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = timePeriodValues18.createCopy(6, 2019);
        java.lang.String str24 = timePeriodValues18.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timePeriodValues18.addChangeListener(seriesChangeListener25);
        int int27 = timePeriodValues18.getMinStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        int int29 = year28.getYear();
        long long30 = year28.getLastMillisecond();
        timePeriodValues18.add((org.jfree.data.time.TimePeriod) year28, (-1.0d));
        java.util.Date date33 = year28.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod(date15, date33);
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int37 = timePeriodValues36.getMaxMiddleIndex();
        timePeriodValues36.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int40 = timePeriodValues36.getMinStartIndex();
        java.lang.Comparable comparable41 = timePeriodValues36.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues44 = timePeriodValues36.createCopy(0, 2019);
        timePeriodValues44.setDescription("Value");
        timePeriodValues44.delete((int) (byte) 10, (int) (byte) 0);
        int int50 = timePeriodValues44.getMaxMiddleIndex();
        java.lang.String str51 = timePeriodValues44.getDomainDescription();
        int int52 = timePeriodValues44.getMaxEndIndex();
        boolean boolean53 = simpleTimePeriod34.equals((java.lang.Object) int52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Value" + "'", str24.equals("Value"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + comparable41 + "' != '" + (short) -1 + "'", comparable41.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues44);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Time" + "'", str51.equals("Time"));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) ' ', 6, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: 1-January-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date4);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int11 = simpleTimePeriod9.compareTo((java.lang.Object) day10);
        java.lang.Number number12 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod9, number12);
        java.util.Date date14 = simpleTimePeriod9.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date14, "13-June-2019", "Value");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getFirstMillisecond();
        java.util.Date date11 = year8.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        long long14 = year12.getFirstMillisecond();
        java.util.Date date15 = year12.getStart();
        boolean boolean16 = year8.equals((java.lang.Object) year12);
        int int17 = day7.compareTo((java.lang.Object) year12);
        long long18 = year12.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
//        long long2 = year0.getFirstMillisecond();
//        java.util.Date date3 = year0.getStart();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
//        java.lang.Class<?> wildcardClass7 = date3.getClass();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        long long10 = year8.getFirstMillisecond();
//        java.util.Date date11 = year8.getStart();
//        java.lang.Class class12 = null;
//        java.util.Date date13 = null;
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date11, timeZone14);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date11);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        long long19 = day18.getFirstMillisecond();
//        int int20 = day18.getMonth();
//        java.util.Date date21 = day18.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date11, date21);
//        java.util.Date date23 = simpleTimePeriod22.getEnd();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getFirstMillisecond();
//        int int26 = day24.getDayOfMonth();
//        java.lang.String str27 = day24.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day24.next();
//        java.util.Date date29 = day24.getEnd();
//        boolean boolean30 = simpleTimePeriod22.equals((java.lang.Object) date29);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560409200000L + "'", long19 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560409200000L + "'", long25 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 13 + "'", int26 == 13);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        timePeriodValues9.setDescription("Value");
        timePeriodValues9.delete((int) (byte) 10, (int) (byte) 0);
        int int15 = timePeriodValues9.getMaxMiddleIndex();
        java.lang.String str16 = timePeriodValues9.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues9.addChangeListener(seriesChangeListener17);
        int int19 = timePeriodValues9.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        boolean boolean10 = timePeriodValues1.getNotify();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
//        long long2 = year0.getFirstMillisecond();
//        java.util.Date date3 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        int int6 = timePeriodValues5.getMaxMiddleIndex();
//        int int7 = timePeriodValues5.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy(6, 2019);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timePeriodValues5.removeChangeListener(seriesChangeListener11);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
//        long long15 = year13.getFirstMillisecond();
//        java.util.Date date16 = year13.getStart();
//        long long17 = year13.getMiddleMillisecond();
//        long long18 = year13.getLastMillisecond();
//        java.util.Date date19 = year13.getEnd();
//        timePeriodValues5.setKey((java.lang.Comparable) date19);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date3, date19);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        long long23 = day22.getFirstMillisecond();
//        int int24 = day22.getMonth();
//        java.util.Date date25 = day22.getStart();
//        java.util.Date date26 = day22.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day22.next();
//        java.util.Date date29 = regularTimePeriod28.getStart();
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(date19, date29);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues10);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1562097599999L + "'", long17 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560409200000L + "'", long23 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(date29);
//    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.util.Date date14 = year13.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass17 = timeZone16.getClass();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(date11, date14);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        int int21 = simpleTimePeriod19.compareTo((java.lang.Object) day20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int23 = year22.getYear();
        boolean boolean24 = simpleTimePeriod19.equals((java.lang.Object) year22);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 1562097599999L);
        long long27 = simpleTimePeriod19.getStartMillis();
        long long28 = simpleTimePeriod19.getEndMillis();
        java.util.Date date29 = simpleTimePeriod19.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date29);
        boolean boolean31 = timePeriodValues30.isEmpty();
        int int32 = timePeriodValues30.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        timePeriodValues4.setKey((java.lang.Comparable) "TimePeriodValue[2019,100]");
//        timePeriodValues4.delete(10, 3);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) year4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timePeriodValues1.getDescription();
        int int10 = timePeriodValues1.getItemCount();
        int int11 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener12);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        java.lang.String str2 = timePeriodValues1.getDescription();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) ' ');
        timePeriodValues1.add(timePeriodValue5);
        boolean boolean7 = timePeriodValues1.getNotify();
        int int8 = timePeriodValues1.getMaxMiddleIndex();
        int int9 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        java.lang.Object obj10 = timePeriodValues1.clone();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getStart();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass18 = timeZone17.getClass();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date15, timeZone17);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date12, date15);
        java.util.Date date21 = simpleTimePeriod20.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int24 = timePeriodValues23.getMaxMiddleIndex();
        timePeriodValues23.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int27 = timePeriodValues23.getMinStartIndex();
        java.lang.Comparable comparable28 = timePeriodValues23.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = timePeriodValues23.createCopy(0, 2019);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.util.Date date33 = year32.getStart();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        java.util.Date date36 = year35.getStart();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date36);
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass39 = timeZone38.getClass();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date36, timeZone38);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(date33, date36);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        int int43 = simpleTimePeriod41.compareTo((java.lang.Object) day42);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        int int45 = year44.getYear();
        boolean boolean46 = simpleTimePeriod41.equals((java.lang.Object) year44);
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) simpleTimePeriod41, (double) 1562097599999L);
        boolean boolean49 = simpleTimePeriod20.equals((java.lang.Object) simpleTimePeriod41);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.previous();
        long long52 = year50.getFirstMillisecond();
        long long53 = year50.getFirstMillisecond();
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue56 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day54, (java.lang.Number) (byte) 10);
        int int57 = year50.compareTo((java.lang.Object) (byte) 10);
        boolean boolean58 = simpleTimePeriod20.equals((java.lang.Object) year50);
        java.util.Date date59 = simpleTimePeriod20.getEnd();
        boolean boolean60 = timePeriodValues1.equals((java.lang.Object) date59);
        org.jfree.data.time.TimePeriodValues timePeriodValues62 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        timePeriodValues62.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = year65.previous();
        boolean boolean67 = timePeriodValues62.equals((java.lang.Object) year65);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener68 = null;
        timePeriodValues62.addChangeListener(seriesChangeListener68);
        java.lang.String str70 = timePeriodValues62.getDescription();
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year();
        java.util.Date date72 = year71.getStart();
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date72);
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year();
        java.util.Date date75 = year74.getStart();
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date75);
        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass78 = timeZone77.getClass();
        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date75, timeZone77);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod80 = new org.jfree.data.time.SimpleTimePeriod(date72, date75);
        java.util.Date date81 = simpleTimePeriod80.getStart();
        java.util.Date date82 = simpleTimePeriod80.getStart();
        java.util.Date date83 = simpleTimePeriod80.getEnd();
        timePeriodValues62.setKey((java.lang.Comparable) date83);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod85 = new org.jfree.data.time.SimpleTimePeriod(date59, date83);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + (short) -1 + "'", comparable28.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues31);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1546329600000L + "'", long52 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1546329600000L + "'", long53 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(timeZone77);
        org.junit.Assert.assertNotNull(wildcardClass78);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertNotNull(date83);
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getDayOfMonth();
//        int int3 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.util.Date date1 = year0.getStart();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        java.util.Date date4 = year3.getStart();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone6);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date4);
//        java.util.Date date10 = simpleTimePeriod9.getStart();
//        java.util.Date date11 = simpleTimePeriod9.getStart();
//        java.util.Date date12 = simpleTimePeriod9.getEnd();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getFirstMillisecond();
//        int int15 = day13.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day13.next();
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        boolean boolean18 = simpleTimePeriod9.equals((java.lang.Object) serialDate17);
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        int int21 = timePeriodValues20.getMaxMiddleIndex();
//        timePeriodValues20.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
//        int int24 = timePeriodValues20.getMinStartIndex();
//        java.lang.Comparable comparable25 = timePeriodValues20.getKey();
//        org.jfree.data.time.TimePeriodValues timePeriodValues28 = timePeriodValues20.createCopy(0, 2019);
//        timePeriodValues28.setDescription("Value");
//        int int31 = timePeriodValues28.getMinStartIndex();
//        boolean boolean32 = simpleTimePeriod9.equals((java.lang.Object) timePeriodValues28);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + (short) -1 + "'", comparable25.equals((short) -1));
//        org.junit.Assert.assertNotNull(timePeriodValues28);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
//        long long2 = year0.getFirstMillisecond();
//        java.util.Date date3 = year0.getStart();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
//        java.lang.Class<?> wildcardClass7 = date3.getClass();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        long long10 = year8.getFirstMillisecond();
//        java.util.Date date11 = year8.getStart();
//        java.lang.Class class12 = null;
//        java.util.Date date13 = null;
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date11, timeZone14);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
//        long long19 = year17.getFirstMillisecond();
//        java.util.Date date20 = year17.getStart();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass22 = timeZone21.getClass();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date20, timeZone21);
//        java.lang.Class<?> wildcardClass24 = date20.getClass();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.previous();
//        long long27 = year25.getFirstMillisecond();
//        java.util.Date date28 = year25.getStart();
//        java.lang.Class class29 = null;
//        java.util.Date date30 = null;
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date28, timeZone31);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date28);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        long long36 = day35.getFirstMillisecond();
//        int int37 = day35.getMonth();
//        java.util.Date date38 = day35.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date28, date38);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(date11, date28);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        java.util.Date date42 = year41.getStart();
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date42);
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass45 = timeZone44.getClass();
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date42, timeZone44);
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year47.previous();
//        long long49 = year47.getFirstMillisecond();
//        java.util.Date date50 = year47.getStart();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass52 = timeZone51.getClass();
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date50, timeZone51);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date42, timeZone51);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date11, timeZone51);
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date11);
//        long long57 = year56.getFirstMillisecond();
//        long long58 = year56.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560409200000L + "'", long36 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1546329600000L + "'", long49 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1546329600000L + "'", long57 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 2019L + "'", long58 == 2019L);
//    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        int int2 = timePeriodValues1.getMaxMiddleIndex();
//        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) (byte) 10);
//        long long8 = day5.getMiddleMillisecond();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
//        long long11 = year9.getFirstMillisecond();
//        java.util.Date date12 = year9.getStart();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass14 = timeZone13.getClass();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12, timeZone13);
//        int int16 = day15.getYear();
//        long long17 = day15.getLastMillisecond();
//        boolean boolean18 = day5.equals((java.lang.Object) day15);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) 11);
//        java.lang.String str21 = timePeriodValues1.getDescription();
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timePeriodValues1.addPropertyChangeListener(propertyChangeListener22);
//        java.beans.PropertyChangeListener propertyChangeListener24 = null;
//        timePeriodValues1.addPropertyChangeListener(propertyChangeListener24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day26, (java.lang.Number) (byte) 10);
//        timePeriodValues1.add(timePeriodValue28);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560452399999L + "'", long8 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546415999999L + "'", long17 == 1546415999999L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str21.equals("org.jfree.data.general.SeriesChangeEvent[source=10]"));
//    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
//        long long2 = year0.getFirstMillisecond();
//        java.util.Date date3 = year0.getStart();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
//        java.lang.Class<?> wildcardClass7 = date3.getClass();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        long long10 = year8.getFirstMillisecond();
//        java.util.Date date11 = year8.getStart();
//        java.lang.Class class12 = null;
//        java.util.Date date13 = null;
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date11, timeZone14);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
//        long long19 = year17.getFirstMillisecond();
//        java.util.Date date20 = year17.getStart();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass22 = timeZone21.getClass();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date20, timeZone21);
//        java.lang.Class<?> wildcardClass24 = date20.getClass();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.previous();
//        long long27 = year25.getFirstMillisecond();
//        java.util.Date date28 = year25.getStart();
//        java.lang.Class class29 = null;
//        java.util.Date date30 = null;
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date28, timeZone31);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date28);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        long long36 = day35.getFirstMillisecond();
//        int int37 = day35.getMonth();
//        java.util.Date date38 = day35.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date28, date38);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(date11, date28);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        java.util.Date date42 = year41.getStart();
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date42);
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass45 = timeZone44.getClass();
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date42, timeZone44);
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year47.previous();
//        long long49 = year47.getFirstMillisecond();
//        java.util.Date date50 = year47.getStart();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass52 = timeZone51.getClass();
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date50, timeZone51);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date42, timeZone51);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date11, timeZone51);
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date11);
//        long long57 = year56.getFirstMillisecond();
//        int int58 = year56.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560409200000L + "'", long36 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1546329600000L + "'", long49 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1546329600000L + "'", long57 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2019 + "'", int58 == 2019);
//    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        java.lang.Class<?> wildcardClass7 = date3.getClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getFirstMillisecond();
        java.util.Date date11 = year8.getStart();
        java.lang.Class class12 = null;
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date11, timeZone14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        long long21 = year19.getFirstMillisecond();
        java.util.Date date22 = year19.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertNotNull(date22);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.removeChangeListener(seriesChangeListener2);
//        int int4 = timePeriodValues1.getMinStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        int int7 = timePeriodValues6.getMaxMiddleIndex();
//        timePeriodValues6.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (byte) 10);
//        long long13 = day10.getMiddleMillisecond();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
//        long long16 = year14.getFirstMillisecond();
//        java.util.Date date17 = year14.getStart();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass19 = timeZone18.getClass();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date17, timeZone18);
//        int int21 = day20.getYear();
//        long long22 = day20.getLastMillisecond();
//        boolean boolean23 = day10.equals((java.lang.Object) day20);
//        timePeriodValues6.add((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) 11);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.previous();
//        long long28 = day26.getSerialIndex();
//        boolean boolean29 = day20.equals((java.lang.Object) long28);
//        java.util.Date date30 = day20.getEnd();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) (-1.0d));
//        int int33 = day20.getMonth();
//        java.util.Date date34 = day20.getEnd();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546415999999L + "'", long22 == 1546415999999L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43629L + "'", long28 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(date34);
//    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
//        long long2 = year0.getFirstMillisecond();
//        java.util.Date date3 = year0.getStart();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
//        java.lang.Class<?> wildcardClass7 = date3.getClass();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        long long10 = year8.getFirstMillisecond();
//        java.util.Date date11 = year8.getStart();
//        java.lang.Class class12 = null;
//        java.util.Date date13 = null;
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date11, timeZone14);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date11);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        long long19 = day18.getFirstMillisecond();
//        int int20 = day18.getMonth();
//        java.util.Date date21 = day18.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date11, date21);
//        long long23 = simpleTimePeriod22.getEndMillis();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        java.util.Date date25 = year24.getStart();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        java.util.Date date28 = year27.getStart();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass31 = timeZone30.getClass();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date28, timeZone30);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(date25, date28);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        int int35 = simpleTimePeriod33.compareTo((java.lang.Object) day34);
//        java.util.Date date36 = simpleTimePeriod33.getEnd();
//        java.util.Date date37 = simpleTimePeriod33.getStart();
//        boolean boolean38 = simpleTimePeriod22.equals((java.lang.Object) simpleTimePeriod33);
//        java.lang.Object obj39 = null;
//        try {
//            int int40 = simpleTimePeriod22.compareTo(obj39);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560409200000L + "'", long19 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560409200000L + "'", long23 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        int int4 = year0.compareTo((java.lang.Object) 11);
        long long5 = year0.getMiddleMillisecond();
        long long6 = year0.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        int int7 = day6.getYear();
        long long8 = day6.getLastMillisecond();
        int int9 = day6.getYear();
        int int10 = day6.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546415999999L + "'", long8 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=10]");
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1, "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]", "");
        timePeriodValues3.setNotify(false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDomainDescription("hi!");
        timePeriodValues1.setDomainDescription("2019");
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy((int) '4', (int) (byte) 100);
        boolean boolean13 = timePeriodValues1.getNotify();
        timePeriodValues1.setNotify(false);
        int int16 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) ' ');
        java.lang.Number number3 = timePeriodValue2.getValue();
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue2.getPeriod();
        java.lang.String str5 = timePeriodValue2.toString();
        boolean boolean7 = timePeriodValue2.equals((java.lang.Object) "1-January-2019");
        java.lang.String str8 = timePeriodValue2.toString();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 32.0d + "'", number3.equals(32.0d));
        org.junit.Assert.assertNotNull(timePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TimePeriodValue[2019,32.0]" + "'", str5.equals("TimePeriodValue[2019,32.0]"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[2019,32.0]" + "'", str8.equals("TimePeriodValue[2019,32.0]"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date3);
        long long8 = day7.getFirstMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) ' ');
        java.lang.Number number12 = timePeriodValue11.getValue();
        java.lang.Object obj13 = timePeriodValue11.clone();
        java.lang.Number number14 = timePeriodValue11.getValue();
        int int15 = day7.compareTo((java.lang.Object) timePeriodValue11);
        java.lang.String str16 = timePeriodValue11.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 32.0d + "'", number12.equals(32.0d));
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 32.0d + "'", number14.equals(32.0d));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TimePeriodValue[2019,32.0]" + "'", str16.equals("TimePeriodValue[2019,32.0]"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: 1-January-2019");
        timePeriodValues1.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=1-January-2019]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "org.jfree.data.general.SeriesException: Value", "TimePeriodValue[2019,100]", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        long long7 = year5.getFirstMillisecond();
        java.util.Date date8 = year5.getStart();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass10 = timeZone9.getClass();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone9);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date8);
        timePeriodValues3.setKey((java.lang.Comparable) day12);
        int int14 = day12.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day6);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day6.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass4 = timeZone3.getClass();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date1, timeZone3);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = year6.getFirstMillisecond();
        java.util.Date date9 = year6.getStart();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass11 = timeZone10.getClass();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date9, timeZone10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date1, timeZone10);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        int int2 = timePeriodValues1.getMaxMiddleIndex();
//        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) (byte) 10);
//        long long8 = day5.getMiddleMillisecond();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
//        long long11 = year9.getFirstMillisecond();
//        java.util.Date date12 = year9.getStart();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass14 = timeZone13.getClass();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12, timeZone13);
//        int int16 = day15.getYear();
//        long long17 = day15.getLastMillisecond();
//        boolean boolean18 = day5.equals((java.lang.Object) day15);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) 11);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
//        long long23 = day21.getSerialIndex();
//        boolean boolean24 = day15.equals((java.lang.Object) long23);
//        java.util.Date date25 = day15.getEnd();
//        int int26 = day15.getMonth();
//        java.util.Calendar calendar27 = null;
//        try {
//            day15.peg(calendar27);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560452399999L + "'", long8 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546415999999L + "'", long17 == 1546415999999L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43629L + "'", long23 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 10);
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
//        long long6 = year4.getFirstMillisecond();
//        java.util.Date date7 = year4.getStart();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass9 = timeZone8.getClass();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone8);
//        int int11 = day10.getYear();
//        long long12 = day10.getLastMillisecond();
//        boolean boolean13 = day0.equals((java.lang.Object) day10);
//        java.util.Calendar calendar14 = null;
//        try {
//            day10.peg(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546415999999L + "'", long12 == 1546415999999L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        int int2 = timePeriodValues1.getMaxMiddleIndex();
//        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) (byte) 10);
//        long long8 = day5.getMiddleMillisecond();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
//        long long11 = year9.getFirstMillisecond();
//        java.util.Date date12 = year9.getStart();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass14 = timeZone13.getClass();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12, timeZone13);
//        int int16 = day15.getYear();
//        long long17 = day15.getLastMillisecond();
//        boolean boolean18 = day5.equals((java.lang.Object) day15);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) 11);
//        java.util.Date date21 = day15.getStart();
//        java.util.Date date22 = day15.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day15.previous();
//        java.util.Calendar calendar24 = null;
//        try {
//            long long25 = day15.getFirstMillisecond(calendar24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560452399999L + "'", long8 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546415999999L + "'", long17 == 1546415999999L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        java.lang.String str2 = timePeriodValues1.getDescription();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) ' ');
        timePeriodValues1.add(timePeriodValue5);
        java.lang.String str7 = timePeriodValue5.toString();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TimePeriodValue[2019,32.0]" + "'", str7.equals("TimePeriodValue[2019,32.0]"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 4, "TimePeriodValue[2019,32.0]", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass4 = timeZone3.getClass();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date1, timeZone3);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year5.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test436");
//        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
//        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getFirstMillisecond();
//        int int5 = day3.getMonth();
//        long long6 = day3.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day3);
//        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=10]");
//        int int10 = day3.compareTo((java.lang.Object) seriesException9);
//        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=10]");
//        java.lang.String str13 = seriesException12.toString();
//        java.lang.Throwable[] throwableArray14 = seriesException12.getSuppressed();
//        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,100]");
//        seriesException12.addSuppressed((java.lang.Throwable) seriesException16);
//        seriesException9.addSuppressed((java.lang.Throwable) seriesException16);
//        seriesException1.addSuppressed((java.lang.Throwable) seriesException16);
//        org.junit.Assert.assertNotNull(throwableArray2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str13.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]"));
//        org.junit.Assert.assertNotNull(throwableArray14);
//    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        java.lang.Class<?> wildcardClass7 = date3.getClass();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date3);
        java.lang.Class class9 = null;
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date3, timeZone11);
        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.removeChangeListener(seriesChangeListener17);
        int int19 = timePeriodValues16.getMinStartIndex();
        boolean boolean20 = day13.equals((java.lang.Object) timePeriodValues16);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100);
        int int2 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        long long7 = year5.getFirstMillisecond();
        java.util.Date date8 = year5.getStart();
        java.lang.Class<?> wildcardClass9 = year5.getClass();
        timePeriodValues1.setKey((java.lang.Comparable) year5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year5.previous();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year5.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        int int4 = year0.compareTo((java.lang.Object) 11);
        long long5 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        long long7 = year0.getSerialIndex();
        long long8 = year0.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        int int2 = day0.getMonth();
//        java.util.Date date3 = day0.getStart();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        int int6 = timePeriodValues5.getMinEndIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getFirstMillisecond();
        java.util.Date date11 = year8.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        long long14 = year12.getFirstMillisecond();
        java.util.Date date15 = year12.getStart();
        boolean boolean16 = year8.equals((java.lang.Object) year12);
        int int17 = day7.compareTo((java.lang.Object) year12);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = year12.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (double) ' ');
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue7.getPeriod();
        boolean boolean9 = timePeriodValues1.equals((java.lang.Object) timePeriodValue7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(timePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Value");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
//        long long2 = year0.getFirstMillisecond();
//        java.util.Date date3 = year0.getStart();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
//        java.lang.Class<?> wildcardClass7 = date3.getClass();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        long long10 = year8.getFirstMillisecond();
//        java.util.Date date11 = year8.getStart();
//        java.lang.Class class12 = null;
//        java.util.Date date13 = null;
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date11, timeZone14);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date11);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        long long19 = day18.getFirstMillisecond();
//        int int20 = day18.getMonth();
//        java.util.Date date21 = day18.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date11, date21);
//        long long23 = simpleTimePeriod22.getEndMillis();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        java.util.Date date25 = year24.getStart();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        java.util.Date date28 = year27.getStart();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass31 = timeZone30.getClass();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date28, timeZone30);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(date25, date28);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        int int35 = simpleTimePeriod33.compareTo((java.lang.Object) day34);
//        java.util.Date date36 = simpleTimePeriod33.getEnd();
//        java.util.Date date37 = simpleTimePeriod33.getStart();
//        boolean boolean38 = simpleTimePeriod22.equals((java.lang.Object) simpleTimePeriod33);
//        long long39 = simpleTimePeriod22.getStartMillis();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560409200000L + "'", long19 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560409200000L + "'", long23 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1546329600000L + "'", long39 == 1546329600000L);
//    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test446");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
//        long long2 = year0.getFirstMillisecond();
//        java.util.Date date3 = year0.getStart();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
//        java.lang.Class<?> wildcardClass7 = date3.getClass();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        long long10 = year8.getFirstMillisecond();
//        java.util.Date date11 = year8.getStart();
//        java.lang.Class class12 = null;
//        java.util.Date date13 = null;
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date11, timeZone14);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date11);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        long long19 = day18.getFirstMillisecond();
//        int int20 = day18.getMonth();
//        java.util.Date date21 = day18.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date11, date21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date11);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date11);
//        java.util.Date date25 = day24.getEnd();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560409200000L + "'", long19 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date25);
//    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.util.Date date14 = year13.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass17 = timeZone16.getClass();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(date11, date14);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        int int21 = simpleTimePeriod19.compareTo((java.lang.Object) day20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int23 = year22.getYear();
        boolean boolean24 = simpleTimePeriod19.equals((java.lang.Object) year22);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 1562097599999L);
        java.lang.String str27 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Value" + "'", str27.equals("Value"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        int int5 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = year6.getFirstMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) 0L);
        boolean boolean11 = timePeriodValues1.getNotify();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        long long2 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        java.lang.String str2 = timePeriodValues1.getDescription();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) ' ');
        timePeriodValues1.add(timePeriodValue5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) ' ');
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue9.getPeriod();
        timePeriodValues1.add(timePeriodValue9);
        int int12 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(timePeriod10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        java.lang.Class<?> wildcardClass7 = date3.getClass();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date3);
        java.util.Calendar calendar9 = null;
        try {
            day8.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDomainDescription("13-June-2019");
        int int5 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        java.lang.String str10 = timePeriodValues9.getDescription();
        timePeriodValues9.setRangeDescription("hi!");
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        long long15 = year13.getFirstMillisecond();
        java.util.Date date16 = year13.getStart();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass18 = timeZone17.getClass();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone17);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date16);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int24 = timePeriodValues23.getMaxMiddleIndex();
        timePeriodValues23.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int27 = timePeriodValues23.getMinStartIndex();
        java.lang.Comparable comparable28 = timePeriodValues23.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = timePeriodValues23.createCopy(0, 2019);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.util.Date date33 = year32.getStart();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        java.util.Date date36 = year35.getStart();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date36);
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass39 = timeZone38.getClass();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date36, timeZone38);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(date33, date36);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        int int43 = simpleTimePeriod41.compareTo((java.lang.Object) day42);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        int int45 = year44.getYear();
        boolean boolean46 = simpleTimePeriod41.equals((java.lang.Object) year44);
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) simpleTimePeriod41, (double) 1562097599999L);
        long long49 = simpleTimePeriod41.getStartMillis();
        long long50 = simpleTimePeriod41.getEndMillis();
        java.util.Date date51 = simpleTimePeriod41.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod52 = new org.jfree.data.time.SimpleTimePeriod(date16, date51);
        boolean boolean53 = timePeriodValues9.equals((java.lang.Object) simpleTimePeriod52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year54.previous();
        long long56 = year54.getFirstMillisecond();
        java.util.Date date57 = year54.getStart();
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass59 = timeZone58.getClass();
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date57, timeZone58);
        java.lang.Class<?> wildcardClass61 = date57.getClass();
        java.lang.Class class62 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass61);
        try {
            int int63 = simpleTimePeriod52.compareTo((java.lang.Object) wildcardClass61);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Class cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str10.equals("org.jfree.data.general.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + (short) -1 + "'", comparable28.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues31);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1546329600000L + "'", long49 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1546329600000L + "'", long50 == 1546329600000L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1546329600000L + "'", long56 == 1546329600000L);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(class62);
    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test456");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        java.lang.String str2 = timePeriodValues1.getDescription();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) ' ');
//        timePeriodValues1.add(timePeriodValue5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) ' ');
//        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue9.getPeriod();
//        timePeriodValues1.add(timePeriodValue9);
//        boolean boolean13 = timePeriodValues1.equals((java.lang.Object) 32.0d);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getFirstMillisecond();
//        int int16 = day14.getMonth();
//        java.util.Date date17 = day14.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day14.next();
//        int int19 = day14.getDayOfMonth();
//        boolean boolean20 = timePeriodValues1.equals((java.lang.Object) int19);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
//        long long23 = year21.getFirstMillisecond();
//        java.util.Date date24 = year21.getStart();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass26 = timeZone25.getClass();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date24, timeZone25);
//        int int28 = day27.getYear();
//        long long29 = day27.getFirstMillisecond();
//        int int30 = day27.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day27.previous();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod31, (java.lang.Number) (byte) 10);
//        org.junit.Assert.assertNull(str2);
//        org.junit.Assert.assertNotNull(timePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560409200000L + "'", long15 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        int int4 = year0.compareTo((java.lang.Object) 11);
        long long5 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        long long7 = year0.getSerialIndex();
        int int8 = year0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int11 = timePeriodValues10.getMaxMiddleIndex();
        int int12 = timePeriodValues10.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues10.createCopy(6, 2019);
        int int16 = year0.compareTo((java.lang.Object) timePeriodValues15);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 9);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) year4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener7);
        boolean boolean10 = timePeriodValues1.equals((java.lang.Object) (-1.0f));
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        long long13 = year11.getFirstMillisecond();
        java.util.Date date14 = year11.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass16 = timeZone15.getClass();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date14, timeZone15);
        int int18 = day17.getYear();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        long long21 = year19.getFirstMillisecond();
        java.util.Date date22 = year19.getStart();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass24 = timeZone23.getClass();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date22, timeZone23);
        boolean boolean26 = day17.equals((java.lang.Object) timeZone23);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day17, (double) '#');
        timePeriodValues1.setNotify(false);
        int int31 = timePeriodValues1.getMaxStartIndex();
        java.lang.String str32 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Time" + "'", str32.equals("Time"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        timePeriodValues9.setDescription("Value");
        int int12 = timePeriodValues9.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues9.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues9.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) ' ');
        timePeriodValue5.setValue((java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue5);
        java.lang.String str9 = timePeriodValue5.toString();
        java.lang.Object obj10 = timePeriodValue5.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TimePeriodValue[2019,100]" + "'", str9.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) ' ');
        timePeriodValue2.setValue((java.lang.Number) 100);
        java.lang.String str5 = timePeriodValue2.toString();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 10);
        java.lang.String str8 = seriesChangeEvent7.toString();
        java.lang.Object obj9 = seriesChangeEvent7.getSource();
        boolean boolean10 = timePeriodValue2.equals(obj9);
        java.lang.String str11 = timePeriodValue2.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TimePeriodValue[2019,100]" + "'", str5.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str8.equals("org.jfree.data.general.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + obj9 + "' != '" + (short) 10 + "'", obj9.equals((short) 10));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TimePeriodValue[2019,100]" + "'", str11.equals("TimePeriodValue[2019,100]"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) year4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener7);
        boolean boolean9 = timePeriodValues1.isEmpty();
        int int10 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.util.TimeZone timeZone0 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass1 = timeZone0.getClass();
        java.util.Date date2 = null;
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass10 = timeZone9.getClass();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date7, timeZone9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(date4, date7);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        int int14 = simpleTimePeriod12.compareTo((java.lang.Object) day13);
        boolean boolean16 = simpleTimePeriod12.equals((java.lang.Object) 1560409200000L);
        java.util.Date date17 = simpleTimePeriod12.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        long long20 = year18.getFirstMillisecond();
        java.util.Date date21 = year18.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass23 = timeZone22.getClass();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21, timeZone22);
        java.lang.Class<?> wildcardClass25 = date21.getClass();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date21);
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date21, timeZone29);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date17, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date2, timeZone29);
        org.junit.Assert.assertNotNull(timeZone0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(regularTimePeriod33);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesException: ");
        boolean boolean7 = timePeriodValues1.equals((java.lang.Object) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.String str2 = year0.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test467");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        int int2 = day0.getMonth();
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        long long5 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (3) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        int int7 = timePeriodValues6.getMaxMiddleIndex();
//        timePeriodValues6.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
//        int int10 = timePeriodValues6.getMinStartIndex();
//        int int11 = day0.compareTo((java.lang.Object) timePeriodValues6);
//        long long12 = day0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day0.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560495599999L + "'", long12 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        boolean boolean10 = timePeriodValues9.isEmpty();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 2019);
        timePeriodValues9.setDescription("Value");
        timePeriodValues9.delete((int) (byte) 10, (int) (byte) 0);
        int int15 = timePeriodValues9.getMaxMiddleIndex();
        java.lang.String str16 = timePeriodValues9.getDomainDescription();
        timePeriodValues9.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        long long6 = year4.getFirstMillisecond();
        java.util.Date date7 = year4.getStart();
        boolean boolean8 = year0.equals((java.lang.Object) year4);
        java.lang.String str9 = year4.toString();
        long long10 = year4.getMiddleMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year4.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100);
        int int2 = timePeriodValues1.getMinStartIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        boolean boolean4 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        java.lang.String str3 = seriesException1.toString();
        java.lang.Throwable[] throwableArray4 = seriesException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str3.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
//        long long2 = year0.getFirstMillisecond();
//        java.util.Date date3 = year0.getStart();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
//        java.lang.Class<?> wildcardClass7 = date3.getClass();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        long long10 = year8.getFirstMillisecond();
//        java.util.Date date11 = year8.getStart();
//        java.lang.Class class12 = null;
//        java.util.Date date13 = null;
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date11, timeZone14);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
//        long long19 = year17.getFirstMillisecond();
//        java.util.Date date20 = year17.getStart();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass22 = timeZone21.getClass();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date20, timeZone21);
//        java.lang.Class<?> wildcardClass24 = date20.getClass();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.previous();
//        long long27 = year25.getFirstMillisecond();
//        java.util.Date date28 = year25.getStart();
//        java.lang.Class class29 = null;
//        java.util.Date date30 = null;
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date28, timeZone31);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date28);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        long long36 = day35.getFirstMillisecond();
//        int int37 = day35.getMonth();
//        java.util.Date date38 = day35.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date28, date38);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(date11, date28);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date11);
//        java.util.Calendar calendar42 = null;
//        try {
//            long long43 = day41.getLastMillisecond(calendar42);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560409200000L + "'", long36 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
//        org.junit.Assert.assertNotNull(date38);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=10]");
        java.lang.String str2 = seriesException1.toString();
        java.lang.String str3 = seriesException1.toString();
        java.lang.String str4 = seriesException1.toString();
        java.lang.String str5 = seriesException1.toString();
        java.lang.String str6 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str3.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str4.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str5.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str6.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]"));
    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.util.Date date1 = year0.getStart();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        java.util.Date date4 = year3.getStart();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone6);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date4);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = simpleTimePeriod9.compareTo((java.lang.Object) day10);
//        boolean boolean13 = simpleTimePeriod9.equals((java.lang.Object) 1560409200000L);
//        java.util.Date date14 = simpleTimePeriod9.getStart();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        long long16 = day15.getFirstMillisecond();
//        int int17 = day15.getMonth();
//        long long18 = day15.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day15);
//        int int20 = simpleTimePeriod9.compareTo((java.lang.Object) day15);
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        int int23 = timePeriodValues22.getMaxMiddleIndex();
//        timePeriodValues22.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day26, (java.lang.Number) (byte) 10);
//        long long29 = day26.getMiddleMillisecond();
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.previous();
//        long long32 = year30.getFirstMillisecond();
//        java.util.Date date33 = year30.getStart();
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass35 = timeZone34.getClass();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date33, timeZone34);
//        int int37 = day36.getYear();
//        long long38 = day36.getLastMillisecond();
//        boolean boolean39 = day26.equals((java.lang.Object) day36);
//        timePeriodValues22.add((org.jfree.data.time.TimePeriod) day36, (java.lang.Number) 11);
//        java.lang.String str42 = timePeriodValues22.getDescription();
//        java.beans.PropertyChangeListener propertyChangeListener43 = null;
//        timePeriodValues22.addPropertyChangeListener(propertyChangeListener43);
//        timePeriodValues22.setNotify(false);
//        boolean boolean47 = day15.equals((java.lang.Object) false);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560409200000L + "'", long16 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560409200000L + "'", long18 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560452399999L + "'", long29 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1546415999999L + "'", long38 == 1546415999999L);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str42.equals("org.jfree.data.general.SeriesChangeEvent[source=10]"));
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 10);
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
//        long long6 = year4.getFirstMillisecond();
//        java.util.Date date7 = year4.getStart();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass9 = timeZone8.getClass();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone8);
//        int int11 = day10.getYear();
//        long long12 = day10.getLastMillisecond();
//        boolean boolean13 = day0.equals((java.lang.Object) day10);
//        long long14 = day10.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546415999999L + "'", long12 == 1546415999999L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
//    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesException: ");
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMinMiddleIndex();
        int int8 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date4);
        java.util.Date date10 = simpleTimePeriod9.getStart();
        java.util.Date date11 = simpleTimePeriod9.getStart();
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate4);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) serialDate4);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 4, "TimePeriodValue[2019,32.0]", "");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener4);
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        int int2 = day0.getMonth();
//        long long3 = day0.getFirstMillisecond();
//        int int4 = day0.getMonth();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        java.util.Date date6 = day0.getStart();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date1, date4);
        java.util.Date date10 = simpleTimePeriod9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        long long13 = year11.getFirstMillisecond();
        java.util.Date date14 = year11.getStart();
        long long15 = year11.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year11.previous();
        int int17 = simpleTimePeriod9.compareTo((java.lang.Object) year11);
        java.util.Date date18 = simpleTimePeriod9.getEnd();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1562097599999L + "'", long15 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        long long6 = year4.getFirstMillisecond();
        java.util.Date date7 = year4.getStart();
        boolean boolean8 = year0.equals((java.lang.Object) year4);
        long long9 = year4.getMiddleMillisecond();
        java.lang.String str10 = year4.toString();
        long long11 = year4.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1562097599999L + "'", long9 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone4);
        java.lang.Class<?> wildcardClass7 = date3.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize(class8);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize(class9);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class9);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class11);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        timePeriodValues1.fireSeriesChanged();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getStart();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass18 = timeZone17.getClass();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date15, timeZone17);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date12, date15);
        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod20);
        java.util.Date date22 = simpleTimePeriod20.getEnd();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str3 = timePeriodValues1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener4);
        timePeriodValues1.fireSeriesChanged();
        java.lang.String str7 = timePeriodValues1.getDescription();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesException: Value");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        timePeriodValues1.fireSeriesChanged();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        long long13 = year11.getFirstMillisecond();
        java.util.Date date14 = year11.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
        long long17 = year15.getFirstMillisecond();
        java.util.Date date18 = year15.getStart();
        boolean boolean19 = year11.equals((java.lang.Object) year15);
        java.lang.String str20 = year15.toString();
        long long21 = year15.getLastMillisecond();
        long long22 = year15.getMiddleMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year15, (double) 0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year15.previous();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1562097599999L + "'", long22 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) year4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timePeriodValues1.getDescription();
        int int10 = timePeriodValues1.getMinEndIndex();
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(6, 2019);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        long long11 = year9.getFirstMillisecond();
        java.util.Date date12 = year9.getStart();
        long long13 = year9.getMiddleMillisecond();
        long long14 = year9.getLastMillisecond();
        java.util.Date date15 = year9.getEnd();
        timePeriodValues1.setKey((java.lang.Comparable) date15);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener17);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener19);
        boolean boolean21 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        timePeriodValues1.setDescription("Time");
        java.lang.String str7 = timePeriodValues1.getDomainDescription();
        boolean boolean8 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 4, "TimePeriodValue[2019,32.0]", "");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener5);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        java.lang.Class class0 = null;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
//        long long5 = year3.getFirstMillisecond();
//        java.util.Date date6 = year3.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass8 = timeZone7.getClass();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date6, timeZone7);
//        java.lang.Class<?> wildcardClass10 = date6.getClass();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
//        long long13 = year11.getFirstMillisecond();
//        java.util.Date date14 = year11.getStart();
//        java.lang.Class class15 = null;
//        java.util.Date date16 = null;
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone17);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
//        long long22 = year20.getFirstMillisecond();
//        java.util.Date date23 = year20.getStart();
//        java.lang.Class<?> wildcardClass24 = year20.getClass();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.previous();
//        long long27 = year25.getFirstMillisecond();
//        java.util.Date date28 = year25.getStart();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass30 = timeZone29.getClass();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date28, timeZone29);
//        java.lang.Class<?> wildcardClass32 = date28.getClass();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date28);
//        java.util.TimeZone timeZone34 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date28, timeZone34);
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date28, timeZone36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date14, timeZone36);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.previous();
//        long long41 = year39.getFirstMillisecond();
//        java.util.Date date42 = year39.getStart();
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass44 = timeZone43.getClass();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date42, timeZone43);
//        java.lang.Class<?> wildcardClass46 = date42.getClass();
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year47.previous();
//        long long49 = year47.getFirstMillisecond();
//        java.util.Date date50 = year47.getStart();
//        java.lang.Class class51 = null;
//        java.util.Date date52 = null;
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date52, timeZone53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date50, timeZone53);
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date50);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
//        long long58 = day57.getFirstMillisecond();
//        int int59 = day57.getMonth();
//        java.util.Date date60 = day57.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod61 = new org.jfree.data.time.SimpleTimePeriod(date50, date60);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date50);
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass64 = timeZone63.getClass();
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date50, timeZone63);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date14, timeZone63);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1546329600000L + "'", long41 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1546329600000L + "'", long49 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560409200000L + "'", long58 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 6 + "'", int59 == 6);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNull(regularTimePeriod66);
//    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int5 = timePeriodValues1.getMinStartIndex();
        int int6 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass7 = timePeriodValues1.getClass();
        java.lang.String str8 = timePeriodValues1.getRangeDescription();
        int int9 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: 1-January-2019");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
//        int int2 = timePeriodValues1.getMaxMiddleIndex();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) ' ');
//        timePeriodValue5.setValue((java.lang.Number) 100);
//        timePeriodValues1.add(timePeriodValue5);
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue5.getPeriod();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
//        long long12 = year10.getFirstMillisecond();
//        java.util.Date date13 = year10.getStart();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass15 = timeZone14.getClass();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13, timeZone14);
//        java.lang.Class<?> wildcardClass17 = date13.getClass();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
//        long long20 = year18.getFirstMillisecond();
//        java.util.Date date21 = year18.getStart();
//        java.lang.Class class22 = null;
//        java.util.Date date23 = null;
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date23, timeZone24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone24);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
//        long long29 = year27.getFirstMillisecond();
//        java.util.Date date30 = year27.getStart();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass32 = timeZone31.getClass();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date30, timeZone31);
//        java.lang.Class<?> wildcardClass34 = date30.getClass();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year35.previous();
//        long long37 = year35.getFirstMillisecond();
//        java.util.Date date38 = year35.getStart();
//        java.lang.Class class39 = null;
//        java.util.Date date40 = null;
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone41);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date38, timeZone41);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date38);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        long long46 = day45.getFirstMillisecond();
//        int int47 = day45.getMonth();
//        java.util.Date date48 = day45.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod(date38, date48);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod(date21, date38);
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
//        java.util.Date date52 = year51.getStart();
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date52);
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass55 = timeZone54.getClass();
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date52, timeZone54);
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year57.previous();
//        long long59 = year57.getFirstMillisecond();
//        java.util.Date date60 = year57.getStart();
//        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass62 = timeZone61.getClass();
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date60, timeZone61);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date52, timeZone61);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date21, timeZone61);
//        java.util.Date date66 = day65.getStart();
//        boolean boolean67 = timePeriodValue5.equals((java.lang.Object) date66);
//        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year(date66);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1546329600000L + "'", long37 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560409200000L + "'", long46 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1546329600000L + "'", long59 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(timeZone61);
//        org.junit.Assert.assertNotNull(wildcardClass62);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//    }
//}

