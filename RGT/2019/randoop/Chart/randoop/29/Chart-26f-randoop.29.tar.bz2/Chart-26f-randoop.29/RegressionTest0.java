import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.Comparable[] comparableArray3 = new java.lang.Comparable[] { 10.0f, ' ', 100.0f };
        java.lang.Comparable[] comparableArray4 = null;
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 100L };
        java.lang.Number[][] numberArray7 = new java.lang.Number[][] { numberArray6 };
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] {};
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset9 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray3, comparableArray4, numberArray7, numberArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray3);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.chart.axis.DateTickUnit.MINUTE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.Plot plot4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace8 = numberAxis1.reserveSpace(graphics2D3, plot4, rectangle2D5, rectangleEdge6, axisSpace7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range2 = null;
        try {
            numberAxis1.setRangeWithMargins(range2, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = null;
        try {
            numberAxis1.setRightArrow(shape2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint1, (java.awt.Paint) color2, (java.awt.Paint) color3);
        java.awt.Stroke stroke5 = null;
        try {
            waterfallBarRenderer4.setBaseOutlineStroke(stroke5, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = null;
        try {
            org.jfree.chart.entity.AxisLabelEntity axisLabelEntity5 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis1, shape2, "hi!", "{0}");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            rectangleInsets0.trim(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint1, (java.awt.Paint) color2, (java.awt.Paint) color3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        try {
            waterfallBarRenderer4.drawItem(graphics2D5, categoryItemRendererState6, rectangle2D7, categoryPlot8, categoryAxis9, valueAxis10, categoryDataset11, (int) (byte) 0, (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            stackedBarRenderer3D3.drawDomainMarker(graphics2D5, categoryPlot6, categoryAxis7, categoryMarker8, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint1, (java.awt.Paint) color2, (java.awt.Paint) color3);
        java.awt.color.ColorSpace colorSpace5 = null;
        float[] floatArray10 = new float[] { 100L, 1L, (byte) -1, 5 };
        try {
            float[] floatArray11 = color0.getComponents(colorSpace5, floatArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        double double3 = dateRange2.getLength();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.0d + "'", double3 == 6.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (short) 1, (double) 1.0f, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            blockBorder4.draw(graphics2D5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            stackedBarRenderer3D3.drawDomainGridline(graphics2D5, categoryPlot6, rectangle2D7, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-452) + "'", int1 == (-452));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) 'a', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double0 = org.jfree.chart.renderer.category.LevelRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setTickMarkOutsideLength((float) (byte) 1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.setAutoTickUnitSelection(false, false);
        numberAxis1.setLowerBound((double) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.lang.String[] strArray3 = new java.lang.String[] { "", "hi!", "ThreadContext" };
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (byte) 10, (short) 0 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (byte) 10, (short) 0 };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { (byte) 10, (short) 0 };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 10, (short) 0 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) 10, (short) 0 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray6, numberArray9, numberArray12, numberArray15, numberArray18 };
        java.lang.Number[] numberArray20 = new java.lang.Number[] {};
        java.lang.Number[] numberArray21 = new java.lang.Number[] {};
        java.lang.Number[] numberArray22 = new java.lang.Number[] {};
        java.lang.Number[] numberArray23 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] { numberArray20, numberArray21, numberArray22, numberArray23 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset25 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray3, numberArray19, numberArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        boolean boolean1 = blockContainer0.isEmpty();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = blockContainer0.arrange(graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("TextAnchor.CENTER_RIGHT");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int0 = org.jfree.chart.axis.DateTickUnit.YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.Plot plot2 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", font1, plot2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 12, (double) (short) 1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 5, 100.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = numberAxis1.getLeftArrow();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity8 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "hi!", "", categoryDataset5, (java.lang.Comparable) 0.05d, (java.lang.Comparable) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Stroke stroke5 = stackedBarRenderer3D3.getBaseStroke();
        stackedBarRenderer3D3.setBase((double) (byte) -1);
        boolean boolean8 = stackedBarRenderer3D3.isDrawBarOutline();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone0;
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(4, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean8 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge7);
        try {
            double double9 = categoryAxis3D1.getCategoryJava2DCoordinate(categoryAnchor3, (-452), (int) (short) 10, rectangle2D6, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        xYPlot6.setBackgroundImageAlignment((int) (byte) -1);
        float float9 = xYPlot6.getForegroundAlpha();
        java.awt.geom.Point2D point2D10 = null;
        try {
            xYPlot6.setQuadrantOrigin(point2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        stackedBarRenderer3D3.setNegativeItemLabelPositionFallback(itemLabelPosition5);
        boolean boolean7 = stackedBarRenderer3D3.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        double double4 = stackedBarRenderer3D3.getBase();
        double double5 = stackedBarRenderer3D3.getYOffset();
        java.awt.Shape shape7 = stackedBarRenderer3D3.lookupSeriesShape(2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint1, (java.awt.Paint) color2, (java.awt.Paint) color3);
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        waterfallBarRenderer4.setFirstBarPaint(paint5);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator10 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        waterfallBarRenderer4.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            waterfallBarRenderer4.drawOutline(graphics2D12, categoryPlot13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean4 = numberAxis3.isNegativeArrowVisible();
        numberAxis3.setAutoTickUnitSelection(false, false);
        boolean boolean8 = blockContainer0.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (short) -1, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        try {
            jFreeChart7.plotChanged(plotChangeEvent8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        double double3 = rectangleInsets1.calculateTopOutset((double) 2958465);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets1.createAdjustedRectangle(rectangle2D4, lengthAdjustmentType5, lengthAdjustmentType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint1, (java.awt.Paint) color2, (java.awt.Paint) color3);
        java.awt.Paint paint5 = waterfallBarRenderer4.getLastBarPaint();
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color8 = java.awt.Color.darkGray;
        java.awt.Color color9 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer10 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color6, paint7, (java.awt.Paint) color8, (java.awt.Paint) color9);
        java.awt.Color color11 = java.awt.Color.cyan;
        waterfallBarRenderer10.setBaseOutlinePaint((java.awt.Paint) color11);
        java.awt.Color color13 = java.awt.Color.darkGray;
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color15 = java.awt.Color.darkGray;
        java.awt.Color color16 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer17 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color13, paint14, (java.awt.Paint) color15, (java.awt.Paint) color16);
        waterfallBarRenderer10.setBaseOutlinePaint(paint14);
        java.awt.Color color19 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.AffineTransform affineTransform23 = null;
        java.awt.RenderingHints renderingHints24 = null;
        java.awt.PaintContext paintContext25 = color19.createContext(colorModel20, rectangle21, rectangle2D22, affineTransform23, renderingHints24);
        int int26 = color19.getTransparency();
        java.awt.Color color27 = color19.darker();
        java.awt.Color color28 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel29 = null;
        java.awt.Rectangle rectangle30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.geom.AffineTransform affineTransform32 = null;
        java.awt.RenderingHints renderingHints33 = null;
        java.awt.PaintContext paintContext34 = color28.createContext(colorModel29, rectangle30, rectangle2D31, affineTransform32, renderingHints33);
        int int35 = color28.getTransparency();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer36 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint5, paint14, (java.awt.Paint) color19, (java.awt.Paint) color28);
        waterfallBarRenderer36.setMinimumBarLength((double) (-452));
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintContext25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paintContext34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        numberAxis1.resizeRange((double) 100L);
        numberAxis1.setTickMarksVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean11 = numberAxis10.isNegativeArrowVisible();
        numberAxis10.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape16 = numberAxis15.getLeftArrow();
        numberAxis10.setLeftArrow(shape16);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape16, 0.0d, (double) (byte) -1);
        numberAxis1.setDownArrow(shape16);
        numberAxis1.setLabelToolTip("hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Paint paint6 = stackedBarRenderer3D3.getSeriesPaint(3);
        java.awt.Paint paint7 = null;
        try {
            stackedBarRenderer3D3.setBaseFillPaint(paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.junit.Assert.assertNull(timeZone0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double6 = rectangleInsets5.getRight();
        double double8 = rectangleInsets5.trimHeight((double) 0);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        boolean boolean2 = paintList0.equals((java.lang.Object) 0.05d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        org.jfree.data.Range range5 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange2, (double) (byte) -1, true);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude(range5, 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint1, (java.awt.Paint) color2, (java.awt.Paint) color3);
        java.awt.Color color5 = java.awt.Color.cyan;
        waterfallBarRenderer4.setBaseOutlinePaint((java.awt.Paint) color5);
        double double7 = waterfallBarRenderer4.getItemMargin();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bottom' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 0, (int) '4', (int) (byte) 100);
        java.lang.Class class4 = null;
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date8 = dateRange7.getUpperDate();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date8, timeZone9);
        try {
            segmentedTimeline3.addException(date8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        xYPlot6.setBackgroundImageAlignment((int) (byte) -1);
        float float9 = xYPlot6.getForegroundAlpha();
        java.awt.Color color10 = java.awt.Color.darkGray;
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Color color13 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer14 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color10, paint11, (java.awt.Paint) color12, (java.awt.Paint) color13);
        java.awt.Paint paint15 = waterfallBarRenderer14.getLastBarPaint();
        java.awt.Color color16 = java.awt.Color.darkGray;
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Color color19 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer20 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color16, paint17, (java.awt.Paint) color18, (java.awt.Paint) color19);
        java.awt.Color color21 = java.awt.Color.cyan;
        waterfallBarRenderer20.setBaseOutlinePaint((java.awt.Paint) color21);
        java.awt.Color color23 = java.awt.Color.darkGray;
        java.awt.Paint paint24 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color25 = java.awt.Color.darkGray;
        java.awt.Color color26 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer27 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color23, paint24, (java.awt.Paint) color25, (java.awt.Paint) color26);
        waterfallBarRenderer20.setBaseOutlinePaint(paint24);
        java.awt.Color color29 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel30 = null;
        java.awt.Rectangle rectangle31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.awt.geom.AffineTransform affineTransform33 = null;
        java.awt.RenderingHints renderingHints34 = null;
        java.awt.PaintContext paintContext35 = color29.createContext(colorModel30, rectangle31, rectangle2D32, affineTransform33, renderingHints34);
        int int36 = color29.getTransparency();
        java.awt.Color color37 = color29.darker();
        java.awt.Color color38 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel39 = null;
        java.awt.Rectangle rectangle40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.geom.AffineTransform affineTransform42 = null;
        java.awt.RenderingHints renderingHints43 = null;
        java.awt.PaintContext paintContext44 = color38.createContext(colorModel39, rectangle40, rectangle2D41, affineTransform42, renderingHints43);
        int int45 = color38.getTransparency();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer46 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint15, paint24, (java.awt.Paint) color29, (java.awt.Paint) color38);
        xYPlot6.setDomainTickBandPaint((java.awt.Paint) color38);
        try {
            java.awt.Paint paint49 = xYPlot6.getQuadrantPaint(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paintContext35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(paintContext44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        java.lang.Comparable comparable2 = null;
        int int3 = keyedObjects2D0.getColumnIndex(comparable2);
        try {
            keyedObjects2D0.removeColumn((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Paint paint6 = stackedBarRenderer3D3.getSeriesPaint(3);
        boolean boolean7 = stackedBarRenderer3D3.getAutoPopulateSeriesFillPaint();
        stackedBarRenderer3D3.setSeriesCreateEntities((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        stackedBarRenderer3D3.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        xYPlot6.setBackgroundImageAlignment((int) (byte) -1);
        float float9 = xYPlot6.getForegroundAlpha();
        java.awt.Color color10 = java.awt.Color.darkGray;
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Color color13 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer14 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color10, paint11, (java.awt.Paint) color12, (java.awt.Paint) color13);
        java.awt.Paint paint15 = waterfallBarRenderer14.getLastBarPaint();
        java.awt.Color color16 = java.awt.Color.darkGray;
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Color color19 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer20 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color16, paint17, (java.awt.Paint) color18, (java.awt.Paint) color19);
        java.awt.Color color21 = java.awt.Color.cyan;
        waterfallBarRenderer20.setBaseOutlinePaint((java.awt.Paint) color21);
        java.awt.Color color23 = java.awt.Color.darkGray;
        java.awt.Paint paint24 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color25 = java.awt.Color.darkGray;
        java.awt.Color color26 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer27 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color23, paint24, (java.awt.Paint) color25, (java.awt.Paint) color26);
        waterfallBarRenderer20.setBaseOutlinePaint(paint24);
        java.awt.Color color29 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel30 = null;
        java.awt.Rectangle rectangle31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.awt.geom.AffineTransform affineTransform33 = null;
        java.awt.RenderingHints renderingHints34 = null;
        java.awt.PaintContext paintContext35 = color29.createContext(colorModel30, rectangle31, rectangle2D32, affineTransform33, renderingHints34);
        int int36 = color29.getTransparency();
        java.awt.Color color37 = color29.darker();
        java.awt.Color color38 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel39 = null;
        java.awt.Rectangle rectangle40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.geom.AffineTransform affineTransform42 = null;
        java.awt.RenderingHints renderingHints43 = null;
        java.awt.PaintContext paintContext44 = color38.createContext(colorModel39, rectangle40, rectangle2D41, affineTransform42, renderingHints43);
        int int45 = color38.getTransparency();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer46 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint15, paint24, (java.awt.Paint) color29, (java.awt.Paint) color38);
        xYPlot6.setDomainTickBandPaint((java.awt.Paint) color38);
        java.lang.Object obj48 = null;
        boolean boolean49 = color38.equals(obj48);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paintContext35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(paintContext44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.util.Locale locale1 = null;
        java.lang.Class class2 = null;
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
        java.util.ResourceBundle.Control control4 = null;
        try {
            java.util.ResourceBundle resourceBundle5 = java.util.ResourceBundle.getBundle("", locale1, classLoader3, control4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classLoader3);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setToolTipText("java.awt.Color[r=64,g=64,b=64]");
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String[] strArray2 = jFreeChartResources0.getStringArray("TextAnchor.CENTER_RIGHT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key TextAnchor.CENTER_RIGHT");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 10, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires end >= start.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("java.awt.Color[r=64,g=64,b=64]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint1, (java.awt.Paint) color2, (java.awt.Paint) color3);
        java.awt.Color color5 = java.awt.Color.cyan;
        waterfallBarRenderer4.setBaseOutlinePaint((java.awt.Paint) color5);
        java.awt.Color color7 = java.awt.Color.darkGray;
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color9 = java.awt.Color.darkGray;
        java.awt.Color color10 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer11 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color7, paint8, (java.awt.Paint) color9, (java.awt.Paint) color10);
        waterfallBarRenderer4.setBaseOutlinePaint(paint8);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = waterfallBarRenderer4.getToolTipGenerator(0, (int) '#');
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.25d + "'", double0 == 0.25d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        xYPlot6.setBackgroundImageAlignment((int) (byte) -1);
        float float9 = xYPlot6.getForegroundAlpha();
        java.awt.Color color10 = java.awt.Color.darkGray;
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Color color13 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer14 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color10, paint11, (java.awt.Paint) color12, (java.awt.Paint) color13);
        java.awt.Paint paint15 = waterfallBarRenderer14.getLastBarPaint();
        java.awt.Color color16 = java.awt.Color.darkGray;
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Color color19 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer20 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color16, paint17, (java.awt.Paint) color18, (java.awt.Paint) color19);
        java.awt.Color color21 = java.awt.Color.cyan;
        waterfallBarRenderer20.setBaseOutlinePaint((java.awt.Paint) color21);
        java.awt.Color color23 = java.awt.Color.darkGray;
        java.awt.Paint paint24 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color25 = java.awt.Color.darkGray;
        java.awt.Color color26 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer27 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color23, paint24, (java.awt.Paint) color25, (java.awt.Paint) color26);
        waterfallBarRenderer20.setBaseOutlinePaint(paint24);
        java.awt.Color color29 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel30 = null;
        java.awt.Rectangle rectangle31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.awt.geom.AffineTransform affineTransform33 = null;
        java.awt.RenderingHints renderingHints34 = null;
        java.awt.PaintContext paintContext35 = color29.createContext(colorModel30, rectangle31, rectangle2D32, affineTransform33, renderingHints34);
        int int36 = color29.getTransparency();
        java.awt.Color color37 = color29.darker();
        java.awt.Color color38 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel39 = null;
        java.awt.Rectangle rectangle40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.geom.AffineTransform affineTransform42 = null;
        java.awt.RenderingHints renderingHints43 = null;
        java.awt.PaintContext paintContext44 = color38.createContext(colorModel39, rectangle40, rectangle2D41, affineTransform42, renderingHints43);
        int int45 = color38.getTransparency();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer46 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint15, paint24, (java.awt.Paint) color29, (java.awt.Paint) color38);
        xYPlot6.setDomainTickBandPaint((java.awt.Paint) color38);
        xYPlot6.setForegroundAlpha(0.0f);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis51 = xYPlot6.getRangeAxisForDataset(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paintContext35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(paintContext44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getValue(0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        org.jfree.data.Range range5 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange2, (double) (byte) -1, true);
        double double7 = range5.constrain((double) 1);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(1.0d, 1.0d, (double) 2958465, 0.0d);
        boolean boolean6 = blockBorder4.equals((java.lang.Object) (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        try {
            java.lang.Comparable comparable2 = defaultStatisticalCategoryDataset0.getColumnKey((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 0, (int) '4', (int) (byte) 100);
        org.jfree.chart.block.BorderArrangement borderArrangement4 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) borderArrangement4);
        java.lang.Object obj6 = null;
        boolean boolean7 = segmentedTimeline3.equals(obj6);
        try {
            long long9 = segmentedTimeline3.toMillisecond(86400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape4 = numberAxis3.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3, valueAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot7.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot7.getRangeAxisEdge((int) 'a');
        try {
            double double12 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 0, (int) '4', (int) (byte) 100);
        org.jfree.chart.block.BorderArrangement borderArrangement4 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) borderArrangement4);
        int int6 = segmentedTimeline3.getSegmentsExcluded();
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date10 = dateRange9.getUpperDate();
        java.lang.Class class11 = null;
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date15 = dateRange14.getUpperDate();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date15, timeZone16);
        org.jfree.data.time.DateRange dateRange20 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date21 = dateRange20.getUpperDate();
        org.jfree.data.time.DateRange dateRange22 = new org.jfree.data.time.DateRange(date15, date21);
        try {
            boolean boolean23 = segmentedTimeline3.containsDomainRange(date10, date21);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        try {
            java.awt.Color color1 = java.awt.Color.decode("java.awt.Color[r=64,g=64,b=64]");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"java.awt.Color[r=64,g=64,b=64]\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        xYPlot6.setBackgroundImageAlignment((int) (byte) -1);
        float float9 = xYPlot6.getForegroundAlpha();
        int int10 = xYPlot6.getWeight();
        org.jfree.chart.plot.Plot plot11 = xYPlot6.getRootPlot();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            xYPlot6.drawOutline(graphics2D12, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(plot11);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = barRenderer0.getToolTipGenerator((int) ' ', 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities(9);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        jFreeChart7.setTextAntiAlias(false);
        boolean boolean10 = jFreeChart7.getAntiAlias();
        boolean boolean11 = jFreeChart7.isNotify();
        org.jfree.chart.event.ChartChangeListener chartChangeListener12 = null;
        try {
            jFreeChart7.removeChangeListener(chartChangeListener12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.lang.Class class0 = null;
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date4 = dateRange3.getUpperDate();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date10 = dateRange9.getUpperDate();
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange(date4, date10);
        java.util.Date date12 = null;
        try {
            org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange(date10, date12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double14 = rectangleInsets13.getRight();
        xYPlot6.setInsets(rectangleInsets13);
        java.lang.Object obj16 = xYPlot6.clone();
        boolean boolean17 = xYPlot6.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Paint paint2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean4 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        try {
            org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=64,g=64,b=64]", font1, paint2, rectangleEdge3, horizontalAlignment5, verticalAlignment6, rectangleInsets7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'horizontalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        xYPlot6.setBackgroundImageAlignment((int) (byte) -1);
        float float9 = xYPlot6.getForegroundAlpha();
        java.awt.Color color10 = java.awt.Color.darkGray;
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Color color13 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer14 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color10, paint11, (java.awt.Paint) color12, (java.awt.Paint) color13);
        java.awt.Paint paint15 = waterfallBarRenderer14.getLastBarPaint();
        java.awt.Color color16 = java.awt.Color.darkGray;
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Color color19 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer20 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color16, paint17, (java.awt.Paint) color18, (java.awt.Paint) color19);
        java.awt.Color color21 = java.awt.Color.cyan;
        waterfallBarRenderer20.setBaseOutlinePaint((java.awt.Paint) color21);
        java.awt.Color color23 = java.awt.Color.darkGray;
        java.awt.Paint paint24 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color25 = java.awt.Color.darkGray;
        java.awt.Color color26 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer27 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color23, paint24, (java.awt.Paint) color25, (java.awt.Paint) color26);
        waterfallBarRenderer20.setBaseOutlinePaint(paint24);
        java.awt.Color color29 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel30 = null;
        java.awt.Rectangle rectangle31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.awt.geom.AffineTransform affineTransform33 = null;
        java.awt.RenderingHints renderingHints34 = null;
        java.awt.PaintContext paintContext35 = color29.createContext(colorModel30, rectangle31, rectangle2D32, affineTransform33, renderingHints34);
        int int36 = color29.getTransparency();
        java.awt.Color color37 = color29.darker();
        java.awt.Color color38 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel39 = null;
        java.awt.Rectangle rectangle40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.geom.AffineTransform affineTransform42 = null;
        java.awt.RenderingHints renderingHints43 = null;
        java.awt.PaintContext paintContext44 = color38.createContext(colorModel39, rectangle40, rectangle2D41, affineTransform42, renderingHints43);
        int int45 = color38.getTransparency();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer46 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint15, paint24, (java.awt.Paint) color29, (java.awt.Paint) color38);
        xYPlot6.setDomainTickBandPaint((java.awt.Paint) color38);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = xYPlot6.getRangeAxisEdge(5);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paintContext35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(paintContext44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge49);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint1, (java.awt.Paint) color2, (java.awt.Paint) color3);
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        waterfallBarRenderer4.setFirstBarPaint(paint5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        try {
            org.jfree.data.Range range8 = waterfallBarRenderer4.findRangeBounds(categoryDataset7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Paint paint6 = stackedBarRenderer3D3.getSeriesPaint(3);
        boolean boolean7 = stackedBarRenderer3D3.getAutoPopulateSeriesFillPaint();
        stackedBarRenderer3D3.setSeriesCreateEntities((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Paint paint13 = stackedBarRenderer3D3.getItemFillPaint(0, 0);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getMinOutlier(0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        double double4 = stackedBarRenderer3D3.getBase();
        java.awt.Paint paint6 = stackedBarRenderer3D3.getSeriesItemLabelPaint(0);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            stackedBarRenderer3D3.drawDomainGridline(graphics2D7, categoryPlot8, rectangle2D9, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String[] strArray2 = jFreeChartResources0.getStringArray("java.awt.Color[r=64,g=64,b=64]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key java.awt.Color[r=64,g=64,b=64]");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double7 = rectangleInsets5.calculateTopInset(0.0d);
        double double9 = rectangleInsets5.calculateRightInset((-49.5d));
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 100, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires end >= start.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Paint paint6 = stackedBarRenderer3D3.getSeriesPaint(3);
        boolean boolean7 = stackedBarRenderer3D3.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator12 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D3.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator12, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = null;
        stackedBarRenderer3D3.setSeriesItemLabelGenerator((int) (byte) 10, categoryItemLabelGenerator16, true);
        stackedBarRenderer3D3.setSeriesVisibleInLegend((int) ' ', (java.lang.Boolean) true, false);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape26 = numberAxis25.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis25, valueAxis27, xYItemRenderer28);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot29);
        org.jfree.chart.axis.ValueAxis valueAxis31 = xYPlot29.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace32 = xYPlot29.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot29.setRangeAxisLocation(axisLocation33);
        xYPlot29.setRangeCrosshairValue(1.0d);
        java.awt.Font font37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot29.setNoDataMessageFont(font37);
        stackedBarRenderer3D3.setBaseItemLabelFont(font37);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(valueAxis31);
        org.junit.Assert.assertNull(axisSpace32);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(font37);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace9 = xYPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot6.getDomainAxisEdge(3);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = null;
        try {
            xYPlot6.setOrientation(plotOrientation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            java.lang.Number number5 = taskSeriesCollection0.getEndValue((int) '4', (int) (byte) 10, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        double double4 = stackedBarRenderer3D3.getBase();
        double double5 = stackedBarRenderer3D3.getYOffset();
        java.awt.Paint paint7 = stackedBarRenderer3D3.getSeriesOutlinePaint((int) (short) -1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        try {
            stackedBarRenderer3D3.setSeriesItemLabelsVisible((int) (short) -1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Class class1 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        try {
            java.lang.Number number10 = taskSeriesCollection0.getEndValue((java.lang.Comparable) date5, (java.lang.Comparable) (-1), 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.gantt.TaskSeries taskSeries1 = null;
        try {
            taskSeriesCollection0.remove(taskSeries1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double6 = rectangleInsets5.getRight();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets5.createAdjustedRectangle(rectangle2D7, lengthAdjustmentType8, lengthAdjustmentType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.lang.Object obj1 = null;
        boolean boolean2 = lengthConstraintType0.equals(obj1);
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNull(rectangleEdge1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getPaint();
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        textTitle0.setPaint(paint2);
        boolean boolean4 = textTitle0.getNotify();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Number number4 = taskSeriesCollection0.getStartValue((java.lang.Comparable) 9999, (java.lang.Comparable) "org.jfree.data.time.TimePeriodFormatException: ", (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        boolean boolean1 = blockContainer0.isEmpty();
        double double2 = blockContainer0.getContentYOffset();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        try {
            java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier((int) (byte) 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Stroke stroke5 = stackedBarRenderer3D3.getBaseStroke();
        stackedBarRenderer3D3.setBase((double) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = null;
        try {
            stackedBarRenderer3D3.setBasePositiveItemLabelPosition(itemLabelPosition8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Color color7 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer8 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color4, paint5, (java.awt.Paint) color6, (java.awt.Paint) color7);
        java.awt.Paint paint9 = waterfallBarRenderer8.getLastBarPaint();
        java.awt.Color color10 = java.awt.Color.darkGray;
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Color color13 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer14 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color10, paint11, (java.awt.Paint) color12, (java.awt.Paint) color13);
        java.awt.Color color15 = java.awt.Color.cyan;
        waterfallBarRenderer14.setBaseOutlinePaint((java.awt.Paint) color15);
        java.awt.Color color17 = java.awt.Color.darkGray;
        java.awt.Paint paint18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color19 = java.awt.Color.darkGray;
        java.awt.Color color20 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer21 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color17, paint18, (java.awt.Paint) color19, (java.awt.Paint) color20);
        waterfallBarRenderer14.setBaseOutlinePaint(paint18);
        java.awt.Color color23 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel24 = null;
        java.awt.Rectangle rectangle25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.geom.AffineTransform affineTransform27 = null;
        java.awt.RenderingHints renderingHints28 = null;
        java.awt.PaintContext paintContext29 = color23.createContext(colorModel24, rectangle25, rectangle2D26, affineTransform27, renderingHints28);
        int int30 = color23.getTransparency();
        java.awt.Color color31 = color23.darker();
        java.awt.Color color32 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel33 = null;
        java.awt.Rectangle rectangle34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        java.awt.geom.AffineTransform affineTransform36 = null;
        java.awt.RenderingHints renderingHints37 = null;
        java.awt.PaintContext paintContext38 = color32.createContext(colorModel33, rectangle34, rectangle2D35, affineTransform36, renderingHints37);
        int int39 = color32.getTransparency();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer40 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint9, paint18, (java.awt.Paint) color23, (java.awt.Paint) color32);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier41 = waterfallBarRenderer40.getDrawingSupplier();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition42 = null;
        waterfallBarRenderer40.setPositiveItemLabelPositionFallback(itemLabelPosition42);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean46 = numberAxis45.isNegativeArrowVisible();
        numberAxis45.resizeRange((double) 100);
        numberAxis45.resizeRange((double) 100L);
        numberAxis45.setTickMarksVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean55 = numberAxis54.isNegativeArrowVisible();
        numberAxis54.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        numberAxis54.setLeftArrow(shape60);
        java.awt.Shape shape64 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape60, 0.0d, (double) (byte) -1);
        numberAxis45.setDownArrow(shape60);
        waterfallBarRenderer40.setBaseShape(shape60, true);
        java.awt.Stroke stroke68 = null;
        java.awt.Color color69 = java.awt.Color.magenta;
        try {
            org.jfree.chart.LegendItem legendItem70 = new org.jfree.chart.LegendItem("java.awt.Color[r=64,g=64,b=64]", "", "org.jfree.data.time.TimePeriodFormatException: ", "hi!", shape60, stroke68, (java.awt.Paint) color69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paintContext29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paintContext38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNull(drawingSupplier41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(color69);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        numberAxis1.resizeRange((double) 100L);
        org.jfree.chart.plot.Plot plot7 = numberAxis1.getPlot();
        java.awt.Color color8 = java.awt.Color.darkGray;
        java.awt.Paint paint9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color10 = java.awt.Color.darkGray;
        java.awt.Color color11 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer12 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color8, paint9, (java.awt.Paint) color10, (java.awt.Paint) color11);
        java.awt.Paint paint13 = waterfallBarRenderer12.getLastBarPaint();
        numberAxis1.setAxisLinePaint(paint13);
        numberAxis1.setUpperBound((double) 86400000L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            java.lang.Comparable comparable3 = taskSeriesCollection0.getRowKey(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape6 = numberAxis5.getLeftArrow();
        java.awt.Color color7 = java.awt.Color.darkGray;
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color9 = java.awt.Color.darkGray;
        java.awt.Color color10 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer11 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color7, paint8, (java.awt.Paint) color9, (java.awt.Paint) color10);
        java.awt.Paint[] paintArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Color color13 = java.awt.Color.darkGray;
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color15 = java.awt.Color.darkGray;
        java.awt.Color color16 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer17 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color13, paint14, (java.awt.Paint) color15, (java.awt.Paint) color16);
        int int18 = color13.getTransparency();
        java.awt.Color color19 = java.awt.Color.cyan;
        java.awt.Paint[] paintArray20 = new java.awt.Paint[] { color13, color19 };
        java.awt.Paint[] paintArray21 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator26 = stackedBarRenderer3D25.getLegendItemURLGenerator();
        java.awt.Stroke stroke27 = stackedBarRenderer3D25.getBaseStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator32 = stackedBarRenderer3D31.getLegendItemURLGenerator();
        java.awt.Stroke stroke33 = stackedBarRenderer3D31.getBaseStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D37 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator38 = stackedBarRenderer3D37.getLegendItemURLGenerator();
        java.awt.Stroke stroke39 = stackedBarRenderer3D37.getBaseStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D43 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator44 = stackedBarRenderer3D43.getLegendItemURLGenerator();
        java.awt.Stroke stroke45 = stackedBarRenderer3D43.getBaseStroke();
        java.awt.Stroke stroke46 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray47 = new java.awt.Stroke[] { stroke27, stroke33, stroke39, stroke45, stroke46 };
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D51 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator52 = stackedBarRenderer3D51.getLegendItemURLGenerator();
        java.awt.Stroke stroke53 = stackedBarRenderer3D51.getBaseStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D57 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator58 = stackedBarRenderer3D57.getLegendItemURLGenerator();
        java.awt.Stroke stroke59 = stackedBarRenderer3D57.getBaseStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D63 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator64 = stackedBarRenderer3D63.getLegendItemURLGenerator();
        java.awt.Stroke stroke65 = stackedBarRenderer3D63.getBaseStroke();
        java.awt.Stroke stroke66 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D70 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator71 = stackedBarRenderer3D70.getLegendItemURLGenerator();
        java.awt.Stroke stroke72 = stackedBarRenderer3D70.getBaseStroke();
        java.awt.Stroke stroke73 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray74 = new java.awt.Stroke[] { stroke53, stroke59, stroke65, stroke66, stroke72, stroke73 };
        org.jfree.chart.axis.NumberAxis numberAxis76 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape77 = numberAxis76.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis79 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean80 = numberAxis79.isNegativeArrowVisible();
        numberAxis79.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis84 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape85 = numberAxis84.getLeftArrow();
        numberAxis79.setLeftArrow(shape85);
        java.awt.Shape[] shapeArray87 = new java.awt.Shape[] { shape77, shape85 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier88 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray12, paintArray20, paintArray21, strokeArray47, strokeArray74, shapeArray87);
        java.awt.Stroke stroke89 = defaultDrawingSupplier88.getNextStroke();
        java.awt.Color color90 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.LegendItem legendItem91 = new org.jfree.chart.LegendItem("", "hi!", "TextAnchor.CENTER_RIGHT", "hi!", shape6, paint8, stroke89, (java.awt.Paint) color90);
        boolean boolean92 = legendItem91.isShapeOutlineVisible();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintArray20);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(strokeArray47);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator64);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator71);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(strokeArray74);
        org.junit.Assert.assertNotNull(shape77);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(shape85);
        org.junit.Assert.assertNotNull(shapeArray87);
        org.junit.Assert.assertNotNull(stroke89);
        org.junit.Assert.assertNotNull(color90);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        jFreeChart7.setTextAntiAlias(false);
        boolean boolean10 = jFreeChart7.getAntiAlias();
        org.jfree.chart.title.Title title12 = jFreeChart7.getSubtitle(0);
        jFreeChart7.fireChartChanged();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(title12);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double7 = rectangleInsets5.calculateTopInset(0.0d);
        double double9 = rectangleInsets5.calculateBottomInset((double) 'a');
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets5.createInsetRectangle(rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace9 = xYPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation(axisLocation10);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Color color15 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer16 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color12, paint13, (java.awt.Paint) color14, (java.awt.Paint) color15);
        xYPlot6.setDomainCrosshairPaint((java.awt.Paint) color14);
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        try {
            xYPlot6.addRangeMarker(marker18, layer19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((-1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Preceding" + "'", str1.equals("Preceding"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.removeColumn((java.lang.Comparable) (-49.5d));
        try {
            java.lang.Comparable comparable4 = defaultKeyedValues2D0.getRowKey((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        taskSeriesCollection0.validateObject();
        try {
            java.lang.Number number5 = taskSeriesCollection0.getValue((int) ' ', 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("TextAnchor.CENTER_RIGHT", graphics2D1, (float) 'a', (float) 100L, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot6.getRangeAxisEdge((int) 'a');
        org.jfree.chart.plot.Plot plot11 = xYPlot6.getParent();
        double double12 = xYPlot6.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape7 = numberAxis6.getLeftArrow();
        numberAxis1.setLeftArrow(shape7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean11 = numberAxis10.isNegativeArrowVisible();
        numberAxis10.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape16 = numberAxis15.getLeftArrow();
        numberAxis10.setLeftArrow(shape16);
        numberAxis1.setDownArrow(shape16);
        boolean boolean19 = numberAxis1.isPositiveArrowVisible();
        org.jfree.data.Range range20 = numberAxis1.getRange();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(range20);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 0, (int) '4', (int) (byte) 100);
        org.jfree.chart.block.BorderArrangement borderArrangement4 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) borderArrangement4);
        int int6 = segmentedTimeline3.getSegmentsExcluded();
        try {
            segmentedTimeline3.addException((long) 12, (long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double14 = rectangleInsets13.getRight();
        xYPlot6.setInsets(rectangleInsets13);
        boolean boolean16 = xYPlot6.isDomainZoomable();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("{0}", font19);
        java.awt.geom.Rectangle2D rectangle2D21 = labelBlock20.getBounds();
        try {
            xYPlot6.drawBackground(graphics2D17, rectangle2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(rectangle2D21);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.removeColumn((java.lang.Comparable) (-49.5d));
        try {
            java.lang.Number number5 = defaultKeyedValues2D0.getValue(12, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = stackedBarRenderer3D4.getLegendItemURLGenerator();
        java.awt.Stroke stroke6 = stackedBarRenderer3D4.getBaseStroke();
        stackedBarRenderer3D4.setBase((double) (byte) -1);
        stackedBarRenderer3D4.setSeriesItemLabelsVisible(100, (java.lang.Boolean) false);
        boolean boolean12 = sortOrder0.equals((java.lang.Object) 100);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        java.lang.Object obj2 = stackedAreaRenderer1.clone();
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType3 = org.jfree.chart.renderer.AreaRendererEndType.TAPER;
        stackedAreaRenderer1.setEndType(areaRendererEndType3);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(areaRendererEndType3);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        java.awt.Paint paint3 = categoryAxis3D1.getLabelPaint();
        categoryAxis3D1.setLowerMargin(0.2d);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = null;
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape12 = numberAxis11.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis11, valueAxis13, xYItemRenderer14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = xYPlot15.getRangeAxis();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("{0}", font19);
        java.awt.geom.Rectangle2D rectangle2D21 = labelBlock20.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        xYPlot15.drawAnnotations(graphics2D17, rectangle2D21, plotRenderingInfo22);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape27 = numberAxis26.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) numberAxis26, valueAxis28, xYItemRenderer29);
        org.jfree.chart.JFreeChart jFreeChart31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot30);
        org.jfree.chart.block.BlockBorder blockBorder36 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = blockBorder36.getInsets();
        double double38 = rectangleInsets37.getRight();
        xYPlot30.setInsets(rectangleInsets37);
        java.awt.Color color40 = java.awt.Color.YELLOW;
        xYPlot30.setDomainTickBandPaint((java.awt.Paint) color40);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = xYPlot30.getDomainAxisEdge();
        try {
            double double43 = categoryAxis3D1.getCategoryJava2DCoordinate(categoryAnchor6, 5, 15, rectangle2D21, rectangleEdge42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(rectangleEdge42);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        int int4 = defaultCategoryDataset3.getRowCount();
        java.util.List list5 = defaultCategoryDataset3.getColumnKeys();
        try {
            defaultBoxAndWhiskerCategoryDataset0.add(list5, (java.lang.Comparable) 4, (java.lang.Comparable) 8.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (Infinity) <= upper (-Infinity).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape5 = numberAxis4.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, valueAxis6, xYItemRenderer7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot8.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace11 = xYPlot8.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot8.getDomainAxisEdge(3);
        taskSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot8);
        try {
            java.lang.Number number18 = taskSeriesCollection0.getEndValue((int) (byte) 1, (int) '4', 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(valueAxis10);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation2 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        jFreeChart7.setTextAntiAlias(false);
        jFreeChart7.setNotify(false);
        org.jfree.chart.title.LegendTitle legendTitle12 = null;
        try {
            jFreeChart7.addLegend(legendTitle12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 0, (int) '4', (int) (byte) 100);
        org.jfree.chart.block.BorderArrangement borderArrangement4 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) borderArrangement4);
        java.lang.Object obj6 = null;
        boolean boolean7 = segmentedTimeline3.equals(obj6);
        int int8 = segmentedTimeline3.getSegmentsExcluded();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot6.getRangeAxisEdge((int) 'a');
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        try {
            xYPlot6.addRangeMarker(marker11, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextBlock textBlock7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = null;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.lang.String str10 = textAnchor9.toString();
        org.jfree.chart.axis.CategoryTick categoryTick12 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) (short) 1, textBlock7, textBlockAnchor8, textAnchor9, 6.0d);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("org.jfree.data.time.TimePeriodFormatException: ", graphics2D1, (float) 10L, (float) '#', textAnchor4, 10.0d, textAnchor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str10.equals("TextAnchor.CENTER_RIGHT"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = rendererState1.getInfo();
        org.junit.Assert.assertNull(plotRenderingInfo2);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape7 = numberAxis6.getLeftArrow();
        numberAxis1.setLeftArrow(shape7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean11 = numberAxis10.isNegativeArrowVisible();
        numberAxis10.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape16 = numberAxis15.getLeftArrow();
        numberAxis10.setLeftArrow(shape16);
        numberAxis1.setDownArrow(shape16);
        boolean boolean19 = numberAxis1.isPositiveArrowVisible();
        boolean boolean20 = numberAxis1.isNegativeArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot6.getRangeAxis();
        java.awt.Paint paint8 = xYPlot6.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = stackedBarRenderer3D3.getSeriesPositiveItemLabelPosition(0);
        stackedBarRenderer3D3.setIncludeBaseInRange(true);
        boolean boolean9 = stackedBarRenderer3D3.getIncludeBaseInRange();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo12);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator18 = stackedBarRenderer3D17.getLegendItemURLGenerator();
        java.awt.Paint paint20 = stackedBarRenderer3D17.getSeriesPaint(3);
        boolean boolean21 = stackedBarRenderer3D17.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator22 = null;
        stackedBarRenderer3D17.setLegendItemURLGenerator(categorySeriesLabelGenerator22);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint26 = categoryPlot25.getRangeGridlinePaint();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean29 = numberAxis28.isNegativeArrowVisible();
        org.jfree.chart.plot.Marker marker30 = null;
        java.awt.Font font32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock33 = new org.jfree.chart.block.LabelBlock("{0}", font32);
        java.awt.geom.Rectangle2D rectangle2D34 = labelBlock33.getBounds();
        stackedBarRenderer3D17.drawRangeMarker(graphics2D24, categoryPlot25, (org.jfree.chart.axis.ValueAxis) numberAxis28, marker30, rectangle2D34);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation37 = categoryPlot36.getDomainAxisLocation();
        java.awt.Color color39 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot36.setRangeGridlinePaint((java.awt.Paint) color39);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D42 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double43 = categoryAxis3D42.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean46 = numberAxis45.isNegativeArrowVisible();
        numberAxis45.resizeRange((double) 100);
        boolean boolean50 = numberAxis45.equals((java.lang.Object) 12);
        numberAxis45.setTickLabelsVisible(false);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection53 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot54 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection53);
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape58 = numberAxis57.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot(xYDataset55, (org.jfree.chart.axis.ValueAxis) numberAxis57, valueAxis59, xYItemRenderer60);
        org.jfree.chart.JFreeChart jFreeChart62 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot61);
        org.jfree.chart.axis.ValueAxis valueAxis63 = xYPlot61.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace64 = xYPlot61.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = xYPlot61.getDomainAxisEdge(3);
        taskSeriesCollection53.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot61);
        try {
            stackedBarRenderer3D3.drawItem(graphics2D10, categoryItemRendererState13, rectangle2D34, categoryPlot36, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D42, (org.jfree.chart.axis.ValueAxis) numberAxis45, (org.jfree.data.category.CategoryDataset) taskSeriesCollection53, 15, 5, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator18);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.05d + "'", double43 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertNotNull(valueAxis63);
        org.junit.Assert.assertNull(axisSpace64);
        org.junit.Assert.assertNotNull(rectangleEdge66);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        double double2 = rectangleInsets1.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Class class2 = null;
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date6 = dateRange5.getUpperDate();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date6, timeZone7);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date12 = dateRange11.getUpperDate();
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange(date6, date12);
        keyedObjects2D0.removeObject((java.lang.Comparable) "org.jfree.data.time.TimePeriodFormatException: ", (java.lang.Comparable) date6);
        java.util.TimeZone timeZone15 = null;
        try {
            org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date6, timeZone15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Stroke stroke5 = stackedBarRenderer3D3.getBaseStroke();
        stackedBarRenderer3D3.setBase((double) (byte) -1);
        stackedBarRenderer3D3.setSeriesItemLabelsVisible(100, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = null;
        stackedBarRenderer3D3.setLegendItemToolTipGenerator(categorySeriesLabelGenerator11);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        boolean boolean2 = dataPackageResources0.containsKey("ThreadContext");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.setValue((double) 60000L, (java.lang.Comparable) 10.0f, (java.lang.Comparable) 2);
        try {
            java.lang.Comparable comparable6 = defaultCategoryDataset0.getRowKey(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) (byte) -1);
        double double4 = rectangleInsets0.calculateBottomOutset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.0d) + "'", double2 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.awt.Paint paint0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape7 = numberAxis6.getLeftArrow();
        numberAxis1.setLeftArrow(shape7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, 0.0d, (double) (byte) -1);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity14 = new org.jfree.chart.entity.TickLabelEntity(shape7, "0", "{0}");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Color color7 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer8 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color4, paint5, (java.awt.Paint) color6, (java.awt.Paint) color7);
        stackedBarRenderer3D3.setBasePaint(paint5, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = stackedBarRenderer3D3.getItemLabelGenerator((int) (short) 0, 3);
        stackedBarRenderer3D3.setBase(8.0d);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState17 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo18);
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock22 = new org.jfree.chart.block.LabelBlock("{0}", font21);
        java.awt.geom.Rectangle2D rectangle2D23 = labelBlock22.getBounds();
        plotRenderingInfo19.setPlotArea(rectangle2D23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot25.getDomainAxisLocation();
        java.awt.Color color28 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot25.setRangeGridlinePaint((java.awt.Paint) color28);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape34 = numberAxis33.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) numberAxis33, valueAxis35, xYItemRenderer36);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot37);
        org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot37.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = xYPlot37.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation43 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot37.setDomainAxisLocation(10, axisLocation43, false);
        categoryPlot25.setDomainAxisLocation(12, axisLocation43);
        java.awt.Stroke stroke47 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace48 = null;
        categoryPlot25.setFixedRangeAxisSpace(axisSpace48);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D51 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.Object obj52 = categoryAxis3D51.clone();
        int int53 = categoryAxis3D51.getCategoryLabelPositionOffset();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent54 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D51);
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset56 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class57 = null;
        org.jfree.data.time.DateRange dateRange60 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date61 = dateRange60.getUpperDate();
        java.util.TimeZone timeZone62 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date61, timeZone62);
        org.jfree.data.time.DateRange dateRange66 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date67 = dateRange66.getUpperDate();
        org.jfree.data.time.DateRange dateRange68 = new org.jfree.data.time.DateRange(date61, date67);
        org.jfree.data.general.PieDataset pieDataset69 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset56, (java.lang.Comparable) date61);
        try {
            stackedBarRenderer3D3.drawItem(graphics2D16, categoryItemRendererState17, rectangle2D23, categoryPlot25, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D51, valueAxis55, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset56, 100, (int) (short) -1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(valueAxis39);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 4 + "'", int53 == 4);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(pieDataset69);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            java.lang.Comparable comparable2 = defaultBoxAndWhiskerCategoryDataset0.getColumnKey(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (short) -1, (double) (byte) 100);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.width = 10L;
        double double3 = size2D0.getHeight();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot6.getRangeAxis();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("{0}", font10);
        java.awt.geom.Rectangle2D rectangle2D12 = labelBlock11.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        xYPlot6.drawAnnotations(graphics2D8, rectangle2D12, plotRenderingInfo13);
        xYPlot6.setForegroundAlpha((float) 2958465);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(rectangle2D12);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int1 = defaultCategoryDataset0.getRowCount();
        try {
            java.lang.Number number4 = defaultCategoryDataset0.getValue(0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Paint paint6 = stackedBarRenderer3D3.getSeriesPaint(3);
        boolean boolean7 = stackedBarRenderer3D3.getAutoPopulateSeriesFillPaint();
        boolean boolean8 = stackedBarRenderer3D3.getIncludeBaseInRange();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape5 = numberAxis4.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, valueAxis6, xYItemRenderer7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot8.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace11 = xYPlot8.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot8.getDomainAxisEdge(3);
        taskSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot8);
        try {
            java.lang.Comparable comparable16 = taskSeriesCollection0.getRowKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(valueAxis10);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        taskSeriesCollection0.validateObject();
        try {
            java.lang.Number number6 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) 9, (java.lang.Comparable) (-1), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint1, (java.awt.Paint) color2, (java.awt.Paint) color3);
        java.awt.Paint paint5 = waterfallBarRenderer4.getLastBarPaint();
        java.awt.Shape shape6 = waterfallBarRenderer4.getBaseShape();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = null;
        try {
            java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape6, rectangleAnchor7, 3.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem1 = null;
        try {
            defaultBoxAndWhiskerCategoryDataset0.add(boxAndWhiskerItem1, (java.lang.Comparable) 60000L, (java.lang.Comparable) 3.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace9 = xYPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot6.getDomainAxisEdge(3);
        java.awt.Paint paint12 = null;
        try {
            xYPlot6.setDomainCrosshairPaint(paint12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape7 = numberAxis6.getLeftArrow();
        numberAxis1.setLeftArrow(shape7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean11 = numberAxis10.isNegativeArrowVisible();
        numberAxis10.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape16 = numberAxis15.getLeftArrow();
        numberAxis10.setLeftArrow(shape16);
        numberAxis1.setDownArrow(shape16);
        java.awt.Shape shape19 = numberAxis1.getDownArrow();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator24 = stackedBarRenderer3D23.getLegendItemURLGenerator();
        java.awt.Paint paint26 = stackedBarRenderer3D23.getSeriesPaint(3);
        java.awt.Shape shape27 = stackedBarRenderer3D23.getBaseShape();
        numberAxis1.setUpArrow(shape27);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator24);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(shape27);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int1 = defaultKeyedValues2D0.getColumnCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint1, (java.awt.Paint) color2, (java.awt.Paint) color3);
        java.awt.Paint paint5 = waterfallBarRenderer4.getLastBarPaint();
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color8 = java.awt.Color.darkGray;
        java.awt.Color color9 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer10 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color6, paint7, (java.awt.Paint) color8, (java.awt.Paint) color9);
        java.awt.Color color11 = java.awt.Color.cyan;
        waterfallBarRenderer10.setBaseOutlinePaint((java.awt.Paint) color11);
        java.awt.Color color13 = java.awt.Color.darkGray;
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color15 = java.awt.Color.darkGray;
        java.awt.Color color16 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer17 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color13, paint14, (java.awt.Paint) color15, (java.awt.Paint) color16);
        waterfallBarRenderer10.setBaseOutlinePaint(paint14);
        java.awt.Color color19 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.AffineTransform affineTransform23 = null;
        java.awt.RenderingHints renderingHints24 = null;
        java.awt.PaintContext paintContext25 = color19.createContext(colorModel20, rectangle21, rectangle2D22, affineTransform23, renderingHints24);
        int int26 = color19.getTransparency();
        java.awt.Color color27 = color19.darker();
        java.awt.Color color28 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel29 = null;
        java.awt.Rectangle rectangle30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.geom.AffineTransform affineTransform32 = null;
        java.awt.RenderingHints renderingHints33 = null;
        java.awt.PaintContext paintContext34 = color28.createContext(colorModel29, rectangle30, rectangle2D31, affineTransform32, renderingHints33);
        int int35 = color28.getTransparency();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer36 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint5, paint14, (java.awt.Paint) color19, (java.awt.Paint) color28);
        java.awt.Stroke stroke39 = waterfallBarRenderer36.getItemOutlineStroke(4, 3);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D44 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator45 = stackedBarRenderer3D44.getLegendItemURLGenerator();
        java.awt.Paint paint47 = stackedBarRenderer3D44.getSeriesPaint(3);
        boolean boolean48 = stackedBarRenderer3D44.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator53 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D44.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator53, true);
        java.awt.Font font58 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock59 = new org.jfree.chart.block.LabelBlock("{0}", font58);
        java.awt.geom.Rectangle2D rectangle2D60 = labelBlock59.getBounds();
        stackedBarRenderer3D44.setSeriesShape(5, (java.awt.Shape) rectangle2D60);
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation63 = categoryPlot62.getDomainAxisLocation();
        java.awt.Color color65 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot62.setRangeGridlinePaint((java.awt.Paint) color65);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo68 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo68);
        java.awt.Font font71 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock72 = new org.jfree.chart.block.LabelBlock("{0}", font71);
        java.awt.geom.Rectangle2D rectangle2D73 = labelBlock72.getBounds();
        plotRenderingInfo69.setPlotArea(rectangle2D73);
        java.awt.geom.Point2D point2D75 = null;
        categoryPlot62.zoomRangeAxes((double) 8, plotRenderingInfo69, point2D75);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo78 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo79 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo78);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState80 = waterfallBarRenderer36.initialise(graphics2D40, rectangle2D60, categoryPlot62, 3, plotRenderingInfo79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintContext25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paintContext34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator45);
        org.junit.Assert.assertNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(axisLocation63);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(font71);
        org.junit.Assert.assertNotNull(rectangle2D73);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        xYPlot6.setBackgroundImageAlignment((int) (byte) -1);
        float float9 = xYPlot6.getForegroundAlpha();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator14 = stackedBarRenderer3D13.getLegendItemURLGenerator();
        java.awt.Stroke stroke15 = stackedBarRenderer3D13.getBaseStroke();
        xYPlot6.setOutlineStroke(stroke15);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot18.getDomainAxisLocation();
        java.awt.Color color21 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot18.setRangeGridlinePaint((java.awt.Paint) color21);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape27 = numberAxis26.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) numberAxis26, valueAxis28, xYItemRenderer29);
        org.jfree.chart.JFreeChart jFreeChart31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot30);
        org.jfree.chart.axis.ValueAxis valueAxis32 = xYPlot30.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = xYPlot30.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot30.setDomainAxisLocation(10, axisLocation36, false);
        categoryPlot18.setDomainAxisLocation(12, axisLocation36);
        try {
            xYPlot6.setRangeAxisLocation((int) (byte) -1, axisLocation36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(valueAxis32);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNotNull(axisLocation36);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean6 = numberAxis5.isNegativeArrowVisible();
        numberAxis5.resizeRange((double) 100);
        numberAxis5.resizeRange((double) 100L);
        numberAxis5.setTickMarksVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean15 = numberAxis14.isNegativeArrowVisible();
        numberAxis14.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape20 = numberAxis19.getLeftArrow();
        numberAxis14.setLeftArrow(shape20);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape20, 0.0d, (double) (byte) -1);
        numberAxis5.setDownArrow(shape20);
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint27 = null;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("{0}", "{0}", "ThreadContext", "ThreadContext", shape20, stroke26, paint27);
        java.lang.String str29 = legendItem28.getLabel();
        int int30 = legendItem28.getDatasetIndex();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "{0}" + "'", str29.equals("{0}"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double7 = rectangleInsets5.calculateTopInset(0.0d);
        double double9 = rectangleInsets5.calculateBottomInset((double) 'a');
        double double11 = rectangleInsets5.calculateTopInset(1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 5, (byte) 10 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 5, (byte) 10 };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray6, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.CENTER_RIGHT", "ThreadContext", numberArray10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("0", "Preceding", numberArray10);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(categoryDataset12);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        java.awt.Paint paint3 = categoryAxis3D1.getLabelPaint();
        boolean boolean4 = categoryAxis3D1.isAxisLineVisible();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot6.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        int int13 = xYPlot6.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis12);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot6.getRangeAxis();
        xYPlot6.setBackgroundAlpha((float) (short) -1);
        xYPlot6.setRangeCrosshairValue(6.0d, false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis7);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = numberAxis1.getLeftArrow();
        float float3 = numberAxis1.getTickMarkInsideLength();
        numberAxis1.setVisible(true);
        java.awt.Color color6 = java.awt.Color.YELLOW;
        boolean boolean7 = numberAxis1.equals((java.lang.Object) color6);
        numberAxis1.centerRange((double) 4);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        try {
            java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier(8, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) 'a');
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder(1.0d, 1.0d, (double) 2958465, 0.0d);
        boolean boolean8 = multiplePiePlot0.equals((java.lang.Object) 1.0d);
        multiplePiePlot0.setOutlineVisible(false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color1 = color0.brighter();
        java.awt.color.ColorSpace colorSpace2 = null;
        java.awt.Color color3 = java.awt.Color.black;
        float[] floatArray10 = new float[] { (byte) -1, 10, (short) 0, (byte) 0, 2958465, (short) 1 };
        float[] floatArray11 = color3.getComponents(floatArray10);
        try {
            float[] floatArray12 = color0.getComponents(colorSpace2, floatArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Color color7 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer8 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color4, paint5, (java.awt.Paint) color6, (java.awt.Paint) color7);
        stackedBarRenderer3D3.setBasePaint(paint5, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = stackedBarRenderer3D3.getItemLabelGenerator((int) (short) 0, 3);
        stackedBarRenderer3D3.setBase(8.0d);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot17.getDomainAxisLocation();
        java.awt.Color color20 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot17.setRangeGridlinePaint((java.awt.Paint) color20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot17.getDomainAxis((int) (byte) 0);
        categoryPlot17.configureDomainAxes();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D28 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedBarRenderer3D28.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = stackedBarRenderer3D28.getSeriesPositiveItemLabelPosition(0);
        stackedBarRenderer3D28.setItemLabelAnchorOffset((double) '#');
        boolean boolean34 = stackedBarRenderer3D28.getAutoPopulateSeriesPaint();
        categoryPlot17.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D28, false);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D38 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int39 = categoryAxis3D38.getCategoryLabelPositionOffset();
        org.jfree.chart.plot.CategoryMarker categoryMarker40 = null;
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape44 = numberAxis43.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset41, (org.jfree.chart.axis.ValueAxis) numberAxis43, valueAxis45, xYItemRenderer46);
        org.jfree.chart.axis.ValueAxis valueAxis48 = xYPlot47.getRangeAxis();
        java.awt.Graphics2D graphics2D49 = null;
        java.awt.Font font51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock52 = new org.jfree.chart.block.LabelBlock("{0}", font51);
        java.awt.geom.Rectangle2D rectangle2D53 = labelBlock52.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        xYPlot47.drawAnnotations(graphics2D49, rectangle2D53, plotRenderingInfo54);
        try {
            stackedBarRenderer3D3.drawDomainMarker(graphics2D16, categoryPlot17, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D38, categoryMarker40, rectangle2D53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNull(valueAxis48);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(rectangle2D53);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape9 = numberAxis8.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis8, valueAxis10, xYItemRenderer11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot12.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot12.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setDomainAxisLocation(10, axisLocation18, false);
        categoryPlot0.setDomainAxisLocation(12, axisLocation18);
        java.awt.Stroke stroke22 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace23);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection26 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection26);
        taskSeriesCollection26.validateObject();
        categoryPlot0.setDataset(12, (org.jfree.data.category.CategoryDataset) taskSeriesCollection26);
        try {
            java.lang.Number number33 = taskSeriesCollection26.getEndValue(8, (int) (byte) -1, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list1 = defaultKeyedValues2D0.getColumnKeys();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(2958465);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) (byte) -1);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection2);
        multiplePiePlot1.setDataset((org.jfree.data.category.CategoryDataset) taskSeriesCollection2);
        try {
            java.lang.Number number7 = taskSeriesCollection2.getPercentComplete((int) (byte) 1, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        taskSeriesCollection0.validateObject();
        org.jfree.data.gantt.TaskSeries taskSeries3 = null;
        try {
            taskSeriesCollection0.add(taskSeries3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape9 = numberAxis8.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis8, valueAxis10, xYItemRenderer11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot12.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot12.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setDomainAxisLocation(10, axisLocation18, false);
        categoryPlot0.setDomainAxisLocation(12, axisLocation18);
        java.awt.Stroke stroke22 = categoryPlot0.getDomainGridlineStroke();
        try {
            categoryPlot0.zoom((double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        blockContainer0.setPadding(rectangleInsets2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("{0}", font6);
        java.awt.geom.Rectangle2D rectangle2D8 = labelBlock7.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D8, rectangleEdge9);
        try {
            blockContainer0.draw(graphics2D4, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = stackedBarRenderer3D3.getSeriesPositiveItemLabelPosition(0);
        stackedBarRenderer3D3.setItemLabelAnchorOffset((double) '#');
        boolean boolean9 = stackedBarRenderer3D3.getAutoPopulateSeriesPaint();
        double double10 = stackedBarRenderer3D3.getItemLabelAnchorOffset();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 35.0d + "'", double10 == 35.0d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        jFreeChart7.setTextAntiAlias(false);
        boolean boolean10 = jFreeChart7.getAntiAlias();
        boolean boolean11 = jFreeChart7.isNotify();
        boolean boolean12 = jFreeChart7.getAntiAlias();
        int int13 = jFreeChart7.getBackgroundImageAlignment();
        java.awt.RenderingHints renderingHints14 = null;
        try {
            jFreeChart7.setRenderingHints(renderingHints14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("0");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name 0, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class1 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date5, date11);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) date5);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date5);
        java.util.Date date15 = month14.getEnd();
        long long16 = month14.getSerialIndex();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 23640L + "'", long16 == 23640L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        xYPlot6.setBackgroundImageAlignment((int) (byte) -1);
        float float9 = xYPlot6.getForegroundAlpha();
        java.awt.Paint paint10 = xYPlot6.getDomainZeroBaselinePaint();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation11 = null;
        try {
            boolean boolean12 = xYPlot6.removeAnnotation(xYAnnotation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        try {
            java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMeanValue((-1), (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        org.jfree.data.Range range5 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange2, (double) (byte) -1, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange2, (double) 2);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = rectangleConstraint7.getHeightConstraintType();
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint1, (java.awt.Paint) color2, (java.awt.Paint) color3);
        java.awt.Paint paint5 = waterfallBarRenderer4.getLastBarPaint();
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color8 = java.awt.Color.darkGray;
        java.awt.Color color9 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer10 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color6, paint7, (java.awt.Paint) color8, (java.awt.Paint) color9);
        java.awt.Color color11 = java.awt.Color.cyan;
        waterfallBarRenderer10.setBaseOutlinePaint((java.awt.Paint) color11);
        java.awt.Color color13 = java.awt.Color.darkGray;
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color15 = java.awt.Color.darkGray;
        java.awt.Color color16 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer17 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color13, paint14, (java.awt.Paint) color15, (java.awt.Paint) color16);
        waterfallBarRenderer10.setBaseOutlinePaint(paint14);
        java.awt.Color color19 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.AffineTransform affineTransform23 = null;
        java.awt.RenderingHints renderingHints24 = null;
        java.awt.PaintContext paintContext25 = color19.createContext(colorModel20, rectangle21, rectangle2D22, affineTransform23, renderingHints24);
        int int26 = color19.getTransparency();
        java.awt.Color color27 = color19.darker();
        java.awt.Color color28 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel29 = null;
        java.awt.Rectangle rectangle30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.geom.AffineTransform affineTransform32 = null;
        java.awt.RenderingHints renderingHints33 = null;
        java.awt.PaintContext paintContext34 = color28.createContext(colorModel29, rectangle30, rectangle2D31, affineTransform32, renderingHints33);
        int int35 = color28.getTransparency();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer36 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint5, paint14, (java.awt.Paint) color19, (java.awt.Paint) color28);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier37 = waterfallBarRenderer36.getDrawingSupplier();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = null;
        waterfallBarRenderer36.setPositiveItemLabelPositionFallback(itemLabelPosition38);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean42 = numberAxis41.isNegativeArrowVisible();
        numberAxis41.resizeRange((double) 100);
        numberAxis41.resizeRange((double) 100L);
        numberAxis41.setTickMarksVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean51 = numberAxis50.isNegativeArrowVisible();
        numberAxis50.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis55 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape56 = numberAxis55.getLeftArrow();
        numberAxis50.setLeftArrow(shape56);
        java.awt.Shape shape60 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape56, 0.0d, (double) (byte) -1);
        numberAxis41.setDownArrow(shape56);
        waterfallBarRenderer36.setBaseShape(shape56, true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D67 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator68 = stackedBarRenderer3D67.getLegendItemURLGenerator();
        java.awt.Paint paint70 = stackedBarRenderer3D67.getSeriesPaint(3);
        boolean boolean71 = stackedBarRenderer3D67.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator76 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D67.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator76, true);
        java.awt.Font font81 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock82 = new org.jfree.chart.block.LabelBlock("{0}", font81);
        java.awt.geom.Rectangle2D rectangle2D83 = labelBlock82.getBounds();
        stackedBarRenderer3D67.setSeriesShape(5, (java.awt.Shape) rectangle2D83);
        waterfallBarRenderer36.setBaseShape((java.awt.Shape) rectangle2D83);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintContext25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paintContext34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNull(drawingSupplier37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator68);
        org.junit.Assert.assertNull(paint70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(font81);
        org.junit.Assert.assertNotNull(rectangle2D83);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("{0}", font7);
        java.awt.geom.Rectangle2D rectangle2D9 = labelBlock8.getBounds();
        plotRenderingInfo5.setPlotArea(rectangle2D9);
        java.awt.Color color11 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color11.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        int int18 = color11.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic19 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D9, (java.awt.Paint) color11);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean22 = numberAxis21.isNegativeArrowVisible();
        numberAxis21.resizeRange((double) 100);
        boolean boolean26 = numberAxis21.equals((java.lang.Object) 12);
        double double27 = numberAxis21.getLowerBound();
        java.text.NumberFormat numberFormat28 = numberAxis21.getNumberFormatOverride();
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape32 = numberAxis31.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis31, valueAxis33, xYItemRenderer34);
        xYPlot35.setBackgroundImageAlignment((int) (byte) -1);
        float float38 = xYPlot35.getForegroundAlpha();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D42 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator43 = stackedBarRenderer3D42.getLegendItemURLGenerator();
        java.awt.Stroke stroke44 = stackedBarRenderer3D42.getBaseStroke();
        xYPlot35.setOutlineStroke(stroke44);
        numberAxis21.setAxisLineStroke(stroke44);
        java.awt.Paint paint47 = null;
        try {
            org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem(attributedString0, "ThreadContext", "DateTickUnit[HOUR, 97]", "", (java.awt.Shape) rectangle2D9, stroke44, paint47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-49.5d) + "'", double27 == (-49.5d));
        org.junit.Assert.assertNull(numberFormat28);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 1.0f + "'", float38 == 1.0f);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator43);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.util.Date date0 = null;
        java.util.Date date1 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(date0, date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (byte) 1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) borderArrangement0);
        blockContainer1.setWidth((double) 100);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) '#');
        java.awt.Paint paint3 = stackedBarRenderer3D2.getWallPaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        stackedBarRenderer3D2.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator5);
        stackedBarRenderer3D2.setItemMargin(1.0d);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        jFreeChart7.setTextAntiAlias(false);
        boolean boolean10 = jFreeChart7.getAntiAlias();
        boolean boolean11 = jFreeChart7.isNotify();
        jFreeChart7.setBorderVisible(false);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer16 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D20 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator21 = stackedBarRenderer3D20.getLegendItemURLGenerator();
        java.awt.Paint paint23 = stackedBarRenderer3D20.getSeriesPaint(3);
        boolean boolean24 = stackedBarRenderer3D20.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator29 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D20.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator29, true);
        java.awt.Font font34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock35 = new org.jfree.chart.block.LabelBlock("{0}", font34);
        java.awt.geom.Rectangle2D rectangle2D36 = labelBlock35.getBounds();
        stackedBarRenderer3D20.setSeriesShape(5, (java.awt.Shape) rectangle2D36);
        boolean boolean38 = stackedAreaRenderer16.equals((java.lang.Object) rectangle2D36);
        java.awt.geom.Point2D point2D39 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = null;
        try {
            jFreeChart7.draw(graphics2D14, rectangle2D36, point2D39, chartRenderingInfo40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator21);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Paint paint6 = stackedBarRenderer3D3.getSeriesPaint(3);
        boolean boolean7 = stackedBarRenderer3D3.getAutoPopulateSeriesFillPaint();
        stackedBarRenderer3D3.setSeriesCreateEntities((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = stackedBarRenderer3D3.getSeriesNegativeItemLabelPosition(100);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.extendWidth((double) 3);
        double double4 = rectangleInsets0.extendHeight((double) 'a');
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 99.0d + "'", double4 == 99.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D1.getCategoryEnd(2958465, 100, rectangle2D5, rectangleEdge6);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        categoryAxis3D1.setCategoryLabelPositions(categoryLabelPositions8);
        java.lang.Object obj10 = categoryAxis3D1.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo1);
        org.jfree.chart.renderer.RendererState rendererState3 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo1);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint1, (java.awt.Paint) color2, (java.awt.Paint) color3);
        java.awt.Color color5 = java.awt.Color.cyan;
        waterfallBarRenderer4.setBaseOutlinePaint((java.awt.Paint) color5);
        java.awt.Color color7 = java.awt.Color.darkGray;
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color9 = java.awt.Color.darkGray;
        java.awt.Color color10 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer11 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color7, paint8, (java.awt.Paint) color9, (java.awt.Paint) color10);
        waterfallBarRenderer4.setBaseOutlinePaint(paint8);
        waterfallBarRenderer4.setSeriesCreateEntities((int) (byte) 0, (java.lang.Boolean) true);
        waterfallBarRenderer4.setBaseItemLabelsVisible(false, true);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = stackedBarRenderer3D4.getLegendItemURLGenerator();
        java.awt.Paint paint7 = stackedBarRenderer3D4.getSeriesPaint(3);
        boolean boolean8 = stackedBarRenderer3D4.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator13 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D4.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator13, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = null;
        stackedBarRenderer3D4.setSeriesItemLabelGenerator((int) (byte) 10, categoryItemLabelGenerator17, true);
        boolean boolean20 = rangeType0.equals((java.lang.Object) (byte) 10);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = null;
        java.awt.Paint paint1 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        try {
            org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        boolean boolean2 = lineBorder0.equals((java.lang.Object) "Other");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.setValue((double) 60000L, (java.lang.Comparable) 10.0f, (java.lang.Comparable) 2);
        defaultCategoryDataset0.clear();
        java.util.List list6 = defaultCategoryDataset0.getRowKeys();
        java.lang.Object obj7 = defaultCategoryDataset0.clone();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double14 = rectangleInsets13.getRight();
        xYPlot6.setInsets(rectangleInsets13);
        java.lang.Object obj16 = xYPlot6.clone();
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot6.getDataset(3);
        xYPlot6.setDomainCrosshairValue((double) 3, true);
        xYPlot6.clearRangeMarkers(9);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot6.setDomainGridlineStroke(stroke24);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("{0}", font1);
        java.awt.Graphics2D graphics2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = labelBlock2.arrange(graphics2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (byte) 0, (float) 0, (float) (-1));
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double14 = rectangleInsets13.getRight();
        xYPlot6.setInsets(rectangleInsets13);
        boolean boolean16 = xYPlot6.isDomainZoomable();
        java.awt.Paint paint17 = xYPlot6.getOutlinePaint();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.lang.String str0 = org.jfree.chart.labels.IntervalCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str0.equals("({0}, {1}) = {3} - {4}"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        try {
            keyedObjects2D0.removeRow((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 0, (int) '4', (int) (byte) 100);
        org.jfree.chart.block.BorderArrangement borderArrangement4 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) borderArrangement4);
        int int6 = segmentedTimeline3.getSegmentsExcluded();
        java.lang.Class class7 = null;
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date11, timeZone12);
        org.jfree.data.time.DateRange dateRange16 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date17 = dateRange16.getUpperDate();
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange(date11, date17);
        java.lang.Class class19 = null;
        org.jfree.data.time.DateRange dateRange22 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date23 = dateRange22.getUpperDate();
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date23, timeZone24);
        org.jfree.data.time.DateRange dateRange28 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date29 = dateRange28.getUpperDate();
        org.jfree.data.time.DateRange dateRange30 = new org.jfree.data.time.DateRange(date23, date29);
        org.jfree.data.time.DateRange dateRange31 = new org.jfree.data.time.DateRange(date17, date23);
        try {
            boolean boolean32 = segmentedTimeline3.containsDomainValue(date17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date29);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Paint paint2 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        boolean boolean3 = verticalAlignment1.equals((java.lang.Object) 3.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 0L, (double) 3);
        java.lang.Object obj7 = null;
        boolean boolean8 = flowArrangement6.equals(obj7);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        xYPlot6.setBackgroundImageAlignment((int) (byte) -1);
        float float9 = xYPlot6.getForegroundAlpha();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation10 = null;
        try {
            xYPlot6.addAnnotation(xYAnnotation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot0.getDomainAxis((int) (byte) 0);
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = stackedBarRenderer3D11.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedBarRenderer3D11.getSeriesPositiveItemLabelPosition(0);
        stackedBarRenderer3D11.setItemLabelAnchorOffset((double) '#');
        boolean boolean17 = stackedBarRenderer3D11.getAutoPopulateSeriesPaint();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D11, false);
        double double20 = stackedBarRenderer3D11.getXOffset();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 10.0d + "'", double20 == 10.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("Category Plot");
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        try {
            java.awt.image.BufferedImage bufferedImage10 = jFreeChart7.createBufferedImage(0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (4) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = ' ';
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        xYPlot6.setBackgroundImageAlignment((int) (byte) -1);
        float float9 = xYPlot6.getForegroundAlpha();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = xYPlot6.getOrientation();
        java.lang.String str11 = plotOrientation10.toString();
        java.lang.String str12 = plotOrientation10.toString();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PlotOrientation.VERTICAL" + "'", str11.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PlotOrientation.VERTICAL" + "'", str12.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight(2958465);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot0.getRangeMarkers((int) (short) 10, layer4);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        try {
            categoryPlot0.setRenderer((-1), (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection5);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight(2958465);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot0.getRangeMarkers((int) (short) 10, layer4);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape10 = numberAxis9.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis9, valueAxis11, xYItemRenderer12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot13.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace16 = xYPlot13.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot13.setRangeAxisLocation(axisLocation17);
        categoryPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation17, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = null;
        try {
            categoryPlot0.setDomainGridlinePosition(categoryAnchor21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(valueAxis15);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape6 = numberAxis5.getLeftArrow();
        java.awt.Color color7 = java.awt.Color.darkGray;
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color9 = java.awt.Color.darkGray;
        java.awt.Color color10 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer11 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color7, paint8, (java.awt.Paint) color9, (java.awt.Paint) color10);
        java.awt.Paint[] paintArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Color color13 = java.awt.Color.darkGray;
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color15 = java.awt.Color.darkGray;
        java.awt.Color color16 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer17 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color13, paint14, (java.awt.Paint) color15, (java.awt.Paint) color16);
        int int18 = color13.getTransparency();
        java.awt.Color color19 = java.awt.Color.cyan;
        java.awt.Paint[] paintArray20 = new java.awt.Paint[] { color13, color19 };
        java.awt.Paint[] paintArray21 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator26 = stackedBarRenderer3D25.getLegendItemURLGenerator();
        java.awt.Stroke stroke27 = stackedBarRenderer3D25.getBaseStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator32 = stackedBarRenderer3D31.getLegendItemURLGenerator();
        java.awt.Stroke stroke33 = stackedBarRenderer3D31.getBaseStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D37 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator38 = stackedBarRenderer3D37.getLegendItemURLGenerator();
        java.awt.Stroke stroke39 = stackedBarRenderer3D37.getBaseStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D43 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator44 = stackedBarRenderer3D43.getLegendItemURLGenerator();
        java.awt.Stroke stroke45 = stackedBarRenderer3D43.getBaseStroke();
        java.awt.Stroke stroke46 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray47 = new java.awt.Stroke[] { stroke27, stroke33, stroke39, stroke45, stroke46 };
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D51 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator52 = stackedBarRenderer3D51.getLegendItemURLGenerator();
        java.awt.Stroke stroke53 = stackedBarRenderer3D51.getBaseStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D57 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator58 = stackedBarRenderer3D57.getLegendItemURLGenerator();
        java.awt.Stroke stroke59 = stackedBarRenderer3D57.getBaseStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D63 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator64 = stackedBarRenderer3D63.getLegendItemURLGenerator();
        java.awt.Stroke stroke65 = stackedBarRenderer3D63.getBaseStroke();
        java.awt.Stroke stroke66 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D70 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator71 = stackedBarRenderer3D70.getLegendItemURLGenerator();
        java.awt.Stroke stroke72 = stackedBarRenderer3D70.getBaseStroke();
        java.awt.Stroke stroke73 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray74 = new java.awt.Stroke[] { stroke53, stroke59, stroke65, stroke66, stroke72, stroke73 };
        org.jfree.chart.axis.NumberAxis numberAxis76 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape77 = numberAxis76.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis79 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean80 = numberAxis79.isNegativeArrowVisible();
        numberAxis79.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis84 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape85 = numberAxis84.getLeftArrow();
        numberAxis79.setLeftArrow(shape85);
        java.awt.Shape[] shapeArray87 = new java.awt.Shape[] { shape77, shape85 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier88 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray12, paintArray20, paintArray21, strokeArray47, strokeArray74, shapeArray87);
        java.awt.Stroke stroke89 = defaultDrawingSupplier88.getNextStroke();
        java.awt.Color color90 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.LegendItem legendItem91 = new org.jfree.chart.LegendItem("", "hi!", "TextAnchor.CENTER_RIGHT", "hi!", shape6, paint8, stroke89, (java.awt.Paint) color90);
        java.awt.Color color92 = java.awt.Color.black;
        java.awt.Color color93 = color92.brighter();
        java.awt.Paint paint94 = null;
        java.awt.Paint paint95 = null;
        try {
            org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer96 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color90, (java.awt.Paint) color92, paint94, paint95);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'negativeBarPaint' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintArray20);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(strokeArray47);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator64);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator71);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(strokeArray74);
        org.junit.Assert.assertNotNull(shape77);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(shape85);
        org.junit.Assert.assertNotNull(shapeArray87);
        org.junit.Assert.assertNotNull(stroke89);
        org.junit.Assert.assertNotNull(color90);
        org.junit.Assert.assertNotNull(color92);
        org.junit.Assert.assertNotNull(color93);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 12);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean3 = valueMarker1.equals((java.lang.Object) standardCategoryToolTipGenerator2);
        java.text.DateFormat dateFormat4 = standardCategoryToolTipGenerator2.getDateFormat();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(dateFormat4);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double14 = rectangleInsets13.getRight();
        xYPlot6.setInsets(rectangleInsets13);
        java.lang.Object obj16 = xYPlot6.clone();
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot6.getDataset(3);
        xYPlot6.setDomainCrosshairValue((double) 3, true);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) 12);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator24 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean25 = valueMarker23.equals((java.lang.Object) standardCategoryToolTipGenerator24);
        xYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker23);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight(2958465);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = stackedBarRenderer3D8.getLegendItemURLGenerator();
        java.awt.Paint paint11 = stackedBarRenderer3D8.getSeriesPaint(3);
        boolean boolean12 = stackedBarRenderer3D8.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator17 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D8.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator17, true);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("{0}", font22);
        java.awt.geom.Rectangle2D rectangle2D24 = labelBlock23.getBounds();
        stackedBarRenderer3D8.setSeriesShape(5, (java.awt.Shape) rectangle2D24);
        boolean boolean26 = stackedAreaRenderer4.equals((java.lang.Object) rectangle2D24);
        int int27 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        taskSeriesCollection0.validateObject();
        int int3 = taskSeriesCollection0.getRowCount();
        try {
            java.lang.Number number6 = taskSeriesCollection0.getPercentComplete(9, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Paint paint6 = stackedBarRenderer3D3.getSeriesPaint(3);
        boolean boolean7 = stackedBarRenderer3D3.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean10 = numberAxis9.isNegativeArrowVisible();
        numberAxis9.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape15 = numberAxis14.getLeftArrow();
        numberAxis9.setLeftArrow(shape15);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean19 = numberAxis18.isNegativeArrowVisible();
        numberAxis18.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape24 = numberAxis23.getLeftArrow();
        numberAxis18.setLeftArrow(shape24);
        numberAxis9.setDownArrow(shape24);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset29 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset29);
        java.text.DateFormat dateFormat33 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit34 = new org.jfree.chart.axis.DateTickUnit(3, (int) 'a', dateFormat33);
        java.lang.String str35 = dateTickUnit34.toString();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity37 = new org.jfree.chart.entity.CategoryItemEntity(shape24, "", "DateTickUnit[HOUR, 97]", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset29, (java.lang.Comparable) dateTickUnit34, (java.lang.Comparable) (short) 1);
        stackedBarRenderer3D3.setBaseShape(shape24);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "DateTickUnit[HOUR, 97]" + "'", str35.equals("DateTickUnit[HOUR, 97]"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Paint paint6 = stackedBarRenderer3D3.getSeriesPaint(3);
        boolean boolean7 = stackedBarRenderer3D3.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = null;
        stackedBarRenderer3D3.setLegendItemURLGenerator(categorySeriesLabelGenerator8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint12 = categoryPlot11.getRangeGridlinePaint();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean15 = numberAxis14.isNegativeArrowVisible();
        org.jfree.chart.plot.Marker marker16 = null;
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("{0}", font18);
        java.awt.geom.Rectangle2D rectangle2D20 = labelBlock19.getBounds();
        stackedBarRenderer3D3.drawRangeMarker(graphics2D10, categoryPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis14, marker16, rectangle2D20);
        double double22 = stackedBarRenderer3D3.getXOffset();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape9 = numberAxis8.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis8, valueAxis10, xYItemRenderer11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot12.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot12.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setDomainAxisLocation(10, axisLocation18, false);
        categoryPlot0.setDomainAxisLocation(12, axisLocation18);
        java.awt.Stroke stroke22 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace23);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D26 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.awt.Paint paint27 = categoryAxis3D26.getLabelPaint();
        java.awt.Color color28 = java.awt.Color.pink;
        categoryAxis3D26.setAxisLinePaint((java.awt.Paint) color28);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer33 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D37 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator38 = stackedBarRenderer3D37.getLegendItemURLGenerator();
        java.awt.Paint paint40 = stackedBarRenderer3D37.getSeriesPaint(3);
        boolean boolean41 = stackedBarRenderer3D37.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator46 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D37.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator46, true);
        java.awt.Font font51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock52 = new org.jfree.chart.block.LabelBlock("{0}", font51);
        java.awt.geom.Rectangle2D rectangle2D53 = labelBlock52.getBounds();
        stackedBarRenderer3D37.setSeriesShape(5, (java.awt.Shape) rectangle2D53);
        boolean boolean55 = stackedAreaRenderer33.equals((java.lang.Object) rectangle2D53);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean57 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge56);
        double double58 = categoryAxis3D26.getCategoryStart(10, 3, rectangle2D53, rectangleEdge56);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D60 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int61 = categoryAxis3D60.getCategoryLabelPositionOffset();
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = null;
        double double66 = categoryAxis3D60.getCategoryEnd(2958465, 100, rectangle2D64, rectangleEdge65);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D68 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int69 = categoryAxis3D68.getCategoryLabelPositionOffset();
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = null;
        double double74 = categoryAxis3D68.getCategoryEnd(2958465, 100, rectangle2D72, rectangleEdge73);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions75 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        categoryAxis3D68.setCategoryLabelPositions(categoryLabelPositions75);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D78 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.awt.Paint paint79 = categoryAxis3D78.getLabelPaint();
        java.awt.Paint paint80 = categoryAxis3D78.getLabelPaint();
        categoryAxis3D78.setLowerMargin(0.2d);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray83 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis3D26, categoryAxis3D60, categoryAxis3D68, categoryAxis3D78 };
        categoryPlot0.setDomainAxes(categoryAxisArray83);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator38);
        org.junit.Assert.assertNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 4 + "'", int61 == 4);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions75);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertNotNull(paint80);
        org.junit.Assert.assertNotNull(categoryAxisArray83);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleEdge.BOTTOM", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        xYPlot6.axisChanged(axisChangeEvent9);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray11 = null;
        try {
            xYPlot6.setRangeAxes(valueAxisArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot6.getRangeAxisEdge((int) 'a');
        org.jfree.chart.plot.Plot plot11 = xYPlot6.getParent();
        java.awt.Stroke stroke12 = xYPlot6.getDomainZeroBaselineStroke();
        xYPlot6.setNoDataMessage("ThreadContext");
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = xYPlot6.getDomainMarkers(layer15);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(collection16);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 0, (int) '4', (int) (byte) 100);
        org.jfree.chart.block.BorderArrangement borderArrangement4 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) borderArrangement4);
        java.lang.Object obj6 = null;
        boolean boolean7 = segmentedTimeline3.equals(obj6);
        java.util.Date date9 = segmentedTimeline3.getDate(1L);
        long long11 = segmentedTimeline3.getTimeFromLong((long) 4);
        long long12 = segmentedTimeline3.getSegmentsGroupSize();
        try {
            long long14 = segmentedTimeline3.toTimelineValue(23640L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 4L + "'", long11 == 4L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.width = 10L;
        java.lang.Object obj3 = size2D0.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double14 = rectangleInsets13.getRight();
        xYPlot6.setInsets(rectangleInsets13);
        org.jfree.chart.LegendItemCollection legendItemCollection16 = xYPlot6.getFixedLegendItems();
        java.awt.Paint paint17 = xYPlot6.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(legendItemCollection16);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class2 = null;
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date6 = dateRange5.getUpperDate();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date6, timeZone7);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date12 = dateRange11.getUpperDate();
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange(date6, date12);
        org.jfree.data.general.PieDataset pieDataset14 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, (java.lang.Comparable) date6);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date6);
        java.util.Date date16 = month15.getEnd();
        java.lang.Comparable[] comparableArray19 = new java.lang.Comparable[] { month15, true, 12 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) 0, (short) 100, 15, (byte) 100, (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) 0, (short) 100, 15, (byte) 100, (-1.0d) };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { (byte) 0, (short) 100, 15, (byte) 100, (-1.0d) };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { (byte) 0, (short) 100, 15, (byte) 100, (-1.0d) };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray25, numberArray31, numberArray37, numberArray43 };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { (byte) 10, (byte) 0, 4, 100.0f };
        java.lang.Number[][] numberArray50 = new java.lang.Number[][] { numberArray49 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset51 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[]) strArray0, comparableArray19, numberArray44, numberArray50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(pieDataset14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(comparableArray19);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray50);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("Category Plot", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        numberAxis1.resizeRange((double) 100L);
        numberAxis1.setTickMarksVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean11 = numberAxis10.isNegativeArrowVisible();
        numberAxis10.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape16 = numberAxis15.getLeftArrow();
        numberAxis10.setLeftArrow(shape16);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape16, 0.0d, (double) (byte) -1);
        numberAxis1.setDownArrow(shape16);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        numberAxis1.setLabelFont(font22);
        numberAxis1.setAutoRange(true);
        numberAxis1.setFixedAutoRange((double) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(font22);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape7 = numberAxis6.getLeftArrow();
        numberAxis1.setLeftArrow(shape7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean11 = numberAxis10.isNegativeArrowVisible();
        numberAxis10.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape16 = numberAxis15.getLeftArrow();
        numberAxis10.setLeftArrow(shape16);
        numberAxis1.setDownArrow(shape16);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity21 = new org.jfree.chart.entity.TickLabelEntity(shape16, "ThreadContext", "java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint23 = textTitle22.getPaint();
        java.awt.Paint paint24 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        textTitle22.setPaint(paint24);
        boolean boolean26 = tickLabelEntity21.equals((java.lang.Object) textTitle22);
        java.lang.String str27 = tickLabelEntity21.getURLText();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "java.awt.Color[r=64,g=64,b=64]" + "'", str27.equals("java.awt.Color[r=64,g=64,b=64]"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) (byte) -1);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            rectangleInsets0.trim(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.0d) + "'", double2 == (-5.0d));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Stroke stroke5 = stackedBarRenderer3D3.getBaseStroke();
        boolean boolean6 = stackedBarRenderer3D3.getBaseSeriesVisible();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("RectangleEdge.BOTTOM");
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = stackedBarRenderer3D5.getLegendItemURLGenerator();
        java.awt.Paint paint8 = stackedBarRenderer3D5.getSeriesPaint(3);
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = blockContainer9.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        blockContainer9.setPadding(rectangleInsets11);
        double double14 = rectangleInsets11.calculateTopOutset((double) 100);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("{0}", font18);
        java.awt.geom.Rectangle2D rectangle2D20 = labelBlock19.getBounds();
        plotRenderingInfo16.setPlotArea(rectangle2D20);
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets11.createOutsetRectangle(rectangle2D20, false, false);
        stackedBarRenderer3D5.setBaseShape((java.awt.Shape) rectangle2D24);
        try {
            blockContainer0.draw(graphics2D1, rectangle2D24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D24);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.getCeilingTickUnit((double) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getRowKeys();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int4 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) 10.0d);
        try {
            java.lang.Comparable comparable6 = defaultStatisticalCategoryDataset0.getColumnKey((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 10);
        java.lang.Object obj2 = chartChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (short) 10 + "'", obj2.equals((short) 10));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape9 = numberAxis8.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis8, valueAxis10, xYItemRenderer11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot12.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot12.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setDomainAxisLocation(10, axisLocation18, false);
        categoryPlot0.setDomainAxisLocation(12, axisLocation18);
        java.awt.Stroke stroke22 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace23);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection26 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection26);
        taskSeriesCollection26.validateObject();
        categoryPlot0.setDataset(12, (org.jfree.data.category.CategoryDataset) taskSeriesCollection26);
        try {
            java.lang.Number number32 = taskSeriesCollection26.getValue((java.lang.Comparable) (short) 1, (java.lang.Comparable) "DateTickUnit[HOUR, 97]");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean6 = numberAxis5.isNegativeArrowVisible();
        numberAxis5.resizeRange((double) 100);
        numberAxis5.resizeRange((double) 100L);
        numberAxis5.setTickMarksVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean15 = numberAxis14.isNegativeArrowVisible();
        numberAxis14.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape20 = numberAxis19.getLeftArrow();
        numberAxis14.setLeftArrow(shape20);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape20, 0.0d, (double) (byte) -1);
        numberAxis5.setDownArrow(shape20);
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint27 = null;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("{0}", "{0}", "ThreadContext", "ThreadContext", shape20, stroke26, paint27);
        java.lang.String str29 = legendItem28.getLabel();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer30 = legendItem28.getFillPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer31 = legendItem28.getFillPaintTransformer();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "{0}" + "'", str29.equals("{0}"));
        org.junit.Assert.assertNotNull(gradientPaintTransformer30);
        org.junit.Assert.assertNotNull(gradientPaintTransformer31);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        jFreeChart7.setTextAntiAlias(false);
        boolean boolean10 = jFreeChart7.getAntiAlias();
        org.jfree.chart.title.Title title12 = jFreeChart7.getSubtitle(0);
        java.awt.Stroke stroke13 = jFreeChart7.getBorderStroke();
        java.awt.RenderingHints renderingHints14 = null;
        try {
            jFreeChart7.setRenderingHints(renderingHints14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(title12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 0, (int) '4', (int) (byte) 100);
        org.jfree.chart.block.BorderArrangement borderArrangement4 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) borderArrangement4);
        java.lang.Object obj6 = null;
        boolean boolean7 = segmentedTimeline3.equals(obj6);
        java.util.Date date9 = segmentedTimeline3.getDate(1L);
        long long11 = segmentedTimeline3.getTimeFromLong((long) 4);
        try {
            segmentedTimeline3.addBaseTimelineException((long) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 4L + "'", long11 == 4L);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        java.awt.Paint paint5 = blockBorder4.getPaint();
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace9 = xYPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation(axisLocation10);
        xYPlot6.setRangeCrosshairValue(1.0d);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot6.setNoDataMessageFont(font14);
        org.jfree.chart.LegendItemCollection legendItemCollection16 = null;
        xYPlot6.setFixedLegendItems(legendItemCollection16);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Paint paint6 = stackedBarRenderer3D3.getSeriesPaint(3);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean13 = numberAxis12.isNegativeArrowVisible();
        numberAxis12.resizeRange((double) 100);
        numberAxis12.resizeRange((double) 100L);
        numberAxis12.setTickMarksVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean22 = numberAxis21.isNegativeArrowVisible();
        numberAxis21.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape27 = numberAxis26.getLeftArrow();
        numberAxis21.setLeftArrow(shape27);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape27, 0.0d, (double) (byte) -1);
        numberAxis12.setDownArrow(shape27);
        java.awt.Stroke stroke33 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint34 = null;
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("{0}", "{0}", "ThreadContext", "ThreadContext", shape27, stroke33, paint34);
        java.lang.String str36 = legendItem35.getLabel();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer37 = legendItem35.getFillPaintTransformer();
        stackedBarRenderer3D3.setGradientPaintTransformer(gradientPaintTransformer37);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "{0}" + "'", str36.equals("{0}"));
        org.junit.Assert.assertNotNull(gradientPaintTransformer37);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        try {
            java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getQ1Value((int) (byte) 0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        numberAxis1.resizeRange((double) 100L);
        org.jfree.chart.plot.Plot plot7 = numberAxis1.getPlot();
        java.awt.Color color8 = java.awt.Color.darkGray;
        java.awt.Paint paint9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color10 = java.awt.Color.darkGray;
        java.awt.Color color11 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer12 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color8, paint9, (java.awt.Paint) color10, (java.awt.Paint) color11);
        java.awt.Paint paint13 = waterfallBarRenderer12.getLastBarPaint();
        numberAxis1.setAxisLinePaint(paint13);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str17 = numberTickUnit15.valueToString(0.0d);
        numberAxis1.setTickUnit(numberTickUnit15);
        org.jfree.data.DefaultKeyedValue defaultKeyedValue20 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) numberTickUnit15, (java.lang.Number) 8.0d);
        boolean boolean22 = defaultKeyedValue20.equals((java.lang.Object) (-5.0d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(numberTickUnit15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(8.0d, 0.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 100L);
        try {
            keyedObjects2D0.removeRow((java.lang.Comparable) 0.05d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean6 = numberAxis5.isNegativeArrowVisible();
        numberAxis5.resizeRange((double) 100);
        numberAxis5.resizeRange((double) 100L);
        numberAxis5.setTickMarksVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean15 = numberAxis14.isNegativeArrowVisible();
        numberAxis14.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape20 = numberAxis19.getLeftArrow();
        numberAxis14.setLeftArrow(shape20);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape20, 0.0d, (double) (byte) -1);
        numberAxis5.setDownArrow(shape20);
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint27 = null;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("{0}", "{0}", "ThreadContext", "ThreadContext", shape20, stroke26, paint27);
        java.lang.String str29 = legendItem28.getLabel();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer30 = legendItem28.getFillPaintTransformer();
        java.lang.Comparable comparable31 = legendItem28.getSeriesKey();
        java.awt.Paint paint32 = legendItem28.getLinePaint();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "{0}" + "'", str29.equals("{0}"));
        org.junit.Assert.assertNotNull(gradientPaintTransformer30);
        org.junit.Assert.assertNull(comparable31);
        org.junit.Assert.assertNull(paint32);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(3, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection2);
        multiplePiePlot1.setDataset((org.jfree.data.category.CategoryDataset) taskSeriesCollection2);
        try {
            java.lang.Number number7 = taskSeriesCollection2.getStartValue((-1), 15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("ThreadContext");
        boolean boolean2 = numberAxis3D1.isPositiveArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.lang.Class class0 = null;
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date4 = dateRange3.getUpperDate();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date10 = dateRange9.getUpperDate();
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange(date4, date10);
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange11);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange11);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.lang.Class class0 = null;
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date4 = dateRange3.getUpperDate();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date10 = dateRange9.getUpperDate();
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange(date4, date10);
        java.lang.Class class12 = null;
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date16 = dateRange15.getUpperDate();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date16, timeZone17);
        org.jfree.data.time.DateRange dateRange21 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date22 = dateRange21.getUpperDate();
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange(date16, date22);
        org.jfree.data.time.DateRange dateRange24 = new org.jfree.data.time.DateRange(date10, date16);
        java.lang.Class class25 = null;
        org.jfree.data.time.DateRange dateRange28 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date29 = dateRange28.getUpperDate();
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date29, timeZone30);
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date35 = dateRange34.getUpperDate();
        org.jfree.data.time.DateRange dateRange36 = new org.jfree.data.time.DateRange(date29, date35);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange24, (org.jfree.data.Range) dateRange36);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date35);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getPaint();
        java.awt.Color color2 = java.awt.Color.cyan;
        textTitle0.setBackgroundPaint((java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Color color7 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer8 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color4, paint5, (java.awt.Paint) color6, (java.awt.Paint) color7);
        stackedBarRenderer3D3.setBasePaint(paint5, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = stackedBarRenderer3D3.getItemLabelGenerator((int) (short) 0, 3);
        stackedBarRenderer3D3.setBase(8.0d);
        stackedBarRenderer3D3.setBase((-5.0d));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Color color7 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer8 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color4, paint5, (java.awt.Paint) color6, (java.awt.Paint) color7);
        stackedBarRenderer3D3.setBasePaint(paint5, false);
        boolean boolean11 = stackedBarRenderer3D3.getAutoPopulateSeriesPaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = null;
        stackedBarRenderer3D3.setBaseItemLabelGenerator(categoryItemLabelGenerator12);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean2 = textBlockAnchor0.equals((java.lang.Object) paintArray1);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.CENTER" + "'", str1.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        jFreeChart7.setTextAntiAlias(false);
        boolean boolean10 = jFreeChart7.getAntiAlias();
        org.jfree.chart.title.Title title12 = jFreeChart7.getSubtitle(0);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart7.getLegend(1);
        jFreeChart7.setBorderVisible(true);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(title12);
        org.junit.Assert.assertNull(legendTitle14);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint1, (java.awt.Paint) color2, (java.awt.Paint) color3);
        java.awt.Paint paint5 = waterfallBarRenderer4.getLastBarPaint();
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color8 = java.awt.Color.darkGray;
        java.awt.Color color9 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer10 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color6, paint7, (java.awt.Paint) color8, (java.awt.Paint) color9);
        java.awt.Color color11 = java.awt.Color.cyan;
        waterfallBarRenderer10.setBaseOutlinePaint((java.awt.Paint) color11);
        java.awt.Color color13 = java.awt.Color.darkGray;
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color15 = java.awt.Color.darkGray;
        java.awt.Color color16 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer17 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color13, paint14, (java.awt.Paint) color15, (java.awt.Paint) color16);
        waterfallBarRenderer10.setBaseOutlinePaint(paint14);
        java.awt.Color color19 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.AffineTransform affineTransform23 = null;
        java.awt.RenderingHints renderingHints24 = null;
        java.awt.PaintContext paintContext25 = color19.createContext(colorModel20, rectangle21, rectangle2D22, affineTransform23, renderingHints24);
        int int26 = color19.getTransparency();
        java.awt.Color color27 = color19.darker();
        java.awt.Color color28 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel29 = null;
        java.awt.Rectangle rectangle30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.geom.AffineTransform affineTransform32 = null;
        java.awt.RenderingHints renderingHints33 = null;
        java.awt.PaintContext paintContext34 = color28.createContext(colorModel29, rectangle30, rectangle2D31, affineTransform32, renderingHints33);
        int int35 = color28.getTransparency();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer36 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint5, paint14, (java.awt.Paint) color19, (java.awt.Paint) color28);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier37 = waterfallBarRenderer36.getDrawingSupplier();
        waterfallBarRenderer36.setSeriesVisibleInLegend((int) (short) 1, (java.lang.Boolean) false, true);
        java.awt.Color color43 = org.jfree.chart.ChartColor.DARK_YELLOW;
        waterfallBarRenderer36.setSeriesItemLabelPaint(2958465, (java.awt.Paint) color43, true);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintContext25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paintContext34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNull(drawingSupplier37);
        org.junit.Assert.assertNotNull(color43);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = stackedBarRenderer3D5.getLegendItemURLGenerator();
        java.awt.Paint paint8 = stackedBarRenderer3D5.getSeriesPaint(3);
        boolean boolean9 = stackedBarRenderer3D5.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator14 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D5.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator14, true);
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("{0}", font19);
        java.awt.geom.Rectangle2D rectangle2D21 = labelBlock20.getBounds();
        stackedBarRenderer3D5.setSeriesShape(5, (java.awt.Shape) rectangle2D21);
        boolean boolean23 = stackedAreaRenderer1.equals((java.lang.Object) rectangle2D21);
        int int24 = stackedAreaRenderer1.getRowCount();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean2 = borderArrangement0.equals((java.lang.Object) (-1.0f));
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("{0}", font4);
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.block.BorderArrangement borderArrangement7 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean9 = borderArrangement7.equals((java.lang.Object) (-1.0f));
        try {
            borderArrangement0.add((org.jfree.chart.block.Block) labelBlock5, (java.lang.Object) borderArrangement7);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.block.BorderArrangement cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = numberAxis1.getLeftArrow();
        float float3 = numberAxis1.getTickMarkInsideLength();
        java.lang.String str4 = numberAxis1.getLabel();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        boolean boolean2 = defaultDrawingSupplier0.equals((java.lang.Object) "PlotOrientation.VERTICAL");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        org.jfree.data.Range range5 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange2, (double) (byte) -1, true);
        double double6 = dateRange2.getLowerBound();
        java.lang.String str7 = dateRange2.toString();
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 3:59:59 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 3:59:59 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getValue((java.lang.Comparable) 23640L, (java.lang.Comparable) (-1L));
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent1.setType(chartChangeEventType2);
        org.jfree.chart.JFreeChart jFreeChart4 = chartChangeEvent1.getChart();
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNull(jFreeChart4);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = stackedBarRenderer3D7.getLegendItemURLGenerator();
        java.awt.Stroke stroke9 = stackedBarRenderer3D7.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = stackedBarRenderer3D7.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor12 = itemLabelPosition11.getItemLabelAnchor();
        stackedBarRenderer3D3.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(itemLabelAnchor12);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer3D0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertNull(itemLabelPosition1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        boolean boolean5 = stackedBarRenderer3D3.getBaseSeriesVisible();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.awt.Color color0 = java.awt.Color.pink;
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.AffineTransform affineTransform5 = null;
        java.awt.RenderingHints renderingHints6 = null;
        java.awt.PaintContext paintContext7 = color1.createContext(colorModel2, rectangle3, rectangle2D4, affineTransform5, renderingHints6);
        int int8 = color1.getTransparency();
        java.awt.Color color9 = color1.darker();
        java.awt.Color color10 = java.awt.Color.black;
        float[] floatArray17 = new float[] { (byte) -1, 10, (short) 0, (byte) 0, 2958465, (short) 1 };
        float[] floatArray18 = color10.getComponents(floatArray17);
        float[] floatArray19 = color1.getColorComponents(floatArray18);
        float[] floatArray20 = color0.getColorComponents(floatArray18);
        float[] floatArray21 = null;
        float[] floatArray22 = color0.getRGBColorComponents(floatArray21);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintContext7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        xYPlot6.setBackgroundImageAlignment((int) (byte) -1);
        float float9 = xYPlot6.getForegroundAlpha();
        int int10 = xYPlot6.getWeight();
        boolean boolean11 = xYPlot6.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double14 = rectangleInsets13.getRight();
        xYPlot6.setInsets(rectangleInsets13);
        java.lang.Object obj16 = xYPlot6.clone();
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot6.getDataset(3);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation19 = null;
        try {
            xYPlot6.addAnnotation(xYAnnotation19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNull(xYDataset18);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        jFreeChart7.setTextAntiAlias(false);
        boolean boolean10 = jFreeChart7.getAntiAlias();
        boolean boolean11 = jFreeChart7.isNotify();
        int int12 = jFreeChart7.getSubtitleCount();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 12);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean3 = valueMarker1.equals((java.lang.Object) standardCategoryToolTipGenerator2);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean6 = numberAxis5.isNegativeArrowVisible();
        numberAxis5.resizeRange((double) 100);
        numberAxis5.resizeRange((double) 100L);
        org.jfree.chart.plot.Plot plot11 = numberAxis5.getPlot();
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Color color15 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer16 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color12, paint13, (java.awt.Paint) color14, (java.awt.Paint) color15);
        java.awt.Paint paint17 = waterfallBarRenderer16.getLastBarPaint();
        numberAxis5.setAxisLinePaint(paint17);
        valueMarker1.setLabelPaint(paint17);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = rectangleConstraint0.toUnconstrainedWidth();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = rectangleConstraint1.getHeightConstraintType();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertNotNull(lengthConstraintType2);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = null;
        numberAxis1.setStandardTickUnits(tickUnitSource2);
        org.jfree.data.RangeType rangeType4 = numberAxis1.getRangeType();
        org.junit.Assert.assertNotNull(rangeType4);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.awt.Color color2 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        int int9 = color2.getTransparency();
        java.awt.Color color10 = color2.darker();
        java.awt.Color color11 = java.awt.Color.black;
        float[] floatArray18 = new float[] { (byte) -1, 10, (short) 0, (byte) 0, 2958465, (short) 1 };
        float[] floatArray19 = color11.getComponents(floatArray18);
        float[] floatArray20 = color2.getColorComponents(floatArray19);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot21.getDomainAxisLocation();
        java.awt.Color color24 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot21.setRangeGridlinePaint((java.awt.Paint) color24);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = categoryPlot21.getDomainAxis((int) (byte) 0);
        categoryPlot21.configureDomainAxes();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator33 = stackedBarRenderer3D32.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = stackedBarRenderer3D32.getSeriesPositiveItemLabelPosition(0);
        stackedBarRenderer3D32.setItemLabelAnchorOffset((double) '#');
        boolean boolean38 = stackedBarRenderer3D32.getAutoPopulateSeriesPaint();
        categoryPlot21.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D32, false);
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        categoryPlot21.setRangeAxis(0, valueAxis42);
        java.awt.Stroke stroke44 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        categoryPlot21.setRangeGridlineStroke(stroke44);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D49 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        stackedBarRenderer3D49.setBaseSeriesVisibleInLegend(false);
        stackedBarRenderer3D49.setSeriesVisible((int) ' ', (java.lang.Boolean) true, false);
        boolean boolean56 = stackedBarRenderer3D49.isDrawBarOutline();
        java.awt.Color color58 = java.awt.Color.darkGray;
        java.awt.Paint paint59 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color60 = java.awt.Color.darkGray;
        java.awt.Color color61 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer62 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color58, paint59, (java.awt.Paint) color60, (java.awt.Paint) color61);
        stackedBarRenderer3D49.setSeriesFillPaint((int) (short) 100, (java.awt.Paint) color61);
        org.jfree.data.xy.XYDataset xYDataset64 = null;
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape67 = numberAxis66.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis68 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer69 = null;
        org.jfree.chart.plot.XYPlot xYPlot70 = new org.jfree.chart.plot.XYPlot(xYDataset64, (org.jfree.chart.axis.ValueAxis) numberAxis66, valueAxis68, xYItemRenderer69);
        xYPlot70.setBackgroundImageAlignment((int) (byte) -1);
        float float73 = xYPlot70.getForegroundAlpha();
        java.awt.Stroke stroke74 = xYPlot70.getRangeGridlineStroke();
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker76 = new org.jfree.chart.plot.IntervalMarker((double) (-1.0f), (double) (byte) 1, (java.awt.Paint) color2, stroke44, (java.awt.Paint) color61, stroke74, (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(categoryAxis27);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator33);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(shape67);
        org.junit.Assert.assertTrue("'" + float73 + "' != '" + 1.0f + "'", float73 == 1.0f);
        org.junit.Assert.assertNotNull(stroke74);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = 97;
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double14 = rectangleInsets13.getRight();
        xYPlot6.setInsets(rectangleInsets13);
        java.awt.Color color16 = java.awt.Color.YELLOW;
        xYPlot6.setDomainTickBandPaint((java.awt.Paint) color16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        xYPlot6.removeChangeListener(plotChangeListener18);
        boolean boolean20 = xYPlot6.isDomainCrosshairVisible();
        xYPlot6.setWeight(10);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Stroke stroke5 = stackedBarRenderer3D3.getBaseStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = stackedBarRenderer3D9.getLegendItemURLGenerator();
        java.awt.Paint paint12 = stackedBarRenderer3D9.getSeriesPaint(3);
        boolean boolean13 = stackedBarRenderer3D9.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator18 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D9.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator18, true);
        stackedBarRenderer3D3.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator18, false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot0.getDomainAxis((int) (byte) 0);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker7, layer8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(categoryAxis6);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection2);
        multiplePiePlot1.setDataset((org.jfree.data.category.CategoryDataset) taskSeriesCollection2);
        org.jfree.data.gantt.TaskSeries taskSeries5 = null;
        try {
            taskSeriesCollection2.remove(taskSeries5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.lang.String str4 = textAnchor3.toString();
        org.jfree.chart.axis.CategoryTick categoryTick6 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) (short) 1, textBlock1, textBlockAnchor2, textAnchor3, 6.0d);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = categoryTick6.getLabelAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = categoryTick6.getLabelAnchor();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str4.equals("TextAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNull(textBlockAnchor7);
        org.junit.Assert.assertNull(textBlockAnchor8);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("", "", "{0}", "java.awt.Color[r=64,g=64,b=64]");
        java.lang.String str5 = library4.getVersion();
        boolean boolean7 = library4.equals((java.lang.Object) "Other");
        java.lang.String str8 = library4.getInfo();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=64,g=64,b=64]" + "'", str8.equals("java.awt.Color[r=64,g=64,b=64]"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        boolean boolean6 = numberAxis1.equals((java.lang.Object) 12);
        double double7 = numberAxis1.getLowerBound();
        java.text.NumberFormat numberFormat8 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape12 = numberAxis11.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis11, valueAxis13, xYItemRenderer14);
        xYPlot15.setBackgroundImageAlignment((int) (byte) -1);
        float float18 = xYPlot15.getForegroundAlpha();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator23 = stackedBarRenderer3D22.getLegendItemURLGenerator();
        java.awt.Stroke stroke24 = stackedBarRenderer3D22.getBaseStroke();
        xYPlot15.setOutlineStroke(stroke24);
        numberAxis1.setAxisLineStroke(stroke24);
        boolean boolean27 = numberAxis1.getAutoRangeIncludesZero();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-49.5d) + "'", double7 == (-49.5d));
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        xYPlot6.setBackgroundImageAlignment((int) (byte) -1);
        float float9 = xYPlot6.getForegroundAlpha();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = xYPlot6.getOrientation();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = xYPlot6.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight(2958465);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot0.getRangeMarkers((int) (short) 10, layer4);
        java.awt.Paint paint6 = categoryPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.general.DatasetGroup datasetGroup2 = new org.jfree.data.general.DatasetGroup();
        taskSeriesCollection0.setGroup(datasetGroup2);
        java.lang.Object obj4 = datasetGroup2.clone();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) 'a');
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder(1.0d, 1.0d, (double) 2958465, 0.0d);
        boolean boolean8 = multiplePiePlot0.equals((java.lang.Object) 1.0d);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) 3.0d);
        org.jfree.chart.util.TableOrder tableOrder11 = multiplePiePlot0.getDataExtractOrder();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(tableOrder11);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        java.awt.Color color3 = java.awt.Color.pink;
        categoryAxis3D1.setAxisLinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = null;
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("{0}", font9);
        java.awt.geom.Rectangle2D rectangle2D11 = labelBlock10.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D11, rectangleEdge12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        try {
            double double15 = categoryAxis3D1.getCategoryJava2DCoordinate(categoryAnchor5, (int) (byte) 100, 2958465, rectangle2D11, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint1, (java.awt.Paint) color2, (java.awt.Paint) color3);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        waterfallBarRenderer4.setSeriesItemLabelPaint((int) (byte) 100, paint6, false);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean12 = numberAxis11.isNegativeArrowVisible();
        numberAxis11.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape17 = numberAxis16.getLeftArrow();
        numberAxis11.setLeftArrow(shape17);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape17, 0.0d, (double) (byte) -1);
        waterfallBarRenderer4.setSeriesShape((int) ' ', shape17);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(5);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        taskSeriesCollection0.validateObject();
        java.util.List list3 = taskSeriesCollection0.getColumnKeys();
        org.jfree.data.gantt.TaskSeries taskSeries4 = null;
        try {
            taskSeriesCollection0.remove(taskSeries4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class1 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date5, date11);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) date5);
        java.lang.Comparable comparable14 = null;
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset13, comparable14, 100.0d, (int) '#');
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset13);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        java.awt.Stroke stroke21 = ringPlot19.getSectionOutlineStroke((java.lang.Comparable) 12);
        java.lang.Object obj22 = ringPlot19.clone();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator23 = null;
        ringPlot19.setLabelGenerator(pieSectionLabelGenerator23);
        ringPlot19.setLabelLinkMargin((double) (byte) 100);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator27 = null;
        try {
            ringPlot19.setLegendLabelGenerator(pieSectionLabelGenerator27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Paint paint6 = stackedBarRenderer3D3.getSeriesPaint(3);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape10 = numberAxis9.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis9, valueAxis11, xYItemRenderer12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot13.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace16 = xYPlot13.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot13.setRangeAxisLocation(axisLocation17);
        xYPlot13.setRangeCrosshairValue(1.0d);
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot13.setNoDataMessageFont(font21);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape26 = numberAxis25.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis25, valueAxis27, xYItemRenderer28);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot29);
        org.jfree.chart.block.BlockBorder blockBorder35 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = blockBorder35.getInsets();
        double double37 = rectangleInsets36.getRight();
        xYPlot29.setInsets(rectangleInsets36);
        java.awt.Color color39 = java.awt.Color.YELLOW;
        xYPlot29.setDomainTickBandPaint((java.awt.Paint) color39);
        xYPlot13.setDomainGridlinePaint((java.awt.Paint) color39);
        java.awt.Color color42 = java.awt.Color.black;
        float[] floatArray49 = new float[] { (byte) -1, 10, (short) 0, (byte) 0, 2958465, (short) 1 };
        float[] floatArray50 = color42.getComponents(floatArray49);
        float[] floatArray51 = color39.getRGBColorComponents(floatArray50);
        stackedBarRenderer3D3.setBasePaint((java.awt.Paint) color39);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(valueAxis15);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertNotNull(floatArray51);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = stackedBarRenderer3D4.getLegendItemURLGenerator();
        java.awt.Paint paint7 = stackedBarRenderer3D4.getSeriesPaint(3);
        boolean boolean8 = stackedBarRenderer3D4.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = null;
        stackedBarRenderer3D4.setLegendItemURLGenerator(categorySeriesLabelGenerator9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint13 = categoryPlot12.getRangeGridlinePaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean16 = numberAxis15.isNegativeArrowVisible();
        org.jfree.chart.plot.Marker marker17 = null;
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("{0}", font19);
        java.awt.geom.Rectangle2D rectangle2D21 = labelBlock20.getBounds();
        stackedBarRenderer3D4.drawRangeMarker(graphics2D11, categoryPlot12, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker17, rectangle2D21);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator23 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.text.NumberFormat numberFormat24 = standardCategoryToolTipGenerator23.getNumberFormat();
        java.text.NumberFormat numberFormat25 = standardCategoryToolTipGenerator23.getNumberFormat();
        numberAxis15.setNumberFormatOverride(numberFormat25);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit27 = new org.jfree.chart.axis.NumberTickUnit((double) (-1), numberFormat25);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(numberFormat24);
        org.junit.Assert.assertNotNull(numberFormat25);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        double double5 = stackedBarRenderer3D4.getBase();
        java.lang.Class<?> wildcardClass6 = stackedBarRenderer3D4.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        java.io.InputStream inputStream8 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Preceding", class7);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNull(inputStream8);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 0, (int) '4', (int) (byte) 100);
        org.jfree.chart.block.BorderArrangement borderArrangement4 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) borderArrangement4);
        java.lang.Class class6 = null;
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date10 = dateRange9.getUpperDate();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date10, timeZone11);
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date16 = dateRange15.getUpperDate();
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange(date10, date16);
        try {
            long long18 = segmentedTimeline3.toTimelineValue(date16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        jFreeChart7.setTextAntiAlias(false);
        boolean boolean10 = jFreeChart7.getAntiAlias();
        boolean boolean11 = jFreeChart7.isNotify();
        jFreeChart7.setBorderVisible(false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        try {
            jFreeChart7.plotChanged(plotChangeEvent14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace9 = xYPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation(axisLocation10);
        xYPlot6.setRangeCrosshairValue(1.0d);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot6.setNoDataMessageFont(font14);
        xYPlot6.setRangeCrosshairValue((double) (-1), false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 0, (int) '4', (int) (byte) 100);
        org.jfree.chart.block.BorderArrangement borderArrangement4 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) borderArrangement4);
        java.lang.Object obj6 = null;
        boolean boolean7 = segmentedTimeline3.equals(obj6);
        java.util.Date date9 = segmentedTimeline3.getDate(1L);
        org.jfree.data.KeyedObjects2D keyedObjects2D10 = new org.jfree.data.KeyedObjects2D();
        java.lang.Class class12 = null;
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date16 = dateRange15.getUpperDate();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date16, timeZone17);
        org.jfree.data.time.DateRange dateRange21 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date22 = dateRange21.getUpperDate();
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange(date16, date22);
        keyedObjects2D10.removeObject((java.lang.Comparable) "org.jfree.data.time.TimePeriodFormatException: ", (java.lang.Comparable) date16);
        try {
            boolean boolean25 = segmentedTimeline3.containsDomainValue(date16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.setAutoTickUnitSelection(false, false);
        numberAxis1.setAutoRange(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight(2958465);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot0.getRangeMarkers((int) (short) 10, layer4);
        java.lang.String str6 = categoryPlot0.getPlotType();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double10 = categoryAxis3D9.getLowerMargin();
        categoryPlot0.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D9);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset12 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range14 = defaultBoxAndWhiskerCategoryDataset12.getRangeBounds(false);
        categoryPlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset12);
        int int16 = defaultBoxAndWhiskerCategoryDataset12.getColumnCount();
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        jFreeChart7.setTextAntiAlias(false);
        boolean boolean10 = jFreeChart7.getAntiAlias();
        boolean boolean11 = jFreeChart7.isNotify();
        jFreeChart7.setBorderVisible(false);
        jFreeChart7.setBackgroundImageAlpha((float) 5);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 12);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean3 = valueMarker1.equals((java.lang.Object) standardCategoryToolTipGenerator2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        try {
            java.lang.String str7 = standardCategoryToolTipGenerator2.generateToolTip(categoryDataset4, (-1), (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot0.getDomainAxis((int) (byte) 0);
        java.awt.Stroke stroke7 = categoryPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = stackedBarRenderer3D3.getGradientPaintTransformer();
        boolean boolean5 = stackedBarRenderer3D3.getBaseCreateEntities();
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Stroke stroke5 = stackedBarRenderer3D3.getBaseStroke();
        java.io.ObjectOutputStream objectOutputStream6 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke5, objectOutputStream6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 12);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean3 = valueMarker1.equals((java.lang.Object) standardCategoryToolTipGenerator2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        valueMarker1.setOutlinePaint((java.awt.Paint) color4);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("{0}", font3);
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        plotRenderingInfo1.setPlotArea(rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.AffineTransform affineTransform11 = null;
        java.awt.RenderingHints renderingHints12 = null;
        java.awt.PaintContext paintContext13 = color7.createContext(colorModel8, rectangle9, rectangle2D10, affineTransform11, renderingHints12);
        int int14 = color7.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D5, (java.awt.Paint) color7);
        java.awt.Paint paint16 = legendGraphic15.getOutlinePaint();
        boolean boolean17 = legendGraphic15.isLineVisible();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintContext13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class1 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date5, date11);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) date5);
        java.lang.Comparable comparable14 = null;
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset13, comparable14, 100.0d, (int) '#');
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset13);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        java.awt.Stroke stroke21 = ringPlot19.getSectionOutlineStroke((java.lang.Comparable) 12);
        java.awt.Stroke stroke22 = ringPlot19.getBaseSectionOutlineStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator23 = null;
        try {
            ringPlot19.setLegendLabelGenerator(pieSectionLabelGenerator23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("{0}", font3);
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        plotRenderingInfo1.setPlotArea(rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.AffineTransform affineTransform11 = null;
        java.awt.RenderingHints renderingHints12 = null;
        java.awt.PaintContext paintContext13 = color7.createContext(colorModel8, rectangle9, rectangle2D10, affineTransform11, renderingHints12);
        int int14 = color7.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D5, (java.awt.Paint) color7);
        java.awt.Color color16 = java.awt.Color.black;
        float[] floatArray23 = new float[] { (byte) -1, 10, (short) 0, (byte) 0, 2958465, (short) 1 };
        float[] floatArray24 = color16.getComponents(floatArray23);
        legendGraphic15.setLinePaint((java.awt.Paint) color16);
        java.awt.Paint paint26 = legendGraphic15.getOutlinePaint();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintContext13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNull(paint26);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean2 = borderArrangement0.equals((java.lang.Object) (-1.0f));
        borderArrangement0.clear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        xYPlot6.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot6.setDataset(xYDataset9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Color color15 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer16 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color12, paint13, (java.awt.Paint) color14, (java.awt.Paint) color15);
        java.awt.Paint paint17 = waterfallBarRenderer16.getLastBarPaint();
        java.awt.Shape shape18 = waterfallBarRenderer16.getBaseShape();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.awt.Paint paint21 = categoryAxis3D20.getLabelPaint();
        java.awt.Color color22 = java.awt.Color.pink;
        categoryAxis3D20.setAxisLinePaint((java.awt.Paint) color22);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer27 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator32 = stackedBarRenderer3D31.getLegendItemURLGenerator();
        java.awt.Paint paint34 = stackedBarRenderer3D31.getSeriesPaint(3);
        boolean boolean35 = stackedBarRenderer3D31.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator40 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D31.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator40, true);
        java.awt.Font font45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock46 = new org.jfree.chart.block.LabelBlock("{0}", font45);
        java.awt.geom.Rectangle2D rectangle2D47 = labelBlock46.getBounds();
        stackedBarRenderer3D31.setSeriesShape(5, (java.awt.Shape) rectangle2D47);
        boolean boolean49 = stackedAreaRenderer27.equals((java.lang.Object) rectangle2D47);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean51 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge50);
        double double52 = categoryAxis3D20.getCategoryStart(10, 3, rectangle2D47, rectangleEdge50);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double54 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D47, rectangleEdge53);
        boolean boolean55 = org.jfree.chart.util.ShapeUtilities.equal(shape18, (java.awt.Shape) rectangle2D47);
        org.jfree.data.KeyedObjects2D keyedObjects2D56 = new org.jfree.data.KeyedObjects2D();
        int int58 = keyedObjects2D56.getColumnIndex((java.lang.Comparable) 100L);
        java.util.List list59 = keyedObjects2D56.getColumnKeys();
        xYPlot6.drawRangeTickBands(graphics2D11, rectangle2D47, list59);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator32);
        org.junit.Assert.assertNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertNotNull(list59);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        double double4 = stackedBarRenderer3D3.getBase();
        java.lang.Class<?> wildcardClass5 = stackedBarRenderer3D3.getClass();
        stackedBarRenderer3D3.setBaseItemLabelsVisible(false, false);
        boolean boolean11 = stackedBarRenderer3D3.isItemLabelVisible(2958465, (int) (byte) 0);
        java.awt.Paint paint12 = stackedBarRenderer3D3.getWallPaint();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Paint[] paintArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Color color5 = java.awt.Color.darkGray;
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color7 = java.awt.Color.darkGray;
        java.awt.Color color8 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer9 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color5, paint6, (java.awt.Paint) color7, (java.awt.Paint) color8);
        int int10 = color5.getTransparency();
        java.awt.Color color11 = java.awt.Color.cyan;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color5, color11 };
        java.awt.Paint[] paintArray13 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator18 = stackedBarRenderer3D17.getLegendItemURLGenerator();
        java.awt.Stroke stroke19 = stackedBarRenderer3D17.getBaseStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator24 = stackedBarRenderer3D23.getLegendItemURLGenerator();
        java.awt.Stroke stroke25 = stackedBarRenderer3D23.getBaseStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D29 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator30 = stackedBarRenderer3D29.getLegendItemURLGenerator();
        java.awt.Stroke stroke31 = stackedBarRenderer3D29.getBaseStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator36 = stackedBarRenderer3D35.getLegendItemURLGenerator();
        java.awt.Stroke stroke37 = stackedBarRenderer3D35.getBaseStroke();
        java.awt.Stroke stroke38 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray39 = new java.awt.Stroke[] { stroke19, stroke25, stroke31, stroke37, stroke38 };
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D43 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator44 = stackedBarRenderer3D43.getLegendItemURLGenerator();
        java.awt.Stroke stroke45 = stackedBarRenderer3D43.getBaseStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D49 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator50 = stackedBarRenderer3D49.getLegendItemURLGenerator();
        java.awt.Stroke stroke51 = stackedBarRenderer3D49.getBaseStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D55 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = stackedBarRenderer3D55.getLegendItemURLGenerator();
        java.awt.Stroke stroke57 = stackedBarRenderer3D55.getBaseStroke();
        java.awt.Stroke stroke58 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D62 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator63 = stackedBarRenderer3D62.getLegendItemURLGenerator();
        java.awt.Stroke stroke64 = stackedBarRenderer3D62.getBaseStroke();
        java.awt.Stroke stroke65 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray66 = new java.awt.Stroke[] { stroke45, stroke51, stroke57, stroke58, stroke64, stroke65 };
        org.jfree.chart.axis.NumberAxis numberAxis68 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape69 = numberAxis68.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis71 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean72 = numberAxis71.isNegativeArrowVisible();
        numberAxis71.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis76 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape77 = numberAxis76.getLeftArrow();
        numberAxis71.setLeftArrow(shape77);
        java.awt.Shape[] shapeArray79 = new java.awt.Shape[] { shape69, shape77 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier80 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray4, paintArray12, paintArray13, strokeArray39, strokeArray66, shapeArray79);
        java.awt.Shape[] shapeArray81 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier82 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray3, strokeArray39, shapeArray81);
        java.lang.Object obj83 = defaultDrawingSupplier82.clone();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(strokeArray39);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator63);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(strokeArray66);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(shape77);
        org.junit.Assert.assertNotNull(shapeArray79);
        org.junit.Assert.assertNotNull(shapeArray81);
        org.junit.Assert.assertNotNull(obj83);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace9 = xYPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation(axisLocation10);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Color color15 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer16 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color12, paint13, (java.awt.Paint) color14, (java.awt.Paint) color15);
        xYPlot6.setDomainCrosshairPaint((java.awt.Paint) color14);
        int int18 = color14.getRed();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 64 + "'", int18 == 64);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot6.getRangeAxis();
        java.lang.String str8 = xYPlot6.getNoDataMessage();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        jFreeChart7.setTextAntiAlias(false);
        jFreeChart7.setNotify(false);
        java.awt.RenderingHints renderingHints12 = jFreeChart7.getRenderingHints();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(renderingHints12);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape7 = numberAxis6.getLeftArrow();
        numberAxis1.setLeftArrow(shape7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean11 = numberAxis10.isNegativeArrowVisible();
        numberAxis10.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape16 = numberAxis15.getLeftArrow();
        numberAxis10.setLeftArrow(shape16);
        numberAxis1.setDownArrow(shape16);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset21 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset21);
        java.text.DateFormat dateFormat25 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = new org.jfree.chart.axis.DateTickUnit(3, (int) 'a', dateFormat25);
        java.lang.String str27 = dateTickUnit26.toString();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity29 = new org.jfree.chart.entity.CategoryItemEntity(shape16, "", "DateTickUnit[HOUR, 97]", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset21, (java.lang.Comparable) dateTickUnit26, (java.lang.Comparable) (short) 1);
        java.lang.Number number30 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset21);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset33 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class34 = null;
        org.jfree.data.time.DateRange dateRange37 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date38 = dateRange37.getUpperDate();
        java.util.TimeZone timeZone39 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date38, timeZone39);
        org.jfree.data.time.DateRange dateRange43 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date44 = dateRange43.getUpperDate();
        org.jfree.data.time.DateRange dateRange45 = new org.jfree.data.time.DateRange(date38, date44);
        org.jfree.data.general.PieDataset pieDataset46 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset33, (java.lang.Comparable) date38);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date38);
        defaultCategoryDataset21.setValue((java.lang.Number) Double.NaN, (java.lang.Comparable) 0.8f, (java.lang.Comparable) month47);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "DateTickUnit[HOUR, 97]" + "'", str27.equals("DateTickUnit[HOUR, 97]"));
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 0.0d + "'", number30.equals(0.0d));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(pieDataset46);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        numberAxis1.resizeRange((double) 100L);
        org.jfree.chart.plot.Plot plot7 = numberAxis1.getPlot();
        java.awt.Color color8 = java.awt.Color.darkGray;
        java.awt.Paint paint9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color10 = java.awt.Color.darkGray;
        java.awt.Color color11 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer12 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color8, paint9, (java.awt.Paint) color10, (java.awt.Paint) color11);
        java.awt.Paint paint13 = waterfallBarRenderer12.getLastBarPaint();
        numberAxis1.setAxisLinePaint(paint13);
        numberAxis1.setAutoTickUnitSelection(false);
        numberAxis1.setLowerBound(0.05d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) '4');
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Paint paint6 = stackedBarRenderer3D3.getSeriesPaint(3);
        boolean boolean7 = stackedBarRenderer3D3.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = null;
        stackedBarRenderer3D3.setLegendItemURLGenerator(categorySeriesLabelGenerator8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint12 = categoryPlot11.getRangeGridlinePaint();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean15 = numberAxis14.isNegativeArrowVisible();
        org.jfree.chart.plot.Marker marker16 = null;
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("{0}", font18);
        java.awt.geom.Rectangle2D rectangle2D20 = labelBlock19.getBounds();
        stackedBarRenderer3D3.drawRangeMarker(graphics2D10, categoryPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis14, marker16, rectangle2D20);
        java.lang.String str22 = numberAxis14.getLabelToolTip();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class1 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date5, date11);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) date5);
        java.lang.Comparable comparable14 = null;
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset13, comparable14, 100.0d, (int) '#');
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset13);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        java.awt.Stroke stroke21 = ringPlot19.getSectionOutlineStroke((java.lang.Comparable) 12);
        java.awt.Stroke stroke22 = ringPlot19.getBaseSectionOutlineStroke();
        org.jfree.chart.util.Rotation rotation23 = ringPlot19.getDirection();
        double double24 = ringPlot19.getOuterSeparatorExtension();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rotation23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.2d + "'", double24 == 0.2d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(100);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (byte) 10, serialDate3);
        try {
            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) -1, serialDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        xYPlot6.setBackgroundImageAlignment((int) (byte) -1);
        float float9 = xYPlot6.getForegroundAlpha();
        int int10 = xYPlot6.getWeight();
        org.jfree.chart.plot.Plot plot11 = xYPlot6.getRootPlot();
        xYPlot6.setDomainCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(plot11);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("", "hi!", "ThreadContext");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection4);
        taskSeriesCollection4.validateObject();
        try {
            java.lang.String str9 = standardCategoryURLGenerator3.generateURL((org.jfree.data.category.CategoryDataset) taskSeriesCollection4, 64, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 64, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        boolean boolean2 = textAnchor0.equals((java.lang.Object) itemLabelAnchor1);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = stackedBarRenderer3D5.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedBarRenderer3D5.getSeriesPositiveItemLabelPosition(0);
        stackedBarRenderer3D5.setItemLabelAnchorOffset((double) '#');
        boolean boolean11 = stackedBarRenderer3D5.getAutoPopulateSeriesPaint();
        java.awt.Paint paint12 = stackedBarRenderer3D5.getBaseOutlinePaint();
        paintList0.setPaint(5, paint12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot14.getDomainAxisLocation();
        java.awt.Color color17 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot14.setRangeGridlinePaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot14.getDomainAxis((int) (byte) 0);
        boolean boolean21 = paintList0.equals((java.lang.Object) categoryAxis20);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        taskSeriesCollection0.validateObject();
        int int3 = taskSeriesCollection0.getRowCount();
        try {
            org.jfree.data.gantt.TaskSeries taskSeries5 = taskSeriesCollection0.getSeries(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.lang.Object[][] objArray1 = dataPackageResources0.getContents();
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace9 = xYPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation(axisLocation10);
        xYPlot6.setRangeCrosshairValue(1.0d);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot6.setNoDataMessageFont(font14);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis18, valueAxis20, xYItemRenderer21);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot22);
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = blockBorder28.getInsets();
        double double30 = rectangleInsets29.getRight();
        xYPlot22.setInsets(rectangleInsets29);
        java.awt.Color color32 = java.awt.Color.YELLOW;
        xYPlot22.setDomainTickBandPaint((java.awt.Paint) color32);
        xYPlot6.setDomainGridlinePaint((java.awt.Paint) color32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation(axisLocation35, false);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) 12);
        org.jfree.chart.text.TextAnchor textAnchor40 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        valueMarker39.setLabelTextAnchor(textAnchor40);
        xYPlot6.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker39);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font44 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        textTitle43.setFont(font44);
        valueMarker39.setLabelFont(font44);
        float float47 = valueMarker39.getAlpha();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(textAnchor40);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.8f + "'", float47 == 0.8f);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("[Dec 31, 1969 3:59:59 PM --> Dec 31, 1969 4:00:00 PM]", graphics2D1, 10.0f, (float) 60000L, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 0, (int) '4', (int) (byte) 100);
        try {
            segmentedTimeline3.addException((long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace9 = xYPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation(axisLocation10);
        xYPlot6.setRangeCrosshairValue(1.0d);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot6.setNoDataMessageFont(font14);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis18, valueAxis20, xYItemRenderer21);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot22);
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = blockBorder28.getInsets();
        double double30 = rectangleInsets29.getRight();
        xYPlot22.setInsets(rectangleInsets29);
        java.awt.Color color32 = java.awt.Color.YELLOW;
        xYPlot22.setDomainTickBandPaint((java.awt.Paint) color32);
        xYPlot6.setDomainGridlinePaint((java.awt.Paint) color32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation(axisLocation35, false);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) 12);
        org.jfree.chart.text.TextAnchor textAnchor40 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        valueMarker39.setLabelTextAnchor(textAnchor40);
        xYPlot6.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker39);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font44 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        textTitle43.setFont(font44);
        valueMarker39.setLabelFont(font44);
        java.lang.Class class47 = null;
        org.jfree.data.time.DateRange dateRange50 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date51 = dateRange50.getUpperDate();
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date51, timeZone52);
        org.jfree.data.time.DateRange dateRange56 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date57 = dateRange56.getUpperDate();
        org.jfree.data.time.DateRange dateRange58 = new org.jfree.data.time.DateRange(date51, date57);
        org.jfree.chart.text.TextAnchor textAnchor60 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor61 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.DateTick dateTick63 = new org.jfree.chart.axis.DateTick(date51, "UnitType.ABSOLUTE", textAnchor60, textAnchor61, (double) 9);
        boolean boolean64 = valueMarker39.equals((java.lang.Object) textAnchor61);
        java.awt.Paint paint65 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        valueMarker39.setOutlinePaint(paint65);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(textAnchor40);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(textAnchor60);
        org.junit.Assert.assertNotNull(textAnchor61);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(paint65);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("RectangleEdge.BOTTOM", (org.jfree.data.time.TimePeriod) month1);
        try {
            org.jfree.data.gantt.Task task4 = task2.getSubtask((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape5 = numberAxis4.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, valueAxis6, xYItemRenderer7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot8);
        jFreeChart9.setTextAntiAlias(false);
        boolean boolean12 = jFreeChart9.getAntiAlias();
        java.awt.Stroke stroke13 = null;
        jFreeChart9.setBorderStroke(stroke13);
        org.jfree.chart.plot.Plot plot15 = jFreeChart9.getPlot();
        boolean boolean16 = defaultCategoryDataset0.hasListener((java.util.EventListener) plot15);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(plot15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.Object obj2 = categoryAxis3D1.clone();
        categoryAxis3D1.setTickMarksVisible(true);
        categoryAxis3D1.configure();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("{0}", font16);
        java.awt.geom.Rectangle2D rectangle2D18 = labelBlock17.getBounds();
        plotRenderingInfo14.setPlotArea(rectangle2D18);
        java.awt.Paint paint20 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape24 = numberAxis23.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) numberAxis23, valueAxis25, xYItemRenderer26);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = xYPlot27.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = xYPlot27.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean34 = numberAxis33.isNegativeArrowVisible();
        numberAxis33.resizeRange((double) 100);
        boolean boolean38 = numberAxis33.equals((java.lang.Object) 12);
        double double39 = numberAxis33.getLowerBound();
        java.text.NumberFormat numberFormat40 = numberAxis33.getNumberFormatOverride();
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape44 = numberAxis43.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset41, (org.jfree.chart.axis.ValueAxis) numberAxis43, valueAxis45, xYItemRenderer46);
        xYPlot47.setBackgroundImageAlignment((int) (byte) -1);
        float float50 = xYPlot47.getForegroundAlpha();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D54 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator55 = stackedBarRenderer3D54.getLegendItemURLGenerator();
        java.awt.Stroke stroke56 = stackedBarRenderer3D54.getBaseStroke();
        xYPlot47.setOutlineStroke(stroke56);
        numberAxis33.setAxisLineStroke(stroke56);
        xYPlot27.setRangeGridlineStroke(stroke56);
        java.awt.Color color60 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.LegendItem legendItem61 = new org.jfree.chart.LegendItem("hi!", "org.jfree.data.time.TimePeriodFormatException: ", "hi!", "Preceding", (java.awt.Shape) rectangle2D18, paint20, stroke56, (java.awt.Paint) color60);
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean63 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge62);
        java.lang.String str64 = rectangleEdge62.toString();
        try {
            double double65 = categoryAxis3D1.getCategoryJava2DCoordinate(categoryAnchor6, 97, (int) (byte) 100, rectangle2D18, rectangleEdge62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(valueAxis29);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + (-49.5d) + "'", double39 == (-49.5d));
        org.junit.Assert.assertNull(numberFormat40);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 1.0f + "'", float50 == 1.0f);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "RectangleEdge.BOTTOM" + "'", str64.equals("RectangleEdge.BOTTOM"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        double double4 = stackedBarRenderer3D3.getBase();
        double double5 = stackedBarRenderer3D3.getYOffset();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator9 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D3.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator9, false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.util.List list2 = blockContainer0.getBlocks();
        java.lang.Object obj3 = blockContainer0.clone();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        java.awt.Paint paint3 = categoryAxis3D1.getLabelPaint();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        categoryAxis3D1.setCategoryLabelPositions(categoryLabelPositions4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("{0}", font9);
        java.awt.geom.Rectangle2D rectangle2D11 = labelBlock10.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D11, rectangleEdge12);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.awt.Paint paint16 = categoryAxis3D15.getLabelPaint();
        java.awt.Color color17 = java.awt.Color.pink;
        categoryAxis3D15.setAxisLinePaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer22 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator27 = stackedBarRenderer3D26.getLegendItemURLGenerator();
        java.awt.Paint paint29 = stackedBarRenderer3D26.getSeriesPaint(3);
        boolean boolean30 = stackedBarRenderer3D26.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator35 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D26.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator35, true);
        java.awt.Font font40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock41 = new org.jfree.chart.block.LabelBlock("{0}", font40);
        java.awt.geom.Rectangle2D rectangle2D42 = labelBlock41.getBounds();
        stackedBarRenderer3D26.setSeriesShape(5, (java.awt.Shape) rectangle2D42);
        boolean boolean44 = stackedAreaRenderer22.equals((java.lang.Object) rectangle2D42);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean46 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge45);
        double double47 = categoryAxis3D15.getCategoryStart(10, 3, rectangle2D42, rectangleEdge45);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean49 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge48);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation51 = categoryPlot50.getDomainAxisLocation();
        java.awt.Color color53 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot50.setRangeGridlinePaint((java.awt.Paint) color53);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo56 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo56);
        java.awt.Font font59 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock60 = new org.jfree.chart.block.LabelBlock("{0}", font59);
        java.awt.geom.Rectangle2D rectangle2D61 = labelBlock60.getBounds();
        plotRenderingInfo57.setPlotArea(rectangle2D61);
        java.awt.geom.Point2D point2D63 = null;
        categoryPlot50.zoomRangeAxes((double) 8, plotRenderingInfo57, point2D63);
        try {
            org.jfree.chart.axis.AxisState axisState65 = categoryAxis3D1.draw(graphics2D6, (double) 60000L, rectangle2D11, rectangle2D42, rectangleEdge48, plotRenderingInfo57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator27);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(rectangle2D61);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        org.jfree.data.Range range5 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange2, (double) (byte) -1, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange2, (double) 2);
        org.jfree.data.Range range8 = rectangleConstraint7.getWidthRange();
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot0.getDomainAxis((int) (byte) 0);
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = stackedBarRenderer3D11.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedBarRenderer3D11.getSeriesPositiveItemLabelPosition(0);
        stackedBarRenderer3D11.setItemLabelAnchorOffset((double) '#');
        boolean boolean17 = stackedBarRenderer3D11.getAutoPopulateSeriesPaint();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D11, false);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        categoryPlot0.setRangeAxis(0, valueAxis21);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot0.getRangeMarkers(layer23);
        categoryPlot0.configureRangeAxes();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(collection24);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = stackedBarRenderer3D3.getSeriesPositiveItemLabelPosition(0);
        stackedBarRenderer3D3.setIncludeBaseInRange(true);
        boolean boolean9 = stackedBarRenderer3D3.getIncludeBaseInRange();
        boolean boolean10 = stackedBarRenderer3D3.getRenderAsPercentages();
        stackedBarRenderer3D3.setSeriesCreateEntities((int) (short) 100, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint1, (java.awt.Paint) color2, (java.awt.Paint) color3);
        java.awt.Color color5 = java.awt.Color.cyan;
        waterfallBarRenderer4.setBaseOutlinePaint((java.awt.Paint) color5);
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        waterfallBarRenderer4.setBaseStroke(stroke7, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = waterfallBarRenderer4.getBaseToolTipGenerator();
        waterfallBarRenderer4.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.LegendItem legendItem15 = waterfallBarRenderer4.getLegendItem(2, (int) (short) 1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(categoryToolTipGenerator10);
        org.junit.Assert.assertNull(legendItem15);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        stackedBarRenderer3D3.setSeriesItemLabelsVisible(0, (java.lang.Boolean) false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double14 = rectangleInsets13.getRight();
        xYPlot6.setInsets(rectangleInsets13);
        java.lang.Object obj16 = xYPlot6.clone();
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot6.getDataset(3);
        xYPlot6.setDomainCrosshairValue((double) 3, true);
        org.jfree.data.xy.XYDataset xYDataset23 = xYPlot6.getDataset(1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        xYPlot6.setRenderer(0, xYItemRenderer25, true);
        org.jfree.chart.LegendItemCollection legendItemCollection28 = xYPlot6.getFixedLegendItems();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertNull(xYDataset23);
        org.junit.Assert.assertNull(legendItemCollection28);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        double double4 = stackedBarRenderer3D3.getBase();
        java.lang.Class<?> wildcardClass5 = stackedBarRenderer3D3.getClass();
        stackedBarRenderer3D3.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot0.getDomainAxis((int) (byte) 0);
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = stackedBarRenderer3D11.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedBarRenderer3D11.getSeriesPositiveItemLabelPosition(0);
        stackedBarRenderer3D11.setItemLabelAnchorOffset((double) '#');
        boolean boolean17 = stackedBarRenderer3D11.getAutoPopulateSeriesPaint();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D11, false);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        categoryPlot0.setRangeAxis(0, valueAxis21);
        org.jfree.chart.axis.AxisSpace axisSpace23 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(axisSpace23);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("{0}", font3);
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        plotRenderingInfo1.setPlotArea(rectangle2D5);
        java.awt.geom.Point2D point2D7 = null;
        try {
            int int8 = plotRenderingInfo1.getSubplotIndex(point2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(rectangle2D5);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("{0}", font3);
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        plotRenderingInfo1.setPlotArea(rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.AffineTransform affineTransform11 = null;
        java.awt.RenderingHints renderingHints12 = null;
        java.awt.PaintContext paintContext13 = color7.createContext(colorModel8, rectangle9, rectangle2D10, affineTransform11, renderingHints12);
        int int14 = color7.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D5, (java.awt.Paint) color7);
        boolean boolean16 = legendGraphic15.isShapeVisible();
        java.awt.Paint paint17 = legendGraphic15.getFillPaint();
        java.awt.Paint paint18 = legendGraphic15.getFillPaint();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        try {
            org.jfree.chart.util.Size2D size2D21 = legendGraphic15.arrange(graphics2D19, rectangleConstraint20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintContext13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight(2958465);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot0.getRangeMarkers((int) (short) 10, layer4);
        java.lang.String str6 = categoryPlot0.getPlotType();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double10 = categoryAxis3D9.getLowerMargin();
        categoryPlot0.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D9);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset12 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range14 = defaultBoxAndWhiskerCategoryDataset12.getRangeBounds(false);
        categoryPlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset12);
        org.jfree.data.general.DatasetGroup datasetGroup16 = defaultBoxAndWhiskerCategoryDataset12.getGroup();
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(datasetGroup16);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape9 = numberAxis8.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis8, valueAxis10, xYItemRenderer11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot12.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot12.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setDomainAxisLocation(10, axisLocation18, false);
        categoryPlot0.setDomainAxisLocation(12, axisLocation18);
        java.awt.Stroke stroke22 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace23);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection26 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection26);
        taskSeriesCollection26.validateObject();
        categoryPlot0.setDataset(12, (org.jfree.data.category.CategoryDataset) taskSeriesCollection26);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder30);
        java.lang.String str32 = datasetRenderingOrder30.toString();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str32.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight(2958465);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot0.getRangeMarkers((int) (short) 10, layer4);
        java.lang.String str6 = categoryPlot0.getPlotType();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double10 = categoryAxis3D9.getLowerMargin();
        categoryPlot0.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D9);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset12 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range14 = defaultBoxAndWhiskerCategoryDataset12.getRangeBounds(false);
        categoryPlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset12);
        try {
            java.lang.Number number18 = defaultBoxAndWhiskerCategoryDataset12.getMinOutlier(2958465, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2958465, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(range14);
    }
}

