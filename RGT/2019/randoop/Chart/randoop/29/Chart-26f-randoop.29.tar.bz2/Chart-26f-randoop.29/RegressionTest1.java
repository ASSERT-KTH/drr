import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        double double4 = stackedBarRenderer3D3.getBase();
        java.lang.Class<?> wildcardClass5 = stackedBarRenderer3D3.getClass();
        stackedBarRenderer3D3.setBaseItemLabelsVisible(false, false);
        java.awt.Color color9 = java.awt.Color.black;
        float[] floatArray16 = new float[] { (byte) -1, 10, (short) 0, (byte) 0, 2958465, (short) 1 };
        float[] floatArray17 = color9.getComponents(floatArray16);
        stackedBarRenderer3D3.setBaseFillPaint((java.awt.Paint) color9);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        double double4 = defaultBoxAndWhiskerCategoryDataset0.getRangeUpperBound(false);
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean8 = numberAxis7.isNegativeArrowVisible();
        numberAxis7.setAutoTickUnitSelection(false, false);
        numberAxis7.setLabel("ThreadContext");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = numberAxis7.getTickUnit();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset15 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class16 = null;
        org.jfree.data.time.DateRange dateRange19 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date20 = dateRange19.getUpperDate();
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date20, timeZone21);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date26 = dateRange25.getUpperDate();
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange(date20, date26);
        org.jfree.data.general.PieDataset pieDataset28 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset15, (java.lang.Comparable) date20);
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) numberTickUnit14, (org.jfree.data.KeyedValues) pieDataset28);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline33 = new org.jfree.chart.axis.SegmentedTimeline((long) 0, (int) '4', (int) (byte) 100);
        org.jfree.chart.block.BorderArrangement borderArrangement34 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean35 = segmentedTimeline33.equals((java.lang.Object) borderArrangement34);
        java.lang.Object obj36 = null;
        boolean boolean37 = segmentedTimeline33.equals(obj36);
        java.util.Date date39 = segmentedTimeline33.getDate(1L);
        try {
            defaultBoxAndWhiskerCategoryDataset0.add(boxAndWhiskerItem5, (java.lang.Comparable) numberTickUnit14, (java.lang.Comparable) date39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(pieDataset28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(date39);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        numberAxis1.resizeRange((double) 100L);
        org.jfree.chart.plot.Plot plot7 = numberAxis1.getPlot();
        java.awt.Color color8 = java.awt.Color.darkGray;
        java.awt.Paint paint9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color10 = java.awt.Color.darkGray;
        java.awt.Color color11 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer12 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color8, paint9, (java.awt.Paint) color10, (java.awt.Paint) color11);
        java.awt.Paint paint13 = waterfallBarRenderer12.getLastBarPaint();
        numberAxis1.setAxisLinePaint(paint13);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(markerAxisBand15);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.DatasetGroup datasetGroup1 = taskSeriesCollection0.getGroup();
        org.junit.Assert.assertNotNull(datasetGroup1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.Class class0 = null;
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date4 = dateRange3.getUpperDate();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date10 = dateRange9.getUpperDate();
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange(date4, date10);
        java.lang.Class class12 = null;
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date16 = dateRange15.getUpperDate();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date16, timeZone17);
        org.jfree.data.time.DateRange dateRange21 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date22 = dateRange21.getUpperDate();
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange(date16, date22);
        org.jfree.data.time.DateRange dateRange24 = new org.jfree.data.time.DateRange(date10, date16);
        java.util.Date date25 = dateRange24.getUpperDate();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight(2958465);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot0.getRangeMarkers((int) (short) 10, layer4);
        java.lang.String str6 = categoryPlot0.getPlotType();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double10 = categoryAxis3D9.getLowerMargin();
        categoryPlot0.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D9);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        categoryAxis3D9.setTickMarkStroke(stroke12);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        double double5 = categoryPlot0.getRangeCrosshairValue();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Point2D point2D8 = null;
        org.jfree.chart.plot.PlotState plotState9 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot10.getDomainAxisLocation();
        java.awt.Color color13 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot10.setRangeGridlinePaint((java.awt.Paint) color13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot10.getDomainAxis((int) (byte) 0);
        categoryPlot10.configureDomainAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot20.getDomainAxisLocation();
        java.awt.Color color23 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot20.setRangeGridlinePaint((java.awt.Paint) color23);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        java.awt.Font font29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock30 = new org.jfree.chart.block.LabelBlock("{0}", font29);
        java.awt.geom.Rectangle2D rectangle2D31 = labelBlock30.getBounds();
        plotRenderingInfo27.setPlotArea(rectangle2D31);
        java.awt.geom.Point2D point2D33 = null;
        categoryPlot20.zoomRangeAxes((double) 8, plotRenderingInfo27, point2D33);
        categoryPlot10.handleClick(100, 0, plotRenderingInfo27);
        try {
            categoryPlot0.draw(graphics2D6, rectangle2D7, point2D8, plotState9, plotRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(rectangle2D31);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Paint paint6 = stackedBarRenderer3D3.getSeriesPaint(3);
        boolean boolean7 = stackedBarRenderer3D3.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = null;
        stackedBarRenderer3D3.setLegendItemURLGenerator(categorySeriesLabelGenerator8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint12 = categoryPlot11.getRangeGridlinePaint();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean15 = numberAxis14.isNegativeArrowVisible();
        org.jfree.chart.plot.Marker marker16 = null;
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("{0}", font18);
        java.awt.geom.Rectangle2D rectangle2D20 = labelBlock19.getBounds();
        stackedBarRenderer3D3.drawRangeMarker(graphics2D10, categoryPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis14, marker16, rectangle2D20);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.Object obj24 = categoryAxis3D23.clone();
        int int25 = categoryAxis3D23.getCategoryLabelPositionOffset();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent26 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D23);
        categoryPlot11.axisChanged(axisChangeEvent26);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class1 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date5, date11);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) date5);
        java.lang.Comparable comparable14 = null;
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset13, comparable14, 100.0d, (int) '#');
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset13);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline23 = new org.jfree.chart.axis.SegmentedTimeline((long) 0, (int) '4', (int) (byte) 100);
        org.jfree.chart.block.BorderArrangement borderArrangement24 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean25 = segmentedTimeline23.equals((java.lang.Object) borderArrangement24);
        java.lang.Object obj26 = null;
        boolean boolean27 = segmentedTimeline23.equals(obj26);
        java.util.Date date29 = segmentedTimeline23.getDate(1L);
        java.awt.Stroke stroke30 = ringPlot19.getSectionOutlineStroke((java.lang.Comparable) 1L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNull(stroke30);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        int int2 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.Plot plot3 = categoryPlot0.getParent();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        jFreeChart7.setTextAntiAlias(false);
        jFreeChart7.setNotify(false);
        jFreeChart7.setBackgroundImageAlpha((float) 6);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape6 = numberAxis5.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis5, valueAxis7, xYItemRenderer8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot9.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot9.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot9.setDomainAxisLocation(10, axisLocation15, false);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = xYPlot9.getRangeMarkers((int) ' ', layer19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.block.BlockContainer blockContainer22 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = blockContainer22.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        blockContainer22.setPadding(rectangleInsets24);
        double double27 = rectangleInsets24.calculateTopOutset((double) 100);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo28);
        java.awt.Font font31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock32 = new org.jfree.chart.block.LabelBlock("{0}", font31);
        java.awt.geom.Rectangle2D rectangle2D33 = labelBlock32.getBounds();
        plotRenderingInfo29.setPlotArea(rectangle2D33);
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets24.createOutsetRectangle(rectangle2D33, false, false);
        org.jfree.chart.axis.AxisCollection axisCollection38 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list39 = axisCollection38.getAxesAtRight();
        java.util.Collection collection40 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list39);
        xYPlot9.drawRangeTickBands(graphics2D21, rectangle2D37, list39);
        try {
            java.lang.Object obj42 = blockContainer0.draw(graphics2D1, rectangle2D2, (java.lang.Object) rectangle2D37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(valueAxis11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.0d + "'", double27 == 2.0d);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(list39);
        org.junit.Assert.assertNotNull(collection40);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getLGPL();
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight(2958465);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot0.getRangeMarkers((int) (short) 10, layer4);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape10 = numberAxis9.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis9, valueAxis11, xYItemRenderer12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot13.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace16 = xYPlot13.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot13.setRangeAxisLocation(axisLocation17);
        categoryPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation17, false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator26 = stackedBarRenderer3D25.getLegendItemURLGenerator();
        categoryPlot0.setRenderer((int) ' ', (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D25);
        stackedBarRenderer3D25.setSeriesItemLabelsVisible(12, (java.lang.Boolean) false, true);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(valueAxis15);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator26);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("{0}", font3);
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        plotRenderingInfo1.setPlotArea(rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.AffineTransform affineTransform11 = null;
        java.awt.RenderingHints renderingHints12 = null;
        java.awt.PaintContext paintContext13 = color7.createContext(colorModel8, rectangle9, rectangle2D10, affineTransform11, renderingHints12);
        int int14 = color7.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D5, (java.awt.Paint) color7);
        java.awt.Paint paint16 = legendGraphic15.getOutlinePaint();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.block.BlockContainer blockContainer18 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockContainer18.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        blockContainer18.setPadding(rectangleInsets20);
        double double23 = rectangleInsets20.calculateTopOutset((double) 100);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo24);
        java.awt.Font font27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock28 = new org.jfree.chart.block.LabelBlock("{0}", font27);
        java.awt.geom.Rectangle2D rectangle2D29 = labelBlock28.getBounds();
        plotRenderingInfo25.setPlotArea(rectangle2D29);
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets20.createOutsetRectangle(rectangle2D29, false, false);
        try {
            legendGraphic15.draw(graphics2D17, rectangle2D29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintContext13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 2.0d + "'", double23 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D33);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double14 = rectangleInsets13.getRight();
        xYPlot6.setInsets(rectangleInsets13);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        xYPlot6.setDataset((int) 'a', xYDataset17);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date6 = dateRange5.getUpperDate();
        org.jfree.data.Range range7 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange2, (org.jfree.data.Range) dateRange5);
        double double8 = range7.getUpperBound();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 5.0d + "'", double8 == 5.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = new org.jfree.chart.axis.SegmentedTimeline((long) 0, (int) '4', (int) (byte) 100);
        org.jfree.chart.block.BorderArrangement borderArrangement5 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean6 = segmentedTimeline4.equals((java.lang.Object) borderArrangement5);
        java.lang.Object obj7 = segmentedTimeline4.clone();
        boolean boolean8 = verticalAlignment0.equals(obj7);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.awt.Color color1 = java.awt.Color.RED;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        stackedBarRenderer3D5.setBaseSeriesVisibleInLegend(false);
        stackedBarRenderer3D5.setSeriesVisible((int) ' ', (java.lang.Boolean) true, false);
        boolean boolean12 = stackedBarRenderer3D5.isDrawBarOutline();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean15 = numberAxis14.isNegativeArrowVisible();
        numberAxis14.resizeRange((double) 100);
        boolean boolean19 = numberAxis14.equals((java.lang.Object) 12);
        double double20 = numberAxis14.getLowerBound();
        java.text.NumberFormat numberFormat21 = numberAxis14.getNumberFormatOverride();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape25 = numberAxis24.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis24, valueAxis26, xYItemRenderer27);
        xYPlot28.setBackgroundImageAlignment((int) (byte) -1);
        float float31 = xYPlot28.getForegroundAlpha();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator36 = stackedBarRenderer3D35.getLegendItemURLGenerator();
        java.awt.Stroke stroke37 = stackedBarRenderer3D35.getBaseStroke();
        xYPlot28.setOutlineStroke(stroke37);
        numberAxis14.setAxisLineStroke(stroke37);
        stackedBarRenderer3D5.setBaseOutlineStroke(stroke37);
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "ERROR : Relative To String", (java.awt.Paint) color1, stroke37);
        boolean boolean42 = categoryMarker41.getDrawAsLine();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-49.5d) + "'", double20 == (-49.5d));
        org.junit.Assert.assertNull(numberFormat21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 1.0f + "'", float31 == 1.0f);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getRowCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 11, 35.0d, 0.0d, (double) (short) -1);
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = groupedStackedBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1);
        boolean boolean3 = groupedStackedBarRenderer0.getRenderAsPercentages();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Stroke stroke2 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setForegroundAlpha((float) 8);
        categoryPlot0.configureDomainAxes();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.util.Locale locale1 = null;
        java.lang.Class class2 = null;
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
        java.util.ResourceBundle.clearCache(classLoader3);
        java.util.ResourceBundle.Control control5 = null;
        try {
            java.util.ResourceBundle resourceBundle6 = java.util.ResourceBundle.getBundle("", locale1, classLoader3, control5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classLoader3);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Paint paint6 = stackedBarRenderer3D3.getSeriesPaint(3);
        java.awt.Shape shape7 = stackedBarRenderer3D3.getBaseShape();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setWeight(2958465);
        int int12 = categoryPlot9.getDatasetCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot13.getDomainAxisLocation();
        java.awt.Color color16 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot13.setRangeGridlinePaint((java.awt.Paint) color16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot13.getDomainAxis((int) (byte) 0);
        categoryPlot13.configureDomainAxes();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator25 = stackedBarRenderer3D24.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = stackedBarRenderer3D24.getSeriesPositiveItemLabelPosition(0);
        stackedBarRenderer3D24.setItemLabelAnchorOffset((double) '#');
        boolean boolean30 = stackedBarRenderer3D24.getAutoPopulateSeriesPaint();
        categoryPlot13.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D24, false);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D24);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape37 = numberAxis36.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset34, (org.jfree.chart.axis.ValueAxis) numberAxis36, valueAxis38, xYItemRenderer39);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape44 = numberAxis43.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset41, (org.jfree.chart.axis.ValueAxis) numberAxis43, valueAxis45, xYItemRenderer46);
        org.jfree.chart.JFreeChart jFreeChart48 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot47);
        org.jfree.chart.axis.ValueAxis valueAxis49 = xYPlot47.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = xYPlot47.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation53 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot47.setDomainAxisLocation(10, axisLocation53, false);
        xYPlot40.setDomainAxisLocation(axisLocation53, true);
        org.jfree.chart.axis.NumberAxis numberAxis60 = new org.jfree.chart.axis.NumberAxis("hi!");
        xYPlot40.setRangeAxis((int) (byte) 10, (org.jfree.chart.axis.ValueAxis) numberAxis60);
        numberAxis60.setAutoRangeIncludesZero(false);
        org.jfree.chart.plot.ValueMarker valueMarker65 = new org.jfree.chart.plot.ValueMarker((double) 12);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator66 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean67 = valueMarker65.equals((java.lang.Object) standardCategoryToolTipGenerator66);
        org.jfree.chart.block.BlockContainer blockContainer68 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = blockContainer68.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        blockContainer68.setPadding(rectangleInsets70);
        double double73 = rectangleInsets70.calculateTopOutset((double) 100);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo74 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo75 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo74);
        java.awt.Font font77 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock78 = new org.jfree.chart.block.LabelBlock("{0}", font77);
        java.awt.geom.Rectangle2D rectangle2D79 = labelBlock78.getBounds();
        plotRenderingInfo75.setPlotArea(rectangle2D79);
        java.awt.geom.Rectangle2D rectangle2D83 = rectangleInsets70.createOutsetRectangle(rectangle2D79, false, false);
        stackedBarRenderer3D3.drawRangeMarker(graphics2D8, categoryPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis60, (org.jfree.chart.plot.Marker) valueMarker65, rectangle2D83);
        org.jfree.chart.util.Layer layer85 = null;
        java.util.Collection collection86 = categoryPlot9.getDomainMarkers(layer85);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(categoryAxis19);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator25);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(valueAxis49);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 2.0d + "'", double73 == 2.0d);
        org.junit.Assert.assertNotNull(font77);
        org.junit.Assert.assertNotNull(rectangle2D79);
        org.junit.Assert.assertNotNull(rectangle2D83);
        org.junit.Assert.assertNull(collection86);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = rectangleConstraint0.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint0.toFixedHeight((double) 0.0f);
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) borderArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockContainer3.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        blockContainer3.setPadding(rectangleInsets5);
        double double8 = rectangleInsets5.calculateTopOutset((double) 100);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("{0}", font12);
        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock13.getBounds();
        plotRenderingInfo10.setPlotArea(rectangle2D14);
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets5.createOutsetRectangle(rectangle2D14, false, false);
        try {
            blockContainer1.draw(graphics2D2, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangle2D18);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        numberAxis1.resizeRange((double) 100L);
        numberAxis1.setTickMarksVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean11 = numberAxis10.isNegativeArrowVisible();
        numberAxis10.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape16 = numberAxis15.getLeftArrow();
        numberAxis10.setLeftArrow(shape16);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape16, 0.0d, (double) (byte) -1);
        numberAxis1.setDownArrow(shape16);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        numberAxis1.setLabelFont(font22);
        numberAxis1.setVerticalTickLabels(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(font22);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        double double5 = stackedBarRenderer3D4.getBase();
        java.lang.Class<?> wildcardClass6 = stackedBarRenderer3D4.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        java.lang.Object obj8 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("http://www.jfree.org/jfreechart/index.html", (java.lang.Class) wildcardClass6);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNull(obj8);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.LEVEL;
        java.lang.String str1 = areaRendererEndType0.toString();
        org.junit.Assert.assertNotNull(areaRendererEndType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AreaRendererEndType.LEVEL" + "'", str1.equals("AreaRendererEndType.LEVEL"));
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 11, (double) 10.0f, false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class1 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date5, date11);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) date5);
        java.lang.Comparable comparable14 = null;
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset13, comparable14, 100.0d, (int) '#');
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset13);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        java.awt.Stroke stroke21 = ringPlot19.getSectionOutlineStroke((java.lang.Comparable) 12);
        java.lang.Object obj22 = ringPlot19.clone();
        java.awt.Color color23 = java.awt.Color.darkGray;
        java.awt.Paint paint24 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color25 = java.awt.Color.darkGray;
        java.awt.Color color26 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer27 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color23, paint24, (java.awt.Paint) color25, (java.awt.Paint) color26);
        java.awt.Color color28 = java.awt.Color.darkGray;
        java.awt.Paint paint29 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color30 = java.awt.Color.darkGray;
        java.awt.Color color31 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer32 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color28, paint29, (java.awt.Paint) color30, (java.awt.Paint) color31);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = new org.jfree.chart.labels.ItemLabelPosition();
        waterfallBarRenderer32.setBasePositiveItemLabelPosition(itemLabelPosition33, true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D39 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        java.awt.Color color40 = java.awt.Color.darkGray;
        java.awt.Paint paint41 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color42 = java.awt.Color.darkGray;
        java.awt.Color color43 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer44 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color40, paint41, (java.awt.Paint) color42, (java.awt.Paint) color43);
        stackedBarRenderer3D39.setBasePaint(paint41, false);
        waterfallBarRenderer32.setBaseItemLabelPaint(paint41);
        java.awt.Color color48 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color49 = color48.brighter();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D51 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.awt.Paint paint52 = categoryAxis3D51.getLabelPaint();
        java.awt.Paint paint53 = categoryAxis3D51.getLabelPaint();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer54 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color25, paint41, (java.awt.Paint) color48, paint53);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor55 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        java.awt.Color color56 = java.awt.Color.black;
        float[] floatArray63 = new float[] { (byte) -1, 10, (short) 0, (byte) 0, 2958465, (short) 1 };
        float[] floatArray64 = color56.getComponents(floatArray63);
        boolean boolean65 = itemLabelAnchor55.equals((java.lang.Object) floatArray64);
        float[] floatArray66 = color48.getRGBComponents(floatArray64);
        ringPlot19.setBaseSectionOutlinePaint((java.awt.Paint) color48);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(itemLabelAnchor55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(floatArray63);
        org.junit.Assert.assertNotNull(floatArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(floatArray66);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) (-1.0f), (double) (byte) 0, (double) ' ', (double) (byte) 100);
        boolean boolean6 = chartChangeEventType0.equals((java.lang.Object) ' ');
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.setAutoTickUnitSelection(false, false);
        numberAxis1.setLabel("ThreadContext");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = numberAxis1.getTickUnit();
        double double9 = numberAxis1.getLabelAngle();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(numberTickUnit8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.lang.Object obj1 = blockContainer0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean6 = numberAxis5.isNegativeArrowVisible();
        numberAxis5.resizeRange((double) 100);
        numberAxis5.resizeRange((double) 100L);
        numberAxis5.setTickMarksVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean15 = numberAxis14.isNegativeArrowVisible();
        numberAxis14.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape20 = numberAxis19.getLeftArrow();
        numberAxis14.setLeftArrow(shape20);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape20, 0.0d, (double) (byte) -1);
        numberAxis5.setDownArrow(shape20);
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint27 = null;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("{0}", "{0}", "ThreadContext", "ThreadContext", shape20, stroke26, paint27);
        java.lang.String str29 = legendItem28.getLabel();
        java.awt.Paint paint30 = legendItem28.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "{0}" + "'", str29.equals("{0}"));
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape9 = numberAxis8.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis8, valueAxis10, xYItemRenderer11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot12.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot12.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setDomainAxisLocation(10, axisLocation18, false);
        categoryPlot0.setDomainAxisLocation(12, axisLocation18);
        java.awt.Stroke stroke22 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace23);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection26 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection26);
        taskSeriesCollection26.validateObject();
        categoryPlot0.setDataset(12, (org.jfree.data.category.CategoryDataset) taskSeriesCollection26);
        try {
            java.lang.Number number32 = taskSeriesCollection26.getPercentComplete((java.lang.Comparable) 4L, (java.lang.Comparable) "({0}, {1}) = {3} - {4}");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Paint paint6 = stackedBarRenderer3D3.getSeriesPaint(3);
        java.awt.Shape shape7 = stackedBarRenderer3D3.getBaseShape();
        java.awt.Stroke stroke8 = stackedBarRenderer3D3.getBaseStroke();
        stackedBarRenderer3D3.setBaseItemLabelsVisible(true, true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape9 = numberAxis8.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis8, valueAxis10, xYItemRenderer11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot12.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot12.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setDomainAxisLocation(10, axisLocation18, false);
        categoryPlot0.setDomainAxisLocation(12, axisLocation18);
        java.awt.Stroke stroke22 = categoryPlot0.getDomainGridlineStroke();
        categoryPlot0.setAnchorValue(0.0d, true);
        java.awt.Paint paint26 = categoryPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape9 = numberAxis8.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis8, valueAxis10, xYItemRenderer11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot12.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot12.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setDomainAxisLocation(10, axisLocation18, false);
        categoryPlot0.setDomainAxisLocation(12, axisLocation18);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) 12);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator24 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean25 = valueMarker23.equals((java.lang.Object) standardCategoryToolTipGenerator24);
        java.awt.Paint paint26 = valueMarker23.getOutlinePaint();
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock29 = new org.jfree.chart.block.LabelBlock("{0}", font28);
        valueMarker23.setLabelFont(font28);
        float float31 = valueMarker23.getAlpha();
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker23);
        java.awt.Font font33 = valueMarker23.getLabelFont();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.8f + "'", float31 == 0.8f);
        org.junit.Assert.assertNotNull(font33);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape9 = numberAxis8.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis8, valueAxis10, xYItemRenderer11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot12.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot12.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setDomainAxisLocation(10, axisLocation18, false);
        categoryPlot0.setDomainAxisLocation(12, axisLocation18);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) 12);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator24 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean25 = valueMarker23.equals((java.lang.Object) standardCategoryToolTipGenerator24);
        java.awt.Paint paint26 = valueMarker23.getOutlinePaint();
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock29 = new org.jfree.chart.block.LabelBlock("{0}", font28);
        valueMarker23.setLabelFont(font28);
        float float31 = valueMarker23.getAlpha();
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker23);
        org.jfree.chart.block.BlockBorder blockBorder37 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = blockBorder37.getInsets();
        double double39 = rectangleInsets38.getRight();
        valueMarker23.setLabelOffset(rectangleInsets38);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker23.setLabelAnchor(rectangleAnchor41);
        java.lang.String str43 = rectangleAnchor41.toString();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.8f + "'", float31 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "RectangleAnchor.CENTER" + "'", str43.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight(2958465);
        categoryPlot0.clearDomainMarkers();
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double7 = rectangleInsets5.calculateLeftInset(0.0d);
        double double8 = rectangleInsets5.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Paint paint2 = null;
        groupedStackedBarRenderer0.setSeriesItemLabelPaint(0, paint2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState7 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot9.getDomainAxisLocation();
        java.awt.Color color12 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot9.setRangeGridlinePaint((java.awt.Paint) color12);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = categoryPlot9.getDomainAxis((int) (byte) 0);
        categoryPlot9.configureDomainAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot19.getDomainAxisLocation();
        java.awt.Color color22 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot19.setRangeGridlinePaint((java.awt.Paint) color22);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo25);
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock29 = new org.jfree.chart.block.LabelBlock("{0}", font28);
        java.awt.geom.Rectangle2D rectangle2D30 = labelBlock29.getBounds();
        plotRenderingInfo26.setPlotArea(rectangle2D30);
        java.awt.geom.Point2D point2D32 = null;
        categoryPlot19.zoomRangeAxes((double) 8, plotRenderingInfo26, point2D32);
        categoryPlot9.handleClick(100, 0, plotRenderingInfo26);
        org.jfree.chart.util.SortOrder sortOrder35 = categoryPlot9.getColumnRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D37 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int38 = categoryAxis3D37.getCategoryLabelPositionOffset();
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = categoryAxis3D37.getCategoryEnd(2958465, 100, rectangle2D41, rectangleEdge42);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("ERROR : Relative To String");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection46 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot47 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection46);
        taskSeriesCollection46.validateObject();
        try {
            groupedStackedBarRenderer0.drawItem(graphics2D4, categoryItemRendererState7, rectangle2D8, categoryPlot9, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D37, (org.jfree.chart.axis.ValueAxis) numberAxis45, (org.jfree.data.category.CategoryDataset) taskSeriesCollection46, 0, (-452), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(categoryAxis15);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(sortOrder35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeGridlinePaint();
        categoryPlot0.clearRangeMarkers();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        double double4 = defaultBoxAndWhiskerCategoryDataset0.getRangeUpperBound(false);
        java.text.DateFormat dateFormat7 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = new org.jfree.chart.axis.DateTickUnit(3, (int) 'a', dateFormat7);
        java.lang.String str9 = dateTickUnit8.toString();
        int int10 = defaultBoxAndWhiskerCategoryDataset0.getRowIndex((java.lang.Comparable) dateTickUnit8);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape14 = numberAxis13.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis13, valueAxis15, xYItemRenderer16);
        xYPlot17.setBackgroundImageAlignment((int) (byte) -1);
        float float20 = xYPlot17.getForegroundAlpha();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator25 = stackedBarRenderer3D24.getLegendItemURLGenerator();
        java.awt.Stroke stroke26 = stackedBarRenderer3D24.getBaseStroke();
        xYPlot17.setOutlineStroke(stroke26);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        xYPlot17.setDataset(xYDataset28);
        boolean boolean30 = defaultBoxAndWhiskerCategoryDataset0.equals((java.lang.Object) xYPlot17);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "DateTickUnit[HOUR, 97]" + "'", str9.equals("DateTickUnit[HOUR, 97]"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean6 = numberAxis5.isNegativeArrowVisible();
        numberAxis5.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape11 = numberAxis10.getLeftArrow();
        numberAxis5.setLeftArrow(shape11);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape11, 0.0d, (double) (byte) -1);
        java.awt.Color color16 = java.awt.Color.darkGray;
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Color color19 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer20 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color16, paint17, (java.awt.Paint) color18, (java.awt.Paint) color19);
        java.awt.Paint paint21 = waterfallBarRenderer20.getLastBarPaint();
        java.awt.Color color22 = java.awt.Color.darkGray;
        java.awt.Paint paint23 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color24 = java.awt.Color.darkGray;
        java.awt.Color color25 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer26 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color22, paint23, (java.awt.Paint) color24, (java.awt.Paint) color25);
        java.awt.Color color27 = java.awt.Color.cyan;
        waterfallBarRenderer26.setBaseOutlinePaint((java.awt.Paint) color27);
        java.awt.Color color29 = java.awt.Color.darkGray;
        java.awt.Paint paint30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color31 = java.awt.Color.darkGray;
        java.awt.Color color32 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer33 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color29, paint30, (java.awt.Paint) color31, (java.awt.Paint) color32);
        waterfallBarRenderer26.setBaseOutlinePaint(paint30);
        java.awt.Color color35 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color35.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        int int42 = color35.getTransparency();
        java.awt.Color color43 = color35.darker();
        java.awt.Color color44 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel45 = null;
        java.awt.Rectangle rectangle46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        java.awt.geom.AffineTransform affineTransform48 = null;
        java.awt.RenderingHints renderingHints49 = null;
        java.awt.PaintContext paintContext50 = color44.createContext(colorModel45, rectangle46, rectangle2D47, affineTransform48, renderingHints49);
        int int51 = color44.getTransparency();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer52 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint21, paint30, (java.awt.Paint) color35, (java.awt.Paint) color44);
        java.awt.Stroke stroke55 = waterfallBarRenderer52.getItemOutlineStroke(4, 3);
        java.awt.Color color57 = java.awt.Color.RED;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D61 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        stackedBarRenderer3D61.setBaseSeriesVisibleInLegend(false);
        stackedBarRenderer3D61.setSeriesVisible((int) ' ', (java.lang.Boolean) true, false);
        boolean boolean68 = stackedBarRenderer3D61.isDrawBarOutline();
        org.jfree.chart.axis.NumberAxis numberAxis70 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean71 = numberAxis70.isNegativeArrowVisible();
        numberAxis70.resizeRange((double) 100);
        boolean boolean75 = numberAxis70.equals((java.lang.Object) 12);
        double double76 = numberAxis70.getLowerBound();
        java.text.NumberFormat numberFormat77 = numberAxis70.getNumberFormatOverride();
        org.jfree.data.xy.XYDataset xYDataset78 = null;
        org.jfree.chart.axis.NumberAxis numberAxis80 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape81 = numberAxis80.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis82 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer83 = null;
        org.jfree.chart.plot.XYPlot xYPlot84 = new org.jfree.chart.plot.XYPlot(xYDataset78, (org.jfree.chart.axis.ValueAxis) numberAxis80, valueAxis82, xYItemRenderer83);
        xYPlot84.setBackgroundImageAlignment((int) (byte) -1);
        float float87 = xYPlot84.getForegroundAlpha();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D91 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator92 = stackedBarRenderer3D91.getLegendItemURLGenerator();
        java.awt.Stroke stroke93 = stackedBarRenderer3D91.getBaseStroke();
        xYPlot84.setOutlineStroke(stroke93);
        numberAxis70.setAxisLineStroke(stroke93);
        stackedBarRenderer3D61.setBaseOutlineStroke(stroke93);
        org.jfree.chart.plot.CategoryMarker categoryMarker97 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "ERROR : Relative To String", (java.awt.Paint) color57, stroke93);
        org.jfree.chart.LegendItem legendItem98 = new org.jfree.chart.LegendItem("", "", "{0}", "AreaRendererEndType.LEVEL", shape11, stroke55, (java.awt.Paint) color57);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(paintContext50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + (-49.5d) + "'", double76 == (-49.5d));
        org.junit.Assert.assertNull(numberFormat77);
        org.junit.Assert.assertNotNull(shape81);
        org.junit.Assert.assertTrue("'" + float87 + "' != '" + 1.0f + "'", float87 == 1.0f);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator92);
        org.junit.Assert.assertNotNull(stroke93);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace9 = xYPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation(axisLocation10);
        int int12 = xYPlot6.getDatasetCount();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("DatasetRenderingOrder.REVERSE");
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 12);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean3 = valueMarker1.equals((java.lang.Object) standardCategoryToolTipGenerator2);
        java.awt.Paint paint4 = valueMarker1.getOutlinePaint();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("{0}", font6);
        valueMarker1.setLabelFont(font6);
        float float9 = valueMarker1.getAlpha();
        java.lang.Object obj10 = valueMarker1.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.8f + "'", float9 == 0.8f);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = groupedStackedBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1);
        int int3 = defaultStatisticalCategoryDataset1.getColumnCount();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.awt.Color color0 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        int int7 = color0.getTransparency();
        java.awt.Color color8 = color0.darker();
        java.awt.Color color9 = java.awt.Color.black;
        float[] floatArray16 = new float[] { (byte) -1, 10, (short) 0, (byte) 0, 2958465, (short) 1 };
        float[] floatArray17 = color9.getComponents(floatArray16);
        float[] floatArray18 = color0.getColorComponents(floatArray17);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection19 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot20 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection19);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape24 = numberAxis23.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) numberAxis23, valueAxis25, xYItemRenderer26);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = xYPlot27.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace30 = xYPlot27.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = xYPlot27.getDomainAxisEdge(3);
        taskSeriesCollection19.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot27);
        java.lang.Object obj34 = taskSeriesCollection19.clone();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent35 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) floatArray18, (org.jfree.data.general.Dataset) taskSeriesCollection19);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(valueAxis29);
        org.junit.Assert.assertNull(axisSpace30);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = rendererState1.getEntityCollection();
        org.jfree.chart.entity.EntityCollection entityCollection3 = rendererState1.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection2);
        org.junit.Assert.assertNull(entityCollection3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot6.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setDomainAxisLocation(10, axisLocation12, false);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = xYPlot6.getRendererForDataset(xYDataset15);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(xYItemRenderer16);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.awt.Paint paint4 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(0.0d, (double) (-452), (double) 10.0f, (double) (-1L), paint4);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) 'a');
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder(1.0d, 1.0d, (double) 2958465, 0.0d);
        boolean boolean8 = multiplePiePlot0.equals((java.lang.Object) 1.0d);
        java.lang.Comparable comparable9 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        multiplePiePlot0.markerChanged(markerChangeEvent10);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + "Other" + "'", comparable9.equals("Other"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.awt.Font font0 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {2}" + "'", str0.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        double double4 = defaultBoxAndWhiskerCategoryDataset0.getRangeUpperBound(false);
        int int5 = defaultBoxAndWhiskerCategoryDataset0.getRowCount();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace9 = xYPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation(axisLocation10);
        xYPlot6.setRangeCrosshairValue(1.0d);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot6.setNoDataMessageFont(font14);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis18, valueAxis20, xYItemRenderer21);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot22);
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = blockBorder28.getInsets();
        double double30 = rectangleInsets29.getRight();
        xYPlot22.setInsets(rectangleInsets29);
        java.awt.Color color32 = java.awt.Color.YELLOW;
        xYPlot22.setDomainTickBandPaint((java.awt.Paint) color32);
        xYPlot6.setDomainGridlinePaint((java.awt.Paint) color32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation(axisLocation35, false);
        org.jfree.chart.axis.ValueAxis valueAxis38 = xYPlot6.getDomainAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = xYPlot6.getRenderer(3);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(valueAxis38);
        org.junit.Assert.assertNull(xYItemRenderer40);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape6 = numberAxis5.getLeftArrow();
        java.awt.Color color7 = java.awt.Color.darkGray;
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color9 = java.awt.Color.darkGray;
        java.awt.Color color10 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer11 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color7, paint8, (java.awt.Paint) color9, (java.awt.Paint) color10);
        java.awt.Paint paint12 = waterfallBarRenderer11.getLastBarPaint();
        java.awt.Color color13 = java.awt.Color.darkGray;
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color15 = java.awt.Color.darkGray;
        java.awt.Color color16 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer17 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color13, paint14, (java.awt.Paint) color15, (java.awt.Paint) color16);
        java.awt.Color color18 = java.awt.Color.cyan;
        waterfallBarRenderer17.setBaseOutlinePaint((java.awt.Paint) color18);
        java.awt.Color color20 = java.awt.Color.darkGray;
        java.awt.Paint paint21 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color22 = java.awt.Color.darkGray;
        java.awt.Color color23 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer24 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color20, paint21, (java.awt.Paint) color22, (java.awt.Paint) color23);
        waterfallBarRenderer17.setBaseOutlinePaint(paint21);
        java.awt.Color color26 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel27 = null;
        java.awt.Rectangle rectangle28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        java.awt.geom.AffineTransform affineTransform30 = null;
        java.awt.RenderingHints renderingHints31 = null;
        java.awt.PaintContext paintContext32 = color26.createContext(colorModel27, rectangle28, rectangle2D29, affineTransform30, renderingHints31);
        int int33 = color26.getTransparency();
        java.awt.Color color34 = color26.darker();
        java.awt.Color color35 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color35.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        int int42 = color35.getTransparency();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer43 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint12, paint21, (java.awt.Paint) color26, (java.awt.Paint) color35);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier44 = waterfallBarRenderer43.getDrawingSupplier();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = null;
        waterfallBarRenderer43.setPositiveItemLabelPositionFallback(itemLabelPosition45);
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean49 = numberAxis48.isNegativeArrowVisible();
        numberAxis48.resizeRange((double) 100);
        numberAxis48.resizeRange((double) 100L);
        numberAxis48.setTickMarksVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean58 = numberAxis57.isNegativeArrowVisible();
        numberAxis57.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape63 = numberAxis62.getLeftArrow();
        numberAxis57.setLeftArrow(shape63);
        java.awt.Shape shape67 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape63, 0.0d, (double) (byte) -1);
        numberAxis48.setDownArrow(shape63);
        waterfallBarRenderer43.setBaseShape(shape63, true);
        org.jfree.chart.entity.ChartEntity chartEntity73 = new org.jfree.chart.entity.ChartEntity(shape63, "Other", "0");
        numberAxis5.setRightArrow(shape63);
        java.awt.Color color75 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel76 = null;
        java.awt.Rectangle rectangle77 = null;
        java.awt.geom.Rectangle2D rectangle2D78 = null;
        java.awt.geom.AffineTransform affineTransform79 = null;
        java.awt.RenderingHints renderingHints80 = null;
        java.awt.PaintContext paintContext81 = color75.createContext(colorModel76, rectangle77, rectangle2D78, affineTransform79, renderingHints80);
        int int82 = color75.getTransparency();
        java.awt.Color color83 = color75.darker();
        org.jfree.chart.LegendItem legendItem84 = new org.jfree.chart.LegendItem("TextAnchor.CENTER_RIGHT", "PlotOrientation.VERTICAL", "ThreadContext", "AreaRendererEndType.LEVEL", shape63, (java.awt.Paint) color83);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paintContext32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(drawingSupplier44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNotNull(shape67);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(paintContext81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
        org.junit.Assert.assertNotNull(color83);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("", "", "{0}", "java.awt.Color[r=64,g=64,b=64]");
        java.lang.String str5 = library4.getName();
        java.lang.String str6 = library4.getName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        jFreeChart7.setTextAntiAlias(false);
        boolean boolean10 = jFreeChart7.getAntiAlias();
        boolean boolean11 = jFreeChart7.isNotify();
        boolean boolean12 = jFreeChart7.getAntiAlias();
        java.awt.Image image13 = jFreeChart7.getBackgroundImage();
        int int14 = jFreeChart7.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(image13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D1 = chartRenderingInfo0.getChartArea();
        org.junit.Assert.assertNotNull(rectangle2D1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = stackedBarRenderer3D3.getNegativeItemLabelPositionFallback();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = stackedBarRenderer3D10.getLegendItemURLGenerator();
        java.awt.Paint paint13 = stackedBarRenderer3D10.getSeriesPaint(3);
        boolean boolean14 = stackedBarRenderer3D10.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator19 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D10.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator19, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = stackedBarRenderer3D10.getPositiveItemLabelPosition(2, (-452));
        try {
            stackedBarRenderer3D3.setSeriesPositiveItemLabelPosition((-452), itemLabelPosition24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("{0}", font3);
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        plotRenderingInfo1.setPlotArea(rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.AffineTransform affineTransform11 = null;
        java.awt.RenderingHints renderingHints12 = null;
        java.awt.PaintContext paintContext13 = color7.createContext(colorModel8, rectangle9, rectangle2D10, affineTransform11, renderingHints12);
        int int14 = color7.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D5, (java.awt.Paint) color7);
        boolean boolean16 = legendGraphic15.isShapeFilled();
        org.jfree.chart.block.BlockFrame blockFrame17 = legendGraphic15.getFrame();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintContext13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(blockFrame17);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.setAutoTickUnitSelection(false, false);
        numberAxis1.setLabel("ThreadContext");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = numberAxis1.getTickUnit();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = numberAxis1.getTickUnit();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(numberTickUnit8);
        org.junit.Assert.assertNotNull(numberTickUnit9);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("RectangleEdge.BOTTOM", (org.jfree.data.time.TimePeriod) month1);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        java.lang.Object obj4 = standardCategoryURLGenerator3.clone();
        boolean boolean5 = task2.equals(obj4);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.gantt.Task task8 = new org.jfree.data.gantt.Task("RectangleEdge.BOTTOM", (org.jfree.data.time.TimePeriod) month7);
        task2.removeSubtask(task8);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 12);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator12 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean13 = valueMarker11.equals((java.lang.Object) standardCategoryToolTipGenerator12);
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) task2, (java.lang.Object) standardCategoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 15, (double) 8);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class1 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date5, date11);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) date5);
        java.lang.Comparable comparable14 = null;
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset13, comparable14, 100.0d, (int) '#');
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset13);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator20 = ringPlot19.getURLGenerator();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(pieURLGenerator20);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Comparable comparable1 = null;
        try {
            java.lang.Number number3 = taskSeriesCollection0.getPercentComplete(comparable1, (java.lang.Comparable) "({0}, {1}) = {3} - {4}");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean6 = numberAxis5.isNegativeArrowVisible();
        numberAxis5.resizeRange((double) 100);
        numberAxis5.resizeRange((double) 100L);
        numberAxis5.setTickMarksVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean15 = numberAxis14.isNegativeArrowVisible();
        numberAxis14.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape20 = numberAxis19.getLeftArrow();
        numberAxis14.setLeftArrow(shape20);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape20, 0.0d, (double) (byte) -1);
        numberAxis5.setDownArrow(shape20);
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint27 = null;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("{0}", "{0}", "ThreadContext", "ThreadContext", shape20, stroke26, paint27);
        org.jfree.data.general.Dataset dataset29 = legendItem28.getDataset();
        boolean boolean30 = legendItem28.isShapeVisible();
        java.lang.String str31 = legendItem28.getLabel();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(dataset29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "{0}" + "'", str31.equals("{0}"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = stackedBarRenderer3D3.getSeriesPositiveItemLabelPosition(0);
        stackedBarRenderer3D3.setIncludeBaseInRange(true);
        boolean boolean9 = stackedBarRenderer3D3.getIncludeBaseInRange();
        java.awt.Paint paint11 = stackedBarRenderer3D3.getSeriesOutlinePaint((-452));
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) '4', (double) (short) 1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.lang.String str4 = textAnchor3.toString();
        org.jfree.chart.axis.CategoryTick categoryTick6 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) (short) 1, textBlock1, textBlockAnchor2, textAnchor3, 6.0d);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot7.getDomainAxisLocation();
        java.awt.Color color10 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot7.setRangeGridlinePaint((java.awt.Paint) color10);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape16 = numberAxis15.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) numberAxis15, valueAxis17, xYItemRenderer18);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot19);
        org.jfree.chart.axis.ValueAxis valueAxis21 = xYPlot19.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot19.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot19.setDomainAxisLocation(10, axisLocation25, false);
        categoryPlot7.setDomainAxisLocation(12, axisLocation25);
        java.awt.Stroke stroke29 = categoryPlot7.getDomainGridlineStroke();
        boolean boolean30 = categoryTick6.equals((java.lang.Object) stroke29);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str4.equals("TextAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(valueAxis21);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.removeColumn((java.lang.Comparable) (-49.5d));
        java.util.List list3 = defaultKeyedValues2D0.getRowKeys();
        try {
            java.lang.Comparable comparable5 = defaultKeyedValues2D0.getRowKey((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.removeColumn((java.lang.Comparable) (-49.5d));
        int int3 = defaultKeyedValues2D0.getRowCount();
        int int5 = defaultKeyedValues2D0.getColumnIndex((java.lang.Comparable) 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot0.getDomainAxis((int) (byte) 0);
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = stackedBarRenderer3D11.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedBarRenderer3D11.getSeriesPositiveItemLabelPosition(0);
        stackedBarRenderer3D11.setItemLabelAnchorOffset((double) '#');
        boolean boolean17 = stackedBarRenderer3D11.getAutoPopulateSeriesPaint();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D11, false);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        categoryPlot0.setRangeAxis(0, valueAxis21);
        java.awt.Stroke stroke23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeGridlineStroke(stroke23);
        java.awt.Color color25 = java.awt.Color.darkGray;
        java.awt.Paint paint26 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color27 = java.awt.Color.darkGray;
        java.awt.Color color28 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer29 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color25, paint26, (java.awt.Paint) color27, (java.awt.Paint) color28);
        java.awt.Color color30 = java.awt.Color.darkGray;
        java.awt.Paint paint31 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color32 = java.awt.Color.darkGray;
        java.awt.Color color33 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer34 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color30, paint31, (java.awt.Paint) color32, (java.awt.Paint) color33);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = new org.jfree.chart.labels.ItemLabelPosition();
        waterfallBarRenderer34.setBasePositiveItemLabelPosition(itemLabelPosition35, true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D41 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        java.awt.Color color42 = java.awt.Color.darkGray;
        java.awt.Paint paint43 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color44 = java.awt.Color.darkGray;
        java.awt.Color color45 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer46 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color42, paint43, (java.awt.Paint) color44, (java.awt.Paint) color45);
        stackedBarRenderer3D41.setBasePaint(paint43, false);
        waterfallBarRenderer34.setBaseItemLabelPaint(paint43);
        java.awt.Color color50 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color51 = color50.brighter();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D53 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.awt.Paint paint54 = categoryAxis3D53.getLabelPaint();
        java.awt.Paint paint55 = categoryAxis3D53.getLabelPaint();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer56 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color27, paint43, (java.awt.Paint) color50, paint55);
        boolean boolean57 = categoryPlot0.equals((java.lang.Object) paint43);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight(2958465);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot0.getRangeMarkers((int) (short) 10, layer4);
        java.lang.String str6 = categoryPlot0.getPlotType();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double10 = categoryAxis3D9.getLowerMargin();
        categoryPlot0.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D9);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Color color15 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer16 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color12, paint13, (java.awt.Paint) color14, (java.awt.Paint) color15);
        java.awt.Paint paint17 = waterfallBarRenderer16.getLastBarPaint();
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Paint paint19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color20 = java.awt.Color.darkGray;
        java.awt.Color color21 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer22 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color18, paint19, (java.awt.Paint) color20, (java.awt.Paint) color21);
        java.awt.Color color23 = java.awt.Color.cyan;
        waterfallBarRenderer22.setBaseOutlinePaint((java.awt.Paint) color23);
        java.awt.Color color25 = java.awt.Color.darkGray;
        java.awt.Paint paint26 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color27 = java.awt.Color.darkGray;
        java.awt.Color color28 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer29 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color25, paint26, (java.awt.Paint) color27, (java.awt.Paint) color28);
        waterfallBarRenderer22.setBaseOutlinePaint(paint26);
        java.awt.Color color31 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel32 = null;
        java.awt.Rectangle rectangle33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.awt.geom.AffineTransform affineTransform35 = null;
        java.awt.RenderingHints renderingHints36 = null;
        java.awt.PaintContext paintContext37 = color31.createContext(colorModel32, rectangle33, rectangle2D34, affineTransform35, renderingHints36);
        int int38 = color31.getTransparency();
        java.awt.Color color39 = color31.darker();
        java.awt.Color color40 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel41 = null;
        java.awt.Rectangle rectangle42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        java.awt.geom.AffineTransform affineTransform44 = null;
        java.awt.RenderingHints renderingHints45 = null;
        java.awt.PaintContext paintContext46 = color40.createContext(colorModel41, rectangle42, rectangle2D43, affineTransform44, renderingHints45);
        int int47 = color40.getTransparency();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer48 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint17, paint26, (java.awt.Paint) color31, (java.awt.Paint) color40);
        categoryPlot0.setRangeGridlinePaint(paint26);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo52 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo52);
        java.awt.Font font55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock56 = new org.jfree.chart.block.LabelBlock("{0}", font55);
        java.awt.geom.Rectangle2D rectangle2D57 = labelBlock56.getBounds();
        plotRenderingInfo53.setPlotArea(rectangle2D57);
        org.jfree.chart.renderer.RendererState rendererState59 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo53);
        java.awt.geom.Point2D point2D60 = null;
        categoryPlot0.zoomDomainAxes((double) 0.8f, (double) 10, plotRenderingInfo53, point2D60);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paintContext37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(paintContext46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNotNull(rectangle2D57);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 0, (int) '4', (int) (byte) 100);
        org.jfree.chart.block.BorderArrangement borderArrangement4 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) borderArrangement4);
        java.lang.Object obj6 = null;
        boolean boolean7 = segmentedTimeline3.equals(obj6);
        java.util.Date date9 = segmentedTimeline3.getDate(1L);
        long long11 = segmentedTimeline3.getTimeFromLong((long) 4);
        long long12 = segmentedTimeline3.getSegmentsGroupSize();
        segmentedTimeline3.setAdjustForDaylightSaving(false);
        segmentedTimeline3.setAdjustForDaylightSaving(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 4L + "'", long11 == 4L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class3 = null;
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date7 = dateRange6.getUpperDate();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date7, timeZone8);
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date13 = dateRange12.getUpperDate();
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange(date7, date13);
        org.jfree.data.general.PieDataset pieDataset15 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2, (java.lang.Comparable) date7);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date7);
        java.util.Date date17 = month16.getEnd();
        int int18 = keyedObjects2D0.getRowIndex((java.lang.Comparable) date17);
        int int20 = keyedObjects2D0.getRowIndex((java.lang.Comparable) "TextAnchor.CENTER_RIGHT");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(pieDataset15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.RIGHT" + "'", str1.equals("RectangleAnchor.RIGHT"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace9 = xYPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation(axisLocation10);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Color color15 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer16 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color12, paint13, (java.awt.Paint) color14, (java.awt.Paint) color15);
        xYPlot6.setDomainCrosshairPaint((java.awt.Paint) color14);
        org.jfree.chart.block.FlowArrangement flowArrangement18 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BorderArrangement borderArrangement19 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean21 = borderArrangement19.equals((java.lang.Object) (-1.0f));
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot6, (org.jfree.chart.block.Arrangement) flowArrangement18, (org.jfree.chart.block.Arrangement) borderArrangement19);
        double double23 = legendTitle22.getWidth();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 100L);
        java.util.List list3 = keyedObjects2D0.getColumnKeys();
        try {
            keyedObjects2D0.removeColumn(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.removeColumn((java.lang.Comparable) (-49.5d));
        java.util.List list3 = defaultKeyedValues2D0.getRowKeys();
        java.lang.Comparable comparable4 = null;
        try {
            java.lang.Number number6 = defaultKeyedValues2D0.getValue(comparable4, (java.lang.Comparable) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        stackedBarRenderer3D3.setBaseSeriesVisibleInLegend(false);
        stackedBarRenderer3D3.setSeriesVisible((int) ' ', (java.lang.Boolean) true, false);
        boolean boolean10 = stackedBarRenderer3D3.isDrawBarOutline();
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Color color15 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer16 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color12, paint13, (java.awt.Paint) color14, (java.awt.Paint) color15);
        stackedBarRenderer3D3.setSeriesFillPaint((int) (short) 100, (java.awt.Paint) color15);
        boolean boolean20 = stackedBarRenderer3D3.isItemLabelVisible(100, 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        numberAxis1.resizeRange((double) 100L);
        numberAxis1.setTickMarksVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean11 = numberAxis10.isNegativeArrowVisible();
        numberAxis10.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape16 = numberAxis15.getLeftArrow();
        numberAxis10.setLeftArrow(shape16);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape16, 0.0d, (double) (byte) -1);
        numberAxis1.setDownArrow(shape16);
        boolean boolean22 = numberAxis1.isVerticalTickLabels();
        numberAxis1.setAutoTickUnitSelection(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color3 = java.awt.Color.darkGray;
        java.awt.Color color4 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer5 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color1, paint2, (java.awt.Paint) color3, (java.awt.Paint) color4);
        java.awt.Color color6 = java.awt.Color.cyan;
        waterfallBarRenderer5.setBaseOutlinePaint((java.awt.Paint) color6);
        java.awt.Stroke stroke8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        waterfallBarRenderer5.setBaseStroke(stroke8, false);
        boolean boolean11 = sortOrder0.equals((java.lang.Object) waterfallBarRenderer5);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = stackedBarRenderer3D15.getLegendItemURLGenerator();
        java.awt.Stroke stroke17 = stackedBarRenderer3D15.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedBarRenderer3D15.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor20 = itemLabelPosition19.getItemLabelAnchor();
        waterfallBarRenderer5.setNegativeItemLabelPositionFallback(itemLabelPosition19);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(itemLabelAnchor20);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("{0}", font3);
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        plotRenderingInfo1.setPlotArea(rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.AffineTransform affineTransform11 = null;
        java.awt.RenderingHints renderingHints12 = null;
        java.awt.PaintContext paintContext13 = color7.createContext(colorModel8, rectangle9, rectangle2D10, affineTransform11, renderingHints12);
        int int14 = color7.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D5, (java.awt.Paint) color7);
        boolean boolean16 = legendGraphic15.isShapeVisible();
        java.awt.Paint paint17 = legendGraphic15.getFillPaint();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        legendGraphic15.setOutlineStroke(stroke18);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintContext13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot6.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean13 = numberAxis12.isNegativeArrowVisible();
        numberAxis12.resizeRange((double) 100);
        boolean boolean17 = numberAxis12.equals((java.lang.Object) 12);
        double double18 = numberAxis12.getLowerBound();
        java.text.NumberFormat numberFormat19 = numberAxis12.getNumberFormatOverride();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape23 = numberAxis22.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) numberAxis22, valueAxis24, xYItemRenderer25);
        xYPlot26.setBackgroundImageAlignment((int) (byte) -1);
        float float29 = xYPlot26.getForegroundAlpha();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator34 = stackedBarRenderer3D33.getLegendItemURLGenerator();
        java.awt.Stroke stroke35 = stackedBarRenderer3D33.getBaseStroke();
        xYPlot26.setOutlineStroke(stroke35);
        numberAxis12.setAxisLineStroke(stroke35);
        xYPlot6.setRangeGridlineStroke(stroke35);
        xYPlot6.mapDatasetToRangeAxis(0, 4);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-49.5d) + "'", double18 == (-49.5d));
        org.junit.Assert.assertNull(numberFormat19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 1.0f + "'", float29 == 1.0f);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator34);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint1, (java.awt.Paint) color2, (java.awt.Paint) color3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape8 = numberAxis7.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis7, valueAxis9, xYItemRenderer10);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot11);
        jFreeChart12.setTextAntiAlias(false);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart12, chartChangeEventType15);
        org.jfree.chart.JFreeChart jFreeChart17 = chartChangeEvent16.getChart();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(chartChangeEventType15);
        org.junit.Assert.assertNotNull(jFreeChart17);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        java.awt.Color color2 = color1.darker();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        stackedBarRenderer3D3.setNegativeItemLabelPositionFallback(itemLabelPosition5);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        stackedBarRenderer3D3.setSeriesItemLabelGenerator(64, categoryItemLabelGenerator8, false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.removeColumn((java.lang.Comparable) (-49.5d));
        java.lang.Object obj3 = defaultKeyedValues2D0.clone();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.Class class6 = null;
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date10 = dateRange9.getUpperDate();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date10, timeZone11);
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date16 = dateRange15.getUpperDate();
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange(date10, date16);
        defaultKeyedValues2D0.addValue((java.lang.Number) 8.0d, (java.lang.Comparable) month5, (java.lang.Comparable) date10);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtLeft();
        java.util.List list2 = axisCollection0.getAxesAtBottom();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        xYPlot6.setBackgroundImageAlignment((int) (byte) -1);
        float float9 = xYPlot6.getForegroundAlpha();
        java.awt.Color color10 = java.awt.Color.darkGray;
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Color color13 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer14 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color10, paint11, (java.awt.Paint) color12, (java.awt.Paint) color13);
        java.awt.Paint paint15 = waterfallBarRenderer14.getLastBarPaint();
        java.awt.Color color16 = java.awt.Color.darkGray;
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Color color19 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer20 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color16, paint17, (java.awt.Paint) color18, (java.awt.Paint) color19);
        java.awt.Color color21 = java.awt.Color.cyan;
        waterfallBarRenderer20.setBaseOutlinePaint((java.awt.Paint) color21);
        java.awt.Color color23 = java.awt.Color.darkGray;
        java.awt.Paint paint24 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color25 = java.awt.Color.darkGray;
        java.awt.Color color26 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer27 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color23, paint24, (java.awt.Paint) color25, (java.awt.Paint) color26);
        waterfallBarRenderer20.setBaseOutlinePaint(paint24);
        java.awt.Color color29 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel30 = null;
        java.awt.Rectangle rectangle31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.awt.geom.AffineTransform affineTransform33 = null;
        java.awt.RenderingHints renderingHints34 = null;
        java.awt.PaintContext paintContext35 = color29.createContext(colorModel30, rectangle31, rectangle2D32, affineTransform33, renderingHints34);
        int int36 = color29.getTransparency();
        java.awt.Color color37 = color29.darker();
        java.awt.Color color38 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel39 = null;
        java.awt.Rectangle rectangle40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.geom.AffineTransform affineTransform42 = null;
        java.awt.RenderingHints renderingHints43 = null;
        java.awt.PaintContext paintContext44 = color38.createContext(colorModel39, rectangle40, rectangle2D41, affineTransform42, renderingHints43);
        int int45 = color38.getTransparency();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer46 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint15, paint24, (java.awt.Paint) color29, (java.awt.Paint) color38);
        xYPlot6.setDomainTickBandPaint((java.awt.Paint) color38);
        xYPlot6.setForegroundAlpha(0.0f);
        int int50 = xYPlot6.getDomainAxisCount();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paintContext35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(paintContext44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) (byte) -1);
        double double4 = rectangleInsets0.calculateBottomInset((double) (byte) 1);
        double double6 = rectangleInsets0.calculateBottomInset((double) '#');
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.0d) + "'", double2 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((-1.0d), (double) (-452));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (-1.0) <= upper (-452.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getRowKeys();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int4 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) 10.0d);
        java.lang.Object obj5 = defaultStatisticalCategoryDataset0.clone();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getPaint();
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        textTitle0.setPaint(paint2);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent4 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        java.lang.Object obj5 = textTitle0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Class class2 = null;
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date6 = dateRange5.getUpperDate();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date6, timeZone7);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date12 = dateRange11.getUpperDate();
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange(date6, date12);
        keyedObjects2D0.removeObject((java.lang.Comparable) "org.jfree.data.time.TimePeriodFormatException: ", (java.lang.Comparable) date6);
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date18 = dateRange17.getUpperDate();
        try {
            keyedObjects2D0.removeRow((java.lang.Comparable) date18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        try {
            java.lang.String str2 = dataPackageResources0.getString("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setStartPercent((-5.0d));
        double double3 = ganttRenderer0.getStartPercent();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-5.0d) + "'", double3 == (-5.0d));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getRowKeys();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int4 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) 10.0d);
        java.text.DateFormat dateFormat7 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = new org.jfree.chart.axis.DateTickUnit(3, (int) 'a', dateFormat7);
        int int9 = dateTickUnit8.getCount();
        java.lang.Comparable comparable10 = null;
        java.lang.Number number11 = defaultStatisticalCategoryDataset0.getStdDevValue((java.lang.Comparable) dateTickUnit8, comparable10);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNull(number11);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator0 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        boolean boolean2 = standardCategoryURLGenerator0.equals((java.lang.Object) multiplePiePlot1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtTop();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        xYPlot6.setBackgroundImageAlignment((int) (byte) -1);
        float float9 = xYPlot6.getForegroundAlpha();
        int int10 = xYPlot6.getWeight();
        xYPlot6.setDomainCrosshairValue((double) (short) 1, false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape9 = numberAxis8.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis8, valueAxis10, xYItemRenderer11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot12.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot12.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setDomainAxisLocation(10, axisLocation18, false);
        categoryPlot0.setDomainAxisLocation(12, axisLocation18);
        java.awt.Stroke stroke22 = categoryPlot0.getDomainGridlineStroke();
        categoryPlot0.setAnchorValue(0.0d, true);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(axisLocation26);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = categoryPlot0.getDomainMarkers(1, layer29);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNull(collection30);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape4 = numberAxis3.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3, valueAxis5, xYItemRenderer6);
        xYPlot7.setBackgroundImageAlignment((int) (byte) -1);
        float float10 = xYPlot7.getForegroundAlpha();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator15 = stackedBarRenderer3D14.getLegendItemURLGenerator();
        java.awt.Stroke stroke16 = stackedBarRenderer3D14.getBaseStroke();
        xYPlot7.setOutlineStroke(stroke16);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) xYPlot7);
        jFreeChart18.setTextAntiAlias(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection26 = null;
        chartRenderingInfo25.setEntityCollection(entityCollection26);
        java.awt.image.BufferedImage bufferedImage28 = jFreeChart18.createBufferedImage((int) ' ', 3, (double) 0.0f, 100.0d, chartRenderingInfo25);
        java.lang.Object obj29 = chartRenderingInfo25.clone();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(bufferedImage28);
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 5, (byte) 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 5, (byte) 10 };
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray4, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.CENTER_RIGHT", "ThreadContext", numberArray8);
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 5, (byte) 10 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 5, (byte) 10 };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray14, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.CENTER_RIGHT", "ThreadContext", numberArray18);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray8, numberArray18);
        java.lang.Comparable[] comparableArray21 = new java.lang.Comparable[] {};
        java.lang.String[] strArray22 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray23 = null;
        java.lang.Number[][] numberArray24 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset25 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray21, (java.lang.Comparable[]) strArray22, numberArray23, numberArray24);
        try {
            defaultIntervalCategoryDataset20.setCategoryKeys((java.lang.Comparable[]) strArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of categories does not match the data.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(comparableArray21);
        org.junit.Assert.assertNotNull(strArray22);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        double double4 = stackedBarRenderer3D3.getBase();
        java.awt.Paint paint7 = stackedBarRenderer3D3.getItemLabelPaint((int) '4', 8);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = stackedBarRenderer3D4.getLegendItemURLGenerator();
        java.awt.Paint paint7 = stackedBarRenderer3D4.getSeriesPaint(3);
        boolean boolean8 = stackedBarRenderer3D4.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator13 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D4.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator13, true);
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("{0}", font18);
        java.awt.geom.Rectangle2D rectangle2D20 = labelBlock19.getBounds();
        stackedBarRenderer3D4.setSeriesShape(5, (java.awt.Shape) rectangle2D20);
        boolean boolean22 = year0.equals((java.lang.Object) 5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year0.previous();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double14 = rectangleInsets13.getRight();
        xYPlot6.setInsets(rectangleInsets13);
        java.lang.Object obj16 = xYPlot6.clone();
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot6.getDataset(3);
        xYPlot6.setDomainCrosshairValue((double) 3, true);
        java.lang.String str22 = xYPlot6.getPlotType();
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean26 = numberAxis25.isNegativeArrowVisible();
        numberAxis25.resizeRange((double) 100);
        numberAxis25.resizeRange((double) 100L);
        numberAxis25.setTickMarksVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean35 = numberAxis34.isNegativeArrowVisible();
        numberAxis34.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape40 = numberAxis39.getLeftArrow();
        numberAxis34.setLeftArrow(shape40);
        java.awt.Shape shape44 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape40, 0.0d, (double) (byte) -1);
        numberAxis25.setDownArrow(shape40);
        java.awt.Font font46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        numberAxis25.setLabelFont(font46);
        java.awt.Font font52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand53 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis25, (double) 100.0f, (double) (-1), (double) 12, 99.0d, font52);
        xYPlot6.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis25, false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "XY Plot" + "'", str22.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(font52);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace9 = xYPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation(axisLocation10);
        xYPlot6.setRangeCrosshairValue(1.0d);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot6.setNoDataMessageFont(font14);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis18, valueAxis20, xYItemRenderer21);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot22);
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = blockBorder28.getInsets();
        double double30 = rectangleInsets29.getRight();
        xYPlot22.setInsets(rectangleInsets29);
        java.awt.Color color32 = java.awt.Color.YELLOW;
        xYPlot22.setDomainTickBandPaint((java.awt.Paint) color32);
        xYPlot6.setDomainGridlinePaint((java.awt.Paint) color32);
        java.awt.Color color35 = java.awt.Color.black;
        float[] floatArray42 = new float[] { (byte) -1, 10, (short) 0, (byte) 0, 2958465, (short) 1 };
        float[] floatArray43 = color35.getComponents(floatArray42);
        float[] floatArray44 = color32.getRGBColorComponents(floatArray43);
        java.awt.Color color48 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel49 = null;
        java.awt.Rectangle rectangle50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        java.awt.geom.AffineTransform affineTransform52 = null;
        java.awt.RenderingHints renderingHints53 = null;
        java.awt.PaintContext paintContext54 = color48.createContext(colorModel49, rectangle50, rectangle2D51, affineTransform52, renderingHints53);
        int int55 = color48.getTransparency();
        java.awt.Color color56 = color48.darker();
        java.awt.Color color57 = java.awt.Color.black;
        float[] floatArray64 = new float[] { (byte) -1, 10, (short) 0, (byte) 0, 2958465, (short) 1 };
        float[] floatArray65 = color57.getComponents(floatArray64);
        float[] floatArray66 = color48.getColorComponents(floatArray65);
        float[] floatArray67 = java.awt.Color.RGBtoHSB((int) (byte) 10, (-1), 6, floatArray65);
        float[] floatArray68 = color32.getColorComponents(floatArray67);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(paintContext54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(floatArray64);
        org.junit.Assert.assertNotNull(floatArray65);
        org.junit.Assert.assertNotNull(floatArray66);
        org.junit.Assert.assertNotNull(floatArray67);
        org.junit.Assert.assertNotNull(floatArray68);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.darkGray;
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color7 = java.awt.Color.darkGray;
        java.awt.Color color8 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer9 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color5, paint6, (java.awt.Paint) color7, (java.awt.Paint) color8);
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        waterfallBarRenderer9.setFirstBarPaint(paint10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot12.getDomainAxisLocation();
        java.awt.Color color15 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot12.setRangeGridlinePaint((java.awt.Paint) color15);
        waterfallBarRenderer9.setBasePaint((java.awt.Paint) color15);
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("TextAnchor.CENTER_RIGHT", "DateTickUnit[HOUR, 97]", "XY Plot", "org.jfree.data.time.TimePeriodFormatException: ", shape4, (java.awt.Paint) color15);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            defaultKeyedValues2D0.removeColumn(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("0");
        numberAxis3D1.setPositiveArrowVisible(false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint1, (java.awt.Paint) color2, (java.awt.Paint) color3);
        int int5 = color0.getTransparency();
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color8 = java.awt.Color.darkGray;
        java.awt.Color color9 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer10 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color6, paint7, (java.awt.Paint) color8, (java.awt.Paint) color9);
        java.awt.Color color11 = java.awt.Color.cyan;
        waterfallBarRenderer10.setBaseOutlinePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        waterfallBarRenderer10.setBaseStroke(stroke13, false);
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = blockBorder20.getInsets();
        double double23 = rectangleInsets21.calculateTopInset(0.0d);
        org.jfree.chart.block.LineBorder lineBorder24 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke13, rectangleInsets21);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D28 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedBarRenderer3D28.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedBarRenderer3D28.getSeriesPaint(3);
        boolean boolean32 = stackedBarRenderer3D28.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator37 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D28.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator37, true);
        java.awt.Font font42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock43 = new org.jfree.chart.block.LabelBlock("{0}", font42);
        java.awt.geom.Rectangle2D rectangle2D44 = labelBlock43.getBounds();
        stackedBarRenderer3D28.setSeriesShape(5, (java.awt.Shape) rectangle2D44);
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets21.createInsetRectangle(rectangle2D44);
        org.jfree.chart.entity.ChartEntity chartEntity49 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D46, "ERROR : Relative To String", "DatasetRenderingOrder.REVERSE");
        java.lang.String str50 = chartEntity49.getToolTipText();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-1.0d) + "'", double23 == (-1.0d));
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "ERROR : Relative To String" + "'", str50.equals("ERROR : Relative To String"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.Object obj2 = categoryAxis3D1.clone();
        categoryAxis3D1.setTickMarksVisible(true);
        categoryAxis3D1.configure();
        categoryAxis3D1.removeCategoryLabelToolTip((java.lang.Comparable) 0.65d);
        categoryAxis3D1.removeCategoryLabelToolTip((java.lang.Comparable) 2958465);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedWidth((double) 5);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint0.toFixedHeight((double) 86400000L);
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) -1, 3, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        double double5 = stackedBarRenderer3D4.getBase();
        java.lang.Class<?> wildcardClass6 = stackedBarRenderer3D4.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        java.lang.Object obj8 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("DatasetRenderingOrder.REVERSE", (java.lang.Class) wildcardClass6);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNull(obj8);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        boolean boolean6 = numberAxis1.equals((java.lang.Object) 12);
        boolean boolean7 = numberAxis1.isVisible();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(markerAxisBand8);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        numberAxis1.resizeRange((double) 100L);
        org.jfree.chart.plot.Plot plot7 = numberAxis1.getPlot();
        try {
            numberAxis1.setRangeWithMargins(9.223372036854776E18d, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (9.223372036854776E18) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(plot7);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape4 = numberAxis3.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3, valueAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot7.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace10 = xYPlot7.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot7.setRangeAxisLocation(axisLocation11);
        java.awt.Color color13 = java.awt.Color.darkGray;
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color15 = java.awt.Color.darkGray;
        java.awt.Color color16 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer17 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color13, paint14, (java.awt.Paint) color15, (java.awt.Paint) color16);
        xYPlot7.setDomainCrosshairPaint((java.awt.Paint) color15);
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BorderArrangement borderArrangement20 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean22 = borderArrangement20.equals((java.lang.Object) (-1.0f));
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot7, (org.jfree.chart.block.Arrangement) flowArrangement19, (org.jfree.chart.block.Arrangement) borderArrangement20);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment25 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        boolean boolean27 = verticalAlignment25.equals((java.lang.Object) 3.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement30 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment24, verticalAlignment25, (double) 0L, (double) 3);
        org.jfree.chart.util.VerticalAlignment verticalAlignment31 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        boolean boolean33 = verticalAlignment31.equals((java.lang.Object) 3.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement36 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment24, verticalAlignment31, 10.0d, (double) 10L);
        java.awt.Font font38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock39 = new org.jfree.chart.block.LabelBlock("{0}", font38);
        java.awt.geom.Rectangle2D rectangle2D40 = labelBlock39.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation42 = categoryPlot41.getDomainAxisLocation();
        int int43 = categoryPlot41.getRangeAxisCount();
        columnArrangement36.add((org.jfree.chart.block.Block) labelBlock39, (java.lang.Object) int43);
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) flowArrangement19, (org.jfree.chart.block.Arrangement) columnArrangement36);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(verticalAlignment25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(verticalAlignment31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 0, (int) '4', (int) (byte) 100);
        org.jfree.chart.block.BorderArrangement borderArrangement4 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) borderArrangement4);
        java.lang.Object obj6 = null;
        boolean boolean7 = segmentedTimeline3.equals(obj6);
        java.util.Date date9 = segmentedTimeline3.getDate(1L);
        int int10 = segmentedTimeline3.getSegmentsExcluded();
        java.text.DateFormat dateFormat13 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = new org.jfree.chart.axis.DateTickUnit(3, (int) 'a', dateFormat13);
        java.lang.Class class15 = null;
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date19 = dateRange18.getUpperDate();
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date19, timeZone20);
        org.jfree.data.time.DateRange dateRange24 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date25 = dateRange24.getUpperDate();
        org.jfree.data.time.DateRange dateRange26 = new org.jfree.data.time.DateRange(date19, date25);
        java.lang.Class class27 = null;
        org.jfree.data.time.DateRange dateRange30 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date31 = dateRange30.getUpperDate();
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date31, timeZone32);
        org.jfree.data.time.DateRange dateRange36 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date37 = dateRange36.getUpperDate();
        org.jfree.data.time.DateRange dateRange38 = new org.jfree.data.time.DateRange(date31, date37);
        org.jfree.data.time.DateRange dateRange39 = new org.jfree.data.time.DateRange(date25, date31);
        java.util.Date date40 = dateTickUnit14.addToDate(date25);
        try {
            boolean boolean41 = segmentedTimeline3.containsDomainValue(date40);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date40);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.gantt.TaskSeries taskSeries2 = taskSeriesCollection0.getSeries((java.lang.Comparable) 28799999L);
        java.util.List list3 = taskSeriesCollection0.getColumnKeys();
        org.junit.Assert.assertNull(taskSeries2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        double double1 = boxAndWhiskerRenderer0.getItemMargin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 'a', 0.0d, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 1, 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.lang.Class class0 = null;
        java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
        java.util.ResourceBundle.clearCache(classLoader1);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader1);
        org.junit.Assert.assertNotNull(classLoader1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint1 = ganttRenderer0.getCompletePaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Paint paint6 = stackedBarRenderer3D3.getSeriesPaint(3);
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = blockContainer7.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        blockContainer7.setPadding(rectangleInsets9);
        double double12 = rectangleInsets9.calculateTopOutset((double) 100);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("{0}", font16);
        java.awt.geom.Rectangle2D rectangle2D18 = labelBlock17.getBounds();
        plotRenderingInfo14.setPlotArea(rectangle2D18);
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets9.createOutsetRectangle(rectangle2D18, false, false);
        stackedBarRenderer3D3.setBaseShape((java.awt.Shape) rectangle2D22);
        stackedBarRenderer3D3.setBaseSeriesVisibleInLegend(false, false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D22);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        xYPlot6.setBackgroundImageAlignment((int) (byte) -1);
        float float9 = xYPlot6.getForegroundAlpha();
        java.awt.Color color10 = java.awt.Color.darkGray;
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Color color13 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer14 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color10, paint11, (java.awt.Paint) color12, (java.awt.Paint) color13);
        java.awt.Paint paint15 = waterfallBarRenderer14.getLastBarPaint();
        java.awt.Color color16 = java.awt.Color.darkGray;
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Color color19 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer20 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color16, paint17, (java.awt.Paint) color18, (java.awt.Paint) color19);
        java.awt.Color color21 = java.awt.Color.cyan;
        waterfallBarRenderer20.setBaseOutlinePaint((java.awt.Paint) color21);
        java.awt.Color color23 = java.awt.Color.darkGray;
        java.awt.Paint paint24 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color25 = java.awt.Color.darkGray;
        java.awt.Color color26 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer27 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color23, paint24, (java.awt.Paint) color25, (java.awt.Paint) color26);
        waterfallBarRenderer20.setBaseOutlinePaint(paint24);
        java.awt.Color color29 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel30 = null;
        java.awt.Rectangle rectangle31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.awt.geom.AffineTransform affineTransform33 = null;
        java.awt.RenderingHints renderingHints34 = null;
        java.awt.PaintContext paintContext35 = color29.createContext(colorModel30, rectangle31, rectangle2D32, affineTransform33, renderingHints34);
        int int36 = color29.getTransparency();
        java.awt.Color color37 = color29.darker();
        java.awt.Color color38 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel39 = null;
        java.awt.Rectangle rectangle40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.geom.AffineTransform affineTransform42 = null;
        java.awt.RenderingHints renderingHints43 = null;
        java.awt.PaintContext paintContext44 = color38.createContext(colorModel39, rectangle40, rectangle2D41, affineTransform42, renderingHints43);
        int int45 = color38.getTransparency();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer46 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint15, paint24, (java.awt.Paint) color29, (java.awt.Paint) color38);
        xYPlot6.setDomainTickBandPaint((java.awt.Paint) color38);
        xYPlot6.setForegroundAlpha(0.0f);
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean52 = numberAxis51.isNegativeArrowVisible();
        numberAxis51.resizeRange((double) 100);
        numberAxis51.resizeRange((double) 100L);
        numberAxis51.zoomRange((double) (short) -1, (double) 8);
        boolean boolean60 = xYPlot6.equals((java.lang.Object) numberAxis51);
        boolean boolean61 = xYPlot6.isDomainZoomable();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paintContext35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(paintContext44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.jfree.chart.axis.AxisCollection axisCollection1 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list2 = axisCollection1.getAxesAtRight();
        java.util.Collection collection3 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list2);
        boolean boolean4 = itemLabelAnchor0.equals((java.lang.Object) collection3);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(collection3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.LegendItem legendItem3 = lineRenderer3D0.getLegendItem(11, 11);
        java.awt.Paint paint4 = lineRenderer3D0.getWallPaint();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = lineRenderer3D0.getURLGenerator((int) (short) 10, 6);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryURLGenerator7);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape9 = numberAxis8.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis8, valueAxis10, xYItemRenderer11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot12.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot12.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setDomainAxisLocation(10, axisLocation18, false);
        categoryPlot0.setDomainAxisLocation(12, axisLocation18);
        java.awt.Stroke stroke22 = categoryPlot0.getDomainGridlineStroke();
        categoryPlot0.setAnchorValue(0.0d, true);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(axisLocation26);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(axisLocation26);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        java.awt.Color color9 = java.awt.Color.darkGray;
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color11 = java.awt.Color.darkGray;
        java.awt.Color color12 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer13 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color9, paint10, (java.awt.Paint) color11, (java.awt.Paint) color12);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape17 = numberAxis16.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) numberAxis16, valueAxis18, xYItemRenderer19);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot20);
        jFreeChart21.setTextAntiAlias(false);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType24 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart21, chartChangeEventType24);
        xYPlot6.setDomainGridlinePaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(chartChangeEventType24);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (double) '4');
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getHeightConstraintType();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(100);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears((int) (byte) 10, serialDate4);
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(100, serialDate7);
        try {
            org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) '#', serialDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 100L);
        java.util.List list3 = keyedObjects2D0.getColumnKeys();
        java.util.List list4 = keyedObjects2D0.getColumnKeys();
        try {
            keyedObjects2D0.removeRow((java.lang.Comparable) 99.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("http://www.jfree.org/jfreechart/index.html", "DateTickUnit[HOUR, 97]", "AreaRendererEndType.LEVEL");
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Color color7 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer8 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color4, paint5, (java.awt.Paint) color6, (java.awt.Paint) color7);
        stackedBarRenderer3D3.setBasePaint(paint5, false);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset11.setValue((double) 60000L, (java.lang.Comparable) 10.0f, (java.lang.Comparable) 2);
        org.jfree.data.Range range16 = stackedBarRenderer3D3.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11);
        double double17 = range16.getUpperBound();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("{0}", font7);
        java.awt.geom.Rectangle2D rectangle2D9 = labelBlock8.getBounds();
        plotRenderingInfo5.setPlotArea(rectangle2D9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape15 = numberAxis14.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis14, valueAxis16, xYItemRenderer17);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot18);
        org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot18.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot18.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean25 = numberAxis24.isNegativeArrowVisible();
        numberAxis24.resizeRange((double) 100);
        boolean boolean29 = numberAxis24.equals((java.lang.Object) 12);
        double double30 = numberAxis24.getLowerBound();
        java.text.NumberFormat numberFormat31 = numberAxis24.getNumberFormatOverride();
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape35 = numberAxis34.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) numberAxis34, valueAxis36, xYItemRenderer37);
        xYPlot38.setBackgroundImageAlignment((int) (byte) -1);
        float float41 = xYPlot38.getForegroundAlpha();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D45 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator46 = stackedBarRenderer3D45.getLegendItemURLGenerator();
        java.awt.Stroke stroke47 = stackedBarRenderer3D45.getBaseStroke();
        xYPlot38.setOutlineStroke(stroke47);
        numberAxis24.setAxisLineStroke(stroke47);
        xYPlot18.setRangeGridlineStroke(stroke47);
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.LegendItem legendItem52 = new org.jfree.chart.LegendItem("hi!", "org.jfree.data.time.TimePeriodFormatException: ", "hi!", "Preceding", (java.awt.Shape) rectangle2D9, paint11, stroke47, (java.awt.Paint) color51);
        java.awt.Shape shape55 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D9, (double) 97, (double) 12);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(valueAxis20);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-49.5d) + "'", double30 == (-49.5d));
        org.junit.Assert.assertNull(numberFormat31);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 1.0f + "'", float41 == 1.0f);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(shape55);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape7 = numberAxis6.getLeftArrow();
        numberAxis1.setLeftArrow(shape7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean11 = numberAxis10.isNegativeArrowVisible();
        numberAxis10.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape16 = numberAxis15.getLeftArrow();
        numberAxis10.setLeftArrow(shape16);
        numberAxis1.setDownArrow(shape16);
        numberAxis1.setTickLabelsVisible(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("UnitType.ABSOLUTE");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis1.getTickMarkPosition();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date6 = dateRange5.getUpperDate();
        java.awt.Color color7 = java.awt.Color.darkGray;
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color9 = java.awt.Color.darkGray;
        java.awt.Color color10 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer11 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color7, paint8, (java.awt.Paint) color9, (java.awt.Paint) color10);
        int int12 = color7.getTransparency();
        java.awt.Color color13 = java.awt.Color.darkGray;
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color15 = java.awt.Color.darkGray;
        java.awt.Color color16 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer17 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color13, paint14, (java.awt.Paint) color15, (java.awt.Paint) color16);
        java.awt.Color color18 = java.awt.Color.cyan;
        waterfallBarRenderer17.setBaseOutlinePaint((java.awt.Paint) color18);
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        waterfallBarRenderer17.setBaseStroke(stroke20, false);
        org.jfree.chart.block.BlockBorder blockBorder27 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = blockBorder27.getInsets();
        double double30 = rectangleInsets28.calculateTopInset(0.0d);
        org.jfree.chart.block.LineBorder lineBorder31 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color7, stroke20, rectangleInsets28);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator36 = stackedBarRenderer3D35.getLegendItemURLGenerator();
        java.awt.Paint paint38 = stackedBarRenderer3D35.getSeriesPaint(3);
        boolean boolean39 = stackedBarRenderer3D35.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator44 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D35.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator44, true);
        java.awt.Font font49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock50 = new org.jfree.chart.block.LabelBlock("{0}", font49);
        java.awt.geom.Rectangle2D rectangle2D51 = labelBlock50.getBounds();
        stackedBarRenderer3D35.setSeriesShape(5, (java.awt.Shape) rectangle2D51);
        java.awt.geom.Rectangle2D rectangle2D53 = rectangleInsets28.createInsetRectangle(rectangle2D51);
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        org.jfree.chart.axis.NumberAxis numberAxis56 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape57 = numberAxis56.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer59 = null;
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot(xYDataset54, (org.jfree.chart.axis.ValueAxis) numberAxis56, valueAxis58, xYItemRenderer59);
        org.jfree.chart.JFreeChart jFreeChart61 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot60);
        org.jfree.chart.axis.ValueAxis valueAxis62 = xYPlot60.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace63 = xYPlot60.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation64 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot60.setRangeAxisLocation(axisLocation64);
        xYPlot60.setRangeCrosshairValue(1.0d);
        java.awt.Font font68 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot60.setNoDataMessageFont(font68);
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = xYPlot60.getRangeAxisEdge(0);
        double double72 = dateAxis1.dateToJava2D(date6, rectangle2D51, rectangleEdge71);
        org.jfree.data.time.DateRange dateRange75 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        org.jfree.data.time.DateRange dateRange78 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date79 = dateRange78.getUpperDate();
        org.jfree.data.Range range80 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange75, (org.jfree.data.Range) dateRange78);
        dateAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange75);
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-1.0d) + "'", double30 == (-1.0d));
        org.junit.Assert.assertNull(categorySeriesLabelGenerator36);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(valueAxis62);
        org.junit.Assert.assertNull(axisSpace63);
        org.junit.Assert.assertNotNull(axisLocation64);
        org.junit.Assert.assertNotNull(font68);
        org.junit.Assert.assertNotNull(rectangleEdge71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertNotNull(range80);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        org.jfree.data.Range range5 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange2, (double) (byte) -1, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange2, (double) 2);
        org.jfree.data.Range range8 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint7.toRangeHeight(range8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("ThreadContext", "({0}, {1}) = {2}");
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        chartRenderingInfo0.setEntityCollection(entityCollection1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = chartRenderingInfo0.getPlotInfo();
        org.junit.Assert.assertNotNull(plotRenderingInfo3);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = stackedBarRenderer3D4.getLegendItemURLGenerator();
        java.awt.Paint paint7 = stackedBarRenderer3D4.getSeriesPaint(3);
        java.awt.Shape shape8 = stackedBarRenderer3D4.getBaseShape();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setWeight(2958465);
        int int13 = categoryPlot10.getDatasetCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot14.getDomainAxisLocation();
        java.awt.Color color17 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot14.setRangeGridlinePaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot14.getDomainAxis((int) (byte) 0);
        categoryPlot14.configureDomainAxes();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator26 = stackedBarRenderer3D25.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = stackedBarRenderer3D25.getSeriesPositiveItemLabelPosition(0);
        stackedBarRenderer3D25.setItemLabelAnchorOffset((double) '#');
        boolean boolean31 = stackedBarRenderer3D25.getAutoPopulateSeriesPaint();
        categoryPlot14.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D25, false);
        categoryPlot10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D25);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape38 = numberAxis37.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) numberAxis37, valueAxis39, xYItemRenderer40);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape45 = numberAxis44.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset42, (org.jfree.chart.axis.ValueAxis) numberAxis44, valueAxis46, xYItemRenderer47);
        org.jfree.chart.JFreeChart jFreeChart49 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot48);
        org.jfree.chart.axis.ValueAxis valueAxis50 = xYPlot48.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = xYPlot48.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation54 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot48.setDomainAxisLocation(10, axisLocation54, false);
        xYPlot41.setDomainAxisLocation(axisLocation54, true);
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis("hi!");
        xYPlot41.setRangeAxis((int) (byte) 10, (org.jfree.chart.axis.ValueAxis) numberAxis61);
        numberAxis61.setAutoRangeIncludesZero(false);
        org.jfree.chart.plot.ValueMarker valueMarker66 = new org.jfree.chart.plot.ValueMarker((double) 12);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator67 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean68 = valueMarker66.equals((java.lang.Object) standardCategoryToolTipGenerator67);
        org.jfree.chart.block.BlockContainer blockContainer69 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = blockContainer69.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        blockContainer69.setPadding(rectangleInsets71);
        double double74 = rectangleInsets71.calculateTopOutset((double) 100);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo75 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo76 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo75);
        java.awt.Font font78 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock79 = new org.jfree.chart.block.LabelBlock("{0}", font78);
        java.awt.geom.Rectangle2D rectangle2D80 = labelBlock79.getBounds();
        plotRenderingInfo76.setPlotArea(rectangle2D80);
        java.awt.geom.Rectangle2D rectangle2D84 = rectangleInsets71.createOutsetRectangle(rectangle2D80, false, false);
        stackedBarRenderer3D4.drawRangeMarker(graphics2D9, categoryPlot10, (org.jfree.chart.axis.ValueAxis) numberAxis61, (org.jfree.chart.plot.Marker) valueMarker66, rectangle2D84);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType86 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType87 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.awt.geom.Rectangle2D rectangle2D88 = rectangleInsets0.createAdjustedRectangle(rectangle2D84, lengthAdjustmentType86, lengthAdjustmentType87);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator26);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(valueAxis50);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertNotNull(rectangleInsets71);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 2.0d + "'", double74 == 2.0d);
        org.junit.Assert.assertNotNull(font78);
        org.junit.Assert.assertNotNull(rectangle2D80);
        org.junit.Assert.assertNotNull(rectangle2D84);
        org.junit.Assert.assertNotNull(lengthAdjustmentType86);
        org.junit.Assert.assertNotNull(lengthAdjustmentType87);
        org.junit.Assert.assertNotNull(rectangle2D88);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getEndPercent();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        ganttRenderer0.setBaseShape(shape2, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.65d + "'", double1 == 0.65d);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape9 = numberAxis8.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis8, valueAxis10, xYItemRenderer11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot12.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot12.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setDomainAxisLocation(10, axisLocation18, false);
        categoryPlot0.setDomainAxisLocation(12, axisLocation18);
        java.awt.Stroke stroke22 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace23);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection26 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection26);
        taskSeriesCollection26.validateObject();
        categoryPlot0.setDataset(12, (org.jfree.data.category.CategoryDataset) taskSeriesCollection26);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder30);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D33 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.awt.Paint paint34 = categoryAxis3D33.getLabelPaint();
        java.util.List list35 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D33);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot37.setWeight(2958465);
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = categoryPlot37.getRangeMarkers((int) (short) 10, layer41);
        java.lang.String str43 = categoryPlot37.getPlotType();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer45 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D49 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator50 = stackedBarRenderer3D49.getLegendItemURLGenerator();
        java.awt.Paint paint52 = stackedBarRenderer3D49.getSeriesPaint(3);
        boolean boolean53 = stackedBarRenderer3D49.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator58 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D49.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator58, true);
        java.awt.Font font63 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock64 = new org.jfree.chart.block.LabelBlock("{0}", font63);
        java.awt.geom.Rectangle2D rectangle2D65 = labelBlock64.getBounds();
        stackedBarRenderer3D49.setSeriesShape(5, (java.awt.Shape) rectangle2D65);
        boolean boolean67 = stackedAreaRenderer45.equals((java.lang.Object) rectangle2D65);
        org.jfree.data.xy.XYDataset xYDataset68 = null;
        org.jfree.chart.axis.NumberAxis numberAxis70 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape71 = numberAxis70.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis72 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer73 = null;
        org.jfree.chart.plot.XYPlot xYPlot74 = new org.jfree.chart.plot.XYPlot(xYDataset68, (org.jfree.chart.axis.ValueAxis) numberAxis70, valueAxis72, xYItemRenderer73);
        org.jfree.chart.JFreeChart jFreeChart75 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot74);
        org.jfree.chart.axis.ValueAxis valueAxis76 = xYPlot74.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = xYPlot74.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisSpace axisSpace79 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace80 = categoryAxis3D33.reserveSpace(graphics2D36, (org.jfree.chart.plot.Plot) categoryPlot37, rectangle2D65, rectangleEdge78, axisSpace79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Category Plot" + "'", str43.equals("Category Plot"));
        org.junit.Assert.assertNull(categorySeriesLabelGenerator50);
        org.junit.Assert.assertNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(font63);
        org.junit.Assert.assertNotNull(rectangle2D65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(shape71);
        org.junit.Assert.assertNotNull(valueAxis76);
        org.junit.Assert.assertNotNull(rectangleEdge78);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("{0}", font6);
        java.awt.geom.Rectangle2D rectangle2D8 = labelBlock7.getBounds();
        plotRenderingInfo4.setPlotArea(rectangle2D8);
        java.awt.Color color10 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = color10.createContext(colorModel11, rectangle12, rectangle2D13, affineTransform14, renderingHints15);
        int int17 = color10.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D8, (java.awt.Paint) color10);
        boolean boolean19 = legendGraphic18.isShapeVisible();
        java.awt.Paint paint20 = legendGraphic18.getFillPaint();
        java.awt.Paint paint21 = legendGraphic18.getFillPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = legendGraphic18.getShapeAnchor();
        java.awt.geom.Rectangle2D rectangle2D23 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 0.0d, 100.0d, rectangleAnchor22);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintContext16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(rectangle2D23);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(3, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "March" + "'", str2.equals("March"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        jFreeChart7.setTextAntiAlias(false);
        boolean boolean10 = jFreeChart7.getAntiAlias();
        org.jfree.chart.title.Title title12 = jFreeChart7.getSubtitle(0);
        title12.setMargin((double) 10.0f, (double) 10L, 35.0d, (double) 1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = org.jfree.chart.util.VerticalAlignment.CENTER;
        title12.setVerticalAlignment(verticalAlignment18);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = title12.getHorizontalAlignment();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape24 = numberAxis23.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) numberAxis23, valueAxis25, xYItemRenderer26);
        xYPlot27.setBackgroundImageAlignment((int) (byte) -1);
        float float30 = xYPlot27.getForegroundAlpha();
        xYPlot27.setRangeCrosshairValue((double) 60000L, false);
        boolean boolean34 = horizontalAlignment20.equals((java.lang.Object) 60000L);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(title12);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        java.awt.Paint paint3 = categoryAxis3D1.getLabelPaint();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        categoryAxis3D1.setCategoryLabelPositions(categoryLabelPositions4);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.awt.Paint paint8 = categoryAxis3D7.getLabelPaint();
        java.awt.Color color9 = java.awt.Color.pink;
        categoryAxis3D7.setAxisLinePaint((java.awt.Paint) color9);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer14 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = stackedBarRenderer3D18.getLegendItemURLGenerator();
        java.awt.Paint paint21 = stackedBarRenderer3D18.getSeriesPaint(3);
        boolean boolean22 = stackedBarRenderer3D18.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator27 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D18.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator27, true);
        java.awt.Font font32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock33 = new org.jfree.chart.block.LabelBlock("{0}", font32);
        java.awt.geom.Rectangle2D rectangle2D34 = labelBlock33.getBounds();
        stackedBarRenderer3D18.setSeriesShape(5, (java.awt.Shape) rectangle2D34);
        boolean boolean36 = stackedAreaRenderer14.equals((java.lang.Object) rectangle2D34);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean38 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge37);
        double double39 = categoryAxis3D7.getCategoryStart(10, 3, rectangle2D34, rectangleEdge37);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double41 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D34, rectangleEdge40);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition42 = categoryLabelPositions4.getLabelPosition(rectangleEdge40);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator19);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPosition42);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class2 = null;
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date6 = dateRange5.getUpperDate();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date6, timeZone7);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date12 = dateRange11.getUpperDate();
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange(date6, date12);
        org.jfree.data.general.PieDataset pieDataset14 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, (java.lang.Comparable) date6);
        java.lang.Comparable comparable15 = null;
        org.jfree.data.general.PieDataset pieDataset18 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset14, comparable15, 100.0d, (int) '#');
        boolean boolean19 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset14);
        boolean boolean20 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset14);
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 4, (org.jfree.data.KeyedValues) pieDataset14);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(pieDataset14);
        org.junit.Assert.assertNotNull(pieDataset18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(categoryDataset21);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double14 = rectangleInsets13.getRight();
        xYPlot6.setInsets(rectangleInsets13);
        java.lang.Object obj16 = xYPlot6.clone();
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot6.getDataset(3);
        xYPlot6.setDomainCrosshairValue((double) 3, true);
        java.awt.Paint paint22 = xYPlot6.getRangeTickBandPaint();
        org.jfree.data.xy.XYDataset xYDataset24 = xYPlot6.getDataset(9999);
        org.jfree.chart.axis.ValueAxis valueAxis26 = xYPlot6.getDomainAxis(12);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNull(xYDataset24);
        org.junit.Assert.assertNull(valueAxis26);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Class class2 = null;
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date6 = dateRange5.getUpperDate();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date6, timeZone7);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date12 = dateRange11.getUpperDate();
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange(date6, date12);
        keyedObjects2D0.removeObject((java.lang.Comparable) "org.jfree.data.time.TimePeriodFormatException: ", (java.lang.Comparable) date6);
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date18 = dateRange17.getUpperDate();
        int int19 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) date18);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape5 = numberAxis4.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, valueAxis6, xYItemRenderer7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot8.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace11 = xYPlot8.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot8.setRangeAxisLocation(axisLocation12);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot16.getDomainAxisLocation();
        java.awt.Color color19 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot16.setRangeGridlinePaint((java.awt.Paint) color19);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo22);
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("{0}", font25);
        java.awt.geom.Rectangle2D rectangle2D27 = labelBlock26.getBounds();
        plotRenderingInfo23.setPlotArea(rectangle2D27);
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot16.zoomRangeAxes((double) 8, plotRenderingInfo23, point2D29);
        java.awt.geom.Point2D point2D31 = null;
        xYPlot8.zoomDomainAxes(0.0d, (double) '4', plotRenderingInfo23, point2D31);
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("{0}", font1, (org.jfree.chart.plot.Plot) xYPlot8, true);
        int int35 = jFreeChart34.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(valueAxis10);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 15 + "'", int35 == 15);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        java.lang.Class class0 = null;
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date4 = dateRange3.getUpperDate();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date10 = dateRange9.getUpperDate();
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange(date4, date10);
        double double13 = dateRange11.constrain(0.65d);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 5.0d + "'", double13 == 5.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Stroke stroke2 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.configureRangeAxes();
        boolean boolean4 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRendererForDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5);
        java.lang.Object obj8 = null;
        boolean boolean9 = defaultCategoryDataset5.equals(obj8);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(categoryItemRenderer7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.awt.Color color2 = java.awt.Color.getColor("RectangleEdge.BOTTOM", 9999);
        java.awt.Color color3 = java.awt.Color.black;
        float[] floatArray10 = new float[] { (byte) -1, 10, (short) 0, (byte) 0, 2958465, (short) 1 };
        float[] floatArray11 = color3.getComponents(floatArray10);
        boolean boolean12 = color2.equals((java.lang.Object) floatArray11);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 5, (byte) 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 5, (byte) 10 };
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray4, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.CENTER_RIGHT", "ThreadContext", numberArray8);
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 5, (byte) 10 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 5, (byte) 10 };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray14, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.CENTER_RIGHT", "ThreadContext", numberArray18);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray8, numberArray18);
        java.lang.Comparable[] comparableArray21 = new java.lang.Comparable[] {};
        java.lang.String[] strArray22 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray23 = null;
        java.lang.Number[][] numberArray24 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset25 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray21, (java.lang.Comparable[]) strArray22, numberArray23, numberArray24);
        try {
            defaultIntervalCategoryDataset20.setSeriesKeys(comparableArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of series keys does not match the data.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(comparableArray21);
        org.junit.Assert.assertNotNull(strArray22);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setBaseShapesVisible(false);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        org.jfree.chart.LegendItem legendItem6 = lineRenderer3D0.getLegendItem(0, (int) (short) 100);
        boolean boolean7 = lineRenderer3D0.getBaseLinesVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(legendItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class1 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date5, date11);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) date5);
        java.lang.Comparable comparable14 = null;
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset13, comparable14, 100.0d, (int) '#');
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset13);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        java.awt.Paint paint20 = ringPlot19.getLabelLinkPaint();
        double double21 = ringPlot19.getInnerSeparatorExtension();
        double double22 = ringPlot19.getLabelLinkMargin();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.2d + "'", double21 == 0.2d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape7 = numberAxis6.getLeftArrow();
        numberAxis1.setLeftArrow(shape7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean11 = numberAxis10.isNegativeArrowVisible();
        numberAxis10.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape16 = numberAxis15.getLeftArrow();
        numberAxis10.setLeftArrow(shape16);
        numberAxis1.setDownArrow(shape16);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset21 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset21);
        java.text.DateFormat dateFormat25 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = new org.jfree.chart.axis.DateTickUnit(3, (int) 'a', dateFormat25);
        java.lang.String str27 = dateTickUnit26.toString();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity29 = new org.jfree.chart.entity.CategoryItemEntity(shape16, "", "DateTickUnit[HOUR, 97]", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset21, (java.lang.Comparable) dateTickUnit26, (java.lang.Comparable) (short) 1);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset30 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class31 = null;
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date35 = dateRange34.getUpperDate();
        java.util.TimeZone timeZone36 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date35, timeZone36);
        org.jfree.data.time.DateRange dateRange40 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date41 = dateRange40.getUpperDate();
        org.jfree.data.time.DateRange dateRange42 = new org.jfree.data.time.DateRange(date35, date41);
        org.jfree.data.general.PieDataset pieDataset43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset30, (java.lang.Comparable) date35);
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date35);
        long long45 = month44.getMiddleMillisecond();
        long long46 = month44.getLastMillisecond();
        categoryItemEntity29.setRowKey((java.lang.Comparable) long46);
        java.lang.Comparable comparable48 = categoryItemEntity29.getColumnKey();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "DateTickUnit[HOUR, 97]" + "'", str27.equals("DateTickUnit[HOUR, 97]"));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(pieDataset43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-1310400001L) + "'", long45 == (-1310400001L));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 28799999L + "'", long46 == 28799999L);
        org.junit.Assert.assertTrue("'" + comparable48 + "' != '" + (short) 1 + "'", comparable48.equals((short) 1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint1, (java.awt.Paint) color2, (java.awt.Paint) color3);
        java.awt.Paint paint5 = waterfallBarRenderer4.getLastBarPaint();
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color8 = java.awt.Color.darkGray;
        java.awt.Color color9 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer10 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color6, paint7, (java.awt.Paint) color8, (java.awt.Paint) color9);
        java.awt.Color color11 = java.awt.Color.cyan;
        waterfallBarRenderer10.setBaseOutlinePaint((java.awt.Paint) color11);
        java.awt.Color color13 = java.awt.Color.darkGray;
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color15 = java.awt.Color.darkGray;
        java.awt.Color color16 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer17 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color13, paint14, (java.awt.Paint) color15, (java.awt.Paint) color16);
        waterfallBarRenderer10.setBaseOutlinePaint(paint14);
        java.awt.Color color19 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.AffineTransform affineTransform23 = null;
        java.awt.RenderingHints renderingHints24 = null;
        java.awt.PaintContext paintContext25 = color19.createContext(colorModel20, rectangle21, rectangle2D22, affineTransform23, renderingHints24);
        int int26 = color19.getTransparency();
        java.awt.Color color27 = color19.darker();
        java.awt.Color color28 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel29 = null;
        java.awt.Rectangle rectangle30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.geom.AffineTransform affineTransform32 = null;
        java.awt.RenderingHints renderingHints33 = null;
        java.awt.PaintContext paintContext34 = color28.createContext(colorModel29, rectangle30, rectangle2D31, affineTransform32, renderingHints33);
        int int35 = color28.getTransparency();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer36 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint5, paint14, (java.awt.Paint) color19, (java.awt.Paint) color28);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier37 = waterfallBarRenderer36.getDrawingSupplier();
        java.awt.Color color38 = java.awt.Color.darkGray;
        java.awt.Paint paint39 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color40 = java.awt.Color.darkGray;
        java.awt.Color color41 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer42 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color38, paint39, (java.awt.Paint) color40, (java.awt.Paint) color41);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = new org.jfree.chart.labels.ItemLabelPosition();
        waterfallBarRenderer42.setBasePositiveItemLabelPosition(itemLabelPosition43, true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D49 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        java.awt.Color color50 = java.awt.Color.darkGray;
        java.awt.Paint paint51 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color52 = java.awt.Color.darkGray;
        java.awt.Color color53 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer54 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color50, paint51, (java.awt.Paint) color52, (java.awt.Paint) color53);
        stackedBarRenderer3D49.setBasePaint(paint51, false);
        waterfallBarRenderer42.setBaseItemLabelPaint(paint51);
        waterfallBarRenderer36.setNegativeBarPaint(paint51);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator59 = null;
        waterfallBarRenderer36.setBaseItemLabelGenerator(categoryItemLabelGenerator59);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintContext25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paintContext34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNull(drawingSupplier37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(color53);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary("({0}, {1}) = {3} - {4}");
        org.jfree.chart.ui.Library[] libraryArray3 = projectInfo0.getOptionalLibraries();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray3);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape9 = numberAxis8.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis8, valueAxis10, xYItemRenderer11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot12.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot12.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setDomainAxisLocation(10, axisLocation18, false);
        categoryPlot0.setDomainAxisLocation(12, axisLocation18);
        java.awt.Stroke stroke22 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace23);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection26 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection26);
        taskSeriesCollection26.validateObject();
        categoryPlot0.setDataset(12, (org.jfree.data.category.CategoryDataset) taskSeriesCollection26);
        try {
            java.lang.Number number33 = taskSeriesCollection26.getStartValue(0, (int) (byte) 1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(100);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (byte) 10, serialDate3);
        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getNearestDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears(100, serialDate6);
        try {
            org.jfree.data.time.SerialDate serialDate9 = serialDate6.getPreviousDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double14 = rectangleInsets13.getRight();
        xYPlot6.setInsets(rectangleInsets13);
        boolean boolean16 = xYPlot6.isDomainZoomable();
        xYPlot6.setBackgroundImageAlignment(1);
        xYPlot6.setDomainCrosshairValue((double) 97);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight(2958465);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot0.getRangeMarkers((int) (short) 10, layer4);
        java.lang.String str6 = categoryPlot0.getPlotType();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double10 = categoryAxis3D9.getLowerMargin();
        categoryPlot0.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D9);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset12 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range14 = defaultBoxAndWhiskerCategoryDataset12.getRangeBounds(false);
        categoryPlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset12);
        java.util.List list16 = defaultBoxAndWhiskerCategoryDataset12.getColumnKeys();
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class1 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date5, date11);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) date5);
        java.lang.Comparable comparable14 = null;
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset13, comparable14, 100.0d, (int) '#');
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset13);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        java.awt.Stroke stroke21 = ringPlot19.getSectionOutlineStroke((java.lang.Comparable) 12);
        java.awt.Paint paint23 = ringPlot19.getSectionPaint((java.lang.Comparable) 15);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNull(paint23);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint1, (java.awt.Paint) color2, (java.awt.Paint) color3);
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        waterfallBarRenderer4.setFirstBarPaint(paint5);
        java.awt.Paint paint7 = waterfallBarRenderer4.getLastBarPaint();
        java.awt.Shape shape8 = null;
        try {
            waterfallBarRenderer4.setBaseShape(shape8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.general.DatasetGroup datasetGroup2 = new org.jfree.data.general.DatasetGroup();
        taskSeriesCollection0.setGroup(datasetGroup2);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean10 = numberAxis9.isNegativeArrowVisible();
        numberAxis9.resizeRange((double) 100);
        numberAxis9.resizeRange((double) 100L);
        numberAxis9.setTickMarksVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean19 = numberAxis18.isNegativeArrowVisible();
        numberAxis18.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape24 = numberAxis23.getLeftArrow();
        numberAxis18.setLeftArrow(shape24);
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape24, 0.0d, (double) (byte) -1);
        numberAxis9.setDownArrow(shape24);
        java.awt.Stroke stroke30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint31 = null;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("{0}", "{0}", "ThreadContext", "ThreadContext", shape24, stroke30, paint31);
        boolean boolean33 = taskSeriesCollection0.equals((java.lang.Object) paint31);
        java.util.List list34 = taskSeriesCollection0.getColumnKeys();
        java.util.List list35 = taskSeriesCollection0.getRowKeys();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(list35);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        jFreeChart7.setTextAntiAlias(false);
        jFreeChart7.setTitle("0");
        java.awt.Paint paint12 = jFreeChart7.getBorderPaint();
        java.lang.Object obj13 = jFreeChart7.clone();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class1 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date5, date11);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) date5);
        java.lang.Comparable comparable14 = null;
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset13, comparable14, 100.0d, (int) '#');
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset13);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        java.awt.Stroke stroke21 = ringPlot19.getSectionOutlineStroke((java.lang.Comparable) 12);
        java.lang.Object obj22 = ringPlot19.clone();
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color24 = color23.brighter();
        ringPlot19.setLabelOutlinePaint((java.awt.Paint) color24);
        int int26 = color24.getBlue();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = stackedBarRenderer3D3.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = stackedBarRenderer3D3.getBaseToolTipGenerator();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        stackedBarRenderer3D10.setBaseSeriesVisibleInLegend(false);
        stackedBarRenderer3D10.setSeriesVisible((int) ' ', (java.lang.Boolean) true, false);
        boolean boolean17 = stackedBarRenderer3D10.isDrawBarOutline();
        java.awt.Color color19 = java.awt.Color.darkGray;
        java.awt.Paint paint20 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color21 = java.awt.Color.darkGray;
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer23 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color19, paint20, (java.awt.Paint) color21, (java.awt.Paint) color22);
        stackedBarRenderer3D10.setSeriesFillPaint((int) (short) 100, (java.awt.Paint) color22);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = stackedBarRenderer3D10.getNegativeItemLabelPosition((int) (short) 1, (int) (byte) 0);
        stackedBarRenderer3D3.setSeriesNegativeItemLabelPosition(12, itemLabelPosition27);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = stackedBarRenderer3D3.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("UnitType.ABSOLUTE");
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        dateAxis1.setRange((org.jfree.data.Range) dateRange4, true, false);
        boolean boolean9 = dateAxis1.equals((java.lang.Object) 60000L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = stackedBarRenderer3D5.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedBarRenderer3D5.getSeriesPositiveItemLabelPosition(0);
        stackedBarRenderer3D5.setAutoPopulateSeriesOutlineStroke(false);
        boolean boolean11 = standardGradientPaintTransformer1.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace9 = xYPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation(axisLocation10);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Color color15 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer16 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color12, paint13, (java.awt.Paint) color14, (java.awt.Paint) color15);
        xYPlot6.setDomainCrosshairPaint((java.awt.Paint) color14);
        org.jfree.chart.block.FlowArrangement flowArrangement18 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BorderArrangement borderArrangement19 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean21 = borderArrangement19.equals((java.lang.Object) (-1.0f));
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot6, (org.jfree.chart.block.Arrangement) flowArrangement18, (org.jfree.chart.block.Arrangement) borderArrangement19);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = xYPlot6.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape7 = numberAxis6.getLeftArrow();
        numberAxis1.setLeftArrow(shape7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean11 = numberAxis10.isNegativeArrowVisible();
        numberAxis10.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape16 = numberAxis15.getLeftArrow();
        numberAxis10.setLeftArrow(shape16);
        numberAxis1.setDownArrow(shape16);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset21 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset21);
        java.text.DateFormat dateFormat25 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = new org.jfree.chart.axis.DateTickUnit(3, (int) 'a', dateFormat25);
        java.lang.String str27 = dateTickUnit26.toString();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity29 = new org.jfree.chart.entity.CategoryItemEntity(shape16, "", "DateTickUnit[HOUR, 97]", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset21, (java.lang.Comparable) dateTickUnit26, (java.lang.Comparable) (short) 1);
        java.lang.Comparable comparable30 = categoryItemEntity29.getColumnKey();
        java.awt.Color color31 = java.awt.Color.darkGray;
        java.awt.Paint paint32 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color33 = java.awt.Color.darkGray;
        java.awt.Color color34 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer35 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color31, paint32, (java.awt.Paint) color33, (java.awt.Paint) color34);
        java.awt.Paint paint36 = waterfallBarRenderer35.getLastBarPaint();
        java.awt.Shape shape37 = waterfallBarRenderer35.getBaseShape();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D39 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.awt.Paint paint40 = categoryAxis3D39.getLabelPaint();
        java.awt.Color color41 = java.awt.Color.pink;
        categoryAxis3D39.setAxisLinePaint((java.awt.Paint) color41);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer46 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D50 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator51 = stackedBarRenderer3D50.getLegendItemURLGenerator();
        java.awt.Paint paint53 = stackedBarRenderer3D50.getSeriesPaint(3);
        boolean boolean54 = stackedBarRenderer3D50.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator59 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D50.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator59, true);
        java.awt.Font font64 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock65 = new org.jfree.chart.block.LabelBlock("{0}", font64);
        java.awt.geom.Rectangle2D rectangle2D66 = labelBlock65.getBounds();
        stackedBarRenderer3D50.setSeriesShape(5, (java.awt.Shape) rectangle2D66);
        boolean boolean68 = stackedAreaRenderer46.equals((java.lang.Object) rectangle2D66);
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean70 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge69);
        double double71 = categoryAxis3D39.getCategoryStart(10, 3, rectangle2D66, rectangleEdge69);
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double73 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D66, rectangleEdge72);
        boolean boolean74 = org.jfree.chart.util.ShapeUtilities.equal(shape37, (java.awt.Shape) rectangle2D66);
        categoryItemEntity29.setArea((java.awt.Shape) rectangle2D66);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "DateTickUnit[HOUR, 97]" + "'", str27.equals("DateTickUnit[HOUR, 97]"));
        org.junit.Assert.assertTrue("'" + comparable30 + "' != '" + (short) 1 + "'", comparable30.equals((short) 1));
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator51);
        org.junit.Assert.assertNull(paint53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(font64);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(rectangleEdge69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.awt.Paint paint0 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace9 = xYPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation(axisLocation10);
        xYPlot6.setRangeCrosshairValue(1.0d);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot6.setNoDataMessageFont(font14);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot6.getRangeAxisEdge(0);
        boolean boolean18 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge17);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape4 = numberAxis3.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3, valueAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot7.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace10 = xYPlot7.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot7.setRangeAxisLocation(axisLocation11);
        xYPlot7.setRangeCrosshairValue(1.0d);
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot7.setNoDataMessageFont(font15);
        java.awt.Color color17 = java.awt.Color.orange;
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, (java.awt.Paint) color17);
        java.util.List list19 = textBlock18.getLines();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = null;
        numberAxis22.setStandardTickUnits(tickUnitSource23);
        java.awt.Font font25 = numberAxis22.getTickLabelFont();
        java.awt.Paint paint26 = null;
        try {
            textBlock18.addLine("TextAnchor.CENTER_RIGHT", font25, paint26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(font25);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (-1310400001L), (double) '#');
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean3 = flowArrangement0.equals((java.lang.Object) false);
        flowArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.Object obj2 = categoryAxis3D1.clone();
        categoryAxis3D1.setTickMarksVisible(true);
        float float5 = categoryAxis3D1.getTickMarkInsideLength();
        categoryAxis3D1.setLabel("({0}, {1}) = {2}");
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint1, (java.awt.Paint) color2, (java.awt.Paint) color3);
        java.lang.String str5 = color2.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=64,g=64,b=64]" + "'", str5.equals("java.awt.Color[r=64,g=64,b=64]"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getInfo();
        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo0.getLibraries();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str1.equals("http://www.jfree.org/jfreechart/index.html"));
        org.junit.Assert.assertNotNull(libraryArray2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getStartPercent();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.35d + "'", double1 == 0.35d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = lineRenderer3D0.getBasePositiveItemLabelPosition();
        org.junit.Assert.assertNotNull(itemLabelPosition1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Paint paint6 = stackedBarRenderer3D3.getSeriesPaint(3);
        java.awt.Shape shape7 = stackedBarRenderer3D3.getBaseShape();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setWeight(2958465);
        int int12 = categoryPlot9.getDatasetCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot13.getDomainAxisLocation();
        java.awt.Color color16 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot13.setRangeGridlinePaint((java.awt.Paint) color16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot13.getDomainAxis((int) (byte) 0);
        categoryPlot13.configureDomainAxes();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator25 = stackedBarRenderer3D24.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = stackedBarRenderer3D24.getSeriesPositiveItemLabelPosition(0);
        stackedBarRenderer3D24.setItemLabelAnchorOffset((double) '#');
        boolean boolean30 = stackedBarRenderer3D24.getAutoPopulateSeriesPaint();
        categoryPlot13.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D24, false);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D24);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape37 = numberAxis36.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset34, (org.jfree.chart.axis.ValueAxis) numberAxis36, valueAxis38, xYItemRenderer39);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape44 = numberAxis43.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset41, (org.jfree.chart.axis.ValueAxis) numberAxis43, valueAxis45, xYItemRenderer46);
        org.jfree.chart.JFreeChart jFreeChart48 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot47);
        org.jfree.chart.axis.ValueAxis valueAxis49 = xYPlot47.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = xYPlot47.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation53 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot47.setDomainAxisLocation(10, axisLocation53, false);
        xYPlot40.setDomainAxisLocation(axisLocation53, true);
        org.jfree.chart.axis.NumberAxis numberAxis60 = new org.jfree.chart.axis.NumberAxis("hi!");
        xYPlot40.setRangeAxis((int) (byte) 10, (org.jfree.chart.axis.ValueAxis) numberAxis60);
        numberAxis60.setAutoRangeIncludesZero(false);
        org.jfree.chart.plot.ValueMarker valueMarker65 = new org.jfree.chart.plot.ValueMarker((double) 12);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator66 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean67 = valueMarker65.equals((java.lang.Object) standardCategoryToolTipGenerator66);
        org.jfree.chart.block.BlockContainer blockContainer68 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = blockContainer68.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        blockContainer68.setPadding(rectangleInsets70);
        double double73 = rectangleInsets70.calculateTopOutset((double) 100);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo74 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo75 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo74);
        java.awt.Font font77 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock78 = new org.jfree.chart.block.LabelBlock("{0}", font77);
        java.awt.geom.Rectangle2D rectangle2D79 = labelBlock78.getBounds();
        plotRenderingInfo75.setPlotArea(rectangle2D79);
        java.awt.geom.Rectangle2D rectangle2D83 = rectangleInsets70.createOutsetRectangle(rectangle2D79, false, false);
        stackedBarRenderer3D3.drawRangeMarker(graphics2D8, categoryPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis60, (org.jfree.chart.plot.Marker) valueMarker65, rectangle2D83);
        boolean boolean85 = stackedBarRenderer3D3.getIncludeBaseInRange();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(categoryAxis19);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator25);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(valueAxis49);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 2.0d + "'", double73 == 2.0d);
        org.junit.Assert.assertNotNull(font77);
        org.junit.Assert.assertNotNull(rectangle2D79);
        org.junit.Assert.assertNotNull(rectangle2D83);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.lang.Class class0 = null;
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date4 = dateRange3.getUpperDate();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date10 = dateRange9.getUpperDate();
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange(date4, date10);
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.DateTick dateTick16 = new org.jfree.chart.axis.DateTick(date4, "UnitType.ABSOLUTE", textAnchor13, textAnchor14, (double) 9);
        double double17 = dateTick16.getValue();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 5.0d + "'", double17 == 5.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.awt.Color color0 = java.awt.Color.yellow;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=255,g=255,b=0]" + "'", str1.equals("java.awt.Color[r=255,g=255,b=0]"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Stroke stroke5 = stackedBarRenderer3D3.getBaseStroke();
        stackedBarRenderer3D3.setBase((double) (byte) -1);
        stackedBarRenderer3D3.setSeriesItemLabelsVisible(100, (java.lang.Boolean) false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = stackedBarRenderer3D3.getSeriesURLGenerator(2958465);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = stackedBarRenderer3D3.getPlot();
        java.lang.Boolean boolean15 = stackedBarRenderer3D3.getSeriesCreateEntities(5);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(categoryURLGenerator12);
        org.junit.Assert.assertNull(categoryPlot13);
        org.junit.Assert.assertNull(boolean15);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint1, (java.awt.Paint) color2, (java.awt.Paint) color3);
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        waterfallBarRenderer4.setFirstBarPaint(paint5);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator10 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        waterfallBarRenderer4.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator10);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = waterfallBarRenderer4.getBaseItemLabelGenerator();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator12);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot6.getRangeAxisEdge((int) 'a');
        org.jfree.chart.plot.Plot plot11 = xYPlot6.getParent();
        java.awt.Stroke stroke12 = xYPlot6.getDomainZeroBaselineStroke();
        xYPlot6.setNoDataMessage("ThreadContext");
        boolean boolean16 = xYPlot6.equals((java.lang.Object) 4);
        org.jfree.chart.plot.Plot plot17 = xYPlot6.getRootPlot();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape23 = numberAxis22.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) numberAxis22, valueAxis24, xYItemRenderer25);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = xYPlot26.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace29 = xYPlot26.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot26.setRangeAxisLocation(axisLocation30);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot34.getDomainAxisLocation();
        java.awt.Color color37 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot34.setRangeGridlinePaint((java.awt.Paint) color37);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo40);
        java.awt.Font font43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock44 = new org.jfree.chart.block.LabelBlock("{0}", font43);
        java.awt.geom.Rectangle2D rectangle2D45 = labelBlock44.getBounds();
        plotRenderingInfo41.setPlotArea(rectangle2D45);
        java.awt.geom.Point2D point2D47 = null;
        categoryPlot34.zoomRangeAxes((double) 8, plotRenderingInfo41, point2D47);
        java.awt.geom.Point2D point2D49 = null;
        xYPlot26.zoomDomainAxes(0.0d, (double) '4', plotRenderingInfo41, point2D49);
        java.awt.geom.Rectangle2D rectangle2D51 = plotRenderingInfo41.getDataArea();
        java.awt.geom.Point2D point2D52 = null;
        xYPlot6.zoomRangeAxes((double) 12, 8.0d, plotRenderingInfo41, point2D52);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(plot17);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(valueAxis28);
        org.junit.Assert.assertNull(axisSpace29);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangle2D51);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Color color7 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer8 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color4, paint5, (java.awt.Paint) color6, (java.awt.Paint) color7);
        stackedBarRenderer3D3.setBasePaint(paint5, false);
        java.lang.Object obj11 = stackedBarRenderer3D3.clone();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState4 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo3);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint7 = categoryPlot6.getRangeGridlinePaint();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int10 = categoryAxis3D9.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset13.setValue((double) 60000L, (java.lang.Comparable) 10.0f, (java.lang.Comparable) 2);
        java.lang.Number number20 = defaultCategoryDataset13.getValue((int) (byte) 0, (int) (short) 0);
        try {
            boxAndWhiskerRenderer0.drawHorizontalItem(graphics2D1, categoryItemRendererState4, rectangle2D5, categoryPlot6, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D9, (org.jfree.chart.axis.ValueAxis) numberAxis12, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset13, (-1), 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.category.DefaultCategoryDataset cannot be cast to org.jfree.data.statistics.BoxAndWhiskerCategoryDataset");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 60000.0d + "'", number20.equals(60000.0d));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape9 = numberAxis8.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis8, valueAxis10, xYItemRenderer11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot12.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot12.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setDomainAxisLocation(10, axisLocation18, false);
        categoryPlot0.setDomainAxisLocation(12, axisLocation18);
        java.awt.Stroke stroke22 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace23);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection26 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection26);
        taskSeriesCollection26.validateObject();
        categoryPlot0.setDataset(12, (org.jfree.data.category.CategoryDataset) taskSeriesCollection26);
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape4 = numberAxis3.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3, valueAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot7.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace10 = xYPlot7.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot7.setRangeAxisLocation(axisLocation11);
        xYPlot7.setRangeCrosshairValue(1.0d);
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot7.setNoDataMessageFont(font15);
        java.awt.Color color17 = java.awt.Color.orange;
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, (java.awt.Paint) color17);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 12);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator21 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean22 = valueMarker20.equals((java.lang.Object) standardCategoryToolTipGenerator21);
        java.awt.Paint paint23 = valueMarker20.getOutlinePaint();
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("{0}", font25);
        valueMarker20.setLabelFont(font25);
        float float28 = valueMarker20.getAlpha();
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape32 = numberAxis31.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis31, valueAxis33, xYItemRenderer34);
        xYPlot35.setBackgroundImageAlignment((int) (byte) -1);
        float float38 = xYPlot35.getForegroundAlpha();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D42 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator43 = stackedBarRenderer3D42.getLegendItemURLGenerator();
        java.awt.Stroke stroke44 = stackedBarRenderer3D42.getBaseStroke();
        xYPlot35.setOutlineStroke(stroke44);
        valueMarker20.setStroke(stroke44);
        boolean boolean47 = textBlock18.equals((java.lang.Object) valueMarker20);
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.util.Size2D size2D49 = textBlock18.calculateDimensions(graphics2D48);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.8f + "'", float28 == 0.8f);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 1.0f + "'", float38 == 1.0f);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(size2D49);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color1 = java.awt.Color.magenta;
        ganttRenderer0.setCompletePaint((java.awt.Paint) color1);
        ganttRenderer0.setStartPercent((double) (-1310400001L));
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        java.awt.Color color9 = java.awt.Color.darkGray;
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color11 = java.awt.Color.darkGray;
        java.awt.Color color12 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer13 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color9, paint10, (java.awt.Paint) color11, (java.awt.Paint) color12);
        stackedBarRenderer3D8.setBasePaint(paint10, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = stackedBarRenderer3D8.getItemLabelGenerator((int) (short) 0, 3);
        stackedBarRenderer3D8.setBase(8.0d);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean23 = numberAxis22.isNegativeArrowVisible();
        numberAxis22.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape28 = numberAxis27.getLeftArrow();
        numberAxis22.setLeftArrow(shape28);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean32 = numberAxis31.isNegativeArrowVisible();
        numberAxis31.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape37 = numberAxis36.getLeftArrow();
        numberAxis31.setLeftArrow(shape37);
        numberAxis22.setDownArrow(shape37);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset42 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset42);
        java.text.DateFormat dateFormat46 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit47 = new org.jfree.chart.axis.DateTickUnit(3, (int) 'a', dateFormat46);
        java.lang.String str48 = dateTickUnit47.toString();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity50 = new org.jfree.chart.entity.CategoryItemEntity(shape37, "", "DateTickUnit[HOUR, 97]", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset42, (java.lang.Comparable) dateTickUnit47, (java.lang.Comparable) (short) 1);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset51 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class52 = null;
        org.jfree.data.time.DateRange dateRange55 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date56 = dateRange55.getUpperDate();
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date56, timeZone57);
        org.jfree.data.time.DateRange dateRange61 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date62 = dateRange61.getUpperDate();
        org.jfree.data.time.DateRange dateRange63 = new org.jfree.data.time.DateRange(date56, date62);
        org.jfree.data.general.PieDataset pieDataset64 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset51, (java.lang.Comparable) date56);
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(date56);
        long long66 = month65.getMiddleMillisecond();
        long long67 = month65.getLastMillisecond();
        categoryItemEntity50.setRowKey((java.lang.Comparable) long67);
        org.jfree.data.category.CategoryDataset categoryDataset69 = categoryItemEntity50.getDataset();
        org.jfree.data.Range range70 = stackedBarRenderer3D8.findRangeBounds(categoryDataset69);
        boolean boolean71 = ganttRenderer0.equals((java.lang.Object) categoryDataset69);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "DateTickUnit[HOUR, 97]" + "'", str48.equals("DateTickUnit[HOUR, 97]"));
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(pieDataset64);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-1310400001L) + "'", long66 == (-1310400001L));
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 28799999L + "'", long67 == 28799999L);
        org.junit.Assert.assertNotNull(categoryDataset69);
        org.junit.Assert.assertNotNull(range70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class1 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date5, date11);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) date5);
        java.lang.Comparable comparable14 = null;
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset13, comparable14, 100.0d, (int) '#');
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset13);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        java.awt.Stroke stroke21 = ringPlot19.getSectionOutlineStroke((java.lang.Comparable) 12);
        java.lang.Object obj22 = ringPlot19.clone();
        java.awt.Paint paint23 = ringPlot19.getShadowPaint();
        double double24 = ringPlot19.getLabelGap();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 60000L);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        boolean boolean6 = numberAxis1.equals((java.lang.Object) 12);
        numberAxis1.setTickLabelsVisible(false);
        double double9 = numberAxis1.getFixedAutoRange();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = stackedBarRenderer3D5.getLegendItemURLGenerator();
        java.awt.Paint paint8 = stackedBarRenderer3D5.getSeriesPaint(3);
        boolean boolean9 = stackedBarRenderer3D5.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator14 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D5.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator14, true);
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("{0}", font19);
        java.awt.geom.Rectangle2D rectangle2D21 = labelBlock20.getBounds();
        stackedBarRenderer3D5.setSeriesShape(5, (java.awt.Shape) rectangle2D21);
        boolean boolean23 = year1.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(3, year1);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.lang.Class class0 = null;
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date4 = dateRange3.getUpperDate();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date10 = dateRange9.getUpperDate();
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange(date4, date10);
        java.lang.Class class12 = null;
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date16 = dateRange15.getUpperDate();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date16, timeZone17);
        org.jfree.data.time.DateRange dateRange21 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date22 = dateRange21.getUpperDate();
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange(date16, date22);
        org.jfree.data.time.DateRange dateRange24 = new org.jfree.data.time.DateRange(date10, date16);
        double double25 = dateRange24.getUpperBound();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 5.0d + "'", double25 == 5.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setLabelURL("");
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot4.getDomainAxisLocation();
        java.awt.Color color7 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot4.setRangeGridlinePaint((java.awt.Paint) color7);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("{0}", font13);
        java.awt.geom.Rectangle2D rectangle2D15 = labelBlock14.getBounds();
        plotRenderingInfo11.setPlotArea(rectangle2D15);
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot4.zoomRangeAxes((double) 8, plotRenderingInfo11, point2D17);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double21 = categoryAxis3D20.getLowerMargin();
        categoryPlot4.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D20);
        categoryAxis3D1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.general.DatasetGroup datasetGroup2 = new org.jfree.data.general.DatasetGroup();
        taskSeriesCollection0.setGroup(datasetGroup2);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean10 = numberAxis9.isNegativeArrowVisible();
        numberAxis9.resizeRange((double) 100);
        numberAxis9.resizeRange((double) 100L);
        numberAxis9.setTickMarksVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean19 = numberAxis18.isNegativeArrowVisible();
        numberAxis18.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape24 = numberAxis23.getLeftArrow();
        numberAxis18.setLeftArrow(shape24);
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape24, 0.0d, (double) (byte) -1);
        numberAxis9.setDownArrow(shape24);
        java.awt.Stroke stroke30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint31 = null;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("{0}", "{0}", "ThreadContext", "ThreadContext", shape24, stroke30, paint31);
        boolean boolean33 = taskSeriesCollection0.equals((java.lang.Object) paint31);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, (java.lang.Comparable) "RectangleAnchor.CENTER");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(pieDataset35);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class1 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date5, date11);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) date5);
        java.lang.Comparable comparable14 = null;
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset13, comparable14, 100.0d, (int) '#');
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset13);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        java.awt.Stroke stroke21 = ringPlot19.getSectionOutlineStroke((java.lang.Comparable) 12);
        java.lang.Object obj22 = ringPlot19.clone();
        java.awt.Paint paint23 = ringPlot19.getShadowPaint();
        java.awt.Paint paint24 = ringPlot19.getBaseSectionPaint();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Color color7 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer8 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color4, paint5, (java.awt.Paint) color6, (java.awt.Paint) color7);
        stackedBarRenderer3D3.setBasePaint(paint5, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = stackedBarRenderer3D3.getItemLabelGenerator((int) (short) 0, 3);
        stackedBarRenderer3D3.setBase(8.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator20 = stackedBarRenderer3D19.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = stackedBarRenderer3D19.getSeriesPositiveItemLabelPosition(0);
        stackedBarRenderer3D3.setPositiveItemLabelPositionFallback(itemLabelPosition22);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator20);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.util.List list2 = blockContainer0.getBlocks();
        java.awt.geom.Rectangle2D rectangle2D3 = blockContainer0.getBounds();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(rectangle2D3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot0.getDomainAxis((int) (byte) 0);
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot10.getDomainAxisLocation();
        java.awt.Color color13 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot10.setRangeGridlinePaint((java.awt.Paint) color13);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("{0}", font19);
        java.awt.geom.Rectangle2D rectangle2D21 = labelBlock20.getBounds();
        plotRenderingInfo17.setPlotArea(rectangle2D21);
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot10.zoomRangeAxes((double) 8, plotRenderingInfo17, point2D23);
        categoryPlot0.handleClick(100, 0, plotRenderingInfo17);
        org.jfree.chart.util.SortOrder sortOrder26 = categoryPlot0.getColumnRenderingOrder();
        try {
            categoryPlot0.zoom((double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(sortOrder26);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) 'a');
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder(1.0d, 1.0d, (double) 2958465, 0.0d);
        boolean boolean8 = multiplePiePlot0.equals((java.lang.Object) 1.0d);
        java.lang.Comparable comparable9 = multiplePiePlot0.getAggregatedItemsKey();
        multiplePiePlot0.setLimit((double) 15);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Point2D point2D14 = null;
        org.jfree.chart.plot.PlotState plotState15 = new org.jfree.chart.plot.PlotState();
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis18, valueAxis20, xYItemRenderer21);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot22);
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot22.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace25 = xYPlot22.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot22.setRangeAxisLocation(axisLocation26);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot30.getDomainAxisLocation();
        java.awt.Color color33 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot30.setRangeGridlinePaint((java.awt.Paint) color33);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo36);
        java.awt.Font font39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock40 = new org.jfree.chart.block.LabelBlock("{0}", font39);
        java.awt.geom.Rectangle2D rectangle2D41 = labelBlock40.getBounds();
        plotRenderingInfo37.setPlotArea(rectangle2D41);
        java.awt.geom.Point2D point2D43 = null;
        categoryPlot30.zoomRangeAxes((double) 8, plotRenderingInfo37, point2D43);
        java.awt.geom.Point2D point2D45 = null;
        xYPlot22.zoomDomainAxes(0.0d, (double) '4', plotRenderingInfo37, point2D45);
        java.awt.geom.Rectangle2D rectangle2D47 = plotRenderingInfo37.getDataArea();
        try {
            multiplePiePlot0.draw(graphics2D12, rectangle2D13, point2D14, plotState15, plotRenderingInfo37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + "Other" + "'", comparable9.equals("Other"));
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNull(axisSpace25);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangle2D47);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.awt.Color color3 = java.awt.Color.darkGray;
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color5 = java.awt.Color.darkGray;
        java.awt.Color color6 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer7 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color3, paint4, (java.awt.Paint) color5, (java.awt.Paint) color6);
        java.awt.Color color8 = java.awt.Color.darkGray;
        java.awt.Paint paint9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color10 = java.awt.Color.darkGray;
        java.awt.Color color11 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer12 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color8, paint9, (java.awt.Paint) color10, (java.awt.Paint) color11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition();
        waterfallBarRenderer12.setBasePositiveItemLabelPosition(itemLabelPosition13, true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        java.awt.Color color20 = java.awt.Color.darkGray;
        java.awt.Paint paint21 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color22 = java.awt.Color.darkGray;
        java.awt.Color color23 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer24 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color20, paint21, (java.awt.Paint) color22, (java.awt.Paint) color23);
        stackedBarRenderer3D19.setBasePaint(paint21, false);
        waterfallBarRenderer12.setBaseItemLabelPaint(paint21);
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color29 = color28.brighter();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D31 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.awt.Paint paint32 = categoryAxis3D31.getLabelPaint();
        java.awt.Paint paint33 = categoryAxis3D31.getLabelPaint();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer34 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color5, paint21, (java.awt.Paint) color28, paint33);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor35 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        java.awt.Color color36 = java.awt.Color.black;
        float[] floatArray43 = new float[] { (byte) -1, 10, (short) 0, (byte) 0, 2958465, (short) 1 };
        float[] floatArray44 = color36.getComponents(floatArray43);
        boolean boolean45 = itemLabelAnchor35.equals((java.lang.Object) floatArray44);
        float[] floatArray46 = color28.getRGBComponents(floatArray44);
        float[] floatArray47 = java.awt.Color.RGBtoHSB(5, (int) ' ', 15, floatArray46);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(itemLabelAnchor35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray47);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.text.DateFormat dateFormat4 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(3, (int) 'a', dateFormat4);
        try {
            defaultKeyedValues0.insertValue(15, (java.lang.Comparable) 3, (java.lang.Number) 8.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        double double4 = defaultBoxAndWhiskerCategoryDataset0.getRangeUpperBound(false);
        java.text.DateFormat dateFormat7 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = new org.jfree.chart.axis.DateTickUnit(3, (int) 'a', dateFormat7);
        java.lang.String str9 = dateTickUnit8.toString();
        int int10 = defaultBoxAndWhiskerCategoryDataset0.getRowIndex((java.lang.Comparable) dateTickUnit8);
        try {
            java.lang.Number number13 = defaultBoxAndWhiskerCategoryDataset0.getMedianValue((int) (short) 0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "DateTickUnit[HOUR, 97]" + "'", str9.equals("DateTickUnit[HOUR, 97]"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        boolean boolean6 = numberAxis1.equals((java.lang.Object) 12);
        double double7 = numberAxis1.getLowerBound();
        java.text.NumberFormat numberFormat8 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape12 = numberAxis11.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis11, valueAxis13, xYItemRenderer14);
        xYPlot15.setBackgroundImageAlignment((int) (byte) -1);
        float float18 = xYPlot15.getForegroundAlpha();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator23 = stackedBarRenderer3D22.getLegendItemURLGenerator();
        java.awt.Stroke stroke24 = stackedBarRenderer3D22.getBaseStroke();
        xYPlot15.setOutlineStroke(stroke24);
        numberAxis1.setAxisLineStroke(stroke24);
        java.text.NumberFormat numberFormat27 = numberAxis1.getNumberFormatOverride();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-49.5d) + "'", double7 == (-49.5d));
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(numberFormat27);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot6.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setDomainAxisLocation(10, axisLocation12, false);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.Color color16 = java.awt.Color.darkGray;
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Color color19 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer20 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color16, paint17, (java.awt.Paint) color18, (java.awt.Paint) color19);
        int int21 = color16.getTransparency();
        java.awt.Color color22 = java.awt.Color.darkGray;
        java.awt.Paint paint23 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color24 = java.awt.Color.darkGray;
        java.awt.Color color25 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer26 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color22, paint23, (java.awt.Paint) color24, (java.awt.Paint) color25);
        java.awt.Color color27 = java.awt.Color.cyan;
        waterfallBarRenderer26.setBaseOutlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        waterfallBarRenderer26.setBaseStroke(stroke29, false);
        org.jfree.chart.block.BlockBorder blockBorder36 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = blockBorder36.getInsets();
        double double39 = rectangleInsets37.calculateTopInset(0.0d);
        org.jfree.chart.block.LineBorder lineBorder40 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color16, stroke29, rectangleInsets37);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D44 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator45 = stackedBarRenderer3D44.getLegendItemURLGenerator();
        java.awt.Paint paint47 = stackedBarRenderer3D44.getSeriesPaint(3);
        boolean boolean48 = stackedBarRenderer3D44.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator53 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D44.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator53, true);
        java.awt.Font font58 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock59 = new org.jfree.chart.block.LabelBlock("{0}", font58);
        java.awt.geom.Rectangle2D rectangle2D60 = labelBlock59.getBounds();
        stackedBarRenderer3D44.setSeriesShape(5, (java.awt.Shape) rectangle2D60);
        java.awt.geom.Rectangle2D rectangle2D62 = rectangleInsets37.createInsetRectangle(rectangle2D60);
        try {
            xYPlot6.drawBackground(graphics2D15, rectangle2D62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + (-1.0d) + "'", double39 == (-1.0d));
        org.junit.Assert.assertNull(categorySeriesLabelGenerator45);
        org.junit.Assert.assertNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangle2D62);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("{0}", font3);
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        plotRenderingInfo1.setPlotArea(rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.AffineTransform affineTransform11 = null;
        java.awt.RenderingHints renderingHints12 = null;
        java.awt.PaintContext paintContext13 = color7.createContext(colorModel8, rectangle9, rectangle2D10, affineTransform11, renderingHints12);
        int int14 = color7.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D5, (java.awt.Paint) color7);
        boolean boolean16 = legendGraphic15.isShapeVisible();
        java.awt.Paint paint17 = legendGraphic15.getFillPaint();
        java.awt.Paint paint18 = legendGraphic15.getFillPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = legendGraphic15.getShapeAnchor();
        java.awt.Paint paint20 = legendGraphic15.getOutlinePaint();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintContext13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNull(paint20);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.setValue((double) 60000L, (java.lang.Comparable) 10.0f, (java.lang.Comparable) 2);
        int int5 = defaultCategoryDataset0.getRowCount();
        try {
            defaultCategoryDataset0.removeRow(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean2 = stackedBarRenderer3D1.getRenderAsPercentages();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("DateTickUnit[HOUR, 97]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        numberAxis1.resizeRange((double) 100L);
        org.jfree.chart.plot.Plot plot7 = numberAxis1.getPlot();
        java.awt.Color color8 = java.awt.Color.darkGray;
        java.awt.Paint paint9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color10 = java.awt.Color.darkGray;
        java.awt.Color color11 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer12 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color8, paint9, (java.awt.Paint) color10, (java.awt.Paint) color11);
        java.awt.Paint paint13 = waterfallBarRenderer12.getLastBarPaint();
        numberAxis1.setAxisLinePaint(paint13);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str17 = numberTickUnit15.valueToString(0.0d);
        numberAxis1.setTickUnit(numberTickUnit15);
        org.jfree.data.DefaultKeyedValue defaultKeyedValue20 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) numberTickUnit15, (java.lang.Number) 8.0d);
        org.jfree.chart.util.PaintList paintList21 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator27 = stackedBarRenderer3D26.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = stackedBarRenderer3D26.getSeriesPositiveItemLabelPosition(0);
        stackedBarRenderer3D26.setItemLabelAnchorOffset((double) '#');
        boolean boolean32 = stackedBarRenderer3D26.getAutoPopulateSeriesPaint();
        java.awt.Paint paint33 = stackedBarRenderer3D26.getBaseOutlinePaint();
        paintList21.setPaint(5, paint33);
        int int35 = paintList21.size();
        boolean boolean36 = defaultKeyedValue20.equals((java.lang.Object) paintList21);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(numberTickUnit15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertNull(categorySeriesLabelGenerator27);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleEdge.BOTTOM", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.awt.geom.Point2D point2D0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        try {
            java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMedianValue((int) ' ', 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        double double5 = categoryPlot0.getRangeCrosshairValue();
        java.lang.String str6 = categoryPlot0.getNoDataMessage();
        java.util.List list7 = categoryPlot0.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge(100);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent1.setType(chartChangeEventType2);
        java.lang.Object obj4 = chartChangeEvent1.getSource();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = chartChangeEvent1.getType();
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (short) 10 + "'", obj4.equals((short) 10));
        org.junit.Assert.assertNotNull(chartChangeEventType5);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list2 = categoryPlot1.getAnnotations();
        boolean boolean3 = lengthAdjustmentType0.equals((java.lang.Object) list2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape7 = numberAxis6.getLeftArrow();
        numberAxis1.setLeftArrow(shape7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean11 = numberAxis10.isNegativeArrowVisible();
        numberAxis10.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape16 = numberAxis15.getLeftArrow();
        numberAxis10.setLeftArrow(shape16);
        numberAxis1.setDownArrow(shape16);
        boolean boolean19 = numberAxis1.isPositiveArrowVisible();
        java.awt.Shape shape20 = numberAxis1.getDownArrow();
        java.util.EventListener eventListener21 = null;
        boolean boolean22 = numberAxis1.hasListener(eventListener21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis1.getLabelInsets();
        numberAxis1.setRangeAboutValue((double) 100, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleInsets23);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("UnitType.ABSOLUTE");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis1.getTickMarkPosition();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date6 = dateRange5.getUpperDate();
        java.awt.Color color7 = java.awt.Color.darkGray;
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color9 = java.awt.Color.darkGray;
        java.awt.Color color10 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer11 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color7, paint8, (java.awt.Paint) color9, (java.awt.Paint) color10);
        int int12 = color7.getTransparency();
        java.awt.Color color13 = java.awt.Color.darkGray;
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color15 = java.awt.Color.darkGray;
        java.awt.Color color16 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer17 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color13, paint14, (java.awt.Paint) color15, (java.awt.Paint) color16);
        java.awt.Color color18 = java.awt.Color.cyan;
        waterfallBarRenderer17.setBaseOutlinePaint((java.awt.Paint) color18);
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        waterfallBarRenderer17.setBaseStroke(stroke20, false);
        org.jfree.chart.block.BlockBorder blockBorder27 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = blockBorder27.getInsets();
        double double30 = rectangleInsets28.calculateTopInset(0.0d);
        org.jfree.chart.block.LineBorder lineBorder31 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color7, stroke20, rectangleInsets28);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator36 = stackedBarRenderer3D35.getLegendItemURLGenerator();
        java.awt.Paint paint38 = stackedBarRenderer3D35.getSeriesPaint(3);
        boolean boolean39 = stackedBarRenderer3D35.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator44 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D35.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator44, true);
        java.awt.Font font49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock50 = new org.jfree.chart.block.LabelBlock("{0}", font49);
        java.awt.geom.Rectangle2D rectangle2D51 = labelBlock50.getBounds();
        stackedBarRenderer3D35.setSeriesShape(5, (java.awt.Shape) rectangle2D51);
        java.awt.geom.Rectangle2D rectangle2D53 = rectangleInsets28.createInsetRectangle(rectangle2D51);
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        org.jfree.chart.axis.NumberAxis numberAxis56 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape57 = numberAxis56.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer59 = null;
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot(xYDataset54, (org.jfree.chart.axis.ValueAxis) numberAxis56, valueAxis58, xYItemRenderer59);
        org.jfree.chart.JFreeChart jFreeChart61 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot60);
        org.jfree.chart.axis.ValueAxis valueAxis62 = xYPlot60.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace63 = xYPlot60.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation64 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot60.setRangeAxisLocation(axisLocation64);
        xYPlot60.setRangeCrosshairValue(1.0d);
        java.awt.Font font68 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot60.setNoDataMessageFont(font68);
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = xYPlot60.getRangeAxisEdge(0);
        double double72 = dateAxis1.dateToJava2D(date6, rectangle2D51, rectangleEdge71);
        dateAxis1.setFixedAutoRange((double) 'a');
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-1.0d) + "'", double30 == (-1.0d));
        org.junit.Assert.assertNull(categorySeriesLabelGenerator36);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(valueAxis62);
        org.junit.Assert.assertNull(axisSpace63);
        org.junit.Assert.assertNotNull(axisLocation64);
        org.junit.Assert.assertNotNull(font68);
        org.junit.Assert.assertNotNull(rectangleEdge71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color8 = java.awt.Color.darkGray;
        java.awt.Color color9 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer10 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color6, paint7, (java.awt.Paint) color8, (java.awt.Paint) color9);
        java.awt.Paint paint11 = waterfallBarRenderer10.getLastBarPaint();
        java.awt.Shape shape12 = waterfallBarRenderer10.getBaseShape();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.awt.Paint paint15 = categoryAxis3D14.getLabelPaint();
        java.awt.Color color16 = java.awt.Color.pink;
        categoryAxis3D14.setAxisLinePaint((java.awt.Paint) color16);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer21 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator26 = stackedBarRenderer3D25.getLegendItemURLGenerator();
        java.awt.Paint paint28 = stackedBarRenderer3D25.getSeriesPaint(3);
        boolean boolean29 = stackedBarRenderer3D25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator34 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D25.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator34, true);
        java.awt.Font font39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock40 = new org.jfree.chart.block.LabelBlock("{0}", font39);
        java.awt.geom.Rectangle2D rectangle2D41 = labelBlock40.getBounds();
        stackedBarRenderer3D25.setSeriesShape(5, (java.awt.Shape) rectangle2D41);
        boolean boolean43 = stackedAreaRenderer21.equals((java.lang.Object) rectangle2D41);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean45 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge44);
        double double46 = categoryAxis3D14.getCategoryStart(10, 3, rectangle2D41, rectangleEdge44);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double48 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D41, rectangleEdge47);
        boolean boolean49 = org.jfree.chart.util.ShapeUtilities.equal(shape12, (java.awt.Shape) rectangle2D41);
        try {
            blockBorder4.draw(graphics2D5, rectangle2D41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator26);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape4 = numberAxis3.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3, valueAxis5, xYItemRenderer6);
        xYPlot7.setBackgroundImageAlignment((int) (byte) -1);
        float float10 = xYPlot7.getForegroundAlpha();
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = xYPlot7.getOrientation();
        java.lang.String str12 = plotOrientation11.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation11);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PlotOrientation.VERTICAL" + "'", str12.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.LegendItem legendItem4 = stackedAreaRenderer1.getLegendItem(3, 8);
        java.lang.Object obj5 = stackedAreaRenderer1.clone();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo7);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState9 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo8);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator14 = stackedBarRenderer3D13.getLegendItemURLGenerator();
        java.awt.Paint paint16 = stackedBarRenderer3D13.getSeriesPaint(3);
        boolean boolean17 = stackedBarRenderer3D13.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator18 = null;
        stackedBarRenderer3D13.setLegendItemURLGenerator(categorySeriesLabelGenerator18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint22 = categoryPlot21.getRangeGridlinePaint();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean25 = numberAxis24.isNegativeArrowVisible();
        org.jfree.chart.plot.Marker marker26 = null;
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock29 = new org.jfree.chart.block.LabelBlock("{0}", font28);
        java.awt.geom.Rectangle2D rectangle2D30 = labelBlock29.getBounds();
        stackedBarRenderer3D13.drawRangeMarker(graphics2D20, categoryPlot21, (org.jfree.chart.axis.ValueAxis) numberAxis24, marker26, rectangle2D30);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double33 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D30, rectangleEdge32);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape39 = numberAxis38.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) numberAxis38, valueAxis40, xYItemRenderer41);
        java.lang.Number[] numberArray47 = new java.lang.Number[] { 5, (byte) 10 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 5, (byte) 10 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray47, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.CENTER_RIGHT", "ThreadContext", numberArray51);
        java.lang.Number[] numberArray57 = new java.lang.Number[] { 5, (byte) 10 };
        java.lang.Number[] numberArray60 = new java.lang.Number[] { 5, (byte) 10 };
        java.lang.Number[][] numberArray61 = new java.lang.Number[][] { numberArray57, numberArray60 };
        org.jfree.data.category.CategoryDataset categoryDataset62 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.CENTER_RIGHT", "ThreadContext", numberArray61);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset63 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray51, numberArray61);
        java.util.List list64 = defaultIntervalCategoryDataset63.getRowKeys();
        try {
            stackedAreaRenderer1.drawItem(graphics2D6, categoryItemRendererState9, rectangle2D30, categoryPlot34, categoryAxis35, (org.jfree.chart.axis.ValueAxis) numberAxis38, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset63, (int) (byte) 10, 3, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.getValue(): series index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItem4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(numberArray57);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(categoryDataset62);
        org.junit.Assert.assertNotNull(list64);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        double double5 = categoryPlot0.getRangeCrosshairValue();
        java.awt.Paint paint6 = categoryPlot0.getBackgroundPaint();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Color color7 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer8 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color4, paint5, (java.awt.Paint) color6, (java.awt.Paint) color7);
        stackedBarRenderer3D3.setBasePaint(paint5, false);
        boolean boolean11 = stackedBarRenderer3D3.getAutoPopulateSeriesPaint();
        stackedBarRenderer3D3.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = new org.jfree.chart.labels.ItemLabelPosition();
        stackedBarRenderer3D3.setBaseNegativeItemLabelPosition(itemLabelPosition14, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator17 = stackedBarRenderer3D3.getBaseURLGenerator();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(categoryURLGenerator17);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape7 = numberAxis6.getLeftArrow();
        numberAxis1.setLeftArrow(shape7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean11 = numberAxis10.isNegativeArrowVisible();
        numberAxis10.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape16 = numberAxis15.getLeftArrow();
        numberAxis10.setLeftArrow(shape16);
        numberAxis1.setDownArrow(shape16);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset21 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset21);
        java.text.DateFormat dateFormat25 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = new org.jfree.chart.axis.DateTickUnit(3, (int) 'a', dateFormat25);
        java.lang.String str27 = dateTickUnit26.toString();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity29 = new org.jfree.chart.entity.CategoryItemEntity(shape16, "", "DateTickUnit[HOUR, 97]", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset21, (java.lang.Comparable) dateTickUnit26, (java.lang.Comparable) (short) 1);
        categoryItemEntity29.setRowKey((java.lang.Comparable) 1L);
        java.lang.Object obj32 = categoryItemEntity29.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "DateTickUnit[HOUR, 97]" + "'", str27.equals("DateTickUnit[HOUR, 97]"));
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        java.lang.Class class2 = null;
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date6 = dateRange5.getUpperDate();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date6, timeZone7);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date12 = dateRange11.getUpperDate();
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange(date6, date12);
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.DateTick dateTick18 = new org.jfree.chart.axis.DateTick(date6, "UnitType.ABSOLUTE", textAnchor15, textAnchor16, (double) 9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder19 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.lang.String str21 = textAnchor20.toString();
        boolean boolean22 = datasetRenderingOrder19.equals((java.lang.Object) textAnchor20);
        org.jfree.chart.axis.NumberTick numberTick24 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (-5.0d), "", textAnchor16, textAnchor20, (double) 4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(datasetRenderingOrder19);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str21.equals("TextAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double14 = rectangleInsets13.getRight();
        xYPlot6.setInsets(rectangleInsets13);
        boolean boolean16 = xYPlot6.isDomainZoomable();
        int int17 = xYPlot6.getSeriesCount();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        xYPlot6.setBackgroundImageAlignment((int) (byte) -1);
        float float9 = xYPlot6.getForegroundAlpha();
        int int10 = xYPlot6.getWeight();
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot6.getDataset((-452));
        java.awt.Paint paint13 = null;
        try {
            xYPlot6.setDomainGridlinePaint(paint13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(xYDataset12);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape4 = numberAxis3.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3, valueAxis5, xYItemRenderer6);
        xYPlot7.setBackgroundImageAlignment((int) (byte) -1);
        float float10 = xYPlot7.getForegroundAlpha();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator15 = stackedBarRenderer3D14.getLegendItemURLGenerator();
        java.awt.Stroke stroke16 = stackedBarRenderer3D14.getBaseStroke();
        xYPlot7.setOutlineStroke(stroke16);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) xYPlot7);
        jFreeChart18.setTextAntiAlias(false);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean23 = numberAxis22.isNegativeArrowVisible();
        numberAxis22.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape28 = numberAxis27.getLeftArrow();
        numberAxis22.setLeftArrow(shape28);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean32 = numberAxis31.isNegativeArrowVisible();
        numberAxis31.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape37 = numberAxis36.getLeftArrow();
        numberAxis31.setLeftArrow(shape37);
        numberAxis22.setDownArrow(shape37);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity42 = new org.jfree.chart.entity.TickLabelEntity(shape37, "ThreadContext", "java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint44 = textTitle43.getPaint();
        java.awt.Paint paint45 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        textTitle43.setPaint(paint45);
        boolean boolean47 = tickLabelEntity42.equals((java.lang.Object) textTitle43);
        jFreeChart18.addSubtitle((org.jfree.chart.title.Title) textTitle43);
        textTitle43.setToolTipText("Preceding");
        org.jfree.data.xy.XYDataset xYDataset51 = null;
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape54 = numberAxis53.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer56 = null;
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot(xYDataset51, (org.jfree.chart.axis.ValueAxis) numberAxis53, valueAxis55, xYItemRenderer56);
        org.jfree.chart.JFreeChart jFreeChart58 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot57);
        jFreeChart58.setTextAntiAlias(false);
        boolean boolean61 = jFreeChart58.getAntiAlias();
        org.jfree.chart.title.Title title63 = jFreeChart58.getSubtitle(0);
        title63.setMargin((double) 10.0f, (double) 10L, 35.0d, (double) 1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment69 = org.jfree.chart.util.VerticalAlignment.CENTER;
        title63.setVerticalAlignment(verticalAlignment69);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment71 = title63.getHorizontalAlignment();
        textTitle43.setTextAlignment(horizontalAlignment71);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(title63);
        org.junit.Assert.assertNotNull(verticalAlignment69);
        org.junit.Assert.assertNotNull(horizontalAlignment71);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Stroke stroke2 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        boolean boolean6 = numberAxis1.equals((java.lang.Object) 12);
        double double7 = numberAxis1.getLowerBound();
        java.text.NumberFormat numberFormat8 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape12 = numberAxis11.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis11, valueAxis13, xYItemRenderer14);
        xYPlot15.setBackgroundImageAlignment((int) (byte) -1);
        float float18 = xYPlot15.getForegroundAlpha();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator23 = stackedBarRenderer3D22.getLegendItemURLGenerator();
        java.awt.Stroke stroke24 = stackedBarRenderer3D22.getBaseStroke();
        xYPlot15.setOutlineStroke(stroke24);
        numberAxis1.setAxisLineStroke(stroke24);
        java.awt.Stroke stroke27 = numberAxis1.getTickMarkStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-49.5d) + "'", double7 == (-49.5d));
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean3 = numberAxis2.isNegativeArrowVisible();
        numberAxis2.setAutoTickUnitSelection(false, false);
        numberAxis2.setLabel("ThreadContext");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = numberAxis2.getTickUnit();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset10 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class11 = null;
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date15 = dateRange14.getUpperDate();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date15, timeZone16);
        org.jfree.data.time.DateRange dateRange20 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date21 = dateRange20.getUpperDate();
        org.jfree.data.time.DateRange dateRange22 = new org.jfree.data.time.DateRange(date15, date21);
        org.jfree.data.general.PieDataset pieDataset23 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset10, (java.lang.Comparable) date15);
        org.jfree.data.category.CategoryDataset categoryDataset24 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) numberTickUnit9, (org.jfree.data.KeyedValues) pieDataset23);
        tickUnits0.add((org.jfree.chart.axis.TickUnit) numberTickUnit9);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(numberTickUnit9);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(pieDataset23);
        org.junit.Assert.assertNotNull(categoryDataset24);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.awt.Color color2 = java.awt.Color.magenta;
        boolean boolean3 = blockContainer0.equals((java.lang.Object) color2);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class1 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date5, date11);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) date5);
        java.lang.Comparable comparable14 = null;
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset13, comparable14, 100.0d, (int) '#');
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset13);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        java.awt.Stroke stroke21 = ringPlot19.getSectionOutlineStroke((java.lang.Comparable) 12);
        java.lang.Object obj22 = ringPlot19.clone();
        java.awt.Paint paint23 = ringPlot19.getShadowPaint();
        double double24 = ringPlot19.getInnerSeparatorExtension();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = ringPlot19.getInsets();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.2d + "'", double24 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = stackedBarRenderer3D3.getSeriesPositiveItemLabelPosition(0);
        stackedBarRenderer3D3.setItemLabelAnchorOffset((double) '#');
        boolean boolean9 = stackedBarRenderer3D3.getAutoPopulateSeriesPaint();
        java.awt.Paint paint10 = stackedBarRenderer3D3.getBaseOutlinePaint();
        stackedBarRenderer3D3.setAutoPopulateSeriesFillPaint(false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) 0.0f);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        try {
            java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMaxRegularValue((int) '4', 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class1 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date5, date11);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) date5);
        java.lang.Comparable comparable14 = null;
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset13, comparable14, 100.0d, (int) '#');
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset13);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        java.awt.Stroke stroke21 = ringPlot19.getSectionOutlineStroke((java.lang.Comparable) 12);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class23 = null;
        org.jfree.data.time.DateRange dateRange26 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date27 = dateRange26.getUpperDate();
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date27, timeZone28);
        org.jfree.data.time.DateRange dateRange32 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date33 = dateRange32.getUpperDate();
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange(date27, date33);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22, (java.lang.Comparable) date27);
        java.lang.Comparable comparable36 = null;
        org.jfree.data.general.PieDataset pieDataset39 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset35, comparable36, 100.0d, (int) '#');
        boolean boolean40 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset35);
        org.jfree.chart.plot.RingPlot ringPlot41 = new org.jfree.chart.plot.RingPlot(pieDataset35);
        java.awt.Stroke stroke43 = ringPlot41.getSectionOutlineStroke((java.lang.Comparable) 12);
        java.awt.Stroke stroke44 = ringPlot41.getBaseSectionOutlineStroke();
        org.jfree.chart.util.Rotation rotation45 = ringPlot41.getDirection();
        ringPlot19.setDirection(rotation45);
        double double47 = ringPlot19.getLabelLinkMargin();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertNotNull(pieDataset39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(stroke43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(rotation45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.05d + "'", double47 == 0.05d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot0.getDomainAxis((int) (byte) 0);
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = stackedBarRenderer3D11.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedBarRenderer3D11.getSeriesPositiveItemLabelPosition(0);
        stackedBarRenderer3D11.setItemLabelAnchorOffset((double) '#');
        boolean boolean17 = stackedBarRenderer3D11.getAutoPopulateSeriesPaint();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D11, false);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        categoryPlot0.setRangeAxis(0, valueAxis21);
        categoryPlot0.clearRangeMarkers();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.general.DatasetGroup datasetGroup2 = new org.jfree.data.general.DatasetGroup();
        taskSeriesCollection0.setGroup(datasetGroup2);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.LegendItem legendItem8 = stackedAreaRenderer5.getLegendItem(3, 8);
        java.lang.Object obj9 = stackedAreaRenderer5.clone();
        boolean boolean10 = datasetGroup2.equals((java.lang.Object) stackedAreaRenderer5);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double14 = rectangleInsets13.getRight();
        xYPlot6.setInsets(rectangleInsets13);
        java.lang.Object obj16 = xYPlot6.clone();
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot6.getDataset(3);
        xYPlot6.setDomainCrosshairValue((double) 3, true);
        java.lang.String str22 = xYPlot6.getPlotType();
        boolean boolean23 = xYPlot6.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "XY Plot" + "'", str22.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(100);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, serialDate2);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class1 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date5, date11);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) date5);
        java.lang.Comparable comparable14 = null;
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset13, comparable14, 100.0d, (int) '#');
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset13);
        org.jfree.data.general.PieDataset pieDataset22 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset13, (java.lang.Comparable) (short) 1, (double) 12, (int) (short) 100);
        java.text.DateFormat dateFormat25 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = new org.jfree.chart.axis.DateTickUnit(3, (int) 'a', dateFormat25);
        java.lang.Class class27 = null;
        org.jfree.data.time.DateRange dateRange30 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date31 = dateRange30.getUpperDate();
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date31, timeZone32);
        org.jfree.data.time.DateRange dateRange36 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date37 = dateRange36.getUpperDate();
        org.jfree.data.time.DateRange dateRange38 = new org.jfree.data.time.DateRange(date31, date37);
        java.lang.Class class39 = null;
        org.jfree.data.time.DateRange dateRange42 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date43 = dateRange42.getUpperDate();
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date43, timeZone44);
        org.jfree.data.time.DateRange dateRange48 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date49 = dateRange48.getUpperDate();
        org.jfree.data.time.DateRange dateRange50 = new org.jfree.data.time.DateRange(date43, date49);
        org.jfree.data.time.DateRange dateRange51 = new org.jfree.data.time.DateRange(date37, date43);
        java.util.Date date52 = dateTickUnit26.addToDate(date37);
        org.jfree.data.general.PieDataset pieDataset54 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset22, (java.lang.Comparable) dateTickUnit26, (double) 23640L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(pieDataset22);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(pieDataset54);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        jFreeChart7.setTextAntiAlias(false);
        jFreeChart7.setTitle("0");
        java.awt.Paint paint12 = jFreeChart7.getBorderPaint();
        jFreeChart7.setBorderVisible(true);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class1 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date5, date11);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) date5);
        java.lang.Comparable comparable14 = null;
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset13, comparable14, 100.0d, (int) '#');
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset13);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        java.awt.Stroke stroke21 = ringPlot19.getSectionOutlineStroke((java.lang.Comparable) 12);
        java.lang.Object obj22 = ringPlot19.clone();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator23 = null;
        ringPlot19.setLabelGenerator(pieSectionLabelGenerator23);
        ringPlot19.setLabelLinkMargin((double) (byte) 100);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent27 = null;
        ringPlot19.notifyListeners(plotChangeEvent27);
        org.jfree.chart.block.LineBorder lineBorder29 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint30 = lineBorder29.getPaint();
        ringPlot19.setLabelOutlinePaint(paint30);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator32 = ringPlot19.getToolTipGenerator();
        double double33 = ringPlot19.getMaximumExplodePercent();
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) 12);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator36 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean37 = valueMarker35.equals((java.lang.Object) standardCategoryToolTipGenerator36);
        java.awt.Paint paint38 = valueMarker35.getOutlinePaint();
        org.jfree.chart.block.BlockBorder blockBorder39 = new org.jfree.chart.block.BlockBorder(paint38);
        ringPlot19.setBaseSectionPaint(paint38);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(pieToolTipGenerator32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape7 = numberAxis6.getLeftArrow();
        numberAxis1.setLeftArrow(shape7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean11 = numberAxis10.isNegativeArrowVisible();
        numberAxis10.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape16 = numberAxis15.getLeftArrow();
        numberAxis10.setLeftArrow(shape16);
        numberAxis1.setDownArrow(shape16);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity21 = new org.jfree.chart.entity.TickLabelEntity(shape16, "ThreadContext", "java.awt.Color[r=64,g=64,b=64]");
        java.lang.Object obj22 = tickLabelEntity21.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("({0}, {1}) = {3} - {4}", "DatasetRenderingOrder.REVERSE", "", "ERROR : Relative To String", "java.awt.Color[r=255,g=255,b=0]");
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot6.getRangeAxisEdge((int) 'a');
        org.jfree.chart.plot.Plot plot11 = xYPlot6.getParent();
        java.awt.Stroke stroke12 = xYPlot6.getDomainZeroBaselineStroke();
        xYPlot6.setNoDataMessage("ThreadContext");
        xYPlot6.setDomainZeroBaselineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot6.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand22 = null;
        numberAxis21.setMarkerBand(markerAxisBand22);
        xYPlot6.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) numberAxis21);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double14 = rectangleInsets13.getRight();
        xYPlot6.setInsets(rectangleInsets13);
        java.lang.Object obj16 = xYPlot6.clone();
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot6.getDataset(3);
        xYPlot6.setDomainCrosshairValue((double) 3, true);
        java.awt.Paint paint22 = xYPlot6.getRangeTickBandPaint();
        org.jfree.data.xy.XYDataset xYDataset24 = xYPlot6.getDataset(9999);
        org.jfree.chart.axis.AxisSpace axisSpace25 = xYPlot6.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNull(xYDataset24);
        org.junit.Assert.assertNull(axisSpace25);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace9 = xYPlot6.getFixedDomainAxisSpace();
        java.awt.Color color10 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = color10.createContext(colorModel11, rectangle12, rectangle2D13, affineTransform14, renderingHints15);
        int int17 = color10.getTransparency();
        java.awt.Color color18 = color10.darker();
        xYPlot6.setRangeCrosshairPaint((java.awt.Paint) color10);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo21);
        java.awt.Font font24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock25 = new org.jfree.chart.block.LabelBlock("{0}", font24);
        java.awt.geom.Rectangle2D rectangle2D26 = labelBlock25.getBounds();
        plotRenderingInfo22.setPlotArea(rectangle2D26);
        java.awt.geom.Point2D point2D28 = null;
        xYPlot6.zoomDomainAxes((double) 1.0f, plotRenderingInfo22, point2D28);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintContext16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(rectangle2D26);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 12);
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        valueMarker11.setLabelTextAnchor(textAnchor12);
        org.jfree.chart.text.TextAnchor textAnchor15 = null;
        java.awt.Shape shape16 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D7, (float) 97, (float) 100, textAnchor12, (double) (-452), textAnchor15);
        try {
            java.awt.Shape shape17 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("XY Plot", graphics2D1, (float) 15, (float) (byte) 1, textAnchor4, (double) 60000L, textAnchor12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNull(shape16);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = stackedBarRenderer3D3.getSeriesPositiveItemLabelPosition(0);
        boolean boolean7 = stackedBarRenderer3D3.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot0.getDomainAxis((int) (byte) 0);
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = stackedBarRenderer3D11.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedBarRenderer3D11.getSeriesPositiveItemLabelPosition(0);
        stackedBarRenderer3D11.setItemLabelAnchorOffset((double) '#');
        boolean boolean17 = stackedBarRenderer3D11.getAutoPopulateSeriesPaint();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D11, false);
        java.awt.Color color20 = java.awt.Color.magenta;
        stackedBarRenderer3D11.setBaseFillPaint((java.awt.Paint) color20);
        java.awt.Stroke stroke22 = stackedBarRenderer3D11.getBaseOutlineStroke();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight(2958465);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot0.getRangeMarkers((int) (short) 10, layer4);
        java.lang.String str6 = categoryPlot0.getPlotType();
        java.awt.Paint paint7 = categoryPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("UnitType.ABSOLUTE");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis1.getTickMarkPosition();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("UnitType.ABSOLUTE");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = dateAxis4.getTickMarkPosition();
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date9 = dateRange8.getUpperDate();
        java.awt.Color color10 = java.awt.Color.darkGray;
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Color color13 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer14 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color10, paint11, (java.awt.Paint) color12, (java.awt.Paint) color13);
        int int15 = color10.getTransparency();
        java.awt.Color color16 = java.awt.Color.darkGray;
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Color color19 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer20 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color16, paint17, (java.awt.Paint) color18, (java.awt.Paint) color19);
        java.awt.Color color21 = java.awt.Color.cyan;
        waterfallBarRenderer20.setBaseOutlinePaint((java.awt.Paint) color21);
        java.awt.Stroke stroke23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        waterfallBarRenderer20.setBaseStroke(stroke23, false);
        org.jfree.chart.block.BlockBorder blockBorder30 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = blockBorder30.getInsets();
        double double33 = rectangleInsets31.calculateTopInset(0.0d);
        org.jfree.chart.block.LineBorder lineBorder34 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color10, stroke23, rectangleInsets31);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D38 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator39 = stackedBarRenderer3D38.getLegendItemURLGenerator();
        java.awt.Paint paint41 = stackedBarRenderer3D38.getSeriesPaint(3);
        boolean boolean42 = stackedBarRenderer3D38.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator47 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D38.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator47, true);
        java.awt.Font font52 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock53 = new org.jfree.chart.block.LabelBlock("{0}", font52);
        java.awt.geom.Rectangle2D rectangle2D54 = labelBlock53.getBounds();
        stackedBarRenderer3D38.setSeriesShape(5, (java.awt.Shape) rectangle2D54);
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets31.createInsetRectangle(rectangle2D54);
        org.jfree.data.xy.XYDataset xYDataset57 = null;
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer62 = null;
        org.jfree.chart.plot.XYPlot xYPlot63 = new org.jfree.chart.plot.XYPlot(xYDataset57, (org.jfree.chart.axis.ValueAxis) numberAxis59, valueAxis61, xYItemRenderer62);
        org.jfree.chart.JFreeChart jFreeChart64 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot63);
        org.jfree.chart.axis.ValueAxis valueAxis65 = xYPlot63.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace66 = xYPlot63.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation67 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot63.setRangeAxisLocation(axisLocation67);
        xYPlot63.setRangeCrosshairValue(1.0d);
        java.awt.Font font71 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot63.setNoDataMessageFont(font71);
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = xYPlot63.getRangeAxisEdge(0);
        double double75 = dateAxis4.dateToJava2D(date9, rectangle2D54, rectangleEdge74);
        org.jfree.data.KeyedObjects2D keyedObjects2D76 = new org.jfree.data.KeyedObjects2D();
        int int77 = keyedObjects2D76.getRowCount();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset78 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class79 = null;
        org.jfree.data.time.DateRange dateRange82 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date83 = dateRange82.getUpperDate();
        java.util.TimeZone timeZone84 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance(class79, date83, timeZone84);
        org.jfree.data.time.DateRange dateRange88 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date89 = dateRange88.getUpperDate();
        org.jfree.data.time.DateRange dateRange90 = new org.jfree.data.time.DateRange(date83, date89);
        org.jfree.data.general.PieDataset pieDataset91 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset78, (java.lang.Comparable) date83);
        org.jfree.data.time.Month month92 = new org.jfree.data.time.Month(date83);
        java.util.Date date93 = month92.getEnd();
        int int94 = keyedObjects2D76.getRowIndex((java.lang.Comparable) date93);
        dateAxis1.setRange(date9, date93);
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-1.0d) + "'", double33 == (-1.0d));
        org.junit.Assert.assertNull(categorySeriesLabelGenerator39);
        org.junit.Assert.assertNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(valueAxis65);
        org.junit.Assert.assertNull(axisSpace66);
        org.junit.Assert.assertNotNull(axisLocation67);
        org.junit.Assert.assertNotNull(font71);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNull(regularTimePeriod85);
        org.junit.Assert.assertNotNull(date89);
        org.junit.Assert.assertNotNull(pieDataset91);
        org.junit.Assert.assertNotNull(date93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + (-1) + "'", int94 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight(2958465);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot0.getRangeMarkers((int) (short) 10, layer4);
        java.lang.String str6 = categoryPlot0.getPlotType();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double10 = categoryAxis3D9.getLowerMargin();
        categoryPlot0.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D9);
        categoryAxis3D9.setLabel("RectangleAnchor.CENTER");
        int int14 = categoryAxis3D9.getMaximumCategoryLabelLines();
        categoryAxis3D9.addCategoryLabelToolTip((java.lang.Comparable) "({0}, {1}) = {3} - {4}", "ThreadContext");
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape4 = numberAxis3.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3, valueAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot7.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace10 = xYPlot7.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot7.setRangeAxisLocation(axisLocation11);
        xYPlot7.setRangeCrosshairValue(1.0d);
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot7.setNoDataMessageFont(font15);
        java.awt.Color color17 = java.awt.Color.orange;
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, (java.awt.Paint) color17);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = textBlock18.getLineAlignment();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint1, (java.awt.Paint) color2, (java.awt.Paint) color3);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        java.awt.Color color9 = java.awt.Color.darkGray;
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color11 = java.awt.Color.darkGray;
        java.awt.Color color12 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer13 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color9, paint10, (java.awt.Paint) color11, (java.awt.Paint) color12);
        stackedBarRenderer3D8.setBasePaint(paint10, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = stackedBarRenderer3D8.getItemLabelGenerator((int) (short) 0, 3);
        stackedBarRenderer3D8.setBase(8.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = stackedBarRenderer3D8.getSeriesNegativeItemLabelPosition(0);
        waterfallBarRenderer4.setBasePositiveItemLabelPosition(itemLabelPosition22);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) '#');
        java.awt.Paint paint27 = stackedBarRenderer3D26.getWallPaint();
        waterfallBarRenderer4.setBaseFillPaint(paint27, false);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape4 = numberAxis3.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3, valueAxis5, xYItemRenderer6);
        xYPlot7.setBackgroundImageAlignment((int) (byte) -1);
        float float10 = xYPlot7.getForegroundAlpha();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator15 = stackedBarRenderer3D14.getLegendItemURLGenerator();
        java.awt.Stroke stroke16 = stackedBarRenderer3D14.getBaseStroke();
        xYPlot7.setOutlineStroke(stroke16);
        taskSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot7);
        org.jfree.data.time.DateRange dateRange21 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date22 = dateRange21.getUpperDate();
        org.jfree.data.general.PieDataset pieDataset23 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, (java.lang.Comparable) date22);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(pieDataset23);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getRowKeys();
        double double3 = defaultStatisticalCategoryDataset0.getRangeLowerBound(true);
        java.util.List list4 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.jfree.data.general.DatasetGroup datasetGroup5 = defaultStatisticalCategoryDataset0.getGroup();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(datasetGroup5);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("UnitType.ABSOLUTE");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = stackedBarRenderer3D10.getLegendItemURLGenerator();
        java.awt.Paint paint13 = stackedBarRenderer3D10.getSeriesPaint(3);
        boolean boolean14 = stackedBarRenderer3D10.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator19 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D10.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator19, true);
        java.awt.Font font24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock25 = new org.jfree.chart.block.LabelBlock("{0}", font24);
        java.awt.geom.Rectangle2D rectangle2D26 = labelBlock25.getBounds();
        stackedBarRenderer3D10.setSeriesShape(5, (java.awt.Shape) rectangle2D26);
        boolean boolean28 = stackedAreaRenderer6.equals((java.lang.Object) rectangle2D26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = dateAxis3.java2DToValue((double) ' ', rectangle2D26, rectangleEdge29);
        ringPlot0.drawBackgroundImage(graphics2D1, rectangle2D26);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 9.223372036854776E18d + "'", double30 == 9.223372036854776E18d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 0, (int) '4', (int) (byte) 100);
        org.jfree.chart.block.BorderArrangement borderArrangement4 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) borderArrangement4);
        java.lang.Object obj6 = null;
        boolean boolean7 = segmentedTimeline3.equals(obj6);
        java.util.Date date9 = segmentedTimeline3.getDate(1L);
        long long11 = segmentedTimeline3.getTimeFromLong((long) 4);
        long long12 = segmentedTimeline3.getSegmentsGroupSize();
        long long13 = segmentedTimeline3.getSegmentsIncludedSize();
        org.jfree.data.time.DateRange dateRange16 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date17 = dateRange16.getUpperDate();
        long long18 = segmentedTimeline3.getTime(date17);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 4L + "'", long11 == 4L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 5L + "'", long18 == 5L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) '#');
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = stackedBarRenderer3D7.getLegendItemURLGenerator();
        java.awt.Stroke stroke9 = stackedBarRenderer3D7.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = stackedBarRenderer3D7.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor12 = itemLabelPosition11.getItemLabelAnchor();
        stackedBarRenderer3D2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition11, false);
        java.awt.Color color16 = java.awt.Color.darkGray;
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Color color19 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer20 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color16, paint17, (java.awt.Paint) color18, (java.awt.Paint) color19);
        java.awt.Paint paint21 = waterfallBarRenderer20.getLastBarPaint();
        java.awt.Color color22 = java.awt.Color.darkGray;
        java.awt.Paint paint23 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color24 = java.awt.Color.darkGray;
        java.awt.Color color25 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer26 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color22, paint23, (java.awt.Paint) color24, (java.awt.Paint) color25);
        java.awt.Color color27 = java.awt.Color.cyan;
        waterfallBarRenderer26.setBaseOutlinePaint((java.awt.Paint) color27);
        java.awt.Color color29 = java.awt.Color.darkGray;
        java.awt.Paint paint30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color31 = java.awt.Color.darkGray;
        java.awt.Color color32 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer33 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color29, paint30, (java.awt.Paint) color31, (java.awt.Paint) color32);
        waterfallBarRenderer26.setBaseOutlinePaint(paint30);
        java.awt.Color color35 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color35.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        int int42 = color35.getTransparency();
        java.awt.Color color43 = color35.darker();
        java.awt.Color color44 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel45 = null;
        java.awt.Rectangle rectangle46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        java.awt.geom.AffineTransform affineTransform48 = null;
        java.awt.RenderingHints renderingHints49 = null;
        java.awt.PaintContext paintContext50 = color44.createContext(colorModel45, rectangle46, rectangle2D47, affineTransform48, renderingHints49);
        int int51 = color44.getTransparency();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer52 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint21, paint30, (java.awt.Paint) color35, (java.awt.Paint) color44);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier53 = waterfallBarRenderer52.getDrawingSupplier();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition54 = null;
        waterfallBarRenderer52.setPositiveItemLabelPositionFallback(itemLabelPosition54);
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean58 = numberAxis57.isNegativeArrowVisible();
        numberAxis57.resizeRange((double) 100);
        numberAxis57.resizeRange((double) 100L);
        numberAxis57.setTickMarksVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean67 = numberAxis66.isNegativeArrowVisible();
        numberAxis66.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis71 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape72 = numberAxis71.getLeftArrow();
        numberAxis66.setLeftArrow(shape72);
        java.awt.Shape shape76 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape72, 0.0d, (double) (byte) -1);
        numberAxis57.setDownArrow(shape72);
        waterfallBarRenderer52.setBaseShape(shape72, true);
        java.awt.Paint paint82 = waterfallBarRenderer52.getItemPaint((-1), (int) (byte) 10);
        stackedBarRenderer3D2.setSeriesItemLabelPaint(6, paint82);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(itemLabelAnchor12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(paintContext50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNull(drawingSupplier53);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(shape72);
        org.junit.Assert.assertNotNull(shape76);
        org.junit.Assert.assertNotNull(paint82);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape4 = numberAxis3.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3, valueAxis5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot7.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace10 = xYPlot7.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot7.setRangeAxisLocation(axisLocation11);
        xYPlot7.setRangeCrosshairValue(1.0d);
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot7.setNoDataMessageFont(font15);
        java.awt.Color color17 = java.awt.Color.orange;
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, (java.awt.Paint) color17);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 12);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator21 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean22 = valueMarker20.equals((java.lang.Object) standardCategoryToolTipGenerator21);
        java.awt.Paint paint23 = valueMarker20.getOutlinePaint();
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("{0}", font25);
        valueMarker20.setLabelFont(font25);
        float float28 = valueMarker20.getAlpha();
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape32 = numberAxis31.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis31, valueAxis33, xYItemRenderer34);
        xYPlot35.setBackgroundImageAlignment((int) (byte) -1);
        float float38 = xYPlot35.getForegroundAlpha();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D42 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator43 = stackedBarRenderer3D42.getLegendItemURLGenerator();
        java.awt.Stroke stroke44 = stackedBarRenderer3D42.getBaseStroke();
        xYPlot35.setOutlineStroke(stroke44);
        valueMarker20.setStroke(stroke44);
        boolean boolean47 = textBlock18.equals((java.lang.Object) valueMarker20);
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor51 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        textBlock18.draw(graphics2D48, (float) 5, 1.0f, textBlockAnchor51, (float) (-452), (float) 6, (double) (byte) 1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.8f + "'", float28 == 0.8f);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 1.0f + "'", float38 == 1.0f);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor51);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot0.getDomainAxis((int) (byte) 0);
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = stackedBarRenderer3D11.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedBarRenderer3D11.getSeriesPositiveItemLabelPosition(0);
        stackedBarRenderer3D11.setItemLabelAnchorOffset((double) '#');
        boolean boolean17 = stackedBarRenderer3D11.getAutoPopulateSeriesPaint();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D11, false);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        categoryPlot0.setRangeAxis(0, valueAxis21);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot0.getRangeMarkers(layer23);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape28 = numberAxis27.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) numberAxis27, valueAxis29, xYItemRenderer30);
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot31);
        jFreeChart32.setTextAntiAlias(false);
        boolean boolean35 = jFreeChart32.getAntiAlias();
        org.jfree.chart.title.Title title37 = jFreeChart32.getSubtitle(0);
        java.awt.Stroke stroke38 = jFreeChart32.getBorderStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke38);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(title37);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(3, (int) 'a', dateFormat2);
        java.lang.String str4 = dateTickUnit3.toString();
        int int5 = dateTickUnit3.getCalendarField();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "DateTickUnit[HOUR, 97]" + "'", str4.equals("DateTickUnit[HOUR, 97]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 11 + "'", int5 == 11);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Color color7 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer8 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color4, paint5, (java.awt.Paint) color6, (java.awt.Paint) color7);
        stackedBarRenderer3D3.setBasePaint(paint5, false);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset11.setValue((double) 60000L, (java.lang.Comparable) 10.0f, (java.lang.Comparable) 2);
        org.jfree.data.Range range16 = stackedBarRenderer3D3.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11);
        java.awt.Paint paint17 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        stackedBarRenderer3D3.setWallPaint(paint17);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class1 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date5, date11);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) date5);
        java.lang.Comparable comparable14 = null;
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset13, comparable14, 100.0d, (int) '#');
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset13);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        java.awt.Stroke stroke21 = ringPlot19.getSectionOutlineStroke((java.lang.Comparable) 12);
        ringPlot19.setLabelLinksVisible(false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(stroke21);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean3 = numberAxis2.isNegativeArrowVisible();
        numberAxis2.resizeRange((double) 100);
        numberAxis2.resizeRange((double) 100L);
        numberAxis2.zoomRange((double) (short) -1, (double) 8);
        boolean boolean11 = color0.equals((java.lang.Object) numberAxis2);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        xYPlot6.setBackgroundImageAlignment((int) (byte) -1);
        float float9 = xYPlot6.getForegroundAlpha();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = xYPlot6.getOrientation();
        java.awt.Stroke stroke11 = xYPlot6.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getEndPercent();
        ganttRenderer0.setStartPercent(0.65d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.65d + "'", double1 == 0.65d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color3 = java.awt.Color.darkGray;
        java.awt.Color color4 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer5 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color1, paint2, (java.awt.Paint) color3, (java.awt.Paint) color4);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        waterfallBarRenderer5.setFirstBarPaint(paint6);
        java.awt.Paint paint8 = waterfallBarRenderer5.getLastBarPaint();
        boolean boolean9 = tickUnits0.equals((java.lang.Object) paint8);
        int int10 = tickUnits0.size();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape5 = numberAxis4.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, valueAxis6, xYItemRenderer7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot8.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace11 = xYPlot8.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot8.setRangeAxisLocation(axisLocation12);
        xYPlot8.setRangeCrosshairValue(1.0d);
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot8.setNoDataMessageFont(font16);
        java.awt.Color color18 = java.awt.Color.orange;
        org.jfree.chart.text.TextBlock textBlock19 = org.jfree.chart.text.TextUtilities.createTextBlock("", font16, (java.awt.Paint) color18);
        java.awt.Shape shape24 = null;
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint26 = textTitle25.getPaint();
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("({0}, {1}) = {2}", "Preceding", "hi!", "RectangleEdge.BOTTOM", shape24, paint26);
        org.jfree.chart.text.TextMeasurer textMeasurer29 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock30 = org.jfree.chart.text.TextUtilities.createTextBlock("0", font16, paint26, (float) 0L, textMeasurer29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(valueAxis10);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(textBlock19);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(100);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears((int) (byte) 10, serialDate4);
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(100, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays((int) (short) -1, serialDate7);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Paint paint6 = stackedBarRenderer3D3.getSeriesPaint(3);
        boolean boolean7 = stackedBarRenderer3D3.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = null;
        stackedBarRenderer3D3.setLegendItemURLGenerator(categorySeriesLabelGenerator8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint12 = categoryPlot11.getRangeGridlinePaint();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean15 = numberAxis14.isNegativeArrowVisible();
        org.jfree.chart.plot.Marker marker16 = null;
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("{0}", font18);
        java.awt.geom.Rectangle2D rectangle2D20 = labelBlock19.getBounds();
        stackedBarRenderer3D3.drawRangeMarker(graphics2D10, categoryPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis14, marker16, rectangle2D20);
        org.jfree.data.time.DateRange dateRange24 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        org.jfree.data.Range range27 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange24, (double) (byte) -1, true);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape30 = numberAxis29.getLeftArrow();
        boolean boolean31 = range27.equals((java.lang.Object) numberAxis29);
        numberAxis14.setRange(range27, false, true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class1 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date5, date11);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) date5);
        java.lang.Comparable comparable14 = null;
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset13, comparable14, 100.0d, (int) '#');
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset13);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        java.awt.Stroke stroke21 = ringPlot19.getSectionOutlineStroke((java.lang.Comparable) 12);
        java.lang.Object obj22 = ringPlot19.clone();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator23 = null;
        ringPlot19.setLabelGenerator(pieSectionLabelGenerator23);
        ringPlot19.setLabelLinkMargin((double) (byte) 100);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent27 = null;
        ringPlot19.notifyListeners(plotChangeEvent27);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape33 = numberAxis32.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis32, valueAxis34, xYItemRenderer35);
        xYPlot36.setBackgroundImageAlignment((int) (byte) -1);
        float float39 = xYPlot36.getForegroundAlpha();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D43 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator44 = stackedBarRenderer3D43.getLegendItemURLGenerator();
        java.awt.Stroke stroke45 = stackedBarRenderer3D43.getBaseStroke();
        xYPlot36.setOutlineStroke(stroke45);
        org.jfree.chart.JFreeChart jFreeChart47 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) xYPlot36);
        java.awt.Color color48 = java.awt.Color.darkGray;
        java.awt.Paint paint49 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color50 = java.awt.Color.darkGray;
        java.awt.Color color51 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer52 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color48, paint49, (java.awt.Paint) color50, (java.awt.Paint) color51);
        java.lang.String str53 = color48.toString();
        xYPlot36.setRangeGridlinePaint((java.awt.Paint) color48);
        ringPlot19.setLabelPaint((java.awt.Paint) color48);
        ringPlot19.setStartAngle((-5.0d));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 1.0f + "'", float39 == 1.0f);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "java.awt.Color[r=64,g=64,b=64]" + "'", str53.equals("java.awt.Color[r=64,g=64,b=64]"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint1, (java.awt.Paint) color2, (java.awt.Paint) color3);
        java.awt.Paint paint5 = waterfallBarRenderer4.getLastBarPaint();
        boolean boolean7 = waterfallBarRenderer4.isSeriesItemLabelsVisible(10);
        boolean boolean8 = waterfallBarRenderer4.getBaseCreateEntities();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = waterfallBarRenderer4.getBaseNegativeItemLabelPosition();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        xYPlot6.setBackgroundImageAlignment((int) (byte) -1);
        float float9 = xYPlot6.getForegroundAlpha();
        int int10 = xYPlot6.getWeight();
        org.jfree.chart.plot.Plot plot11 = xYPlot6.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot6.getDomainAxisLocation(0);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color15 = color14.brighter();
        xYPlot6.setRangeCrosshairPaint((java.awt.Paint) color15);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        jFreeChart7.setTextAntiAlias(false);
        boolean boolean10 = jFreeChart7.getAntiAlias();
        boolean boolean11 = jFreeChart7.isNotify();
        boolean boolean12 = jFreeChart7.getAntiAlias();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart7.getPadding();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        java.awt.Paint paint6 = stackedBarRenderer3D3.getSeriesPaint(3);
        boolean boolean7 = stackedBarRenderer3D3.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator12 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D3.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator12, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = null;
        stackedBarRenderer3D3.setSeriesItemLabelGenerator((int) (byte) 10, categoryItemLabelGenerator16, true);
        double double19 = stackedBarRenderer3D3.getYOffset();
        double double20 = stackedBarRenderer3D3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke22 = stackedBarRenderer3D3.getSeriesStroke(2);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 10.0d + "'", double19 == 10.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertNull(stroke22);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint1, (java.awt.Paint) color2, (java.awt.Paint) color3);
        java.awt.Color color5 = java.awt.Color.cyan;
        waterfallBarRenderer4.setBaseOutlinePaint((java.awt.Paint) color5);
        java.awt.Paint paint9 = waterfallBarRenderer4.getItemPaint(15, 100);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("{0}", font14);
        java.awt.geom.Rectangle2D rectangle2D16 = labelBlock15.getBounds();
        plotRenderingInfo12.setPlotArea(rectangle2D16);
        java.awt.Color color18 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel19 = null;
        java.awt.Rectangle rectangle20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.awt.geom.AffineTransform affineTransform22 = null;
        java.awt.RenderingHints renderingHints23 = null;
        java.awt.PaintContext paintContext24 = color18.createContext(colorModel19, rectangle20, rectangle2D21, affineTransform22, renderingHints23);
        int int25 = color18.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic26 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D16, (java.awt.Paint) color18);
        boolean boolean27 = legendGraphic26.isShapeVisible();
        java.awt.Paint paint28 = legendGraphic26.getFillPaint();
        java.awt.Paint paint29 = legendGraphic26.getFillPaint();
        waterfallBarRenderer4.setSeriesOutlinePaint(64, paint29);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintContext24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double14 = rectangleInsets13.getRight();
        xYPlot6.setInsets(rectangleInsets13);
        java.lang.Object obj16 = xYPlot6.clone();
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot6.getDataset(3);
        boolean boolean19 = xYPlot6.isDomainZeroBaselineVisible();
        java.awt.Color color20 = java.awt.Color.darkGray;
        java.awt.Paint paint21 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color22 = java.awt.Color.darkGray;
        java.awt.Color color23 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer24 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color20, paint21, (java.awt.Paint) color22, (java.awt.Paint) color23);
        java.awt.Color color25 = java.awt.Color.cyan;
        waterfallBarRenderer24.setBaseOutlinePaint((java.awt.Paint) color25);
        java.awt.Color color27 = java.awt.Color.darkGray;
        java.awt.Paint paint28 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color29 = java.awt.Color.darkGray;
        java.awt.Color color30 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer31 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color27, paint28, (java.awt.Paint) color29, (java.awt.Paint) color30);
        waterfallBarRenderer24.setBaseOutlinePaint(paint28);
        waterfallBarRenderer24.setSeriesCreateEntities((int) (byte) 0, (java.lang.Boolean) true);
        java.awt.Color color37 = java.awt.Color.white;
        waterfallBarRenderer24.setSeriesPaint(9999, (java.awt.Paint) color37, false);
        xYPlot6.setDomainGridlinePaint((java.awt.Paint) color37);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color37);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = lineBorder0.getInsets();
        double double2 = rectangleInsets1.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class1 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date5, date11);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) date5);
        java.lang.Comparable comparable14 = null;
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset13, comparable14, 100.0d, (int) '#');
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset13);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        java.awt.Stroke stroke21 = ringPlot19.getSectionOutlineStroke((java.lang.Comparable) 12);
        java.lang.Object obj22 = ringPlot19.clone();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator23 = null;
        ringPlot19.setLabelGenerator(pieSectionLabelGenerator23);
        ringPlot19.setLabelLinkMargin((double) (byte) 100);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent27 = null;
        ringPlot19.notifyListeners(plotChangeEvent27);
        org.jfree.chart.block.LineBorder lineBorder29 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint30 = lineBorder29.getPaint();
        ringPlot19.setLabelOutlinePaint(paint30);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator32 = ringPlot19.getToolTipGenerator();
        double double33 = ringPlot19.getMaximumExplodePercent();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator34 = null;
        ringPlot19.setURLGenerator(pieURLGenerator34);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(pieToolTipGenerator32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Color color7 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer8 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color4, paint5, (java.awt.Paint) color6, (java.awt.Paint) color7);
        stackedBarRenderer3D3.setBasePaint(paint5, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = stackedBarRenderer3D3.getItemLabelGenerator((int) (short) 0, 3);
        stackedBarRenderer3D3.setBase(8.0d);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean18 = numberAxis17.isNegativeArrowVisible();
        numberAxis17.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape23 = numberAxis22.getLeftArrow();
        numberAxis17.setLeftArrow(shape23);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean27 = numberAxis26.isNegativeArrowVisible();
        numberAxis26.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape32 = numberAxis31.getLeftArrow();
        numberAxis26.setLeftArrow(shape32);
        numberAxis17.setDownArrow(shape32);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset37 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset37);
        java.text.DateFormat dateFormat41 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit42 = new org.jfree.chart.axis.DateTickUnit(3, (int) 'a', dateFormat41);
        java.lang.String str43 = dateTickUnit42.toString();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity45 = new org.jfree.chart.entity.CategoryItemEntity(shape32, "", "DateTickUnit[HOUR, 97]", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset37, (java.lang.Comparable) dateTickUnit42, (java.lang.Comparable) (short) 1);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset46 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class47 = null;
        org.jfree.data.time.DateRange dateRange50 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date51 = dateRange50.getUpperDate();
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date51, timeZone52);
        org.jfree.data.time.DateRange dateRange56 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date57 = dateRange56.getUpperDate();
        org.jfree.data.time.DateRange dateRange58 = new org.jfree.data.time.DateRange(date51, date57);
        org.jfree.data.general.PieDataset pieDataset59 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset46, (java.lang.Comparable) date51);
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month(date51);
        long long61 = month60.getMiddleMillisecond();
        long long62 = month60.getLastMillisecond();
        categoryItemEntity45.setRowKey((java.lang.Comparable) long62);
        org.jfree.data.category.CategoryDataset categoryDataset64 = categoryItemEntity45.getDataset();
        org.jfree.data.Range range65 = stackedBarRenderer3D3.findRangeBounds(categoryDataset64);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D67 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.awt.Paint paint68 = categoryAxis3D67.getLabelPaint();
        java.awt.Paint paint69 = categoryAxis3D67.getLabelPaint();
        stackedBarRenderer3D3.setBasePaint(paint69, false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNull(range38);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "DateTickUnit[HOUR, 97]" + "'", str43.equals("DateTickUnit[HOUR, 97]"));
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(pieDataset59);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-1310400001L) + "'", long61 == (-1310400001L));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 28799999L + "'", long62 == 28799999L);
        org.junit.Assert.assertNotNull(categoryDataset64);
        org.junit.Assert.assertNotNull(range65);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(paint69);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint1, (java.awt.Paint) color2, (java.awt.Paint) color3);
        java.awt.Paint paint5 = waterfallBarRenderer4.getLastBarPaint();
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color8 = java.awt.Color.darkGray;
        java.awt.Color color9 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer10 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color6, paint7, (java.awt.Paint) color8, (java.awt.Paint) color9);
        java.awt.Color color11 = java.awt.Color.cyan;
        waterfallBarRenderer10.setBaseOutlinePaint((java.awt.Paint) color11);
        java.awt.Color color13 = java.awt.Color.darkGray;
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color15 = java.awt.Color.darkGray;
        java.awt.Color color16 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer17 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color13, paint14, (java.awt.Paint) color15, (java.awt.Paint) color16);
        waterfallBarRenderer10.setBaseOutlinePaint(paint14);
        java.awt.Color color19 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.AffineTransform affineTransform23 = null;
        java.awt.RenderingHints renderingHints24 = null;
        java.awt.PaintContext paintContext25 = color19.createContext(colorModel20, rectangle21, rectangle2D22, affineTransform23, renderingHints24);
        int int26 = color19.getTransparency();
        java.awt.Color color27 = color19.darker();
        java.awt.Color color28 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel29 = null;
        java.awt.Rectangle rectangle30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.geom.AffineTransform affineTransform32 = null;
        java.awt.RenderingHints renderingHints33 = null;
        java.awt.PaintContext paintContext34 = color28.createContext(colorModel29, rectangle30, rectangle2D31, affineTransform32, renderingHints33);
        int int35 = color28.getTransparency();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer36 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint5, paint14, (java.awt.Paint) color19, (java.awt.Paint) color28);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator37 = null;
        waterfallBarRenderer36.setBaseItemLabelGenerator(categoryItemLabelGenerator37, true);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintContext25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paintContext34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        double double4 = stackedBarRenderer3D3.getBase();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) '#');
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Paint paint15 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color16 = java.awt.Color.darkGray;
        java.awt.Color color17 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer18 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color14, paint15, (java.awt.Paint) color16, (java.awt.Paint) color17);
        stackedBarRenderer3D13.setBasePaint(paint15, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = stackedBarRenderer3D13.getItemLabelGenerator((int) (short) 0, 3);
        stackedBarRenderer3D13.setBase(8.0d);
        java.awt.Font font28 = stackedBarRenderer3D13.getItemLabelFont(3, (int) (short) 0);
        stackedBarRenderer3D8.setSeriesItemLabelFont(12, font28);
        stackedBarRenderer3D3.setSeriesItemLabelFont((int) (byte) 0, font28);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(categoryItemLabelGenerator23);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date6 = dateRange5.getUpperDate();
        org.jfree.data.Range range7 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange2, (org.jfree.data.Range) dateRange5);
        boolean boolean9 = dateRange5.contains((double) 1L);
        boolean boolean12 = dateRange5.intersects((double) (byte) 0, 3.0d);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D1.getCategoryEnd(2958465, 100, rectangle2D5, rectangleEdge6);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        categoryAxis3D1.setCategoryLabelPositions(categoryLabelPositions8);
        java.text.DateFormat dateFormat12 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = new org.jfree.chart.axis.DateTickUnit(3, (int) 'a', dateFormat12);
        int int14 = dateTickUnit13.getCount();
        int int15 = dateTickUnit13.getCalendarField();
        categoryAxis3D1.removeCategoryLabelToolTip((java.lang.Comparable) dateTickUnit13);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot19.getDomainAxisLocation();
        java.awt.Color color22 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot19.setRangeGridlinePaint((java.awt.Paint) color22);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape28 = numberAxis27.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) numberAxis27, valueAxis29, xYItemRenderer30);
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot31);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot31.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = xYPlot31.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot31.setDomainAxisLocation(10, axisLocation37, false);
        categoryPlot19.setDomainAxisLocation(12, axisLocation37);
        java.awt.Stroke stroke41 = categoryPlot19.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace42 = null;
        categoryPlot19.setFixedRangeAxisSpace(axisSpace42);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection45 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot46 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection45);
        taskSeriesCollection45.validateObject();
        categoryPlot19.setDataset(12, (org.jfree.data.category.CategoryDataset) taskSeriesCollection45);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder49 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot19.setDatasetRenderingOrder(datasetRenderingOrder49);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D52 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.awt.Paint paint53 = categoryAxis3D52.getLabelPaint();
        java.util.List list54 = categoryPlot19.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D52);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D58 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.awt.Paint paint59 = categoryAxis3D58.getLabelPaint();
        java.awt.Color color60 = java.awt.Color.pink;
        categoryAxis3D58.setAxisLinePaint((java.awt.Paint) color60);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer65 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D69 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator70 = stackedBarRenderer3D69.getLegendItemURLGenerator();
        java.awt.Paint paint72 = stackedBarRenderer3D69.getSeriesPaint(3);
        boolean boolean73 = stackedBarRenderer3D69.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator78 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D69.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator78, true);
        java.awt.Font font83 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock84 = new org.jfree.chart.block.LabelBlock("{0}", font83);
        java.awt.geom.Rectangle2D rectangle2D85 = labelBlock84.getBounds();
        stackedBarRenderer3D69.setSeriesShape(5, (java.awt.Shape) rectangle2D85);
        boolean boolean87 = stackedAreaRenderer65.equals((java.lang.Object) rectangle2D85);
        org.jfree.chart.util.RectangleEdge rectangleEdge88 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean89 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge88);
        double double90 = categoryAxis3D58.getCategoryStart(10, 3, rectangle2D85, rectangleEdge88);
        org.jfree.chart.util.RectangleEdge rectangleEdge91 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean92 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge91);
        java.lang.String str93 = rectangleEdge91.toString();
        double double94 = categoryAxis3D52.getCategoryStart((int) (byte) 10, 9999, rectangle2D85, rectangleEdge91);
        org.jfree.chart.util.RectangleEdge rectangleEdge95 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean96 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge95);
        double double97 = categoryAxis3D1.getCategoryEnd(64, (int) '#', rectangle2D85, rectangleEdge95);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 97 + "'", int14 == 97);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 11 + "'", int15 == 11);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(valueAxis33);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(datasetRenderingOrder49);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(list54);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator70);
        org.junit.Assert.assertNull(paint72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(font83);
        org.junit.Assert.assertNotNull(rectangle2D85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(rectangleEdge88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "RectangleEdge.BOTTOM" + "'", str93.equals("RectangleEdge.BOTTOM"));
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.0d + "'", double97 == 0.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getPaint();
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        textTitle0.setPaint(paint2);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent4 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.block.BlockFrame blockFrame5 = textTitle0.getFrame();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(blockFrame5);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        xYPlot6.setBackgroundImageAlignment((int) (byte) -1);
        float float9 = xYPlot6.getForegroundAlpha();
        int int10 = xYPlot6.getWeight();
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot6.getDataset((-452));
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = xYPlot6.getOrientation();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertNotNull(plotOrientation13);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot0.getDomainAxis((int) (byte) 0);
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = stackedBarRenderer3D11.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedBarRenderer3D11.getSeriesPositiveItemLabelPosition(0);
        stackedBarRenderer3D11.setItemLabelAnchorOffset((double) '#');
        boolean boolean17 = stackedBarRenderer3D11.getAutoPopulateSeriesPaint();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D11, false);
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer20 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset21 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range22 = groupedStackedBarRenderer20.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset21);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) groupedStackedBarRenderer20, true);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(range22);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class1 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date5, date11);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) date5);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date5);
        long long15 = month14.getMiddleMillisecond();
        long long16 = month14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month14.previous();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1310400001L) + "'", long15 == (-1310400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28799999L + "'", long16 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class1 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date5, date11);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) date5);
        java.lang.Comparable comparable14 = null;
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset13, comparable14, 100.0d, (int) '#');
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset13);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        java.awt.Stroke stroke21 = ringPlot19.getSectionOutlineStroke((java.lang.Comparable) 12);
        java.awt.Stroke stroke22 = ringPlot19.getBaseSectionOutlineStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator23 = null;
        ringPlot19.setLegendLabelURLGenerator(pieURLGenerator23);
        java.awt.Paint paint26 = ringPlot19.getSectionOutlinePaint((java.lang.Comparable) (-452));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(paint26);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        java.awt.Color color0 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        int int7 = color0.getTransparency();
        java.awt.Color color8 = color0.darker();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 12);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator11 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean12 = valueMarker10.equals((java.lang.Object) standardCategoryToolTipGenerator11);
        java.awt.Paint paint13 = valueMarker10.getOutlinePaint();
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder(paint13);
        boolean boolean15 = color0.equals((java.lang.Object) blockBorder14);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str1.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("UnitType.ABSOLUTE");
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        dateAxis1.setRange((org.jfree.data.Range) dateRange4, true, false);
        dateAxis1.setInverted(true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        jFreeChart7.setTextAntiAlias(false);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint11 = textTitle10.getPaint();
        java.awt.Paint paint12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        textTitle10.setPaint(paint12);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent14 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle10);
        jFreeChart7.setTitle(textTitle10);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class1 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date5, date11);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) date5);
        java.lang.Comparable comparable14 = null;
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset13, comparable14, 100.0d, (int) '#');
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset13);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        java.awt.Paint paint20 = ringPlot19.getLabelLinkPaint();
        double double21 = ringPlot19.getSectionDepth();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.2d + "'", double21 == 0.2d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        xYPlot6.setBackgroundImageAlignment((int) (byte) -1);
        float float9 = xYPlot6.getForegroundAlpha();
        int int10 = xYPlot6.getWeight();
        xYPlot6.configureRangeAxes();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation12 = null;
        try {
            xYPlot6.addAnnotation(xYAnnotation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape7 = numberAxis6.getLeftArrow();
        java.awt.Color color8 = java.awt.Color.darkGray;
        java.awt.Paint paint9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color10 = java.awt.Color.darkGray;
        java.awt.Color color11 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer12 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color8, paint9, (java.awt.Paint) color10, (java.awt.Paint) color11);
        java.awt.Paint[] paintArray13 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Paint paint15 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color16 = java.awt.Color.darkGray;
        java.awt.Color color17 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer18 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color14, paint15, (java.awt.Paint) color16, (java.awt.Paint) color17);
        int int19 = color14.getTransparency();
        java.awt.Color color20 = java.awt.Color.cyan;
        java.awt.Paint[] paintArray21 = new java.awt.Paint[] { color14, color20 };
        java.awt.Paint[] paintArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator27 = stackedBarRenderer3D26.getLegendItemURLGenerator();
        java.awt.Stroke stroke28 = stackedBarRenderer3D26.getBaseStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator33 = stackedBarRenderer3D32.getLegendItemURLGenerator();
        java.awt.Stroke stroke34 = stackedBarRenderer3D32.getBaseStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D38 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator39 = stackedBarRenderer3D38.getLegendItemURLGenerator();
        java.awt.Stroke stroke40 = stackedBarRenderer3D38.getBaseStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D44 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator45 = stackedBarRenderer3D44.getLegendItemURLGenerator();
        java.awt.Stroke stroke46 = stackedBarRenderer3D44.getBaseStroke();
        java.awt.Stroke stroke47 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray48 = new java.awt.Stroke[] { stroke28, stroke34, stroke40, stroke46, stroke47 };
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D52 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator53 = stackedBarRenderer3D52.getLegendItemURLGenerator();
        java.awt.Stroke stroke54 = stackedBarRenderer3D52.getBaseStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D58 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator59 = stackedBarRenderer3D58.getLegendItemURLGenerator();
        java.awt.Stroke stroke60 = stackedBarRenderer3D58.getBaseStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D64 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator65 = stackedBarRenderer3D64.getLegendItemURLGenerator();
        java.awt.Stroke stroke66 = stackedBarRenderer3D64.getBaseStroke();
        java.awt.Stroke stroke67 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D71 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator72 = stackedBarRenderer3D71.getLegendItemURLGenerator();
        java.awt.Stroke stroke73 = stackedBarRenderer3D71.getBaseStroke();
        java.awt.Stroke stroke74 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray75 = new java.awt.Stroke[] { stroke54, stroke60, stroke66, stroke67, stroke73, stroke74 };
        org.jfree.chart.axis.NumberAxis numberAxis77 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape78 = numberAxis77.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis80 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean81 = numberAxis80.isNegativeArrowVisible();
        numberAxis80.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis85 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape86 = numberAxis85.getLeftArrow();
        numberAxis80.setLeftArrow(shape86);
        java.awt.Shape[] shapeArray88 = new java.awt.Shape[] { shape78, shape86 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier89 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray13, paintArray21, paintArray22, strokeArray48, strokeArray75, shapeArray88);
        java.awt.Stroke stroke90 = defaultDrawingSupplier89.getNextStroke();
        java.awt.Color color91 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.LegendItem legendItem92 = new org.jfree.chart.LegendItem("", "hi!", "TextAnchor.CENTER_RIGHT", "hi!", shape7, paint9, stroke90, (java.awt.Paint) color91);
        java.awt.Stroke stroke93 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker94 = new org.jfree.chart.plot.ValueMarker(0.05d, paint9, stroke93);
        org.jfree.chart.text.TextAnchor textAnchor95 = valueMarker94.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(strokeArray48);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator59);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator65);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator72);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(strokeArray75);
        org.junit.Assert.assertNotNull(shape78);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(shape86);
        org.junit.Assert.assertNotNull(shapeArray88);
        org.junit.Assert.assertNotNull(stroke90);
        org.junit.Assert.assertNotNull(color91);
        org.junit.Assert.assertNotNull(stroke93);
        org.junit.Assert.assertNotNull(textAnchor95);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.Object obj2 = categoryAxis3D1.clone();
        categoryAxis3D1.setTickMarksVisible(true);
        categoryAxis3D1.configure();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset6 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class7 = null;
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date11, timeZone12);
        org.jfree.data.time.DateRange dateRange16 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date17 = dateRange16.getUpperDate();
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange(date11, date17);
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset6, (java.lang.Comparable) date11);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date11);
        java.util.Date date21 = month20.getEnd();
        categoryAxis3D1.removeCategoryLabelToolTip((java.lang.Comparable) date21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date21);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(pieDataset19);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int2 = defaultKeyedValues2D0.getColumnIndex((java.lang.Comparable) 0L);
        java.util.List list3 = defaultKeyedValues2D0.getColumnKeys();
        try {
            java.lang.Number number6 = defaultKeyedValues2D0.getValue(100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = lineAndShapeRenderer0.getSeriesPositiveItemLabelPosition((int) 'a');
        org.junit.Assert.assertNotNull(itemLabelPosition2);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean6 = numberAxis5.isNegativeArrowVisible();
        numberAxis5.resizeRange((double) 100);
        numberAxis5.resizeRange((double) 100L);
        numberAxis5.setTickMarksVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean15 = numberAxis14.isNegativeArrowVisible();
        numberAxis14.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape20 = numberAxis19.getLeftArrow();
        numberAxis14.setLeftArrow(shape20);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape20, 0.0d, (double) (byte) -1);
        numberAxis5.setDownArrow(shape20);
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint27 = null;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("{0}", "{0}", "ThreadContext", "ThreadContext", shape20, stroke26, paint27);
        org.jfree.data.general.Dataset dataset29 = legendItem28.getDataset();
        java.awt.Stroke stroke30 = legendItem28.getOutlineStroke();
        org.jfree.data.general.Dataset dataset31 = legendItem28.getDataset();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(dataset29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(dataset31);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.resizeRange((double) 100);
        numberAxis1.resizeRange((double) 100L);
        org.jfree.chart.plot.Plot plot7 = numberAxis1.getPlot();
        java.awt.Color color8 = java.awt.Color.darkGray;
        java.awt.Paint paint9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color10 = java.awt.Color.darkGray;
        java.awt.Color color11 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer12 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color8, paint9, (java.awt.Paint) color10, (java.awt.Paint) color11);
        java.awt.Paint paint13 = waterfallBarRenderer12.getLastBarPaint();
        numberAxis1.setAxisLinePaint(paint13);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str17 = numberTickUnit15.valueToString(0.0d);
        numberAxis1.setTickUnit(numberTickUnit15);
        java.lang.String str20 = numberTickUnit15.valueToString(0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(numberTickUnit15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Stroke stroke2 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.configureRangeAxes();
        boolean boolean4 = categoryPlot0.isRangeCrosshairLockedOnData();
        int int5 = categoryPlot0.getDatasetCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(10, axisLocation7, false);
        categoryPlot0.setAnchorValue((double) 0.5f, true);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.LegendItem legendItem3 = lineRenderer3D0.getLegendItem(11, 11);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot5.getDomainAxisLocation();
        java.awt.Color color8 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot5.setRangeGridlinePaint((java.awt.Paint) color8);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape14 = numberAxis13.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis13, valueAxis15, xYItemRenderer16);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = xYPlot17.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot17.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot17.setDomainAxisLocation(10, axisLocation23, false);
        categoryPlot5.setDomainAxisLocation(12, axisLocation23);
        java.awt.Stroke stroke27 = categoryPlot5.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace28);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection31 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection31);
        taskSeriesCollection31.validateObject();
        categoryPlot5.setDataset(12, (org.jfree.data.category.CategoryDataset) taskSeriesCollection31);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean37 = numberAxis36.isNegativeArrowVisible();
        numberAxis36.resizeRange((double) 100);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand40 = null;
        numberAxis36.setMarkerBand(markerAxisBand40);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean44 = numberAxis43.isNegativeArrowVisible();
        numberAxis43.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape49 = numberAxis48.getLeftArrow();
        numberAxis43.setLeftArrow(shape49);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean53 = numberAxis52.isNegativeArrowVisible();
        numberAxis52.resizeRange((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape58 = numberAxis57.getLeftArrow();
        numberAxis52.setLeftArrow(shape58);
        numberAxis43.setDownArrow(shape58);
        boolean boolean61 = numberAxis43.isPositiveArrowVisible();
        java.awt.Shape shape62 = numberAxis43.getDownArrow();
        org.jfree.chart.axis.NumberAxis numberAxis64 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean65 = numberAxis64.isNegativeArrowVisible();
        numberAxis64.resizeRange((double) 100);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray68 = new org.jfree.chart.axis.ValueAxis[] { numberAxis36, numberAxis43, numberAxis64 };
        categoryPlot5.setRangeAxes(valueAxisArray68);
        java.awt.Font font71 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock72 = new org.jfree.chart.block.LabelBlock("{0}", font71);
        java.awt.geom.Rectangle2D rectangle2D73 = labelBlock72.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = null;
        double double75 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D73, rectangleEdge74);
        try {
            lineRenderer3D0.drawBackground(graphics2D4, categoryPlot5, rectangle2D73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(valueAxis19);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(shape62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(valueAxisArray68);
        org.junit.Assert.assertNotNull(font71);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        xYPlot6.setBackgroundImageAlignment((int) (byte) -1);
        float float9 = xYPlot6.getForegroundAlpha();
        int int10 = xYPlot6.getWeight();
        org.jfree.chart.plot.Plot plot11 = xYPlot6.getRootPlot();
        int int12 = xYPlot6.getRangeAxisCount();
        org.jfree.chart.LegendItemCollection legendItemCollection13 = null;
        xYPlot6.setFixedLegendItems(legendItemCollection13);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock21 = new org.jfree.chart.block.LabelBlock("{0}", font20);
        java.awt.geom.Rectangle2D rectangle2D22 = labelBlock21.getBounds();
        plotRenderingInfo18.setPlotArea(rectangle2D22);
        org.jfree.chart.renderer.RendererState rendererState24 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo18);
        java.awt.geom.Point2D point2D25 = null;
        try {
            xYPlot6.zoomDomainAxes((double) 2958465, 2.0d, plotRenderingInfo18, point2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (3106388.25) <= upper (2.1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(rectangle2D22);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        stackedBarRenderer3D3.setBaseSeriesVisibleInLegend(false);
        stackedBarRenderer3D3.setSeriesVisible((int) ' ', (java.lang.Boolean) true, false);
        boolean boolean10 = stackedBarRenderer3D3.isDrawBarOutline();
        stackedBarRenderer3D3.setRenderAsPercentages(true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class1 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date5, date11);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) date5);
        java.lang.Comparable comparable14 = null;
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset13, comparable14, 100.0d, (int) '#');
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset13);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        java.awt.Stroke stroke21 = ringPlot19.getSectionOutlineStroke((java.lang.Comparable) 12);
        java.lang.Object obj22 = ringPlot19.clone();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator23 = null;
        ringPlot19.setLabelGenerator(pieSectionLabelGenerator23);
        ringPlot19.setLabelLinkMargin((double) (byte) 100);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent27 = null;
        ringPlot19.notifyListeners(plotChangeEvent27);
        ringPlot19.setShadowYOffset(0.0d);
        double double31 = ringPlot19.getMaximumLabelWidth();
        int int32 = ringPlot19.getPieIndex();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2d + "'", double31 == 0.2d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getInfo();
        projectInfo0.addOptionalLibrary("DatasetRenderingOrder.REVERSE");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str1.equals("http://www.jfree.org/jfreechart/index.html"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape5 = numberAxis4.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, valueAxis6, xYItemRenderer7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot8.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace11 = xYPlot8.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot8.getDomainAxisEdge(3);
        taskSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot8);
        java.lang.Comparable comparable15 = null;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D20 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator21 = stackedBarRenderer3D20.getLegendItemURLGenerator();
        java.awt.Paint paint23 = stackedBarRenderer3D20.getSeriesPaint(3);
        boolean boolean24 = stackedBarRenderer3D20.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator29 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "{0}", "ThreadContext");
        stackedBarRenderer3D20.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator29, true);
        java.awt.Font font34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock35 = new org.jfree.chart.block.LabelBlock("{0}", font34);
        java.awt.geom.Rectangle2D rectangle2D36 = labelBlock35.getBounds();
        stackedBarRenderer3D20.setSeriesShape(5, (java.awt.Shape) rectangle2D36);
        boolean boolean38 = year16.equals((java.lang.Object) 5);
        try {
            int int39 = taskSeriesCollection0.getSubIntervalCount(comparable15, (java.lang.Comparable) year16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(valueAxis10);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator21);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class1 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date11 = dateRange10.getUpperDate();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(date5, date11);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) date5);
        java.lang.Comparable comparable14 = null;
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset13, comparable14, 100.0d, (int) '#');
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset13);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        java.awt.Paint paint20 = ringPlot19.getLabelLinkPaint();
        double double21 = ringPlot19.getInnerSeparatorExtension();
        java.awt.Paint paint23 = ringPlot19.getSectionPaint((java.lang.Comparable) "TextAnchor.CENTER_RIGHT");
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.2d + "'", double21 == 0.2d);
        org.junit.Assert.assertNull(paint23);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 0, (int) '4', (int) (byte) 100);
        org.jfree.chart.block.BorderArrangement borderArrangement4 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) borderArrangement4);
        int int6 = segmentedTimeline3.getSegmentsExcluded();
        boolean boolean7 = segmentedTimeline3.getAdjustForDaylightSaving();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) '#');
        int int4 = defaultKeyedValues0.getIndex((java.lang.Comparable) '#');
        java.lang.Object obj5 = defaultKeyedValues0.clone();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("{0}", font3);
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        plotRenderingInfo1.setPlotArea(rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.AffineTransform affineTransform11 = null;
        java.awt.RenderingHints renderingHints12 = null;
        java.awt.PaintContext paintContext13 = color7.createContext(colorModel8, rectangle9, rectangle2D10, affineTransform11, renderingHints12);
        int int14 = color7.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D5, (java.awt.Paint) color7);
        java.awt.Color color16 = java.awt.Color.black;
        float[] floatArray23 = new float[] { (byte) -1, 10, (short) 0, (byte) 0, 2958465, (short) 1 };
        float[] floatArray24 = color16.getComponents(floatArray23);
        legendGraphic15.setLinePaint((java.awt.Paint) color16);
        legendGraphic15.setShapeVisible(false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintContext13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.LegendItem legendItem4 = stackedAreaRenderer1.getLegendItem(3, 8);
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType5 = stackedAreaRenderer1.getEndType();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset6 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range7 = stackedAreaRenderer1.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = stackedAreaRenderer1.getBaseURLGenerator();
        org.junit.Assert.assertNull(legendItem4);
        org.junit.Assert.assertNotNull(areaRendererEndType5);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(categoryURLGenerator8);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean3 = numberAxis2.isNegativeArrowVisible();
        numberAxis2.resizeRange((double) 100);
        numberAxis2.resizeRange((double) 100L);
        org.jfree.chart.plot.Plot plot8 = numberAxis2.getPlot();
        java.awt.Color color9 = java.awt.Color.darkGray;
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color11 = java.awt.Color.darkGray;
        java.awt.Color color12 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer13 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color9, paint10, (java.awt.Paint) color11, (java.awt.Paint) color12);
        java.awt.Paint paint14 = waterfallBarRenderer13.getLastBarPaint();
        numberAxis2.setAxisLinePaint(paint14);
        numberAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean20 = numberAxis19.isNegativeArrowVisible();
        numberAxis19.resizeRange((double) 100);
        boolean boolean24 = numberAxis19.equals((java.lang.Object) 12);
        numberAxis19.resizeRange((double) (short) 100, (double) 0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis19, xYItemRenderer28);
        numberAxis19.setAutoRangeStickyZero(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color3 = java.awt.Color.darkGray;
        java.awt.Color color4 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer5 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color1, paint2, (java.awt.Paint) color3, (java.awt.Paint) color4);
        java.awt.Color color6 = java.awt.Color.cyan;
        waterfallBarRenderer5.setBaseOutlinePaint((java.awt.Paint) color6);
        java.awt.Stroke stroke8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        waterfallBarRenderer5.setBaseStroke(stroke8, false);
        boolean boolean11 = sortOrder0.equals((java.lang.Object) waterfallBarRenderer5);
        java.text.DateFormat dateFormat14 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = new org.jfree.chart.axis.DateTickUnit(3, (int) 'a', dateFormat14);
        java.lang.Class class16 = null;
        org.jfree.data.time.DateRange dateRange19 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date20 = dateRange19.getUpperDate();
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date20, timeZone21);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date26 = dateRange25.getUpperDate();
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange(date20, date26);
        java.lang.Class class28 = null;
        org.jfree.data.time.DateRange dateRange31 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date32 = dateRange31.getUpperDate();
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date32, timeZone33);
        org.jfree.data.time.DateRange dateRange37 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date38 = dateRange37.getUpperDate();
        org.jfree.data.time.DateRange dateRange39 = new org.jfree.data.time.DateRange(date32, date38);
        org.jfree.data.time.DateRange dateRange40 = new org.jfree.data.time.DateRange(date26, date32);
        java.util.Date date41 = dateTickUnit15.rollDate(date26);
        boolean boolean42 = sortOrder0.equals((java.lang.Object) date26);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double14 = rectangleInsets13.getRight();
        xYPlot6.setInsets(rectangleInsets13);
        java.awt.Color color16 = java.awt.Color.YELLOW;
        xYPlot6.setDomainTickBandPaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot6.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        xYPlot6.setRangeAxisLocation(6, axisLocation20);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer3D3.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = stackedBarRenderer3D3.getSeriesPositiveItemLabelPosition(0);
        stackedBarRenderer3D3.setItemLabelAnchorOffset((double) '#');
        boolean boolean9 = stackedBarRenderer3D3.getAutoPopulateSeriesPaint();
        java.awt.Paint paint10 = stackedBarRenderer3D3.getBaseOutlinePaint();
        java.awt.Stroke stroke13 = stackedBarRenderer3D3.getItemOutlineStroke((int) ' ', 0);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double14 = rectangleInsets13.getRight();
        xYPlot6.setInsets(rectangleInsets13);
        java.awt.Color color16 = java.awt.Color.YELLOW;
        xYPlot6.setDomainTickBandPaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot6.getDomainAxisEdge();
        java.awt.Stroke stroke19 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot6.setRangeCrosshairStroke(stroke19);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("{0}", font3);
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        plotRenderingInfo1.setPlotArea(rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.AffineTransform affineTransform11 = null;
        java.awt.RenderingHints renderingHints12 = null;
        java.awt.PaintContext paintContext13 = color7.createContext(colorModel8, rectangle9, rectangle2D10, affineTransform11, renderingHints12);
        int int14 = color7.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D5, (java.awt.Paint) color7);
        boolean boolean16 = legendGraphic15.isShapeVisible();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo18);
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock22 = new org.jfree.chart.block.LabelBlock("{0}", font21);
        java.awt.geom.Rectangle2D rectangle2D23 = labelBlock22.getBounds();
        plotRenderingInfo19.setPlotArea(rectangle2D23);
        java.awt.Color color25 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel26 = null;
        java.awt.Rectangle rectangle27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.geom.AffineTransform affineTransform29 = null;
        java.awt.RenderingHints renderingHints30 = null;
        java.awt.PaintContext paintContext31 = color25.createContext(colorModel26, rectangle27, rectangle2D28, affineTransform29, renderingHints30);
        int int32 = color25.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic33 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D23, (java.awt.Paint) color25);
        try {
            legendGraphic15.draw(graphics2D17, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintContext13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paintContext31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("{0}", font1);
        java.lang.String str3 = labelBlock2.getID();
        labelBlock2.setURLText("org.jfree.data.time.TimePeriodFormatException: ");
        java.awt.Color color6 = java.awt.Color.magenta;
        labelBlock2.setPaint((java.awt.Paint) color6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean10 = numberAxis9.isNegativeArrowVisible();
        numberAxis9.resizeRange((double) 100);
        numberAxis9.resizeRange((double) 100L);
        org.jfree.chart.plot.Plot plot15 = numberAxis9.getPlot();
        java.awt.Color color16 = java.awt.Color.darkGray;
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Color color19 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer20 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color16, paint17, (java.awt.Paint) color18, (java.awt.Paint) color19);
        java.awt.Paint paint21 = waterfallBarRenderer20.getLastBarPaint();
        numberAxis9.setAxisLinePaint(paint21);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit23 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str25 = numberTickUnit23.valueToString(0.0d);
        numberAxis9.setTickUnit(numberTickUnit23);
        org.jfree.data.DefaultKeyedValue defaultKeyedValue28 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) numberTickUnit23, (java.lang.Number) 8.0d);
        boolean boolean29 = labelBlock2.equals((java.lang.Object) defaultKeyedValue28);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape33 = numberAxis32.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis32, valueAxis34, xYItemRenderer35);
        org.jfree.chart.JFreeChart jFreeChart37 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot36);
        org.jfree.chart.axis.ValueAxis valueAxis38 = xYPlot36.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace39 = xYPlot36.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation40 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot36.setRangeAxisLocation(axisLocation40);
        xYPlot36.setRangeCrosshairValue(1.0d);
        java.awt.Font font44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot36.setNoDataMessageFont(font44);
        org.jfree.data.xy.XYDataset xYDataset46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape49 = numberAxis48.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset46, (org.jfree.chart.axis.ValueAxis) numberAxis48, valueAxis50, xYItemRenderer51);
        org.jfree.chart.JFreeChart jFreeChart53 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot52);
        org.jfree.chart.block.BlockBorder blockBorder58 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = blockBorder58.getInsets();
        double double60 = rectangleInsets59.getRight();
        xYPlot52.setInsets(rectangleInsets59);
        java.awt.Color color62 = java.awt.Color.YELLOW;
        xYPlot52.setDomainTickBandPaint((java.awt.Paint) color62);
        xYPlot36.setDomainGridlinePaint((java.awt.Paint) color62);
        org.jfree.chart.axis.AxisLocation axisLocation65 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot36.setRangeAxisLocation(axisLocation65, false);
        org.jfree.chart.plot.ValueMarker valueMarker69 = new org.jfree.chart.plot.ValueMarker((double) 12);
        org.jfree.chart.text.TextAnchor textAnchor70 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        valueMarker69.setLabelTextAnchor(textAnchor70);
        xYPlot36.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker69);
        org.jfree.chart.title.TextTitle textTitle73 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font74 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        textTitle73.setFont(font74);
        valueMarker69.setLabelFont(font74);
        labelBlock2.setFont(font74);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(numberTickUnit23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(valueAxis38);
        org.junit.Assert.assertNull(axisSpace39);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(axisLocation65);
        org.junit.Assert.assertNotNull(textAnchor70);
        org.junit.Assert.assertNotNull(font74);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("{0}", font3);
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        plotRenderingInfo1.setPlotArea(rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.AffineTransform affineTransform11 = null;
        java.awt.RenderingHints renderingHints12 = null;
        java.awt.PaintContext paintContext13 = color7.createContext(colorModel8, rectangle9, rectangle2D10, affineTransform11, renderingHints12);
        int int14 = color7.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D5, (java.awt.Paint) color7);
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        legendGraphic15.setLine(shape16);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintContext13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getPaint();
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        textTitle0.setPaint(paint2);
        java.lang.String str4 = textTitle0.getURLText();
        java.lang.Class class5 = null;
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date9 = dateRange8.getUpperDate();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date9, timeZone10);
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date15 = dateRange14.getUpperDate();
        org.jfree.data.time.DateRange dateRange16 = new org.jfree.data.time.DateRange(date9, date15);
        java.lang.Class class17 = null;
        org.jfree.data.time.DateRange dateRange20 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date21 = dateRange20.getUpperDate();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date21, timeZone22);
        org.jfree.data.time.DateRange dateRange26 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date27 = dateRange26.getUpperDate();
        org.jfree.data.time.DateRange dateRange28 = new org.jfree.data.time.DateRange(date21, date27);
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange(date15, date21);
        boolean boolean30 = textTitle0.equals((java.lang.Object) date15);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        double[] doubleArray3 = new double[] { 2 };
        double[] doubleArray5 = new double[] { 2 };
        double[] doubleArray7 = new double[] { 2 };
        double[][] doubleArray8 = new double[][] { doubleArray3, doubleArray5, doubleArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "ThreadContext", doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot6.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace9 = xYPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation(axisLocation10);
        xYPlot6.setRangeCrosshairValue(1.0d);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot6.setNoDataMessageFont(font14);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis18, valueAxis20, xYItemRenderer21);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot22);
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = blockBorder28.getInsets();
        double double30 = rectangleInsets29.getRight();
        xYPlot22.setInsets(rectangleInsets29);
        java.awt.Color color32 = java.awt.Color.YELLOW;
        xYPlot22.setDomainTickBandPaint((java.awt.Paint) color32);
        xYPlot6.setDomainGridlinePaint((java.awt.Paint) color32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation(axisLocation35, false);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) 12);
        org.jfree.chart.text.TextAnchor textAnchor40 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        valueMarker39.setLabelTextAnchor(textAnchor40);
        xYPlot6.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker39);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent43 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot6);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(valueAxis8);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(textAnchor40);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D1.getCategoryEnd(2958465, 100, rectangle2D5, rectangleEdge6);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        categoryAxis3D1.setCategoryLabelPositions(categoryLabelPositions8);
        java.text.DateFormat dateFormat12 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = new org.jfree.chart.axis.DateTickUnit(3, (int) 'a', dateFormat12);
        int int14 = dateTickUnit13.getCount();
        int int15 = dateTickUnit13.getCalendarField();
        categoryAxis3D1.removeCategoryLabelToolTip((java.lang.Comparable) dateTickUnit13);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset17 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Class class18 = null;
        org.jfree.data.time.DateRange dateRange21 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date22 = dateRange21.getUpperDate();
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date22, timeZone23);
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        java.util.Date date28 = dateRange27.getUpperDate();
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange(date22, date28);
        org.jfree.data.general.PieDataset pieDataset30 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset17, (java.lang.Comparable) date22);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date22);
        java.lang.String str32 = dateTickUnit13.dateToString(date22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 97 + "'", int14 == 97);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 11 + "'", int15 == 11);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(pieDataset30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "12/31/69" + "'", str32.equals("12/31/69"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Object obj1 = lineAndShapeRenderer0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer((int) '#');
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNull(categoryItemRenderer3);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("{0}", font3);
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        plotRenderingInfo1.setPlotArea(rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.AffineTransform affineTransform11 = null;
        java.awt.RenderingHints renderingHints12 = null;
        java.awt.PaintContext paintContext13 = color7.createContext(colorModel8, rectangle9, rectangle2D10, affineTransform11, renderingHints12);
        int int14 = color7.getTransparency();
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D5, (java.awt.Paint) color7);
        boolean boolean16 = legendGraphic15.isShapeVisible();
        java.awt.Paint paint17 = legendGraphic15.getFillPaint();
        java.awt.Color color20 = java.awt.Color.getColor("RectangleEdge.BOTTOM", 9999);
        legendGraphic15.setOutlinePaint((java.awt.Paint) color20);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintContext13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = chartRenderingInfo0.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D2 = chartRenderingInfo0.getChartArea();
        org.junit.Assert.assertNotNull(plotRenderingInfo1);
        org.junit.Assert.assertNotNull(rectangle2D2);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(6);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Friday" + "'", str1.equals("Friday"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10, (double) 10L, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = stackedBarRenderer3D5.getLegendItemURLGenerator();
        java.awt.Paint paint8 = stackedBarRenderer3D5.getSeriesPaint(3);
        boolean boolean9 = stackedBarRenderer3D5.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = null;
        stackedBarRenderer3D5.setLegendItemURLGenerator(categorySeriesLabelGenerator10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint14 = categoryPlot13.getRangeGridlinePaint();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean17 = numberAxis16.isNegativeArrowVisible();
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock21 = new org.jfree.chart.block.LabelBlock("{0}", font20);
        java.awt.geom.Rectangle2D rectangle2D22 = labelBlock21.getBounds();
        stackedBarRenderer3D5.drawRangeMarker(graphics2D12, categoryPlot13, (org.jfree.chart.axis.ValueAxis) numberAxis16, marker18, rectangle2D22);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator24 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.text.NumberFormat numberFormat25 = standardCategoryToolTipGenerator24.getNumberFormat();
        java.text.NumberFormat numberFormat26 = standardCategoryToolTipGenerator24.getNumberFormat();
        numberAxis16.setNumberFormatOverride(numberFormat26);
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator28 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("TextAnchor.CENTER_RIGHT", numberFormat26);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator29 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("Category Plot", numberFormat26);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(numberFormat25);
        org.junit.Assert.assertNotNull(numberFormat26);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double14 = rectangleInsets13.getRight();
        xYPlot6.setInsets(rectangleInsets13);
        java.awt.Color color16 = java.awt.Color.YELLOW;
        xYPlot6.setDomainTickBandPaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot6.getDomainAxisEdge();
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection20 = xYPlot6.getDomainMarkers(layer19);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertNull(collection20);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object[][] objArray1 = jFreeChartResources0.getContents();
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color3 = java.awt.Color.darkGray;
        java.awt.Color color4 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer5 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color1, paint2, (java.awt.Paint) color3, (java.awt.Paint) color4);
        int int6 = color1.getTransparency();
        java.awt.Color color7 = java.awt.Color.darkGray;
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        java.awt.Color color9 = java.awt.Color.darkGray;
        java.awt.Color color10 = java.awt.Color.GRAY;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer11 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color7, paint8, (java.awt.Paint) color9, (java.awt.Paint) color10);
        java.awt.Color color12 = java.awt.Color.cyan;
        waterfallBarRenderer11.setBaseOutlinePaint((java.awt.Paint) color12);
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        waterfallBarRenderer11.setBaseStroke(stroke14, false);
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, (double) 1L, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockBorder21.getInsets();
        double double24 = rectangleInsets22.calculateTopInset(0.0d);
        org.jfree.chart.block.LineBorder lineBorder25 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color1, stroke14, rectangleInsets22);
        boolean boolean26 = chartRenderingInfo0.equals((java.lang.Object) lineBorder25);
        chartRenderingInfo0.clear();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        xYPlot6.setBackgroundImageAlignment((int) (byte) -1);
        float float9 = xYPlot6.getForegroundAlpha();
        int int10 = xYPlot6.getWeight();
        org.jfree.chart.plot.Plot plot11 = xYPlot6.getRootPlot();
        java.awt.Stroke stroke12 = plot11.getOutlineStroke();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 0.65d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) (short) -1, (double) 5);
        org.jfree.data.Range range5 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange2, (double) (byte) -1, true);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape8 = numberAxis7.getLeftArrow();
        boolean boolean9 = range5.equals((java.lang.Object) numberAxis7);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str12 = numberTickUnit10.valueToString(0.0d);
        numberAxis7.setTickUnit(numberTickUnit10, true, true);
        org.jfree.data.RangeType rangeType16 = numberAxis7.getRangeType();
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(rangeType16);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        jFreeChart7.setTextAntiAlias(false);
        boolean boolean10 = jFreeChart7.getAntiAlias();
        java.awt.Stroke stroke11 = null;
        jFreeChart7.setBorderStroke(stroke11);
        jFreeChart7.setBorderVisible(true);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        java.awt.Paint paint3 = categoryAxis3D1.getLabelPaint();
        categoryAxis3D1.setLowerMargin(0.2d);
        boolean boolean6 = categoryAxis3D1.isAxisLineVisible();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Other");
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("RectangleEdge.BOTTOM", (org.jfree.data.time.TimePeriod) month1);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        java.lang.Object obj4 = standardCategoryURLGenerator3.clone();
        boolean boolean5 = task2.equals(obj4);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.gantt.Task task8 = new org.jfree.data.gantt.Task("RectangleEdge.BOTTOM", (org.jfree.data.time.TimePeriod) month7);
        task2.removeSubtask(task8);
        java.lang.Double double10 = task2.getPercentComplete();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(double10);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape9 = numberAxis8.getLeftArrow();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis8, valueAxis10, xYItemRenderer11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot12.getDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot12.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setDomainAxisLocation(10, axisLocation18, false);
        categoryPlot0.setDomainAxisLocation(12, axisLocation18);
        java.awt.Stroke stroke22 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace23);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection26 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection26);
        taskSeriesCollection26.validateObject();
        categoryPlot0.setDataset(12, (org.jfree.data.category.CategoryDataset) taskSeriesCollection26);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder30);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D33 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.awt.Paint paint34 = categoryAxis3D33.getLabelPaint();
        java.util.List list35 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D33);
        org.jfree.chart.JFreeChart jFreeChart36 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType37 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent38 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis3D33, jFreeChart36, chartChangeEventType37);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(chartChangeEventType37);
    }
}

