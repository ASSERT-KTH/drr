import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Week week1 = new org.jfree.data.time.Week(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.Week.LAST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 53 + "'", int0 == 53);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getStart();
        java.util.Calendar calendar2 = null;
        try {
            week0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2);
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date2, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test016");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test018");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getMiddleMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week0.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        int int2 = week0.getYearValue();
        java.util.Date date3 = week0.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date3, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.Week.FIRST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        int int2 = week0.getYearValue();
        java.util.Date date3 = week0.getStart();
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week5.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        java.lang.Class<?> wildcardClass5 = timeZone3.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year8 = week7.getYear();
        int int9 = week7.getYearValue();
        java.util.Date date10 = week7.getStart();
        java.lang.Class class11 = null;
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        java.util.Date date13 = week12.getStart();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
        java.lang.Class<?> wildcardClass16 = timeZone14.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date10, timeZone14);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = regularTimePeriod17.getMiddleMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = week0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            week0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test028");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.Year year12 = week11.getYear();
//        long long13 = week11.getLastMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560668399999L + "'", long13 == 1560668399999L);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        int int2 = week0.getYearValue();
        java.util.Date date3 = week0.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week4.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test030");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        int int2 = week0.getYearValue();
        java.util.Date date3 = week0.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
        java.util.Calendar calendar6 = null;
        try {
            week5.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        int int2 = week0.getYearValue();
        java.util.Date date3 = week0.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
        java.lang.Class class6 = null;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        java.util.Date date8 = week7.getStart();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date8, timeZone9);
        java.lang.Class<?> wildcardClass11 = timeZone9.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year14 = week13.getYear();
        int int15 = week13.getYearValue();
        java.util.Date date16 = week13.getStart();
        java.lang.Class class17 = null;
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
        java.util.Date date19 = week18.getStart();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date19, timeZone20);
        java.lang.Class<?> wildcardClass22 = timeZone20.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date16, timeZone20);
        java.util.Locale locale24 = null;
        try {
            org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date3, timeZone20, locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test034");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        java.lang.Class<?> wildcardClass11 = date3.getClass();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year13 = week12.getYear();
//        long long14 = week12.getFirstMillisecond();
//        java.util.Date date15 = week12.getEnd();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        java.util.Date date18 = week17.getStart();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date18, timeZone19);
//        java.lang.Class<?> wildcardClass21 = timeZone19.getClass();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date15, timeZone19);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        java.util.Date date25 = week24.getStart();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date25, timeZone26);
//        java.lang.Class<?> wildcardClass28 = timeZone26.getClass();
//        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year31 = week30.getYear();
//        int int32 = week30.getYearValue();
//        java.util.Date date33 = week30.getStart();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        java.util.Date date36 = week35.getStart();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date36, timeZone37);
//        java.lang.Class<?> wildcardClass39 = timeZone37.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date33, timeZone37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone37);
//        java.lang.Class class42 = null;
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
//        java.util.Date date44 = week43.getStart();
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date44, timeZone45);
//        java.util.Locale locale47 = null;
//        try {
//            org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date15, timeZone45, locale47);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560063600000L + "'", long14 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test037");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getWeek();
//        java.lang.String str3 = week0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test038");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.util.Date date3 = regularTimePeriod2.getEnd();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, 11);
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test040");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test041");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        java.lang.Class<?> wildcardClass5 = timeZone3.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        int int9 = week7.getYearValue();
//        java.util.Date date10 = week7.getStart();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        java.util.Date date13 = week12.getStart();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
//        java.lang.Class<?> wildcardClass16 = timeZone14.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date10, timeZone14);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year19 = week18.getYear();
//        long long20 = week18.getFirstMillisecond();
//        java.util.Date date21 = week18.getEnd();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        java.util.Date date24 = week23.getStart();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date24, timeZone25);
//        java.lang.Class<?> wildcardClass27 = timeZone25.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date21, timeZone25);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year30 = week29.getYear();
//        int int31 = week29.getWeek();
//        java.lang.Class class32 = null;
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        java.util.Date date34 = week33.getStart();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date34, timeZone35);
//        java.lang.Class<?> wildcardClass37 = timeZone35.getClass();
//        boolean boolean38 = week29.equals((java.lang.Object) timeZone35);
//        java.util.Locale locale39 = null;
//        try {
//            org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date21, timeZone35, locale39);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560063600000L + "'", long20 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 24 + "'", int31 == 24);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test042");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getWeek();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getMiddleMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test043");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        java.lang.Class<?> wildcardClass5 = timeZone3.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        int int9 = week7.getYearValue();
//        java.util.Date date10 = week7.getStart();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        java.util.Date date13 = week12.getStart();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
//        java.lang.Class<?> wildcardClass16 = timeZone14.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date10, timeZone14);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year19 = week18.getYear();
//        long long20 = week18.getFirstMillisecond();
//        java.util.Date date21 = week18.getEnd();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        java.util.Date date24 = week23.getStart();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date24, timeZone25);
//        java.lang.Class<?> wildcardClass27 = timeZone25.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date21, timeZone25);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year30 = week29.getYear();
//        long long31 = week29.getFirstMillisecond();
//        java.util.Date date32 = week29.getEnd();
//        java.lang.Class class33 = null;
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        java.util.Date date35 = week34.getStart();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date35, timeZone36);
//        java.lang.Class<?> wildcardClass38 = timeZone36.getClass();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date32, timeZone36);
//        java.lang.Class<?> wildcardClass40 = date32.getClass();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year42 = week41.getYear();
//        long long43 = week41.getFirstMillisecond();
//        java.util.Date date44 = week41.getEnd();
//        java.lang.Class class45 = null;
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        java.util.Date date47 = week46.getStart();
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date47, timeZone48);
//        java.lang.Class<?> wildcardClass50 = timeZone48.getClass();
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date44, timeZone48);
//        java.lang.Class class52 = null;
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week();
//        java.util.Date date54 = week53.getStart();
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date54, timeZone55);
//        java.lang.Class<?> wildcardClass57 = timeZone55.getClass();
//        java.lang.Class class58 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass57);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year60 = week59.getYear();
//        int int61 = week59.getYearValue();
//        java.util.Date date62 = week59.getStart();
//        java.lang.Class class63 = null;
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week();
//        java.util.Date date65 = week64.getStart();
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance(class63, date65, timeZone66);
//        java.lang.Class<?> wildcardClass68 = timeZone66.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class58, date62, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date44, timeZone66);
//        java.util.Locale locale71 = null;
//        try {
//            org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date21, timeZone66, locale71);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560063600000L + "'", long20 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560063600000L + "'", long31 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertNotNull(year42);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560063600000L + "'", long43 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(wildcardClass57);
//        org.junit.Assert.assertNotNull(class58);
//        org.junit.Assert.assertNotNull(year60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2019 + "'", int61 == 2019);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(wildcardClass68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertNull(regularTimePeriod70);
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test044");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        java.lang.String str2 = week0.toString();
//        int int3 = week0.getWeek();
//        int int4 = week0.getYearValue();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        java.lang.Class<?> wildcardClass5 = timeZone3.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year8 = week7.getYear();
        int int9 = week7.getYearValue();
        java.util.Date date10 = week7.getStart();
        java.lang.Class class11 = null;
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        java.util.Date date13 = week12.getStart();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
        java.lang.Class<?> wildcardClass16 = timeZone14.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date10, timeZone14);
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(class18);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.Year year12 = week11.getYear();
//        int int13 = week11.getWeek();
//        java.util.Calendar calendar14 = null;
//        try {
//            week11.peg(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        int int2 = week0.getYearValue();
        java.util.Date date3 = week0.getStart();
        java.lang.Class class4 = null;
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        java.util.Date date6 = week5.getStart();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year12 = week11.getYear();
        int int13 = week11.getYearValue();
        java.util.Date date14 = week11.getStart();
        java.lang.Class class15 = null;
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
        java.util.Date date17 = week16.getStart();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date17, timeZone18);
        java.lang.Class<?> wildcardClass20 = timeZone18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date14, timeZone18);
        java.util.Locale locale22 = null;
        try {
            org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date3, timeZone18, locale22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test049");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year13 = week12.getYear();
//        long long14 = week12.getFirstMillisecond();
//        java.util.Date date15 = week12.getEnd();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        java.util.Date date18 = week17.getStart();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date18, timeZone19);
//        java.lang.Class<?> wildcardClass21 = timeZone19.getClass();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date15, timeZone19);
//        java.lang.Class<?> wildcardClass23 = date15.getClass();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year25 = week24.getYear();
//        long long26 = week24.getFirstMillisecond();
//        java.util.Date date27 = week24.getEnd();
//        java.lang.Class class28 = null;
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        java.util.Date date30 = week29.getStart();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date30, timeZone31);
//        java.lang.Class<?> wildcardClass33 = timeZone31.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date27, timeZone31);
//        java.lang.Class class35 = null;
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        java.util.Date date37 = week36.getStart();
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date37, timeZone38);
//        java.lang.Class<?> wildcardClass40 = timeZone38.getClass();
//        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass40);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year43 = week42.getYear();
//        int int44 = week42.getYearValue();
//        java.util.Date date45 = week42.getStart();
//        java.lang.Class class46 = null;
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week();
//        java.util.Date date48 = week47.getStart();
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date48, timeZone49);
//        java.lang.Class<?> wildcardClass51 = timeZone49.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date45, timeZone49);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date27, timeZone49);
//        java.util.Locale locale54 = null;
//        try {
//            org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date3, timeZone49, locale54);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560063600000L + "'", long14 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560063600000L + "'", long26 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertNotNull(class41);
//        org.junit.Assert.assertNotNull(year43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test050");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        java.lang.Class<?> wildcardClass3 = year2.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year7 = week6.getYear();
//        long long8 = year7.getMiddleMillisecond();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(1, year7);
//        java.util.Date date10 = year7.getEnd();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year12 = week11.getYear();
//        int int13 = week11.getWeek();
//        java.lang.Class class14 = null;
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        java.util.Date date16 = week15.getStart();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date16, timeZone17);
//        java.lang.Class<?> wildcardClass19 = timeZone17.getClass();
//        boolean boolean20 = week11.equals((java.lang.Object) timeZone17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date10, timeZone17);
//        java.util.Locale locale22 = null;
//        try {
//            org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date0, timeZone17, locale22);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(11, 12);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test052");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        java.util.Calendar calendar12 = null;
//        try {
//            week10.peg(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getStart();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = week0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        long long4 = year3.getMiddleMillisecond();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(1, year3);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((-1), year3);
        java.lang.String str7 = week6.toString();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week -1, 2019" + "'", str7.equals("Week -1, 2019"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        long long3 = year2.getMiddleMillisecond();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(11, year2);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week4.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        long long4 = year3.getMiddleMillisecond();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(1, year3);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((-1), year3);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week6.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = week0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test058");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.String str3 = week0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test059");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        long long4 = year3.getMiddleMillisecond();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(1, year3);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year3);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        long long9 = week7.getFirstMillisecond();
//        java.util.Date date10 = week7.getEnd();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        java.util.Date date13 = week12.getStart();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
//        java.lang.Class<?> wildcardClass16 = timeZone14.getClass();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date10, timeZone14);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date10);
//        org.jfree.data.time.Year year19 = week18.getYear();
//        boolean boolean20 = week6.equals((java.lang.Object) week18);
//        long long21 = week18.getSerialIndex();
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 107031L + "'", long21 == 107031L);
//    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test060");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = year5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(1, year5);
//        boolean boolean8 = week0.equals((java.lang.Object) year5);
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = year5.getMiddleMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test061");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getLastMillisecond();
//        long long3 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test062");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        long long6 = week0.getLastMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            week0.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test063");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = year5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(1, year5);
//        boolean boolean8 = week0.equals((java.lang.Object) year5);
//        java.lang.String str9 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week0.next();
//        java.util.Date date11 = regularTimePeriod10.getEnd();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date11);
//    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.util.Date date4 = week0.getStart();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        int int2 = week0.getYearValue();
        java.util.Date date3 = week0.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
        java.lang.Class<?> wildcardClass6 = date3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date3);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week7.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test066");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        java.lang.String str2 = week0.toString();
//        int int3 = week0.getWeek();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        int int5 = week0.getWeek();
//        long long6 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        java.lang.Class class5 = null;
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        java.util.Date date7 = week6.getStart();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date7, timeZone8);
        java.lang.Class<?> wildcardClass10 = timeZone8.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year13 = week12.getYear();
        int int14 = week12.getYearValue();
        java.util.Date date15 = week12.getStart();
        java.lang.Class class16 = null;
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
        java.util.Date date18 = week17.getStart();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date18, timeZone19);
        java.lang.Class<?> wildcardClass21 = timeZone19.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date15, timeZone19);
        java.util.Locale locale23 = null;
        try {
            org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date2, timeZone19, locale23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test068");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        long long2 = week0.getSerialIndex();
//        java.lang.String str3 = week0.toString();
//        long long4 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(9, (int) (short) -1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test070");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        java.util.Date date5 = regularTimePeriod4.getStart();
//        java.util.Date date6 = regularTimePeriod4.getEnd();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test071");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        java.lang.Class<?> wildcardClass11 = date3.getClass();
//        java.util.Date date12 = null;
//        java.lang.Class class13 = null;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getStart();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone16);
//        java.lang.Class<?> wildcardClass18 = timeZone16.getClass();
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year21 = week20.getYear();
//        int int22 = week20.getYearValue();
//        java.util.Date date23 = week20.getStart();
//        java.lang.Class class24 = null;
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        java.util.Date date26 = week25.getStart();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date26, timeZone27);
//        java.lang.Class<?> wildcardClass29 = timeZone27.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date23, timeZone27);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year32 = week31.getYear();
//        long long33 = week31.getFirstMillisecond();
//        java.util.Date date34 = week31.getEnd();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        java.util.Date date37 = week36.getStart();
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date37, timeZone38);
//        java.lang.Class<?> wildcardClass40 = timeZone38.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date34, timeZone38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone38);
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560063600000L + "'", long33 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(class43);
//    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        int int3 = week0.getYearValue();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        long long16 = week15.getSerialIndex();
//        boolean boolean17 = week0.equals((java.lang.Object) week15);
//        org.jfree.data.time.Year year18 = week15.getYear();
//        java.util.Calendar calendar19 = null;
//        try {
//            long long20 = week15.getFirstMillisecond(calendar19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(year18);
//    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test073");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.Year year12 = week11.getYear();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = year12.getMiddleMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year12);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        int int2 = week0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        java.util.Date date4 = week0.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        java.util.TimeZone timeZone6 = null;
        java.util.Locale locale7 = null;
        try {
            org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date4, timeZone6, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date3);
//        java.util.TimeZone timeZone12 = null;
//        java.util.Locale locale13 = null;
//        try {
//            org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date3, timeZone12, locale13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test077");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date3);
//        long long12 = week11.getSerialIndex();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = week11.getLastMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        long long4 = year3.getMiddleMillisecond();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(11, year3);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (byte) 0, year3);
        int int8 = week6.compareTo((java.lang.Object) 24);
        java.util.Date date9 = week6.getStart();
        java.lang.String str10 = week6.toString();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 0, 2019" + "'", str10.equals("Week 0, 2019"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        int int2 = week0.getYearValue();
        java.util.Date date3 = week0.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        int int6 = week4.compareTo((java.lang.Object) 8);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test080");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        long long3 = week1.getFirstMillisecond();
//        java.util.Date date4 = week1.getEnd();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getStart();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date7, timeZone8);
//        java.lang.Class<?> wildcardClass10 = timeZone8.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone8);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date4);
//        org.jfree.data.time.Year year13 = week12.getYear();
//        long long14 = year13.getMiddleMillisecond();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(6, year13);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1562097599999L + "'", long14 == 1562097599999L);
//    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getWeek();
//        java.lang.String str3 = week0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            week0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test082");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        int int3 = week0.getYearValue();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        long long16 = week15.getSerialIndex();
//        boolean boolean17 = week0.equals((java.lang.Object) week15);
//        long long18 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560063600000L + "'", long18 == 1560063600000L);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        java.lang.Class<?> wildcardClass5 = timeZone3.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year8 = week7.getYear();
        int int9 = week7.getYearValue();
        java.util.Date date10 = week7.getStart();
        java.lang.Class class11 = null;
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        java.util.Date date13 = week12.getStart();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
        java.lang.Class<?> wildcardClass16 = timeZone14.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date10, timeZone14);
        java.util.Date date18 = regularTimePeriod17.getEnd();
        java.util.TimeZone timeZone19 = null;
        try {
            org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date18, timeZone19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        int int2 = week0.getYearValue();
        java.util.Date date3 = week0.getStart();
        int int4 = week0.getYearValue();
        org.jfree.data.time.Year year5 = week0.getYear();
        java.util.Calendar calendar6 = null;
        try {
            week0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(year5);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test085");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date2);
//        java.lang.String str7 = week6.toString();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week6.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        int int2 = week0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
//        java.lang.Class<?> wildcardClass6 = date3.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        long long9 = week7.getFirstMillisecond();
//        java.util.Date date10 = week7.getEnd();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        java.util.Date date13 = week12.getStart();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
//        java.lang.Class<?> wildcardClass16 = timeZone14.getClass();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date10, timeZone14);
//        java.lang.Class<?> wildcardClass18 = date10.getClass();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year20 = week19.getYear();
//        long long21 = week19.getFirstMillisecond();
//        java.util.Date date22 = week19.getEnd();
//        java.lang.Class class23 = null;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        java.util.Date date25 = week24.getStart();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date25, timeZone26);
//        java.lang.Class<?> wildcardClass28 = timeZone26.getClass();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date22, timeZone26);
//        java.lang.Class class30 = null;
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        java.util.Date date32 = week31.getStart();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date32, timeZone33);
//        java.lang.Class<?> wildcardClass35 = timeZone33.getClass();
//        java.lang.Class class36 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass35);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year38 = week37.getYear();
//        int int39 = week37.getYearValue();
//        java.util.Date date40 = week37.getStart();
//        java.lang.Class class41 = null;
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        java.util.Date date43 = week42.getStart();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date43, timeZone44);
//        java.lang.Class<?> wildcardClass46 = timeZone44.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date40, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone44);
//        java.util.Locale locale49 = null;
//        try {
//            org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date3, timeZone44, locale49);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560063600000L + "'", long21 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(class36);
//        org.junit.Assert.assertNotNull(year38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test088");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.String str3 = week0.toString();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        int int6 = week4.getYearValue();
//        java.util.Date date7 = week4.getStart();
//        int int8 = week0.compareTo((java.lang.Object) week4);
//        long long9 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        long long4 = year3.getMiddleMillisecond();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(11, year3);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (byte) 0, year3);
        int int8 = week6.compareTo((java.lang.Object) 24);
        java.util.Date date9 = week6.getStart();
        java.util.Date date10 = week6.getStart();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test090");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        long long3 = year2.getMiddleMillisecond();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(1, year2);
//        java.util.Date date5 = year2.getEnd();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.util.Date date8 = week7.getStart();
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date8, timeZone9);
//        java.lang.Class<?> wildcardClass11 = timeZone9.getClass();
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        int int15 = week13.getYearValue();
//        java.util.Date date16 = week13.getStart();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        java.util.Date date19 = week18.getStart();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date19, timeZone20);
//        java.lang.Class<?> wildcardClass22 = timeZone20.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date16, timeZone20);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year25 = week24.getYear();
//        long long26 = week24.getFirstMillisecond();
//        java.util.Date date27 = week24.getEnd();
//        java.lang.Class class28 = null;
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        java.util.Date date30 = week29.getStart();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date30, timeZone31);
//        java.lang.Class<?> wildcardClass33 = timeZone31.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date27, timeZone31);
//        java.util.Locale locale35 = null;
//        try {
//            org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date5, timeZone31, locale35);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560063600000L + "'", long26 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.lang.Object obj4 = null;
//        int int5 = week0.compareTo(obj4);
//        long long6 = week0.getMiddleMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            week0.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week5.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int12 = week10.getWeek();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 24, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test095");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        java.lang.Class<?> wildcardClass11 = date3.getClass();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year13 = week12.getYear();
//        long long14 = week12.getFirstMillisecond();
//        java.util.Date date15 = week12.getEnd();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        java.util.Date date18 = week17.getStart();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date18, timeZone19);
//        java.lang.Class<?> wildcardClass21 = timeZone19.getClass();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date15, timeZone19);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        java.util.Date date25 = week24.getStart();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date25, timeZone26);
//        java.lang.Class<?> wildcardClass28 = timeZone26.getClass();
//        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year31 = week30.getYear();
//        int int32 = week30.getYearValue();
//        java.util.Date date33 = week30.getStart();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        java.util.Date date36 = week35.getStart();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date36, timeZone37);
//        java.lang.Class<?> wildcardClass39 = timeZone37.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date33, timeZone37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone37);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date15);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560063600000L + "'", long14 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year4 = week3.getYear();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(11, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 0, year4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', year4);
//        java.lang.Class<?> wildcardClass9 = week8.getClass();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getStart();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date12, timeZone13);
//        java.lang.Class<?> wildcardClass15 = timeZone13.getClass();
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year18 = week17.getYear();
//        int int19 = week17.getYearValue();
//        java.util.Date date20 = week17.getStart();
//        java.lang.Class class21 = null;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        java.util.Date date23 = week22.getStart();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date23, timeZone24);
//        java.lang.Class<?> wildcardClass26 = timeZone24.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date20, timeZone24);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year29 = week28.getYear();
//        long long30 = week28.getFirstMillisecond();
//        java.util.Date date31 = week28.getEnd();
//        java.lang.Class class32 = null;
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        java.util.Date date34 = week33.getStart();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date34, timeZone35);
//        java.lang.Class<?> wildcardClass37 = timeZone35.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date31, timeZone35);
//        int int39 = week8.compareTo((java.lang.Object) timeZone35);
//        java.util.Calendar calendar40 = null;
//        try {
//            long long41 = week8.getLastMillisecond(calendar40);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560063600000L + "'", long30 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getStart();
        boolean boolean3 = week0.equals((java.lang.Object) 'a');
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        java.lang.Class class5 = null;
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        java.util.Date date7 = week6.getStart();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date7, timeZone8);
        java.lang.Class<?> wildcardClass10 = timeZone8.getClass();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date2, timeZone8);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date2);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = week12.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getStart();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = week0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test100");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', 0);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = year5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(1, year5);
//        boolean boolean8 = week0.equals((java.lang.Object) year5);
//        java.lang.String str9 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week0.next();
//        java.util.Date date11 = regularTimePeriod10.getEnd();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year13 = week12.getYear();
//        long long14 = week12.getFirstMillisecond();
//        java.util.Date date15 = week12.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        java.lang.Class<?> wildcardClass18 = year17.getClass();
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year22 = week21.getYear();
//        long long23 = year22.getMiddleMillisecond();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(1, year22);
//        java.util.Date date25 = year22.getEnd();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year27 = week26.getYear();
//        int int28 = week26.getWeek();
//        java.lang.Class class29 = null;
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        java.util.Date date31 = week30.getStart();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date31, timeZone32);
//        java.lang.Class<?> wildcardClass34 = timeZone32.getClass();
//        boolean boolean35 = week26.equals((java.lang.Object) timeZone32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date25, timeZone32);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date15, timeZone32);
//        java.util.Locale locale38 = null;
//        try {
//            org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date11, timeZone32, locale38);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560063600000L + "'", long14 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1562097599999L + "'", long23 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(year27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 24 + "'", int28 == 24);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test103");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getSerialIndex();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test104");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.Year year12 = week11.getYear();
//        int int13 = week11.getWeek();
//        int int14 = week11.getWeek();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
//    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        int int2 = week0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        java.util.Date date4 = week0.getStart();
        org.jfree.data.time.Year year5 = week0.getYear();
        long long6 = year5.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(11, (int) 'a');
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week -1, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test110");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        boolean boolean16 = week0.equals((java.lang.Object) week15);
//        long long17 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date2);
        java.lang.Class<?> wildcardClass7 = week6.getClass();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getSerialIndex();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.util.Date date8 = week7.getStart();
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date8, timeZone9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date8);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date8);
//        java.lang.String str13 = week12.toString();
//        long long14 = week12.getMiddleMillisecond();
//        boolean boolean15 = week0.equals((java.lang.Object) week12);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 24, 2019" + "'", str13.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560365999999L + "'", long14 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(11, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test116");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.lang.Class<?> wildcardClass2 = year1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        long long7 = year6.getMiddleMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(1, year6);
//        java.util.Date date9 = year6.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year11 = week10.getYear();
//        int int12 = week10.getWeek();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getStart();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone16);
//        java.lang.Class<?> wildcardClass18 = timeZone16.getClass();
//        boolean boolean19 = week10.equals((java.lang.Object) timeZone16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone16);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year22 = week21.getYear();
//        java.lang.Class<?> wildcardClass23 = year22.getClass();
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year27 = week26.getYear();
//        long long28 = year27.getMiddleMillisecond();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(1, year27);
//        java.util.Date date30 = year27.getEnd();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year32 = week31.getYear();
//        int int33 = week31.getWeek();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        java.util.Date date36 = week35.getStart();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date36, timeZone37);
//        java.lang.Class<?> wildcardClass39 = timeZone37.getClass();
//        boolean boolean40 = week31.equals((java.lang.Object) timeZone37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date30, timeZone37);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date9, timeZone37);
//        java.util.Calendar calendar43 = null;
//        try {
//            long long44 = week42.getFirstMillisecond(calendar43);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1562097599999L + "'", long7 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertNotNull(year27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1562097599999L + "'", long28 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 24 + "'", int33 == 24);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test117");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        long long3 = year2.getMiddleMillisecond();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(11, year2);
//        long long5 = week4.getSerialIndex();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year7 = week6.getYear();
//        java.lang.Class<?> wildcardClass8 = year7.getClass();
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year11 = week10.getYear();
//        int int12 = week10.getWeek();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year15 = week14.getYear();
//        long long16 = year15.getMiddleMillisecond();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(1, year15);
//        boolean boolean18 = week10.equals((java.lang.Object) year15);
//        java.lang.String str19 = week10.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week10.next();
//        java.util.Date date21 = regularTimePeriod20.getEnd();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        java.util.Date date24 = week23.getStart();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date24, timeZone25);
//        java.lang.Class<?> wildcardClass27 = timeZone25.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date21, timeZone25);
//        boolean boolean29 = week4.equals((java.lang.Object) class9);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107018L + "'", long5 == 107018L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1562097599999L + "'", long16 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Week 24, 2019" + "'", str19.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.lang.Object obj4 = null;
//        int int5 = week0.compareTo(obj4);
//        long long6 = week0.getSerialIndex();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        int int3 = week0.getYearValue();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        long long16 = week15.getSerialIndex();
//        boolean boolean17 = week0.equals((java.lang.Object) week15);
//        java.lang.String str18 = week0.toString();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 24, 2019" + "'", str18.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        java.lang.String str2 = week0.toString();
//        int int3 = week0.getWeek();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        java.util.Date date5 = week0.getStart();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        int int3 = week0.getYearValue();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        long long16 = week15.getSerialIndex();
//        boolean boolean17 = week0.equals((java.lang.Object) week15);
//        long long18 = week0.getLastMillisecond();
//        java.util.Calendar calendar19 = null;
//        try {
//            long long20 = week0.getMiddleMillisecond(calendar19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560668399999L + "'", long18 == 1560668399999L);
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
//        java.lang.Class<?> wildcardClass6 = date3.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date3);
//        int int8 = week7.getYearValue();
//        long long9 = week7.getSerialIndex();
//        long long10 = week7.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        java.lang.Class<?> wildcardClass5 = timeZone3.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year9 = week8.getYear();
//        int int10 = week8.getWeek();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year13 = week12.getYear();
//        long long14 = year13.getMiddleMillisecond();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(1, year13);
//        boolean boolean16 = week8.equals((java.lang.Object) year13);
//        java.lang.String str17 = week8.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week8.next();
//        java.util.Date date19 = regularTimePeriod18.getEnd();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year21 = week20.getYear();
//        long long22 = week20.getFirstMillisecond();
//        java.util.Date date23 = week20.getEnd();
//        java.lang.Class class24 = null;
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        java.util.Date date26 = week25.getStart();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date26, timeZone27);
//        java.lang.Class<?> wildcardClass29 = timeZone27.getClass();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date23, timeZone27);
//        java.lang.Class<?> wildcardClass31 = date23.getClass();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year33 = week32.getYear();
//        long long34 = week32.getFirstMillisecond();
//        java.util.Date date35 = week32.getEnd();
//        java.lang.Class class36 = null;
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        java.util.Date date38 = week37.getStart();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date38, timeZone39);
//        java.lang.Class<?> wildcardClass41 = timeZone39.getClass();
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date35, timeZone39);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
//        java.util.Date date45 = week44.getStart();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class43, date45, timeZone46);
//        java.lang.Class<?> wildcardClass48 = timeZone46.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year51 = week50.getYear();
//        int int52 = week50.getYearValue();
//        java.util.Date date53 = week50.getStart();
//        java.lang.Class class54 = null;
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week();
//        java.util.Date date56 = week55.getStart();
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date56, timeZone57);
//        java.lang.Class<?> wildcardClass59 = timeZone57.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date53, timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date35, timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date19, timeZone57);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1562097599999L + "'", long14 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 24, 2019" + "'", str17.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560063600000L + "'", long22 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(year33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560063600000L + "'", long34 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(year51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(wildcardClass59);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
//        long long7 = week5.getMiddleMillisecond();
//        java.util.Date date8 = week5.getStart();
//        java.lang.Class class9 = null;
//        java.lang.Class class10 = null;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getStart();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date12, timeZone13);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date12);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        int int18 = week16.getWeek();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year21 = week20.getYear();
//        long long22 = year21.getMiddleMillisecond();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(1, year21);
//        boolean boolean24 = week16.equals((java.lang.Object) year21);
//        java.lang.String str25 = week16.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week16.next();
//        java.util.Date date27 = regularTimePeriod26.getEnd();
//        java.lang.Class class28 = null;
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        java.util.Date date30 = week29.getStart();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date30, timeZone31);
//        java.lang.Class<?> wildcardClass33 = timeZone31.getClass();
//        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year36 = week35.getYear();
//        int int37 = week35.getYearValue();
//        java.util.Date date38 = week35.getStart();
//        java.lang.Class class39 = null;
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        java.util.Date date41 = week40.getStart();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date41, timeZone42);
//        java.lang.Class<?> wildcardClass44 = timeZone42.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date38, timeZone42);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year47 = week46.getYear();
//        long long48 = week46.getFirstMillisecond();
//        java.util.Date date49 = week46.getEnd();
//        java.lang.Class class50 = null;
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
//        java.util.Date date52 = week51.getStart();
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date52, timeZone53);
//        java.lang.Class<?> wildcardClass55 = timeZone53.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date49, timeZone53);
//        java.lang.Class class57 = null;
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week();
//        java.util.Date date59 = week58.getStart();
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date59, timeZone60);
//        java.lang.Class<?> wildcardClass62 = timeZone60.getClass();
//        java.lang.Class class63 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass62);
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year65 = week64.getYear();
//        int int66 = week64.getYearValue();
//        java.util.Date date67 = week64.getStart();
//        java.lang.Class class68 = null;
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week();
//        java.util.Date date70 = week69.getStart();
//        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance(class68, date70, timeZone71);
//        java.lang.Class<?> wildcardClass73 = timeZone71.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class63, date67, timeZone71);
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year76 = week75.getYear();
//        long long77 = week75.getFirstMillisecond();
//        java.util.Date date78 = week75.getEnd();
//        java.lang.Class class79 = null;
//        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week();
//        java.util.Date date81 = week80.getStart();
//        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance(class79, date81, timeZone82);
//        java.lang.Class<?> wildcardClass84 = timeZone82.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance(class63, date78, timeZone82);
//        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week(date49, timeZone82);
//        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date27, timeZone82);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date12, timeZone82);
//        java.util.Locale locale89 = null;
//        try {
//            org.jfree.data.time.Week week90 = new org.jfree.data.time.Week(date8, timeZone82, locale89);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1562097599999L + "'", long22 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Week 24, 2019" + "'", str25.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(year47);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560063600000L + "'", long48 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(wildcardClass62);
//        org.junit.Assert.assertNotNull(class63);
//        org.junit.Assert.assertNotNull(year65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(timeZone71);
//        org.junit.Assert.assertNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(wildcardClass73);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertNotNull(year76);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1560063600000L + "'", long77 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(timeZone82);
//        org.junit.Assert.assertNull(regularTimePeriod83);
//        org.junit.Assert.assertNotNull(wildcardClass84);
//        org.junit.Assert.assertNotNull(regularTimePeriod85);
//        org.junit.Assert.assertNull(regularTimePeriod88);
//    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        long long3 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        java.lang.Class<?> wildcardClass11 = date3.getClass();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year13 = week12.getYear();
//        long long14 = week12.getFirstMillisecond();
//        java.util.Date date15 = week12.getEnd();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        java.util.Date date18 = week17.getStart();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date18, timeZone19);
//        java.lang.Class<?> wildcardClass21 = timeZone19.getClass();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date15, timeZone19);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        java.util.Date date25 = week24.getStart();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date25, timeZone26);
//        java.lang.Class<?> wildcardClass28 = timeZone26.getClass();
//        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year31 = week30.getYear();
//        int int32 = week30.getYearValue();
//        java.util.Date date33 = week30.getStart();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        java.util.Date date36 = week35.getStart();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date36, timeZone37);
//        java.lang.Class<?> wildcardClass39 = timeZone37.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date33, timeZone37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone37);
//        java.util.TimeZone timeZone42 = null;
//        try {
//            org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date15, timeZone42);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560063600000L + "'", long14 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
//        long long7 = week5.getMiddleMillisecond();
//        java.util.Date date8 = week5.getStart();
//        java.util.Calendar calendar9 = null;
//        try {
//            week5.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date8);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
        java.lang.String str4 = timePeriodFormatException3.toString();
        java.lang.String str5 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str7 = timePeriodFormatException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getSerialIndex();
//        long long6 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        int int2 = week0.getYearValue();
        java.util.Date date3 = week0.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Calendar calendar5 = null;
        try {
            week4.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week0.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        long long3 = year2.getMiddleMillisecond();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(11, year2);
        int int5 = week4.getYearValue();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week4.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
//        long long7 = week5.getMiddleMillisecond();
//        java.util.Date date8 = week5.getStart();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week5.getFirstMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date8);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        long long4 = year3.getMiddleMillisecond();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(1, year3);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year3);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        long long9 = week7.getFirstMillisecond();
//        java.util.Date date10 = week7.getEnd();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        java.util.Date date13 = week12.getStart();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
//        java.lang.Class<?> wildcardClass16 = timeZone14.getClass();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date10, timeZone14);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date10);
//        org.jfree.data.time.Year year19 = week18.getYear();
//        boolean boolean20 = week6.equals((java.lang.Object) week18);
//        java.util.Date date21 = week18.getStart();
//        java.util.Calendar calendar22 = null;
//        try {
//            long long23 = week18.getLastMillisecond(calendar22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(date21);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (byte) 1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        long long5 = year4.getMiddleMillisecond();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(1, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((-1), year4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) 0, year4);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year4.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getLastMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        java.lang.Class class5 = null;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getStart();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date7, timeZone8);
//        java.lang.Class<?> wildcardClass10 = timeZone8.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year13 = week12.getYear();
//        int int14 = week12.getYearValue();
//        java.util.Date date15 = week12.getStart();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        java.util.Date date18 = week17.getStart();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date18, timeZone19);
//        java.lang.Class<?> wildcardClass21 = timeZone19.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date15, timeZone19);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year24 = week23.getYear();
//        long long25 = week23.getFirstMillisecond();
//        java.util.Date date26 = week23.getEnd();
//        java.lang.Class class27 = null;
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        java.util.Date date29 = week28.getStart();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date29, timeZone30);
//        java.lang.Class<?> wildcardClass32 = timeZone30.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date26, timeZone30);
//        java.util.Locale locale34 = null;
//        try {
//            org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date2, timeZone30, locale34);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560063600000L + "'", long25 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, 3);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test143");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = week0.getMiddleMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        int int2 = week0.getYearValue();
        java.util.Date date3 = week0.getStart();
        int int4 = week0.getYearValue();
        org.jfree.data.time.Year year5 = week0.getYear();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year5.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(year5);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        java.lang.Class class0 = null;
//        java.lang.Class class1 = null;
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.util.Date date3 = week2.getStart();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date3, timeZone4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        int int9 = week7.getWeek();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year12 = week11.getYear();
//        long long13 = year12.getMiddleMillisecond();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(1, year12);
//        boolean boolean15 = week7.equals((java.lang.Object) year12);
//        java.lang.String str16 = week7.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week7.next();
//        java.util.Date date18 = regularTimePeriod17.getEnd();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        java.util.Date date21 = week20.getStart();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date21, timeZone22);
//        java.lang.Class<?> wildcardClass24 = timeZone22.getClass();
//        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year27 = week26.getYear();
//        int int28 = week26.getYearValue();
//        java.util.Date date29 = week26.getStart();
//        java.lang.Class class30 = null;
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        java.util.Date date32 = week31.getStart();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date32, timeZone33);
//        java.lang.Class<?> wildcardClass35 = timeZone33.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date29, timeZone33);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year38 = week37.getYear();
//        long long39 = week37.getFirstMillisecond();
//        java.util.Date date40 = week37.getEnd();
//        java.lang.Class class41 = null;
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        java.util.Date date43 = week42.getStart();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date43, timeZone44);
//        java.lang.Class<?> wildcardClass46 = timeZone44.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date40, timeZone44);
//        java.lang.Class class48 = null;
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week();
//        java.util.Date date50 = week49.getStart();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date50, timeZone51);
//        java.lang.Class<?> wildcardClass53 = timeZone51.getClass();
//        java.lang.Class class54 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass53);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year56 = week55.getYear();
//        int int57 = week55.getYearValue();
//        java.util.Date date58 = week55.getStart();
//        java.lang.Class class59 = null;
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week();
//        java.util.Date date61 = week60.getStart();
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class59, date61, timeZone62);
//        java.lang.Class<?> wildcardClass64 = timeZone62.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date58, timeZone62);
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year67 = week66.getYear();
//        long long68 = week66.getFirstMillisecond();
//        java.util.Date date69 = week66.getEnd();
//        java.lang.Class class70 = null;
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week();
//        java.util.Date date72 = week71.getStart();
//        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class70, date72, timeZone73);
//        java.lang.Class<?> wildcardClass75 = timeZone73.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date69, timeZone73);
//        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date40, timeZone73);
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date18, timeZone73);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone73);
//        java.lang.Class<?> wildcardClass80 = date3.getClass();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 24, 2019" + "'", str16.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertNotNull(year27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560063600000L + "'", long39 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertNotNull(class54);
//        org.junit.Assert.assertNotNull(year56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertNotNull(year67);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1560063600000L + "'", long68 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(timeZone73);
//        org.junit.Assert.assertNull(regularTimePeriod74);
//        org.junit.Assert.assertNotNull(wildcardClass75);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNull(regularTimePeriod79);
//        org.junit.Assert.assertNotNull(wildcardClass80);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(53, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = year5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(1, year5);
//        boolean boolean8 = week0.equals((java.lang.Object) year5);
//        long long9 = week0.getSerialIndex();
//        java.util.Calendar calendar10 = null;
//        try {
//            week0.peg(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(11, (int) '#');
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        long long4 = week0.getLastMillisecond();
//        int int5 = week0.getWeek();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(9, (int) (short) -1);
//        long long3 = week2.getLastMillisecond();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        boolean boolean16 = week2.equals((java.lang.Object) date7);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62193715200001L) + "'", long3 == (-62193715200001L));
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
        java.lang.String str4 = timePeriodFormatException3.toString();
        java.lang.String str5 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.String str3 = week0.toString();
//        long long4 = week0.getSerialIndex();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        java.lang.Class<?> wildcardClass5 = timeZone3.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        int int9 = week7.getYearValue();
//        java.util.Date date10 = week7.getStart();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        java.util.Date date13 = week12.getStart();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
//        java.lang.Class<?> wildcardClass16 = timeZone14.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date10, timeZone14);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year19 = week18.getYear();
//        long long20 = week18.getFirstMillisecond();
//        java.util.Date date21 = week18.getEnd();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        java.util.Date date24 = week23.getStart();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date24, timeZone25);
//        java.lang.Class<?> wildcardClass27 = timeZone25.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date21, timeZone25);
//        java.lang.Class class29 = null;
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        java.util.Date date31 = week30.getStart();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date31, timeZone32);
//        java.lang.Class<?> wildcardClass34 = timeZone32.getClass();
//        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year37 = week36.getYear();
//        int int38 = week36.getYearValue();
//        java.util.Date date39 = week36.getStart();
//        java.lang.Class class40 = null;
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        java.util.Date date42 = week41.getStart();
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date42, timeZone43);
//        java.lang.Class<?> wildcardClass45 = timeZone43.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date39, timeZone43);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year48 = week47.getYear();
//        long long49 = week47.getFirstMillisecond();
//        java.util.Date date50 = week47.getEnd();
//        java.lang.Class class51 = null;
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week();
//        java.util.Date date53 = week52.getStart();
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date53, timeZone54);
//        java.lang.Class<?> wildcardClass56 = timeZone54.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date50, timeZone54);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date21, timeZone54);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date21);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560063600000L + "'", long20 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(year48);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560063600000L + "'", long49 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.lang.Class<?> wildcardClass2 = year1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        long long7 = year6.getMiddleMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(1, year6);
//        java.util.Date date9 = year6.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year11 = week10.getYear();
//        int int12 = week10.getWeek();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getStart();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone16);
//        java.lang.Class<?> wildcardClass18 = timeZone16.getClass();
//        boolean boolean19 = week10.equals((java.lang.Object) timeZone16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone16);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year22 = week21.getYear();
//        java.lang.Class<?> wildcardClass23 = year22.getClass();
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year27 = week26.getYear();
//        long long28 = year27.getMiddleMillisecond();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(1, year27);
//        java.util.Date date30 = year27.getEnd();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year32 = week31.getYear();
//        int int33 = week31.getWeek();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        java.util.Date date36 = week35.getStart();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date36, timeZone37);
//        java.lang.Class<?> wildcardClass39 = timeZone37.getClass();
//        boolean boolean40 = week31.equals((java.lang.Object) timeZone37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date30, timeZone37);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date9, timeZone37);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year44 = week43.getYear();
//        long long45 = week43.getFirstMillisecond();
//        java.util.Date date46 = week43.getEnd();
//        java.lang.Class class47 = null;
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        java.util.Date date49 = week48.getStart();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date49, timeZone50);
//        java.lang.Class<?> wildcardClass52 = timeZone50.getClass();
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date46, timeZone50);
//        java.lang.Class<?> wildcardClass54 = date46.getClass();
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year56 = week55.getYear();
//        long long57 = week55.getFirstMillisecond();
//        java.util.Date date58 = week55.getEnd();
//        java.lang.Class class59 = null;
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week();
//        java.util.Date date61 = week60.getStart();
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class59, date61, timeZone62);
//        java.lang.Class<?> wildcardClass64 = timeZone62.getClass();
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date58, timeZone62);
//        java.lang.Class class66 = null;
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week();
//        java.util.Date date68 = week67.getStart();
//        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date68, timeZone69);
//        java.lang.Class<?> wildcardClass71 = timeZone69.getClass();
//        java.lang.Class class72 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass71);
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year74 = week73.getYear();
//        int int75 = week73.getYearValue();
//        java.util.Date date76 = week73.getStart();
//        java.lang.Class class77 = null;
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week();
//        java.util.Date date79 = week78.getStart();
//        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class77, date79, timeZone80);
//        java.lang.Class<?> wildcardClass82 = timeZone80.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance(class72, date76, timeZone80);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date58, timeZone80);
//        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(date9, timeZone80);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1562097599999L + "'", long7 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertNotNull(year27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1562097599999L + "'", long28 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 24 + "'", int33 == 24);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(year44);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560063600000L + "'", long45 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertNotNull(year56);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560063600000L + "'", long57 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(timeZone69);
//        org.junit.Assert.assertNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(wildcardClass71);
//        org.junit.Assert.assertNotNull(class72);
//        org.junit.Assert.assertNotNull(year74);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 2019 + "'", int75 == 2019);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertNotNull(timeZone80);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//        org.junit.Assert.assertNotNull(wildcardClass82);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertNull(regularTimePeriod84);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getSerialIndex();
//        long long6 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, 7);
        long long3 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61946352000001L) + "'", long3 == (-61946352000001L));
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date2);
//        java.lang.String str7 = week6.toString();
//        long long8 = week6.getMiddleMillisecond();
//        org.jfree.data.time.Year year9 = week6.getYear();
//        java.lang.String str10 = week6.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week6.next();
//        java.lang.String str12 = week6.toString();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 24, 2019" + "'", str12.equals("Week 24, 2019"));
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        long long3 = year2.getMiddleMillisecond();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(11, year2);
        java.util.Date date5 = year2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week6.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        java.lang.Class<?> wildcardClass5 = timeZone3.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year9 = week8.getYear();
//        long long10 = week8.getFirstMillisecond();
//        java.util.Date date11 = week8.getEnd();
//        java.util.Date date12 = week8.getStart();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        long long15 = week13.getFirstMillisecond();
//        java.util.Date date16 = week13.getEnd();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        java.util.Date date19 = week18.getStart();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date19, timeZone20);
//        java.lang.Class<?> wildcardClass22 = timeZone20.getClass();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date16, timeZone20);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year25 = week24.getYear();
//        long long26 = week24.getFirstMillisecond();
//        java.util.Date date27 = week24.getEnd();
//        java.lang.Class class28 = null;
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        java.util.Date date30 = week29.getStart();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date30, timeZone31);
//        java.lang.Class<?> wildcardClass33 = timeZone31.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date27, timeZone31);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date27);
//        java.util.Date date36 = week35.getEnd();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year38 = week37.getYear();
//        long long39 = week37.getFirstMillisecond();
//        java.util.Date date40 = week37.getEnd();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year42 = week41.getYear();
//        java.lang.Class<?> wildcardClass43 = year42.getClass();
//        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year47 = week46.getYear();
//        long long48 = year47.getMiddleMillisecond();
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(1, year47);
//        java.util.Date date50 = year47.getEnd();
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year52 = week51.getYear();
//        int int53 = week51.getWeek();
//        java.lang.Class class54 = null;
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week();
//        java.util.Date date56 = week55.getStart();
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date56, timeZone57);
//        java.lang.Class<?> wildcardClass59 = timeZone57.getClass();
//        boolean boolean60 = week51.equals((java.lang.Object) timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date50, timeZone57);
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date40, timeZone57);
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date36, timeZone57);
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date16, timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date12, timeZone57);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560063600000L + "'", long26 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(year38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560063600000L + "'", long39 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(year42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(class44);
//        org.junit.Assert.assertNotNull(year47);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1562097599999L + "'", long48 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(year52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 24 + "'", int53 == 24);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(wildcardClass59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertNull(regularTimePeriod65);
//    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        java.util.Date date5 = regularTimePeriod4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        int int7 = week6.getYearValue();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = regularTimePeriod3.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        java.lang.String str2 = week0.toString();
//        int int3 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, (int) (short) -1);
//        int int7 = week0.compareTo((java.lang.Object) (short) -1);
//        long long8 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        java.lang.String str7 = timePeriodFormatException5.toString();
        java.lang.String str8 = timePeriodFormatException5.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str15 = timePeriodFormatException14.toString();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException19.getSuppressed();
        java.lang.String str21 = timePeriodFormatException19.toString();
        java.lang.String str22 = timePeriodFormatException19.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException24.getSuppressed();
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str29 = timePeriodFormatException28.toString();
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException28.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray35 = timePeriodFormatException34.getSuppressed();
        java.lang.String str36 = timePeriodFormatException34.toString();
        java.lang.String str37 = timePeriodFormatException34.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray40 = timePeriodFormatException39.getSuppressed();
        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        java.lang.Throwable[] throwableArray42 = timePeriodFormatException34.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException44 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray45 = timePeriodFormatException44.getSuppressed();
        java.lang.String str46 = timePeriodFormatException44.toString();
        java.lang.String str47 = timePeriodFormatException44.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException49 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray50 = timePeriodFormatException49.getSuppressed();
        timePeriodFormatException44.addSuppressed((java.lang.Throwable) timePeriodFormatException49);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException53 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str54 = timePeriodFormatException53.toString();
        timePeriodFormatException44.addSuppressed((java.lang.Throwable) timePeriodFormatException53);
        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException44);
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        java.lang.String str58 = timePeriodFormatException28.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str29.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str36.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str37.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNotNull(throwableArray42);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str46.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str47.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str54.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str58.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        java.lang.Class<?> wildcardClass6 = week0.getClass();
//        long long7 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        long long6 = week0.getLastMillisecond();
//        java.util.Date date7 = week0.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year9 = week8.getYear();
//        long long10 = week8.getFirstMillisecond();
//        java.util.Date date11 = week8.getEnd();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        java.util.Date date14 = week13.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date14, timeZone15);
//        java.lang.Class<?> wildcardClass17 = timeZone15.getClass();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date11, timeZone15);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Year year20 = week19.getYear();
//        int int21 = week19.getYearValue();
//        boolean boolean22 = week0.equals((java.lang.Object) week19);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date2);
//        java.lang.String str7 = week6.toString();
//        long long8 = week6.getMiddleMillisecond();
//        org.jfree.data.time.Year year9 = week6.getYear();
//        java.lang.String str10 = week6.toString();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = week6.getMiddleMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        java.lang.String str2 = week0.toString();
//        int int3 = week0.getWeek();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        java.util.Date date5 = week0.getStart();
//        java.util.TimeZone timeZone6 = null;
//        java.util.Locale locale7 = null;
//        try {
//            org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5, timeZone6, locale7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        java.lang.Class<?> wildcardClass5 = timeZone3.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year10 = week9.getYear();
//        long long11 = year10.getMiddleMillisecond();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(11, year10);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (byte) 0, year10);
//        int int15 = week13.compareTo((java.lang.Object) 24);
//        java.util.Date date16 = week13.getStart();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year18 = week17.getYear();
//        long long19 = week17.getFirstMillisecond();
//        java.util.Date date20 = week17.getEnd();
//        java.lang.Class class21 = null;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        java.util.Date date23 = week22.getStart();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date23, timeZone24);
//        java.lang.Class<?> wildcardClass26 = timeZone24.getClass();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date20, timeZone24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date16, timeZone24);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560063600000L + "'", long19 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.lang.Object obj4 = null;
//        int int5 = week0.compareTo(obj4);
//        long long6 = week0.getMiddleMillisecond();
//        long long7 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.lang.Class<?> wildcardClass2 = year1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize(class3);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(class4);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getWeek();
//        java.lang.Class class3 = null;
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getStart();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date5, timeZone6);
//        java.lang.Class<?> wildcardClass8 = timeZone6.getClass();
//        boolean boolean9 = week0.equals((java.lang.Object) timeZone6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week0.previous();
//        java.util.Date date11 = regularTimePeriod10.getStart();
//        java.util.Date date12 = regularTimePeriod10.getStart();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date12);
//    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
//        long long7 = week5.getMiddleMillisecond();
//        java.util.Date date8 = week5.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date8);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        java.lang.String str5 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str7 = timePeriodFormatException3.toString();
        java.lang.Class<?> wildcardClass8 = timePeriodFormatException3.getClass();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        java.util.Date date5 = regularTimePeriod4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        java.util.Calendar calendar7 = null;
//        try {
//            week6.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        java.lang.String str2 = week0.toString();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getMiddleMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test176");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        boolean boolean16 = week0.equals((java.lang.Object) week15);
//        java.lang.String str17 = week15.toString();
//        long long18 = week15.getMiddleMillisecond();
//        java.util.Calendar calendar19 = null;
//        try {
//            week15.peg(calendar19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 24, 2019" + "'", str17.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560365999999L + "'", long18 == 1560365999999L);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
        java.lang.String str4 = timePeriodFormatException3.toString();
        java.lang.String str5 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        java.lang.String str9 = timePeriodFormatException7.toString();
        java.lang.String str10 = timePeriodFormatException7.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException12.getSuppressed();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str17 = timePeriodFormatException16.toString();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray22 = timePeriodFormatException21.getSuppressed();
        java.lang.String str23 = timePeriodFormatException21.toString();
        java.lang.String str24 = timePeriodFormatException21.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray27 = timePeriodFormatException26.getSuppressed();
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str31 = timePeriodFormatException30.toString();
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        java.lang.Throwable[] throwableArray33 = timePeriodFormatException30.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray37 = timePeriodFormatException36.getSuppressed();
        java.lang.String str38 = timePeriodFormatException36.toString();
        java.lang.String str39 = timePeriodFormatException36.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray42 = timePeriodFormatException41.getSuppressed();
        timePeriodFormatException36.addSuppressed((java.lang.Throwable) timePeriodFormatException41);
        java.lang.Throwable[] throwableArray44 = timePeriodFormatException36.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException46 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray47 = timePeriodFormatException46.getSuppressed();
        java.lang.String str48 = timePeriodFormatException46.toString();
        java.lang.String str49 = timePeriodFormatException46.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException51 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray52 = timePeriodFormatException51.getSuppressed();
        timePeriodFormatException46.addSuppressed((java.lang.Throwable) timePeriodFormatException51);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException55 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str56 = timePeriodFormatException55.toString();
        timePeriodFormatException46.addSuppressed((java.lang.Throwable) timePeriodFormatException55);
        timePeriodFormatException36.addSuppressed((java.lang.Throwable) timePeriodFormatException46);
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        java.lang.Throwable[] throwableArray61 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str31.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str38.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str39.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray42);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str48.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str49.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray52);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str56.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray61);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getLastMillisecond();
//        java.util.Date date3 = week0.getStart();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: Week -1, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        java.lang.String str2 = week0.toString();
//        int int3 = week0.getWeek();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Year year6 = week0.getYear();
//        long long7 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week0.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.String str5 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        java.lang.String str7 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getWeek();
//        java.lang.Class class3 = null;
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getStart();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date5, timeZone6);
//        java.lang.Class<?> wildcardClass8 = timeZone6.getClass();
//        boolean boolean9 = week0.equals((java.lang.Object) timeZone6);
//        java.util.Calendar calendar10 = null;
//        try {
//            week0.peg(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.String str3 = week0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.String str4 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        java.lang.String str13 = timePeriodFormatException11.toString();
        java.lang.String str14 = timePeriodFormatException11.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException16.getSuppressed();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str21 = timePeriodFormatException20.toString();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray26 = timePeriodFormatException25.getSuppressed();
        java.lang.String str27 = timePeriodFormatException25.toString();
        java.lang.String str28 = timePeriodFormatException25.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException30.getSuppressed();
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray36 = timePeriodFormatException35.getSuppressed();
        java.lang.String str37 = timePeriodFormatException35.toString();
        java.lang.String str38 = timePeriodFormatException35.toString();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str28.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str37.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str38.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getWeek();
//        java.lang.Class class3 = null;
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getStart();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date5, timeZone6);
//        java.lang.Class<?> wildcardClass8 = timeZone6.getClass();
//        boolean boolean9 = week0.equals((java.lang.Object) timeZone6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week0.previous();
//        java.lang.Class<?> wildcardClass11 = regularTimePeriod10.getClass();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year13 = week12.getYear();
//        long long14 = week12.getFirstMillisecond();
//        java.util.Date date15 = week12.getEnd();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        java.util.Date date18 = week17.getStart();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date18, timeZone19);
//        java.lang.Class<?> wildcardClass21 = timeZone19.getClass();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date15, timeZone19);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        java.util.Date date25 = week24.getStart();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date25, timeZone26);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        java.util.Date date30 = week29.getStart();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date30, timeZone31);
//        java.lang.Class<?> wildcardClass33 = timeZone31.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date25, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone31);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560063600000L + "'", long14 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (short) 10);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 11);
        java.util.Date date3 = week2.getStart();
        java.util.Date date4 = week2.getEnd();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.util.Date date3 = week0.getEnd();
//        java.util.Calendar calendar4 = null;
//        try {
//            week0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 0, year4);
//        java.util.Date date6 = week5.getEnd();
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date6);
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        java.lang.Class class0 = null;
//        java.lang.Class class1 = null;
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.util.Date date3 = week2.getStart();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date3, timeZone4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        int int9 = week7.getWeek();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year12 = week11.getYear();
//        long long13 = year12.getMiddleMillisecond();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(1, year12);
//        boolean boolean15 = week7.equals((java.lang.Object) year12);
//        java.lang.String str16 = week7.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week7.next();
//        java.util.Date date18 = regularTimePeriod17.getEnd();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        java.util.Date date21 = week20.getStart();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date21, timeZone22);
//        java.lang.Class<?> wildcardClass24 = timeZone22.getClass();
//        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year27 = week26.getYear();
//        int int28 = week26.getYearValue();
//        java.util.Date date29 = week26.getStart();
//        java.lang.Class class30 = null;
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        java.util.Date date32 = week31.getStart();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date32, timeZone33);
//        java.lang.Class<?> wildcardClass35 = timeZone33.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date29, timeZone33);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year38 = week37.getYear();
//        long long39 = week37.getFirstMillisecond();
//        java.util.Date date40 = week37.getEnd();
//        java.lang.Class class41 = null;
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        java.util.Date date43 = week42.getStart();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date43, timeZone44);
//        java.lang.Class<?> wildcardClass46 = timeZone44.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date40, timeZone44);
//        java.lang.Class class48 = null;
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week();
//        java.util.Date date50 = week49.getStart();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date50, timeZone51);
//        java.lang.Class<?> wildcardClass53 = timeZone51.getClass();
//        java.lang.Class class54 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass53);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year56 = week55.getYear();
//        int int57 = week55.getYearValue();
//        java.util.Date date58 = week55.getStart();
//        java.lang.Class class59 = null;
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week();
//        java.util.Date date61 = week60.getStart();
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class59, date61, timeZone62);
//        java.lang.Class<?> wildcardClass64 = timeZone62.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date58, timeZone62);
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year67 = week66.getYear();
//        long long68 = week66.getFirstMillisecond();
//        java.util.Date date69 = week66.getEnd();
//        java.lang.Class class70 = null;
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week();
//        java.util.Date date72 = week71.getStart();
//        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class70, date72, timeZone73);
//        java.lang.Class<?> wildcardClass75 = timeZone73.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date69, timeZone73);
//        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date40, timeZone73);
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date18, timeZone73);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone73);
//        try {
//            java.lang.Class<?> wildcardClass80 = regularTimePeriod79.getClass();
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 24, 2019" + "'", str16.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertNotNull(year27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560063600000L + "'", long39 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertNotNull(class54);
//        org.junit.Assert.assertNotNull(year56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertNotNull(year67);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1560063600000L + "'", long68 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(timeZone73);
//        org.junit.Assert.assertNull(regularTimePeriod74);
//        org.junit.Assert.assertNotNull(wildcardClass75);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNull(regularTimePeriod79);
//    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.lang.Class<?> wildcardClass2 = year1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        long long7 = year6.getMiddleMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(1, year6);
//        java.util.Date date9 = year6.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year11 = week10.getYear();
//        int int12 = week10.getWeek();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getStart();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone16);
//        java.lang.Class<?> wildcardClass18 = timeZone16.getClass();
//        boolean boolean19 = week10.equals((java.lang.Object) timeZone16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone16);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date9);
//        long long22 = week21.getFirstMillisecond();
//        java.lang.String str23 = week21.toString();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1562097599999L + "'", long7 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577606400000L + "'", long22 == 1577606400000L);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Week 1, 2020" + "'", str23.equals("Week 1, 2020"));
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        java.lang.Class<?> wildcardClass5 = timeZone3.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize(class8);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(class9);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) 'a');
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 10, 3);
        int int3 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.util.Date date4 = week0.getStart();
//        java.util.Date date5 = week0.getEnd();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        java.lang.Class<?> wildcardClass5 = timeZone3.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        int int9 = week7.getYearValue();
//        java.util.Date date10 = week7.getStart();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        java.util.Date date13 = week12.getStart();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
//        java.lang.Class<?> wildcardClass16 = timeZone14.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date10, timeZone14);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year19 = week18.getYear();
//        long long20 = week18.getFirstMillisecond();
//        java.util.Date date21 = week18.getEnd();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        java.util.Date date24 = week23.getStart();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date24, timeZone25);
//        java.lang.Class<?> wildcardClass27 = timeZone25.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date21, timeZone25);
//        java.lang.Class class29 = null;
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        java.util.Date date31 = week30.getStart();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date31, timeZone32);
//        java.lang.Class<?> wildcardClass34 = timeZone32.getClass();
//        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year37 = week36.getYear();
//        int int38 = week36.getYearValue();
//        java.util.Date date39 = week36.getStart();
//        java.lang.Class class40 = null;
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        java.util.Date date42 = week41.getStart();
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date42, timeZone43);
//        java.lang.Class<?> wildcardClass45 = timeZone43.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date39, timeZone43);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year48 = week47.getYear();
//        long long49 = week47.getFirstMillisecond();
//        java.util.Date date50 = week47.getEnd();
//        java.lang.Class class51 = null;
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week();
//        java.util.Date date53 = week52.getStart();
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date53, timeZone54);
//        java.lang.Class<?> wildcardClass56 = timeZone54.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date50, timeZone54);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date21, timeZone54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = week58.next();
//        int int60 = week58.getYearValue();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560063600000L + "'", long20 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(year48);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560063600000L + "'", long49 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
//    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        long long4 = year3.getMiddleMillisecond();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(11, year3);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (byte) 0, year3);
//        int int8 = week6.compareTo((java.lang.Object) 24);
//        java.util.Date date9 = week6.getStart();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getStart();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date12, timeZone13);
//        java.lang.Class<?> wildcardClass15 = timeZone13.getClass();
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year18 = week17.getYear();
//        int int19 = week17.getYearValue();
//        java.util.Date date20 = week17.getStart();
//        java.lang.Class class21 = null;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        java.util.Date date23 = week22.getStart();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date23, timeZone24);
//        java.lang.Class<?> wildcardClass26 = timeZone24.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date20, timeZone24);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year29 = week28.getYear();
//        long long30 = week28.getFirstMillisecond();
//        java.util.Date date31 = week28.getEnd();
//        java.lang.Class class32 = null;
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        java.util.Date date34 = week33.getStart();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date34, timeZone35);
//        java.lang.Class<?> wildcardClass37 = timeZone35.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date31, timeZone35);
//        java.lang.Class class39 = null;
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        java.util.Date date41 = week40.getStart();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date41, timeZone42);
//        java.lang.Class<?> wildcardClass44 = timeZone42.getClass();
//        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass44);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year47 = week46.getYear();
//        int int48 = week46.getYearValue();
//        java.util.Date date49 = week46.getStart();
//        java.lang.Class class50 = null;
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
//        java.util.Date date52 = week51.getStart();
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date52, timeZone53);
//        java.lang.Class<?> wildcardClass55 = timeZone53.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date49, timeZone53);
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year58 = week57.getYear();
//        long long59 = week57.getFirstMillisecond();
//        java.util.Date date60 = week57.getEnd();
//        java.lang.Class class61 = null;
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week();
//        java.util.Date date63 = week62.getStart();
//        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class61, date63, timeZone64);
//        java.lang.Class<?> wildcardClass66 = timeZone64.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date60, timeZone64);
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date31, timeZone64);
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date9, timeZone64);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560063600000L + "'", long30 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertNotNull(class45);
//        org.junit.Assert.assertNotNull(year47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(year58);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560063600000L + "'", long59 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(timeZone64);
//        org.junit.Assert.assertNull(regularTimePeriod65);
//        org.junit.Assert.assertNotNull(wildcardClass66);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        long long2 = week0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        long long4 = week0.getFirstMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            week0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        long long4 = year3.getMiddleMillisecond();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(11, year3);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (byte) 0, year3);
        int int8 = week6.compareTo((java.lang.Object) 24);
        java.util.Date date9 = week6.getStart();
        org.jfree.data.time.Year year10 = week6.getYear();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = week6.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(year10);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 11);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        long long3 = year2.getMiddleMillisecond();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(11, year2);
        int int5 = week4.getYearValue();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year7 = week6.getYear();
        java.lang.Class<?> wildcardClass8 = year7.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        boolean boolean11 = week4.equals((java.lang.Object) wildcardClass8);
        java.lang.Object obj12 = null;
        boolean boolean13 = week4.equals(obj12);
        long long14 = week4.getLastMillisecond();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1552805999999L + "'", long14 == 1552805999999L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
//        java.lang.Class<?> wildcardClass6 = date3.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        int int9 = week7.getYearValue();
//        java.util.Date date10 = week7.getStart();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year13 = week12.getYear();
//        int int14 = week12.getWeek();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        java.util.Date date17 = week16.getStart();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date17, timeZone18);
//        java.lang.Class<?> wildcardClass20 = timeZone18.getClass();
//        boolean boolean21 = week12.equals((java.lang.Object) timeZone18);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date10, timeZone18);
//        java.util.Locale locale23 = null;
//        try {
//            org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date3, timeZone18, locale23);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test205");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.lang.Class<?> wildcardClass2 = year1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        long long7 = year6.getMiddleMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(1, year6);
//        java.util.Date date9 = year6.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year11 = week10.getYear();
//        int int12 = week10.getWeek();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getStart();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone16);
//        java.lang.Class<?> wildcardClass18 = timeZone16.getClass();
//        boolean boolean19 = week10.equals((java.lang.Object) timeZone16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone16);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year22 = week21.getYear();
//        java.lang.Class<?> wildcardClass23 = year22.getClass();
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year27 = week26.getYear();
//        long long28 = year27.getMiddleMillisecond();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(1, year27);
//        java.util.Date date30 = year27.getEnd();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year32 = week31.getYear();
//        int int33 = week31.getWeek();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        java.util.Date date36 = week35.getStart();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date36, timeZone37);
//        java.lang.Class<?> wildcardClass39 = timeZone37.getClass();
//        boolean boolean40 = week31.equals((java.lang.Object) timeZone37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date30, timeZone37);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date9, timeZone37);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date9);
//        java.util.TimeZone timeZone44 = null;
//        try {
//            org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date9, timeZone44);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1562097599999L + "'", long7 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertNotNull(year27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1562097599999L + "'", long28 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 24 + "'", int33 == 24);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        boolean boolean16 = week0.equals((java.lang.Object) week15);
//        long long17 = week15.getLastMillisecond();
//        int int18 = week15.getWeek();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560668399999L + "'", long17 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year5 = week4.getYear();
        long long6 = year5.getMiddleMillisecond();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(1, year5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(2, year5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 1, year5);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(0, year5);
        java.lang.Class<?> wildcardClass11 = week10.getClass();
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 10, 3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(9, (int) (short) -1);
        long long3 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62194320000000L) + "'", long3 == (-62194320000000L));
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.String str3 = week0.toString();
//        java.lang.String str4 = week0.toString();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date2);
//        java.lang.String str7 = week6.toString();
//        long long8 = week6.getMiddleMillisecond();
//        java.util.Calendar calendar9 = null;
//        try {
//            week6.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        java.lang.Class<?> wildcardClass5 = timeZone3.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        int int9 = week7.getYearValue();
//        java.util.Date date10 = week7.getStart();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        java.util.Date date13 = week12.getStart();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
//        java.lang.Class<?> wildcardClass16 = timeZone14.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date10, timeZone14);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year19 = week18.getYear();
//        long long20 = week18.getFirstMillisecond();
//        java.util.Date date21 = week18.getEnd();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        java.util.Date date24 = week23.getStart();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date24, timeZone25);
//        java.lang.Class<?> wildcardClass27 = timeZone25.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date21, timeZone25);
//        long long29 = regularTimePeriod28.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560063600000L + "'", long20 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560668399999L + "'", long29 == 1560668399999L);
//    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year4 = week3.getYear();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(11, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 0, year4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', year4);
//        java.lang.Class<?> wildcardClass9 = week8.getClass();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getStart();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date12, timeZone13);
//        java.lang.Class<?> wildcardClass15 = timeZone13.getClass();
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year18 = week17.getYear();
//        int int19 = week17.getYearValue();
//        java.util.Date date20 = week17.getStart();
//        java.lang.Class class21 = null;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        java.util.Date date23 = week22.getStart();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date23, timeZone24);
//        java.lang.Class<?> wildcardClass26 = timeZone24.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date20, timeZone24);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year29 = week28.getYear();
//        long long30 = week28.getFirstMillisecond();
//        java.util.Date date31 = week28.getEnd();
//        java.lang.Class class32 = null;
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        java.util.Date date34 = week33.getStart();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date34, timeZone35);
//        java.lang.Class<?> wildcardClass37 = timeZone35.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date31, timeZone35);
//        int int39 = week8.compareTo((java.lang.Object) timeZone35);
//        java.util.Calendar calendar40 = null;
//        try {
//            long long41 = week8.getMiddleMillisecond(calendar40);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560063600000L + "'", long30 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.Year year12 = week11.getYear();
//        int int13 = week11.getYearValue();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = week11.getMiddleMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        java.lang.Class<?> wildcardClass11 = date3.getClass();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year13 = week12.getYear();
//        long long14 = week12.getFirstMillisecond();
//        java.util.Date date15 = week12.getEnd();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        java.util.Date date18 = week17.getStart();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date18, timeZone19);
//        java.lang.Class<?> wildcardClass21 = timeZone19.getClass();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date15, timeZone19);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        java.util.Date date25 = week24.getStart();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date25, timeZone26);
//        java.lang.Class<?> wildcardClass28 = timeZone26.getClass();
//        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year31 = week30.getYear();
//        int int32 = week30.getYearValue();
//        java.util.Date date33 = week30.getStart();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        java.util.Date date36 = week35.getStart();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date36, timeZone37);
//        java.lang.Class<?> wildcardClass39 = timeZone37.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date33, timeZone37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone37);
//        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize(class42);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560063600000L + "'", long14 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(class42);
//        org.junit.Assert.assertNotNull(class43);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        long long3 = year2.getMiddleMillisecond();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(11, year2);
        java.util.Date date5 = year2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.next();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        long long4 = year3.getMiddleMillisecond();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(11, year3);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (byte) 0, year3);
        int int8 = week6.compareTo((java.lang.Object) 24);
        java.util.Date date9 = week6.getStart();
        org.jfree.data.time.Year year10 = week6.getYear();
        java.lang.Class<?> wildcardClass11 = week6.getClass();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        java.lang.String str6 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 10, 3);
        int int3 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = year5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(1, year5);
//        boolean boolean8 = week0.equals((java.lang.Object) year5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week0.previous();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.util.Calendar calendar4 = null;
//        try {
//            week0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        int int4 = week0.getWeek();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        long long7 = week5.getFirstMillisecond();
//        java.util.Date date8 = week5.getEnd();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year10 = week9.getYear();
//        java.lang.Class<?> wildcardClass11 = year10.getClass();
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year15 = week14.getYear();
//        long long16 = year15.getMiddleMillisecond();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(1, year15);
//        java.util.Date date18 = year15.getEnd();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year20 = week19.getYear();
//        int int21 = week19.getWeek();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        java.util.Date date24 = week23.getStart();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date24, timeZone25);
//        java.lang.Class<?> wildcardClass27 = timeZone25.getClass();
//        boolean boolean28 = week19.equals((java.lang.Object) timeZone25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date18, timeZone25);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date8, timeZone25);
//        java.util.Locale locale31 = null;
//        try {
//            org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date4, timeZone25, locale31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1562097599999L + "'", long16 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 24 + "'", int21 == 24);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        long long4 = year3.getMiddleMillisecond();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(11, year3);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (byte) 0, year3);
        java.lang.Class<?> wildcardClass7 = year3.getClass();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(2019, year2);
        org.junit.Assert.assertNotNull(year2);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        boolean boolean16 = week0.equals((java.lang.Object) week15);
//        java.lang.String str17 = week15.toString();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year19 = week18.getYear();
//        int int20 = week18.getWeek();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year23 = week22.getYear();
//        long long24 = year23.getMiddleMillisecond();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(1, year23);
//        boolean boolean26 = week18.equals((java.lang.Object) year23);
//        int int27 = week15.compareTo((java.lang.Object) boolean26);
//        long long28 = week15.getLastMillisecond();
//        long long29 = week15.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 24, 2019" + "'", str17.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1562097599999L + "'", long24 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560668399999L + "'", long28 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 107031L + "'", long29 == 107031L);
//    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date3);
//        long long12 = week11.getSerialIndex();
//        org.jfree.data.time.Year year13 = week11.getYear();
//        long long14 = week11.getFirstMillisecond();
//        org.jfree.data.time.Year year15 = week11.getYear();
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = week11.getLastMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560063600000L + "'", long14 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year15);
//    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 100, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(0, year5);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year5);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        long long5 = year4.getMiddleMillisecond();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(1, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((-1), year4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, year4);
        long long9 = week8.getSerialIndex();
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107007L + "'", long9 == 107007L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(11, 24);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        int int7 = week5.getWeek();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        boolean boolean14 = week5.equals((java.lang.Object) timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date3, timeZone11);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        java.lang.Class<?> wildcardClass18 = year17.getClass();
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year22 = week21.getYear();
//        long long23 = year22.getMiddleMillisecond();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(1, year22);
//        java.util.Date date25 = year22.getEnd();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year27 = week26.getYear();
//        int int28 = week26.getWeek();
//        java.lang.Class class29 = null;
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        java.util.Date date31 = week30.getStart();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date31, timeZone32);
//        java.lang.Class<?> wildcardClass34 = timeZone32.getClass();
//        boolean boolean35 = week26.equals((java.lang.Object) timeZone32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date25, timeZone32);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        java.util.Date date38 = week37.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week37.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week37.next();
//        java.util.Date date41 = regularTimePeriod40.getStart();
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year43 = week42.getYear();
//        long long44 = week42.getFirstMillisecond();
//        java.util.Date date45 = week42.getEnd();
//        java.lang.Class class46 = null;
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week();
//        java.util.Date date48 = week47.getStart();
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date48, timeZone49);
//        java.lang.Class<?> wildcardClass51 = timeZone49.getClass();
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date45, timeZone49);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year54 = week53.getYear();
//        long long55 = week53.getFirstMillisecond();
//        java.util.Date date56 = week53.getEnd();
//        java.lang.Class class57 = null;
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week();
//        java.util.Date date59 = week58.getStart();
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date59, timeZone60);
//        java.lang.Class<?> wildcardClass62 = timeZone60.getClass();
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date56, timeZone60);
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date56);
//        java.util.Date date65 = week64.getEnd();
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year67 = week66.getYear();
//        long long68 = week66.getFirstMillisecond();
//        java.util.Date date69 = week66.getEnd();
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year71 = week70.getYear();
//        java.lang.Class<?> wildcardClass72 = year71.getClass();
//        java.lang.Class class73 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass72);
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year76 = week75.getYear();
//        long long77 = year76.getMiddleMillisecond();
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(1, year76);
//        java.util.Date date79 = year76.getEnd();
//        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year81 = week80.getYear();
//        int int82 = week80.getWeek();
//        java.lang.Class class83 = null;
//        org.jfree.data.time.Week week84 = new org.jfree.data.time.Week();
//        java.util.Date date85 = week84.getStart();
//        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance(class83, date85, timeZone86);
//        java.lang.Class<?> wildcardClass88 = timeZone86.getClass();
//        boolean boolean89 = week80.equals((java.lang.Object) timeZone86);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass72, date79, timeZone86);
//        org.jfree.data.time.Week week91 = new org.jfree.data.time.Week(date69, timeZone86);
//        org.jfree.data.time.Week week92 = new org.jfree.data.time.Week(date65, timeZone86);
//        org.jfree.data.time.Week week93 = new org.jfree.data.time.Week(date45, timeZone86);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date41, timeZone86);
//        java.util.Locale locale95 = null;
//        try {
//            org.jfree.data.time.Week week96 = new org.jfree.data.time.Week(date3, timeZone86, locale95);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1562097599999L + "'", long23 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(year27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 24 + "'", int28 == 24);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(year43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560063600000L + "'", long44 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNotNull(year54);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560063600000L + "'", long55 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(wildcardClass62);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(year67);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1560063600000L + "'", long68 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(year71);
//        org.junit.Assert.assertNotNull(wildcardClass72);
//        org.junit.Assert.assertNotNull(class73);
//        org.junit.Assert.assertNotNull(year76);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1562097599999L + "'", long77 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertNotNull(year81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 24 + "'", int82 == 24);
//        org.junit.Assert.assertNotNull(date85);
//        org.junit.Assert.assertNotNull(timeZone86);
//        org.junit.Assert.assertNull(regularTimePeriod87);
//        org.junit.Assert.assertNotNull(wildcardClass88);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod90);
//        org.junit.Assert.assertNotNull(regularTimePeriod94);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        long long3 = year2.getMiddleMillisecond();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(11, year2);
        int int5 = week4.getYearValue();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year7 = week6.getYear();
        java.lang.Class<?> wildcardClass8 = year7.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        boolean boolean11 = week4.equals((java.lang.Object) wildcardClass8);
        long long12 = week4.getSerialIndex();
        java.util.Date date13 = week4.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week4.previous();
        java.util.Calendar calendar15 = null;
        try {
            week4.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107018L + "'", long12 == 107018L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        java.lang.Class<?> wildcardClass11 = date3.getClass();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year13 = week12.getYear();
//        long long14 = week12.getFirstMillisecond();
//        java.util.Date date15 = week12.getEnd();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        java.util.Date date18 = week17.getStart();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date18, timeZone19);
//        java.lang.Class<?> wildcardClass21 = timeZone19.getClass();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date15, timeZone19);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        java.util.Date date25 = week24.getStart();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date25, timeZone26);
//        java.lang.Class<?> wildcardClass28 = timeZone26.getClass();
//        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year31 = week30.getYear();
//        int int32 = week30.getYearValue();
//        java.util.Date date33 = week30.getStart();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        java.util.Date date36 = week35.getStart();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date36, timeZone37);
//        java.lang.Class<?> wildcardClass39 = timeZone37.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date33, timeZone37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone37);
//        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
//        java.util.Date date44 = week43.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week43.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week43.next();
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year48 = week47.getYear();
//        long long49 = week47.getFirstMillisecond();
//        java.util.Date date50 = week47.getEnd();
//        java.lang.Class class51 = null;
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week();
//        java.util.Date date53 = week52.getStart();
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date53, timeZone54);
//        java.lang.Class<?> wildcardClass56 = timeZone54.getClass();
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date50, timeZone54);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date50);
//        boolean boolean59 = week43.equals((java.lang.Object) week58);
//        java.lang.String str60 = week58.toString();
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year62 = week61.getYear();
//        int int63 = week61.getWeek();
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year66 = week65.getYear();
//        long long67 = year66.getMiddleMillisecond();
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(1, year66);
//        boolean boolean69 = week61.equals((java.lang.Object) year66);
//        int int70 = week58.compareTo((java.lang.Object) boolean69);
//        java.lang.String str71 = week58.toString();
//        java.util.Date date72 = week58.getEnd();
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year74 = week73.getYear();
//        long long75 = week73.getFirstMillisecond();
//        java.util.Date date76 = week73.getEnd();
//        java.lang.Class class77 = null;
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week();
//        java.util.Date date79 = week78.getStart();
//        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class77, date79, timeZone80);
//        java.lang.Class<?> wildcardClass82 = timeZone80.getClass();
//        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date76, timeZone80);
//        java.lang.Class<?> wildcardClass84 = date76.getClass();
//        java.util.Date date85 = null;
//        java.lang.Class class86 = null;
//        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week();
//        java.util.Date date88 = week87.getStart();
//        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance(class86, date88, timeZone89);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass84, date85, timeZone89);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date72, timeZone89);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560063600000L + "'", long14 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(class42);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(year48);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560063600000L + "'", long49 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Week 24, 2019" + "'", str60.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 24 + "'", int63 == 24);
//        org.junit.Assert.assertNotNull(year66);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1562097599999L + "'", long67 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "Week 24, 2019" + "'", str71.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(year74);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1560063600000L + "'", long75 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertNotNull(timeZone80);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//        org.junit.Assert.assertNotNull(wildcardClass82);
//        org.junit.Assert.assertNotNull(wildcardClass84);
//        org.junit.Assert.assertNotNull(date88);
//        org.junit.Assert.assertNotNull(timeZone89);
//        org.junit.Assert.assertNull(regularTimePeriod90);
//        org.junit.Assert.assertNull(regularTimePeriod91);
//        org.junit.Assert.assertNull(regularTimePeriod92);
//    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.Year year12 = week11.getYear();
//        int int13 = week11.getYearValue();
//        long long14 = week11.getLastMillisecond();
//        int int15 = week11.getWeek();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560668399999L + "'", long14 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
//    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.lang.Class<?> wildcardClass2 = year1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        long long7 = year6.getMiddleMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(1, year6);
//        java.util.Date date9 = year6.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year11 = week10.getYear();
//        int int12 = week10.getWeek();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getStart();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone16);
//        java.lang.Class<?> wildcardClass18 = timeZone16.getClass();
//        boolean boolean19 = week10.equals((java.lang.Object) timeZone16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone16);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        java.util.Date date22 = week21.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week21.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week21.next();
//        java.util.Date date25 = regularTimePeriod24.getStart();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year27 = week26.getYear();
//        long long28 = week26.getFirstMillisecond();
//        java.util.Date date29 = week26.getEnd();
//        java.lang.Class class30 = null;
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        java.util.Date date32 = week31.getStart();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date32, timeZone33);
//        java.lang.Class<?> wildcardClass35 = timeZone33.getClass();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date29, timeZone33);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year38 = week37.getYear();
//        long long39 = week37.getFirstMillisecond();
//        java.util.Date date40 = week37.getEnd();
//        java.lang.Class class41 = null;
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        java.util.Date date43 = week42.getStart();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date43, timeZone44);
//        java.lang.Class<?> wildcardClass46 = timeZone44.getClass();
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date40, timeZone44);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date40);
//        java.util.Date date49 = week48.getEnd();
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year51 = week50.getYear();
//        long long52 = week50.getFirstMillisecond();
//        java.util.Date date53 = week50.getEnd();
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year55 = week54.getYear();
//        java.lang.Class<?> wildcardClass56 = year55.getClass();
//        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass56);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year60 = week59.getYear();
//        long long61 = year60.getMiddleMillisecond();
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(1, year60);
//        java.util.Date date63 = year60.getEnd();
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year65 = week64.getYear();
//        int int66 = week64.getWeek();
//        java.lang.Class class67 = null;
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week();
//        java.util.Date date69 = week68.getStart();
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance(class67, date69, timeZone70);
//        java.lang.Class<?> wildcardClass72 = timeZone70.getClass();
//        boolean boolean73 = week64.equals((java.lang.Object) timeZone70);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date63, timeZone70);
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date53, timeZone70);
//        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date49, timeZone70);
//        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date29, timeZone70);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date25, timeZone70);
//        java.lang.Class<?> wildcardClass79 = timeZone70.getClass();
//        java.util.Date date80 = null;
//        java.util.TimeZone timeZone81 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass79, date80, timeZone81);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1562097599999L + "'", long7 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(year27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560063600000L + "'", long28 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(year38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560063600000L + "'", long39 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(year51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560063600000L + "'", long52 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(year55);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(class57);
//        org.junit.Assert.assertNotNull(year60);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1562097599999L + "'", long61 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(year65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 24 + "'", int66 == 24);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(wildcardClass72);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertNotNull(wildcardClass79);
//        org.junit.Assert.assertNull(regularTimePeriod82);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        long long5 = year4.getMiddleMillisecond();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(1, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(2, year4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) -1, year4);
        java.lang.String str9 = week8.toString();
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week -1, 2019" + "'", str9.equals("Week -1, 2019"));
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        boolean boolean16 = week0.equals((java.lang.Object) week15);
//        java.lang.String str17 = week15.toString();
//        int int18 = week15.getWeek();
//        java.util.Date date19 = week15.getStart();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date19);
//        org.jfree.data.time.Year year21 = week20.getYear();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 24, 2019" + "'", str17.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(year21);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        java.lang.Class<?> wildcardClass5 = timeZone3.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year9 = week8.getYear();
        int int10 = week8.getYearValue();
        java.util.Date date11 = week8.getStart();
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone12);
        java.util.TimeZone timeZone14 = null;
        try {
            org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date11, timeZone14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(regularTimePeriod13);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, 8);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        java.lang.String str2 = week0.toString();
//        int int3 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, (int) (short) -1);
//        int int7 = week0.compareTo((java.lang.Object) (short) -1);
//        java.lang.String str8 = week0.toString();
//        long long9 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        long long3 = week1.getFirstMillisecond();
//        java.util.Date date4 = week1.getEnd();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getStart();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date7, timeZone8);
//        java.lang.Class<?> wildcardClass10 = timeZone8.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone8);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date4);
//        org.jfree.data.time.Year year13 = week12.getYear();
//        long long14 = year13.getMiddleMillisecond();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(12, year13);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1562097599999L + "'", long14 == 1562097599999L);
//    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year4 = week3.getYear();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(11, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 0, year4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', year4);
//        java.util.Date date9 = year4.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year11 = week10.getYear();
//        int int12 = week10.getWeek();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getStart();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone16);
//        java.lang.Class<?> wildcardClass18 = timeZone16.getClass();
//        boolean boolean19 = week10.equals((java.lang.Object) timeZone16);
//        java.util.Locale locale20 = null;
//        try {
//            org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date9, timeZone16, locale20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 3);
        int int4 = week2.compareTo((java.lang.Object) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 3);
        int int4 = week2.compareTo((java.lang.Object) (-1.0d));
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.lang.Class<?> wildcardClass2 = year1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize(class5);
        java.util.Date date7 = null;
        java.lang.Class class8 = null;
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
        java.util.Date date10 = week9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date7, timeZone11);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNull(regularTimePeriod13);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, 7);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        boolean boolean16 = week0.equals((java.lang.Object) week15);
//        java.lang.String str17 = week15.toString();
//        int int18 = week15.getWeek();
//        java.util.Date date19 = week15.getStart();
//        java.util.Calendar calendar20 = null;
//        try {
//            long long21 = week15.getFirstMillisecond(calendar20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 24, 2019" + "'", str17.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//        org.junit.Assert.assertNotNull(date19);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        java.util.Calendar calendar3 = null;
        try {
            week0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        int int2 = week0.getYearValue();
        java.util.Date date3 = week0.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
        java.lang.String str6 = timePeriodFormatException5.toString();
        java.lang.String str7 = timePeriodFormatException5.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException9.getSuppressed();
        java.lang.String str11 = timePeriodFormatException9.toString();
        java.lang.String str12 = timePeriodFormatException9.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str19 = timePeriodFormatException18.toString();
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException23.getSuppressed();
        java.lang.String str25 = timePeriodFormatException23.toString();
        java.lang.String str26 = timePeriodFormatException23.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray29 = timePeriodFormatException28.getSuppressed();
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str33 = timePeriodFormatException32.toString();
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        java.lang.Throwable[] throwableArray35 = timePeriodFormatException32.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        java.lang.Class<?> wildcardClass37 = timePeriodFormatException32.getClass();
        boolean boolean38 = week0.equals((java.lang.Object) wildcardClass37);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str19.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str26.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str33.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        boolean boolean16 = week0.equals((java.lang.Object) week15);
//        java.lang.String str17 = week15.toString();
//        int int18 = week15.getWeek();
//        java.lang.Class<?> wildcardClass19 = week15.getClass();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year21 = week20.getYear();
//        long long22 = week20.getFirstMillisecond();
//        java.util.Date date23 = week20.getEnd();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year25 = week24.getYear();
//        int int26 = week24.getWeek();
//        java.lang.Class class27 = null;
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        java.util.Date date29 = week28.getStart();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date29, timeZone30);
//        java.lang.Class<?> wildcardClass32 = timeZone30.getClass();
//        boolean boolean33 = week24.equals((java.lang.Object) timeZone30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date23, timeZone30);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 24, 2019" + "'", str17.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560063600000L + "'", long22 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 24 + "'", int26 == 24);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        java.lang.Class class5 = null;
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        java.util.Date date7 = week6.getStart();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date7, timeZone8);
        java.lang.Class<?> wildcardClass10 = timeZone8.getClass();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date2, timeZone8);
        java.lang.Object obj12 = null;
        int int13 = week11.compareTo(obj12);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 0);
        long long3 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168616000001L) + "'", long3 == (-62168616000001L));
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, (int) '4');
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 10);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date2);
//        long long7 = week6.getFirstMillisecond();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week6.getMiddleMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        boolean boolean3 = week0.equals((java.lang.Object) 'a');
//        java.lang.String str4 = week0.toString();
//        long long5 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        long long3 = year2.getMiddleMillisecond();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(11, year2);
        int int5 = week4.getYearValue();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year7 = week6.getYear();
        java.lang.Class<?> wildcardClass8 = year7.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        boolean boolean11 = week4.equals((java.lang.Object) wildcardClass8);
        long long12 = week4.getSerialIndex();
        java.util.Date date13 = week4.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week4.previous();
        java.lang.Class<?> wildcardClass15 = regularTimePeriod14.getClass();
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107018L + "'", long12 == 107018L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class16);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.next();
        java.util.Date date8 = regularTimePeriod7.getStart();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        long long3 = year2.getMiddleMillisecond();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(11, year2);
        int int5 = week4.getYearValue();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year7 = week6.getYear();
        java.lang.Class<?> wildcardClass8 = year7.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        boolean boolean11 = week4.equals((java.lang.Object) wildcardClass8);
        long long12 = week4.getSerialIndex();
        java.util.Date date13 = week4.getEnd();
        java.lang.Class class14 = null;
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
        java.util.Date date16 = week15.getStart();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date16, timeZone17);
        java.lang.Class class19 = null;
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
        java.util.Date date21 = week20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date21, timeZone22);
        java.lang.Class<?> wildcardClass24 = timeZone22.getClass();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date16, timeZone22);
        java.util.Locale locale26 = null;
        try {
            org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date13, timeZone22, locale26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107018L + "'", long12 == 107018L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 11);
//        java.util.Date date3 = week2.getStart();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year12 = week11.getYear();
//        int int13 = week11.getYearValue();
//        java.util.Date date14 = week11.getStart();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        java.util.Date date17 = week16.getStart();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date17, timeZone18);
//        java.lang.Class<?> wildcardClass20 = timeZone18.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date14, timeZone18);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year23 = week22.getYear();
//        long long24 = week22.getFirstMillisecond();
//        java.util.Date date25 = week22.getEnd();
//        java.lang.Class class26 = null;
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        java.util.Date date28 = week27.getStart();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date28, timeZone29);
//        java.lang.Class<?> wildcardClass31 = timeZone29.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date25, timeZone29);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        java.util.Date date35 = week34.getStart();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date35, timeZone36);
//        java.lang.Class<?> wildcardClass38 = timeZone36.getClass();
//        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year41 = week40.getYear();
//        int int42 = week40.getYearValue();
//        java.util.Date date43 = week40.getStart();
//        java.lang.Class class44 = null;
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week();
//        java.util.Date date46 = week45.getStart();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date46, timeZone47);
//        java.lang.Class<?> wildcardClass49 = timeZone47.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date43, timeZone47);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year52 = week51.getYear();
//        long long53 = week51.getFirstMillisecond();
//        java.util.Date date54 = week51.getEnd();
//        java.lang.Class class55 = null;
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week();
//        java.util.Date date57 = week56.getStart();
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date57, timeZone58);
//        java.lang.Class<?> wildcardClass60 = timeZone58.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date54, timeZone58);
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date25, timeZone58);
//        java.util.Locale locale63 = null;
//        try {
//            org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date3, timeZone58, locale63);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560063600000L + "'", long24 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNotNull(class39);
//        org.junit.Assert.assertNotNull(year41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(year52);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560063600000L + "'", long53 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(wildcardClass60);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.Year year12 = week11.getYear();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getStart();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone16);
//        java.lang.Class<?> wildcardClass18 = timeZone16.getClass();
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year21 = week20.getYear();
//        int int22 = week20.getYearValue();
//        java.util.Date date23 = week20.getStart();
//        java.lang.Class class24 = null;
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        java.util.Date date26 = week25.getStart();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date26, timeZone27);
//        java.lang.Class<?> wildcardClass29 = timeZone27.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date23, timeZone27);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year32 = week31.getYear();
//        long long33 = week31.getFirstMillisecond();
//        java.util.Date date34 = week31.getEnd();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        java.util.Date date37 = week36.getStart();
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date37, timeZone38);
//        java.lang.Class<?> wildcardClass40 = timeZone38.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date34, timeZone38);
//        int int42 = week11.compareTo((java.lang.Object) regularTimePeriod41);
//        java.util.Calendar calendar43 = null;
//        try {
//            long long44 = regularTimePeriod41.getMiddleMillisecond(calendar43);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560063600000L + "'", long33 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        boolean boolean3 = week0.equals((java.lang.Object) 'a');
//        java.lang.String str4 = week0.toString();
//        int int5 = week0.getWeek();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        java.lang.String str2 = week0.toString();
//        int int3 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, (int) (short) -1);
//        int int7 = week0.compareTo((java.lang.Object) (short) -1);
//        java.lang.String str8 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week0.next();
//        int int10 = week0.getYearValue();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        java.lang.String str7 = timePeriodFormatException5.toString();
        java.lang.String str8 = timePeriodFormatException5.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str15 = timePeriodFormatException14.toString();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException5.getSuppressed();
        java.lang.Class<?> wildcardClass19 = throwableArray18.getClass();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week -1, 2019");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 0);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year4 = week3.getYear();
//        int int5 = week3.getWeek();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.util.Date date8 = week7.getStart();
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date8, timeZone9);
//        java.lang.Class<?> wildcardClass11 = timeZone9.getClass();
//        boolean boolean12 = week3.equals((java.lang.Object) timeZone9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week3.previous();
//        java.util.Date date14 = regularTimePeriod13.getStart();
//        boolean boolean15 = week2.equals((java.lang.Object) regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        long long3 = year2.getMiddleMillisecond();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(11, year2);
        java.util.Date date5 = year2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.lang.Class<?> wildcardClass2 = year1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        long long7 = year6.getMiddleMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(1, year6);
//        java.util.Date date9 = year6.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year11 = week10.getYear();
//        int int12 = week10.getWeek();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getStart();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone16);
//        java.lang.Class<?> wildcardClass18 = timeZone16.getClass();
//        boolean boolean19 = week10.equals((java.lang.Object) timeZone16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone16);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Year year23 = week22.getYear();
//        java.util.Calendar calendar24 = null;
//        try {
//            long long25 = year23.getMiddleMillisecond(calendar24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1562097599999L + "'", long7 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(year23);
//    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
//        long long7 = week5.getMiddleMillisecond();
//        java.util.Date date8 = week5.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year10 = week9.getYear();
//        int int11 = week9.getYearValue();
//        java.util.Date date12 = week9.getStart();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year15 = week14.getYear();
//        int int16 = week14.getWeek();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        java.util.Date date19 = week18.getStart();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date19, timeZone20);
//        java.lang.Class<?> wildcardClass22 = timeZone20.getClass();
//        boolean boolean23 = week14.equals((java.lang.Object) timeZone20);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date12, timeZone20);
//        java.util.Locale locale25 = null;
//        try {
//            org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date8, timeZone20, locale25);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year4 = week3.getYear();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(11, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 0, year4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', year4);
//        java.lang.Class<?> wildcardClass9 = week8.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year12 = week11.getYear();
//        long long13 = week11.getFirstMillisecond();
//        java.util.Date date14 = week11.getEnd();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year16 = week15.getYear();
//        long long17 = week15.getFirstMillisecond();
//        java.util.Date date18 = week15.getEnd();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        java.util.Date date21 = week20.getStart();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date21, timeZone22);
//        java.lang.Class<?> wildcardClass24 = timeZone22.getClass();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date18, timeZone22);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year27 = week26.getYear();
//        long long28 = week26.getFirstMillisecond();
//        java.util.Date date29 = week26.getEnd();
//        java.lang.Class class30 = null;
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        java.util.Date date32 = week31.getStart();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date32, timeZone33);
//        java.lang.Class<?> wildcardClass35 = timeZone33.getClass();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date29, timeZone33);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date29);
//        java.util.Date date38 = week37.getEnd();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year40 = week39.getYear();
//        long long41 = week39.getFirstMillisecond();
//        java.util.Date date42 = week39.getEnd();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year44 = week43.getYear();
//        java.lang.Class<?> wildcardClass45 = year44.getClass();
//        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass45);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year49 = week48.getYear();
//        long long50 = year49.getMiddleMillisecond();
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(1, year49);
//        java.util.Date date52 = year49.getEnd();
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year54 = week53.getYear();
//        int int55 = week53.getWeek();
//        java.lang.Class class56 = null;
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week();
//        java.util.Date date58 = week57.getStart();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class56, date58, timeZone59);
//        java.lang.Class<?> wildcardClass61 = timeZone59.getClass();
//        boolean boolean62 = week53.equals((java.lang.Object) timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date52, timeZone59);
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date42, timeZone59);
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date38, timeZone59);
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date18, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone59);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560063600000L + "'", long13 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(year27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560063600000L + "'", long28 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(year40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560063600000L + "'", long41 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(year44);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(class46);
//        org.junit.Assert.assertNotNull(year49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1562097599999L + "'", long50 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(year54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 24 + "'", int55 == 24);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year5 = week4.getYear();
        long long6 = year5.getMiddleMillisecond();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(1, year5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(2, year5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 1, year5);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (byte) 10, year5);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        java.lang.String str7 = timePeriodFormatException5.toString();
        java.lang.String str8 = timePeriodFormatException5.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str15 = timePeriodFormatException14.toString();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException19.getSuppressed();
        java.lang.String str21 = timePeriodFormatException19.toString();
        java.lang.String str22 = timePeriodFormatException19.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException24.getSuppressed();
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str29 = timePeriodFormatException28.toString();
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException28.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        java.lang.Class<?> wildcardClass33 = timePeriodFormatException28.getClass();
        java.lang.Throwable[] throwableArray34 = timePeriodFormatException28.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str29.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(throwableArray34);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 10, 3);
        long long3 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62067312000000L) + "'", long3 == (-62067312000000L));
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        boolean boolean16 = week0.equals((java.lang.Object) week15);
//        java.lang.String str17 = week15.toString();
//        int int18 = week15.getWeek();
//        java.util.Date date19 = week15.getStart();
//        long long20 = week15.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 24, 2019" + "'", str17.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560668399999L + "'", long20 == 1560668399999L);
//    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.lang.Class<?> wildcardClass2 = year1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        long long7 = year6.getMiddleMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(1, year6);
//        java.util.Date date9 = year6.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year11 = week10.getYear();
//        int int12 = week10.getWeek();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getStart();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone16);
//        java.lang.Class<?> wildcardClass18 = timeZone16.getClass();
//        boolean boolean19 = week10.equals((java.lang.Object) timeZone16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone16);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.previous();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1562097599999L + "'", long7 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        long long3 = year2.getMiddleMillisecond();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(1, year2);
        long long5 = year2.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        int int2 = week0.getYearValue();
        java.util.Date date3 = week0.getStart();
        int int4 = week0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
        java.util.Date date6 = week0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.previous();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test281");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        java.lang.Class<?> wildcardClass11 = date3.getClass();
//        java.util.Date date12 = null;
//        java.lang.Class class13 = null;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getStart();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone16);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year20 = week19.getYear();
//        long long21 = week19.getFirstMillisecond();
//        java.util.Date date22 = week19.getEnd();
//        java.util.Date date23 = week19.getStart();
//        java.util.Date date24 = week19.getEnd();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year26 = week25.getYear();
//        java.lang.Class<?> wildcardClass27 = year26.getClass();
//        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year30 = week29.getYear();
//        int int31 = week29.getWeek();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year34 = week33.getYear();
//        long long35 = year34.getMiddleMillisecond();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(1, year34);
//        boolean boolean37 = week29.equals((java.lang.Object) year34);
//        java.lang.String str38 = week29.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week29.next();
//        java.util.Date date40 = regularTimePeriod39.getEnd();
//        java.lang.Class class41 = null;
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        java.util.Date date43 = week42.getStart();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date43, timeZone44);
//        java.lang.Class<?> wildcardClass46 = timeZone44.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date40, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date24, timeZone44);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560063600000L + "'", long21 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 24 + "'", int31 == 24);
//        org.junit.Assert.assertNotNull(year34);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1562097599999L + "'", long35 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Week 24, 2019" + "'", str38.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        long long3 = year2.getMiddleMillisecond();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(11, year2);
//        int int5 = week4.getYearValue();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year7 = week6.getYear();
//        java.lang.Class<?> wildcardClass8 = year7.getClass();
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        boolean boolean11 = week4.equals((java.lang.Object) wildcardClass8);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        long long15 = week13.getFirstMillisecond();
//        long long16 = week13.getSerialIndex();
//        long long17 = week13.getFirstMillisecond();
//        java.util.Date date18 = week13.getEnd();
//        java.util.TimeZone timeZone19 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date18, timeZone19);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        boolean boolean16 = week0.equals((java.lang.Object) week15);
//        java.lang.String str17 = week15.toString();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        java.util.Date date20 = week19.getStart();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.next();
//        long long25 = week23.getMiddleMillisecond();
//        java.util.Date date26 = week23.getStart();
//        long long27 = week23.getLastMillisecond();
//        int int28 = week15.compareTo((java.lang.Object) week23);
//        java.util.Calendar calendar29 = null;
//        try {
//            week15.peg(calendar29);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 24, 2019" + "'", str17.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560365999999L + "'", long25 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560668399999L + "'", long27 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        long long4 = week0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        java.lang.Class class5 = null;
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        java.util.Date date7 = week6.getStart();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date7, timeZone8);
        java.lang.Class<?> wildcardClass10 = timeZone8.getClass();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date2, timeZone8);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.Year year13 = week12.getYear();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(year13);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        java.lang.String str2 = week0.toString();
//        int int3 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, (int) (short) -1);
//        int int7 = week0.compareTo((java.lang.Object) (short) -1);
//        java.lang.Class<?> wildcardClass8 = week0.getClass();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week0.getLastMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 3);
        int int4 = week2.compareTo((java.lang.Object) (-1.0d));
        long long5 = week2.getFirstMillisecond();
        long long6 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62067312000000L) + "'", long5 == (-62067312000000L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62067312000000L) + "'", long6 == (-62067312000000L));
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date2);
//        java.lang.String str7 = week6.toString();
//        long long8 = week6.getMiddleMillisecond();
//        long long9 = week6.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test289");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        boolean boolean16 = week0.equals((java.lang.Object) week15);
//        java.lang.String str17 = week15.toString();
//        int int18 = week15.getWeek();
//        java.util.Date date19 = week15.getStart();
//        java.util.Calendar calendar20 = null;
//        try {
//            long long21 = week15.getMiddleMillisecond(calendar20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 24, 2019" + "'", str17.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//        org.junit.Assert.assertNotNull(date19);
//    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        long long3 = week1.getFirstMillisecond();
//        java.util.Date date4 = week1.getEnd();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getStart();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date7, timeZone8);
//        java.lang.Class<?> wildcardClass10 = timeZone8.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone8);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date4);
//        java.util.Date date13 = week12.getEnd();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year15 = week14.getYear();
//        long long16 = week14.getFirstMillisecond();
//        java.util.Date date17 = week14.getEnd();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year19 = week18.getYear();
//        java.lang.Class<?> wildcardClass20 = year19.getClass();
//        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year24 = week23.getYear();
//        long long25 = year24.getMiddleMillisecond();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(1, year24);
//        java.util.Date date27 = year24.getEnd();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year29 = week28.getYear();
//        int int30 = week28.getWeek();
//        java.lang.Class class31 = null;
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        java.util.Date date33 = week32.getStart();
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date33, timeZone34);
//        java.lang.Class<?> wildcardClass36 = timeZone34.getClass();
//        boolean boolean37 = week28.equals((java.lang.Object) timeZone34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date27, timeZone34);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date17, timeZone34);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date13, timeZone34);
//        try {
//            org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date0, timeZone34);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560063600000L + "'", long16 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1562097599999L + "'", long25 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 24 + "'", int30 == 24);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 8);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
        java.lang.Throwable throwable2 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        java.lang.Class<?> wildcardClass5 = timeZone3.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        int int9 = week7.getYearValue();
//        java.util.Date date10 = week7.getStart();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        java.util.Date date13 = week12.getStart();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
//        java.lang.Class<?> wildcardClass16 = timeZone14.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date10, timeZone14);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year19 = week18.getYear();
//        long long20 = week18.getFirstMillisecond();
//        java.util.Date date21 = week18.getEnd();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        java.util.Date date24 = week23.getStart();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date24, timeZone25);
//        java.lang.Class<?> wildcardClass27 = timeZone25.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date21, timeZone25);
//        java.lang.Class class29 = null;
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        java.util.Date date31 = week30.getStart();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date31, timeZone32);
//        java.lang.Class<?> wildcardClass34 = timeZone32.getClass();
//        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year37 = week36.getYear();
//        int int38 = week36.getYearValue();
//        java.util.Date date39 = week36.getStart();
//        java.lang.Class class40 = null;
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        java.util.Date date42 = week41.getStart();
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date42, timeZone43);
//        java.lang.Class<?> wildcardClass45 = timeZone43.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date39, timeZone43);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year48 = week47.getYear();
//        long long49 = week47.getFirstMillisecond();
//        java.util.Date date50 = week47.getEnd();
//        java.lang.Class class51 = null;
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week();
//        java.util.Date date53 = week52.getStart();
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date53, timeZone54);
//        java.lang.Class<?> wildcardClass56 = timeZone54.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date50, timeZone54);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date21, timeZone54);
//        int int59 = week58.getWeek();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560063600000L + "'", long20 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(year48);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560063600000L + "'", long49 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 24 + "'", int59 == 24);
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(11, (int) (byte) -1);
        long long3 = week2.getSerialIndex();
        long long4 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-42L) + "'", long3 == (-42L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62192808000001L) + "'", long4 == (-62192808000001L));
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        java.util.Date date4 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        long long4 = year3.getMiddleMillisecond();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(1, year3);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year3);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        long long9 = week7.getFirstMillisecond();
//        java.util.Date date10 = week7.getEnd();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        java.util.Date date13 = week12.getStart();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
//        java.lang.Class<?> wildcardClass16 = timeZone14.getClass();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date10, timeZone14);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date10);
//        org.jfree.data.time.Year year19 = week18.getYear();
//        boolean boolean20 = week6.equals((java.lang.Object) week18);
//        org.jfree.data.time.Year year21 = week18.getYear();
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(year21);
//    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        java.lang.String str4 = week0.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        int int3 = week0.getYearValue();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        long long16 = week15.getSerialIndex();
//        boolean boolean17 = week0.equals((java.lang.Object) week15);
//        org.jfree.data.time.Year year18 = week15.getYear();
//        int int19 = week15.getYearValue();
//        java.util.Calendar calendar20 = null;
//        try {
//            long long21 = week15.getMiddleMillisecond(calendar20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        long long5 = week4.getLastMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year5 = week4.getYear();
        long long6 = year5.getMiddleMillisecond();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(1, year5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((-1), year5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 0, year5);
        long long10 = year5.getMiddleMillisecond();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(2019, year5);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        long long5 = year4.getMiddleMillisecond();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(1, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((-1), year4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) 0, year4);
        java.lang.Class<?> wildcardClass9 = week8.getClass();
        java.util.Calendar calendar10 = null;
        try {
            week8.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.String str4 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException6.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = year5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(1, year5);
//        boolean boolean8 = week0.equals((java.lang.Object) year5);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year12 = week11.getYear();
//        long long13 = year12.getMiddleMillisecond();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(11, year12);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (byte) 0, year12);
//        int int16 = week0.compareTo((java.lang.Object) (byte) 0);
//        java.util.Date date17 = week0.getEnd();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(date17);
//    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        java.util.Date date4 = week0.getStart();
//        long long5 = week0.getMiddleMillisecond();
//        long long6 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        java.lang.String str7 = timePeriodFormatException5.toString();
        java.lang.String str8 = timePeriodFormatException5.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str15 = timePeriodFormatException14.toString();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException5.getSuppressed();
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray22 = timePeriodFormatException21.getSuppressed();
        java.lang.String str23 = timePeriodFormatException21.toString();
        java.lang.String str24 = timePeriodFormatException21.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray27 = timePeriodFormatException26.getSuppressed();
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray27);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        long long5 = year4.getMiddleMillisecond();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(1, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((-1), year4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, year4);
        long long9 = week8.getLastMillisecond();
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546156799999L + "'", long9 == 1546156799999L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 10, 3);
        int int4 = week2.compareTo((java.lang.Object) (-42L));
        java.util.Calendar calendar5 = null;
        try {
            week2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year7 = week6.getYear();
//        long long8 = week6.getFirstMillisecond();
//        java.util.Date date9 = week6.getEnd();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getStart();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date12, timeZone13);
//        java.lang.Class<?> wildcardClass15 = timeZone13.getClass();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date9, timeZone13);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year18 = week17.getYear();
//        long long19 = week17.getFirstMillisecond();
//        java.util.Date date20 = week17.getEnd();
//        java.lang.Class class21 = null;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        java.util.Date date23 = week22.getStart();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date23, timeZone24);
//        java.lang.Class<?> wildcardClass26 = timeZone24.getClass();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date20, timeZone24);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date20);
//        java.util.Date date29 = week28.getEnd();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year31 = week30.getYear();
//        long long32 = week30.getFirstMillisecond();
//        java.util.Date date33 = week30.getEnd();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year35 = week34.getYear();
//        java.lang.Class<?> wildcardClass36 = year35.getClass();
//        java.lang.Class class37 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass36);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year40 = week39.getYear();
//        long long41 = year40.getMiddleMillisecond();
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(1, year40);
//        java.util.Date date43 = year40.getEnd();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year45 = week44.getYear();
//        int int46 = week44.getWeek();
//        java.lang.Class class47 = null;
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        java.util.Date date49 = week48.getStart();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date49, timeZone50);
//        java.lang.Class<?> wildcardClass52 = timeZone50.getClass();
//        boolean boolean53 = week44.equals((java.lang.Object) timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date43, timeZone50);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date33, timeZone50);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date29, timeZone50);
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date9, timeZone50);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date4, timeZone50);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year60 = week59.getYear();
//        long long61 = week59.getFirstMillisecond();
//        org.jfree.data.time.Year year62 = week59.getYear();
//        java.lang.Class class63 = null;
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week();
//        java.util.Date date65 = week64.getStart();
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance(class63, date65, timeZone66);
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date65);
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date65);
//        java.lang.String str70 = week69.toString();
//        long long71 = week69.getMiddleMillisecond();
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year73 = week72.getYear();
//        int int74 = week72.getYearValue();
//        java.util.Date date75 = week72.getEnd();
//        int int76 = week69.compareTo((java.lang.Object) week72);
//        boolean boolean77 = week59.equals((java.lang.Object) week72);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = week72.previous();
//        int int79 = week58.compareTo((java.lang.Object) week72);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560063600000L + "'", long19 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560063600000L + "'", long32 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(year35);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(class37);
//        org.junit.Assert.assertNotNull(year40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1562097599999L + "'", long41 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(year45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 24 + "'", int46 == 24);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(year60);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560063600000L + "'", long61 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year62);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "Week 24, 2019" + "'", str70.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560365999999L + "'", long71 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 2019 + "'", int74 == 2019);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
//    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year7 = week6.getYear();
//        long long8 = week6.getFirstMillisecond();
//        java.util.Date date9 = week6.getEnd();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getStart();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date12, timeZone13);
//        java.lang.Class<?> wildcardClass15 = timeZone13.getClass();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date9, timeZone13);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year18 = week17.getYear();
//        long long19 = week17.getFirstMillisecond();
//        java.util.Date date20 = week17.getEnd();
//        java.lang.Class class21 = null;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        java.util.Date date23 = week22.getStart();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date23, timeZone24);
//        java.lang.Class<?> wildcardClass26 = timeZone24.getClass();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date20, timeZone24);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date20);
//        java.util.Date date29 = week28.getEnd();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year31 = week30.getYear();
//        long long32 = week30.getFirstMillisecond();
//        java.util.Date date33 = week30.getEnd();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year35 = week34.getYear();
//        java.lang.Class<?> wildcardClass36 = year35.getClass();
//        java.lang.Class class37 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass36);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year40 = week39.getYear();
//        long long41 = year40.getMiddleMillisecond();
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(1, year40);
//        java.util.Date date43 = year40.getEnd();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year45 = week44.getYear();
//        int int46 = week44.getWeek();
//        java.lang.Class class47 = null;
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        java.util.Date date49 = week48.getStart();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date49, timeZone50);
//        java.lang.Class<?> wildcardClass52 = timeZone50.getClass();
//        boolean boolean53 = week44.equals((java.lang.Object) timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date43, timeZone50);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date33, timeZone50);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date29, timeZone50);
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date9, timeZone50);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date4, timeZone50);
//        java.util.Calendar calendar59 = null;
//        try {
//            long long60 = week58.getMiddleMillisecond(calendar59);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560063600000L + "'", long19 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560063600000L + "'", long32 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(year35);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(class37);
//        org.junit.Assert.assertNotNull(year40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1562097599999L + "'", long41 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(year45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 24 + "'", int46 == 24);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.String str4 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        java.lang.String str13 = timePeriodFormatException11.toString();
        java.lang.String str14 = timePeriodFormatException11.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException16.getSuppressed();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str21 = timePeriodFormatException20.toString();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.String str24 = timePeriodFormatException11.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        long long4 = week0.getLastMillisecond();
//        long long5 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 1);
//        int int9 = week0.compareTo((java.lang.Object) (byte) 1);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 0, 2019");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
        java.lang.String str5 = timePeriodFormatException4.toString();
        java.lang.String str6 = timePeriodFormatException4.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        java.lang.String str10 = timePeriodFormatException8.toString();
        java.lang.String str11 = timePeriodFormatException8.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException13.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str18 = timePeriodFormatException17.toString();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException22.getSuppressed();
        java.lang.String str24 = timePeriodFormatException22.toString();
        java.lang.String str25 = timePeriodFormatException22.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray28 = timePeriodFormatException27.getSuppressed();
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str32 = timePeriodFormatException31.toString();
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        java.lang.Throwable[] throwableArray34 = timePeriodFormatException31.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        java.lang.Class<?> wildcardClass36 = timePeriodFormatException31.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        timePeriodFormatException31.addSuppressed((java.lang.Throwable) timePeriodFormatException38);
        java.lang.Throwable[] throwableArray40 = timePeriodFormatException31.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str32.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(throwableArray40);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        boolean boolean16 = week0.equals((java.lang.Object) week15);
//        java.lang.String str17 = week15.toString();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year19 = week18.getYear();
//        int int20 = week18.getWeek();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year23 = week22.getYear();
//        long long24 = year23.getMiddleMillisecond();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(1, year23);
//        boolean boolean26 = week18.equals((java.lang.Object) year23);
//        int int27 = week15.compareTo((java.lang.Object) boolean26);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray30 = timePeriodFormatException29.getSuppressed();
//        java.lang.String str31 = timePeriodFormatException29.toString();
//        java.lang.String str32 = timePeriodFormatException29.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
//        java.lang.Throwable[] throwableArray35 = timePeriodFormatException34.getSuppressed();
//        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
//        boolean boolean37 = week15.equals((java.lang.Object) timePeriodFormatException29);
//        long long38 = week15.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 24, 2019" + "'", str17.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1562097599999L + "'", long24 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(throwableArray30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str31.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str32.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertNotNull(throwableArray35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 107031L + "'", long38 == 107031L);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
        java.lang.String str8 = timePeriodFormatException6.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str12 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
        org.jfree.data.time.Year year4 = week0.getYear();
        java.lang.Class<?> wildcardClass5 = week0.getClass();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 1, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        java.lang.String str2 = week0.toString();
//        int int3 = week0.getYearValue();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week -1, 2019");
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
//        java.lang.String str8 = timePeriodFormatException6.toString();
//        int int9 = week0.compareTo((java.lang.Object) str8);
//        long long10 = week0.getMiddleMillisecond();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = week0.getLastMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week -1, 2019" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: Week -1, 2019"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560365999999L + "'", long10 == 1560365999999L);
//    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
//        long long7 = week5.getMiddleMillisecond();
//        long long8 = week5.getFirstMillisecond();
//        org.jfree.data.time.Year year9 = week5.getYear();
//        long long10 = week5.getMiddleMillisecond();
//        java.util.Date date11 = week5.getEnd();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560365999999L + "'", long10 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date11);
//    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date6);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date6);
//        java.lang.String str11 = week10.toString();
//        long long12 = week10.getMiddleMillisecond();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        int int15 = week13.getYearValue();
//        java.util.Date date16 = week13.getEnd();
//        int int17 = week10.compareTo((java.lang.Object) week13);
//        boolean boolean18 = week0.equals((java.lang.Object) week13);
//        java.util.Calendar calendar19 = null;
//        try {
//            long long20 = week13.getLastMillisecond(calendar19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 24, 2019" + "'", str11.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560365999999L + "'", long12 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        int int3 = week1.getWeek();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        long long7 = year6.getMiddleMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(1, year6);
//        boolean boolean9 = week1.equals((java.lang.Object) year6);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (short) 100, year6);
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = week10.getFirstMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1562097599999L + "'", long7 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        long long4 = year3.getMiddleMillisecond();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(1, year3);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(2, year3);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week6.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.String str3 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        java.util.Date date6 = week0.getEnd();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        int int2 = week0.getYearValue();
        java.util.Date date3 = week0.getStart();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        long long3 = year2.getMiddleMillisecond();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(11, year2);
//        int int5 = week4.getYearValue();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year7 = week6.getYear();
//        java.lang.Class<?> wildcardClass8 = year7.getClass();
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        boolean boolean11 = week4.equals((java.lang.Object) wildcardClass8);
//        long long12 = week4.getSerialIndex();
//        java.util.Date date13 = week4.getEnd();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year15 = week14.getYear();
//        java.lang.Class<?> wildcardClass16 = year15.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year20 = week19.getYear();
//        long long21 = year20.getMiddleMillisecond();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(1, year20);
//        java.util.Date date23 = year20.getEnd();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year25 = week24.getYear();
//        int int26 = week24.getWeek();
//        java.lang.Class class27 = null;
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        java.util.Date date29 = week28.getStart();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date29, timeZone30);
//        java.lang.Class<?> wildcardClass32 = timeZone30.getClass();
//        boolean boolean33 = week24.equals((java.lang.Object) timeZone30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date23, timeZone30);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        java.util.Date date36 = week35.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = week35.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week35.next();
//        java.util.Date date39 = regularTimePeriod38.getStart();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year41 = week40.getYear();
//        long long42 = week40.getFirstMillisecond();
//        java.util.Date date43 = week40.getEnd();
//        java.lang.Class class44 = null;
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week();
//        java.util.Date date46 = week45.getStart();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date46, timeZone47);
//        java.lang.Class<?> wildcardClass49 = timeZone47.getClass();
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date43, timeZone47);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year52 = week51.getYear();
//        long long53 = week51.getFirstMillisecond();
//        java.util.Date date54 = week51.getEnd();
//        java.lang.Class class55 = null;
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week();
//        java.util.Date date57 = week56.getStart();
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date57, timeZone58);
//        java.lang.Class<?> wildcardClass60 = timeZone58.getClass();
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date54, timeZone58);
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date54);
//        java.util.Date date63 = week62.getEnd();
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year65 = week64.getYear();
//        long long66 = week64.getFirstMillisecond();
//        java.util.Date date67 = week64.getEnd();
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year69 = week68.getYear();
//        java.lang.Class<?> wildcardClass70 = year69.getClass();
//        java.lang.Class class71 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass70);
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year74 = week73.getYear();
//        long long75 = year74.getMiddleMillisecond();
//        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(1, year74);
//        java.util.Date date77 = year74.getEnd();
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year79 = week78.getYear();
//        int int80 = week78.getWeek();
//        java.lang.Class class81 = null;
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week();
//        java.util.Date date83 = week82.getStart();
//        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance(class81, date83, timeZone84);
//        java.lang.Class<?> wildcardClass86 = timeZone84.getClass();
//        boolean boolean87 = week78.equals((java.lang.Object) timeZone84);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass70, date77, timeZone84);
//        org.jfree.data.time.Week week89 = new org.jfree.data.time.Week(date67, timeZone84);
//        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week(date63, timeZone84);
//        org.jfree.data.time.Week week91 = new org.jfree.data.time.Week(date43, timeZone84);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date39, timeZone84);
//        org.jfree.data.time.Week week93 = new org.jfree.data.time.Week(date13, timeZone84);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107018L + "'", long12 == 107018L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1562097599999L + "'", long21 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 24 + "'", int26 == 24);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(year41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560063600000L + "'", long42 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNotNull(year52);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560063600000L + "'", long53 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(wildcardClass60);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(year65);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1560063600000L + "'", long66 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(year69);
//        org.junit.Assert.assertNotNull(wildcardClass70);
//        org.junit.Assert.assertNotNull(class71);
//        org.junit.Assert.assertNotNull(year74);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1562097599999L + "'", long75 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNotNull(year79);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 24 + "'", int80 == 24);
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertNotNull(timeZone84);
//        org.junit.Assert.assertNull(regularTimePeriod85);
//        org.junit.Assert.assertNotNull(wildcardClass86);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod88);
//        org.junit.Assert.assertNotNull(regularTimePeriod92);
//    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test326");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = year5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(1, year5);
//        boolean boolean8 = week0.equals((java.lang.Object) year5);
//        java.lang.String str9 = week0.toString();
//        java.util.Calendar calendar10 = null;
//        try {
//            week0.peg(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 10, (int) (short) 1);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
        org.jfree.data.time.Year year4 = week0.getYear();
        java.lang.Class<?> wildcardClass5 = year4.getClass();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = regularTimePeriod2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(11, (int) (byte) -1);
        long long3 = week2.getSerialIndex();
        long long4 = week2.getFirstMillisecond();
        long long5 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-42L) + "'", long3 == (-42L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62193110400000L) + "'", long4 == (-62193110400000L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62192808000001L) + "'", long5 == (-62192808000001L));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        long long5 = year4.getMiddleMillisecond();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(11, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 0, year4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', year4);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week8.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        long long5 = year4.getMiddleMillisecond();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(11, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 0, year4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', year4);
        java.lang.Class<?> wildcardClass9 = week8.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNull(regularTimePeriod13);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 5);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 10, 3);
        long long3 = week2.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62066707200001L) + "'", long3 == (-62066707200001L));
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        java.lang.String str2 = week0.toString();
//        int int3 = week0.getWeek();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        java.util.Date date5 = week0.getStart();
//        long long6 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.util.Date date3 = week0.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
//        java.lang.String str7 = timePeriodFormatException5.toString();
//        java.lang.String str8 = timePeriodFormatException5.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
//        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
//        java.lang.String str15 = timePeriodFormatException14.toString();
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
//        java.lang.Throwable[] throwableArray17 = timePeriodFormatException14.getSuppressed();
//        java.lang.Class<?> wildcardClass18 = throwableArray17.getClass();
//        int int19 = week0.compareTo((java.lang.Object) wildcardClass18);
//        java.util.Date date20 = null;
//        java.lang.Class class21 = null;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        java.util.Date date23 = week22.getStart();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date23, timeZone24);
//        java.lang.Class<?> wildcardClass26 = timeZone24.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year29 = week28.getYear();
//        int int30 = week28.getYearValue();
//        java.util.Date date31 = week28.getStart();
//        java.lang.Class class32 = null;
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        java.util.Date date34 = week33.getStart();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date34, timeZone35);
//        java.lang.Class<?> wildcardClass37 = timeZone35.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date31, timeZone35);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year40 = week39.getYear();
//        long long41 = week39.getFirstMillisecond();
//        java.util.Date date42 = week39.getEnd();
//        java.lang.Class class43 = null;
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
//        java.util.Date date45 = week44.getStart();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class43, date45, timeZone46);
//        java.lang.Class<?> wildcardClass48 = timeZone46.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date42, timeZone46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date20, timeZone46);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertNotNull(throwableArray11);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
//        org.junit.Assert.assertNotNull(throwableArray17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(year40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560063600000L + "'", long41 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.String str4 = timePeriodFormatException1.toString();
        java.lang.String str5 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        java.util.Date date4 = week0.getStart();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date4);
//    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        boolean boolean3 = week0.equals((java.lang.Object) 'a');
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        long long7 = week4.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week4.previous();
//        boolean boolean9 = week0.equals((java.lang.Object) week4);
//        int int10 = week0.getYearValue();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        long long3 = year2.getMiddleMillisecond();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(11, year2);
        int int5 = week4.getYearValue();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year7 = week6.getYear();
        java.lang.Class<?> wildcardClass8 = year7.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        boolean boolean11 = week4.equals((java.lang.Object) wildcardClass8);
        long long12 = week4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week4.next();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107018L + "'", long12 == 107018L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date3);
//        long long12 = week11.getLastMillisecond();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = week11.getLastMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560668399999L + "'", long12 == 1560668399999L);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 1);
        long long3 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62136259200000L) + "'", long3 == (-62136259200000L));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (int) (byte) 10);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        java.lang.String str2 = week0.toString();
//        int int3 = week0.getYearValue();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 10, 3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
//        java.util.Date date9 = regularTimePeriod8.getStart();
//        int int10 = week0.compareTo((java.lang.Object) date9);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        boolean boolean16 = week0.equals((java.lang.Object) week15);
//        java.lang.String str17 = week15.toString();
//        int int18 = week15.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week15.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 24, 2019" + "'", str17.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date3);
//        java.util.Date date12 = week11.getEnd();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        int int15 = week13.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week13.previous();
//        java.util.Date date17 = week13.getStart();
//        org.jfree.data.time.Year year18 = week13.getYear();
//        long long19 = week13.getLastMillisecond();
//        java.util.Date date20 = week13.getStart();
//        java.lang.Class class21 = null;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        java.util.Date date23 = week22.getStart();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date23, timeZone24);
//        java.lang.Class class26 = null;
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        java.util.Date date28 = week27.getStart();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date28, timeZone29);
//        java.lang.Class<?> wildcardClass31 = timeZone29.getClass();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date23, timeZone29);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date20, timeZone29);
//        java.util.Locale locale34 = null;
//        try {
//            org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date12, timeZone29, locale34);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560668399999L + "'", long19 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
//        long long7 = week5.getMiddleMillisecond();
//        long long8 = week5.getFirstMillisecond();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week5.getMiddleMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, 8);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.String str4 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
        java.lang.String str7 = timePeriodFormatException6.toString();
        java.lang.String str8 = timePeriodFormatException6.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        java.lang.String str12 = timePeriodFormatException10.toString();
        java.lang.String str13 = timePeriodFormatException10.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str20 = timePeriodFormatException19.toString();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        java.lang.String str6 = week5.toString();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        long long4 = year3.getMiddleMillisecond();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(1, year3);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(2, year3);
        int int7 = week6.getYearValue();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        boolean boolean16 = week0.equals((java.lang.Object) week15);
//        java.lang.String str17 = week15.toString();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year19 = week18.getYear();
//        int int20 = week18.getWeek();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year23 = week22.getYear();
//        long long24 = year23.getMiddleMillisecond();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(1, year23);
//        boolean boolean26 = week18.equals((java.lang.Object) year23);
//        int int27 = week15.compareTo((java.lang.Object) boolean26);
//        java.lang.String str28 = week15.toString();
//        java.util.Date date29 = week15.getEnd();
//        long long30 = week15.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 24, 2019" + "'", str17.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1562097599999L + "'", long24 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Week 24, 2019" + "'", str28.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560668399999L + "'", long30 == 1560668399999L);
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        long long2 = year1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        boolean boolean3 = week0.equals((java.lang.Object) 'a');
//        java.lang.String str4 = week0.toString();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        int int3 = week1.getWeek();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        long long7 = year6.getMiddleMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(1, year6);
//        boolean boolean9 = week1.equals((java.lang.Object) year6);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (short) 10, year6);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1562097599999L + "'", long7 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getWeek();
//        java.lang.Class class3 = null;
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getStart();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date5, timeZone6);
//        java.lang.Class<?> wildcardClass8 = timeZone6.getClass();
//        boolean boolean9 = week0.equals((java.lang.Object) timeZone6);
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = week0.getFirstMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year7 = week6.getYear();
//        long long8 = week6.getFirstMillisecond();
//        java.util.Date date9 = week6.getEnd();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getStart();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date12, timeZone13);
//        java.lang.Class<?> wildcardClass15 = timeZone13.getClass();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date9, timeZone13);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year18 = week17.getYear();
//        long long19 = week17.getFirstMillisecond();
//        java.util.Date date20 = week17.getEnd();
//        java.lang.Class class21 = null;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        java.util.Date date23 = week22.getStart();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date23, timeZone24);
//        java.lang.Class<?> wildcardClass26 = timeZone24.getClass();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date20, timeZone24);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date20);
//        java.util.Date date29 = week28.getEnd();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year31 = week30.getYear();
//        long long32 = week30.getFirstMillisecond();
//        java.util.Date date33 = week30.getEnd();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year35 = week34.getYear();
//        java.lang.Class<?> wildcardClass36 = year35.getClass();
//        java.lang.Class class37 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass36);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year40 = week39.getYear();
//        long long41 = year40.getMiddleMillisecond();
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(1, year40);
//        java.util.Date date43 = year40.getEnd();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year45 = week44.getYear();
//        int int46 = week44.getWeek();
//        java.lang.Class class47 = null;
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        java.util.Date date49 = week48.getStart();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date49, timeZone50);
//        java.lang.Class<?> wildcardClass52 = timeZone50.getClass();
//        boolean boolean53 = week44.equals((java.lang.Object) timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date43, timeZone50);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date33, timeZone50);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date29, timeZone50);
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date9, timeZone50);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date4, timeZone50);
//        java.lang.Class<?> wildcardClass59 = date4.getClass();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560063600000L + "'", long19 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560063600000L + "'", long32 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(year35);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(class37);
//        org.junit.Assert.assertNotNull(year40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1562097599999L + "'", long41 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(year45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 24 + "'", int46 == 24);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(wildcardClass59);
//    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getWeek();
//        java.lang.Class class3 = null;
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getStart();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date5, timeZone6);
//        java.lang.Class<?> wildcardClass8 = timeZone6.getClass();
//        boolean boolean9 = week0.equals((java.lang.Object) timeZone6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week0.previous();
//        long long11 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560668399999L + "'", long11 == 1560668399999L);
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException1.getClass();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        long long4 = year3.getMiddleMillisecond();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(11, year3);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (byte) 0, year3);
        int int8 = week6.compareTo((java.lang.Object) 24);
        java.util.Date date9 = week6.getStart();
        org.jfree.data.time.Year year10 = week6.getYear();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = week6.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(year10);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        int int4 = week0.getWeek();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Date date6 = week2.getEnd();
        java.util.Date date7 = week2.getStart();
        org.jfree.data.time.Year year8 = week2.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(1, year8);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(0, year8);
        int int11 = week10.getYearValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(11, (int) (byte) -1);
        long long3 = week2.getSerialIndex();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        long long6 = week5.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-42L) + "'", long3 == (-42L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62097552000001L) + "'", long6 == (-62097552000001L));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
        java.util.Date date4 = week0.getEnd();
        java.util.Date date5 = week0.getStart();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = year5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(1, year5);
//        boolean boolean8 = week0.equals((java.lang.Object) year5);
//        java.lang.String str9 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week0.next();
//        java.util.Date date11 = regularTimePeriod10.getEnd();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        java.util.Date date14 = week13.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date14, timeZone15);
//        java.lang.Class<?> wildcardClass17 = timeZone15.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year20 = week19.getYear();
//        int int21 = week19.getYearValue();
//        java.util.Date date22 = week19.getStart();
//        java.lang.Class class23 = null;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        java.util.Date date25 = week24.getStart();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date25, timeZone26);
//        java.lang.Class<?> wildcardClass28 = timeZone26.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date22, timeZone26);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year31 = week30.getYear();
//        long long32 = week30.getFirstMillisecond();
//        java.util.Date date33 = week30.getEnd();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        java.util.Date date36 = week35.getStart();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date36, timeZone37);
//        java.lang.Class<?> wildcardClass39 = timeZone37.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date33, timeZone37);
//        java.lang.Class class41 = null;
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        java.util.Date date43 = week42.getStart();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date43, timeZone44);
//        java.lang.Class<?> wildcardClass46 = timeZone44.getClass();
//        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass46);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year49 = week48.getYear();
//        int int50 = week48.getYearValue();
//        java.util.Date date51 = week48.getStart();
//        java.lang.Class class52 = null;
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week();
//        java.util.Date date54 = week53.getStart();
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date54, timeZone55);
//        java.lang.Class<?> wildcardClass57 = timeZone55.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date51, timeZone55);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year60 = week59.getYear();
//        long long61 = week59.getFirstMillisecond();
//        java.util.Date date62 = week59.getEnd();
//        java.lang.Class class63 = null;
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week();
//        java.util.Date date65 = week64.getStart();
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance(class63, date65, timeZone66);
//        java.lang.Class<?> wildcardClass68 = timeZone66.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date62, timeZone66);
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(date33, timeZone66);
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date11, timeZone66);
//        java.lang.Object obj72 = null;
//        int int73 = week71.compareTo(obj72);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560063600000L + "'", long32 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertNotNull(class47);
//        org.junit.Assert.assertNotNull(year49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2019 + "'", int50 == 2019);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(wildcardClass57);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(year60);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560063600000L + "'", long61 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(wildcardClass68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        long long4 = week2.getMiddleMillisecond();
        long long5 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61782148800001L) + "'", long4 == (-61782148800001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 648L + "'", long5 == 648L);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 10, 3);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62066707200001L) + "'", long3 == (-62066707200001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62067009600001L) + "'", long4 == (-62067009600001L));
    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date3);
//        long long12 = week11.getSerialIndex();
//        org.jfree.data.time.Year year13 = week11.getYear();
//        long long14 = week11.getFirstMillisecond();
//        org.jfree.data.time.Year year15 = week11.getYear();
//        java.util.Date date16 = week11.getEnd();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560063600000L + "'", long14 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(date16);
//    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year12 = week11.getYear();
//        int int13 = week11.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week11.previous();
//        java.util.Date date15 = week11.getStart();
//        org.jfree.data.time.Year year16 = week11.getYear();
//        long long17 = week11.getLastMillisecond();
//        java.util.Date date18 = week11.getStart();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        java.util.Date date21 = week20.getStart();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date21, timeZone22);
//        java.lang.Class class24 = null;
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        java.util.Date date26 = week25.getStart();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date26, timeZone27);
//        java.lang.Class<?> wildcardClass29 = timeZone27.getClass();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date21, timeZone27);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date18, timeZone27);
//        java.util.Locale locale32 = null;
//        try {
//            org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date3, timeZone27, locale32);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560668399999L + "'", long17 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        java.lang.String str2 = week0.toString();
//        int int3 = week0.getWeek();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        int int5 = week0.getWeek();
//        long long6 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = year5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(1, year5);
//        boolean boolean8 = week0.equals((java.lang.Object) year5);
//        java.lang.String str9 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week0.next();
//        java.util.Date date11 = regularTimePeriod10.getEnd();
//        java.lang.Class<?> wildcardClass12 = regularTimePeriod10.getClass();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(9, (int) (short) 0);
        java.util.Calendar calendar3 = null;
        try {
            week2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        long long3 = year2.getMiddleMillisecond();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(11, year2);
        long long5 = week4.getSerialIndex();
        java.lang.String str6 = week4.toString();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107018L + "'", long5 == 107018L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 11, 2019" + "'", str6.equals("Week 11, 2019"));
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = year3.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date6);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date6);
//        java.lang.String str11 = week10.toString();
//        long long12 = week10.getMiddleMillisecond();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        int int15 = week13.getYearValue();
//        java.util.Date date16 = week13.getEnd();
//        int int17 = week10.compareTo((java.lang.Object) week13);
//        boolean boolean18 = week0.equals((java.lang.Object) week13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week13.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week13.next();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 24, 2019" + "'", str11.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560365999999L + "'", long12 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test379");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        boolean boolean16 = week0.equals((java.lang.Object) week15);
//        java.lang.String str17 = week15.toString();
//        int int18 = week15.getWeek();
//        java.lang.Class<?> wildcardClass19 = week15.getClass();
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 24, 2019" + "'", str17.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(class20);
//    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.util.Date date4 = week0.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        int int7 = week5.getYearValue();
//        java.util.Date date8 = week5.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date8);
//        java.lang.Class<?> wildcardClass11 = date8.getClass();
//        boolean boolean12 = week0.equals((java.lang.Object) date8);
//        java.lang.Class class13 = null;
//        java.util.Date date14 = null;
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year16 = week15.getYear();
//        int int17 = week15.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week15.previous();
//        java.util.Date date19 = week15.getStart();
//        org.jfree.data.time.Year year20 = week15.getYear();
//        long long21 = week15.getLastMillisecond();
//        java.util.Date date22 = week15.getStart();
//        java.lang.Class class23 = null;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        java.util.Date date25 = week24.getStart();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date25, timeZone26);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        java.util.Date date30 = week29.getStart();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date30, timeZone31);
//        java.lang.Class<?> wildcardClass33 = timeZone31.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date25, timeZone31);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date22, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date14, timeZone31);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date8, timeZone31);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560668399999L + "'", long21 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 429L + "'", long4 == 429L);
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        int int3 = week0.getYearValue();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        long long16 = week15.getSerialIndex();
//        boolean boolean17 = week0.equals((java.lang.Object) week15);
//        org.jfree.data.time.Year year18 = week15.getYear();
//        long long19 = week15.getSerialIndex();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 107031L + "'", long19 == 107031L);
//    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        int int7 = week5.getWeek();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year10 = week9.getYear();
//        long long11 = year10.getMiddleMillisecond();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(1, year10);
//        boolean boolean13 = week5.equals((java.lang.Object) year10);
//        java.lang.String str14 = week5.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week5.next();
//        java.util.Date date16 = regularTimePeriod15.getEnd();
//        int int17 = week0.compareTo((java.lang.Object) date16);
//        int int18 = week0.getWeek();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date3);
//        long long12 = week11.getSerialIndex();
//        org.jfree.data.time.Year year13 = week11.getYear();
//        long long14 = week11.getFirstMillisecond();
//        org.jfree.data.time.Year year15 = week11.getYear();
//        long long16 = week11.getLastMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560063600000L + "'", long14 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560668399999L + "'", long16 == 1560668399999L);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        int int2 = week0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        java.util.Date date4 = week0.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week5.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        long long7 = week4.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week4.previous();
//        boolean boolean9 = week0.equals((java.lang.Object) week4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week0.previous();
//        int int11 = week0.getWeek();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
//        java.lang.Class<?> wildcardClass6 = date3.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date3);
//        java.util.Date date8 = week7.getStart();
//        long long9 = week7.getLastMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560668399999L + "'", long9 == 1560668399999L);
//    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year4 = week3.getYear();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(1, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((-1), year4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) 0, year4);
//        java.lang.Class<?> wildcardClass9 = week8.getClass();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getStart();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date12, timeZone13);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year16 = week15.getYear();
//        java.lang.Class<?> wildcardClass17 = year16.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year21 = week20.getYear();
//        long long22 = year21.getMiddleMillisecond();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(1, year21);
//        java.util.Date date24 = year21.getEnd();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year26 = week25.getYear();
//        int int27 = week25.getWeek();
//        java.lang.Class class28 = null;
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        java.util.Date date30 = week29.getStart();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date30, timeZone31);
//        java.lang.Class<?> wildcardClass33 = timeZone31.getClass();
//        boolean boolean34 = week25.equals((java.lang.Object) timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date24, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date12, timeZone31);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year38 = week37.getYear();
//        int int39 = week37.getYearValue();
//        java.util.Date date40 = week37.getStart();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date40);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date40);
//        java.lang.Class<?> wildcardClass43 = date40.getClass();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year45 = week44.getYear();
//        int int46 = week44.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week44.previous();
//        java.util.Date date48 = week44.getStart();
//        org.jfree.data.time.Year year49 = week44.getYear();
//        long long50 = week44.getLastMillisecond();
//        java.util.Date date51 = week44.getStart();
//        java.lang.Class class52 = null;
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week();
//        java.util.Date date54 = week53.getStart();
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date54, timeZone55);
//        java.lang.Class class57 = null;
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week();
//        java.util.Date date59 = week58.getStart();
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date59, timeZone60);
//        java.lang.Class<?> wildcardClass62 = timeZone60.getClass();
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date54, timeZone60);
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date51, timeZone60);
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year66 = week65.getYear();
//        java.lang.Class<?> wildcardClass67 = year66.getClass();
//        java.lang.Class class68 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass67);
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year71 = week70.getYear();
//        long long72 = year71.getMiddleMillisecond();
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(1, year71);
//        java.util.Date date74 = year71.getEnd();
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year76 = week75.getYear();
//        int int77 = week75.getWeek();
//        java.lang.Class class78 = null;
//        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week();
//        java.util.Date date80 = week79.getStart();
//        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance(class78, date80, timeZone81);
//        java.lang.Class<?> wildcardClass83 = timeZone81.getClass();
//        boolean boolean84 = week75.equals((java.lang.Object) timeZone81);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass67, date74, timeZone81);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date51, timeZone81);
//        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date12, timeZone81);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1562097599999L + "'", long22 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 24 + "'", int27 == 24);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(year45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(year49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560668399999L + "'", long50 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(wildcardClass62);
//        org.junit.Assert.assertNotNull(year66);
//        org.junit.Assert.assertNotNull(wildcardClass67);
//        org.junit.Assert.assertNotNull(class68);
//        org.junit.Assert.assertNotNull(year71);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1562097599999L + "'", long72 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(year76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 24 + "'", int77 == 24);
//        org.junit.Assert.assertNotNull(date80);
//        org.junit.Assert.assertNotNull(timeZone81);
//        org.junit.Assert.assertNull(regularTimePeriod82);
//        org.junit.Assert.assertNotNull(wildcardClass83);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod85);
//        org.junit.Assert.assertNull(regularTimePeriod86);
//    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test389");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date2);
//        java.lang.String str7 = week6.toString();
//        long long8 = week6.getMiddleMillisecond();
//        org.jfree.data.time.Year year9 = week6.getYear();
//        java.lang.String str10 = week6.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week6.next();
//        java.lang.Class<?> wildcardClass12 = regularTimePeriod11.getClass();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        java.lang.String str2 = week0.toString();
//        int int3 = week0.getWeek();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        long long5 = week0.getSerialIndex();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        java.lang.String str7 = timePeriodFormatException5.toString();
        java.lang.String str8 = timePeriodFormatException5.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str15 = timePeriodFormatException14.toString();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException19.getSuppressed();
        java.lang.String str21 = timePeriodFormatException19.toString();
        java.lang.String str22 = timePeriodFormatException19.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException24.getSuppressed();
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str29 = timePeriodFormatException28.toString();
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException28.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        java.lang.Class<?> wildcardClass33 = timePeriodFormatException28.getClass();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year35 = week34.getYear();
        int int36 = week34.getYearValue();
        java.util.Date date37 = week34.getStart();
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date37);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date37);
        java.lang.Class<?> wildcardClass40 = date37.getClass();
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date37);
        java.util.TimeZone timeZone42 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date37, timeZone42);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str29.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(year35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNull(regularTimePeriod43);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 10);
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        boolean boolean16 = week0.equals((java.lang.Object) week15);
//        java.lang.String str17 = week15.toString();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        java.util.Date date20 = week19.getStart();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.next();
//        long long25 = week23.getMiddleMillisecond();
//        java.util.Date date26 = week23.getStart();
//        long long27 = week23.getLastMillisecond();
//        int int28 = week15.compareTo((java.lang.Object) week23);
//        long long29 = week23.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 24, 2019" + "'", str17.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560365999999L + "'", long25 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560668399999L + "'", long27 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560063600000L + "'", long29 == 1560063600000L);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        java.lang.String str5 = timePeriodFormatException3.toString();
        java.lang.String str6 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException3.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray11);
    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.Year year12 = week11.getYear();
//        long long13 = week11.getSerialIndex();
//        long long14 = week11.getLastMillisecond();
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = week11.getLastMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 107031L + "'", long13 == 107031L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560668399999L + "'", long14 == 1560668399999L);
//    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date2);
//        java.lang.String str7 = week6.toString();
//        long long8 = week6.getMiddleMillisecond();
//        org.jfree.data.time.Year year9 = week6.getYear();
//        int int10 = week6.getYearValue();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = week6.getLastMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        java.lang.Class<?> wildcardClass4 = year3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        long long9 = year8.getMiddleMillisecond();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(1, year8);
//        java.util.Date date11 = year8.getEnd();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year13 = week12.getYear();
//        int int14 = week12.getWeek();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        java.util.Date date17 = week16.getStart();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date17, timeZone18);
//        java.lang.Class<?> wildcardClass20 = timeZone18.getClass();
//        boolean boolean21 = week12.equals((java.lang.Object) timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date11, timeZone18);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Year year25 = week24.getYear();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) (short) 100, year25);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(0, year25);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1562097599999L + "'", long9 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year25);
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 10, (int) (byte) 1);
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        int int3 = week0.getYearValue();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        long long16 = week15.getSerialIndex();
//        boolean boolean17 = week0.equals((java.lang.Object) week15);
//        org.jfree.data.time.Year year18 = week15.getYear();
//        int int19 = week15.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week15.next();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass3 = timePeriodFormatException1.getClass();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.lang.Class<?> wildcardClass2 = year1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        long long7 = year6.getMiddleMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(1, year6);
//        java.util.Date date9 = year6.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year11 = week10.getYear();
//        int int12 = week10.getWeek();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getStart();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone16);
//        java.lang.Class<?> wildcardClass18 = timeZone16.getClass();
//        boolean boolean19 = week10.equals((java.lang.Object) timeZone16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone16);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date9);
//        long long22 = week21.getFirstMillisecond();
//        java.util.Calendar calendar23 = null;
//        try {
//            long long24 = week21.getFirstMillisecond(calendar23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1562097599999L + "'", long7 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577606400000L + "'", long22 == 1577606400000L);
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 1, 2020");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        long long5 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        java.lang.String str2 = week0.toString();
//        int int3 = week0.getYearValue();
//        int int4 = week0.getWeek();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.lang.Class<?> wildcardClass2 = year1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        long long7 = year6.getMiddleMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(1, year6);
//        java.util.Date date9 = year6.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year11 = week10.getYear();
//        int int12 = week10.getWeek();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getStart();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone16);
//        java.lang.Class<?> wildcardClass18 = timeZone16.getClass();
//        boolean boolean19 = week10.equals((java.lang.Object) timeZone16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone16);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Year year23 = week22.getYear();
//        int int24 = week22.getYearValue();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1562097599999L + "'", long7 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2020 + "'", int24 == 2020);
//    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week1.next();
        java.util.Date date5 = week1.getEnd();
        java.util.Date date6 = week1.getStart();
        org.jfree.data.time.Year year7 = week1.getYear();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(53, year7);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(year7);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.String str5 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week -1, 2019");
        java.lang.Class<?> wildcardClass13 = timePeriodFormatException12.getClass();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Class<?> wildcardClass15 = timePeriodFormatException12.getClass();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date2);
//        java.lang.String str7 = week6.toString();
//        long long8 = week6.getMiddleMillisecond();
//        org.jfree.data.time.Year year9 = week6.getYear();
//        java.lang.String str10 = week6.toString();
//        int int11 = week6.getYearValue();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        int int3 = week0.getYearValue();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        long long16 = week15.getSerialIndex();
//        boolean boolean17 = week0.equals((java.lang.Object) week15);
//        java.util.Date date18 = week0.getStart();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(date18);
//    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        java.lang.String str2 = week0.toString();
//        int int3 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, (int) (short) -1);
//        int int7 = week0.compareTo((java.lang.Object) (short) -1);
//        java.lang.Class<?> wildcardClass8 = week0.getClass();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year10 = week9.getYear();
//        int int11 = week9.getYearValue();
//        java.util.Date date12 = week9.getStart();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
//        int int14 = week0.compareTo((java.lang.Object) date12);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        int int2 = week0.getYearValue();
        java.util.Date date3 = week0.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
        java.lang.Class<?> wildcardClass6 = date3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 2020");
        boolean boolean10 = week7.equals((java.lang.Object) "Week 1, 2020");
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.lang.Class<?> wildcardClass2 = year1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        long long7 = year6.getMiddleMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(1, year6);
//        java.util.Date date9 = year6.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year11 = week10.getYear();
//        int int12 = week10.getWeek();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getStart();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone16);
//        java.lang.Class<?> wildcardClass18 = timeZone16.getClass();
//        boolean boolean19 = week10.equals((java.lang.Object) timeZone16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone16);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year22 = week21.getYear();
//        java.lang.Class<?> wildcardClass23 = year22.getClass();
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year27 = week26.getYear();
//        long long28 = year27.getMiddleMillisecond();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(1, year27);
//        java.util.Date date30 = year27.getEnd();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year32 = week31.getYear();
//        int int33 = week31.getWeek();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        java.util.Date date36 = week35.getStart();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date36, timeZone37);
//        java.lang.Class<?> wildcardClass39 = timeZone37.getClass();
//        boolean boolean40 = week31.equals((java.lang.Object) timeZone37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date30, timeZone37);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date9, timeZone37);
//        org.jfree.data.time.Year year43 = week42.getYear();
//        long long44 = week42.getSerialIndex();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1562097599999L + "'", long7 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertNotNull(year27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1562097599999L + "'", long28 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 24 + "'", int33 == 24);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(year43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 107061L + "'", long44 == 107061L);
//    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date2);
//        long long7 = week6.getFirstMillisecond();
//        long long8 = week6.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 11);
//        java.util.Date date3 = week2.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        int int6 = week4.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.previous();
//        java.util.Date date8 = week4.getStart();
//        org.jfree.data.time.Year year9 = week4.getYear();
//        long long10 = week4.getLastMillisecond();
//        int int11 = week2.compareTo((java.lang.Object) long10);
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = week2.getFirstMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560668399999L + "'", long10 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test419");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        int int3 = week0.getYearValue();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        long long16 = week15.getSerialIndex();
//        boolean boolean17 = week0.equals((java.lang.Object) week15);
//        long long18 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year21 = week20.getYear();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(11, year21);
//        int int23 = week0.compareTo((java.lang.Object) year21);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560668399999L + "'", long18 == 1560668399999L);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        long long12 = week10.getLastMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560668399999L + "'", long12 == 1560668399999L);
//    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        long long6 = week0.getLastMillisecond();
//        java.util.Date date7 = week0.getStart();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getStart();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone16);
//        java.lang.Class<?> wildcardClass18 = timeZone16.getClass();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date10, timeZone16);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date7, timeZone16);
//        java.lang.Class class21 = null;
//        java.util.Date date22 = null;
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year24 = week23.getYear();
//        java.lang.Class<?> wildcardClass25 = year24.getClass();
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year28 = week27.getYear();
//        int int29 = week27.getWeek();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year32 = week31.getYear();
//        long long33 = year32.getMiddleMillisecond();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(1, year32);
//        boolean boolean35 = week27.equals((java.lang.Object) year32);
//        java.lang.String str36 = week27.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = week27.next();
//        java.util.Date date38 = regularTimePeriod37.getEnd();
//        java.lang.Class class39 = null;
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        java.util.Date date41 = week40.getStart();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date41, timeZone42);
//        java.lang.Class<?> wildcardClass44 = timeZone42.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date38, timeZone42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone42);
//        java.util.Locale locale47 = null;
//        try {
//            org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date7, timeZone42, locale47);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 24 + "'", int29 == 24);
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1562097599999L + "'", long33 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Week 24, 2019" + "'", str36.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, 0);
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        java.util.Date date3 = week0.getStart();
//        int int4 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        java.util.Date date6 = week0.getStart();
//        java.util.Date date7 = week0.getStart();
//        long long8 = week0.getSerialIndex();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        java.lang.String str7 = timePeriodFormatException5.toString();
        java.lang.String str8 = timePeriodFormatException5.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str15 = timePeriodFormatException14.toString();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException19.getSuppressed();
        java.lang.String str21 = timePeriodFormatException19.toString();
        java.lang.String str22 = timePeriodFormatException19.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException24.getSuppressed();
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str29 = timePeriodFormatException28.toString();
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException28.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        java.lang.String str33 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str29.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str33.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
//        java.lang.Class<?> wildcardClass6 = date3.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date3);
//        java.util.Date date8 = week7.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year11 = week10.getYear();
//        long long12 = week10.getFirstMillisecond();
//        java.util.Date date13 = week10.getEnd();
//        java.lang.Class class14 = null;
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        java.util.Date date16 = week15.getStart();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date16, timeZone17);
//        java.lang.Class<?> wildcardClass19 = timeZone17.getClass();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date13, timeZone17);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date8, timeZone17);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560063600000L + "'", long12 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        java.lang.Class<?> wildcardClass5 = timeZone3.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        int int9 = week7.getYearValue();
//        java.util.Date date10 = week7.getStart();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        java.util.Date date13 = week12.getStart();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
//        java.lang.Class<?> wildcardClass16 = timeZone14.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date10, timeZone14);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year19 = week18.getYear();
//        long long20 = week18.getFirstMillisecond();
//        java.util.Date date21 = week18.getEnd();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        java.util.Date date24 = week23.getStart();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date24, timeZone25);
//        java.lang.Class<?> wildcardClass27 = timeZone25.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date21, timeZone25);
//        java.lang.Class class29 = null;
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        java.util.Date date31 = week30.getStart();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date31, timeZone32);
//        java.lang.Class<?> wildcardClass34 = timeZone32.getClass();
//        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year37 = week36.getYear();
//        int int38 = week36.getYearValue();
//        java.util.Date date39 = week36.getStart();
//        java.lang.Class class40 = null;
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        java.util.Date date42 = week41.getStart();
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date42, timeZone43);
//        java.lang.Class<?> wildcardClass45 = timeZone43.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date39, timeZone43);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year48 = week47.getYear();
//        long long49 = week47.getFirstMillisecond();
//        java.util.Date date50 = week47.getEnd();
//        java.lang.Class class51 = null;
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week();
//        java.util.Date date53 = week52.getStart();
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date53, timeZone54);
//        java.lang.Class<?> wildcardClass56 = timeZone54.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date50, timeZone54);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date21, timeZone54);
//        java.lang.String str59 = week58.toString();
//        long long60 = week58.getSerialIndex();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560063600000L + "'", long20 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(year48);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560063600000L + "'", long49 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Week 24, 2019" + "'", str59.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 107031L + "'", long60 == 107031L);
//    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = year5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(1, year5);
//        boolean boolean8 = week0.equals((java.lang.Object) year5);
//        long long9 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week0.previous();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = regularTimePeriod10.getMiddleMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        long long3 = year2.getMiddleMillisecond();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(11, year2);
        java.util.Date date5 = year2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week6.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = year5.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(1, year5);
//        boolean boolean8 = week0.equals((java.lang.Object) year5);
//        java.lang.String str9 = week0.toString();
//        long long10 = week0.getSerialIndex();
//        java.lang.String str11 = week0.toString();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 24, 2019" + "'", str11.equals("Week 24, 2019"));
//    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, 2);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Calendar calendar1 = null;
        try {
            week0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, 24);
        java.lang.String str3 = week2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 0, 24" + "'", str3.equals("Week 0, 24"));
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Date date3 = week0.getEnd();
//        java.util.Date date4 = week0.getStart();
//        long long5 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        long long5 = year4.getMiddleMillisecond();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(11, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 0, year4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', year4);
        java.lang.Class<?> wildcardClass9 = week8.getClass();
        java.util.Date date10 = week8.getStart();
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        long long4 = week2.getMiddleMillisecond();
        int int5 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61782148800001L) + "'", long4 == (-61782148800001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 0, 2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        int int4 = week2.getYearValue();
        java.util.Date date5 = week2.getStart();
        int int6 = week2.getYearValue();
        org.jfree.data.time.Year year7 = week2.getYear();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '4', year7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(7, year7);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(year7);
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        java.lang.String str2 = week0.toString();
//        int int3 = week0.getWeek();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Year year6 = week0.getYear();
//        org.jfree.data.time.Year year7 = week0.getYear();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(year7);
//    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        boolean boolean16 = week0.equals((java.lang.Object) week15);
//        java.lang.String str17 = week15.toString();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year19 = week18.getYear();
//        int int20 = week18.getWeek();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year23 = week22.getYear();
//        long long24 = year23.getMiddleMillisecond();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(1, year23);
//        boolean boolean26 = week18.equals((java.lang.Object) year23);
//        int int27 = week15.compareTo((java.lang.Object) boolean26);
//        long long28 = week15.getLastMillisecond();
//        java.lang.Class<?> wildcardClass29 = week15.getClass();
//        int int30 = week15.getWeek();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 24, 2019" + "'", str17.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1562097599999L + "'", long24 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560668399999L + "'", long28 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 24 + "'", int30 == 24);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (byte) 100);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        java.util.Date date4 = week0.getStart();
        java.lang.Class class5 = null;
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        java.util.Date date7 = week6.getStart();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date7, timeZone8);
        java.lang.Class<?> wildcardClass10 = timeZone8.getClass();
        java.util.Locale locale11 = null;
        try {
            org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date4, timeZone8, locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        java.lang.String str5 = week4.toString();
//        java.lang.String str6 = week4.toString();
//        java.lang.Object obj7 = null;
//        int int8 = week4.compareTo(obj7);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        java.lang.Class<?> wildcardClass5 = timeZone3.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize(class7);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(class8);
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        java.lang.String str2 = week0.toString();
//        int int3 = week0.getWeek();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year9 = week8.getYear();
//        long long10 = year9.getMiddleMillisecond();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(1, year9);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(2, year9);
//        int int13 = week0.compareTo((java.lang.Object) year9);
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = week0.getMiddleMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test446");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        java.lang.Class class5 = null;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getStart();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date7, timeZone8);
//        java.lang.Class<?> wildcardClass10 = timeZone8.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date2, timeZone8);
//        java.lang.Class class12 = null;
//        java.util.Date date13 = null;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year15 = week14.getYear();
//        java.lang.Class<?> wildcardClass16 = year15.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year19 = week18.getYear();
//        int int20 = week18.getWeek();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year23 = week22.getYear();
//        long long24 = year23.getMiddleMillisecond();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(1, year23);
//        boolean boolean26 = week18.equals((java.lang.Object) year23);
//        java.lang.String str27 = week18.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week18.next();
//        java.util.Date date29 = regularTimePeriod28.getEnd();
//        java.lang.Class class30 = null;
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        java.util.Date date32 = week31.getStart();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date32, timeZone33);
//        java.lang.Class<?> wildcardClass35 = timeZone33.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date29, timeZone33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone33);
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date2, timeZone33);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1562097599999L + "'", long24 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Week 24, 2019" + "'", str27.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        long long4 = year3.getMiddleMillisecond();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(1, year3);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year3);
        int int7 = week6.getYearValue();
        long long8 = week6.getSerialIndex();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107007L + "'", long8 == 107007L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 0, 2019");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 0, 2019" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: Week 0, 2019"));
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        java.lang.String str2 = week0.toString();
//        int int3 = week0.getWeek();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        java.util.Date date5 = week0.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
//        int int10 = week0.compareTo((java.lang.Object) week6);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        long long6 = week0.getLastMillisecond();
//        java.util.Date date7 = week0.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        long long5 = year4.getMiddleMillisecond();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(11, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 0, year4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', year4);
        long long9 = week8.getLastMillisecond();
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1567321199999L + "'", long9 == 1567321199999L);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.lang.Class<?> wildcardClass2 = year1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getStart();
//        java.lang.String str6 = week4.toString();
//        int int7 = week4.getWeek();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(9, (int) (short) -1);
//        int int11 = week4.compareTo((java.lang.Object) (short) -1);
//        java.lang.Class<?> wildcardClass12 = week4.getClass();
//        int int13 = week4.getYearValue();
//        java.util.Date date14 = week4.getEnd();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year16 = week15.getYear();
//        java.lang.Class<?> wildcardClass17 = year16.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year21 = week20.getYear();
//        long long22 = year21.getMiddleMillisecond();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(1, year21);
//        java.util.Date date24 = year21.getEnd();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year26 = week25.getYear();
//        int int27 = week25.getWeek();
//        java.lang.Class class28 = null;
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        java.util.Date date30 = week29.getStart();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date30, timeZone31);
//        java.lang.Class<?> wildcardClass33 = timeZone31.getClass();
//        boolean boolean34 = week25.equals((java.lang.Object) timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date24, timeZone31);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year37 = week36.getYear();
//        java.lang.Class<?> wildcardClass38 = year37.getClass();
//        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year42 = week41.getYear();
//        long long43 = year42.getMiddleMillisecond();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(1, year42);
//        java.util.Date date45 = year42.getEnd();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year47 = week46.getYear();
//        int int48 = week46.getWeek();
//        java.lang.Class class49 = null;
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week();
//        java.util.Date date51 = week50.getStart();
//        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date51, timeZone52);
//        java.lang.Class<?> wildcardClass54 = timeZone52.getClass();
//        boolean boolean55 = week46.equals((java.lang.Object) timeZone52);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date45, timeZone52);
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date24, timeZone52);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date14, timeZone52);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1562097599999L + "'", long22 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 24 + "'", int27 == 24);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNotNull(class39);
//        org.junit.Assert.assertNotNull(year42);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1562097599999L + "'", long43 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(year47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 24 + "'", int48 == 24);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(timeZone52);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test453");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        int int3 = week0.getWeek();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, (int) (short) 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: Week 0, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test456");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getFirstMillisecond();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7);
//        boolean boolean16 = week0.equals((java.lang.Object) week15);
//        java.lang.String str17 = week15.toString();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year19 = week18.getYear();
//        int int20 = week18.getWeek();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year23 = week22.getYear();
//        long long24 = year23.getMiddleMillisecond();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(1, year23);
//        boolean boolean26 = week18.equals((java.lang.Object) year23);
//        int int27 = week15.compareTo((java.lang.Object) boolean26);
//        long long28 = week15.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week15.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 24, 2019" + "'", str17.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1562097599999L + "'", long24 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560668399999L + "'", long28 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
//        java.lang.Class<?> wildcardClass6 = date3.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date3);
//        int int8 = week7.getYearValue();
//        long long9 = week7.getSerialIndex();
//        int int11 = week7.compareTo((java.lang.Object) 100);
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = week7.getMiddleMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.lang.Class<?> wildcardClass2 = year1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        long long7 = year6.getMiddleMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(1, year6);
//        java.util.Date date9 = year6.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year11 = week10.getYear();
//        int int12 = week10.getWeek();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getStart();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone16);
//        java.lang.Class<?> wildcardClass18 = timeZone16.getClass();
//        boolean boolean19 = week10.equals((java.lang.Object) timeZone16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone16);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date9);
//        int int23 = week22.getYearValue();
//        java.util.Calendar calendar24 = null;
//        try {
//            long long25 = week22.getLastMillisecond(calendar24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1562097599999L + "'", long7 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2020 + "'", int23 == 2020);
//    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
        java.util.Date date4 = week0.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year7 = week6.getYear();
//        long long8 = week6.getFirstMillisecond();
//        java.util.Date date9 = week6.getEnd();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getStart();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date12, timeZone13);
//        java.lang.Class<?> wildcardClass15 = timeZone13.getClass();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date9, timeZone13);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year18 = week17.getYear();
//        long long19 = week17.getFirstMillisecond();
//        java.util.Date date20 = week17.getEnd();
//        java.lang.Class class21 = null;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        java.util.Date date23 = week22.getStart();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date23, timeZone24);
//        java.lang.Class<?> wildcardClass26 = timeZone24.getClass();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date20, timeZone24);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date20);
//        java.util.Date date29 = week28.getEnd();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year31 = week30.getYear();
//        long long32 = week30.getFirstMillisecond();
//        java.util.Date date33 = week30.getEnd();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year35 = week34.getYear();
//        java.lang.Class<?> wildcardClass36 = year35.getClass();
//        java.lang.Class class37 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass36);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year40 = week39.getYear();
//        long long41 = year40.getMiddleMillisecond();
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(1, year40);
//        java.util.Date date43 = year40.getEnd();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year45 = week44.getYear();
//        int int46 = week44.getWeek();
//        java.lang.Class class47 = null;
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        java.util.Date date49 = week48.getStart();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date49, timeZone50);
//        java.lang.Class<?> wildcardClass52 = timeZone50.getClass();
//        boolean boolean53 = week44.equals((java.lang.Object) timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date43, timeZone50);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date33, timeZone50);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date29, timeZone50);
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date9, timeZone50);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date4, timeZone50);
//        java.util.Calendar calendar59 = null;
//        try {
//            long long60 = week58.getLastMillisecond(calendar59);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560063600000L + "'", long19 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560063600000L + "'", long32 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(year35);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(class37);
//        org.junit.Assert.assertNotNull(year40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1562097599999L + "'", long41 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(year45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 24 + "'", int46 == 24);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        long long6 = week0.getLastMillisecond();
//        java.util.Date date7 = week0.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year9 = week8.getYear();
//        long long10 = week8.getFirstMillisecond();
//        java.util.Date date11 = week8.getEnd();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        java.util.Date date14 = week13.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date14, timeZone15);
//        java.lang.Class<?> wildcardClass17 = timeZone15.getClass();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date11, timeZone15);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year20 = week19.getYear();
//        long long21 = week19.getFirstMillisecond();
//        java.util.Date date22 = week19.getEnd();
//        java.lang.Class class23 = null;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        java.util.Date date25 = week24.getStart();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date25, timeZone26);
//        java.lang.Class<?> wildcardClass28 = timeZone26.getClass();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date22, timeZone26);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date22);
//        java.util.Date date31 = week30.getEnd();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year33 = week32.getYear();
//        long long34 = week32.getFirstMillisecond();
//        java.util.Date date35 = week32.getEnd();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year37 = week36.getYear();
//        java.lang.Class<?> wildcardClass38 = year37.getClass();
//        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year42 = week41.getYear();
//        long long43 = year42.getMiddleMillisecond();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(1, year42);
//        java.util.Date date45 = year42.getEnd();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year47 = week46.getYear();
//        int int48 = week46.getWeek();
//        java.lang.Class class49 = null;
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week();
//        java.util.Date date51 = week50.getStart();
//        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date51, timeZone52);
//        java.lang.Class<?> wildcardClass54 = timeZone52.getClass();
//        boolean boolean55 = week46.equals((java.lang.Object) timeZone52);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date45, timeZone52);
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date35, timeZone52);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date31, timeZone52);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date11, timeZone52);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date7, timeZone52);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560063600000L + "'", long21 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(year33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560063600000L + "'", long34 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNotNull(class39);
//        org.junit.Assert.assertNotNull(year42);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1562097599999L + "'", long43 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(year47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 24 + "'", int48 == 24);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(timeZone52);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//    }
//}

