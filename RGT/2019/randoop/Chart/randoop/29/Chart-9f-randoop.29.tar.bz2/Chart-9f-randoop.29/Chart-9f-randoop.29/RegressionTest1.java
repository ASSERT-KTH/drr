import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class3);
        boolean boolean6 = timeSeries4.equals((java.lang.Object) 10.0f);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class10);
        boolean boolean12 = timeSeries11.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        long long15 = fixedMillisecond14.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 100.0f);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries4.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries4.getDataItem(0);
        timeSeries4.setRangeDescription("June 2019");
        boolean boolean23 = timeSeries4.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class3);
        boolean boolean6 = timeSeries4.equals((java.lang.Object) 10.0f);
        timeSeries4.setDomainDescription("6-January-1900");
        timeSeries4.clear();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
        int int13 = day11.getMonth();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class17);
        boolean boolean19 = timeSeries18.isEmpty();
        boolean boolean20 = day11.equals((java.lang.Object) timeSeries18);
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class24);
        boolean boolean26 = timeSeries25.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.addAndOrUpdate(timeSeries25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date30 = fixedMillisecond29.getEnd();
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(serialDate31);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addMonths(8, serialDate31);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(serialDate31);
        try {
            timeSeries25.add((org.jfree.data.time.RegularTimePeriod) day34, (java.lang.Number) 1L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate33);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999, 2, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(4, 8, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        int int21 = day20.getMonth();
        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        boolean boolean29 = spreadsheetDate16.isOnOrBefore(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean32 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date36 = fixedMillisecond35.getEnd();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addMonths(8, serialDate37);
        org.jfree.data.time.SerialDate serialDate41 = serialDate37.getFollowingDayOfWeek(1);
        java.lang.String str42 = serialDate41.getDescription();
        boolean boolean43 = spreadsheetDate1.isAfter(serialDate41);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("6-January-1900");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("Mon Jun 10 11:59:06 PDT 2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str5 = seriesException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("6-January-1900");
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("Mon Jun 10 11:59:06 PDT 2019");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException9);
        seriesException3.addSuppressed((java.lang.Throwable) seriesException9);
        java.lang.String str12 = seriesException3.toString();
        java.lang.String str13 = seriesException3.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: Mon Jun 10 11:59:06 PDT 2019" + "'", str5.equals("org.jfree.data.general.SeriesException: Mon Jun 10 11:59:06 PDT 2019"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesException: Mon Jun 10 11:59:06 PDT 2019" + "'", str12.equals("org.jfree.data.general.SeriesException: Mon Jun 10 11:59:06 PDT 2019"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.general.SeriesException: Mon Jun 10 11:59:06 PDT 2019" + "'", str13.equals("org.jfree.data.general.SeriesException: Mon Jun 10 11:59:06 PDT 2019"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date1, timeZone6);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date1);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar16 = null;
        fixedMillisecond15.peg(calendar16);
        java.lang.Number number18 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Date date19 = fixedMillisecond15.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date23 = fixedMillisecond22.getEnd();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23, timeZone25);
        java.lang.Class<?> wildcardClass27 = timeZone25.getClass();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date19, timeZone25);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date1, timeZone25);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond0.getFirstMillisecond(calendar7);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193222485L + "'", long3 == 1560193222485L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560193222485L + "'", long4 == 1560193222485L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560193222485L + "'", long8 == 1560193222485L);
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        int int21 = day20.getMonth();
        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        boolean boolean29 = spreadsheetDate16.isOnOrBefore(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean32 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.lang.Object obj34 = null;
        boolean boolean35 = spreadsheetDate16.equals(obj34);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int37 = spreadsheetDate16.toSerial();
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar44 = null;
        fixedMillisecond43.peg(calendar44);
        java.lang.Number number46 = timeSeries42.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
        timeSeries42.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries42.createCopy((int) (short) 1, 8);
        java.lang.Class class55 = null;
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class55);
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar58 = null;
        fixedMillisecond57.peg(calendar58);
        java.lang.Number number60 = timeSeries56.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57);
        timeSeries56.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries56.createCopy((int) (short) 1, 8);
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries42.addAndOrUpdate(timeSeries56);
        timeSeries66.setDescription("ERROR : Relative To String");
        boolean boolean69 = timeSeries66.isEmpty();
        java.lang.Object obj70 = timeSeries66.clone();
        try {
            int int71 = spreadsheetDate16.compareTo(obj70);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 7 + "'", int37 == 7);
        org.junit.Assert.assertNull(number46);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertNull(number60);
        org.junit.Assert.assertNotNull(timeSeries65);
        org.junit.Assert.assertNotNull(timeSeries66);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(obj70);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        int int11 = day10.getMonth();
        boolean boolean12 = spreadsheetDate6.equals((java.lang.Object) day10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date14 = fixedMillisecond13.getEnd();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        serialDate15.setDescription("ERROR : Relative To String");
        java.lang.String str18 = serialDate15.getDescription();
        boolean boolean19 = spreadsheetDate6.isOnOrBefore(serialDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean22 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date31 = fixedMillisecond30.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(serialDate32);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addMonths(8, serialDate32);
        org.jfree.data.time.SerialDate serialDate36 = serialDate32.getFollowingDayOfWeek(1);
        boolean boolean37 = spreadsheetDate21.isInRange(serialDate25, serialDate32);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addMonths(6, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean39 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate40 = null;
        try {
            boolean boolean41 = spreadsheetDate21.isOnOrAfter(serialDate40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ERROR : Relative To String" + "'", str18.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        java.lang.Object obj14 = timeSeries4.clone();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries4.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(obj14);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        long long5 = timeSeries4.getMaximumItemAge();
//        timeSeries4.clear();
//        timeSeries4.setMaximumItemCount((int) (short) 10);
//        java.lang.Class class9 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries4.removeChangeListener(seriesChangeListener10);
//        int int12 = timeSeries4.getMaximumItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        fixedMillisecond13.peg(calendar14);
//        long long16 = fixedMillisecond13.getMiddleMillisecond();
//        long long17 = fixedMillisecond13.getMiddleMillisecond();
//        java.lang.String[] strArray18 = org.jfree.data.time.SerialDate.getMonths();
//        int int19 = fixedMillisecond13.compareTo((java.lang.Object) strArray18);
//        java.lang.Number number20 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertNull(class9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560193222546L + "'", long16 == 1560193222546L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560193222546L + "'", long17 == 1560193222546L);
//        org.junit.Assert.assertNotNull(strArray18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNull(number20);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.String str11 = timeSeries4.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date15 = fixedMillisecond14.getEnd();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
        int int18 = day17.getMonth();
        boolean boolean19 = spreadsheetDate13.equals((java.lang.Object) day17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date21 = fixedMillisecond20.getEnd();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
        serialDate22.setDescription("ERROR : Relative To String");
        java.lang.String str25 = serialDate22.getDescription();
        boolean boolean26 = spreadsheetDate13.isOnOrBefore(serialDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date30 = fixedMillisecond29.getEnd();
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(serialDate31);
        int int33 = day32.getMonth();
        boolean boolean34 = spreadsheetDate28.equals((java.lang.Object) day32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date36 = fixedMillisecond35.getEnd();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
        serialDate37.setDescription("ERROR : Relative To String");
        java.lang.String str40 = serialDate37.getDescription();
        boolean boolean41 = spreadsheetDate28.isOnOrBefore(serialDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean44 = spreadsheetDate28.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate43);
        boolean boolean45 = spreadsheetDate13.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
        java.lang.Object obj46 = null;
        boolean boolean47 = spreadsheetDate28.equals(obj46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate28);
        java.lang.String str49 = day48.toString();
        org.jfree.data.time.SerialDate serialDate50 = day48.getSerialDate();
        boolean boolean51 = timeSeries4.equals((java.lang.Object) day48);
        int int52 = day48.getDayOfMonth();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ERROR : Relative To String" + "'", str25.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ERROR : Relative To String" + "'", str40.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "6-January-1900" + "'", str49.equals("6-January-1900"));
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 6 + "'", int52 == 6);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(4, 100);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(4, year20);
        java.lang.Object obj24 = null;
        int int25 = month23.compareTo(obj24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        int int27 = month23.getYearValue();
        java.util.Date date28 = month23.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
        java.util.Date date30 = fixedMillisecond29.getTime();
        long long31 = fixedMillisecond29.getFirstMillisecond();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1554102000000L + "'", long31 == 1554102000000L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2147483647, 31, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        int int11 = timeSeries4.getItemCount();
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class3);
        boolean boolean6 = timeSeries4.equals((java.lang.Object) 10.0f);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class10);
        boolean boolean12 = timeSeries11.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        long long15 = fixedMillisecond14.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 100.0f);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries4.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries4.getNextTimePeriod();
        java.lang.Class class20 = timeSeries4.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNull(class20);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        java.lang.Comparable comparable5 = timeSeries4.getKey();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener6);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "" + "'", comparable5.equals(""));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
        java.lang.Class<?> wildcardClass8 = timeZone6.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "org.jfree.data.general.SeriesException: Mon Jun 10 11:59:06 PDT 2019", "Mon Jun 10 11:59:38 PDT 2019", (java.lang.Class) wildcardClass8);
        long long10 = year0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        long long4 = day3.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        timeSeries4.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
//        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class18);
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries19.createCopy(4, 100);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        long long24 = year23.getFirstMillisecond();
//        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) year23);
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class30);
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries31.createCopy(4, 100);
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        long long36 = year35.getFirstMillisecond();
//        timeSeries31.delete((org.jfree.data.time.RegularTimePeriod) year35);
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(4, year35);
//        java.lang.Object obj39 = null;
//        int int40 = month38.compareTo(obj39);
//        int int41 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) month38);
//        java.util.Collection collection42 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries19);
//        java.util.List list43 = timeSeries13.getItems();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day44.next();
//        long long46 = regularTimePeriod45.getMiddleMillisecond();
//        java.lang.String str47 = regularTimePeriod45.toString();
//        java.lang.Number number48 = timeSeries13.getValue(regularTimePeriod45);
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1546329600000L + "'", long36 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
//        org.junit.Assert.assertNotNull(collection42);
//        org.junit.Assert.assertNotNull(list43);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560279599999L + "'", long46 == 1560279599999L);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "11-June-2019" + "'", str47.equals("11-June-2019"));
//        org.junit.Assert.assertNull(number48);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar7 = null;
        fixedMillisecond6.peg(calendar7);
        java.lang.Number number9 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        timeSeries5.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries5.createCopy((int) (short) 1, 8);
        timeSeries14.setMaximumItemCount(7);
        boolean boolean17 = fixedMillisecond0.equals((java.lang.Object) 7);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
        try {
            org.jfree.data.time.TimeSeries timeSeries21 = timeSeries18.createCopy((-1), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(31);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class4);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries5.createCopy(4, 100);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year9);
        long long13 = year9.getFirstMillisecond();
        long long14 = year9.getFirstMillisecond();
        java.lang.String str15 = year9.toString();
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class3);
//        boolean boolean5 = timeSeries4.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
//        long long8 = fixedMillisecond7.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 100.0f);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar12 = null;
//        fixedMillisecond11.peg(calendar12);
//        long long14 = fixedMillisecond11.getMiddleMillisecond();
//        long long15 = fixedMillisecond11.getMiddleMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond11.getMiddleMillisecond(calendar16);
//        long long18 = fixedMillisecond11.getSerialIndex();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long18);
//        java.lang.Object obj20 = seriesChangeEvent19.getSource();
//        boolean boolean21 = fixedMillisecond7.equals(obj20);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560193223088L + "'", long14 == 1560193223088L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560193223088L + "'", long15 == 1560193223088L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560193223088L + "'", long17 == 1560193223088L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560193223088L + "'", long18 == 1560193223088L);
//        org.junit.Assert.assertTrue("'" + obj20 + "' != '" + 1560193223088L + "'", obj20.equals(1560193223088L));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        int int7 = day6.getMonth();
        boolean boolean8 = spreadsheetDate2.equals((java.lang.Object) day6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        serialDate11.setDescription("ERROR : Relative To String");
        java.lang.String str14 = serialDate11.getDescription();
        boolean boolean15 = spreadsheetDate2.isOnOrBefore(serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date19 = fixedMillisecond18.getEnd();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate20);
        int int22 = day21.getMonth();
        boolean boolean23 = spreadsheetDate17.equals((java.lang.Object) day21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date25 = fixedMillisecond24.getEnd();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
        serialDate26.setDescription("ERROR : Relative To String");
        java.lang.String str29 = serialDate26.getDescription();
        boolean boolean30 = spreadsheetDate17.isOnOrBefore(serialDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean33 = spreadsheetDate17.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        boolean boolean34 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.Object obj35 = null;
        boolean boolean36 = spreadsheetDate17.equals(obj35);
        java.lang.String str37 = spreadsheetDate17.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date40 = fixedMillisecond39.getEnd();
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(date40);
        serialDate41.setDescription("ERROR : Relative To String");
        java.lang.String str44 = serialDate41.getDescription();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths(11, serialDate41);
        boolean boolean46 = spreadsheetDate17.isAfter(serialDate41);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addMonths((int) (short) -1, serialDate41);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ERROR : Relative To String" + "'", str14.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ERROR : Relative To String" + "'", str29.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "6-January-1900" + "'", str37.equals("6-January-1900"));
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "ERROR : Relative To String" + "'", str44.equals("ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(serialDate47);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class3);
        timeSeries4.setDescription("6-January-1900");
        timeSeries4.setRangeDescription("10-June-2019");
        java.util.List list9 = timeSeries4.getItems();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class13);
        boolean boolean15 = timeSeries14.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        long long18 = fixedMillisecond17.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (double) 100.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries22 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, regularTimePeriod21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date2 = fixedMillisecond1.getEnd();
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(8, serialDate3);
        org.jfree.data.time.SerialDate serialDate7 = serialDate3.getFollowingDayOfWeek(1);
        java.lang.Class<?> wildcardClass8 = serialDate3.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getEnd();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
//        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
//        int int13 = day11.getMonth();
//        java.lang.String str14 = day11.toString();
//        java.lang.Class<?> wildcardClass15 = day11.getClass();
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = day11.getFirstMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass15);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(31);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date21 = fixedMillisecond20.getEnd();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate22);
        int int24 = day23.getMonth();
        boolean boolean25 = spreadsheetDate19.equals((java.lang.Object) day23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date27 = fixedMillisecond26.getEnd();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date27);
        serialDate28.setDescription("ERROR : Relative To String");
        java.lang.String str31 = serialDate28.getDescription();
        boolean boolean32 = spreadsheetDate19.isOnOrBefore(serialDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date36 = fixedMillisecond35.getEnd();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
        int int39 = day38.getMonth();
        boolean boolean40 = spreadsheetDate34.equals((java.lang.Object) day38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date42 = fixedMillisecond41.getEnd();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date42);
        serialDate43.setDescription("ERROR : Relative To String");
        java.lang.String str46 = serialDate43.getDescription();
        boolean boolean47 = spreadsheetDate34.isOnOrBefore(serialDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean50 = spreadsheetDate34.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate49);
        boolean boolean51 = spreadsheetDate19.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean52 = spreadsheetDate16.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date54 = fixedMillisecond53.getEnd();
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(date54);
        serialDate55.setDescription("ERROR : Relative To String");
        boolean boolean58 = spreadsheetDate34.isAfter(serialDate55);
        int int59 = spreadsheetDate34.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date63 = fixedMillisecond62.getEnd();
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.createInstance(date63);
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(serialDate64);
        int int66 = day65.getMonth();
        boolean boolean67 = spreadsheetDate61.equals((java.lang.Object) day65);
        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date69 = fixedMillisecond68.getEnd();
        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.createInstance(date69);
        serialDate70.setDescription("ERROR : Relative To String");
        java.lang.String str73 = serialDate70.getDescription();
        boolean boolean74 = spreadsheetDate61.isOnOrBefore(serialDate70);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond77 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date78 = fixedMillisecond77.getEnd();
        org.jfree.data.time.SerialDate serialDate79 = org.jfree.data.time.SerialDate.createInstance(date78);
        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day(serialDate79);
        int int81 = day80.getMonth();
        boolean boolean82 = spreadsheetDate76.equals((java.lang.Object) day80);
        org.jfree.data.time.FixedMillisecond fixedMillisecond83 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date84 = fixedMillisecond83.getEnd();
        org.jfree.data.time.SerialDate serialDate85 = org.jfree.data.time.SerialDate.createInstance(date84);
        serialDate85.setDescription("ERROR : Relative To String");
        java.lang.String str88 = serialDate85.getDescription();
        boolean boolean89 = spreadsheetDate76.isOnOrBefore(serialDate85);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate91 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean92 = spreadsheetDate76.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate91);
        boolean boolean93 = spreadsheetDate61.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate76);
        boolean boolean94 = spreadsheetDate34.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate61);
        int int95 = spreadsheetDate61.getDayOfMonth();
        java.lang.Object obj96 = null;
        boolean boolean97 = spreadsheetDate61.equals(obj96);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ERROR : Relative To String" + "'", str31.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "ERROR : Relative To String" + "'", str46.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 6 + "'", int66 == 6);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "ERROR : Relative To String" + "'", str73.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(serialDate79);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 6 + "'", int81 == 6);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "ERROR : Relative To String" + "'", str88.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 6 + "'", int95 == 6);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(4, 100);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(4, year20);
        java.lang.Object obj24 = null;
        int int25 = month23.compareTo(obj24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        int int27 = month23.getYearValue();
        long long28 = month23.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month23.next();
        long long30 = month23.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month23.next();
        org.jfree.data.time.Year year32 = month23.getYear();
        org.jfree.data.time.Year year33 = month23.getYear();
        long long34 = year33.getLastMillisecond();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1556693999999L + "'", long28 == 1556693999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 24232L + "'", long30 == 24232L);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertNotNull(year33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        timeSeries4.setMaximumItemCount(1900);
//        timeSeries4.setDescription("");
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar19 = null;
//        fixedMillisecond18.peg(calendar19);
//        java.lang.Number number21 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
//        timeSeries17.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries17.createCopy((int) (short) 1, 8);
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar33 = null;
//        fixedMillisecond32.peg(calendar33);
//        java.lang.Number number35 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        timeSeries31.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries31.createCopy((int) (short) 1, 8);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries17.addAndOrUpdate(timeSeries31);
//        timeSeries41.setDescription("ERROR : Relative To String");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener44 = null;
//        timeSeries41.removeChangeListener(seriesChangeListener44);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date47 = fixedMillisecond46.getEnd();
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date47);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date50 = fixedMillisecond49.getEnd();
//        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance(date50);
//        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date50, timeZone52);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month(date47, timeZone52);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar56 = null;
//        fixedMillisecond55.peg(calendar56);
//        long long58 = fixedMillisecond55.getMiddleMillisecond();
//        long long59 = fixedMillisecond55.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, 0.0d);
//        int int62 = month54.compareTo((java.lang.Object) timeSeriesDataItem61);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = month54.next();
//        int int64 = month54.getYearValue();
//        java.lang.Number number65 = timeSeries41.getValue((org.jfree.data.time.RegularTimePeriod) month54);
//        timeSeries41.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
//        long long69 = fixedMillisecond68.getLastMillisecond();
//        long long70 = fixedMillisecond68.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, (java.lang.Number) 0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, (java.lang.Number) 1560193146505L);
//        timeSeries4.setMaximumItemCount((int) (short) 0);
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNull(number21);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNull(number35);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNotNull(timeZone52);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560193224580L + "'", long58 == 1560193224580L);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560193224580L + "'", long59 == 1560193224580L);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2019 + "'", int64 == 2019);
//        org.junit.Assert.assertNull(number65);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 10L + "'", long69 == 10L);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 10L + "'", long70 == 10L);
//        org.junit.Assert.assertNull(timeSeriesDataItem72);
//        org.junit.Assert.assertNull(timeSeriesDataItem74);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        try {
            timeSeries4.update(7, (java.lang.Number) 1560193204254L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class4);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries5.createCopy(4, 100);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year9);
        long long13 = month12.getSerialIndex();
        long long14 = month12.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class21);
        timeSeries22.setDescription("6-January-1900");
        java.lang.Class<?> wildcardClass25 = timeSeries22.getClass();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond17, (java.lang.Class) wildcardClass25);
        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long14, "Mon Jun 10 11:59:08 PDT 2019", "Mon Jun 10 12:00:04 PDT 2019", (java.lang.Class) wildcardClass25);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 24232L + "'", long13 == 24232L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1554102000000L + "'", long14 == 1554102000000L);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(class27);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Mon Jun 10 12:00:04 PDT 2019");
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(4, 100);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(4, year20);
        java.lang.Object obj24 = null;
        int int25 = month23.compareTo(obj24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        int int27 = month23.getYearValue();
        long long28 = month23.getLastMillisecond();
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar35 = null;
        fixedMillisecond34.peg(calendar35);
        java.lang.Number number37 = timeSeries33.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        timeSeries33.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries33.createCopy((int) (short) 1, 8);
        java.lang.Class class46 = null;
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar49 = null;
        fixedMillisecond48.peg(calendar49);
        java.lang.Number number51 = timeSeries47.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        timeSeries47.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries47.createCopy((int) (short) 1, 8);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries33.addAndOrUpdate(timeSeries47);
        timeSeries57.setDescription("ERROR : Relative To String");
        java.util.Collection collection60 = timeSeries57.getTimePeriods();
        boolean boolean61 = month23.equals((java.lang.Object) timeSeries57);
        java.beans.PropertyChangeListener propertyChangeListener62 = null;
        timeSeries57.removePropertyChangeListener(propertyChangeListener62);
        java.lang.Object obj64 = timeSeries57.clone();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1556693999999L + "'", long28 == 1556693999999L);
        org.junit.Assert.assertNull(number37);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertNull(number51);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertNotNull(collection60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(obj64);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("6-January-1900");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException5);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("6-January-1900");
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("Mon Jun 10 11:59:06 PDT 2019");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) seriesException11);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getEnd();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
//        java.lang.Class<?> wildcardClass8 = timeZone6.getClass();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560193165121L, "6-January-1900", "10-June-2019", (java.lang.Class) wildcardClass8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        fixedMillisecond15.peg(calendar16);
//        java.lang.Number number18 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        java.util.Date date19 = fixedMillisecond15.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond15.next();
//        long long21 = fixedMillisecond15.getSerialIndex();
//        long long22 = fixedMillisecond15.getFirstMillisecond();
//        java.lang.Number number23 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        java.lang.Comparable comparable24 = timeSeries9.getKey();
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560193224998L + "'", long21 == 1560193224998L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560193224998L + "'", long22 == 1560193224998L);
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + 1560193165121L + "'", comparable24.equals(1560193165121L));
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int18 = spreadsheetDate16.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date22 = fixedMillisecond21.getEnd();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(serialDate23);
        int int25 = day24.getMonth();
        boolean boolean26 = spreadsheetDate20.equals((java.lang.Object) day24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date28 = fixedMillisecond27.getEnd();
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date28);
        serialDate29.setDescription("ERROR : Relative To String");
        java.lang.String str32 = serialDate29.getDescription();
        boolean boolean33 = spreadsheetDate20.isOnOrBefore(serialDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean36 = spreadsheetDate20.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date39 = fixedMillisecond38.getEnd();
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(date39);
        serialDate40.setDescription("ERROR : Relative To String");
        java.lang.String str43 = serialDate40.getDescription();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addMonths(11, serialDate40);
        boolean boolean45 = spreadsheetDate16.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, serialDate40);
        int int46 = spreadsheetDate20.getMonth();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 7 + "'", int18 == 7);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "ERROR : Relative To String" + "'", str32.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "ERROR : Relative To String" + "'", str43.equals("ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        int int7 = day6.getMonth();
        boolean boolean8 = spreadsheetDate2.equals((java.lang.Object) day6);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        timeSeries4.setMaximumItemCount((int) (short) 10);
        java.util.List list9 = timeSeries4.getItems();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560193150522L, class11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.addChangeListener(seriesChangeListener13);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries4.addAndOrUpdate(timeSeries12);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        timeSeries4.setMaximumItemCount((int) (short) 10);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class12);
        int int14 = timeSeries13.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries4.addAndOrUpdate(timeSeries13);
        try {
            timeSeries15.delete(0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        timeSeries13.setMaximumItemCount(7);
        timeSeries13.clear();
        timeSeries13.clear();
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        java.lang.String str9 = fixedMillisecond5.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond5.previous();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod10, class11);
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Mon Jun 10 12:00:25 PDT 2019" + "'", str9.equals("Mon Jun 10 12:00:25 PDT 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        timeSeries4.setMaximumItemCount((int) (short) 10);
        java.lang.Class class9 = timeSeries4.getTimePeriodClass();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries4.getTimePeriod((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNull(class9);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2019);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date1, timeZone6);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        timeSeries13.setMaximumItemCount(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date19 = fixedMillisecond18.getEnd();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate20);
        int int22 = day21.getMonth();
        boolean boolean23 = spreadsheetDate17.equals((java.lang.Object) day21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day21.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries13.addOrUpdate(regularTimePeriod24, (java.lang.Number) 100.0d);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        int int11 = day10.getMonth();
        boolean boolean12 = spreadsheetDate6.equals((java.lang.Object) day10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date14 = fixedMillisecond13.getEnd();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        serialDate15.setDescription("ERROR : Relative To String");
        java.lang.String str18 = serialDate15.getDescription();
        boolean boolean19 = spreadsheetDate6.isOnOrBefore(serialDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date23 = fixedMillisecond22.getEnd();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        int int26 = day25.getMonth();
        boolean boolean27 = spreadsheetDate21.equals((java.lang.Object) day25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date29 = fixedMillisecond28.getEnd();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
        serialDate30.setDescription("ERROR : Relative To String");
        java.lang.String str33 = serialDate30.getDescription();
        boolean boolean34 = spreadsheetDate21.isOnOrBefore(serialDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean37 = spreadsheetDate21.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate36);
        boolean boolean38 = spreadsheetDate6.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
        java.util.Date date39 = spreadsheetDate6.toDate();
        int int40 = fixedMillisecond1.compareTo((java.lang.Object) spreadsheetDate6);
        long long41 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ERROR : Relative To String" + "'", str18.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "ERROR : Relative To String" + "'", str33.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        int int21 = day20.getMonth();
        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        boolean boolean29 = spreadsheetDate16.isOnOrBefore(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean32 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.util.Date date34 = spreadsheetDate1.toDate();
        java.util.Date date35 = spreadsheetDate1.toDate();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date35);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date35);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Mon Jun 10 11:59:52 PDT 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        timeSeries4.setMaximumItemCount((int) (short) 10);
        long long9 = timeSeries4.getMaximumItemAge();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date13 = fixedMillisecond12.getEnd();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        int int16 = day15.getMonth();
        boolean boolean17 = spreadsheetDate11.equals((java.lang.Object) day15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date19 = fixedMillisecond18.getEnd();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        serialDate20.setDescription("ERROR : Relative To String");
        java.lang.String str23 = serialDate20.getDescription();
        boolean boolean24 = spreadsheetDate11.isOnOrBefore(serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean27 = spreadsheetDate11.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date29 = fixedMillisecond28.getEnd();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
        serialDate30.setDescription("ERROR : Relative To String");
        java.lang.String str33 = serialDate30.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date36 = fixedMillisecond35.getEnd();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addMonths(8, serialDate37);
        org.jfree.data.time.SerialDate serialDate41 = serialDate37.getFollowingDayOfWeek(1);
        boolean boolean42 = spreadsheetDate26.isInRange(serialDate30, serialDate37);
        boolean boolean43 = timeSeries4.equals((java.lang.Object) serialDate37);
        timeSeries4.setDomainDescription("Mon Jun 10 11:59:50 PDT 2019");
        java.lang.Class class49 = null;
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class49);
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries50.createCopy(4, 100);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        long long55 = year54.getFirstMillisecond();
        timeSeries50.delete((org.jfree.data.time.RegularTimePeriod) year54);
        java.lang.Class class61 = null;
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class61);
        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries62.createCopy(4, 100);
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
        long long67 = year66.getFirstMillisecond();
        timeSeries62.delete((org.jfree.data.time.RegularTimePeriod) year66);
        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month(4, year66);
        java.lang.Object obj70 = null;
        int int71 = month69.compareTo(obj70);
        int int72 = timeSeries50.getIndex((org.jfree.data.time.RegularTimePeriod) month69);
        int int73 = month69.getYearValue();
        long long74 = month69.getLastMillisecond();
        long long75 = month69.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = month69.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = month69.previous();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month69, (double) 1560193192373L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ERROR : Relative To String" + "'", str23.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "ERROR : Relative To String" + "'", str33.equals("ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1546329600000L + "'", long55 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries65);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1546329600000L + "'", long67 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2019 + "'", int73 == 2019);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1556693999999L + "'", long74 == 1556693999999L);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1556693999999L + "'", long75 == 1556693999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
        java.util.Date date9 = day5.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date11 = fixedMillisecond10.getEnd();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date11, timeZone13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date9, timeZone13);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(timeZone13);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(1969);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 17 + "'", int1 == 17);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getEnd();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
//        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
//        int int13 = day11.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
//        int int16 = day11.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day11.next();
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, 4);
        java.lang.String str3 = month2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 4" + "'", str3.equals("June 4"));
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        serialDate2.setDescription("ERROR : Relative To String");
//        java.lang.String str5 = serialDate2.getDescription();
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class9);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries10.addPropertyChangeListener(propertyChangeListener11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getEnd();
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date14, timeZone16);
//        boolean boolean18 = timeSeries10.equals((java.lang.Object) day17);
//        int int19 = day17.getMonth();
//        java.lang.String str20 = day17.toString();
//        java.lang.Class<?> wildcardClass21 = day17.getClass();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate2, (java.lang.Class) wildcardClass21);
//        java.lang.String str23 = timeSeries22.getDescription();
//        timeSeries22.fireSeriesChanged();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ERROR : Relative To String" + "'", str5.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10-June-2019" + "'", str20.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNull(str23);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date10);
        boolean boolean13 = timeSeries4.equals((java.lang.Object) date10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        java.util.Date date16 = fixedMillisecond15.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date18, timeZone20);
        java.lang.Class<?> wildcardClass22 = timeZone20.getClass();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date16, timeZone20);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date10, timeZone20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar31 = null;
        fixedMillisecond30.peg(calendar31);
        java.lang.Number number33 = timeSeries29.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        java.util.Date date34 = fixedMillisecond30.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(date34);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date38 = fixedMillisecond37.getEnd();
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(date38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date41 = fixedMillisecond40.getEnd();
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(date41);
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date41, timeZone43);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date38, timeZone43);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date34, timeZone43);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date10, timeZone43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month47.next();
        org.jfree.data.time.Year year49 = month47.getYear();
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(number33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(year49);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        timeSeries4.setMaximumItemCount(1900);
//        timeSeries4.setDescription("");
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar19 = null;
//        fixedMillisecond18.peg(calendar19);
//        java.lang.Number number21 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
//        timeSeries17.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries17.createCopy((int) (short) 1, 8);
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar33 = null;
//        fixedMillisecond32.peg(calendar33);
//        java.lang.Number number35 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        timeSeries31.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries31.createCopy((int) (short) 1, 8);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries17.addAndOrUpdate(timeSeries31);
//        timeSeries41.setDescription("ERROR : Relative To String");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener44 = null;
//        timeSeries41.removeChangeListener(seriesChangeListener44);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date47 = fixedMillisecond46.getEnd();
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date47);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date50 = fixedMillisecond49.getEnd();
//        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance(date50);
//        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date50, timeZone52);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month(date47, timeZone52);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar56 = null;
//        fixedMillisecond55.peg(calendar56);
//        long long58 = fixedMillisecond55.getMiddleMillisecond();
//        long long59 = fixedMillisecond55.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, 0.0d);
//        int int62 = month54.compareTo((java.lang.Object) timeSeriesDataItem61);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = month54.next();
//        int int64 = month54.getYearValue();
//        java.lang.Number number65 = timeSeries41.getValue((org.jfree.data.time.RegularTimePeriod) month54);
//        timeSeries41.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
//        long long69 = fixedMillisecond68.getLastMillisecond();
//        long long70 = fixedMillisecond68.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, (java.lang.Number) 0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, (java.lang.Number) 1560193146505L);
//        java.util.Date date75 = fixedMillisecond68.getTime();
//        java.util.TimeZone timeZone76 = null;
//        try {
//            org.jfree.data.time.Month month77 = new org.jfree.data.time.Month(date75, timeZone76);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNull(number21);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNull(number35);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNotNull(timeZone52);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560193226863L + "'", long58 == 1560193226863L);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560193226863L + "'", long59 == 1560193226863L);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2019 + "'", int64 == 2019);
//        org.junit.Assert.assertNull(number65);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 10L + "'", long69 == 10L);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 10L + "'", long70 == 10L);
//        org.junit.Assert.assertNull(timeSeriesDataItem72);
//        org.junit.Assert.assertNull(timeSeriesDataItem74);
//        org.junit.Assert.assertNotNull(date75);
//    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, 0);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date6 = fixedMillisecond5.getEnd();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
//        int int9 = day8.getMonth();
//        boolean boolean10 = spreadsheetDate4.equals((java.lang.Object) day8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date12 = fixedMillisecond11.getEnd();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
//        serialDate13.setDescription("ERROR : Relative To String");
//        java.lang.String str16 = serialDate13.getDescription();
//        boolean boolean17 = spreadsheetDate4.isOnOrBefore(serialDate13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean20 = spreadsheetDate4.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date25 = fixedMillisecond24.getEnd();
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(serialDate26);
//        int int28 = day27.getMonth();
//        boolean boolean29 = spreadsheetDate23.equals((java.lang.Object) day27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date31 = fixedMillisecond30.getEnd();
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
//        serialDate32.setDescription("ERROR : Relative To String");
//        java.lang.String str35 = serialDate32.getDescription();
//        boolean boolean36 = spreadsheetDate23.isOnOrBefore(serialDate32);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean39 = spreadsheetDate23.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date41 = fixedMillisecond40.getEnd();
//        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(date41);
//        serialDate42.setDescription("ERROR : Relative To String");
//        java.lang.String str45 = serialDate42.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date48 = fixedMillisecond47.getEnd();
//        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date48);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(serialDate49);
//        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addMonths(8, serialDate49);
//        org.jfree.data.time.SerialDate serialDate53 = serialDate49.getFollowingDayOfWeek(1);
//        boolean boolean54 = spreadsheetDate38.isInRange(serialDate42, serialDate49);
//        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addMonths(6, (org.jfree.data.time.SerialDate) spreadsheetDate38);
//        boolean boolean56 = spreadsheetDate4.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date61 = fixedMillisecond60.getEnd();
//        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance(date61);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(serialDate62);
//        int int64 = day63.getMonth();
//        boolean boolean65 = spreadsheetDate59.equals((java.lang.Object) day63);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date67 = fixedMillisecond66.getEnd();
//        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.createInstance(date67);
//        serialDate68.setDescription("ERROR : Relative To String");
//        java.lang.String str71 = serialDate68.getDescription();
//        boolean boolean72 = spreadsheetDate59.isOnOrBefore(serialDate68);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean75 = spreadsheetDate59.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate74);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date77 = fixedMillisecond76.getEnd();
//        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.createInstance(date77);
//        serialDate78.setDescription("ERROR : Relative To String");
//        java.lang.String str81 = serialDate78.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond83 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date84 = fixedMillisecond83.getEnd();
//        org.jfree.data.time.SerialDate serialDate85 = org.jfree.data.time.SerialDate.createInstance(date84);
//        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day(serialDate85);
//        org.jfree.data.time.SerialDate serialDate87 = org.jfree.data.time.SerialDate.addMonths(8, serialDate85);
//        org.jfree.data.time.SerialDate serialDate89 = serialDate85.getFollowingDayOfWeek(1);
//        boolean boolean90 = spreadsheetDate74.isInRange(serialDate78, serialDate85);
//        org.jfree.data.time.SerialDate serialDate91 = org.jfree.data.time.SerialDate.addYears((int) '#', serialDate85);
//        java.lang.String str92 = serialDate85.toString();
//        boolean boolean93 = spreadsheetDate4.isBefore(serialDate85);
//        int int94 = month2.compareTo((java.lang.Object) serialDate85);
//        java.lang.Class<?> wildcardClass95 = serialDate85.getClass();
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ERROR : Relative To String" + "'", str16.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "ERROR : Relative To String" + "'", str35.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "ERROR : Relative To String" + "'", str45.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 6 + "'", int64 == 6);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "ERROR : Relative To String" + "'", str71.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNotNull(serialDate78);
//        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "ERROR : Relative To String" + "'", str81.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNotNull(date84);
//        org.junit.Assert.assertNotNull(serialDate85);
//        org.junit.Assert.assertNotNull(serialDate87);
//        org.junit.Assert.assertNotNull(serialDate89);
//        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
//        org.junit.Assert.assertNotNull(serialDate91);
//        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "10-June-2019" + "'", str92.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
//        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 1 + "'", int94 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass95);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class4);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries5.createCopy(4, 100);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year9);
        long long13 = year9.getFirstMillisecond();
        int int14 = year9.getYear();
        long long15 = year9.getSerialIndex();
        long long16 = year9.getSerialIndex();
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class10);
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(4, 100);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries11.createCopy((int) 'a', (int) (short) 100);
//        boolean boolean18 = timeSeriesDataItem6.equals((java.lang.Object) 'a');
//        int int20 = timeSeriesDataItem6.compareTo((java.lang.Object) 1560193153583L);
//        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("6-January-1900");
//        org.jfree.data.general.SeriesException seriesException26 = new org.jfree.data.general.SeriesException("");
//        timePeriodFormatException24.addSuppressed((java.lang.Throwable) seriesException26);
//        seriesException22.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
//        int int29 = timeSeriesDataItem6.compareTo((java.lang.Object) timePeriodFormatException24);
//        java.lang.String str30 = timePeriodFormatException24.toString();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193228277L + "'", long3 == 1560193228277L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560193228277L + "'", long4 == 1560193228277L);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 6-January-1900" + "'", str30.equals("org.jfree.data.time.TimePeriodFormatException: 6-January-1900"));
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
        int int13 = day11.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        java.lang.Number number16 = timeSeriesDataItem15.getValue();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class20);
        timeSeries21.clear();
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class26);
        long long28 = timeSeries27.getMaximumItemAge();
        timeSeries27.clear();
        timeSeries27.setMaximumItemCount((int) (short) 10);
        java.lang.Class class35 = null;
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class35);
        int int37 = timeSeries36.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries27.addAndOrUpdate(timeSeries36);
        boolean boolean39 = timeSeries27.isEmpty();
        java.util.Collection collection40 = timeSeries21.getTimePeriodsUniqueToOtherSeries(timeSeries27);
        int int41 = timeSeriesDataItem15.compareTo((java.lang.Object) collection40);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 9999.0d + "'", number16.equals(9999.0d));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 9223372036854775807L + "'", long28 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(collection40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class3);
        boolean boolean6 = timeSeries4.equals((java.lang.Object) 10.0f);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class10);
        boolean boolean12 = timeSeries11.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        long long15 = fixedMillisecond14.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 100.0f);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries4.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries4.getDataItem(0);
        timeSeries4.setRangeDescription("June 2019");
        try {
            timeSeries4.removeAgedItems(1560193148466L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem20);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Mon Jun 10 11:59:08 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.next();
        org.jfree.data.time.SerialDate serialDate14 = day11.getSerialDate();
        java.lang.Class class15 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date17 = fixedMillisecond16.getEnd();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date17, timeZone19);
        boolean boolean21 = day11.equals((java.lang.Object) class15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day11.previous();
        java.util.Date date23 = regularTimePeriod22.getStart();
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 0, 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries4.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class12);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries13.createCopy(4, 100);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getFirstMillisecond();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(4, year17);
        java.lang.Number number21 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year17, number21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year17.next();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Mon Jun 10 12:00:07 PDT 2019");
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        timeSeries4.setMaximumItemCount(0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("6-January-1900");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("Mon Jun 10 11:59:06 PDT 2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str5 = seriesException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("6-January-1900");
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("Mon Jun 10 11:59:06 PDT 2019");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException9);
        java.lang.String str11 = seriesException9.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("6-January-1900");
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("Mon Jun 10 11:59:06 PDT 2019");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) seriesException15);
        seriesException9.addSuppressed((java.lang.Throwable) seriesException15);
        seriesException3.addSuppressed((java.lang.Throwable) seriesException15);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: Mon Jun 10 11:59:06 PDT 2019" + "'", str5.equals("org.jfree.data.general.SeriesException: Mon Jun 10 11:59:06 PDT 2019"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: Mon Jun 10 11:59:06 PDT 2019" + "'", str11.equals("org.jfree.data.general.SeriesException: Mon Jun 10 11:59:06 PDT 2019"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("10-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-43619), (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -43619");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        long long5 = timeSeries4.getMaximumItemAge();
//        timeSeries4.clear();
//        timeSeries4.setMaximumItemCount((int) (short) 10);
//        java.lang.Class class9 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries4.removeChangeListener(seriesChangeListener10);
//        timeSeries4.setDescription("hi!");
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar20 = null;
//        fixedMillisecond19.peg(calendar20);
//        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        timeSeries18.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
//        java.lang.Class class28 = timeSeries27.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date30 = fixedMillisecond29.getEnd();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond29.getMiddleMillisecond(calendar31);
//        timeSeries27.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        java.util.Date date34 = fixedMillisecond29.getStart();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date34);
//        long long36 = year35.getFirstMillisecond();
//        long long37 = year35.getLastMillisecond();
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year35, (java.lang.Number) 1560193150924L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertNull(class9);
//        org.junit.Assert.assertNull(number22);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNull(class28);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560193228982L + "'", long32 == 1560193228982L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1546329600000L + "'", long36 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1577865599999L + "'", long37 == 1577865599999L);
//    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getEnd();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date1, timeZone6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        fixedMillisecond9.peg(calendar10);
//        long long12 = fixedMillisecond9.getMiddleMillisecond();
//        long long13 = fixedMillisecond9.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, 0.0d);
//        int int16 = month8.compareTo((java.lang.Object) timeSeriesDataItem15);
//        org.jfree.data.time.Year year17 = month8.getYear();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560193229000L + "'", long12 == 1560193229000L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560193229000L + "'", long13 == 1560193229000L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(year17);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date5 = fixedMillisecond4.getEnd();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        int int8 = day7.getMonth();
        boolean boolean9 = spreadsheetDate3.equals((java.lang.Object) day7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date11 = fixedMillisecond10.getEnd();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date11);
        serialDate12.setDescription("ERROR : Relative To String");
        java.lang.String str15 = serialDate12.getDescription();
        boolean boolean16 = spreadsheetDate3.isOnOrBefore(serialDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date20 = fixedMillisecond19.getEnd();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate21);
        int int23 = day22.getMonth();
        boolean boolean24 = spreadsheetDate18.equals((java.lang.Object) day22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date26 = fixedMillisecond25.getEnd();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
        serialDate27.setDescription("ERROR : Relative To String");
        java.lang.String str30 = serialDate27.getDescription();
        boolean boolean31 = spreadsheetDate18.isOnOrBefore(serialDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean34 = spreadsheetDate18.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean35 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date37 = fixedMillisecond36.getEnd();
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(date37);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(serialDate38);
        boolean boolean40 = spreadsheetDate18.isAfter(serialDate38);
        int int41 = spreadsheetDate18.getMonth();
        int int42 = spreadsheetDate18.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears(1, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addDays(0, serialDate43);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ERROR : Relative To String" + "'", str15.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "ERROR : Relative To String" + "'", str30.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getEnd();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
//        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.next();
//        java.lang.String str14 = day11.toString();
//        long long15 = day11.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560150000000L + "'", long15 == 1560150000000L);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        int int11 = day10.getMonth();
        boolean boolean12 = spreadsheetDate6.equals((java.lang.Object) day10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date14 = fixedMillisecond13.getEnd();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        serialDate15.setDescription("ERROR : Relative To String");
        java.lang.String str18 = serialDate15.getDescription();
        boolean boolean19 = spreadsheetDate6.isOnOrBefore(serialDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean22 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date31 = fixedMillisecond30.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(serialDate32);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addMonths(8, serialDate32);
        org.jfree.data.time.SerialDate serialDate36 = serialDate32.getFollowingDayOfWeek(1);
        boolean boolean37 = spreadsheetDate21.isInRange(serialDate25, serialDate32);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addMonths(6, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean39 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int40 = spreadsheetDate21.getDayOfWeek();
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ERROR : Relative To String" + "'", str18.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 7 + "'", int40 == 7);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        int int21 = day20.getMonth();
        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        boolean boolean29 = spreadsheetDate16.isOnOrBefore(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean32 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.lang.Object obj34 = null;
        boolean boolean35 = spreadsheetDate16.equals(obj34);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.lang.String str37 = day36.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day36.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "6-January-1900" + "'", str37.equals("6-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod38);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        java.util.Date date9 = fixedMillisecond5.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date9);
        long long12 = month11.getFirstMillisecond();
        long long13 = month11.getSerialIndex();
        long long14 = month11.getSerialIndex();
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 24234L + "'", long13 == 24234L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24234L + "'", long14 == 24234L);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date6 = fixedMillisecond5.getEnd();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date9, timeZone11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date6, timeZone11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = regularTimePeriod16.getMiddleMillisecond();
//        java.lang.String str18 = regularTimePeriod16.toString();
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) month13, regularTimePeriod16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month13.previous();
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560279599999L + "'", long17 == 1560279599999L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "11-June-2019" + "'", str18.equals("11-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        timeSeries4.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
//        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date16 = fixedMillisecond15.getEnd();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond15.getMiddleMillisecond(calendar17);
//        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond15.getMiddleMillisecond(calendar20);
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNull(class14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560193229910L + "'", long18 == 1560193229910L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560193229910L + "'", long21 == 1560193229910L);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(4, 100);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(4, year20);
        java.lang.Object obj24 = null;
        int int25 = month23.compareTo(obj24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        int int27 = month23.getYearValue();
        long long28 = month23.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month23.next();
        long long30 = month23.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month23.next();
        int int32 = month23.getYearValue();
        java.util.Calendar calendar33 = null;
        try {
            long long34 = month23.getLastMillisecond(calendar33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1556693999999L + "'", long28 == 1556693999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 24232L + "'", long30 == 24232L);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        timeSeries4.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar20 = null;
//        fixedMillisecond19.peg(calendar20);
//        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        timeSeries18.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
//        java.lang.Object obj29 = timeSeries28.clone();
//        timeSeries28.setDomainDescription("");
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class35);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar38 = null;
//        fixedMillisecond37.peg(calendar38);
//        java.lang.Number number40 = timeSeries36.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
//        java.util.Date date41 = fixedMillisecond37.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(date41);
//        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date41);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month43.next();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day45.next();
//        long long47 = regularTimePeriod46.getMiddleMillisecond();
//        java.lang.String str48 = regularTimePeriod46.toString();
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) month43, regularTimePeriod46);
//        java.util.Collection collection50 = timeSeries28.getTimePeriods();
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNull(number22);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(obj29);
//        org.junit.Assert.assertNull(number40);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560279599999L + "'", long47 == 1560279599999L);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "11-June-2019" + "'", str48.equals("11-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries49);
//        org.junit.Assert.assertNotNull(collection50);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = regularTimePeriod2.getMiddleMillisecond(calendar3);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9L + "'", long4 == 9L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries7.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getEnd();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
//        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.next();
//        java.lang.String str14 = day11.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day11.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day11.previous();
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-43619));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-11037) + "'", int1 == (-11037));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date1, timeZone6);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date1);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = month9.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date19 = fixedMillisecond18.getEnd();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        serialDate20.setDescription("ERROR : Relative To String");
        java.lang.String str23 = serialDate20.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date26 = fixedMillisecond25.getEnd();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addMonths(8, serialDate27);
        org.jfree.data.time.SerialDate serialDate31 = serialDate27.getFollowingDayOfWeek(1);
        boolean boolean32 = spreadsheetDate16.isInRange(serialDate20, serialDate27);
        try {
            org.jfree.data.time.SerialDate serialDate34 = spreadsheetDate16.getFollowingDayOfWeek((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ERROR : Relative To String" + "'", str23.equals("ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        int int7 = day6.getMonth();
        boolean boolean8 = spreadsheetDate2.equals((java.lang.Object) day6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        serialDate11.setDescription("ERROR : Relative To String");
        java.lang.String str14 = serialDate11.getDescription();
        boolean boolean15 = spreadsheetDate2.isOnOrBefore(serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date20 = fixedMillisecond19.getEnd();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        serialDate21.setDescription("ERROR : Relative To String");
        java.lang.String str24 = serialDate21.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date27 = fixedMillisecond26.getEnd();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate28);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(8, serialDate28);
        org.jfree.data.time.SerialDate serialDate32 = serialDate28.getFollowingDayOfWeek(1);
        boolean boolean33 = spreadsheetDate17.isInRange(serialDate21, serialDate28);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addMonths(6, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str35 = spreadsheetDate17.toString();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ERROR : Relative To String" + "'", str14.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ERROR : Relative To String" + "'", str24.equals("ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "6-January-1900" + "'", str35.equals("6-January-1900"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(4, 100);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(4, year20);
        java.lang.Object obj24 = null;
        int int25 = month23.compareTo(obj24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        int int27 = month23.getYearValue();
        long long28 = month23.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month23.next();
        long long30 = month23.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month23.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month23.next();
        java.util.Date date33 = month23.getStart();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1556693999999L + "'", long28 == 1556693999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 24232L + "'", long30 == 24232L);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date33);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560193150522L, class1);
        java.lang.Comparable comparable3 = timeSeries2.getKey();
        java.lang.Comparable comparable4 = timeSeries2.getKey();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class8);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries9.createCopy(4, 100);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) year13);
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class20);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries21.createCopy(4, 100);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getFirstMillisecond();
        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) year25);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(4, year25);
        java.lang.Object obj29 = null;
        int int30 = month28.compareTo(obj29);
        int int31 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) month28);
        int int32 = month28.getYearValue();
        java.util.Date date33 = month28.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
        java.lang.Number number35 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Class class40 = null;
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class40);
        timeSeries41.setDescription("6-January-1900");
        java.lang.Class<?> wildcardClass44 = timeSeries41.getClass();
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond36, (java.lang.Class) wildcardClass44);
        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass44);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond34, class46);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 1560193150522L + "'", comparable3.equals(1560193150522L));
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 1560193150522L + "'", comparable4.equals(1560193150522L));
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNull(number35);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(class46);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("6-January-1900");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("Mon Jun 10 11:59:06 PDT 2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("6-January-1900");
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("Mon Jun 10 11:59:06 PDT 2019");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) seriesException8);
        java.lang.String str10 = seriesException8.toString();
        seriesException3.addSuppressed((java.lang.Throwable) seriesException8);
        java.lang.Throwable[] throwableArray12 = seriesException8.getSuppressed();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesException: Mon Jun 10 11:59:06 PDT 2019" + "'", str10.equals("org.jfree.data.general.SeriesException: Mon Jun 10 11:59:06 PDT 2019"));
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class3);
        boolean boolean5 = timeSeries4.isEmpty();
        java.lang.Number number7 = null;
        try {
            timeSeries4.update(11, number7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.toSerial();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 6L + "'", long4 == 6L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
        java.lang.Class<?> wildcardClass8 = timeZone6.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date2, timeZone6);
        int int10 = year9.getYear();
        long long11 = year9.getLastMillisecond();
        java.lang.String str12 = year9.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969" + "'", str12.equals("1969"));
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        java.lang.String[] strArray5 = org.jfree.data.time.SerialDate.getMonths();
//        int int6 = fixedMillisecond0.compareTo((java.lang.Object) strArray5);
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class10);
//        long long12 = timeSeries11.getMaximumItemAge();
//        timeSeries11.clear();
//        timeSeries11.setMaximumItemCount((int) (short) 10);
//        java.util.List list16 = timeSeries11.getItems();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560193150522L, class18);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries19.addChangeListener(seriesChangeListener20);
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries11.addAndOrUpdate(timeSeries19);
//        int int23 = fixedMillisecond0.compareTo((java.lang.Object) timeSeries19);
//        timeSeries19.setMaximumItemAge(1560193216654L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193231760L + "'", long3 == 1560193231760L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560193231760L + "'", long4 == 1560193231760L);
//        org.junit.Assert.assertNotNull(strArray5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list16);
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar7 = null;
//        fixedMillisecond6.peg(calendar7);
//        java.lang.Number number9 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        timeSeries5.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries5.createCopy((int) (short) 1, 8);
//        timeSeries14.setMaximumItemCount(7);
//        boolean boolean17 = fixedMillisecond0.equals((java.lang.Object) 7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        fixedMillisecond24.peg(calendar25);
//        java.lang.Number number27 = timeSeries23.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        timeSeries23.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries23.createCopy((int) (short) 1, 8);
//        timeSeries32.setMaximumItemCount(7);
//        boolean boolean35 = fixedMillisecond18.equals((java.lang.Object) 7);
//        boolean boolean36 = fixedMillisecond0.equals((java.lang.Object) 7);
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond0.getFirstMillisecond(calendar37);
//        org.junit.Assert.assertNull(number9);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNull(number27);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560193231784L + "'", long38 == 1560193231784L);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        timeSeries4.setMaximumItemCount((int) (short) 10);
        java.lang.Class class9 = timeSeries4.getTimePeriodClass();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class13);
        timeSeries14.clear();
        java.util.Collection collection16 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        java.lang.Comparable comparable17 = timeSeries4.getKey();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + "" + "'", comparable17.equals(""));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(9999);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        java.lang.String str9 = fixedMillisecond5.toString();
//        long long10 = fixedMillisecond5.getFirstMillisecond();
//        java.lang.Number number11 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, number11);
//        java.lang.Number number13 = timeSeriesDataItem12.getValue();
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Mon Jun 10 12:00:31 PDT 2019" + "'", str9.equals("Mon Jun 10 12:00:31 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560193231836L + "'", long10 == 1560193231836L);
//        org.junit.Assert.assertNull(number13);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        int int7 = day6.getMonth();
        boolean boolean8 = spreadsheetDate2.equals((java.lang.Object) day6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        serialDate11.setDescription("ERROR : Relative To String");
        java.lang.String str14 = serialDate11.getDescription();
        boolean boolean15 = spreadsheetDate2.isOnOrBefore(serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int19 = spreadsheetDate17.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date23 = fixedMillisecond22.getEnd();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        int int26 = day25.getMonth();
        boolean boolean27 = spreadsheetDate21.equals((java.lang.Object) day25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date29 = fixedMillisecond28.getEnd();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
        serialDate30.setDescription("ERROR : Relative To String");
        java.lang.String str33 = serialDate30.getDescription();
        boolean boolean34 = spreadsheetDate21.isOnOrBefore(serialDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean37 = spreadsheetDate21.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date40 = fixedMillisecond39.getEnd();
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(date40);
        serialDate41.setDescription("ERROR : Relative To String");
        java.lang.String str44 = serialDate41.getDescription();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths(11, serialDate41);
        boolean boolean46 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, serialDate41);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addDays(7, serialDate41);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ERROR : Relative To String" + "'", str14.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 7 + "'", int19 == 7);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "ERROR : Relative To String" + "'", str33.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "ERROR : Relative To String" + "'", str44.equals("ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(serialDate47);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        int int21 = day20.getMonth();
        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        boolean boolean29 = spreadsheetDate16.isOnOrBefore(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean32 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int34 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate36 = spreadsheetDate1.getFollowingDayOfWeek((int) (byte) 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertNotNull(serialDate36);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setMaximumItemCount(1900);
        timeSeries4.removeAgedItems(true);
        org.junit.Assert.assertNull(number8);
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        java.lang.String str9 = fixedMillisecond5.toString();
//        long long10 = fixedMillisecond5.getFirstMillisecond();
//        java.util.Date date11 = fixedMillisecond5.getTime();
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Mon Jun 10 12:00:32 PDT 2019" + "'", str9.equals("Mon Jun 10 12:00:32 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560193232326L + "'", long10 == 1560193232326L);
//        org.junit.Assert.assertNotNull(date11);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        java.util.Calendar calendar5 = null;
        long long6 = regularTimePeriod4.getMiddleMillisecond(calendar5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9L + "'", long6 == 9L);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getEnd();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date1, timeZone6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        fixedMillisecond9.peg(calendar10);
//        long long12 = fixedMillisecond9.getMiddleMillisecond();
//        long long13 = fixedMillisecond9.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, 0.0d);
//        int int16 = month8.compareTo((java.lang.Object) timeSeriesDataItem15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month8.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month8.previous();
//        long long19 = month8.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560193232356L + "'", long12 == 1560193232356L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560193232356L + "'", long13 == 1560193232356L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 24234L + "'", long19 == 24234L);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class4);
        timeSeries5.setDescription("6-January-1900");
        java.lang.Class<?> wildcardClass8 = timeSeries5.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        timeSeries9.fireSeriesChanged();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(comparable10);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getEnd();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        int int6 = day5.getMonth();
//        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
//        serialDate10.setDescription("ERROR : Relative To String");
//        java.lang.String str13 = serialDate10.getDescription();
//        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date22 = fixedMillisecond21.getEnd();
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(serialDate23);
//        int int25 = day24.getMonth();
//        boolean boolean26 = spreadsheetDate20.equals((java.lang.Object) day24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date28 = fixedMillisecond27.getEnd();
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date28);
//        serialDate29.setDescription("ERROR : Relative To String");
//        java.lang.String str32 = serialDate29.getDescription();
//        boolean boolean33 = spreadsheetDate20.isOnOrBefore(serialDate29);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean36 = spreadsheetDate20.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date38 = fixedMillisecond37.getEnd();
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(date38);
//        serialDate39.setDescription("ERROR : Relative To String");
//        java.lang.String str42 = serialDate39.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date45 = fixedMillisecond44.getEnd();
//        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(date45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(serialDate46);
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addMonths(8, serialDate46);
//        org.jfree.data.time.SerialDate serialDate50 = serialDate46.getFollowingDayOfWeek(1);
//        boolean boolean51 = spreadsheetDate35.isInRange(serialDate39, serialDate46);
//        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.addMonths(6, (org.jfree.data.time.SerialDate) spreadsheetDate35);
//        boolean boolean53 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date58 = fixedMillisecond57.getEnd();
//        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance(date58);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(serialDate59);
//        int int61 = day60.getMonth();
//        boolean boolean62 = spreadsheetDate56.equals((java.lang.Object) day60);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date64 = fixedMillisecond63.getEnd();
//        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance(date64);
//        serialDate65.setDescription("ERROR : Relative To String");
//        java.lang.String str68 = serialDate65.getDescription();
//        boolean boolean69 = spreadsheetDate56.isOnOrBefore(serialDate65);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean72 = spreadsheetDate56.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate71);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date74 = fixedMillisecond73.getEnd();
//        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.createInstance(date74);
//        serialDate75.setDescription("ERROR : Relative To String");
//        java.lang.String str78 = serialDate75.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond80 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date81 = fixedMillisecond80.getEnd();
//        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.createInstance(date81);
//        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(serialDate82);
//        org.jfree.data.time.SerialDate serialDate84 = org.jfree.data.time.SerialDate.addMonths(8, serialDate82);
//        org.jfree.data.time.SerialDate serialDate86 = serialDate82.getFollowingDayOfWeek(1);
//        boolean boolean87 = spreadsheetDate71.isInRange(serialDate75, serialDate82);
//        org.jfree.data.time.SerialDate serialDate88 = org.jfree.data.time.SerialDate.addYears((int) '#', serialDate82);
//        java.lang.String str89 = serialDate82.toString();
//        boolean boolean90 = spreadsheetDate1.isBefore(serialDate82);
//        java.lang.String str91 = serialDate82.getDescription();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "ERROR : Relative To String" + "'", str32.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "ERROR : Relative To String" + "'", str42.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 6 + "'", int61 == 6);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "ERROR : Relative To String" + "'", str68.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(serialDate75);
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "ERROR : Relative To String" + "'", str78.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(serialDate82);
//        org.junit.Assert.assertNotNull(serialDate84);
//        org.junit.Assert.assertNotNull(serialDate86);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertNotNull(serialDate88);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10-June-2019" + "'", str89.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
//        org.junit.Assert.assertNull(str91);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar20 = null;
        fixedMillisecond19.peg(calendar20);
        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        timeSeries18.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
        java.lang.String str29 = timeSeries28.getDescription();
        timeSeries28.setDomainDescription("Overwritten values from: ");
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNull(str29);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (6) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date1, timeZone6);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date1);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(timeZone6);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class4);
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries5.addPropertyChangeListener(propertyChangeListener6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date9, timeZone11);
//        boolean boolean13 = timeSeries5.equals((java.lang.Object) day12);
//        int int14 = day12.getMonth();
//        java.lang.String str15 = day12.toString();
//        java.lang.Class<?> wildcardClass16 = day12.getClass();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560193190501L, (java.lang.Class) wildcardClass16);
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class18);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class4);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries5.createCopy(4, 100);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year9);
        long long13 = year9.getFirstMillisecond();
        java.text.DateFormatSymbols dateFormatSymbols14 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int15 = year9.compareTo((java.lang.Object) dateFormatSymbols14);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(dateFormatSymbols14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(4, 100);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(4, year20);
        java.lang.Object obj24 = null;
        int int25 = month23.compareTo(obj24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        int int27 = month23.getYearValue();
        long long28 = month23.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month23.previous();
        java.lang.Number number30 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month23, number30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month23, (java.lang.Number) 2958465);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1554102000000L + "'", long28 == 1554102000000L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date21 = fixedMillisecond20.getEnd();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate22);
        int int24 = day23.getMonth();
        boolean boolean25 = spreadsheetDate19.equals((java.lang.Object) day23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date27 = fixedMillisecond26.getEnd();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date27);
        serialDate28.setDescription("ERROR : Relative To String");
        java.lang.String str31 = serialDate28.getDescription();
        boolean boolean32 = spreadsheetDate19.isOnOrBefore(serialDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date36 = fixedMillisecond35.getEnd();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
        int int39 = day38.getMonth();
        boolean boolean40 = spreadsheetDate34.equals((java.lang.Object) day38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date42 = fixedMillisecond41.getEnd();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date42);
        serialDate43.setDescription("ERROR : Relative To String");
        java.lang.String str46 = serialDate43.getDescription();
        boolean boolean47 = spreadsheetDate34.isOnOrBefore(serialDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean50 = spreadsheetDate34.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate49);
        boolean boolean51 = spreadsheetDate19.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean52 = spreadsheetDate16.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date54 = fixedMillisecond53.getEnd();
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(date54);
        serialDate55.setDescription("ERROR : Relative To String");
        boolean boolean58 = spreadsheetDate34.isAfter(serialDate55);
        int int59 = spreadsheetDate34.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date63 = fixedMillisecond62.getEnd();
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.createInstance(date63);
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(serialDate64);
        int int66 = day65.getMonth();
        boolean boolean67 = spreadsheetDate61.equals((java.lang.Object) day65);
        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date69 = fixedMillisecond68.getEnd();
        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.createInstance(date69);
        serialDate70.setDescription("ERROR : Relative To String");
        java.lang.String str73 = serialDate70.getDescription();
        boolean boolean74 = spreadsheetDate61.isOnOrBefore(serialDate70);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond77 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date78 = fixedMillisecond77.getEnd();
        org.jfree.data.time.SerialDate serialDate79 = org.jfree.data.time.SerialDate.createInstance(date78);
        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day(serialDate79);
        int int81 = day80.getMonth();
        boolean boolean82 = spreadsheetDate76.equals((java.lang.Object) day80);
        org.jfree.data.time.FixedMillisecond fixedMillisecond83 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date84 = fixedMillisecond83.getEnd();
        org.jfree.data.time.SerialDate serialDate85 = org.jfree.data.time.SerialDate.createInstance(date84);
        serialDate85.setDescription("ERROR : Relative To String");
        java.lang.String str88 = serialDate85.getDescription();
        boolean boolean89 = spreadsheetDate76.isOnOrBefore(serialDate85);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate91 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean92 = spreadsheetDate76.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate91);
        boolean boolean93 = spreadsheetDate61.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate76);
        boolean boolean94 = spreadsheetDate34.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate61);
        java.lang.Class<?> wildcardClass95 = spreadsheetDate34.getClass();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ERROR : Relative To String" + "'", str31.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "ERROR : Relative To String" + "'", str46.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 6 + "'", int66 == 6);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "ERROR : Relative To String" + "'", str73.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(serialDate79);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 6 + "'", int81 == 6);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "ERROR : Relative To String" + "'", str88.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
        org.junit.Assert.assertNotNull(wildcardClass95);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        java.util.Date date9 = fixedMillisecond5.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date13 = fixedMillisecond12.getEnd();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13, timeZone15);
        java.lang.Class<?> wildcardClass17 = timeZone15.getClass();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date9, timeZone15);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date9);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        timeSeries4.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
//        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date16 = fixedMillisecond15.getEnd();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond15.getMiddleMillisecond(calendar17);
//        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        java.util.Date date20 = fixedMillisecond15.getStart();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
//        long long22 = year21.getLastMillisecond();
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNull(class14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560193234915L + "'", long18 == 1560193234915L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
//    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class4);
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries5.createCopy(4, 100);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        long long10 = year9.getFirstMillisecond();
//        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) year9);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year9);
//        java.lang.Object obj13 = null;
//        int int14 = month12.compareTo(obj13);
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        fixedMillisecond20.peg(calendar21);
//        java.lang.Number number23 = timeSeries19.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        java.util.Date date24 = fixedMillisecond20.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date24);
//        long long26 = fixedMillisecond25.getMiddleMillisecond();
//        int int27 = month12.compareTo((java.lang.Object) fixedMillisecond25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond25.previous();
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560193234950L + "'", long26 == 1560193234950L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        int int7 = day6.getMonth();
        boolean boolean8 = spreadsheetDate2.equals((java.lang.Object) day6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        serialDate11.setDescription("ERROR : Relative To String");
        java.lang.String str14 = serialDate11.getDescription();
        boolean boolean15 = spreadsheetDate2.isOnOrBefore(serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date19 = fixedMillisecond18.getEnd();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate20);
        int int22 = day21.getMonth();
        boolean boolean23 = spreadsheetDate17.equals((java.lang.Object) day21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date25 = fixedMillisecond24.getEnd();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
        serialDate26.setDescription("ERROR : Relative To String");
        java.lang.String str29 = serialDate26.getDescription();
        boolean boolean30 = spreadsheetDate17.isOnOrBefore(serialDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean33 = spreadsheetDate17.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        boolean boolean34 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.Object obj35 = null;
        boolean boolean36 = spreadsheetDate17.equals(obj35);
        java.lang.String str37 = spreadsheetDate17.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date40 = fixedMillisecond39.getEnd();
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(date40);
        serialDate41.setDescription("ERROR : Relative To String");
        java.lang.String str44 = serialDate41.getDescription();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths(11, serialDate41);
        boolean boolean46 = spreadsheetDate17.isAfter(serialDate41);
        try {
            org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2147483647, serialDate41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ERROR : Relative To String" + "'", str14.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ERROR : Relative To String" + "'", str29.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "6-January-1900" + "'", str37.equals("6-January-1900"));
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "ERROR : Relative To String" + "'", str44.equals("ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getDayOfMonth();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(4, 100);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(4, year20);
        java.lang.Object obj24 = null;
        int int25 = month23.compareTo(obj24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        int int27 = month23.getYearValue();
        java.util.Date date28 = month23.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
        java.util.Date date30 = fixedMillisecond29.getTime();
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date30);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(serialDate31);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        long long4 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(4, 100);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(4, year20);
        java.lang.Object obj24 = null;
        int int25 = month23.compareTo(obj24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        int int27 = month23.getYearValue();
        long long28 = month23.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month23.next();
        long long30 = month23.getSerialIndex();
        java.lang.String str31 = month23.toString();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1556693999999L + "'", long28 == 1556693999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 24232L + "'", long30 == 24232L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "April 2019" + "'", str31.equals("April 2019"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(17);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) 'a', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getLastMillisecond(calendar2);
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond0.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193235145L + "'", long3 == 1560193235145L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        timeSeries4.setMaximumItemCount(1900);
//        timeSeries4.setDescription("");
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar19 = null;
//        fixedMillisecond18.peg(calendar19);
//        java.lang.Number number21 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
//        timeSeries17.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries17.createCopy((int) (short) 1, 8);
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar33 = null;
//        fixedMillisecond32.peg(calendar33);
//        java.lang.Number number35 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        timeSeries31.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries31.createCopy((int) (short) 1, 8);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries17.addAndOrUpdate(timeSeries31);
//        timeSeries41.setDescription("ERROR : Relative To String");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener44 = null;
//        timeSeries41.removeChangeListener(seriesChangeListener44);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date47 = fixedMillisecond46.getEnd();
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date47);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date50 = fixedMillisecond49.getEnd();
//        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance(date50);
//        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date50, timeZone52);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month(date47, timeZone52);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar56 = null;
//        fixedMillisecond55.peg(calendar56);
//        long long58 = fixedMillisecond55.getMiddleMillisecond();
//        long long59 = fixedMillisecond55.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, 0.0d);
//        int int62 = month54.compareTo((java.lang.Object) timeSeriesDataItem61);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = month54.next();
//        int int64 = month54.getYearValue();
//        java.lang.Number number65 = timeSeries41.getValue((org.jfree.data.time.RegularTimePeriod) month54);
//        timeSeries41.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
//        long long69 = fixedMillisecond68.getLastMillisecond();
//        long long70 = fixedMillisecond68.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, (java.lang.Number) 0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, (java.lang.Number) 1560193146505L);
//        java.util.Date date75 = fixedMillisecond68.getTime();
//        org.jfree.data.time.SerialDate serialDate76 = org.jfree.data.time.SerialDate.createInstance(date75);
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNull(number21);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNull(number35);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNotNull(timeZone52);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560193235171L + "'", long58 == 1560193235171L);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560193235171L + "'", long59 == 1560193235171L);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2019 + "'", int64 == 2019);
//        org.junit.Assert.assertNull(number65);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 10L + "'", long69 == 10L);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 10L + "'", long70 == 10L);
//        org.junit.Assert.assertNull(timeSeriesDataItem72);
//        org.junit.Assert.assertNull(timeSeriesDataItem74);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(serialDate76);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class12);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries13.createCopy(4, 100);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getFirstMillisecond();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(4, year17);
        java.lang.Number number21 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year17, number21);
        long long23 = year17.getFirstMillisecond();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        java.util.Date date9 = fixedMillisecond5.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date13 = fixedMillisecond12.getEnd();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date16 = fixedMillisecond15.getEnd();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date13, timeZone18);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date9, timeZone18);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(date9);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(timeZone18);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class10);
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(4, 100);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries11.createCopy((int) 'a', (int) (short) 100);
//        boolean boolean18 = timeSeriesDataItem6.equals((java.lang.Object) 'a');
//        int int20 = timeSeriesDataItem6.compareTo((java.lang.Object) 1560193153583L);
//        java.lang.Class class24 = null;
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class24);
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timeSeries25.addPropertyChangeListener(propertyChangeListener26);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date29 = fixedMillisecond28.getEnd();
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date29, timeZone31);
//        boolean boolean33 = timeSeries25.equals((java.lang.Object) day32);
//        int int34 = day32.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day32, (double) 9999);
//        long long37 = day32.getSerialIndex();
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar44 = null;
//        fixedMillisecond43.peg(calendar44);
//        java.lang.Number number46 = timeSeries42.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
//        int int47 = day32.compareTo((java.lang.Object) timeSeries42);
//        boolean boolean48 = timeSeriesDataItem6.equals((java.lang.Object) timeSeries42);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193235669L + "'", long3 == 1560193235669L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560193235669L + "'", long4 == 1560193235669L);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 43626L + "'", long37 == 43626L);
//        org.junit.Assert.assertNull(number46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        timeSeries4.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar20 = null;
//        fixedMillisecond19.peg(calendar20);
//        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        timeSeries18.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
//        timeSeries28.setDescription("ERROR : Relative To String");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries28.removeChangeListener(seriesChangeListener31);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class36);
//        java.beans.PropertyChangeListener propertyChangeListener38 = null;
//        timeSeries37.addPropertyChangeListener(propertyChangeListener38);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date41 = fixedMillisecond40.getEnd();
//        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(date41);
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date41, timeZone43);
//        boolean boolean45 = timeSeries37.equals((java.lang.Object) day44);
//        int int46 = day44.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day44, (double) 9999);
//        long long49 = day44.getSerialIndex();
//        java.lang.Number number50 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) day44);
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNull(number22);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 6 + "'", int46 == 6);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 43626L + "'", long49 == 43626L);
//        org.junit.Assert.assertNull(number50);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("First");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class4);
        timeSeries5.setDescription("6-January-1900");
        java.lang.Class<?> wildcardClass8 = timeSeries5.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, (java.lang.Class) wildcardClass8);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar18 = null;
        fixedMillisecond17.peg(calendar18);
        java.lang.Number number20 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.util.Date date21 = fixedMillisecond17.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        java.util.Date date25 = fixedMillisecond24.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date27 = fixedMillisecond26.getEnd();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date27);
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date27, timeZone29);
        java.lang.Class<?> wildcardClass31 = timeZone29.getClass();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date25, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date21, timeZone29);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNull(regularTimePeriod33);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries4.getTimePeriod(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class3);
        boolean boolean6 = timeSeries4.equals((java.lang.Object) 10.0f);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class10);
        boolean boolean12 = timeSeries11.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        long long15 = fixedMillisecond14.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 100.0f);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries4.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries4.getDataItem(0);
        timeSeries4.setRangeDescription("June 2019");
        timeSeries4.setDescription("");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = null;
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar32 = null;
        fixedMillisecond31.peg(calendar32);
        java.lang.Number number34 = timeSeries30.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
        java.util.Date date35 = fixedMillisecond31.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(date35);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date35);
        long long38 = month37.getFirstMillisecond();
        long long39 = month37.getLastMillisecond();
        try {
            org.jfree.data.time.TimeSeries timeSeries40 = timeSeries4.createCopy(regularTimePeriod25, (org.jfree.data.time.RegularTimePeriod) month37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem20);
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1559372400000L + "'", long38 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1561964399999L + "'", long39 == 1561964399999L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        int int7 = day6.getMonth();
        boolean boolean8 = spreadsheetDate2.equals((java.lang.Object) day6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        serialDate11.setDescription("ERROR : Relative To String");
        java.lang.String str14 = serialDate11.getDescription();
        boolean boolean15 = spreadsheetDate2.isOnOrBefore(serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date20 = fixedMillisecond19.getEnd();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        serialDate21.setDescription("ERROR : Relative To String");
        java.lang.String str24 = serialDate21.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date27 = fixedMillisecond26.getEnd();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate28);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(8, serialDate28);
        org.jfree.data.time.SerialDate serialDate32 = serialDate28.getFollowingDayOfWeek(1);
        boolean boolean33 = spreadsheetDate17.isInRange(serialDate21, serialDate28);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addYears((int) '#', serialDate28);
        serialDate34.setDescription("Overwritten values from: ");
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ERROR : Relative To String" + "'", str14.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ERROR : Relative To String" + "'", str24.equals("ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(serialDate34);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 'a');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        java.lang.String str4 = year0.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        timeSeries4.setMaximumItemCount((int) (short) 10);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class12);
        int int14 = timeSeries13.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries4.addAndOrUpdate(timeSeries13);
        timeSeries13.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=1560193203437]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries13.removeChangeListener(seriesChangeListener18);
        boolean boolean20 = timeSeries13.getNotify();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class3);
        boolean boolean6 = timeSeries4.equals((java.lang.Object) 10.0f);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class10);
        boolean boolean12 = timeSeries11.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        long long15 = fixedMillisecond14.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 100.0f);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries4.addAndOrUpdate(timeSeries11);
        timeSeries11.setMaximumItemAge(1554102000000L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Mon Jun 10 11:59:57 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int18 = spreadsheetDate1.getYYYY();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1900 + "'", int18 == 1900);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        timeSeriesDataItem6.setValue((java.lang.Number) 1560193146639L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem6.getPeriod();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193236384L + "'", long3 == 1560193236384L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560193236384L + "'", long4 == 1560193236384L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        java.util.Date date9 = fixedMillisecond5.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date13 = fixedMillisecond12.getEnd();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date16 = fixedMillisecond15.getEnd();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date13, timeZone18);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date9, timeZone18);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date9);
        long long23 = month22.getFirstMillisecond();
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1559372400000L + "'", long23 == 1559372400000L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        boolean boolean2 = fixedMillisecond0.equals((java.lang.Object) 1560279599999L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1560193212493L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod13, (java.lang.Number) 11);
        java.lang.Number number16 = timeSeriesDataItem15.getValue();
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 11 + "'", number16.equals(11));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(11);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test159");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.lang.Object obj7 = timeSeriesDataItem6.clone();
//        timeSeriesDataItem6.setValue((java.lang.Number) 1560193215785L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193237427L + "'", long3 == 1560193237427L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560193237427L + "'", long4 == 1560193237427L);
//        org.junit.Assert.assertNotNull(obj7);
//    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        java.util.Date date9 = fixedMillisecond5.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date13 = fixedMillisecond12.getEnd();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date16 = fixedMillisecond15.getEnd();
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone18);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date13, timeZone18);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date9, timeZone18);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date9);
//        boolean boolean24 = day22.equals((java.lang.Object) 1);
//        long long25 = day22.getSerialIndex();
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        timeSeries4.setMaximumItemCount((int) (short) 10);
        long long9 = timeSeries4.getMaximumItemAge();
        boolean boolean10 = timeSeries4.isEmpty();
        timeSeries4.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries4.removeChangeListener(seriesChangeListener12);
        try {
            timeSeries4.removeAgedItems(1560193150522L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        timeSeries4.setMaximumItemCount((int) (short) 10);
        long long9 = timeSeries4.getMaximumItemAge();
        boolean boolean10 = timeSeries4.isEmpty();
        timeSeries4.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries4.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date15 = fixedMillisecond14.getEnd();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
        int int18 = day17.getMonth();
        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar26 = null;
        fixedMillisecond25.peg(calendar26);
        java.lang.Number number28 = timeSeries24.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        java.util.Date date29 = fixedMillisecond25.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(date29);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date29);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day17, (org.jfree.data.time.RegularTimePeriod) month31);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeSeries32);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        int int21 = day20.getMonth();
        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        boolean boolean29 = spreadsheetDate16.isOnOrBefore(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean32 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.lang.Object obj34 = null;
        boolean boolean35 = spreadsheetDate16.equals(obj34);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.lang.String str37 = day36.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day36.next();
        int int39 = day36.getMonth();
        long long40 = day36.getSerialIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "6-January-1900" + "'", str37.equals("6-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 7L + "'", long40 == 7L);
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getEnd();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        int int6 = day5.getMonth();
//        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
//        serialDate10.setDescription("ERROR : Relative To String");
//        java.lang.String str13 = serialDate10.getDescription();
//        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date19 = fixedMillisecond18.getEnd();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
//        serialDate20.setDescription("ERROR : Relative To String");
//        java.lang.String str23 = serialDate20.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date26 = fixedMillisecond25.getEnd();
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addMonths(8, serialDate27);
//        org.jfree.data.time.SerialDate serialDate31 = serialDate27.getFollowingDayOfWeek(1);
//        boolean boolean32 = spreadsheetDate16.isInRange(serialDate20, serialDate27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date35 = fixedMillisecond34.getEnd();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate36);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addMonths(8, serialDate36);
//        org.jfree.data.time.SerialDate serialDate40 = serialDate36.getFollowingDayOfWeek(1);
//        int int41 = spreadsheetDate16.compareTo((java.lang.Object) serialDate36);
//        java.util.Date date42 = spreadsheetDate16.toDate();
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date42);
//        java.lang.String str44 = year43.toString();
//        int int45 = year43.getYear();
//        java.util.Calendar calendar46 = null;
//        try {
//            year43.peg(calendar46);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ERROR : Relative To String" + "'", str23.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-43619) + "'", int41 == (-43619));
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1900" + "'", str44.equals("1900"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1900 + "'", int45 == 1900);
//    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getEnd();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date1, timeZone6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        fixedMillisecond9.peg(calendar10);
//        long long12 = fixedMillisecond9.getMiddleMillisecond();
//        long long13 = fixedMillisecond9.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, 0.0d);
//        int int16 = month8.compareTo((java.lang.Object) timeSeriesDataItem15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month8.next();
//        org.jfree.data.time.Year year18 = month8.getYear();
//        long long19 = year18.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560193237889L + "'", long12 == 1560193237889L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560193237889L + "'", long13 == 1560193237889L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        int int7 = day6.getMonth();
        boolean boolean8 = spreadsheetDate2.equals((java.lang.Object) day6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        serialDate11.setDescription("ERROR : Relative To String");
        java.lang.String str14 = serialDate11.getDescription();
        boolean boolean15 = spreadsheetDate2.isOnOrBefore(serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int19 = spreadsheetDate17.toSerial();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date21 = fixedMillisecond20.getEnd();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
        serialDate22.setDescription("ERROR : Relative To String");
        boolean boolean25 = spreadsheetDate17.isAfter(serialDate22);
        int int26 = spreadsheetDate17.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addYears(1969, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ERROR : Relative To String" + "'", str14.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 7 + "'", int19 == 7);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertNotNull(serialDate27);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) strArray0);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        timeSeries4.removeAgedItems(false);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        java.util.Date date9 = fixedMillisecond5.getTime();
//        long long10 = fixedMillisecond5.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) 10);
//        long long13 = fixedMillisecond5.getLastMillisecond();
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560193238090L + "'", long10 == 1560193238090L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560193238090L + "'", long13 == 1560193238090L);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date10);
        boolean boolean13 = timeSeries4.equals((java.lang.Object) date10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        java.util.Date date16 = fixedMillisecond15.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date18, timeZone20);
        java.lang.Class<?> wildcardClass22 = timeZone20.getClass();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date16, timeZone20);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date10, timeZone20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar31 = null;
        fixedMillisecond30.peg(calendar31);
        java.lang.Number number33 = timeSeries29.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        java.util.Date date34 = fixedMillisecond30.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(date34);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date38 = fixedMillisecond37.getEnd();
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(date38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date41 = fixedMillisecond40.getEnd();
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(date41);
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date41, timeZone43);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date38, timeZone43);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date34, timeZone43);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date10, timeZone43);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond(date10);
        java.util.Calendar calendar49 = null;
        fixedMillisecond48.peg(calendar49);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(number33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(timeZone43);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class4);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries5.createCopy(4, 100);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year9);
        long long13 = year9.getFirstMillisecond();
        int int14 = year9.getYear();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date19 = fixedMillisecond18.getEnd();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date19, timeZone21);
        java.lang.Class<?> wildcardClass23 = timeZone21.getClass();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year15, "org.jfree.data.general.SeriesException: Mon Jun 10 11:59:06 PDT 2019", "Mon Jun 10 11:59:38 PDT 2019", (java.lang.Class) wildcardClass23);
        java.lang.String[] strArray25 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) strArray25);
        java.lang.Object obj27 = seriesChangeEvent26.getSource();
        java.lang.String str28 = seriesChangeEvent26.toString();
        java.lang.Object obj29 = seriesChangeEvent26.getSource();
        boolean boolean30 = year15.equals((java.lang.Object) seriesChangeEvent26);
        int int31 = year9.compareTo((java.lang.Object) year15);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int18 = spreadsheetDate16.getDayOfWeek();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date21 = fixedMillisecond20.getEnd();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate22);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths(8, serialDate22);
        org.jfree.data.time.SerialDate serialDate26 = serialDate22.getFollowingDayOfWeek(1);
        java.lang.Class<?> wildcardClass27 = serialDate22.getClass();
        boolean boolean28 = spreadsheetDate16.isAfter(serialDate22);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 7 + "'", int18 == 7);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class4);
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries5.createCopy(4, 100);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        long long10 = year9.getFirstMillisecond();
//        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) year9);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year9);
//        java.lang.Object obj13 = null;
//        int int14 = month12.compareTo(obj13);
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        fixedMillisecond20.peg(calendar21);
//        java.lang.Number number23 = timeSeries19.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        java.util.Date date24 = fixedMillisecond20.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date24);
//        long long26 = fixedMillisecond25.getMiddleMillisecond();
//        int int27 = month12.compareTo((java.lang.Object) fixedMillisecond25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month12.next();
//        int int29 = month12.getYearValue();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date33 = fixedMillisecond32.getEnd();
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(date33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(serialDate34);
//        int int36 = day35.getMonth();
//        boolean boolean37 = spreadsheetDate31.equals((java.lang.Object) day35);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date39 = fixedMillisecond38.getEnd();
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(date39);
//        serialDate40.setDescription("ERROR : Relative To String");
//        java.lang.String str43 = serialDate40.getDescription();
//        boolean boolean44 = spreadsheetDate31.isOnOrBefore(serialDate40);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean47 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate46);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date51 = fixedMillisecond50.getEnd();
//        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(date51);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(serialDate52);
//        int int54 = day53.getMonth();
//        boolean boolean55 = spreadsheetDate49.equals((java.lang.Object) day53);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date57 = fixedMillisecond56.getEnd();
//        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance(date57);
//        serialDate58.setDescription("ERROR : Relative To String");
//        java.lang.String str61 = serialDate58.getDescription();
//        boolean boolean62 = spreadsheetDate49.isOnOrBefore(serialDate58);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date66 = fixedMillisecond65.getEnd();
//        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.createInstance(date66);
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(serialDate67);
//        int int69 = day68.getMonth();
//        boolean boolean70 = spreadsheetDate64.equals((java.lang.Object) day68);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date72 = fixedMillisecond71.getEnd();
//        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.createInstance(date72);
//        serialDate73.setDescription("ERROR : Relative To String");
//        java.lang.String str76 = serialDate73.getDescription();
//        boolean boolean77 = spreadsheetDate64.isOnOrBefore(serialDate73);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate79 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean80 = spreadsheetDate64.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate79);
//        boolean boolean81 = spreadsheetDate49.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate64);
//        boolean boolean82 = spreadsheetDate46.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate64);
//        int int83 = month12.compareTo((java.lang.Object) spreadsheetDate64);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560193238763L + "'", long26 == 1560193238763L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "ERROR : Relative To String" + "'", str43.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 6 + "'", int54 == 6);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "ERROR : Relative To String" + "'", str61.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 6 + "'", int69 == 6);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(serialDate73);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "ERROR : Relative To String" + "'", str76.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
//    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date10 = fixedMillisecond9.getEnd();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
//        int int13 = day12.getMonth();
//        boolean boolean14 = spreadsheetDate8.equals((java.lang.Object) day12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date16 = fixedMillisecond15.getEnd();
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
//        serialDate17.setDescription("ERROR : Relative To String");
//        java.lang.String str20 = serialDate17.getDescription();
//        boolean boolean21 = spreadsheetDate8.isOnOrBefore(serialDate17);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date25 = fixedMillisecond24.getEnd();
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(serialDate26);
//        int int28 = day27.getMonth();
//        boolean boolean29 = spreadsheetDate23.equals((java.lang.Object) day27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date31 = fixedMillisecond30.getEnd();
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
//        serialDate32.setDescription("ERROR : Relative To String");
//        java.lang.String str35 = serialDate32.getDescription();
//        boolean boolean36 = spreadsheetDate23.isOnOrBefore(serialDate32);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean39 = spreadsheetDate23.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
//        boolean boolean40 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date42 = fixedMillisecond41.getEnd();
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate43);
//        boolean boolean45 = spreadsheetDate23.isAfter(serialDate43);
//        boolean boolean46 = timeSeriesDataItem6.equals((java.lang.Object) serialDate43);
//        timeSeriesDataItem6.setValue((java.lang.Number) 9999.0d);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193239445L + "'", long3 == 1560193239445L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560193239445L + "'", long4 == 1560193239445L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "ERROR : Relative To String" + "'", str20.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "ERROR : Relative To String" + "'", str35.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date10 = fixedMillisecond9.getEnd();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
//        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10, timeZone12);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day13.next();
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class21);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries22.addPropertyChangeListener(propertyChangeListener23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date26 = fixedMillisecond25.getEnd();
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date26, timeZone28);
//        boolean boolean30 = timeSeries22.equals((java.lang.Object) day29);
//        int int31 = day29.getMonth();
//        java.lang.String str32 = day29.toString();
//        java.lang.Class<?> wildcardClass33 = day29.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date35 = fixedMillisecond34.getEnd();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date35);
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar44 = null;
//        fixedMillisecond43.peg(calendar44);
//        java.lang.Number number46 = timeSeries42.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
//        java.util.Date date47 = fixedMillisecond43.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond(date47);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date47);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date51 = fixedMillisecond50.getEnd();
//        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(date51);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date54 = fixedMillisecond53.getEnd();
//        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(date54);
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date54, timeZone56);
//        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month(date51, timeZone56);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date47, timeZone56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date35, timeZone56);
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod15, "org.jfree.data.general.SeriesException: Mon Jun 10 11:59:06 PDT 2019", "", (java.lang.Class) wildcardClass33);
//        java.util.Date date62 = regularTimePeriod15.getStart();
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNull(number46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(date62);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(2019);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar20 = null;
        fixedMillisecond19.peg(calendar20);
        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        timeSeries18.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
        java.lang.Comparable comparable29 = timeSeries28.getKey();
        java.lang.Object obj30 = timeSeries28.clone();
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + "Overwritten values from: " + "'", comparable29.equals("Overwritten values from: "));
        org.junit.Assert.assertNotNull(obj30);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(4, 100);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(4, year20);
        java.lang.Object obj24 = null;
        int int25 = month23.compareTo(obj24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        int int27 = month23.getYearValue();
        long long28 = month23.getLastMillisecond();
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar35 = null;
        fixedMillisecond34.peg(calendar35);
        java.lang.Number number37 = timeSeries33.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        timeSeries33.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries33.createCopy((int) (short) 1, 8);
        java.lang.Class class46 = null;
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar49 = null;
        fixedMillisecond48.peg(calendar49);
        java.lang.Number number51 = timeSeries47.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        timeSeries47.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries47.createCopy((int) (short) 1, 8);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries33.addAndOrUpdate(timeSeries47);
        timeSeries57.setDescription("ERROR : Relative To String");
        java.util.Collection collection60 = timeSeries57.getTimePeriods();
        boolean boolean61 = month23.equals((java.lang.Object) timeSeries57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = month23.next();
        long long63 = month23.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month23, (java.lang.Number) (byte) 1);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1556693999999L + "'", long28 == 1556693999999L);
        org.junit.Assert.assertNull(number37);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertNull(number51);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertNotNull(collection60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1556693999999L + "'", long63 == 1556693999999L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class12);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries13.createCopy(4, 100);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getFirstMillisecond();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(4, year17);
        java.lang.Number number21 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year17, number21);
        long long23 = timeSeries4.getMaximumItemAge();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        java.lang.String str9 = fixedMillisecond5.toString();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        fixedMillisecond15.peg(calendar16);
//        java.lang.Number number18 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        timeSeries14.setRangeDescription("hi!");
//        java.lang.Class class24 = null;
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class24);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries25.createCopy(4, 100);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries25.createCopy((int) 'a', (int) (short) 100);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries14.addAndOrUpdate(timeSeries31);
//        timeSeries31.setRangeDescription("1900");
//        boolean boolean35 = fixedMillisecond5.equals((java.lang.Object) "1900");
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Mon Jun 10 12:00:40 PDT 2019" + "'", str9.equals("Mon Jun 10 12:00:40 PDT 2019"));
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560193150522L, class1);
        timeSeries2.setDescription("December");
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560193150522L, class1);
        java.lang.Comparable comparable3 = timeSeries2.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date5 = fixedMillisecond4.getEnd();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
        serialDate6.setDescription("ERROR : Relative To String");
        java.lang.String str9 = serialDate6.getDescription();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate6);
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day10);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 1560193150522L + "'", comparable3.equals(1560193150522L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ERROR : Relative To String" + "'", str9.equals("ERROR : Relative To String"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date22 = fixedMillisecond21.getEnd();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(serialDate23);
        int int25 = day24.getMonth();
        boolean boolean26 = spreadsheetDate20.equals((java.lang.Object) day24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date28 = fixedMillisecond27.getEnd();
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date28);
        serialDate29.setDescription("ERROR : Relative To String");
        java.lang.String str32 = serialDate29.getDescription();
        boolean boolean33 = spreadsheetDate20.isOnOrBefore(serialDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean36 = spreadsheetDate20.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date38 = fixedMillisecond37.getEnd();
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(date38);
        serialDate39.setDescription("ERROR : Relative To String");
        java.lang.String str42 = serialDate39.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date45 = fixedMillisecond44.getEnd();
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(date45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(serialDate46);
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addMonths(8, serialDate46);
        org.jfree.data.time.SerialDate serialDate50 = serialDate46.getFollowingDayOfWeek(1);
        boolean boolean51 = spreadsheetDate35.isInRange(serialDate39, serialDate46);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.addMonths(6, (org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean53 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
        java.lang.Class class57 = null;
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class57);
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar60 = null;
        fixedMillisecond59.peg(calendar60);
        java.lang.Number number62 = timeSeries58.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59);
        timeSeries58.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries58.createCopy((int) (short) 1, 8);
        java.lang.Class class71 = null;
        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class71);
        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar74 = null;
        fixedMillisecond73.peg(calendar74);
        java.lang.Number number76 = timeSeries72.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73);
        timeSeries72.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries72.createCopy((int) (short) 1, 8);
        org.jfree.data.time.TimeSeries timeSeries82 = timeSeries58.addAndOrUpdate(timeSeries72);
        timeSeries82.setDescription("ERROR : Relative To String");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener85 = null;
        timeSeries82.removeChangeListener(seriesChangeListener85);
        try {
            int int87 = spreadsheetDate1.compareTo((java.lang.Object) timeSeries82);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "ERROR : Relative To String" + "'", str32.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "ERROR : Relative To String" + "'", str42.equals("ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNull(number62);
        org.junit.Assert.assertNotNull(timeSeries67);
        org.junit.Assert.assertNull(number76);
        org.junit.Assert.assertNotNull(timeSeries81);
        org.junit.Assert.assertNotNull(timeSeries82);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        java.util.Date date9 = fixedMillisecond5.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date9);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class3);
        boolean boolean5 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        long long8 = fixedMillisecond7.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 100.0f);
        java.lang.String str11 = fixedMillisecond7.toString();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str11.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        java.util.List list6 = timeSeries4.getItems();
        boolean boolean7 = timeSeries4.getNotify();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries12.createCopy(4, 100);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getFirstMillisecond();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries4.addAndOrUpdate(timeSeries12);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries12.getDataItem((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries19);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class3);
        boolean boolean6 = timeSeries4.equals((java.lang.Object) 10.0f);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class10);
        boolean boolean12 = timeSeries11.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        long long15 = fixedMillisecond14.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 100.0f);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries4.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries4.getDataItem(0);
        timeSeries4.setRangeDescription("June 2019");
        timeSeries4.setDescription("");
        boolean boolean25 = timeSeries4.getNotify();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class12);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries13.createCopy(4, 100);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getFirstMillisecond();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(4, year17);
        java.lang.Number number21 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year17, number21);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (short) 10, 0);
        java.lang.Number number26 = null;
        timeSeries4.update((org.jfree.data.time.RegularTimePeriod) month25, number26);
        try {
            org.jfree.data.time.TimeSeries timeSeries30 = timeSeries4.createCopy((int) (short) 0, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date10 = fixedMillisecond9.getEnd();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date10);
//        boolean boolean13 = timeSeries4.equals((java.lang.Object) date10);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560193150522L, class15);
//        java.lang.Comparable comparable17 = timeSeries16.getKey();
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class21);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries22.addPropertyChangeListener(propertyChangeListener23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date26 = fixedMillisecond25.getEnd();
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date26, timeZone28);
//        boolean boolean30 = timeSeries22.equals((java.lang.Object) day29);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day29.next();
//        org.jfree.data.time.SerialDate serialDate32 = day29.getSerialDate();
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class36);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar39 = null;
//        fixedMillisecond38.peg(calendar39);
//        java.lang.Number number41 = timeSeries37.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
//        java.lang.String str42 = fixedMillisecond38.toString();
//        long long43 = fixedMillisecond38.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) day29, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries4.addAndOrUpdate(timeSeries16);
//        long long46 = timeSeries45.getMaximumItemAge();
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 1560193150522L + "'", comparable17.equals(1560193150522L));
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNull(number41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Mon Jun 10 12:00:40 PDT 2019" + "'", str42.equals("Mon Jun 10 12:00:40 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560193240806L + "'", long43 == 1560193240806L);
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 9223372036854775807L + "'", long46 == 9223372036854775807L);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(1, (int) (byte) -1, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class3);
        boolean boolean5 = timeSeries4.isEmpty();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries4.getTimePeriod(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        int int7 = day6.getMonth();
        boolean boolean8 = spreadsheetDate2.equals((java.lang.Object) day6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        serialDate11.setDescription("ERROR : Relative To String");
        java.lang.String str14 = serialDate11.getDescription();
        boolean boolean15 = spreadsheetDate2.isOnOrBefore(serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int19 = spreadsheetDate17.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date23 = fixedMillisecond22.getEnd();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        int int26 = day25.getMonth();
        boolean boolean27 = spreadsheetDate21.equals((java.lang.Object) day25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date29 = fixedMillisecond28.getEnd();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
        serialDate30.setDescription("ERROR : Relative To String");
        java.lang.String str33 = serialDate30.getDescription();
        boolean boolean34 = spreadsheetDate21.isOnOrBefore(serialDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean37 = spreadsheetDate21.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date40 = fixedMillisecond39.getEnd();
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(date40);
        serialDate41.setDescription("ERROR : Relative To String");
        java.lang.String str44 = serialDate41.getDescription();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths(11, serialDate41);
        boolean boolean46 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, serialDate41);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addDays(11, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.Class class51 = null;
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class51);
        java.beans.PropertyChangeListener propertyChangeListener53 = null;
        timeSeries52.addPropertyChangeListener(propertyChangeListener53);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener55 = null;
        timeSeries52.addChangeListener(seriesChangeListener55);
        timeSeries52.setRangeDescription("Mon Jun 10 11:59:06 PDT 2019");
        boolean boolean59 = spreadsheetDate17.equals((java.lang.Object) "Mon Jun 10 11:59:06 PDT 2019");
        int int60 = spreadsheetDate17.getMonth();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ERROR : Relative To String" + "'", str14.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 7 + "'", int19 == 7);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "ERROR : Relative To String" + "'", str33.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "ERROR : Relative To String" + "'", str44.equals("ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int2 = year0.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1560193159487L);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test197");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getEnd();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        int int6 = day5.getMonth();
//        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
//        serialDate10.setDescription("ERROR : Relative To String");
//        java.lang.String str13 = serialDate10.getDescription();
//        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date19 = fixedMillisecond18.getEnd();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
//        serialDate20.setDescription("ERROR : Relative To String");
//        java.lang.String str23 = serialDate20.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date26 = fixedMillisecond25.getEnd();
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addMonths(8, serialDate27);
//        org.jfree.data.time.SerialDate serialDate31 = serialDate27.getFollowingDayOfWeek(1);
//        boolean boolean32 = spreadsheetDate16.isInRange(serialDate20, serialDate27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date35 = fixedMillisecond34.getEnd();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate36);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addMonths(8, serialDate36);
//        org.jfree.data.time.SerialDate serialDate40 = serialDate36.getFollowingDayOfWeek(1);
//        int int41 = spreadsheetDate16.compareTo((java.lang.Object) serialDate36);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date44 = fixedMillisecond43.getEnd();
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(date44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(serialDate45);
//        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addMonths(8, serialDate45);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date51 = fixedMillisecond50.getEnd();
//        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(date51);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(serialDate52);
//        int int54 = day53.getMonth();
//        boolean boolean55 = spreadsheetDate49.equals((java.lang.Object) day53);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date57 = fixedMillisecond56.getEnd();
//        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance(date57);
//        serialDate58.setDescription("ERROR : Relative To String");
//        java.lang.String str61 = serialDate58.getDescription();
//        boolean boolean62 = spreadsheetDate49.isOnOrBefore(serialDate58);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean65 = spreadsheetDate49.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate64);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date67 = fixedMillisecond66.getEnd();
//        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.createInstance(date67);
//        serialDate68.setDescription("ERROR : Relative To String");
//        java.lang.String str71 = serialDate68.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date74 = fixedMillisecond73.getEnd();
//        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.createInstance(date74);
//        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(serialDate75);
//        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.addMonths(8, serialDate75);
//        org.jfree.data.time.SerialDate serialDate79 = serialDate75.getFollowingDayOfWeek(1);
//        boolean boolean80 = spreadsheetDate64.isInRange(serialDate68, serialDate75);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond82 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date83 = fixedMillisecond82.getEnd();
//        org.jfree.data.time.SerialDate serialDate84 = org.jfree.data.time.SerialDate.createInstance(date83);
//        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(serialDate84);
//        org.jfree.data.time.SerialDate serialDate86 = org.jfree.data.time.SerialDate.addMonths(8, serialDate84);
//        org.jfree.data.time.SerialDate serialDate88 = serialDate84.getFollowingDayOfWeek(1);
//        int int89 = spreadsheetDate64.compareTo((java.lang.Object) serialDate84);
//        boolean boolean90 = spreadsheetDate16.isInRange(serialDate45, (org.jfree.data.time.SerialDate) spreadsheetDate64);
//        org.jfree.data.time.SerialDate serialDate92 = org.jfree.data.time.SerialDate.createInstance(2958465);
//        boolean boolean93 = spreadsheetDate16.isOnOrAfter(serialDate92);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ERROR : Relative To String" + "'", str23.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-43619) + "'", int41 == (-43619));
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 6 + "'", int54 == 6);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "ERROR : Relative To String" + "'", str61.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "ERROR : Relative To String" + "'", str71.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(serialDate75);
//        org.junit.Assert.assertNotNull(serialDate77);
//        org.junit.Assert.assertNotNull(serialDate79);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertNotNull(serialDate84);
//        org.junit.Assert.assertNotNull(serialDate86);
//        org.junit.Assert.assertNotNull(serialDate88);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + (-43619) + "'", int89 == (-43619));
//        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
//        org.junit.Assert.assertNotNull(serialDate92);
//        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        timeSeries4.setMaximumItemCount((int) (short) 10);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class12);
        int int14 = timeSeries13.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries4.addAndOrUpdate(timeSeries13);
        timeSeries13.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=1560193203437]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries13.removeChangeListener(seriesChangeListener18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = null;
        try {
            int int21 = timeSeries13.getIndex(regularTimePeriod20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getEnd();
//        long long3 = fixedMillisecond1.getMiddleMillisecond();
//        long long4 = fixedMillisecond1.getFirstMillisecond();
//        boolean boolean5 = year0.equals((java.lang.Object) long4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = year0.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193243409L + "'", long3 == 1560193243409L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560193243409L + "'", long4 == 1560193243409L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) -1, (int) (byte) 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class4);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries5.createCopy(4, 100);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year9);
        java.lang.Object obj13 = null;
        int int14 = month12.compareTo(obj13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month12.previous();
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class14);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries15.createCopy(4, 100);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries15.createCopy((int) 'a', (int) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries4.addAndOrUpdate(timeSeries21);
        timeSeries22.setNotify(true);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(timeSeries22);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(4, 100);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(4, year20);
        java.lang.Object obj24 = null;
        int int25 = month23.compareTo(obj24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        long long27 = month23.getFirstMillisecond();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1554102000000L + "'", long27 == 1554102000000L);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        long long5 = timeSeries4.getMaximumItemAge();
//        java.util.List list6 = timeSeries4.getItems();
//        boolean boolean7 = timeSeries4.getNotify();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class11);
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries12.createCopy(4, 100);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        long long17 = year16.getFirstMillisecond();
//        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) year16);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries4.addAndOrUpdate(timeSeries12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date21 = fixedMillisecond20.getEnd();
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date24 = fixedMillisecond23.getEnd();
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date24, timeZone26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date21, timeZone26);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar30 = null;
//        fixedMillisecond29.peg(calendar30);
//        long long32 = fixedMillisecond29.getMiddleMillisecond();
//        long long33 = fixedMillisecond29.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, 0.0d);
//        int int36 = month28.compareTo((java.lang.Object) timeSeriesDataItem35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month28.previous();
//        java.lang.Number number38 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries19.addOrUpdate(regularTimePeriod37, number38);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560193243511L + "'", long32 == 1560193243511L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560193243511L + "'", long33 == 1560193243511L);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar20 = null;
        fixedMillisecond19.peg(calendar20);
        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        timeSeries18.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
        java.lang.Object obj29 = timeSeries28.clone();
        timeSeries28.setMaximumItemCount(0);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class36);
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries37.createCopy(4, 100);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        long long42 = year41.getFirstMillisecond();
        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) year41);
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(4, year41);
        java.lang.String str45 = year41.toString();
        int int46 = year41.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date48 = fixedMillisecond47.getEnd();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date48);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(serialDate49);
        int int51 = day50.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date54 = fixedMillisecond53.getEnd();
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(date54);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(serialDate55);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.addMonths(8, serialDate55);
        boolean boolean58 = day50.equals((java.lang.Object) 8);
        boolean boolean60 = day50.equals((java.lang.Object) 4);
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) year41, (org.jfree.data.time.RegularTimePeriod) day50);
        java.lang.Comparable comparable62 = timeSeries28.getKey();
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1546329600000L + "'", long42 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "2019" + "'", str45.equals("2019"));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 6 + "'", int51 == 6);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertTrue("'" + comparable62 + "' != '" + "Overwritten values from: " + "'", comparable62.equals("Overwritten values from: "));
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.lang.Object obj7 = timeSeriesDataItem6.clone();
//        java.lang.Object obj8 = null;
//        int int9 = timeSeriesDataItem6.compareTo(obj8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeriesDataItem6.getPeriod();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193243966L + "'", long3 == 1560193243966L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560193243966L + "'", long4 == 1560193243966L);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Mon Jun 10 11:59:38 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        int int21 = day20.getMonth();
        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        boolean boolean29 = spreadsheetDate16.isOnOrBefore(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean32 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int34 = spreadsheetDate16.getYYYY();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1900 + "'", int34 == 1900);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        int int21 = day20.getMonth();
        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date27 = fixedMillisecond26.getEnd();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate28);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(8, serialDate28);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate28);
        boolean boolean32 = spreadsheetDate24.isAfter(serialDate28);
        boolean boolean33 = spreadsheetDate16.isBefore(serialDate28);
        org.jfree.data.time.SerialDate serialDate34 = spreadsheetDate1.getEndOfCurrentMonth(serialDate28);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(serialDate34);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date2 = fixedMillisecond1.getEnd();
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(8, serialDate3);
        org.jfree.data.time.SerialDate serialDate7 = serialDate3.getFollowingDayOfWeek(1);
        java.lang.String str8 = serialDate7.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date12 = fixedMillisecond11.getEnd();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate13);
        int int15 = day14.getMonth();
        boolean boolean16 = spreadsheetDate10.equals((java.lang.Object) day14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        serialDate19.setDescription("ERROR : Relative To String");
        java.lang.String str22 = serialDate19.getDescription();
        boolean boolean23 = spreadsheetDate10.isOnOrBefore(serialDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date27 = fixedMillisecond26.getEnd();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate28);
        int int30 = day29.getMonth();
        boolean boolean31 = spreadsheetDate25.equals((java.lang.Object) day29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date33 = fixedMillisecond32.getEnd();
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(date33);
        serialDate34.setDescription("ERROR : Relative To String");
        java.lang.String str37 = serialDate34.getDescription();
        boolean boolean38 = spreadsheetDate25.isOnOrBefore(serialDate34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean41 = spreadsheetDate25.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate40);
        boolean boolean42 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date44 = fixedMillisecond43.getEnd();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(date44);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(serialDate45);
        boolean boolean47 = spreadsheetDate25.isAfter(serialDate45);
        int int48 = spreadsheetDate25.getMonth();
        int int49 = spreadsheetDate25.getYYYY();
        org.jfree.data.time.SerialDate serialDate50 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate25);
        try {
            org.jfree.data.time.SerialDate serialDate52 = spreadsheetDate25.getPreviousDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ERROR : Relative To String" + "'", str22.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "ERROR : Relative To String" + "'", str37.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1900 + "'", int49 == 1900);
        org.junit.Assert.assertNotNull(serialDate50);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test212");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getEnd();
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(8, serialDate3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate3);
//        long long7 = day6.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560193199999L + "'", long7 == 1560193199999L);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class4);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries5.createCopy(4, 100);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year9);
        java.lang.Object obj13 = null;
        int int14 = month12.compareTo(obj13);
        long long15 = month12.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(8, serialDate19);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate19);
        boolean boolean23 = month12.equals((java.lang.Object) serialDate19);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24232L + "'", long15 == 24232L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
        java.lang.Class<?> wildcardClass8 = timeZone6.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "org.jfree.data.general.SeriesException: Mon Jun 10 11:59:06 PDT 2019", "Mon Jun 10 11:59:38 PDT 2019", (java.lang.Class) wildcardClass8);
        long long10 = year0.getLastMillisecond();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(4, 100);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(4, year20);
        java.lang.Object obj24 = null;
        int int25 = month23.compareTo(obj24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        int int27 = month23.getYearValue();
        long long28 = month23.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month23.next();
        long long30 = month23.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month23.next();
        org.jfree.data.time.Year year32 = month23.getYear();
        org.jfree.data.time.Year year33 = month23.getYear();
        java.util.Calendar calendar34 = null;
        try {
            long long35 = year33.getLastMillisecond(calendar34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1556693999999L + "'", long28 == 1556693999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 24232L + "'", long30 == 24232L);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertNotNull(year33);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date6 = fixedMillisecond5.getEnd();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date9, timeZone11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date6, timeZone11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = regularTimePeriod16.getMiddleMillisecond();
//        java.lang.String str18 = regularTimePeriod16.toString();
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) month13, regularTimePeriod16);
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener20);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560279599999L + "'", long17 == 1560279599999L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "11-June-2019" + "'", str18.equals("11-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries19);
//    }
//}

